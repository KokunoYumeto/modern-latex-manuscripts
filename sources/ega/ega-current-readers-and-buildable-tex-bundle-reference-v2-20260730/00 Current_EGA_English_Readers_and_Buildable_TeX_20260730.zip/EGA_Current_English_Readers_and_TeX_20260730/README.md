# Current EGA English readers and buildable TeX

This one-click archive contains one cumulative English reader PDF and its
complete buildable TeX closure for every current EGA scope on the public
record: EGA 0/III Sections 8-13, complete EGA II through authority EOF, EGA
III Sections 1-7, and EGA IV Sections 1-10.

The EGA II subtree is the complete source-aligned reference-v2 successor: 165
letter pages, 1,028 stable targets, 2,078 valid internal GoTo actions, and
2,538 named destinations. The EGA 0, EGA III, and EGA IV subtrees are
byte-identical to the preceding bundle.

The archive excludes provenance archives, QA images, raw logs, authority
scans, historical releases, and project-production notes. `SHA256SUMS.csv`
covers every other member exactly.
