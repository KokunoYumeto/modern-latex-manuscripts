# Current EGA English readers and buildable TeX

This bundle is the compact reader-facing entry point for the current EGA
English work preserved in the archive.

- EGA 0/III: assigned source-first Sections 8-13 working reader.
- EGA I: complete source-aligned working reader through bibliography and both
  indexes; exhaustive reference-v2 certification remains a later successor.
- EGA II: complete source-aligned reference-v2 working reader through EOF.
- EGA III: assigned source-first Sections 1-7 working reader.
- EGA IV: cumulative source-aligned Sections 1-10 working reader.

Each volume directory contains one cumulative reader PDF and its complete
buildable TeX closure. French authorities, OCR, raw logs, render trees,
private paths, and workflow material are excluded.

These are scholarly working translations, not critical editions, peer-review
or mathematical certifications, rights determinations, accessibility
remediation, or a claim that all of EGA has been translated and checked.
