# Current EGA English Readers and TeX

This bundle contains every cumulative English EGA reader currently present
on the public archive surface, together with the complete TeX source needed
to build each reader, as of 2026-07-30.

It is deliberately reader-focused. It excludes provenance archives, QA
images, machine ledgers, build logs, historical releases, authority scans,
and internal project notes. Those materials remain available separately in
the public archive.

## Contents and build entry points

| Scope | Reader | Build entry point | Engine |
| --- | --- | --- | --- |
| EGA 0 working reader | `EGA0/reader/EGA0_English_Working_Reader.pdf` | `EGA0/source/ega0.tex` | pdfLaTeX |
| EGA II complete working reader | `EGA2/reader/EGA2_English_Reader.pdf` | `EGA2/source/ega2.tex` | pdfLaTeX |
| EGA III Sections 1-7 | `EGA3/reader/EGA3_English_Working_Reader_Sections1_7.pdf` | `EGA3/source/ega3.tex` | pdfLaTeX |
| EGA IV Sections 1-10 | `EGA4/reader/EGA4_English_Working_Reader_Sections1_10.pdf` | `EGA4/source/build_harness/EGA4_English_Sections1_10.tex` | pdfLaTeX |

Run the stated engine from the directory containing the entry point. Use
BibTeX where the reader invokes a bibliography, and use multiple LaTeX
passes for converged cross-references and contents.

The EGA surface is still growing; the scope labels above are part of the
identity of this bundle. These are scholarly working translations and
reading editions, not critical editions or a new license for underlying
source works. See the separate public provenance and rights materials for
detailed scope and attribution.

`SHA256SUMS.csv` records every other member by relative path, byte count,
and SHA-256.
