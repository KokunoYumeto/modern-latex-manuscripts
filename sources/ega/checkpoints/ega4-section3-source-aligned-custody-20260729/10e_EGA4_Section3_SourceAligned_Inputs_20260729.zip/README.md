# EGA IV Section 3 source-aligned integration input

This archive preserves the completed source-aligned English
successor for EGA IV Section 3 in one compact package.

- Scope: subsections 3.1-3.4.
- Reader: 13 A4 pages.
- Editable TeX and eight exact machine controls are included.
- The single diagram is native TeX and passed direct authority
  review at native 600 ppi and vector-output 5000 dpi.
- Authority scans and redundant target renders are not included.
- The visual ledger preserves all 51 on-disk PNG identities.
- Continuation: EGA IV Section 4.

This is an off-PC integration input, not a complete EGA IV reader,
rights determination, or critical-edition claim.
