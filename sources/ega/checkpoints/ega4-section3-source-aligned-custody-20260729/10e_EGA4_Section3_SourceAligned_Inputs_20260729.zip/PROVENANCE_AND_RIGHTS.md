# Provenance and rights

The controlling authority is the NUMDAM EGA IV Part 2 French PDF.
- bytes: 31819022
- SHA-256: `C3E960AA1C5C37046E8892D8A3CAC098E2738164136B5CDAA5D5D893F89931DA`

The authority PDF and authority-derived crops are not included.
The editable English file is a source-aligned working successor.
This package grants no new rights in the underlying French work.
Pre-existing user-supplied OCR was consulted read-only only as a
locator and drafting witness; the source image remained authority.

This is bounded Section 3 integration input, not a complete EGA IV
edition or a critical edition. Section 4 is the next cursor.
