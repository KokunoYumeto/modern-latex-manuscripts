# EGA IV Sections 1-2 source-aligned integration inputs

This archive preserves the completed source-aligned English
successors for EGA IV Sections 1 and 2 in one compact package.

- Section 1: subsections 1.1-1.10, 21-page bounded reader.
- Section 2: subsections 2.1-2.8, 27-page bounded reader.
- Editable TeX and exact machine validation controls are included.
- Six native diagrams have direct lead high-zoom authority review.
- Authority scans and redundant target renders are not included.
- The visual ledger preserves all 76 on-disk PNG identities and
  records their rights or redundancy disposition.
- Continuation: EGA IV Section 3.

The package is an off-PC integration input. It is not a complete
EGA IV reader, rights determination, or critical-edition claim.
