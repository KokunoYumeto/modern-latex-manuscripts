# Source-alignment status

State: paused at a clean source-aligned checkpoint.

- Admitted English scope: opening through Corollary 4.4.5, inclusive.
- Resume cursor: Proposition 4.4.6.
- Authority coordinate: physical page 77 / printed page 80.
- Editable coordinate: `source/ega2/ega2-4.tex`, line 529.

Later inherited English is retained for layered reading and build continuity
but has not yet passed the source-alignment gate.
