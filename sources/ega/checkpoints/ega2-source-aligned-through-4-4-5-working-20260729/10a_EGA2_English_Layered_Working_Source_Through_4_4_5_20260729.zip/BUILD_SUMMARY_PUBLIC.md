# Public build summary

- XeLaTeX passes: three consecutive successful passes.
- Fatal or error-pattern count: zero.
- Reader pages: 151.
- Reader SHA-256: `C34EE831E694422ADA8824CA738B1DB7F71A3EBE07620D406853F826BC7B418C`.
- Internal build-log SHA-256: `96DB4B0AFAA25047303B010ACB5C7C1041DA36974F05C477D0A74484371F46BD`.
- Internal final-console SHA-256: `1864BFA20480778397FA76E71808D99A2DD4DD992D103E96701854F22FBF9698`.
- Manual seam review: reader pages 59-60 through Corollary 4.4.5 and the
  intact transition into Proposition 4.4.6.

Raw logs and rendered page PNGs are excluded from this compact public
package because they add no mathematical content and can expose local build
details.
