# Provenance and rights

The controlling authority is the NUMDAM EGA IV Part 2 French PDF.
- bytes: 31819022
- pages: 228
- SHA-256: `C3E960AA1C5C37046E8892D8A3CAC098E2738164136B5CDAA5D5D893F89931DA`

The authority PDF and authority-derived crops are not included. The
English components are bounded source-aligned working successors.
This package grants no new rights in the underlying French work.
Pre-existing user-supplied OCR was read-only locator/drafting evidence;
the source images remained authority and no OCR was generated or rerun.

This is EGA IV Sections 4.1-4.4 integration input, not a complete EGA IV
edition, critical edition, peer review, or rights determination.
