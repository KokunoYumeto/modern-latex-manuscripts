# EGA IV Sections 4.1-4.4 source-aligned integration input

This archive preserves the completed English source-aligned successor
for EGA IV Sections 4.1-4.4 in one compact package.

- Four editable TeX components and a frozen aggregator are included.
- A reproducible XeLaTeX harness and stable 10-page reader are included.
- All four producer validation controls report PASS with errors[].
- Diagram 4.2.1.3 is native TeX and passed 5,000-dpi comparison.
- Authority pixels and redundant target renders are not included.
- The visual ledger binds all 33 in-scope PNG identities.
- Continuation: EGA IV Section 4.5.

This is off-PC integration custody, not a complete EGA IV reader or a
new license grant.
