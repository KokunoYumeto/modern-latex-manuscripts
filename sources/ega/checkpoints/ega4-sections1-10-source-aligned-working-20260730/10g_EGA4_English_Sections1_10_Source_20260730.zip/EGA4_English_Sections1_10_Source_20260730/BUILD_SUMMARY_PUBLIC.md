# Public build summary

- Engine: MiKTeX pdfTeX 1.40.29
- Passes: 4
- Exit status: 0 on every pass
- Passes 3 and 4 console SHA-256:
  `6359EF68CEBE4CB6AC6AD9F82BA9A8E32D0958700FBB756C4BD3B65DD9225547`
- Reader: 268 letter-size pages
- Named destinations: 1,438
- Internal GoTo annotations: 2,708
- Broken GoTo annotations: 0
- Unique font resources: 20
- Type 3 fonts: 0
- Undefined citations: 0
- Visible `[?]` citations: 0
- Undefined hyperlink warnings: 1,041 occurrences / 500 unique names
- Overfull boxes: 0
- Underfull boxes: 1

The public build log is summarized rather than bundled because raw TeX logs
contain host-local paths.
