# EGA IV, Sections 1-10

This archive contains the editable source for the cumulative English working
reader covering EGA IV Sections 1 through 10.

## Reading surface

- `build_harness/EGA4_English_Sections1_10.tex` is the reader-clean public
  master.
- `build_harness/ega4_sections01_10_source_aligned_cumulative_r1.tex` is the
  exact sealed production master.
- `source/` contains the exact 37 source files used by the sealed production
  build.

The reader-clean wrapper changes no mathematical source file. It uses a plain
mathematical title and renders the two source-bibliography calls `IV-32` and
`IV-34` as the literal printed numbers `[32]` and `[34]`, because the terminal
EGA IV bibliography lies outside this bounded Sections 1-10 reader.

## Authority and lineage

The controlling authority for this source-aligned checkpoint is the NUMDAM
EGA IV Part 2 French original, 228 pages, 31,819,022 bytes, SHA-256
`C3E960AA1C5C37046E8892D8A3CAC098E2738164136B5CDAA5D5D893F89931DA`.
That PDF is already present on the public EGA record and is not duplicated in
this ZIP.

The broader editable English tree descends from the public
[`ryankeleti/ega`](https://github.com/ryankeleti/ega) community project. The
frozen comparison snapshot used in the local intake was commit
`3d7afe28c99d1887ccdb85acf2ca1afd93fb1971`. No repository-root license grant
was found in that snapshot, so this package does not infer one. Other English
comparisons and the user's pre-existing OCR were drafting or locator witnesses
only; the French source remained controlling.

## Quality boundary

The translation, source, build, and layout gates passed for Sections 1-10.
The reader is not yet convention-v2 reference-complete. Exactly 1,041 printed
locator occurrences across 500 unique names are not clickable: 53 targets
inside Sections 1-10, 17 later EGA IV targets, and 430 targets in EGA 0-III or
other external works. Existing links remain valid, and printed locator text is
preserved.

This is a scholarly working translation, not complete EGA IV, complete EGA, a
critical edition, rights determination, peer review, mathematical
certification, or tagged-PDF accessibility remediation.
