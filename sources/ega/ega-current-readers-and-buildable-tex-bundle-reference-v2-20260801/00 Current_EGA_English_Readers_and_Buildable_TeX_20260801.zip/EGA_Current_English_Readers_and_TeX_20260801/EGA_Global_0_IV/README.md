# EGA 0-IV complete linked English reader

Open the PDF in `reader/` for one continuous EGA 0-IV reader. The
`source/` directory is its complete buildable TeX closure. Internal
links work within and across the five volumes.

This is a working English reader, not a critical edition or a new
rights grant.
