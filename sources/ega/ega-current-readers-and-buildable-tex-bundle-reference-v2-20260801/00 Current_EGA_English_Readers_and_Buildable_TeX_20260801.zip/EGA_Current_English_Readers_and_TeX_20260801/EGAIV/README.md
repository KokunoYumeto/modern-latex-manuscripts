# EGA IV complete English reference-v2 reader

The reader covers Sections 1-21 and all backmatter through EOF. Its source
directory contains the complete 59-file TeX closure. Cross-volume references
remain visible nonlinks; all 7,374 local GoTo actions resolve.

This is a source-aligned working translation, not a critical edition or a new
rights grant.
