# Current EGA English readers and TeX

This one-click bundle contains cumulative English working readers and complete
buildable TeX for EGA 0, I, II, the published EGA III text, and EGA IV through
EOF. EGA IV is the 651-page complete reference-v2 successor.

These are working translations, not critical editions or new rights grants.
