# Current EGA English readers and buildable TeX

Start with `EGA_Global_0_IV/reader/` for one continuous EGA 0-IV PDF.
The EGA0, EGA1, EGA2, EGAIII, and EGAIV directories contain the five
standalone readers. Every reader has its complete buildable TeX here.

These are working English readers, not critical editions or new
rights grants.
