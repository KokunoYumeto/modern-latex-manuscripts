Carl Friedrich Gauss: Collected Works
Modern English and German translations

The collected English reader has 655 pages; the German reader has 682 pages.
Each contains complete Volume I, followed by the historical title matter,
the first five complete papers of Volume II:

A New Proof of an Arithmetical Theorem (Theorematis arithmetici demonstratio
nova), Articles 1–7, presented on January 15, 1808.

Summation of Certain Special Series (Summatio quarumdam serierum singularium),
Articles 1–36, presented on August 24, 1808.

New Proofs and Extensions of the Fundamental Theorem in the Theory of Quadratic
Residues (Theorematis fundamentalis in doctrina de residuis quadraticis
demonstrationes et ampliationes novae), presented on February 10, 1817:
the introduction, fifth proof (Articles 1–3), sixth proof (Articles 1–6) and
new algorithm (Articles 1–6).

Theory of Biquadratic Residues, First Paper (Theoria residuorum biquadraticorum,
commentatio prima), Articles 1–23, presented on April 5, 1825.

Theory of Biquadratic Residues, Second Paper (Theoria residuorum biquadraticorum,
commentatio secunda), historical title and Articles 24–76, presented on April 15, 1831.
Five complete self-reviews follow the five papers: May 12 and September 19,
1808; March 10, 1817; April 11, 1825; and April 23, 1831.
Seven reviews of other writings follow: March 11, 1809; March 23, 1812;
November 3, 1814; November 7, 1816; August 9, 1817; December 19, 1825; and July 9, 1831.
They concern a work on irrational radicals, the factor tables of Chernac and
Burckhardt, Erchinger’s construction of the regular seventeen-sided polygon,
and Seeber’s positive ternary quadratic forms.
The manuscript work Solution of the Congruence X^m−1 ≡ 0 follows,
comprising the complete first part of Chapter VI of Analysis of Residues,
Articles 237–252. General Investigations of Congruences, Chapter VIII of
Analysis of Residues, contains Articles 330–375 as printed, including the unfinished ending of Article 375. R. Dedekind's complete historical remarks follow. The title and Articles 1–16 of Further Development of the Investigations of Pure Equations follow them. Later
Volume-II writings and other volumes are outside this selection.

Volume I contains the historical title matter, dedication, preface, all seven
sections (Articles 1–366), five historical additions, Tables I–III, the historical
contents, both imprints, the manuscript appendix and the historical editor's
closing note. Contents page references retain the source pagination.

Historical sources: Carl Friedrich Gauss, Werke, Volume I, Göttingen, 1863;
Volume II, second printing, Göttingen, 1876. Disquisitiones Arithmeticae was
first published in Leipzig in 1801.

Originally German passages in the Volume-I appendix and editorial closing,
German Volume-II title matter, all twelve reviews and the manuscript
division title and R. Dedekind's historical remarks are identified as modern
German renderings. The original German review texts are supplied separately.
Historical German and Latin bodies are preserved in the originals directories.

The package contains editable LaTeX text, mathematics and tables, and the genuine
portraits used in the readers. The volume_I and volume_II directories contain
english and german sources. Build main.tex with XeLaTeX twice, using Latin
Modern, Babel, pdflscape and longtable. The collected readers present the volumes
in numerical order; the individual volume readers are also supplied.

English and German translations prepared using OpenAI GPT-6.1 Sol.

Translation sources and terminology

These English and German texts are translated from Gauss's original-language
editions. Earlier translations are consulted to standardize mathematical
terminology and usage; they are not reproduced as this edition's running text.
The original mathematical formulations remain those of Gauss's source.

H. Maser, German editor and translator, Carl Friedrich Gauss' Untersuchungen
über höhere Arithmetik, Berlin: Julius Springer, 1889, is a reference for
German arithmetical terminology and corresponding passages.
https://archive.org/details/carlfriedrichga00gausgoog

James Caddall Morehead and Adam Miller Hiltebeitel, translators, General
Investigations of Curved Surfaces of 1827 and 1825, Princeton University
Library, 1902 (Project Gutenberg 36856), and Paul Taylor's English translation
of Gauss's second proof of the fundamental theorem of algebra, with Bernard
Leak, 1983, are references for English mathematical terminology and usage.
Their geometrical and algebraic subject matter differs from these arithmetic
papers; they do not supply replacement text or proofs for them.
https://www.gutenberg.org/ebooks/36856
https://www.paultaylor.eu/misc/gauss.html

Contemporary German terminology is also informed by Ulrich Görtz, Algebra,
Wintersemester 2021/22, Section 3.1, and Lineare Algebra II, Sommersemester
2021, Section 18.4; and Nikolay Moshchevitin, Eine Bemerkung über positiv
definite quadratische Formen und rationale Punkte, arXiv:1510.06214v3.
These are terminology references, not translations of the present works.
https://math.ug/a-ws2122/sect0006.html
https://math.ug/la2-ss21/sec-quotient-ring.html
https://arxiv.org/abs/1510.06214v3

Quellen und Terminologie der Übersetzungen

Die englischen und deutschen Texte sind aus Gauss' originalsprachlichen
Ausgaben übersetzt. Frühere Übersetzungen dienen dem Abgleich der
mathematischen Terminologie und des Sprachgebrauchs; ihr Wortlaut wird nicht
als fortlaufender Text dieser Ausgabe übernommen. Die mathematischen
Formulierungen bleiben die der Originalvorlage. Die oben genannten
Übersetzer und Autoren werden für diese terminologische Nutzung gewürdigt.
