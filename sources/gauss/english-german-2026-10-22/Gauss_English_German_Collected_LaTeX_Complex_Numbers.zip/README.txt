Carl Friedrich Gauss: Collected Works
Modern English and German translations

The collected English reader has 800 pages; the German reader has 830 pages.
Each contains complete Volume I, followed by the historical title matter,
the first five complete papers of Volume II:

A New Proof of an Arithmetical Theorem (Theorematis arithmetici demonstratio
nova), Articles 1–7, presented on January 15, 1808.

Summation of Certain Special Series (Summatio quarumdam serierum singularium),
Articles 1–36, presented on August 24, 1808.

New Proofs and Extensions of the Fundamental Theorem in the Theory of Quadratic
Residues (Theorematis fundamentalis in doctrina de residuis quadraticis
demonstrationes et ampliationes novae), presented on February 10, 1817:
the introduction, fifth proof (Articles 1–3), sixth proof (Articles 1–6) and
new algorithm (Articles 1–6).

Theory of Biquadratic Residues, First Paper (Theoria residuorum biquadraticorum,
commentatio prima), Articles 1–23, presented on April 5, 1825.

Theory of Biquadratic Residues, Second Paper (Theoria residuorum biquadraticorum,
commentatio secunda), historical title and Articles 24–76, presented on April 15, 1831.
Five complete self-reviews follow the five papers: May 12 and September 19,
1808; March 10, 1817; April 11, 1825; and April 23, 1831.
Seven reviews of other writings follow: March 11, 1809; March 23, 1812;
November 3, 1814; November 7, 1816; August 9, 1817; December 19, 1825; and July 9, 1831.
They concern a work on irrational radicals, the factor tables of Chernac and
Burckhardt, Erchinger’s construction of the regular seventeen-sided polygon,
and Seeber’s positive ternary quadratic forms.
The manuscript work Solution of the Congruence X^m−1 ≡ 0 follows,
comprising the complete first part of Chapter VI of Analysis of Residues,
Articles 237–252. General Investigations of Congruences, Chapter VIII of
Analysis of Residues, contains Articles 330–375 as printed, including the unfinished ending of Article 375. R. Dedekind's complete historical remarks follow. Further Development of the Investigations of Pure Equations follows in full as
printed, with its title, Articles 1–19 and R. Dedekind's historical remarks.
The fragment Proof of Some Theorems Concerning the Periods of Classes of Binary
Quadratic Forms contains both theorems, the unfinished ending of the second
proof and Stern's historical remark. The text marked [I.] of On the Connection
between the Number of Classes into Which Binary Quadratic Forms Are Distributed
and Their Determinant, First Paper, follows in full as printed, with its title
and Articles 1–8. The text marked [II.] of the same first paper, presented in
1837, is also included in full as printed, with its title and Articles 1–8.
Fragments III–X follow in full as printed, with their historical editorial
notes, followed by the complete historical remarks on [I.]–[X.]. The fragments
include representation counts and the distributions of quadratic residues
in eighths and twelfths, with their historical tables.
The posthumous texts [I.] and [II.] of On the Theory of Biquadratic Residues follow. Text [I.] contains its title and complete Articles 1–19, including all five editable diagrams. Text [II.], Preparations for the General Theory of Biquadratic Residues, contains both preparatory sections (1) and (2) and complete Articles 1–12 as printed. They treat oriented lines, winding and boundary conventions, residue classes, decidents and their composition, the residue 1+i, and the point, square and ligature constructions for biquadratic characters. Their originally German prose is rendered in modern German in the German reader; all original German bodies and editable diagrams are supplied separately.

Text [III.], Theory of Biquadratic Residues, follows in full as printed, with its title and Articles 1–14, including the joint heading 7–8. It treats least-residue classes, decidents and the stated reciprocity theorem, coordinate bounds, parity sums and all boundary exceptions. Text [IV.] follows in full as printed, Articles 1–5, with its coordinate relations, two bound tables, intensor sums and sign table; its second method ends after the fourth step. The German reader renders the original German in modern German; the historical originals are supplied separately.

Later Volume-II writings and other volumes are outside this selection.

Volume I contains the historical title matter, dedication, preface, all seven
sections (Articles 1–366), five historical additions, Tables I–III, the historical
contents, both imprints, the manuscript appendix and the historical editor's
closing note. Contents page references retain the source pagination.

Historical sources: Carl Friedrich Gauss, Werke, Volume I, Göttingen, 1863;
Volume II, second printing, Göttingen, 1876. Disquisitiones Arithmeticae was
first published in Leipzig in 1801.

Originally German passages in the Volume-I appendix and editorial closing,
German Volume-II title matter, all twelve reviews and the manuscript
division title, Fragments III–IV and VIII–X, and the historical remarks
(including those of R. Dedekind and Stern) are identified as modern
German renderings. The original German review texts are supplied separately.
Historical German and Latin bodies are preserved in the originals directories.

The package contains editable LaTeX text, mathematics, tables and diagrams, and the genuine
portraits used in the readers. The volume_I and volume_II directories contain
english and german sources. Build main.tex with XeLaTeX twice, using Latin
Modern, Babel, pdflscape and longtable. The collected readers present the volumes
in numerical order; the individual volume readers are also supplied.

AI-translated into English and German using OpenAI GPT-6.1 Sol; AI-produced typesetting.

Geometrical Aspect of Ternary Forms is included with its geometric definitions, crystallographic tables, two editable diagrams and Schering’s historical remarks. Its originally German prose is rendered in modern German in the German reader; the historical German and Latin originals are supplied separately.

Text [V.], Theory of Biquadratic Residues, follows in full as printed, Articles 1–17, with its editable lattice diagram, numerical examples, parity tables and 128-case table. Text [VI.] follows in full as printed, with its title and Articles 1–6: complete residue systems, associated quarter systems, the character and its independence, boundary conventions and the four-case construction. Their original German prose is rendered in modern German in the German reader; the historical originals are supplied separately.

Schering’s complete historical remarks on the six biquadratic manuscript texts [I.]–[VI.] follow, including his dating qualifications, geometric interpretations, summation derivations and signature. The originally German remarks are rendered in modern German in the German reader; their historical originals are supplied separately.

On the Theory of Complex Numbers follows in full as printed: six fragments [I.]–[VI.] on the decomposition of cubes, the nearest integer, measures of numbers, units and congruences, followed by Schering’s historical remarks. The originally German passages are rendered in modern German in the German reader; their historical originals are supplied separately.

Translation sources and terminology

These English and German texts are AI-translated from Gauss's original-language
editions. Earlier translations are consulted to standardize mathematical
terminology and usage; they are not reproduced as this edition's running text.
The original mathematical formulations remain those of Gauss's source.

H. Maser, German editor and translator, Carl Friedrich Gauss' Untersuchungen
über höhere Arithmetik, Berlin: Julius Springer, 1889, is a reference for
German arithmetical terminology and corresponding passages.
https://archive.org/details/carlfriedrichga00gausgoog

James Caddall Morehead and Adam Miller Hiltebeitel, translators, General
Investigations of Curved Surfaces of 1827 and 1825, Princeton University
Library, 1902 (Project Gutenberg 36856), and Paul Taylor's English translation
of Gauss's second proof of the fundamental theorem of algebra, with Bernard
Leak, 1983, are references for English mathematical terminology and usage.
Their geometrical and algebraic subject matter differs from these arithmetic
papers; they do not supply replacement text or proofs for them.
https://www.gutenberg.org/ebooks/36856
https://www.paultaylor.eu/misc/gauss.html

Contemporary German terminology is also informed by Ulrich Görtz, Algebra,
Wintersemester 2021/22, Section 3.1, and Lineare Algebra II, Sommersemester
2021, Section 18.4; and Nikolay Moshchevitin, Eine Bemerkung über positiv
definite quadratische Formen und rationale Punkte, arXiv:1510.06214v3.
These are terminology references, not translations of the present works.
https://math.ug/a-ws2122/sect0006.html
https://math.ug/la2-ss21/sec-quotient-ring.html
https://arxiv.org/abs/1510.06214v3

Quellen und Terminologie der Übersetzungen

Die englischen und deutschen Texte sind aus Gauss' originalsprachlichen
Ausgaben KI-übersetzt. Frühere Übersetzungen dienen dem Abgleich der
mathematischen Terminologie und des Sprachgebrauchs; ihr Wortlaut wird nicht
als fortlaufender Text dieser Ausgabe übernommen. Die mathematischen
Formulierungen bleiben die der Originalvorlage. Die oben genannten
Übersetzer und Autoren werden für diese terminologische Nutzung gewürdigt.

Crystallographic terminology references: Ian O. Angell and Moreton Moore, Projections of cubic crystals, IUCr, Table 2, https://www.iucr.org/what-we-do/education/pamphlets/projections-of-cubic-crystals ; Th. Hahn, H. Klapper, U. Müller and M. I. Aroyo, Point groups and crystal classes, International Tables for Crystallography A (2016), chapter 3.2, https://doi.org/10.1107/97809553602060000930 . These references guide terminology and usage; their running prose is not reproduced.


## AI authorship and publication rights

These English and German editions are AI-translated using OpenAI GPT-6.1 Sol, with AI-produced typesetting. Gauss is the author of the historical mathematical text; signed historical editorial contributions retain their authorship. The named human translations and writings cited above are credited for their stated terminology and usage roles.

The editions are available free of charge for non-commercial, purely educational purposes. Publication rests on the publisher's presumption that the respective rights holders would not object; this is not established permission. Free access to a source does not itself authorize derivative publication. Rights in the originals and any protected derivative contributions remain with their respective rights holders. No project-wide licence or public-domain dedication is granted here.

Rights holders may raise objections through the [GitHub issue page](https://github.com/KokunoYumeto/modern-latex-manuscripts/issues). The publisher undertakes to take down the affected material upon a rights holder's request.

[Scholarly citation metadata](https://github.com/KokunoYumeto/modern-latex-manuscripts/blob/main/sources/gauss/english-german-2026-10-22/CITATIONS.bib) identifies the original editions and the named terminology references.

