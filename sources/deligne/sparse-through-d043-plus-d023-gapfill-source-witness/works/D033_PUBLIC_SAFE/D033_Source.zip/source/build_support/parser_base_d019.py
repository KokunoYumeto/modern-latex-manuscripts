#!/usr/bin/env python3
"""Generate deterministic, standalone D019 TeX sources without compiling them.

The generator is deliberately limited to the frozen edition records, the accepted
asset ledger, and local presentation fallbacks.  It never mutates corpus inputs,
uses no network resources, and invokes no external programs.  PDF compilation is
a later, separately authorized operation.
"""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import io
import json
import re
import shutil
import sys
import unicodedata
from pathlib import Path
from typing import Any, Iterable


WORK_ID = "D019"
REPAIR_SCHEMA = "d019_canonical_repair_map_v1"
BUILD_SCHEMA = "d019_canonical_tex_build_v1"
EXPECTED_PAGES = 73
EXPECTED_ASSETS = 144
SOURCE_SHA256 = "2AE487E4F774E805CD9428C7CF66C2F31CD1A67208FE38AEA2BA525EE3A74B8B"

LAYER_FILES = {
    "source_language": "edition/source_language.ndjson",
    "english_standalone": "edition/english_standalone.ndjson",
    "apparatus": "edition/apparatus.ndjson",
}

OUTPUT_TEX = {
    "source_language": "D019_SOURCE_LANGUAGE_CANONICAL.tex",
    "english_standalone": "D019_ENGLISH_CANONICAL.tex",
    "apparatus": "D019_APPARATUS_CANONICAL.tex",
}

OUTPUT_DATA = {
    "source_language": "source_language_canonical.ndjson",
    "english_standalone": "english_canonical.ndjson",
    "apparatus": "apparatus_canonical.ndjson",
}

DOCUMENT_SETTINGS = {
    "source_language": {
        "title": "Théorie de Hodge, III - Édition canonique française",
        "running": "Édition canonique française",
        "babel": "french",
    },
    "english_standalone": {
        "title": "Hodge Theory, III - Canonical English Edition",
        "running": "Canonical English Edition",
        "babel": "english",
    },
    "apparatus": {
        "title": "Hodge Theory, III - Critical Apparatus",
        "running": "Critical Apparatus",
        "babel": "english",
    },
}

MARKER_RE = re.compile(r"⟦(P\d{4}-A\d{2})(?:\s+—\s*(.*?))?⟧")
KNOWN_BACKSLASH_RE = re.compile(r"\\(?:xrightarrow\{|[{}]|Gr\b|W\b)")

STRONG_MATH_CHARS = frozenset(
    "_^=<>≤≥≠≃≅≈→←↪↩↠⇄⇆⇒⇐⇔∈∉∋∩∪⊗⊕⊙×±∓∑∏∂∇∞"
    "⊂⊃⊆⊇∼≡∨∧¬∀∃∅∫∏√⊢⊣⊥∥∣ℤℚℝℂℕℓℋℱℒℬℰ"
    "𝒪𝒞𝓛𝓗𝓕𝓔ΩΔΓΛΠΣΦΨαβγδεζηθικλμνξπρστφχψω"
    "•♮"
)

MATH_CHAR_MAP = {
    "Ȳ": r"\overline{Y}",
    "Ỹ": r"\widetilde{Y}", "ū": r"\overline{u}",
    "α": r"\alpha", "β": r"\beta", "γ": r"\gamma", "δ": r"\delta",
    "ε": r"\varepsilon", "ζ": r"\zeta", "η": r"\eta", "θ": r"\theta",
    "ι": r"\iota", "κ": r"\kappa", "λ": r"\lambda", "μ": r"\mu",
    "ν": r"\nu", "ξ": r"\xi", "π": r"\pi", "ρ": r"\rho",
    "σ": r"\sigma", "τ": r"\tau", "υ": r"\upsilon", "φ": r"\varphi",
    "χ": r"\chi", "ψ": r"\psi", "ω": r"\omega",
    "Γ": r"\Gamma", "Δ": r"\Delta", "Θ": r"\Theta", "Λ": r"\Lambda",
    "Ξ": r"\Xi", "Π": r"\Pi", "Σ": r"\Sigma", "Φ": r"\Phi",
    "Ψ": r"\Psi", "Ω": r"\Omega", "↓": r"\downarrow", "↑": r"\uparrow",
    "⇉": r"\rightrightarrows", "⇇": r"\leftleftarrows",
    "ℤ": r"\mathbb{Z}",
    "ℚ": r"\mathbb{Q}",
    "ℝ": r"\mathbb{R}",
    "ℂ": r"\mathbb{C}",
    "ℕ": r"\mathbb{N}",
    "ℓ": r"\ell",
    "ℋ": r"\mathcal{H}",
    "ℱ": r"\mathcal{F}",
    "ℒ": r"\mathcal{L}",
    "ℬ": r"\mathcal{B}",
    "ℰ": r"\mathcal{E}",
    "𝒪": r"\mathcal{O}",
    "𝒞": r"\mathcal{C}",
    "𝓛": r"\mathcal{L}",
    "𝓗": r"\mathcal{H}",
    "𝓕": r"\mathcal{F}",
    "𝓔": r"\mathcal{E}",
    "→": r"\to",
    "←": r"\leftarrow",
    "↪": r"\hookrightarrow",
    "↩": r"\hookleftarrow",
    "↠": r"\twoheadrightarrow",
    "⇄": r"\rightleftarrows",
    "⇆": r"\rightleftarrows",
    "⇒": r"\Rightarrow",
    "⇐": r"\Leftarrow",
    "⇔": r"\Leftrightarrow",
    "≤": r"\leq",
    "≥": r"\geq",
    "≠": r"\neq",
    "≃": r"\simeq",
    "≅": r"\cong",
    "≈": r"\approx",
    "∈": r"\in",
    "∉": r"\notin",
    "∋": r"\ni",
    "∩": r"\cap",
    "∪": r"\cup",
    "⊗": r"\otimes",
    "⊕": r"\oplus",
    "⊙": r"\odot",
    "×": r"\times",
    "±": r"\pm",
    "∓": r"\mp",
    "∑": r"\sum",
    "∏": r"\prod",
    "∂": r"\partial",
    "∇": r"\nabla",
    "∞": r"\infty",
    "⊂": r"\subset",
    "⊃": r"\supset",
    "⊆": r"\subseteq",
    "⊇": r"\supseteq",
    "∼": r"\sim",
    "≡": r"\equiv",
    "∨": r"\vee",
    "∧": r"\wedge",
    "¬": r"\neg",
    "∀": r"\forall",
    "∃": r"\exists",
    "∅": r"\varnothing",
    "√": r"\sqrt{}",
    "∥": r"\parallel",
    "∣": r"\mid",
    "•": r"\bullet",
    "♮": r"\natural",
}

OPERATORS = frozenset(
    {
        "Aut",
        "Biext",
        "Coker",
        "Ext",
        "Gr",
        "Hom",
        "Im",
        "Ker",
        "Lie",
        "Pic",
        "Spec",
        "Sym",
        "coker",
        "cosq",
        "deg",
        "dim",
        "exp",
        "lim",
        "log",
        "mod",
        "pr",
        "sq",
    }
)

TEXT_ESCAPES = {
    "#": r"\#{}",
    "$": r"\${}",
    "%": r"\%{}",
    "&": r"\&{}",
    "_": r"\textunderscore{}",
    "{": r"\{{}",
    "}": r"\}{}",
    "~": r"\textasciitilde{}",
    "^": r"\textasciicircum{}",
}


class BuildError(RuntimeError):
    """Raised when an input, repair, or output invariant fails."""


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def json_bytes(value: Any) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8")


def record_digest(record: dict[str, Any]) -> str:
    compact = json.dumps(record, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return sha256_bytes(compact.encode("utf-8"))


def ndjson_bytes(rows: Iterable[dict[str, Any]]) -> bytes:
    lines = [json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(",", ":")) for row in rows]
    return ("\n".join(lines) + "\n").encode("utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BuildError(message)


def load_ndjson(path: Path) -> list[dict[str, Any]]:
    require(path.is_file(), f"missing NDJSON input: {path}")
    rows: list[dict[str, Any]] = []
    for number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            raise BuildError(f"invalid JSON at {path}:{number}: {exc}") from exc
        require(isinstance(value, dict), f"record at {path}:{number} is not an object")
        rows.append(value)
    return rows


def load_ledger(path: Path) -> dict[str, dict[str, str]]:
    require(path.is_file(), f"missing asset ledger: {path}")
    with path.open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream, delimiter="\t"))
    require(len(rows) == EXPECTED_ASSETS, f"asset ledger has {len(rows)} rows, expected {EXPECTED_ASSETS}")
    ledger: dict[str, dict[str, str]] = {}
    for row in rows:
        asset_id = row.get("asset_id", "")
        require(re.fullmatch(r"P\d{4}-A\d{2}", asset_id) is not None, f"invalid asset id: {asset_id!r}")
        require(asset_id not in ledger, f"duplicate asset id in ledger: {asset_id}")
        require(row.get("status") == "ACCEPTED", f"asset is not accepted: {asset_id}")
        ledger[asset_id] = row
    return ledger


def validate_records(
    corpus: Path,
    layers: dict[str, list[dict[str, Any]]],
    ledger: dict[str, dict[str, str]],
) -> None:
    expected_pages = list(range(1, EXPECTED_PAGES + 1))
    for layer, rows in layers.items():
        require(len(rows) == EXPECTED_PAGES, f"{layer} has {len(rows)} rows, expected {EXPECTED_PAGES}")
        physical = [row.get("physical_page") for row in rows]
        require(physical == expected_pages, f"{layer} physical-page sequence is not exactly 1..73")
        seen_assets: set[str] = set()
        for row in rows:
            page = row["physical_page"]
            require(row.get("authority_pdf_page") == page + 1, f"{layer} page {page}: bad authority anchor")
            require(row.get("source_volume_page") == page + 667, f"{layer} page {page}: bad volume anchor")
            require(row.get("printed_page") == page + 4, f"{layer} page {page}: bad printed anchor")
            require(row.get("source_sha256") == SOURCE_SHA256, f"{layer} page {page}: source hash mismatch")
            require(row.get("disposition") == "INCLUDE_WORK", f"{layer} page {page}: disposition is not INCLUDE_WORK")
            require(isinstance(row.get("text"), str) and row["text"].strip(), f"{layer} page {page}: empty text")
            assets = row.get("assets")
            require(isinstance(assets, list), f"{layer} page {page}: assets is not a list")
            for asset in assets:
                require(isinstance(asset, dict), f"{layer} page {page}: malformed asset entry")
                asset_id = asset.get("id")
                require(asset_id in ledger, f"{layer} page {page}: unknown asset {asset_id!r}")
                require(asset_id not in seen_assets, f"{layer}: duplicate declared asset {asset_id}")
                seen_assets.add(asset_id)
                led = ledger[asset_id]
                require(int(led["physical_page"]) == page, f"{layer} page {page}: asset {asset_id} belongs to another page")
                require(asset.get("presentation_path") == led["presentation_path"], f"{layer} page {page}: asset path mismatch")
                require(asset.get("raw_path") == led["raw_crop_path"], f"{layer} page {page}: raw path mismatch")
                require(isinstance(asset.get("caption"), str) and asset["caption"].strip(), f"{layer} page {page}: empty asset caption")
        require(seen_assets == set(ledger), f"{layer}: declared asset set does not equal ledger set")

    for asset_id, row in ledger.items():
        presentation = corpus / row["presentation_path"]
        require(presentation.is_file(), f"missing presentation fallback: {presentation}")
        actual = sha256_file(presentation)
        require(actual == row["presentation_sha256"], f"presentation hash mismatch for {asset_id}")


def load_repairs(path: Path | None) -> tuple[dict[str, Any], str]:
    if path is None:
        empty = {"schema": REPAIR_SCHEMA, "work_id": WORK_ID, "repairs": []}
        return empty, sha256_bytes(json_bytes(empty))
    require(path.is_file(), f"repair map does not exist: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BuildError(f"invalid repair map JSON: {exc}") from exc
    require(isinstance(value, dict), "repair map must be a JSON object")
    require(value.get("schema") == REPAIR_SCHEMA, f"repair-map schema must be {REPAIR_SCHEMA!r}")
    require(value.get("work_id") == WORK_ID, f"repair-map work_id must be {WORK_ID!r}")
    require(isinstance(value.get("repairs"), list), "repair-map repairs must be a list")
    return value, sha256_file(path)


def apply_repairs(
    layers: dict[str, list[dict[str, Any]]], repair_map: dict[str, Any]
) -> tuple[dict[str, list[dict[str, Any]]], list[dict[str, Any]]]:
    repaired = copy.deepcopy(layers)
    receipts: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    for index, repair in enumerate(repair_map["repairs"], 1):
        require(isinstance(repair, dict), f"repair {index} is not an object")
        repair_id = repair.get("repair_id")
        require(isinstance(repair_id, str) and repair_id.strip(), f"repair {index}: missing repair_id")
        require(repair_id not in seen_ids, f"duplicate repair_id: {repair_id}")
        seen_ids.add(repair_id)
        layer = repair.get("layer")
        require(layer in repaired, f"{repair_id}: unknown layer {layer!r}")
        page = repair.get("physical_page")
        require(isinstance(page, int) and 1 <= page <= EXPECTED_PAGES, f"{repair_id}: invalid physical_page")
        record = repaired[layer][page - 1]
        require(record["physical_page"] == page, f"{repair_id}: internal page routing mismatch")
        if "authority_pdf_page" in repair:
            require(repair["authority_pdf_page"] == record["authority_pdf_page"], f"{repair_id}: authority page mismatch")
        justification = repair.get("justification")
        require(isinstance(justification, str) and justification.strip(), f"{repair_id}: missing justification")
        operation = repair.get("operation")
        require(operation in {"replace", "insert_before", "replace_asset_caption"}, f"{repair_id}: unsupported operation")
        old = repair.get("old")
        new = repair.get("new")
        expected_count = repair.get("expected_count")
        require(isinstance(old, str) and old, f"{repair_id}: old must be non-empty text")
        require(isinstance(new, str), f"{repair_id}: new must be text")
        require(isinstance(expected_count, int) and expected_count > 0, f"{repair_id}: expected_count must be positive")

        asset_ids = repair.get("asset_ids", [])
        require(isinstance(asset_ids, list) and all(isinstance(item, str) for item in asset_ids), f"{repair_id}: asset_ids must be strings")
        declared = {asset["id"] for asset in record["assets"]}
        require(set(asset_ids) <= declared, f"{repair_id}: asset_ids are not all declared on page {page}")

        before = record_digest(record)
        if operation in {"replace", "insert_before"}:
            actual_count = record["text"].count(old)
            require(actual_count == expected_count, f"{repair_id}: found {actual_count} occurrences, expected {expected_count}")
            if operation == "replace":
                record["text"] = record["text"].replace(old, new)
            else:
                record["text"] = record["text"].replace(old, new + old)
        else:
            asset_id = repair.get("asset_id")
            require(isinstance(asset_id, str) and asset_id in declared, f"{repair_id}: invalid asset_id")
            matches = [asset for asset in record["assets"] if asset["id"] == asset_id and asset.get("caption") == old]
            require(len(matches) == expected_count, f"{repair_id}: caption matched {len(matches)} times, expected {expected_count}")
            for asset in matches:
                asset["caption"] = new
        after = record_digest(record)
        require(after != before, f"{repair_id}: operation made no change")
        receipts.append(
            {
                "repair_id": repair_id,
                "layer": layer,
                "physical_page": page,
                "authority_pdf_page": record["authority_pdf_page"],
                "operation": operation,
                "expected_count": expected_count,
                "before_record_sha256": before,
                "after_record_sha256": after,
                "asset_ids": asset_ids,
                "justification": justification,
            }
        )
    return repaired, receipts


def validate_inherited_bindings(layers: dict[str, list[dict[str, Any]]]) -> None:
    for index in range(EXPECTED_PAGES):
        page = index + 1
        source = layers["source_language"][index]
        english = layers["english_standalone"][index]
        apparatus = layers["apparatus"][index]
        source_hash = record_digest(source)
        english_hash = record_digest(english)
        require(
            english.get("source_record_sha256") == source_hash,
            f"English page {page}: inherited source binding is stale",
        )
        require(
            apparatus.get("source_record_sha256") == source_hash,
            f"apparatus page {page}: inherited source binding is stale",
        )
        require(
            apparatus.get("english_record_sha256") == english_hash,
            f"apparatus page {page}: inherited English binding is stale",
        )


def bind_canonical_records(
    repaired: dict[str, list[dict[str, Any]]]
) -> tuple[dict[str, list[dict[str, Any]]], list[dict[str, Any]]]:
    """Bind downstream records to canonical upstream bytes and retain prior bindings."""
    canonical = copy.deepcopy(repaired)
    bindings: list[dict[str, Any]] = []
    for index in range(EXPECTED_PAGES):
        page = index + 1
        source = canonical["source_language"][index]
        english = canonical["english_standalone"][index]
        apparatus = canonical["apparatus"][index]

        source_hash = record_digest(source)
        inherited_english_source = english.get("source_record_sha256")
        require(
            "inherited_source_record_sha256" not in english,
            f"English page {page}: inherited binding field already exists",
        )
        english["inherited_source_record_sha256"] = inherited_english_source
        english["source_record_sha256"] = source_hash
        english_hash = record_digest(english)

        inherited_apparatus_source = apparatus.get("source_record_sha256")
        inherited_apparatus_english = apparatus.get("english_record_sha256")
        require(
            "inherited_source_record_sha256" not in apparatus
            and "inherited_english_record_sha256" not in apparatus,
            f"apparatus page {page}: inherited binding field already exists",
        )
        apparatus["inherited_source_record_sha256"] = inherited_apparatus_source
        apparatus["inherited_english_record_sha256"] = inherited_apparatus_english
        apparatus["source_record_sha256"] = source_hash
        apparatus["english_record_sha256"] = english_hash
        apparatus_hash = record_digest(apparatus)

        require(english["source_record_sha256"] == record_digest(source), f"English page {page}: canonical binding failed")
        require(apparatus["source_record_sha256"] == record_digest(source), f"apparatus page {page}: source binding failed")
        require(apparatus["english_record_sha256"] == record_digest(english), f"apparatus page {page}: English binding failed")
        bindings.append(
            {
                "physical_page": page,
                "authority_pdf_page": source["authority_pdf_page"],
                "source_language_record_sha256": source_hash,
                "english_record_sha256": english_hash,
                "apparatus_record_sha256": apparatus_hash,
                "inherited_english_source_record_sha256": inherited_english_source,
                "inherited_apparatus_source_record_sha256": inherited_apparatus_source,
                "inherited_apparatus_english_record_sha256": inherited_apparatus_english,
            }
        )
    return canonical, bindings


def escape_text(text: str) -> str:
    if "\\" in text:
        raise BuildError(f"unhandled backslash in text fragment: {text!r}")
    return "".join(TEXT_ESCAPES.get(char, char) for char in text)


def find_balanced(text: str, opening: int) -> tuple[str, int]:
    require(opening < len(text) and text[opening] == "{", "internal balanced-group error")
    depth = 0
    for position in range(opening, len(text)):
        char = text[position]
        if position > 0 and text[position - 1] == "\\":
            continue
        if char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                return text[opening + 1 : position], position + 1
    raise BuildError(f"unclosed brace in mathematical expression: {text!r}")


def script_argument(text: str, start: int) -> tuple[str, int]:
    require(start < len(text), f"missing script argument in {text!r}")
    if text[start] == "{":
        content, end = find_balanced(text, start)
        return math_tex(content), end
    for label in ("rec", "an", "ev"):
        if text.startswith(label, start) and (start + len(label) == len(text) or not text[start + len(label)].isalpha()):
            return r"\mathrm{" + label + "}", start + len(label)
    char = text[start]
    if char.isascii() and char.isdigit():
        end = start + 1
        while end < len(text) and text[end].isascii() and text[end].isdigit():
            end += 1
        return text[start:end], end
    if char.isascii() and char.isalpha():
        # Native TeX consumes one unbraced letter. In particular {}_kX_•
        # is a left subscript k on X, not a subscript named kX.
        return char, start + 1
    return math_tex(char), start + 1


def math_tex(text: str) -> str:
    """Convert one notation-bearing fragment to executable Unicode-math TeX."""
    output: list[str] = []
    position = 0
    length = len(text)
    while position < length:
        if text.startswith("lim←", position):
            output.append(r"\varprojlim ")
            position += len("lim←")
            continue
        if text.startswith(r"\backslash", position):
            output.append(r"\mathbin{\backslash}")
            position += len(r"\backslash")
            continue
        if text.startswith(r"\operatorname{", position):
            content, end = find_balanced(text, position + len(r"\operatorname"))
            require(re.fullmatch(r"[A-Za-z]+", content) is not None, "invalid operator name")
            output.append(r"\operatorname{" + content + "}")
            position = end
            continue
        if text.startswith(r"\xrightarrow{", position):
            opening = position + len(r"\xrightarrow")
            label, end = find_balanced(text, opening)
            output.append(r"\xrightarrow{" + math_tex(label) + "}")
            position = end
            continue
        if text.startswith(r"\{", position):
            output.append(r"\lbrace ")
            position += 2
            continue
        if text.startswith(r"\}", position):
            output.append(r"\rbrace ")
            position += 2
            continue
        if text.startswith(r"\Gr", position) or text.startswith(r"\W", position):
            # These corpus sequences encode a printed quotient/set-difference bar,
            # followed by the operand Gr... or W.... They are not TeX macros.
            output.append(r"\mathbin{\backslash}\,")
            position += 1
            continue
        char = text[position]
        if char == "\\":
            match = re.match(r"\\[A-Za-z]+|\\.", text[position:])
            token = match.group(0) if match else "\\"
            raise BuildError(f"unsupported TeX-like token {token!r} in {text!r}")

        if char in "①②③④⑤⑥⑦⑧⑨":
            output.append(r"\text{\textcircled{" + str(ord(char)-ord("①")+1) + "}}")
            position += 1
            continue

        labelled = re.match(r"—([^\s→←↪]{1,32})([→↪])", text[position:])
        if labelled:
            label = math_tex(labelled.group(1))
            output.append((r"\xrightarrow{" + label + "}") if labelled.group(2) == "→" else (r"\overset{" + label + r"}{\hookrightarrow}"))
            position += len(labelled.group(0))
            continue

        if char in {"→", "←"} and text.startswith("∼", position + 1):
            output.append((r"\xrightarrow{\sim}" if char == "→" else r"\xleftarrow{\sim}"))
            position += 2
            continue

        if char in {"→", "←"} and position+1 < length and text[position+1] in "①②③④⑤⑥⑦⑧⑨":
            label=math_tex(text[position+1])
            output.append((r"\xrightarrow" if char=="→" else r"\xleftarrow") + "{" + label + "}")
            position += 2
            continue

        if char in {"→", "←", "↪"} and text.startswith("^", position + 1):
            label, end = script_argument(text, position + 2)
            command = r"\xrightarrow" if char == "→" else r"\xleftarrow"
            below = ""
            if end < length and text[end] == "_":
                below, end = script_argument(text, end + 1)
            if char == "↪":
                base = r"\hookrightarrow" if not below else (r"\underset{" + below + r"}{\hookrightarrow}")
                output.append(r"\overset{" + label + "}{" + base + "}")
            else:
                output.append(command + ("[" + below + "]" if below else "") + "{" + label + "}")
            position = end
            continue

        if char in {"\u0304", "\u0303", "\u0302"}:
            require(bool(output), f"accent without base in {text!r}")
            command = {"\u0304": r"\overline", "\u0303": r"\widetilde", "\u0302": r"\widehat"}[char]
            output[-1] = command + "{" + output[-1] + "}"
            position += 1
            continue

        if char in {"_", "^"}:
            argument, end = script_argument(text, position + 1)
            output.append(char + "{" + argument + "}")
            position = end
            continue

        supers = dict(zip("⁰¹²³⁴⁵⁶⁷⁸⁹ⁿ⁺⁻", "0123456789n+-"))
        subs = dict(zip("₀₁₂₃₄₅₆₇₈₉₊₋", "0123456789+-"))
        if char in supers or char in subs:
            table, kind = (supers, "^") if char in supers else (subs, "_")
            end = position + 1
            while end < length and text[end] in table:
                end += 1
            output.append(kind + "{" + "".join(table[c] for c in text[position:end]) + "}")
            position = end
            continue

        if "SUBSCRIPT" in unicodedata.name(char, ""):
            output.append("_{" + unicodedata.normalize("NFKC", char) + "}")
            position += 1
            continue

        if char == "{":
            if text.startswith("{}", position):
                output.append("{}")
                position += 2
                continue
            output.append(r"\lbrace ")
            position += 1
            continue
        if char == "}":
            output.append(r"\rbrace ")
            position += 1
            continue

        if char not in MATH_CHAR_MAP and char.isalpha() and (char.isascii() or "LATIN" in unicodedata.name(char, "")):
            end = position + 1
            while end < length and text[end] not in MATH_CHAR_MAP and "SUBSCRIPT" not in unicodedata.name(text[end], "") and text[end].isalpha() and (text[end].isascii() or "LATIN" in unicodedata.name(text[end], "")):
                end += 1
            token = text[position:end]
            if token in OPERATORS:
                output.append(r"\operatorname{" + token + "}")
            elif not token.isascii():
                output.append(r"\text{" + token + "}")
            elif token in {"an", "op", "prim", "tor", "top", "red", "cst"}:
                output.append(r"\mathrm{" + token + "}")
            else:
                output.append(token)
            position = end
            continue

        if char.isascii() and char.isdigit():
            end = position + 1
            while end < length and text[end].isascii() and text[end].isdigit():
                end += 1
            output.append(text[position:end])
            position = end
            continue

        if char in MATH_CHAR_MAP:
            mapped = MATH_CHAR_MAP[char]
            output.append(mapped + (" " if re.fullmatch(r"\\[A-Za-z]+", mapped) else ""))
        elif char == " ":
            output.append(r"\,")
        elif char == "&":
            output.append(r"\&")
        elif char == "%":
            output.append(r"\%")
        elif char == "#":
            output.append(r"\#")
        elif char == "$":
            output.append(r"\$")
        elif char == "~":
            output.append(r"\sim ")
        elif char == "*":
            output.append(r"\ast ")
        elif char == "|":
            output.append(r"\mid ")
        else:
            output.append(char)
        position += 1
    return "".join(output)


def contains_math_trigger(token: str) -> bool:
    return "\\" in token or any(char in STRONG_MATH_CHARS or char in "ȲỸū⇉⇇↓↑①②③④⑤⑥⑦⑧⑨\u0304\u0303\u0302⁰¹²³⁴⁵⁶⁷⁸⁹ⁿ₀₁₂₃₄₅₆₇₈₉" or unicodedata.category(char) == "Sm" or "MATHEMATICAL" in unicodedata.name(char, "") or "SUBSCRIPT" in unicodedata.name(char, "") for char in token)


def inline_parts(text: str) -> list[str]:
    """Split only outside explicit script groups; never split a TeX argument."""
    parts: list[str] = []
    start = 0
    depth = 0
    for pos, char in enumerate(text):
        escaped = pos > 0 and text[pos - 1] == "\\"
        if char == "{" and not escaped:
            depth += 1
        elif char == "}" and not escaped:
            depth -= 1
        if char.isspace() and depth == 0:
            if start < pos:
                parts.append(text[start:pos])
            parts.append(" ")
            start = pos + 1
    if start < len(text):
        parts.append(text[start:])
    require(depth == 0, f"unbalanced inline group: {text!r}")
    return parts


def split_token_punctuation(token: str) -> tuple[str, str, str]:
    leading = ""
    trailing = ""
    while token and token[0] in "“‘\"":
        leading += token[0]
        token = token[1:]
    while token and token[-1] in ".,;:!?\"”’":
        if len(token) >= 2 and token[-2] in "_^":
            break
        trailing = token[-1] + trailing
        token = token[:-1]
    return leading, token, trailing


def inline_tex(text: str) -> str:
    pieces: list[str] = []
    for part in inline_parts(text):
        if not part:
            continue
        if part.isspace():
            pieces.append(" ")
            continue
        leading, core, trailing = split_token_punctuation(part)
        pieces.append(escape_text(leading))
        if core in {"ZERO_ACCEPTED", "INCLUDE_WORK"}:
            pieces.append(escape_text(core))
        elif re.fullmatch(r"[0-9A-F]{64}[.)]?", core):
            pieces.append(r"\allowbreak{}".join(core[i:i+8] for i in range(0, len(core), 8)))
        elif core and contains_math_trigger(core):
            pieces.append(r"\(" + math_tex(core) + r"\)")
        else:
            pieces.append(escape_text(core))
        pieces.append(escape_text(trailing))
    return "".join(pieces)


def looks_like_formula_line(line: str) -> bool:
    if not contains_math_trigger(line) or MARKER_RE.search(line):
        return False
    words = re.findall(r"[A-Za-zÀ-ÖØ-öø-ÿ]{2,}", line)
    sentence_markers = len(re.findall(r"\b(?:the|and|that|which|with|pour|dans|avec|soit|est|une|des|les)\b", line, re.I))
    return len(words) <= 5 and sentence_markers == 0 and len(line) <= 360


def render_asset(asset_id: str, caption: str, repeated: bool) -> str:
    command = "DAssetReference" if repeated else "DAsset"
    return rf"\{command}{{{asset_id}}}{{{inline_tex(caption)}}}"


def render_edition_text(record: dict[str, Any]) -> str:
    assets = {asset["id"]: asset for asset in record["assets"]}
    embedded: set[str] = set()
    output: list[str] = []

    for line in record["text"].splitlines():
        if not line.strip():
            output.append(r"\par\medskip")
            continue
        matches = list(MARKER_RE.finditer(line))
        if not matches:
            contents = re.fullmatch(r"\s*(.*?)\s*\.{4,}\s*(\d+)\s*", line)
            if contents:
                indent = r"\hspace*{1em}" if line.startswith(" ") else ""
                output.append(indent + inline_tex(contents.group(1)) + r"\dotfill " + contents.group(2) + r"\par")
            elif looks_like_formula_line(line):
                output.append(r"\DFormula{" + math_tex(line.strip()) + "}")
            else:
                output.append(inline_tex(line.strip()) + r"\par")
            continue
        cursor = 0
        for match in matches:
            before = line[cursor : match.start()].strip()
            if before:
                output.append(inline_tex(before) + r"\par")
            asset_id = match.group(1)
            require(asset_id in assets, f"page {record['physical_page']}: marker references undeclared asset {asset_id}")
            caption = (match.group(2) or assets[asset_id]["caption"]).strip()
            output.append(render_asset(asset_id, caption, asset_id in embedded))
            embedded.add(asset_id)
            cursor = match.end()
        after = line[cursor:].strip()
        if after:
            output.append(inline_tex(after) + r"\par")

    for asset in record["assets"]:
        if asset["id"] not in embedded:
            output.append(render_asset(asset["id"], asset["caption"], False))
            embedded.add(asset["id"])
    require(embedded == set(assets), f"page {record['physical_page']}: not all assets were embedded")
    return "\n".join(output)


def apparatus_paragraphs(text: str) -> list[str]:
    retained: list[str] = []
    for paragraph in re.split(r"\n\s*\n", text.strip()):
        normalized = paragraph.strip()
        lower = normalized.casefold()
        if lower.startswith("page anchor:"):
            continue
        if "assets/raw_crops/" in normalized or "assets/presentation_derivatives/" in normalized or "sha256" in lower:
            continue
        if lower.startswith(
            (
                "comparator",
                "inherited",
                "adverse inherited",
                "the comparator",
                "the lower-raster comparator",
            )
        ):
            continue
        retained.append(normalized)
    require(retained and retained[0].casefold().startswith("disposition:"), "apparatus entry lost its disposition paragraph")
    return retained


def render_apparatus_text(record: dict[str, Any]) -> str:
    output: list[str] = []
    for paragraph in apparatus_paragraphs(record["text"]):
        for line in paragraph.splitlines():
            line = line.strip()
            if not line:
                continue
            if looks_like_formula_line(line):
                output.append(r"\DFormula{" + math_tex(line) + "}")
            else:
                output.append(inline_tex(line) + r"\par")
        output.append(r"\smallskip")
    return "\n".join(output)


def anchor_command(layer: str, record: dict[str, Any]) -> str:
    command = "DApparatusAnchor" if layer == "apparatus" else "DArticleAnchor"
    page = record["physical_page"]
    return (
        rf"\{command}{{{page:04d}}}{{{page}}}{{{record['authority_pdf_page']}}}"
        rf"{{{record['source_volume_page']}}}{{{record['printed_page']}}}{{{escape_text(record['prompt_id'])}}}"
    )


def render_body(layer: str, rows: list[dict[str, Any]]) -> str:
    chunks: list[str] = []
    for record in rows:
        chunks.append(anchor_command(layer, record))
        if layer != "apparatus" and record["physical_page"] == 1:
            chunks.append(r"\begingroup\small\setlength{\parskip}{0.1\baselineskip}")
        if layer == "source_language":
            chunks.append(render_edition_text(record))
        elif layer == "english_standalone":
            chunks.append(render_edition_text(record))
        else:
            chunks.append(render_apparatus_text(record))
        if layer != "apparatus" and record["physical_page"] == 1:
            chunks.append(r"\endgroup")
    return "\n\n".join(chunks)


def hash_with_breaks(value: str) -> str:
    require(re.fullmatch(r"[0-9A-F]{64}", value) is not None, f"invalid SHA-256 for manifest: {value}")
    return r"\allowbreak{}".join(value[index : index + 8] for index in range(0, 64, 8))


def apparatus_appendix(ledger: dict[str, dict[str, str]]) -> str:
    lines = [
        r"\clearpage",
        r"\section*{Presentation fallback manifest}",
        r"\addcontentsline{toc}{section}{Presentation fallback manifest}",
        r"\small",
        r"\begin{longtable}{@{}r l >{\ttfamily\scriptsize}p{0.64\linewidth}@{}}",
        r"\toprule",
        r"Article & Asset & Presentation SHA-256 \\",
        r"\midrule",
        r"\endfirsthead",
        r"\toprule",
        r"Article & Asset & Presentation SHA-256 \\",
        r"\midrule",
        r"\endhead",
    ]
    for asset_id, row in sorted(ledger.items(), key=lambda item: (int(item[1]["physical_page"]), item[0])):
        lines.append(f"{int(row['physical_page'])} & {asset_id} & {hash_with_breaks(row['presentation_sha256'])} " + r"\\")
    lines.extend([r"\bottomrule", r"\end{longtable}", r"\normalsize"])
    return "\n".join(lines)


def provenance_tex(layer: str, layer_path: str, layer_sha: str, repair_ids: list[str]) -> str:
    repaired = ", ".join(repair_ids) if repair_ids else "none"
    record_label = {"source_language":"French/source-language records", "english_standalone":"English reading records", "apparatus":"apparatus records"}[layer]
    text = (
        f"This standalone source is generated deterministically from the preserved {record_label} "
        f"(SHA-256 {layer_sha}). Exact, fail-closed repair IDs applied to this layer: {repaired}. "
        "Every numbered entry preserves the corpus four-way page anchor. Complex diagrams are supplied only from local, "
        "byte-verified presentation fallbacks; no external URL, script, or network resource is used."
    )
    return r"\begin{quote}\small " + inline_tex(text) + r" \end{quote}"


def global_note_tex(layer: str) -> str:
    if layer == "apparatus":
        text = (
            "Editorial policy. Comparator and inherited witnesses remain comparison-only and ZERO_ACCEPTED; their recurring "
            "replay boilerplate is summarized here rather than repeated in each entry. The entries retain dispositions and "
            "substantive authority-settled readings. Accepted local fallbacks are indexed once in the compact manifest."
        )
    else:
        text = (
            "Reading convention. Mathematical notation is emitted in Unicode math mode with STIX Two Math. Labelled arrows "
            "are executable TeX, while complex arrow topology remains controlled by the adjacent local fallback images."
        )
    return r"\begin{quote}\small " + inline_tex(text) + r" \end{quote}"


def fill_template(template: str, replacements: dict[str, str]) -> str:
    result = template
    for key, value in replacements.items():
        token = f"@@{key}@@"
        require(token in result, f"template token is absent: {token}")
        result = result.replace(token, value)
    leftovers = sorted(set(re.findall(r"@@[A-Z_]+@@", result)))
    require(not leftovers, f"unfilled template tokens: {leftovers}")
    return result.replace("\r\n", "\n").replace("\r", "\n")


def render_documents(
    template: str,
    layers: dict[str, list[dict[str, Any]]],
    layer_hashes: dict[str, str],
    ledger: dict[str, dict[str, str]],
    receipts: list[dict[str, Any]],
    repair_map_sha256: str,
    engine: str,
) -> dict[str, bytes]:
    documents: dict[str, bytes] = {}
    for layer, rows in layers.items():
        settings = DOCUMENT_SETTINGS[layer]
        repairs = [receipt["repair_id"] for receipt in receipts if receipt["layer"] == layer]
        appendix = apparatus_appendix(ledger) if layer == "apparatus" else ""
        text = fill_template(
            template,
            {
                "ENGINE": engine,
                "REPAIR_MAP_SHA256": repair_map_sha256,
                "BABEL_LANGUAGE": settings["babel"],
                "PDF_TITLE": escape_text(settings["title"]),
                "RUNNING_TITLE": escape_text(settings["running"]),
                "DOCUMENT_TITLE": escape_text(settings["title"]),
                "PROVENANCE": provenance_tex(layer, LAYER_FILES[layer], layer_hashes[layer], repairs),
                "GLOBAL_NOTE": global_note_tex(layer),
                "BODY": render_body(layer, rows),
                "APPENDIX": appendix,
            },
        )
        require(text.count(r"\DArticleAnchor{") == (EXPECTED_PAGES if layer != "apparatus" else 0), f"{layer}: wrong article-anchor count")
        require(text.count(r"\DApparatusAnchor{") == (EXPECTED_PAGES if layer == "apparatus" else 0), f"{layer}: wrong apparatus-anchor count")
        documents[layer] = (text.rstrip() + "\n").encode("utf-8")
    return documents


def asset_manifest_bytes(ledger: dict[str, dict[str, str]]) -> bytes:
    buffer = io.StringIO(newline="")
    fields = [
        "asset_id",
        "physical_page",
        "authority_pdf_page",
        "output_filename",
        "bytes",
        "sha256",
        "corpus_presentation_path",
    ]
    writer = csv.DictWriter(buffer, fieldnames=fields, delimiter="\t", lineterminator="\n")
    writer.writeheader()
    for asset_id, row in sorted(ledger.items(), key=lambda item: (int(item[1]["physical_page"]), item[0])):
        writer.writerow(
            {
                "asset_id": asset_id,
                "physical_page": row["physical_page"],
                "authority_pdf_page": row["authority_pdf_page"],
                "output_filename": f"{asset_id}_presentation.png",
                "bytes": "PENDING_STAGE_VALIDATION",
                "sha256": row["presentation_sha256"],
                "corpus_presentation_path": row["presentation_path"],
            }
        )
    return buffer.getvalue().encode("utf-8")


def final_asset_manifest_bytes(corpus: Path, ledger: dict[str, dict[str, str]]) -> bytes:
    buffer = io.StringIO(newline="")
    fields = [
        "asset_id",
        "physical_page",
        "authority_pdf_page",
        "output_filename",
        "bytes",
        "sha256",
        "corpus_presentation_path",
    ]
    writer = csv.DictWriter(buffer, fieldnames=fields, delimiter="\t", lineterminator="\n")
    writer.writeheader()
    for asset_id, row in sorted(ledger.items(), key=lambda item: (int(item[1]["physical_page"]), item[0])):
        source = corpus / row["presentation_path"]
        writer.writerow(
            {
                "asset_id": asset_id,
                "physical_page": row["physical_page"],
                "authority_pdf_page": row["authority_pdf_page"],
                "output_filename": f"{asset_id}_presentation.png",
                "bytes": source.stat().st_size,
                "sha256": row["presentation_sha256"],
                "corpus_presentation_path": row["presentation_path"],
            }
        )
    return buffer.getvalue().encode("utf-8")


def write_if_changed(path: Path, data: bytes) -> None:
    if path.exists() and path.read_bytes() == data:
        return
    path.write_bytes(data)


def stage_assets(corpus: Path, output_assets: Path, ledger: dict[str, dict[str, str]]) -> list[dict[str, Any]]:
    staged: list[dict[str, Any]] = []
    for asset_id, row in sorted(ledger.items(), key=lambda item: item[0]):
        source = corpus / row["presentation_path"]
        target = output_assets / f"{asset_id}_presentation.png"
        expected = row["presentation_sha256"]
        require(sha256_file(source) == expected, f"source asset changed before stage: {asset_id}")
        if target.exists():
            require(sha256_file(target) == expected, f"refusing to overwrite non-identical staged asset: {target}")
        else:
            shutil.copyfile(source, target)
        require(sha256_file(target) == expected, f"staged asset hash mismatch: {asset_id}")
        staged.append({"asset_id": asset_id, "path": f"assets/{target.name}", "bytes": target.stat().st_size, "sha256": expected})
    return staged


def parse_args(argv: list[str]) -> argparse.Namespace:
    script_dir = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", type=Path, default=script_dir.parent / "replay_primary" / "corpus")
    parser.add_argument("--output-dir", type=Path, default=script_dir / "output")
    parser.add_argument("--template", type=Path, default=script_dir / "templates" / "document.tex.in")
    parser.add_argument("--repair-map", type=Path, default=None)
    parser.add_argument("--engine", choices=("lualatex", "xelatex"), default="lualatex")
    parser.add_argument("--dry-run", action="store_true", help="validate and render in memory without writing any output")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    script_dir = Path(__file__).resolve().parent
    corpus = args.corpus.resolve()
    template_path = args.template.resolve()
    output_dir = args.output_dir.resolve()
    default_repair = script_dir / "D019_REPAIR_MAP.json"
    repair_path = args.repair_map.resolve() if args.repair_map else (default_repair if default_repair.is_file() else None)

    layer_paths = {layer: corpus / relative for layer, relative in LAYER_FILES.items()}
    layers = {layer: load_ndjson(path) for layer, path in layer_paths.items()}
    layer_hashes = {layer: sha256_file(path) for layer, path in layer_paths.items()}
    ledger_path = corpus / "edition" / "asset_ledger.tsv"
    ledger = load_ledger(ledger_path)
    validate_records(corpus, layers, ledger)
    validate_inherited_bindings(layers)
    repair_map, repair_map_sha = load_repairs(repair_path)
    repaired, repair_receipts = apply_repairs(layers, repair_map)
    validate_records(corpus, repaired, ledger)
    canonical, canonical_bindings = bind_canonical_records(repaired)
    validate_records(corpus, canonical, ledger)
    template = template_path.read_text(encoding="utf-8")
    documents = render_documents(
        template, canonical, layer_hashes, ledger, repair_receipts, repair_map_sha, args.engine
    )
    canonical_data = {layer: ndjson_bytes(rows) for layer, rows in canonical.items()}
    asset_manifest = final_asset_manifest_bytes(corpus, ledger)
    route_rows = []
    for layer, rows in canonical.items():
        for record in rows:
            rendered = render_apparatus_text(record) if layer == "apparatus" else render_edition_text(record)
            route_rows.append({
                "layer": layer, "physical_page": record["physical_page"],
                "authority_pdf_page": record["authority_pdf_page"], "prompt_id": record["prompt_id"],
                "canonical_record_sha256": record_digest(record),
                "raw_text_sha256": sha256_bytes(record["text"].encode("utf-8")),
                "rendered_tex": rendered,
                "rendered_tex_sha256": sha256_bytes(rendered.encode("utf-8")),
                "editable_inline_math_spans": rendered.count(r"\("),
                "editable_display_math_spans": rendered.count(r"\DFormula{"),
                "diagram_routes": [{"asset_id": a["id"], "presentation_sha256": ledger[a["id"]]["presentation_sha256"],
                    "text_marker_count": len(re.findall("⟦"+re.escape(a["id"]), record["text"])),
                    "render_route": "manifest_entry" if layer == "apparatus" else "one_local_image_plus_references"}
                    for a in record["assets"]],
            })
    route_data = ndjson_bytes(route_rows)

    summary = {
        "schema": BUILD_SCHEMA,
        "work_id": WORK_ID,
        "engine": args.engine,
        "dry_run": bool(args.dry_run),
        "anchors_per_document": EXPECTED_PAGES,
        "asset_count": len(ledger),
        "repair_map_sha256": repair_map_sha,
        "repairs_applied": repair_receipts,
        "canonical_record_bindings": canonical_bindings,
        "inputs": [
            {"path": LAYER_FILES[layer], "bytes": layer_paths[layer].stat().st_size, "sha256": layer_hashes[layer]}
            for layer in LAYER_FILES
        ]
        + [
            {
                "path": "edition/asset_ledger.tsv",
                "bytes": ledger_path.stat().st_size,
                "sha256": sha256_file(ledger_path),
            },
            {
                "path": "canonical_build/templates/document.tex.in",
                "bytes": template_path.stat().st_size,
                "sha256": sha256_file(template_path),
            },
        ],
        "planned_outputs": [
            {
                "path": f"tex/{OUTPUT_TEX[layer]}",
                "bytes": len(data),
                "sha256": sha256_bytes(data),
            }
            for layer, data in documents.items()
        ]
        + [
            {
                "path": f"data/{OUTPUT_DATA[layer]}",
                "bytes": len(data),
                "sha256": sha256_bytes(data),
            }
            for layer, data in canonical_data.items()
        ]
        + [
            {
                "path": "assets/D019_PRESENTATION_ASSET_MANIFEST.tsv",
                "bytes": len(asset_manifest),
                "sha256": sha256_bytes(asset_manifest),
            }
        ],
    }

    if args.dry_run:
        print(json.dumps(summary, ensure_ascii=False, sort_keys=True, indent=2))
        return 0

    tex_dir = output_dir / "tex"
    data_dir = output_dir / "data"
    assets_dir = output_dir / "assets"
    pdf_dir = output_dir / "pdf"
    tex_dir.mkdir(parents=True, exist_ok=True)
    data_dir.mkdir(parents=True, exist_ok=True)
    assets_dir.mkdir(parents=True, exist_ok=True)
    pdf_dir.mkdir(parents=True, exist_ok=True)
    staged = stage_assets(corpus, assets_dir, ledger)
    for layer, data in documents.items():
        write_if_changed(tex_dir / OUTPUT_TEX[layer], data)
    for layer, data in canonical_data.items():
        write_if_changed(data_dir / OUTPUT_DATA[layer], data)
    manifest_path = assets_dir / "D019_PRESENTATION_ASSET_MANIFEST.tsv"
    write_if_changed(manifest_path, asset_manifest)
    route_path = data_dir / "D019_FORMULA_AND_DIAGRAM_ROUTES.ndjson"
    write_if_changed(route_path, route_data)

    summary["dry_run"] = False
    summary["staged_assets"] = staged
    summary["outputs"] = [
        {
            "path": f"tex/{OUTPUT_TEX[layer]}",
            "bytes": (tex_dir / OUTPUT_TEX[layer]).stat().st_size,
            "sha256": sha256_file(tex_dir / OUTPUT_TEX[layer]),
        }
        for layer in documents
    ] + [
        {
            "path": f"data/{OUTPUT_DATA[layer]}",
            "bytes": (data_dir / OUTPUT_DATA[layer]).stat().st_size,
            "sha256": sha256_file(data_dir / OUTPUT_DATA[layer]),
        }
        for layer in canonical_data
    ] + [
        {
            "path": "assets/D019_PRESENTATION_ASSET_MANIFEST.tsv",
            "bytes": manifest_path.stat().st_size,
            "sha256": sha256_file(manifest_path),
        }
    ]
    summary["outputs"].append({"path": "data/D019_FORMULA_AND_DIAGRAM_ROUTES.ndjson", "bytes": route_path.stat().st_size, "sha256": sha256_file(route_path)})
    write_if_changed(output_dir / "D019_CANONICAL_BUILD_MANIFEST.json", json_bytes(summary))
    print(json.dumps({"result": "PASS", "output_dir": str(output_dir), "repairs": len(repair_receipts)}, sort_keys=True))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BuildError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
