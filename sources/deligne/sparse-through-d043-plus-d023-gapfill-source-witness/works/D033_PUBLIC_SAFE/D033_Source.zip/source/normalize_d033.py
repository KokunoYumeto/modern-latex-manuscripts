"""Deterministic D033 editable-math derivative. A successful build is NOT a fidelity PASS."""
from pathlib import Path
import argparse, hashlib, json, re, unicodedata, sys, copy
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'build_support'))
import parser_base_d019 as core

MAP=dict(core.MATH_CHAR_MAP)
MAP.update({'↦':r'\mapsto','≪':r'\ll','≫':r'\gg','∤':r'\nmid','⊄':r'\not\subset',
 '‖':r'\Vert','∫':r'\int','·':r'\cdot','−':'-','…':r'\ldots','∘':r'\circ',
 '⋃':r'\bigcup','†':r'\dagger','ℍ':r'\mathfrak{H}','ℌ':r'\mathfrak{H}',
 'Û':r'\widehat{U}','Ô':r'\widehat{O}','Ĝ':r'\widehat{G}',
 '𝒩':r'\mathcal{N}','𝒫':r'\mathcal{P}','𝒮':r'\mathcal{S}','𝒱':r'\mathcal{V}',
 '𝓙':r'\mathcal{J}','𝓜':r'\mathcal{M}','│':r'\vert','↘':r'\searrow','↗':r'\nearrow'})
OPS=set(core.OPERATORS)|{'SL','GL','End','Isom','Re','Im','det','tr','sgn','Gal','Norm','cond','sin','cos','vol'}
MATRICES={
 '(a  b; c  d)':r'\begin{pmatrix}a&b\\c&d\end{pmatrix}',
 '(α  0; 0  α^{-1})':r'\begin{pmatrix}\alpha&0\\0&\alpha^{-1}\end{pmatrix}',
 '(x  0; 0  x^{-1})':r'\begin{pmatrix}x&0\\0&x^{-1}\end{pmatrix}',
 '(α  β; γ  δ)':r'\begin{pmatrix}\alpha&\beta\\\gamma&\delta\end{pmatrix}',
 '(α β; γ δ)':r'\begin{pmatrix}\alpha&\beta\\\gamma&\delta\end{pmatrix}',
 '(0  1; −1  0)':r'\begin{pmatrix}0&1\\-1&0\end{pmatrix}',
 '(1  x; 0  1)':r'\begin{pmatrix}1&x\\0&1\end{pmatrix}',
 '(a  0; 0  a^{-1})':r'\begin{pmatrix}a&0\\0&a^{-1}\end{pmatrix}',
 '(cosθ  −sinθ; sinθ  cosθ)':r'\begin{pmatrix}\cos\theta&-\sin\theta\\\sin\theta&\cos\theta\end{pmatrix}',
 '(√b  a√(b^{-1}); 0  √(b^{-1}))':r'\begin{pmatrix}\sqrt b&a\sqrt{b^{-1}}\\0&\sqrt{b^{-1}}\end{pmatrix}'
}

def protect_matrices(s):
    for i,raw in enumerate(MATRICES):s=s.replace(raw,'⟪M'+str(i)+'⟫')
    return s
SUFFIXES={'algebra','algebras','algèbre','algèbres','adic','adique','adiquement','adiques','valued','valuées','valuée','valués','valué','linear','linéaire','linéaires','module','modules','stable','stables','invariant','invariante','invariants','invariantes','structure','structures','expansion','expansions','développement','développements','coefficients','morphism','division','vector','espace','vectoriel','vectoriels'}
SUPERS=dict(zip('⁰¹²³⁴⁵⁶⁷⁸⁹ⁿ⁺⁻ᵃᵇᶜᵒ','0123456789n+-abco'))
SUBS=dict(zip('₀₁₂₃₄₅₆₇₈₉₊₋','0123456789+-'))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def dump(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def text_tex(s):
    s=s.replace('–','--').replace('—','---').replace('˜',r'\textasciitilde{}')
    return core.escape_text(s)

def group(text,start,op='(',cl=')'):
    depth=0
    for i in range(start,len(text)):
        if text[i]==op:depth+=1
        elif text[i]==cl:
            depth-=1
            if depth==0:return text[start+1:i],i+1
    raise ValueError('unclosed group '+text)

def scriptarg(text,start):
    if start>=len(text):raise ValueError('missing script argument '+text)
    if text[start]=='{':s,end=group(text,start,'{','}');return math_tex(s),end
    for name in ('can','can.','red','ord','odd','even'):
        if text.startswith(name,start) and (start+len(name)==len(text) or not text[start+len(name)].isalpha()):return r'\mathrm{'+name+'}',start+len(name)
    end=start+1
    if text[start].isdigit():
        while end<len(text) and text[end].isdigit():end+=1
    return math_tex(text[start:end]),end

def math_tex(text):
    # Exact notation fixes are rendering routes, not altered edition readings.
    text=protect_matrices(text).replace('—∼→','→∼').replace('∼→','→∼').replace('⟶[N; ∼]','→^{N}_{∼}').replace('Γ_R','Γ_ℝ')
    out=[];p=0
    while p<len(text):
        matrix=re.match(r'⟪M(\d+)⟫',text[p:])
        if matrix:out.append(list(MATRICES.values())[int(matrix.group(1))]);p+=len(matrix.group(0));continue
        if text.startswith('lim←',p):out.append(r'\varprojlim ');p+=4;continue
        char=text[p]
        if char=='(':
            try:inner,end=group(text,p)
            except ValueError:end=0
            if end and end<len(text) and text[end] in '\u0304\u0303\u0302\u0332':
                cmd={'\u0304':r'\overline','\u0303':r'\widetilde','\u0302':r'\widehat','\u0332':r'\underline'}[text[end]]
                out.append(cmd+'{'+math_tex(inner)+'}');p=end+1;continue
        if char in 'QCZ':out.append(r'\mathbb{'+char+'}');p+=1;continue
        if char=='F' and (text[p+1:p+2]=='̄' or re.match(r'_(?:[pq]|\{q)',text[p+1:])):out.append(r'\mathbb{F}');p+=1;continue
        if char=='N' and text[p+1:p+2]=='⁺':out.append(r'\mathbb{N}');p+=1;continue
        if char=='˜' and text[p+1:p+2]=='(':
            inner,end=group(text,p+1);out.append(r'\widetilde{'+math_tex(inner)+'}');p=end;continue
        labelled=re.match(r'—([^\s→←↪]{1,32})([→↪])',text[p:])
        if labelled:
            label=math_tex(labelled.group(1));out.append((r'\xrightarrow{'+label+'}') if labelled.group(2)=='→' else (r'\overset{'+label+r'}{\hookrightarrow}'));p+=len(labelled.group(0));continue
        if char in '→←' and text[p+1:p+2]=='∼':out.append(r'\xrightarrow{\sim}' if char=='→' else r'\xleftarrow{\sim}');p+=2;continue
        if char in '→←↪' and text[p+1:p+2]=='^':
            upper,end=scriptarg(text,p+2);lower=''
            if end<len(text) and text[end]=='_':lower,end=scriptarg(text,end+1)
            if char=='↪':out.append(r'\overset{'+upper+'}{'+(r'\underset{'+lower+r'}{\hookrightarrow}' if lower else r'\hookrightarrow')+'}')
            else:out.append((r'\xrightarrow' if char=='→' else r'\xleftarrow')+('['+lower+']' if lower else '')+'{'+upper+'}')
            p=end;continue
        if char in '\u0304\u0303\u0302\u0332':
            if not out:raise ValueError('accent missing base '+text)
            cmd={'\u0304':r'\overline','\u0303':r'\widetilde','\u0302':r'\widehat','\u0332':r'\underline'}[char]
            out[-1]=cmd+'{'+out[-1]+'}';p+=1;continue
        if char=='√':
            if p+1>=len(text):raise ValueError('sqrt missing radicand '+text)
            if text[p+1]=='(':rad,end=group(text,p+1);rad=math_tex(rad)
            elif text[p+1]=='{':rad,end=group(text,p+1,'{','}');rad=math_tex(rad)
            elif text[p+1] in '−-':
                rad,end=scriptarg(text,p+2);rad='-'+rad
            else:rad,end=scriptarg(text,p+1)
            out.append(r'\sqrt{'+rad+'}');p=end;continue
        if char in '_^':arg,end=scriptarg(text,p+1);out.append(char+'{'+arg+'}');p=end;continue
        if char in SUPERS or char in SUBS:
            table,kind=(SUPERS,'^') if char in SUPERS else (SUBS,'_');end=p+1
            while end<len(text) and text[end] in table:end+=1
            out.append(kind+'{'+''.join(table[c] for c in text[p:end])+'}');p=end;continue
        if char=='*':out.append(r'^{\ast}');p+=1;continue
        if char=='†':out.append(r'^{\dagger}' if out else r'\dagger');p+=1;continue
        if char in '′″':out.append("'" if char=='′' else "''");p+=1;continue
        if char=='{':
            if text[p:p+2]=='{}':out.append('{}');p+=2;continue
            out.append(r'\lbrace ');p+=1;continue
        if char=='}':out.append(r'\rbrace ');p+=1;continue
        if char=='\\':raise ValueError('Unparsed backslash: '+text)
        if char not in MAP and (char.isascii() and char.isalpha()):
            end=p+1
            while end<len(text) and text[end].isascii() and text[end].isalpha():end+=1
            token=text[p:end]
            if token=='lim':out.append(r'\lim ')
            elif token in OPS:out.append(r'\operatorname{'+token+'}')
            elif token in {'for','if','and','or','where','with','pour','si','et','ou','avec','modulo','resp'}:out.append(r'\text{'+token+'}')
            elif token in {'can','red','ord'}:out.append(r'\mathrm{'+token+'}')
            else:out.extend(r'\mathbb{'+c+'}' if c in 'QCZ' else c for c in token)
            p=end;continue
        if char in MAP:
            m=MAP[char];out.append(m+(' ' if re.fullmatch(r'\\[A-Za-z]+',m) else ''))
        elif char.isspace():out.append(r'\,')
        elif char=='|':out.append(r'\vert ')
        elif char=='~':out.append(r'\sim ')
        elif char in '&%#$':out.append('\\'+char)
        elif char in '–—':out.append('-')
        elif char.isalpha() and 'LATIN' in unicodedata.name(char,'') and ord(char)>127:out.append(r'\text{'+char+'}')
        else:out.append(char)
        p+=1
    return ''.join(out)

def trigger(s):
    return core.contains_math_trigger(s) or any(c in s for c in 'ÛÔĜ‖·†˜ᵃᵇᶜᵒ′″ℍℌ↦⟪*') or bool(re.search(r'(?:SL|GL|Hom|End|Isom|Gal|Spec|Lie|det|tr)\(|[QZR]/|/[QZR]|\d+/\d+',s))

def inline(s):
    s=protect_matrices(s)
    out=[]
    for part in core.inline_parts(s):
        if part.isspace():out.append(' ');continue
        lead,tok,tail=core.split_token_punctuation(part)
        out.append(text_tex(lead))
        suffix=re.match(r'^(.*?)-([A-Za-zÀ-ÖØ-öø-ÿ]+)([).,;:]*)$',tok)
        if suffix and suffix.group(2) in SUFFIXES and (trigger(suffix.group(1)) or re.fullmatch('[A-Za-z]',suffix.group(1))):
            out.append(r'\('+math_tex(suffix.group(1))+r'\)-'+text_tex(suffix.group(2)+suffix.group(3)))
        elif tok in {'ZERO_ACCEPTED','INCLUDE_WORK'}:out.append(text_tex(tok))
        elif re.fullmatch(r'[A-Za-zÀ-ÖØ-öø-ÿ]{2,}[¹²³*]',tok):out.append(text_tex(tok[:-1])+r'\textsuperscript{'+SUPERS.get(tok[-1],tok[-1])+'}')
        elif tok and (trigger(tok) or re.fullmatch(r'[A-Z](?:[.,;:]?\)?)',tok) or (len(tok)==1 and tok in 'kpqrstxyz')):
            out.append(r'\('+math_tex(tok)+r'\)')
        else:out.append(text_tex(tok))
        out.append(text_tex(tail))
    return ''.join(out)

def isformula(line):
    if not trigger(line):return False
    words=re.findall(r'[A-Za-zÀ-ÖØ-öø-ÿ]{2,}',line)
    prose=[w for w in words if w not in OPS and w not in {'can','bis','mod','for','if','si','pour','et','or','ou','and','resp'}]
    return len(prose)==0 and len(line)<700

def number_face(line,page,real_tail=False):
    # R is not globally a number-field glyph: p12 initially denotes a Q-algebra,
    # pp33-41 a coefficient ring, p25 a integration parameter, p50 a lattice.
    if page in {3,18,19,22,27,28,48,49} or (page==12 and real_tail):
        return re.sub(r'(?<![A-Za-zÀ-ÖØ-öø-ÿ])R(?![A-Za-zÀ-ÖØ-öø-ÿ])','ℝ',line)
    if page in {35,36,44,46,50}:return line.replace('K⊗R','K⊗ℝ')
    return line

PREAMBLE=r'''% !TeX program = lualatex
% D033 editable mathematical derivative. Acceptance is established only by the separate corpus gate.
\documentclass[11pt]{article}
\usepackage{fontspec,amsmath,unicode-math}
\setmainfont{STIXTwoText}[Extension=.otf,UprightFont=*-Regular,ItalicFont=*-Italic,BoldFont=*-Bold,BoldItalicFont=*-BoldItalic]
\setmathfont{STIXTwoMath-Regular.otf}
\usepackage[main=LANG]{babel}
\usepackage[a4paper,left=25mm,right=25mm,top=22mm,bottom=24mm,headheight=15pt]{geometry}
\usepackage{graphicx,adjustbox,needspace,parskip,fancyhdr,microtype,hyperref,tikz-cd}
\hypersetup{hidelinks,pdftitle={TITLE},pdfauthor={Pierre Deligne and Kenneth A. Ribet},pdfsubject={D033 bilingual scholarly edition}}
\pdfvariable suppressoptionalinfo 767\relax
\setlength{\parindent}{0pt}\setlength{\parskip}{.25\baselineskip}\setlength{\emergencystretch}{3em}\raggedbottom
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small D033: Deligne--Ribet}\fancyhead[R]{\small ROLE}\fancyfoot[C]{\thepage}
\newcommand{\DAnchor}[2]{\clearpage\phantomsection\pdfbookmark[1]{Authority #1 / printed #2}{d033p#1}{\small\textsc{Authority #1 / printed #2}\par}\medskip}
\newcommand{\DAppAnchor}[2]{\Needspace{5\baselineskip}\phantomsection\pdfbookmark[1]{Authority #1 / printed #2}{d033p#1}\subsection*{Authority #1 / printed #2}}
\newcommand{\DFormula}[1]{\par\smallskip\noindent\begin{adjustbox}{max width=\linewidth}$\displaystyle #1$\end{adjustbox}\par\smallskip}
\newcommand{\DFallback}[2]{\par\medskip\begin{center}\includegraphics[width=.75\linewidth,height=.55\textheight,keepaspectratio]{../assets/#1}\par{\small #2}\end{center}\medskip}
\begin{document}
'''

def render(layer,rows,overrides):
    lang='french' if layer=='french_translation' else 'english'
    role={'source_english':'English source edition','french_translation':'Traduction française','apparatus':'Restrained apparatus'}[layer]
    title={'source_english':'Values of Abelian L-functions at Negative Integers over Totally Real Fields','french_translation':'Valeurs de fonctions L abéliennes aux entiers négatifs sur les corps totalement réels','apparatus':'D033: Editorial apparatus'}[layer]
    out=[PREAMBLE.replace('LANG',lang).replace('TITLE',title).replace('ROLE',role)]
    routes=[]
    if layer=='apparatus':
        out.extend([r'\section*{Editorial policy}',inline('English is the source language. The French text is a separate translation. Repeated journal running heads, folios, publisher copyright and price copy-matter are excluded from reader prose but remain in the untouched authority. Inherited candidates, failed V1 receipts and all web audit claims remain ZERO_ACCEPTED evidence until the independent corpus gate. This apparatus records substantive readings and explicit exclusions, not repeated production status.')+r'\par'])
    for row in rows:
        page=row['physical_page'];out.append((r'\DAppAnchor' if layer=='apparatus' else r'\DAnchor')+'{'+str(page)+'}{'+str(page+226)+'}')
        text=row['text'];block_map={}
        for key,value in overrides.items():
            prefix=f'{layer}:{page}:'
            if key.startswith(prefix) and '\n' in key[len(prefix):]:
                old=key[len(prefix):];assert text.count(old)==1,key
                token='@@D033BLOCK'+str(len(block_map))+'@@';block_map[token]=(old,value['tex']);text=text.replace(old,token)
        lines=text.splitlines();page_routes=[]
        real_tail=False
        bibliography=False
        if page==60 and layer!='apparatus':
            out.append(r'\begingroup\small\setlength{\parskip}{.15\baselineskip}');bibliography=True
        for idx,line in enumerate(lines):
            line=line.strip()
            if not line:out.append(r'\par');continue
            if page==59 and layer!='apparatus' and line in {'References','Références'}:
                out.append(r'\begingroup\small\setlength{\parskip}{.15\baselineskip}');bibliography=True
            if line in block_map:
                old,tex=block_map[line];out.append(tex);page_routes.append({'line':idx+1,'original':old,'tex':tex,'route':'explicit_block'});continue
            if layer!='apparatus' and page==1 and (line.startswith('©') or line=='Inventiones mathematicae' or line.startswith('0020-9910/')):
                page_routes.append({'line':idx+1,'original':line,'action':'COPY_MATTER_EXCLUSION'});continue
            key=f'{layer}:{page}:{line}'
            if key in overrides:
                tex=overrides[key]['tex'];out.append(tex);page_routes.append({'line':idx+1,'original':line,'tex':tex,'route':'explicit'});continue
            original_line=line
            if page==12 and line.startswith(('For α∈K,','Pour α∈K,')):real_tail=True
            if layer!='apparatus':line=number_face(line,page,real_tail)
            contents=re.fullmatch(r'(.*?)\s*\.{4,}\s*(\d+)\s*',line)
            if contents:tex=inline(contents.group(1))+r'\dotfill '+contents.group(2)+r'\par'
            elif line.startswith('§') and len(line)<120:tex=r'\subsection*{'+inline(line)+'}'
            elif re.fullmatch(r'(?:Contents|Table des matières|References|Références|[A-ZÀÉ][a-zÀ-ÿ\- ]{8,90})',line) and page<59:tex=r'\subsection*{'+inline(line)+'}'
            elif isformula(line):tex=r'\DFormula{'+math_tex(line)+'}'
            else:tex=inline(line)+r'\par'
            out.append(tex);page_routes.append({'line':idx+1,'original':original_line,'tex':tex,'route':'display' if isformula(line) else 'inline'})
        if bibliography:out.append(r'\endgroup')
        routes.append({'layer':layer,'physical_page':page,'printed_page':page+226,'source_record_sha256':hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest().upper(),'routes':page_routes})
    out.append(r'\end{document}')
    return '\n'.join(out)+'\n',routes

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,required=True);ap.add_argument('--output',type=Path,default=BASE/'normalized_v1');a=ap.parse_args()
    out=a.output.resolve();assert out.is_relative_to(BASE)
    input_receipt=json.loads((BASE/'D033_INPUT_REPLAY.json').read_text());expected={r['path']:r['sha256'] for r in input_receipt['members']}
    overrides=json.loads((BASE/'D033_TEX_OVERRIDES.json').read_text(encoding='utf8')) if (BASE/'D033_TEX_OVERRIDES.json').exists() else {}
    repairs=json.loads((BASE/'D033_TEXT_REPAIRS.json').read_text(encoding='utf8')) if (BASE/'D033_TEXT_REPAIRS.json').exists() else []
    manifest=[];allroutes=[];applied=[]
    for layer in ('source_english','french_translation','apparatus'):
        p=a.source/'edition'/(layer+'.ndjson');assert sha(p)==expected['edition/'+layer+'.ndjson']
        rows=[json.loads(s) for s in p.read_text(encoding='utf8').splitlines() if s.strip()]
        if layer=='apparatus':
            notes=json.loads((BASE/'D033_APPARATUS_NOTES.json').read_text(encoding='utf8'))
            rows=[dict(row,text=notes[str(row['physical_page'])]) for row in rows if str(row['physical_page']) in notes]
        for rep in repairs:
            if rep['layer']!=layer:continue
            row=rows[rep['page']-1];assert row['text'].count(rep['old'])==rep['count'],rep
            row['text']=row['text'].replace(rep['old'],rep['new']);applied.append(rep)
        doc,routes=render(layer,rows,overrides);allroutes.extend(routes)
        dest=out/'tex'/('D033_'+{'source_english':'EN','french_translation':'FR','apparatus':'APPARATUS'}[layer]+'.tex');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(doc,encoding='utf8')
        manifest.append({'path':dest.relative_to(out).as_posix(),'bytes':dest.stat().st_size,'sha256':sha(dest),'page_anchors':len(rows),'inline_math_spans':doc.count(r'\('),'display_math_spans':doc.count(r'\DFormula{'),'acceptance':'NORMALIZATION_DRAFT_NOT_AUDITED'})
    dump(out/'D033_FORMULA_ROUTES.json',allroutes)
    dump(out/'D033_NORMALIZATION_BUILD.json',{'schema':'d033_normalization_build_v1','status':'GENERATED_PENDING_COLD_VISUAL_MATHEMATICAL_AUDIT','source_archive_sha256':input_receipt['archive']['sha256'],'authority_sha256':input_receipt['authority_sha256'],'generator_sha256':sha(Path(__file__)),'parser_base_sha256':sha(BASE/'build_support/parser_base_d019.py'),'text_repairs':applied,'explicit_tex_overrides':len(overrides),'outputs':manifest})
    print(json.dumps({'result':'GENERATED_PENDING_AUDIT','outputs':manifest},ensure_ascii=True))

if __name__=='__main__':main()
