"""Sequential local LuaLaTeX build and deterministic diagnostic receipt."""
from pathlib import Path
import argparse,subprocess,os,json,hashlib,datetime,re
BASE=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def main():
    a=argparse.ArgumentParser();a.add_argument('--engine',required=True);a.add_argument('--directory',type=Path,default=BASE/'normalized_v1');a.add_argument('--passes',type=int,default=2);a.add_argument('--only',choices=['D033_EN','D033_FR','D033_APPARATUS']);args=a.parse_args()
    d=args.directory.resolve();assert d.is_relative_to(BASE)
    pdf=d/'pdf';pdf.mkdir(parents=True,exist_ok=True)
    env=dict(os.environ,SOURCE_DATE_EPOCH='0',FORCE_SOURCE_DATE='1',max_print_line='1000')
    rows=[]
    for name in ([args.only] if args.only else ('D033_EN','D033_FR','D033_APPARATUS')):
        for run in range(args.passes):
            cmd=[args.engine,'--no-shell-escape','--disable-installer','--interaction=nonstopmode','--halt-on-error','--output-directory=../pdf',name+'.tex']
            proc=subprocess.run(cmd,cwd=d/'tex',env=env,capture_output=True,timeout=180)
            (pdf/(name+f'.pass{run+1}.stdout.log')).write_bytes(proc.stdout)
            if proc.returncode:raise RuntimeError(name+' failed; inspect exact stdout log')
        log=(pdf/(name+'.log')).read_text(encoding='utf8',errors='replace')
        rows.append({'name':name,'tex_sha256':sha(d/'tex'/(name+'.tex')),'pdf_bytes':(pdf/(name+'.pdf')).stat().st_size,'pdf_sha256':sha(pdf/(name+'.pdf')),'log_sha256':sha(pdf/(name+'.log')),'diagnostics':[x for x in log.splitlines() if re.search(r'Overfull|Underfull|Missing character|^!|Warning:',x)],'result':'COMPILED_PENDING_VISUAL_AUDIT'})
    receipt=d/'D033_COMPILE_RECEIPT.json'
    if args.only and receipt.exists():
        prior=json.loads(receipt.read_text(encoding='utf8'))['artifacts'];rows=[r for r in prior if r['name']!=args.only]+rows
        rows.sort(key=lambda r:r['name'])
    receipt.write_text(json.dumps({'schema':'d033_compile_v1','engine':Path(args.engine).name,'compiled_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passes':args.passes,'artifacts':rows},indent=2)+'\n',encoding='utf8')
    print(json.dumps(rows))
if __name__=='__main__':main()
