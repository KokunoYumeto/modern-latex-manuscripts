"""Fresh nonpatching structural/reproduction check of the frozen D033 reader set."""
from pathlib import Path
import hashlib,json,re,subprocess
import pdfplumber
from pypdf import PdfReader
BASE=Path(__file__).resolve().parent
NORM=BASE/'normalized_v1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
records=[]
for lang,expected_pages in [('EN',60),('FR',60),('APPARATUS',3)]:
    p=NORM/'pdf'/f'D033_{lang}.pdf'
    tex=NORM/'tex'/f'D033_{lang}.tex'
    assert sha(p)==sha(BASE/'reproduction_check/pdf'/p.name)
    assert sha(tex)==sha(BASE/'reproduction_check/tex'/tex.name)
    pages=PdfReader(p).pages;assert len(pages)==expected_pages
    if lang!='APPARATUS':
        for i,page in enumerate(pages,1):
            assert re.search(r'Authority\s+'+str(i)+r'\s*/\s*printed\s+'+str(i+226),page.extract_text(),re.I)
    bounds=[]
    with pdfplumber.open(p) as pdf:
        for i,page in enumerate(pdf.pages,1):
            bad=[{'text':c['text'],'x0':c['x0'],'x1':c['x1'],'top':c['top'],'bottom':c['bottom']} for c in page.chars if c['x0']<0 or c['x1']>page.width+.5 or c['top']<0 or c['bottom']>page.height+.5]
            assert not bad,(lang,i,bad)
            bounds.append({'page':i,'characters':len(page.chars),'bounds':'WITHIN_MEDIA_BOX'})
    fonts=subprocess.run(['pdffonts',str(p)],check=True,capture_output=True,text=True).stdout.splitlines()[2:]
    assert fonts and all('yes yes yes' in line for line in fonts),fonts
    log=(NORM/'pdf'/f'D033_{lang}.log').read_text(encoding='utf8',errors='replace')
    assert not re.search(r'Overfull|Missing character|^!',log,re.M)
    records.append({'language':lang,'pdf_bytes':p.stat().st_size,'pdf_sha256':sha(p),'tex_bytes':tex.stat().st_size,'tex_sha256':sha(tex),'pages':len(pages),'fresh_rebuild':'BYTE_IDENTICAL_TEX_AND_PDF','embedded_fonts':len(fonts),'all_fonts_embedded_subset_unicode':True,'character_bounds':bounds,'overfull_or_missing_glyphs':0})
pixel_reuse=[]
for lang in ['EN','FR']:
    new=lang+'_'+sha(NORM/'pdf'/f'D033_{lang}.pdf')[:12]
    count=58 if lang=='EN' else 12
    for p in range(1,count+1):
        old=NORM/'qa'/lang/f'page-{p:02d}.png';latest=NORM/'qa'/new/f'page-{p:02d}.png'
        assert sha(old)==sha(latest),(lang,p)
    pixel_reuse.append({'language':lang,'verified_identical_already_inspected_pages':list(range(1,count+1)),'method':'PNG bytes SHA256 identical; bibliography-only layout change has no pixel effect here'})
old_fr=NORM/'qa/FR_B0043B1F42AC'
new_fr=NORM/'qa'/('FR_'+sha(NORM/'pdf/D033_FR.pdf')[:12])
changed=[p for p in range(1,61) if sha(old_fr/f'page-{p:02d}.png')!=sha(new_fr/f'page-{p:02d}.png')]
assert changed==[28]
pixel_reuse.append({'language':'FR','prose_boundary_correction_changed_pages':changed,'all_other_59_pages':'PNG bytes SHA256 identical to fully inspected preceding candidate','new_page28':'Producer visually inspected Réciproquement as normal prose; unchanged mathematics and page layout verified.'})
result={'schema':'d033_frozen_structural_gate_v1','result':'PASS','inspection_mode':'Fresh nonpatching check; no candidate mutation','artifacts':records,'pixel_reuse_proof':pixel_reuse,'visual_review':{'method':'Producer inspected complete English/French contact sheets across all120 reader pages, using proved pixel identity where a bibliography-only update changed the file container. All3 apparatus pages reviewed; detailed Englishp59, Frenchp43, apparatusp1 and rawsourcep19/p37 inspected at readable resolution. Independent auditor separately checks mathematical critical pages.','layout_findings':'Final readers each have exactly60 pages, one authority anchor per page. All42 references and EOF retained. No orphan spill pages, clipping, overlap, missing glyphs or off-page text found.','minor_build_messages':'French two underfull paragraph warnings are benign line-spacing diagnostics; visually inspected pages have no overflow. Shell-escape-off warning is intentional.'}}
(NORM/'D033_FROZEN_STRUCTURAL_GATE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps({'result':'PASS','artifacts':[{k:r[k] for k in ['language','pdf_bytes','pdf_sha256','pages','fresh_rebuild']} for r in records]}))
