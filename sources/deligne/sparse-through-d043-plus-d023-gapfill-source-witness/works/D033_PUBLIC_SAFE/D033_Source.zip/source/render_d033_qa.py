"""Bounded whole-reader rendering and page-topology diagnostics; no acceptance inference."""
from pathlib import Path
import hashlib,json,re,subprocess
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw
BASE=Path(__file__).resolve().parent
OUT=BASE/'normalized_v1'
QA=OUT/'qa'
QA.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
result=[]
for lang in ('EN','FR','APPARATUS'):
    pdf=OUT/'pdf'/('D033_'+lang+'.pdf')
    reader=PdfReader(pdf)
    pages=[];anchors=[]
    for i,page in enumerate(reader.pages,1):
        text=page.extract_text()
        hits=re.findall(r'Authority\s+(\d+)\s*/\s*printed\s+(\d+)',text,re.I)
        pages.append({'reader_page':i,'text_characters':len(text),'authority_anchors':hits})
        anchors.extend([int(a) for a,b in hits])
    if lang!='APPARATUS':assert anchors==list(range(1,61)),(lang,anchors)
    assert all(x['text_characters']>80 for x in pages)
    target=QA/(lang+'_'+sha(pdf)[:12]);target.mkdir(exist_ok=True)
    subprocess.run(['pdftoppm','-r','110','-png',str(pdf),str(target/'page')],check=True,capture_output=True,timeout=300)
    pngs=sorted(target.glob('page-*.png'))
    assert len(pngs)==len(reader.pages)
    contacts=[]
    for start in range(0,len(pngs),12):
        sheet=Image.new('RGB',(1800,1680),'#d5d5d5');draw=ImageDraw.Draw(sheet)
        for k,p in enumerate(pngs[start:start+12]):
            im=Image.open(p).convert('RGB');im.thumbnail((430,510))
            x=(k%4)*450+(450-im.width)//2;y=(k//4)*560+30
            sheet.paste(im,(x,y));draw.text(((k%4)*450+15,(k//4)*560+10),f'{lang} reader page {start+k+1}',fill='black')
        dest=target/f'contact_{start+1:03d}.jpg';sheet.save(dest,quality=90);contacts.append({'path':dest.relative_to(OUT).as_posix(),'sha256':sha(dest)})
    result.append({'language':lang,'pdf_sha256':sha(pdf),'reader_pages':len(reader.pages),'anchor_pages':anchors,'pages':pages,'rendered_pngs':len(pngs),'contact_sheets':contacts,'status':'RENDERED_REQUIRES_VISUAL_INSPECTION'})
(OUT/'D033_PAGE_TOPOLOGY.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps([{k:r[k] for k in ['language','pdf_sha256','reader_pages','rendered_pngs','anchor_pages']} for r in result]))
