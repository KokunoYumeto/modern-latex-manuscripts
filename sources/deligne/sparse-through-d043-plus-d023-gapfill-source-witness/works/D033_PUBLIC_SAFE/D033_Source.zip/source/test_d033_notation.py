"""Authority-bound regression tests. These supplement, never replace, pixel fidelity QA."""
import unittest, json, hashlib
from pathlib import Path
import normalize_d033 as n
BASE=Path(__file__).resolve().parent

class Notation(unittest.TestCase):
    def test_negative_radicals(self):
        self.assertEqual(n.math_tex('K(√−u)'),r'K(\sqrt{-u})')
        self.assertEqual(n.math_tex('K(√−1)'),r'K(\sqrt{-1})')
    def test_atomic_completion(self):
        self.assertEqual(n.math_tex('mẐ'),r'm\widehat{\mathbb{Z}}')
        self.assertEqual(n.math_tex('a+fẐ'),r'a+f\widehat{\mathbb{Z}}')
    def test_product_completion(self):
        self.assertIn(r'\widehat{',n.math_tex('(𝔣^{-1}𝔇^{-1})̂'))
        self.assertNotIn(')',n.math_tex('(𝔣^{-1}𝔇^{-1})̂'))
    def test_modified_function(self):
        self.assertEqual(n.math_tex('˜(εη^{k−1})'),r'\widetilde{\varepsilon \eta ^{k-1}}')
    def test_unit_dual_dagger(self):
        self.assertEqual(n.math_tex('I*'),r'I^{\ast}')
        self.assertEqual(n.math_tex('ε†'),r'\varepsilon ^{\dagger}')
        self.assertIn(r'\mathbb{Z}',n.inline('(Z/dZ)*'))
        self.assertIn(r'^{\ast}',n.inline('(Z/dZ)*'))
    def test_inverse_limit_and_scripts(self):
        self.assertIn(r'\varprojlim',n.math_tex('lim← R/p^nR'))
        self.assertIn(r'_{p^{n}}',n.math_tex('μ_{p^n}'))
        self.assertIn(r'^{b}u',n.math_tex('q^bu'))
    def test_matrix_spacing(self):
        self.assertEqual(n.math_tex('(α β; γ δ)'),n.math_tex('(α  β; γ  δ)'))
        self.assertIn(r'\begin{pmatrix}',n.inline('(α β; γ δ)'))
    def test_real_parameter_distinction(self):
        self.assertEqual(n.number_face('K⊗R→R',12,False),'K⊗R→R')
        self.assertEqual(n.number_face('K⊗R→R',12,True),'K⊗ℝ→ℝ')
        self.assertEqual(n.number_face('K⊗R; R⊂L',50),'K⊗ℝ; R⊂L')
        self.assertEqual(n.math_tex('Γ_R'),r'\Gamma _{\mathbb{R}}')
        self.assertEqual(n.number_face('Réciproquement,',28),'Réciproquement,')
    def test_diagram_and_labels(self):
        entries=json.loads((BASE/'D033_TEX_OVERRIDES.json').read_text(encoding='utf8'))
        tri=[v['tex'] for k,v in entries.items() if k.startswith('source_english:19:')][0]
        self.assertNotIn(r'\sim',tri)
        self.assertIn(r'\arrow[dd]',tri)
        self.assertIn(r'\arrow[ur',tri)
        arrow=[v['tex'] for k,v in entries.items() if k.startswith('source_english:28:')][0]
        self.assertIn(r'\xrightarrow[\sim]{N}',arrow)
        comp=[v['tex'] for k,v in entries.items() if k.startswith('source_english:34:')][0]
        self.assertEqual(comp.count(r'\xrightarrow{\sim}'),2)
        bernoulli=[v['tex'] for k,v in entries.items() if k.startswith('source_english:7:')][0]
        self.assertNotIn(r'\mathbb',bernoulli)
        self.assertIn(r'\frac{Z^k}{k!}',bernoulli)
        sums=[v['tex'] for k,v in entries.items() if k.startswith('source_english:43:')]
        self.assertEqual(len(sums),2)
        self.assertIn(r'\text{ invertible}',sums[0])
        self.assertIn(r'\right]_{s=0}',sums[0])
    def test_copy_exclusion_and_topology(self):
        for lang in ('EN','FR'):
            doc=(BASE/'normalized_v1/tex'/('D033_'+lang+'.tex')).read_text(encoding='utf8')
            self.assertEqual(doc.count(r'\DAnchor{'),60)
            for p in range(1,61):self.assertEqual(doc.count(r'\DAnchor{'+str(p)+'}{'+str(p+226)+'}'),1)
            for forbidden in ('©','0020-9910/','verbatim','<pre>'):
                self.assertNotIn(forbidden,doc)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Notation)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    rec={'schema':'d033_notation_regression_v1','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'result':'PASS' if result.wasSuccessful() else 'FAIL','scope':'Ten authority-bound notation families plus 60-anchor and copy-exclusion checks; separate source, visual and cold audits still required.','test_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest().upper()}
    (BASE/'normalized_v1/D033_NOTATION_TESTS.json').write_text(json.dumps(rec,indent=2)+'\n',encoding='utf8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
