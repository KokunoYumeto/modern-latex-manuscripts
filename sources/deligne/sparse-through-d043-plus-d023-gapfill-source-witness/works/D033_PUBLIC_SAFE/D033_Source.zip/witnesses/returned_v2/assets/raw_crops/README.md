Untouched lossless crops from the controlling IAS authority only. Never overwrite. Record page, pixel bounding box, parameters, and SHA-256.
