#!/usr/bin/env python3
import argparse,csv,hashlib,json,pathlib,subprocess,sys,tempfile,zipfile
PREFIX='DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS';AUTH_SHA='29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D'
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest().upper()
def rows(path):
 with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def writej(path,obj):path.write_bytes((json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n').encode())
p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('output_dir');p.add_argument('session_id');p.add_argument('prompt_id');p.add_argument('status',choices=('IN_PROGRESS','COMPLETE'));p.add_argument('--diagnostic',action='append',default=[]);a=p.parse_args();root=pathlib.Path(a.root).resolve();out=pathlib.Path(a.output_dir).resolve();out.mkdir(parents=True,exist_ok=True);n=int(a.prompt_id[1:]);assert a.session_id==f'S{n:02d}' and 1<=n<=10
plan=rows(root/'control'/'SESSION_PLAN.tsv');row=plan[n-1];assert row['prompt_id']==a.prompt_id;cov=rows(root/'coverage'/'coverage.tsv');counts={key:sum(r[key]=='COMPLETE' for r in cov) for key in ('source_status','french_status','apparatus_status','final_status')};expected=int(row['cumulative_units_on_complete'])
if a.status=='COMPLETE':
 assert all(value==expected for value in counts.values());owned=set(range(int(row['physical_start']),int(row['physical_end'])+1));assert all(int(r['physical_page']) not in owned or r['final_status']=='COMPLETE' for r in cov)
 if n==10:
  receipt=root/'audit'/'S10_COLD_AUDIT.json';assert receipt.is_file();audit=json.loads(receipt.read_text(encoding='utf-8'));assert audit['status']=='COMPLETE' and audit['mode']=='FRESH_FULL_NONPATCHING_COLD_AUDIT' and int(audit['fresh_audit_attempt'])>=1 and audit['visual_formula_audit']==audit['diagram_audit']==audit['english_source_audit']==audit['french_translation_audit']==audit['role_audit']=='COMPLETE'
assert not any(int(r['physical_page'])>int(row['physical_end']) and r['final_status']=='COMPLETE' for r in cov)
subprocess.run([sys.executable,str(root/'tools'/'build_readers.py'),str(root)],check=True,stdout=subprocess.PIPE);subprocess.run([sys.executable,str(root/'tools'/'validate_state.py'),str(root)],check=True,stdout=subprocess.PIPE)
stem=f'{PREFIX}_S{n:02d}_CUMULATIVE';z=out/f'{stem}_FULL_STATE.zip';c=out/f'{stem}_CHECKPOINT.json';m=out/f'{stem}_MANIFEST.tsv';subprocess.run([sys.executable,str(root/'tools'/'package_state.py'),str(root),str(z)],check=True)
with tempfile.TemporaryDirectory(prefix='d033_repack_') as td:
 second=pathlib.Path(td)/'second.zip';subprocess.run([sys.executable,str(root/'tools'/'package_state.py'),str(root),str(second)],check=True);assert sha(second)==sha(z)
checkpoint={'schema_version':'deligne-d033-checkpoint-v1','work_id':PREFIX,'current_session':a.session_id,'prompt_id':a.prompt_id,'status':a.status,'physical_units':60,'article_pages':60,'source_pdf_pages':60,'source_pdf_sha256':AUTH_SHA,'source_complete_units':counts['source_status'],'french_complete_units':counts['french_status'],'apparatus_complete_units':counts['apparatus_status'],'final_complete_units':counts['final_status'],'accepted_prior_members':0,'accepted_diagram_members':0,'full_state':{'filename':z.name,'bytes':z.stat().st_size,'sha256':sha(z)},'deterministic_repack':True,'next_prompt':('NONE_PROJECT_COMPLETE' if n==10 and a.status=='COMPLETE' else (a.prompt_id if a.status=='IN_PROGRESS' else f'P{n+1:02d}')),'resume_rule':'Use newest valid same-session trio while IN_PROGRESS; after COMPLETE advance once; never roll back.','internal_diagnostics':a.diagnostic};writej(c,checkpoint)
lines=['scope\tpath\tbytes\tsha256',f'TRIO\t{z.name}\t{z.stat().st_size}\t{sha(z)}',f'TRIO\t{c.name}\t{c.stat().st_size}\t{sha(c)}']
with zipfile.ZipFile(z) as archive:
 for name in archive.namelist():data=archive.read(name);lines.append(f'STATE_MEMBER\t{name}\t{len(data)}\t{hashlib.sha256(data).hexdigest().upper()}')
m.write_text('\n'.join(lines)+'\n',encoding='utf-8',newline='\n');print(json.dumps({'result':'PASS','status':a.status,'trio':[z.name,c.name,m.name],'deterministic_repack':True},sort_keys=True))
