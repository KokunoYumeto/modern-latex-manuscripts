Conservative derivatives paired with untouched raw authority crops. Public QA and diagram crops remain ZERO_ACCEPTED locators and cannot substitute.
