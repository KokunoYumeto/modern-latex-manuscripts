# Read first - D033 exact-work intake

This flat packet opens exactly one English joint work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. The controlling authority is 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf, 60 physical pages mapping to printed pages 227-286, SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only.

The production layers are not two English readers. They are: (1) a source-faithful diplomatic English edition; (2) a standalone French translation made only from frozen English source pages; and (3) restrained apparatus. Run exactly P01-P10 in order. P10 integrates all 60 pages and conducts a fresh full nonpatching audit.

30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip has SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D: 61 path-provenance rows map to 58 unique preserved members. 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip has SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0: exactly 95 unique D033-only diagram/archive members selected from the named 501,856,673-byte multiwork archive. Across both branches there are 156 provenance rows and 153 unique contents. Every inherited candidate, evidence member, OCR locator, QA render, and diagram witness begins ZERO_ACCEPTED.

Every response returns a deterministic cumulative full-state ZIP, checkpoint JSON, and manifest TSV. Workflow states are only IN_PROGRESS and COMPLETE. Replay and freeze authority English before candidate comparison or French translation.
