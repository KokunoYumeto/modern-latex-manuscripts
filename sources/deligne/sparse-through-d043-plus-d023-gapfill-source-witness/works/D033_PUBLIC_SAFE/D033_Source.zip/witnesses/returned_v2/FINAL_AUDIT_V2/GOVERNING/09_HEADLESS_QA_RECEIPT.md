# Headless QA receipt - D033 staging

Construction uses exact hashing, PDF metadata/XObject checks, deterministic archive selection, candidate structural assertions, ZIP reopening/repacking, and rendered PNG inspection without Explorer or any GUI viewer. Authority pages representing opening, contents, section starts, the page-31 exponent gate, references, and EOF are reviewed; the Segment 2 opening render is reviewed for inherited overflow. The final packet is not opened on screen.
