# Authority topology and boundary audit - D033

The selected authority is 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf: 60 consecutive pages, printed 227-286, rotation 0, no encryption, form, JavaScript, annotations, or AcroForm. It contains one 3392-or-3400 by 5393-or-5394 gray one-bit CCITT image per page at 600 dpi. Its 60 decoded aggregate page-content hashes and 60 decoded image hashes are distinct.

The 60-page comparator is rotation 0 and contains one 1132-or-1134 by 1799-or-1800 gray one-bit JBIG2 image per page at 200 dpi; it remains comparison-only. The public structural audits have SHA-256 7818C46BEE32B9982FE41A65A987F5512E6ED46BFC525F105B0F192717BCBF6A and 75BD43CF572D6CAF962C9673A17DB7FC7AA8DEF86A1969EA5BFC6DEF2EAAA40F.

Physical 1 carries the publication line, exact title, both-author byline, address/footnote, and Section 0. The Contents on physical 6 locates Sections 1-8 at printed 233, 238, 245, 254, 258, 267, 273, and 277. Physical 31 contains authority `q^b u`. Physical 59 begins References [1]-[21]; physical 60 completes [22]-[42], prints `Received January 7, 1980`, leaves blank remainder, and is physical EOF.
