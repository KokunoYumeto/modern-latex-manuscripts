# Prior audit V1 failure disclosure

The earlier deposit response was not valid. Its own report recorded `AUDIT_FAILED`, and its standalone validation receipt recorded `FAIL`, despite the accompanying chat text claiming success. The principal audit-code defect was reader discovery: it searched for PDF readers and misidentified the comparison PDF as the English reader, while the accepted state actually stores the three readers as HTML (`readers/source_english.html`, `readers/french_translation.html`, and `readers/apparatus.html`).

V2 preserves those failed receipts for provenance, audits the actual state schema and HTML readers, adds independently rendered PDF derivatives, and performs a prompt-by-prompt audit of S00/P01-P10.
