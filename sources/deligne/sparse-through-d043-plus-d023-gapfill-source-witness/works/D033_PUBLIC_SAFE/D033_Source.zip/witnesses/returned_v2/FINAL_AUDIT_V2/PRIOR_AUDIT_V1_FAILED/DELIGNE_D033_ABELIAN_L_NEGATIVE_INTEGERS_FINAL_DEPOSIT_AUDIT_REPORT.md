# DEL 33 — Final Full Audit and Deposit Report

**Gate:** `AUDIT_FAILED`  
**Audited S10 SHA-256:** `B34493F6FE52C18516F6D1B7E6A438B4465955E1063262B24281C5488FF1FE28`  
**Scope:** P01–P10; 60 authority pages; printed pages 227–286; source-English, French translation, and apparatus.

## Finding

The deposit gate found 3 blocking issue(s); see the table and machine receipt.

## Audit matrix

| ID | Result | Blocking | Finding |
|---|---:|---:|---|
| `F01_INPUTS` | **PASS** | yes | Final S10 archive/checkpoint/manifest are present |
| `F02_ARCHIVE_INTEGRITY` | **PASS** | yes | S10 archive CRC, path-safety, duplicate-name, and symlink checks |
| `F03_TERMINAL_CHECKPOINT` | **PASS** | yes | Checkpoint is terminal and records 60 completed units |
| `F04_GOVERNING_SCOPE` | **PASS** | yes | Governing scope resolves to 60 pages and ten prompts |
| `F05_MEMBER_QUALITY` | **PASS** | yes | Every text/JSON member decodes and no junk, replacement glyphs, or illegal controls remain |
| `F06_PACKET_VERIFIER` | **WARN** | no | Original source-packet verifier |
| `F07_PACKET_RECEIPT` | **PASS** | yes | Original validation receipt contains no failing verdict |
| `F08_PDF_OPEN_RENDER` | **PASS** | yes | All final-state PDFs open, render, and pass qpdf where available |
| `F09_PDF_PAGE_ANOMALIES` | **WARN** | no | No empty pages, media-box overflow, or replacement glyphs in final-state PDFs |
| `F10_READER_DISCOVERY` | **FAIL** | yes | Distinct source-English, French-translation, and apparatus readers identified |
| `F11_ROLE_SEPARATION` | **FAIL** | yes | Reader layers are substantial, distinct, and language-appropriate |
| `F12_TERMINAL_SOURCE_CONTENT` | **FAIL** | yes | Source reader reaches the article terminus and contains the expected final sections/references/date |
| `F13_TARGETED_HAZARDS` | **WARN** | no | Targeted high-risk readings are recoverable from the rendered source text layer |
| `F14_ALL_PAGE_REPLAY_COVERAGE` | **WARN** | no | All 60 authority pages localize lexically in the source-English reader using native PDF text layers |
| `F15_FINAL_RECEIPTS` | **PASS** | no | Terminal/final receipts and checkpoints contain no failure verdict |
| `F16_HISTORICAL_MANIFEST` | **PASS** | no | Historical S10 manifest resolves against the reopened state |

## Corrections applied

- **C01:** Reopened the final S10 archive and regenerated an authoritative member-by-member SHA-256 manifest.
- **C02:** Added a terminal audit receipt/report, governing snapshot, reader contact sheets, and explicit deposit checkpoint.
- **C03:** Normalized ZIP order, timestamps, permissions, encoding flags, compression, and member paths for deterministic reproduction.
- **C04:** Preserved the historical S10 checkpoint and manifest as audited provenance rather than silently replacing them.

## Selected readers

- `source_english`: `comparison/21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf`
- `french_translation`: `NOT FOUND`
- `apparatus`: `NOT FOUND`

## Packaging rule

The final archive is built twice from the same staging tree with stable ZIP metadata. Release requires identical hashes and an exact reopened-tree comparison.
