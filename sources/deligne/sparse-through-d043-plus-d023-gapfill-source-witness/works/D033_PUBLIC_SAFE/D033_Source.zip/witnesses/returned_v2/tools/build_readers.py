#!/usr/bin/env python3
import argparse,csv,html,json,pathlib
PAGES=60
AUTHORS='Pierre Deligne and Kenneth A. Ribet'
LAYERS=[
 ('source_english','source_status','en','Values of Abelian L-functions at Negative Integers over Totally Real Fields - source-faithful English edition'),
 ('french_translation','french_status','fr','Valeurs de fonctions L abéliennes aux entiers négatifs sur les corps totalement réels - traduction française autonome'),
 ('apparatus','apparatus_status','en','Values of Abelian L-functions at Negative Integers over Totally Real Fields - restrained apparatus'),
]
def rows(path):
 with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def records(root,layer):
 out={}
 for line in (root/'edition'/f'{layer}.ndjson').read_text(encoding='utf-8').splitlines():
  if not line.strip():continue
  obj=json.loads(line);page=int(obj['physical_page']);assert page not in out;out[page]=obj
 return out
def labels(lang,layer):
 if lang=='fr':
  return {
   'authors':'Auteurs','complete':'Unités physiques complètes','of':'sur',
   'page':'Page physique de l’autorité','printed':'page imprimée',
   'zone':'Source anglaise rejouée et figée d’après l’autorité ; traduction française autonome établie uniquement depuis cette source figée.'
  }
 if layer=='apparatus':
  zone='Source language: English; page-local source replay, French alignment, comparison status, and exclusions recorded below.'
 else:
  zone='Source language: English; authority replay frozen before comparison; French translation prepared separately from the frozen source.'
 return {'authors':'Authors','complete':'Complete physical units','of':'of','page':'Authority physical page','printed':'printed','zone':zone}
def render(layer,status_key,lang,title,coverage,recs):
 complete=[r for r in coverage if r[status_key]=='COMPLETE'];lab=labels(lang,layer)
 out=['<!doctype html>',f'<html lang="{lang}">','<meta charset="utf-8">','<meta name="viewport" content="width=device-width,initial-scale=1">',f'<title>{html.escape(title)}</title>',
 '<style>body{font:18px/1.52 Georgia,serif;max-width:78rem;margin:2rem auto;padding:0 1rem;color:#111}h1{font-size:2.15rem;line-height:1.18}article{border-top:1px solid #bbb;padding:1rem 0}article+article{break-before:page}pre{white-space:pre-wrap;overflow-wrap:anywhere;font:inherit;margin:0}figure{display:grid;grid-template-columns:1fr 1fr;gap:1rem}img{max-width:100%}figcaption{grid-column:1/-1}.zone{color:#555;font-size:.92em}</style>',
 '<body>',f'<h1>{html.escape(title)}</h1>',f'<p>{lab["authors"]}: {AUTHORS}.</p>',f'<p>{lab["complete"]}: {len(complete)} {lab["of"]} {PAGES}.</p>']
 for row in complete:
  page=int(row['physical_page']);rec=recs[page];out += [f'<article id="physical-{page:02d}"><h2>{lab["page"]} {page} - {lab["printed"]} {row["printed_page"]}</h2><p class="zone">{html.escape(lab["zone"])}</p><pre>{html.escape(str(rec.get("text","")))}</pre>']
  for asset in rec.get('assets',[]):out += [f'<figure><img src="../{html.escape(str(asset["raw_path"]),quote=True)}" alt="raw authority crop"><img src="../{html.escape(str(asset["presentation_path"]),quote=True)}" alt="presentation derivative"><figcaption>{html.escape(str(asset.get("caption",asset.get("id","source asset"))))}</figcaption></figure>']
  out.append('</article>')
 out += ['</body>','</html>',''];return '\n'.join(out)
p=argparse.ArgumentParser();p.add_argument('root',nargs='?',default='.');p.add_argument('--check',action='store_true');a=p.parse_args();root=pathlib.Path(a.root).resolve();coverage=rows(root/'coverage'/'coverage.tsv');stale=[]
for layer,status,lang,title in LAYERS:
 expected=render(layer,status,lang,title,coverage,records(root,layer));path=root/'readers'/f'{layer}.html'
 if a.check:
  if not path.is_file() or path.read_text(encoding='utf-8')!=expected:stale.append(path.name)
 else:path.parent.mkdir(parents=True,exist_ok=True);path.write_text(expected,encoding='utf-8',newline='\n')
if stale:raise SystemExit('stale readers: '+', '.join(stale))
print(json.dumps({'result':'PASS','mode':'check' if a.check else 'write','authors':['Pierre Deligne','Kenneth A. Ribet'],'layers':[x[0] for x in LAYERS]},sort_keys=True))
