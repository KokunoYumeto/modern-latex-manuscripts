# Ten literal ordered prompts - D033

Exactly ceil(60/6) = 10; contiguous six-page ranges with no gaps or overlap. P10 integrates and conducts the fresh full nonpatching audit.

<!-- BEGIN_LITERAL_PROMPT P01 -->
# P01 - D033 physical pages 1-6 (printed 227-232)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 1-6, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay publication line, exact title, both-author byline, IHES address/Ribet permanent-address footnote, Section 0 opening, introduction, main-results summary, and complete Contents on printed 227-232.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S01_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S01_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S01_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S01/P01, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P01 -->

<!-- BEGIN_LITERAL_PROMPT P02 -->
# P02 - D033 physical pages 7-12 (printed 233-238)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 7-12, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 233-238: Section 1, equations (1.1)-(1.16), all result labels/proofs, and the opening of Section 2.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S02_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S02_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S02_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S02/P02, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P02 -->

<!-- BEGIN_LITERAL_PROMPT P03 -->
# P03 - D033 physical pages 13-18 (printed 239-244)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 13-18, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 239-244: Section 2 in full continuity, including all measure-space definitions, diagrams, formulae, and footnotes.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S03_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S03_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S03_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S03/P03, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P03 -->

<!-- BEGIN_LITERAL_PROMPT P04 -->
# P04 - D033 physical pages 19-24 (printed 245-250)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 19-24, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 245-250: native commutative diagrams and the opening/continuation of Section 3 A Functional Equation.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S04_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S04_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S04_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S04/P04, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P04 -->

<!-- BEGIN_LITERAL_PROMPT P05 -->
# P05 - D033 physical pages 25-30 (printed 251-256)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 25-30, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 251-256: finish Section 3, open Section 4 An Irreducibility Theorem, and preserve formulas (4.1)-(4.5) exactly.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S05_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S05_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S05_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S05/P05, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P05 -->

<!-- BEGIN_LITERAL_PROMPT P06 -->
# P06 - D033 physical pages 31-36 (printed 257-262)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 31-36, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 257-262 once from authority. Preserve q^b u in Theorem (4.5)(b), not inherited q^{1/b}u; complete Corollary (4.6), open Section 5, and reject the candidate overlap, invented continuation heading/bracketed prose, French labels, and overflow.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S06_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S06_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S06_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S06/P06, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P06 -->

<!-- BEGIN_LITERAL_PROMPT P07 -->
# P07 - D033 physical pages 37-42 (printed 263-268)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 37-42, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 263-268: continue Section 5, open Section 6 Eisenstein Series, and preserve Theorem (6.1) and all formula/diagram structures.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S07_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S07_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S07_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S07/P07, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P07 -->

<!-- BEGIN_LITERAL_PROMPT P08 -->
# P08 - D033 physical pages 43-48 (printed 269-274)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 43-48, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 269-274: finish the relevant Section 6 development and open Section 7 Theta Series at printed 273.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S08_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S08_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S08_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S08/P08, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P08 -->

<!-- BEGIN_LITERAL_PROMPT P09 -->
# P09 - D033 physical pages 49-54 (printed 275-280)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 49-54, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 275-280: continue Section 7 and open Section 8 Congruences for L-values with Theorem (8.1).

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S09_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S09_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S09_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S09/P09, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P09 -->

<!-- BEGIN_LITERAL_PROMPT P10 -->
# P10 - D033 physical pages 55-60 (printed 281-286)

You are editing exactly one work: Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*. Use 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf (60 pages; SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D) as the only authority. 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf is comparison-only. 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip (SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D) and 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip (SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0) are inherited ZERO_ACCEPTED locator/lineage evidence.

Open the newest valid cumulative predecessor state and execute only owned physical pages 55-60, exactly once and in order. On each page: inspect authority pixels; replay complete source-English content; render-compare, correct, and freeze English; only then compare inherited evidence; translate the frozen English into standalone French; render/check French; then add restrained apparatus. Do not create a redundant second English translation.

Replay printed 281-286: finish Section 8 and the proof of (0.4); preserve References [1]-[42], Received January 7, 1980, terminal blank-remainder exclusion, and physical EOF.

Consult 14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv. Do not silently patch inherited text. Any image fallback requires a new untouched authority crop plus a separately hashed/logged derivative. Inherited QA renders and the 95 diagram members remain locators only. Preserve all work matter; omit repeated running headers/folios from reader prose and exclude terminal blank remainder while documenting them in apparatus. Use only IN_PROGRESS or COMPLETE; repair from attached scans and continue without a routine stop state or attempt/time cap.

After page-local freeze, integrate physical pages 1-60. Start a new clean audit workspace, do not read earlier audit conclusions, and do not perform patch-only checking. Reopen the authority and audit every page; English source fidelity; French alignment; both-author role; title, address, footnote, Sections 0-8; every mathematical display and diagram; all five hazard gates; references/received date; exclusions; and EOF. Record audit/S10_COLD_AUDIT.json with mode FRESH_FULL_NONPATCHING_COLD_AUDIT, status COMPLETE, positive fresh_audit_attempt, and visual_formula_audit, diagram_audit, english_source_audit, french_translation_audit, and role_audit all COMPLETE. If anything is wrong, repair normal state and restart the clean audit at page 1.


Before responding, rebuild readers, validate state, package the complete cumulative state twice with fixed metadata, require identical hashes, reopen and verify all members. Return exactly:

- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S10_CUMULATIVE_FULL_STATE.zip
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S10_CUMULATIVE_CHECKPOINT.json
- DELIGNE_D033_ABELIAN_L_NEGATIVE_INTEGERS_S10_CUMULATIVE_MANIFEST.tsv

The checkpoint identifies S10/P10, actual status, cumulative layer counts, authority and ZIP hashes, deterministic repack, diagnostics, and next prompt.
<!-- END_LITERAL_PROMPT P10 -->
