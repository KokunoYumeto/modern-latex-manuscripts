# Audit correction notice

V1 must not be treated as a passed deposit. Its embedded report and standalone validation receipt both recorded failure. V2 corrects the audit implementation, not the accepted S10 edition: it recognizes HTML readers, audits all prompt trios, generates reader PDF derivatives for convenience, preserves the failed V1 evidence, and produces a new deterministic deposit with a passing external validation receipt.
