# Governing instructions - D033

## Frozen identity and precedence

- Work: *Values of Abelian L-functions at Negative Integers over Totally Real Fields*; authors Pierre Deligne and Kenneth A. Ribet; exact source byline `Pierre Deligne and Kenneth A. Ribet*`.
- Authority: 20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf, 60 pages, printed 227-286, SHA-256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D.
- Comparator: 21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf, SHA-256 683C3C94BC1533875DFD79311555C3827351B9FCB075D1D8F3B3300C6A1A58A5; COMPARISON_ONLY.
- Public record: 21808065, DOI 10.5281/zenodo.21808065. The local 15-file MD5-verified delta totals 17,485,122 bytes.
- Prior/evidence salvage: 30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip, SHA-256 D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D; 61 witnesses to 58 unique contents.
- D033 diagram selection: 31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip, SHA-256 B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0; exactly 95 members/50,106,108 uncompressed bytes; the full multiwork archive is not attached.
- Precedence: authority pixels; frozen page-local English source; independently checked French translation; restrained apparatus. Candidates, OCR, public QA renders, diagram witnesses, and comparator remain ZERO_ACCEPTED locators until page-local authority replay proves the relevant content.

## Three-layer contract

The original is English. Build one source-faithful diplomatic English edition, not a modernized paraphrase. Build a separate French translation only after the corresponding English page is rendered, compared, corrected, and frozen. Build restrained apparatus separately. Never create a redundant second English translation and never relabel the inherited mixed-label candidates as French.

Preserve title, both-author byline, address and Ribet footnote, Section 0, Sections 1-8, every theorem/corollary/proof/equation/diagram/footnote, References [1]-[42], and `Received January 7, 1980`. Exclude repeated running headers/folios from reader prose and the terminal blank remainder while recording pagination and exclusions in apparatus. Do not silently modernize notation, punctuation, spelling, or mathematical typography.

## Page-local replay order

For each owned page: inspect attached authority pixels; replay complete source-English text, mathematics, and diagrams; render-compare; correct and freeze English; only then inspect candidates/evidence/comparator; translate the frozen page into French; render/check the French; then write restrained apparatus. Any image fallback requires a new untouched lossless crop from the attached authority plus a separately hashed presentation derivative and full extraction log. Inherited QA/diagram images remain locators only.

## Mandatory gates

14_MANDATORY_REPLAY_HAZARD_LEDGER.tsv defines five mandatory replay hazards. In particular, physical page 31 must preserve source `q^b u`, not inherited `q^{1/b}u`; pages 31-32 are replayed exactly once despite the substantive candidate overlap; invented continuation prose and visible overflow are removed by authority replay; English theorem labels stay English; and French is independently translated because no inherited French candidate exists. These are non-exhaustive warnings: audit every other line, formula, diagram, and footnote.

## Sessions and completion

Exactly ten prompts own 1-6, 7-12, 13-18, 19-24, 25-30, 31-36, 37-42, 43-48, 49-54, and 55-60. Each response, including IN_PROGRESS, returns the complete current cumulative ZIP/checkpoint/manifest trio. Package twice with fixed ZIP metadata, reopen and verify, and require identical hashes. Resume newest valid same-session state; never roll back.

Only IN_PROGRESS and COMPLETE are production states. Repair anomalies from attached authority bytes and continue; there is no ordinary HOLD, terminal FAIL, time cap, summarization, skipping, or invented material. P10 rebuilds all readers, then starts a clean audit workspace without prior audit conclusions and audits every page nonpatchingly. On any error, repair ordinary state and restart the fresh audit from page 1.
