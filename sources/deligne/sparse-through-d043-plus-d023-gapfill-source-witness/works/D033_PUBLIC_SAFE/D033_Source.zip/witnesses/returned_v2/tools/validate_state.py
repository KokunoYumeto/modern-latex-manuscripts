#!/usr/bin/env python3
import csv,hashlib,json,pathlib,re,subprocess,sys,zipfile
ROOT=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
AUTH='20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf';AUTH_SHA='29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D';AUTH_BYTES=5228290
COMP='21_COMPARATOR_DELIGNE_RIBET_D033_COLLECTED_60PP.pdf';COMP_SHA='683C3C94BC1533875DFD79311555C3827351B9FCB075D1D8F3B3300C6A1A58A5';COMP_BYTES=1379033
SALV='30_ZERO_ACCEPTED_DEDUP_PRIOR_EVIDENCE_D033.zip';SALV_SHA='D5E65DF898BD5667453A2495F5D49B26E1B9F456E1A69F01D194BE7F2F8CAE1D';DIAG='31_ZERO_ACCEPTED_D033_DIAGRAM_SELECTION_95.zip';DIAG_SHA='B90F429B75074F5A098A0270E2A576BB71B4391D4CA957490AAEFC9ADFF1D1E0'
LAYERS=[('source_english','source_status','source_record_sha256'),('french_translation','french_status','french_record_sha256'),('apparatus','apparatus_status','apparatus_record_sha256')]
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest().upper()
def rows(path):
 with path.open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f,delimiter='\t'))
def canonical(obj):return hashlib.sha256(json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest().upper()
def pdfinfo(path):return subprocess.check_output(['pdfinfo',str(path)],text=True,errors='replace')
def pdfpages(path):return int(next(x.split(':',1)[1].strip() for x in pdfinfo(path).splitlines() if x.startswith('Pages:')))
def image_rows(path):return [x.split() for x in subprocess.check_output(['pdfimages','-list',str(path)],text=True,errors='replace').splitlines() if x.split() and x.split()[0].isdigit()]
def records(layer):
 out={}
 for line in (ROOT/'edition'/f'{layer}.ndjson').read_text(encoding='utf-8').splitlines():
  if not line.strip():continue
  obj=json.loads(line);assert line==json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':'));assert {'physical_page','authority_pdf_page','article_page','printed_page','source_language','source_edition_action','french_translation_action','disposition','status','source_pdf_sha256','text','assets'}.issubset(obj);page=int(obj['physical_page']);assert page not in out and obj['status'] in ('IN_PROGRESS','COMPLETE');out[page]=obj
 return out
authority=ROOT/'source'/AUTH;comparator=ROOT/'comparison'/COMP;salvage=ROOT/'salvage'/SALV;diagram=ROOT/'salvage'/DIAG
assert authority.is_file() and authority.stat().st_size==AUTH_BYTES and sha(authority)==AUTH_SHA and pdfpages(authority)==60 and 'Page rot:        0' in pdfinfo(authority)
assert comparator.is_file() and comparator.stat().st_size==COMP_BYTES and sha(comparator)==COMP_SHA and pdfpages(comparator)==60 and 'Page rot:        0' in pdfinfo(comparator)
ar=image_rows(authority);assert len(ar)==60 and [int(x[0]) for x in ar]==list(range(1,61)) and all(x[2]=='image' and int(x[3]) in (3392,3400) and int(x[4]) in (5393,5394) and x[5]=='gray' and x[6]=='1' and x[7]=='1' and x[8]=='ccitt' and int(x[12])==600 and int(x[13])==600 for x in ar)
cr=image_rows(comparator);assert len(cr)==60 and [int(x[0]) for x in cr]==list(range(1,61)) and all(x[2]=='image' and int(x[3]) in (1132,1134) and int(x[4]) in (1799,1800) and x[5]=='gray' and x[6]=='1' and x[7]=='1' and x[8]=='jbig2' and int(x[12])==200 and int(x[13])==200 for x in cr)
ledger=rows(ROOT/'control'/'SALVAGE_PROVENANCE_LEDGER.tsv');assert len(ledger)==61 and all(r['accepted_state']=='ZERO_ACCEPTED' for r in ledger);canon={r['canonical_archive_path'] for r in ledger};assert len(canon)==58 and len({r['sha256'] for r in ledger})==58
assert sha(salvage)==SALV_SHA
with zipfile.ZipFile(salvage) as z:
 assert z.testzip() is None and set(z.namelist())==canon and len(z.namelist())==58 and all(i.date_time==(1980,1,1,0,0,0) for i in z.infolist())
 for r in ledger:
  data=z.read(r['canonical_archive_path']);assert len(data)==int(r['bytes']) and hashlib.sha256(data).hexdigest().upper()==r['sha256']
evidence=rows(ROOT/'control'/'D033_PUBLIC_EVIDENCE_MEMBER_INVENTORY.tsv');assert len(evidence)==45 and sum(r['member_type']=='FILE' for r in evidence)==43 and sum(r['member_type']=='DIRECTORY_ENTRY' for r in evidence)==2 and all(r['accepted_state']=='ZERO_ACCEPTED' for r in evidence)
diagrams=rows(ROOT/'control'/'D033_DIAGRAM_SELECTION_INVENTORY.tsv');assert len(diagrams)==95 and len({r['sha256'] for r in diagrams})==95 and sum(int(r['bytes']) for r in diagrams)==50106108 and all(r['accepted_state']=='ZERO_ACCEPTED' for r in diagrams)
assert sha(diagram)==DIAG_SHA
with zipfile.ZipFile(diagram) as z:
 assert z.testzip() is None and set(z.namelist())=={r['canonical_archive_path'] for r in diagrams} and len(z.namelist())==95 and all(i.date_time==(1980,1,1,0,0,0) for i in z.infolist())
 for r in diagrams:
  data=z.read(r['canonical_archive_path']);assert len(data)==int(r['bytes']) and hashlib.sha256(data).hexdigest().upper()==r['sha256']
faults=rows(ROOT/'control'/'MANDATORY_REPLAY_HAZARD_LEDGER.tsv');assert len(faults)==5 and [r['fault_id'] for r in faults]==[f'F{i:02d}' for i in range(1,6)] and all(r['accepted_state']=='ZERO_ACCEPTED' for r in faults)
mapping=rows(ROOT/'control'/'PAGE_MAP.tsv');assert len(mapping)==60 and [int(r['physical_page']) for r in mapping]==list(range(1,61)) and [int(r['printed_page']) for r in mapping]==list(range(227,287)) and all(r['source_language']=='ENGLISH' for r in mapping)
plan=rows(ROOT/'control'/'SESSION_PLAN.tsv');ranges=[(1,6),(7,12),(13,18),(19,24),(25,30),(31,36),(37,42),(43,48),(49,54),(55,60)];assert len(plan)==10 and [(int(r['physical_start']),int(r['physical_end'])) for r in plan]==ranges and all(int(r['physical_count'])==6 for r in plan) and plan[-1]['mode']=='END_TO_END_UNIT_PLUS_FRESH_NONPATCHING_COLD_AUDIT';owned=[]
for r in plan:owned.extend(range(int(r['physical_start']),int(r['physical_end'])+1))
assert owned==list(range(1,61))
coverage=rows(ROOT/'coverage'/'coverage.tsv');assert len(coverage)==60 and [int(r['physical_page']) for r in coverage]==list(range(1,61));loaded={layer:records(layer) for layer,_,_ in LAYERS};refs={layer:{} for layer,_,_ in LAYERS}
for row,mapped in zip(coverage,mapping):
 page=int(row['physical_page']);assert all(row[k]==mapped[k] for k in ('authority_pdf_page','article_page','comparator_pdf_page','printed_page','prompt_id','source_language','source_edition_action','french_translation_action','disposition'));statuses=[row['source_status'],row['french_status'],row['apparatus_status'],row['final_status']];assert all(v in ('IN_PROGRESS','COMPLETE') for v in statuses);assert row['source_frozen'] in ('TRUE','FALSE')
 if row['source_status']=='COMPLETE':assert row['source_frozen']=='TRUE'
 else:assert row['source_frozen']=='FALSE'
 if row['french_status']=='COMPLETE':assert row['source_status']=='COMPLETE' and row['source_frozen']=='TRUE'
 if row['apparatus_status']=='COMPLETE':assert row['source_status']==row['french_status']=='COMPLETE'
 assert (row['final_status']=='COMPLETE')==(row['source_status']==row['french_status']==row['apparatus_status']=='COMPLETE')
 for layer,status_col,hash_col in LAYERS:
  recs=loaded[layer]
  if row[status_col]=='COMPLETE':
   assert page in recs;rec=recs[page];assert rec['status']=='COMPLETE' and rec['source_pdf_sha256']==AUTH_SHA and int(rec['authority_pdf_page'])==page and int(rec['article_page'])==page and int(rec['printed_page'])==page+226 and rec['source_language']==row['source_language'] and rec['source_edition_action']==row['source_edition_action'] and rec['french_translation_action']==row['french_translation_action'] and rec['disposition']==row['disposition'] and row[hash_col]==canonical(rec) and str(rec['text']).strip()
  else:
   assert not row[hash_col]
   if page in recs:assert recs[page]['status']=='IN_PROGRESS'
  if page in recs:
   for asset in recs[page].get('assets',[]):refs[layer].setdefault(str(asset['id']),set()).add(page)
assets=rows(ROOT/'edition'/'asset_ledger.tsv');byid={}
for r in assets:
 aid=r['asset_id'];assert re.fullmatch(r'P\d{2}-A\d{2}',aid) and aid not in byid and r['status'] in ('IN_PROGRESS','COMPLETE');page=int(r['physical_page']);assert 1<=page<=60 and int(r['authority_pdf_page'])==page and int(r['printed_page'])==page+226
 for pkey,hkey,prefix,exts in [('raw_crop_path','raw_crop_sha256','assets/raw_crops/',('.png',)),('presentation_path','presentation_sha256','assets/presentation_derivatives/',('.png','.svg'))]:
  rel=pathlib.PurePosixPath(r[pkey]);assert not rel.is_absolute() and '..' not in rel.parts and r[pkey].startswith(prefix) and r[pkey].lower().endswith(exts);p=ROOT/pathlib.Path(*rel.parts);assert p.is_file() and sha(p)==r[hkey]
 assert r['raw_crop_path']!=r['presentation_path'] and r['extraction_parameters'].strip() and r['operations'].strip();byid[aid]=r
for layer in refs:
 for aid,pages in refs[layer].items():assert aid in byid and pages=={int(byid[aid]['physical_page'])}
subprocess.run([sys.executable,str(ROOT/'tools'/'build_readers.py'),str(ROOT),'--check'],check=True,stdout=subprocess.PIPE)
for reader in (ROOT/'readers').glob('*.html'):
 text=reader.read_text(encoding='utf-8').lower();assert 'http://' not in text and 'https://' not in text and '<script' not in text and 'pierre deligne' in text and 'kenneth a. ribet' in text
state=json.loads((ROOT/'control'/'state_schema.json').read_text(encoding='utf-8'));assert state['authors']==['Pierre Deligne','Kenneth A. Ribet'] and state['workflow_status'] in ('IN_PROGRESS','COMPLETE') and state['accepted_prior_members']==0 and state['accepted_diagram_members']==0 and state['layers']==['source_english','french_translation','apparatus']
print(json.dumps({'result':'PASS','physical_pages':60,'prompts':10,'salvage_provenance_rows':61,'salvage_unique_members':58,'diagram_members':95,'authors':['Pierre Deligne','Kenneth A. Ribet']},sort_keys=True))
