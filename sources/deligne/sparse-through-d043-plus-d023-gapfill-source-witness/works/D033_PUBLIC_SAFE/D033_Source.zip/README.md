# D033 editable source and provenance

Pierre Deligne and Kenneth A. Ribet, *Values of Abelian L-functions at Negative Integers over Totally Real Fields*, Inventiones mathematicae 59 (1980), 227–286.

The original language is English; French is a separately typeset translation. Complete authority coverage is physical pages 1–60, printed pages 227–286. The cumulative corpus remains sparse: this individual packet makes no claim about other work IDs.

`source/normalized_v1/tex/` holds the three editable LuaLaTeX editions. `witnesses/returned_v2/` holds returned material as evidence only, including preformatted readers, failed V1 disclosure, every inherited branch, source authority, comparator, and web proof. None of its inherited PASS labels supplies the independent corpus gate. The authoritative PDF is `witnesses/returned_v2/source/20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf`; SHA256 29C27A6B570E833AB6ABB2645E01F396694FAA198F715109F9307D62BA00818D.

Four exact notation repairs and omission of one unprinted diagram label are disclosed in the apparatus and repair routes. Printed source quirks remain unchanged. Repeated running heads, folios, journal logo, publisher copyright/price matter, and terminal blank remainder are excluded only from the reader prose, not from authority evidence. A fresh raw authority crop records the page19 triangle; the reader uses an editable diagram.

## Rebuild

Requirements: Python3, LuaLaTeX, STIX Two Text/Math fonts, the standard listed TeX packages, and Poppler for optional image replay. No shell escape or network installation is used by the build.

From the `source` directory:

```
python normalize_d033.py --source ../witnesses/returned_v2
python test_d033_notation.py
python compile_d033.py --engine lualatex
```

The normalizer verifies each English/French/apparatus input against its original member hash. The compiler runs two sequential passes with SOURCE_DATE_EPOCH=0 and FORCE_SOURCE_DATE=1. It writes to `normalized_v1/pdf/`; cross-platform TeX installations may differ, so the audited published PDFs and exact hashes are also retained.

For the raw page19 triangle crop, the reproducible Poppler command is:

```
pdftoppm -f 19 -l 19 -r 300 -x 700 -y 505 -W 300 -H 285 -png -singlefile ../witnesses/returned_v2/source/20_AUTHORITY_DELIGNE_RIBET_D033_IAS_60PP.pdf normalized_v1/assets/D033_p19_diagram_authority
```

`ORIGINAL_BINDINGS.json` lists every original returned member. `PUBLIC_NAME_REDACTIONS.json` identifies only exact local-account-name substitutions needed for the public derivative; untouched originals remain preserved locally. `MANIFEST.json` binds every other member's exact bytes. The ZIP uses sorted names, fixed timestamps and permissions, and is fully replayed after two byte-identical serializations. This source ZIP's outer receipt and cold audit are separate to avoid self-referential hashes.
