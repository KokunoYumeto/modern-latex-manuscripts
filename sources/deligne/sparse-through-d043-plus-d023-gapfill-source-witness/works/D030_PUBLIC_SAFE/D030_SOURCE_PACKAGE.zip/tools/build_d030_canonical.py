#!/usr/bin/env python3
"""Build structured D030 LuaLaTeX sources from the frozen page-indexed return.

The inherited records are treated as ZERO_ACCEPTED inputs.  This program does
not revise their wording: it creates normal-prose, page-addressable editions,
substitutes the certified diagram derivative for the explicit placeholder,
and produces a restrained page-by-page apparatus.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import unicodedata
from pathlib import Path


AUTHORITY_SHA256 = "6CFACB0F8742314FB9FAEB3585159BDC13C3FF6E93686E3FE0A23AD775E8B574"
COMPARATOR_SHA256 = "30C125672931928F18E6CBC1930DB1BC2920DDA1685A68C3578F2D8E2B9158A4"
ZERO_SHA256 = "7EDC48FE09334A876C29DB564C067721BFA0F813EC21FA52D1A7929CBF9A6D98"
RAW_ASSET_SHA256 = "4DB161893339B5781D6A7F1636A4C682354CB06A5A50912688538AB037978DA9"
PRESENTATION_ASSET_SHA256 = "222B3D1A4B351A59C88B1829F75D197616078965EB053F30BCB847B0908C7818"


SUPERSCRIPT_MAP = {
    "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
    "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9",
    "⁺": "+", "⁻": "-", "⁼": "=", "⁽": "(", "⁾": ")",
    "ⁿ": "n", "ᵃ": "a", "ᵈ": "d", "ᵏ": "k", "ᵗ": "t",
    "ˢ": "s", "ᐟ": "/",
}
SUBSCRIPT_MAP = {
    "₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4",
    "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9",
    "₊": "+", "₋": "-", "₌": "=", "₍": "(", "₎": ")",
}
MATH_LETTERLIKE = {
    "ℂ", "ℚ", "ℝ", "ℤ", "ℍ", "ℙ", "ℳ", "ℋ", "ℜ", "ℰ",
    "ℱ", "ℒ", "ℓ", "℘", "ℬ", "ℐ", "ℑ", "ℵ",
}
MATH_PUNCT = {"′", "″", "‴", "⟨", "⟩", "⟦", "⟧", "·", "‖"}
COMBINING_COMMAND = {
    "\u0304": "bar",
    "\u0305": "overline",
    "\u0303": "widetilde",
    "\u030c": "check",
    "\u0302": "widehat",
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def require_hash(path: Path, expected: str) -> None:
    actual = sha256_file(path)
    if actual != expected:
        raise RuntimeError(f"hash mismatch for {path.name}: {actual} != {expected}")


def read_ndjson(path: Path) -> list[dict]:
    rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]
    if len(rows) != 34:
        raise RuntimeError(f"expected 34 page records in {path.name}, found {len(rows)}")
    expected = list(range(1, 35))
    for key in ("physical_page", "authority_pdf_page", "article_page"):
        values = [int(row[key]) for row in rows]
        if values != expected:
            raise RuntimeError(f"noncanonical {key} order in {path.name}: {values}")
    if any(row.get("status") != "COMPLETE" for row in rows):
        raise RuntimeError(f"non-COMPLETE record in {path.name}")
    if any(row.get("source_pdf_sha256") != AUTHORITY_SHA256 for row in rows):
        raise RuntimeError(f"authority identity drift in {path.name}")
    return rows


def read_tsv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        return list(csv.DictReader(stream, delimiter="\t"))


def tex_metadata(text: str) -> str:
    return (text.replace("\\", "\\textbackslash{}")
            .replace("{", "\\{").replace("}", "\\}")
            .replace("%", "\\%").replace("#", "\\#").replace("&", "\\&")
            .replace("_", "\\_").replace("^", "\\textasciicircum{}"))


def is_math_cluster(base: str, marks: str) -> bool:
    cp = ord(base)
    category = unicodedata.category(base)
    return bool(
        marks
        or category == "Sm"
        or 0x0370 <= cp <= 0x03FF
        or 0x2190 <= cp <= 0x21FF
        or 0x2200 <= cp <= 0x22FF
        or 0x1D400 <= cp <= 0x1D7FF
        or base in MATH_LETTERLIKE
        or base in MATH_PUNCT
    )


def math_group(value: str) -> str:
    value = unicodedata.normalize("NFC", value)
    escaped = []
    index = 0
    while index < len(value):
        char = value[index]
        marks = []
        next_index = index + 1
        while next_index < len(value) and unicodedata.category(value[next_index]) == "Mn":
            marks.append(value[next_index])
            next_index += 1
        if marks:
            expression = char
            for mark in marks:
                command = COMBINING_COMMAND.get(mark)
                expression = ("\\" + command + "{" + expression + "}") if command else expression + mark
            escaped.append(expression)
            index = next_index
            continue
        if char in "%#$&":
            escaped.append("\\" + char)
        elif char == "\\":
            escaped.append("\\backslash")
        elif char in "{}":
            escaped.append(char)
        elif char == "~":
            escaped.append("\\sim")
        elif char.isspace():
            escaped.append("\\,")
        else:
            escaped.append(char)
        index += 1
    rendered = "".join(escaped)
    if value.isalpha() and len(value) > 1 and value.isascii():
        rendered = "\\mathrm{" + rendered + "}"
    return rendered


def consume_script(text: str, start: int) -> tuple[str, int]:
    if start >= len(text):
        return "", start
    if text[start] == "{":
        depth = 1
        index = start + 1
        out = []
        while index < len(text) and depth:
            char = text[index]
            if char == "{":
                depth += 1
                if depth > 1:
                    out.append(char)
            elif char == "}":
                depth -= 1
                if depth:
                    out.append(char)
            else:
                out.append(char)
            index += 1
        if depth:
            return "", start
        return "".join(out), index
    match = re.match(r"[A-Za-z0-9]+", text[start:])
    if match:
        return match.group(0), start + len(match.group(0))
    return text[start], start + 1


def tex_text(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    out: list[str] = []
    index = 0
    while index < len(text):
        char = text[index]
        if char in "_^":
            value, end = consume_script(text, index + 1)
            if value:
                symbol = "_" if char == "_" else "^"
                out.append("\\ensuremath{" + symbol + "{" + math_group(value) + "}}")
                index = end
                continue
            out.append("\\_" if char == "_" else "\\textasciicircum{}")
            index += 1
            continue
        if char in SUPERSCRIPT_MAP:
            values = []
            while index < len(text) and text[index] in SUPERSCRIPT_MAP:
                values.append(SUPERSCRIPT_MAP[text[index]])
                index += 1
            out.append("\\ensuremath{^{" + "".join(values) + "}}")
            continue
        if char in SUBSCRIPT_MAP:
            values = []
            while index < len(text) and text[index] in SUBSCRIPT_MAP:
                values.append(SUBSCRIPT_MAP[text[index]])
                index += 1
            out.append("\\ensuremath{_{" + "".join(values) + "}}")
            continue
        if char == "§":
            out.append("\\S{}")
            index += 1
            continue
        if char == "©":
            out.append("\\copyright{}")
            index += 1
            continue
        if char == "°":
            out.append("\\ensuremath{^{\\circ}}")
            index += 1
            continue
        if char == "□":
            out.append("\\ensuremath{□}")
            index += 1
            continue
        if char == "▶":
            out.append("\\ensuremath{▶}")
            index += 1
            continue
        if char == "▼":
            out.append("\\ensuremath{▼}")
            index += 1
            continue
        if char in "\\%$#&{}~":
            replacements = {
                "\\": "\\textbackslash{}", "%": "\\%", "$": "\\$",
                "#": "\\#", "&": "\\&", "{": "\\{", "}": "\\}",
                "~": "\\textasciitilde{}",
            }
            out.append(replacements[char])
            index += 1
            continue
        marks = []
        next_index = index + 1
        while next_index < len(text) and unicodedata.category(text[next_index]) == "Mn":
            marks.append(text[next_index])
            next_index += 1
        marks_text = "".join(marks)
        if marks_text:
            expression = char
            for mark in marks:
                command = COMBINING_COMMAND.get(mark)
                if command:
                    expression = "\\" + command + "{" + expression + "}"
                else:
                    expression += mark
            out.append("\\ensuremath{" + expression + "}")
            index = next_index
            continue
        if is_math_cluster(char, ""):
            out.append("\\ensuremath{" + char + "}")
        else:
            out.append(char)
        index += 1
    return "".join(out)


def is_diagram(paragraph: str) -> bool:
    lines = paragraph.splitlines()
    if len(lines) < 2:
        return False
    if any(char in paragraph for char in "─│║▶▼"):
        return True
    aligned_lines = sum(bool(re.search(r" {4,}", line)) for line in lines)
    return aligned_lines >= 2 and any(char in paragraph for char in "→↦⟶")


def emit_paragraph(paragraph: str, language: str, page: int) -> str:
    paragraph = paragraph.strip()
    if not paragraph:
        return ""
    if page == 7 and (
        "Diagramme reproduit par le fac-similé" in paragraph
        or "Diagram reproduced in the attached authority facsimile" in paragraph
    ):
        return (
            "\\begin{center}\n"
            "\\includegraphics[width=.82\\linewidth]{assets/P07-A01_diagram_1_3_1_presentation.png}\n"
            "\\par\\smallskip{\\small\\color{D030Muted}Diagram (1.3.1), certified presentation derivative; "
            "the lossless authority crop is retained with the sources.}\\end{center}\n"
        )
    if is_diagram(paragraph):
        return "\\begin{D030Diagram}\n" + paragraph + "\n\\end{D030Diagram}\n"
    flat = re.sub(r"\s*\n\s*", " ", paragraph)
    if flat.startswith(("INSTITUT ", "SCHOOL OF ", "DEPARTMENT OF ")):
        return "\\begin{flushright}\\small " + tex_text(flat) + "\\end{flushright}\n"
    alpha_count = sum(char.isalpha() for char in flat)
    upper_count = sum(char.isupper() for char in flat)
    has_math_signal = any(unicodedata.category(char) == "Sm" for char in flat)
    claim_prefix = re.match(
        r"^(EXEMPLE|EXAMPLE|PROPOSITION|PROOF|DÉMONSTRATION|THÉORÈME|THEOREM|"
        r"LEMME|LEMMA|DÉFINITION|DEFINITION|COROLLAIRE|COROLLARY|REMARQUE|REMARK)\b",
        flat,
    )
    if len(flat) <= 110 and alpha_count >= 5 and not has_math_signal and not claim_prefix and upper_count >= alpha_count * 0.72:
        return "\\section*{" + tex_text(flat) + "}\n"
    section = re.match(r"^([0-9]+\.\s+[^.!?]{2,72}\.)\s+(.*)$", flat, flags=re.DOTALL)
    if section:
        return "\\SectionLead{" + tex_text(section.group(1)) + "} " + tex_text(section.group(2)) + "\\par\n"
    lead_words = (
        "EXEMPLE", "EXAMPLE", "PROPOSITION", "PROOF", "DÉMONSTRATION",
        "THÉORÈME", "THEOREM", "LEMME", "LEMMA", "DÉFINITION", "DEFINITION",
        "COROLLAIRE", "COROLLARY", "REMARQUE", "REMARK",
    )
    claim = re.match(r"^(" + "|".join(lead_words) + r")(\s+[^.]{0,45}\.)\s+(.*)$", flat, flags=re.DOTALL)
    if claim:
        return "\\ClaimLead{" + tex_text(claim.group(1) + claim.group(2)) + "} " + tex_text(claim.group(3)) + "\\par\n"
    return tex_text(flat) + "\\par\n"


def preamble(title: str, subject: str, running: str) -> str:
    return rf"""\documentclass[10pt,twoside]{{article}}
\pdfvariable suppressoptionalinfo 767
\pdfvariable minorversion 7
\pdfvariable compresslevel 9
\pdfvariable objcompresslevel 0
\usepackage{{fontspec}}
\usepackage{{unicode-math}}
\setmainfont{{Libertinus Serif}}[Ligatures=TeX]
\setsansfont{{Libertinus Sans}}
\setmonofont{{Noto Sans Mono}}[Scale=MatchLowercase]
\setmathfont{{Libertinus Math}}
\usepackage[a4paper,inner=25mm,outer=21mm,top=23mm,bottom=25mm,headheight=14pt]{{geometry}}
\usepackage{{microtype}}
\usepackage{{graphicx}}
\usepackage{{xcolor}}
\usepackage{{fancyhdr}}
\usepackage{{xurl}}
\usepackage{{hyperref}}
\usepackage{{bookmark}}
\usepackage{{longtable}}
\usepackage{{booktabs}}
\usepackage{{array}}
\usepackage{{tabularx}}
\usepackage{{fvextra}}
\definecolor{{D030Ink}}{{HTML}}{{16212B}}
\definecolor{{D030Accent}}{{HTML}}{{7A2E3A}}
\definecolor{{D030Muted}}{{HTML}}{{59636E}}
\definecolor{{D030Rule}}{{HTML}}{{CAD1D8}}
\color{{D030Ink}}
\hypersetup{{unicode=true,colorlinks=true,linkcolor=D030Accent,urlcolor=D030Accent,
  pdftitle={{{tex_metadata(title)}}},pdfauthor={{Pierre Deligne}},pdfsubject={{{tex_metadata(subject)}}},
  pdfkeywords={{D030, L-functions, periods, bilingual critical edition}}}}
\pagestyle{{fancy}}
\fancyhf{{}}
\fancyhead[LE]{{\small\color{{D030Muted}}D030 · Pierre Deligne}}
\fancyhead[RO]{{\small\color{{D030Muted}}{tex_metadata(running)}}}
\fancyfoot[C]{{\small\color{{D030Muted}}\thepage}}
\renewcommand{{\headrulewidth}}{{0.35pt}}
\renewcommand{{\footrulewidth}}{{0pt}}
\setlength{{\parindent}}{{1.25em}}
\setlength{{\parskip}}{{0.34em plus 0.08em minus 0.05em}}
\emergencystretch=2em
\newcommand{{\PageUnit}}[3]{{%
  \par\noindent\hypertarget{{record-#1}}{{}}%
  \pdfbookmark[1]{{Authority page #1 · printed #2}}{{bookmark-#1}}%
  {{\sffamily\footnotesize\color{{D030Muted}}AUTHORITY PHYSICAL #1 · PRINTED #2 · #3}}%
  \par\vspace{{0.35em}}\hrule height 0.35pt\vspace{{0.8em}}}}
\newcommand{{\SectionLead}}[1]{{\textbf{{\color{{D030Accent}}#1}}}}
\newcommand{{\ClaimLead}}[1]{{\textsc{{#1}}}}
\DefineVerbatimEnvironment{{D030Diagram}}{{Verbatim}}{{fontsize=\scriptsize,frame=single,framesep=2mm,rulecolor=\color{{D030Rule}},breaklines=true,breakanywhere=true}}
\begin{{document}}
"""


def cover(title: str, subtitle: str, language_note: str) -> str:
    return rf"""\thispagestyle{{empty}}
\begin{{center}}
\vspace*{{0.16\textheight}}
{{\sffamily\small\color{{D030Accent}}PIERRE DELIGNE · D030}}\par\vspace{{1.2em}}
{{\Huge\bfseries {tex_text(title)}}}\par\vspace{{1.1em}}
{{\Large P. Deligne}}\par\vspace{{2.1em}}
{{\large\itshape {tex_text(subtitle)}}}\par\vfill
\begin{{minipage}}{{0.78\textwidth}}\small\color{{D030Muted}}
34 authority pages (printed pages 313--346). {tex_text(language_note)}
The text is organized in exact authority-page units; repeated proceedings copy matter is excluded and documented in the separate apparatus.
\end{{minipage}}
\vspace*{{0.10\textheight}}
\end{{center}}
\clearpage
\thispagestyle{{plain}}
\section*{{Edition note}}
This maintenance edition is a source-checked, math-typeset reconstruction keyed one-to-one to the controlling 34-page authority scan. The comparator is retained for comparison only. The Koblitz--Ogus appendix on authority pages 31--34 is source-English in both language editions. Page-unit markers preserve the authority and printed-page topology. The certified image fallback for diagram (1.3.1) is embedded at its exact page unit, with both the lossless crop and presentation derivative retained in the source package.
\clearpage
"""


def build_reader(rows: list[dict], title: str, subtitle: str, language_note: str, running: str, language: str) -> str:
    output = [preamble(title, subtitle, running), cover(title, subtitle, language_note)]
    for index, row in enumerate(rows):
        if index:
            output.append("\\clearpage\n")
        zone = row["source_language_zone"].replace("_", " ")
        output.append(f"\\PageUnit{{{row['physical_page']}}}{{{row['printed_page']}}}{{{tex_metadata(zone)}}}\n")
        paragraphs = re.split(r"\n\s*\n", row["text"])
        if index == 0 and len(paragraphs) >= 2:
            paragraphs = paragraphs[2:]
        for paragraph in paragraphs:
            output.append(emit_paragraph(paragraph, language, int(row["physical_page"])))
    output.append("\\end{document}\n")
    return "".join(output)


def build_apparatus(rows: list[dict], page_map: list[dict[str, str]]) -> str:
    title = "D030 Editorial Apparatus and Page Topology"
    output = [preamble(title, "Authority, topology, exclusions, and textual audit", "Editorial apparatus")]
    output.append(r"""\thispagestyle{empty}
\begin{center}
\vspace*{0.15\textheight}
{\sffamily\small\color{D030Accent}PIERRE DELIGNE · D030}\par\vspace{1em}
{\Huge\bfseries Editorial Apparatus}\par\vspace{0.8em}
{\Large Authority · topology · exclusions · textual audit}\par\vfill
\begin{minipage}{0.82\textwidth}\small\color{D030Muted}
This apparatus binds the 34 physical authority pages to printed pages 313--346, records copy-matter exclusions, distinguishes the comparison witness, and identifies the embedded source-English Koblitz--Ogus appendix. It does not silently amend either language edition.
\end{minipage}
\vspace*{0.12\textheight}
\end{center}
\clearpage
\section*{Controlling identities}
\begin{description}
\item[Authority.] IAS scan, 34 pages; SHA-256 \nolinkurl{6CFACB0F8742314FB9FAEB3585159BDC13C3FF6E93686E3FE0A23AD775E8B574}.
\item[Comparator.] Collected-paper witness, comparison only, 34 pages; SHA-256 \nolinkurl{30C125672931928F18E6CBC1930DB1BC2920DDA1685A68C3578F2D8E2B9158A4}.
\item[Prior work.] Exact inherited ZERO\_ACCEPTED carrier; SHA-256 \nolinkurl{7EDC48FE09334A876C29DB564C067721BFA0F813EC21FA52D1A7929CBF9A6D98}.
\item[Image fallback.] Lossless authority crop \nolinkurl{4DB161893339B5781D6A7F1636A4C682354CB06A5A50912688538AB037978DA9}; presentation derivative \nolinkurl{222B3D1A4B351A59C88B1829F75D197616078965EB053F30BCB847B0908C7818}.
\end{description}
\section*{Copy-matter rule}
Repeated proceedings headers, repeated folios/bylines, scan-edge black bands, neighboring-article slivers, and terminal blank remainder are excluded from the reader text. Publication citation, classifications, and copyright notice are retained here. The article proper and the source-English appendix are included in full.
\section*{Topology overview}
\small
""")
    for row in page_map:
        marker = tex_text(row["topology_marker"])
        zone = tex_text(row["source_language_zone"].replace("_", " "))
        output.append(
            f"\\noindent\\textbf{{Physical {row['physical_page']} · printed {row['printed_page']} · "
            f"{tex_metadata(row['prompt_id'])}}} \\textsf{{{zone}}}. {marker}\\par\\smallskip\n"
        )
    output.append("\\normalsize\n\\clearpage\n\\section*{Page-by-page apparatus}\n")
    for row in rows:
        physical = int(row["physical_page"])
        output.append(
            f"\\subsection*{{Authority physical {physical} · printed {row['printed_page']}}}\n"
            f"\\noindent\\textsf{{Zone: {tex_metadata(row['source_language_zone'].replace('_', ' '))}}}\\par\n"
            + tex_text(row["text"]) + "\\par\n"
        )
    output.append(r"""\clearpage
\section*{Mandatory literality and mathematics gates}
The independent gate checks the opening Zagier sentence for $L_3/L_4$ (not $L_3/L_5$), the exact French phrase “dû à Grothendieck,” diagram (1.3.1), the determinant-line $\delta$ passage, $\Gamma(f)≔\pi^{-k}\prod_a\Gamma(\langle a\rangle)^{f(a)}$, $\Gamma(f)^n=\Gamma(nf)$, and the six accented section headings. The appendix by N. Koblitz and A. Ogus is attributed only to the appendix; it is not promoted into the main-paper byline.
\end{document}
""")
    return "".join(output)


def copy_checked(source: Path, destination: Path, expected: str) -> None:
    require_hash(source, expected)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    require_hash(destination, expected)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    returned = root / "work" / "s06_unpacked"
    outer = root / "work" / "returned_outer_unpacked"
    source_dir = root / "source"
    canonical = root / "canonical"
    source_dir.mkdir(parents=True, exist_ok=True)
    canonical.mkdir(parents=True, exist_ok=True)

    inputs = {
        "source_language.ndjson": returned / "edition" / "source_language.ndjson",
        "english_standalone.ndjson": returned / "edition" / "english_standalone.ndjson",
        "apparatus.ndjson": returned / "edition" / "apparatus.ndjson",
        "coverage.tsv": returned / "coverage" / "coverage.tsv",
        "PAGE_MAP.tsv": returned / "control" / "PAGE_MAP.tsv",
        "asset_ledger.tsv": returned / "edition" / "asset_ledger.tsv",
    }
    for name, source in inputs.items():
        shutil.copyfile(source, source_dir / name)

    authority = returned / "source" / "20_AUTHORITY_DELIGNE_D030_L_VALUES_PERIODS_IAS_34PP.pdf"
    comparator = returned / "comparison" / "21_COMPARATOR_DELIGNE_D030_L_VALUES_PERIODS_COLLECTED_34PP.pdf"
    zero = returned / "salvage" / "30_ZERO_ACCEPTED_DEDUP_PRIOR_WORK_DELIGNE_D030.zip"
    raw_asset = returned / "assets" / "raw_crops" / "P07-A01_diagram_1_3_1_authority_raw.png"
    presentation_asset = returned / "assets" / "presentation_derivatives" / "P07-A01_diagram_1_3_1_presentation.png"
    copy_checked(authority, canonical / "D030_AUTHORITY_IAS_34PP.pdf", AUTHORITY_SHA256)
    copy_checked(comparator, canonical / "D030_COMPARATOR_COMPARISON_ONLY_34PP.pdf", COMPARATOR_SHA256)
    copy_checked(raw_asset, canonical / "assets" / "P07-A01_diagram_1_3_1_authority_raw.png", RAW_ASSET_SHA256)
    copy_checked(presentation_asset, canonical / "assets" / "P07-A01_diagram_1_3_1_presentation.png", PRESENTATION_ASSET_SHA256)
    copy_checked(zero, root / "ZERO_ACCEPTED" / "prior" / zero.name, ZERO_SHA256)

    terminal_zip = outer / "session_trios" / "S06" / "DELIGNE_D030_L_VALUES_PERIODS_S06_CUMULATIVE_FULL_STATE.zip"
    terminal_destination = root / "ZERO_ACCEPTED" / "terminal" / terminal_zip.name
    terminal_destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(terminal_zip, terminal_destination)

    source_rows = read_ndjson(inputs["source_language.ndjson"])
    english_rows = read_ndjson(inputs["english_standalone.ndjson"])
    apparatus_rows = read_ndjson(inputs["apparatus.ndjson"])
    page_map = read_tsv(inputs["PAGE_MAP.tsv"])
    coverage = read_tsv(inputs["coverage.tsv"])
    if len(page_map) != 34 or [int(row["physical_page"]) for row in page_map] != list(range(1, 35)):
        raise RuntimeError("PAGE_MAP.tsv does not contain exact physical pages 1--34")
    if len(coverage) != 34 or [int(row["physical_page"]) for row in coverage] != list(range(1, 35)):
        raise RuntimeError("coverage.tsv does not contain exact physical pages 1--34")

    fr_tex = build_reader(
        source_rows,
        "Valeurs de fonctions L et périodes d’intégrales",
        "Édition source française contrôlée",
        "The main paper is French; the embedded Koblitz--Ogus appendix is reproduced in its source English.",
        "Édition source française",
        "fr",
    )
    en_tex = build_reader(
        english_rows,
        "Values of L-functions and periods of integrals",
        "Standalone English edition",
        "The French main paper is translated into English; the embedded Koblitz--Ogus appendix is replayed in its source English.",
        "Standalone English edition",
        "en",
    )
    apparatus_tex = build_apparatus(apparatus_rows, page_map)
    (source_dir / "D030_SOURCE_FR.tex").write_text(fr_tex, encoding="utf-8", newline="\n")
    (source_dir / "D030_EN.tex").write_text(en_tex, encoding="utf-8", newline="\n")
    (source_dir / "D030_APPARATUS.tex").write_text(apparatus_tex, encoding="utf-8", newline="\n")
    coverage_by_page = {int(row["physical_page"]): row for row in coverage}
    with (source_dir / "D030_PAGE_TOPOLOGY.tsv").open("w", encoding="utf-8", newline="\n") as stream:
        stream.write(
            "physical_page\tauthority_pdf_page\tprinted_page\tprompt_id\tsource_language_zone\t"
            "source_pdf_page\tenglish_pdf_page\tdisposition\tcopy_matter_exclusion\t"
            "source_record_sha256\tenglish_record_sha256\tapparatus_record_sha256\n"
        )
        for row in page_map:
            physical = int(row["physical_page"])
            frozen = coverage_by_page[physical]
            canonical_page = physical + 2
            stream.write(
                f"{physical}\t{row['authority_pdf_page']}\t{row['printed_page']}\t{row['prompt_id']}\t"
                f"{row['source_language_zone']}\t{canonical_page}\t{canonical_page}\t{row['disposition']}\t"
                f"{row['copy_matter_exclusion']}\t{frozen['source_record_sha256']}\t"
                f"{frozen['english_record_sha256']}\t{frozen['apparatus_record_sha256']}\n"
            )

    manifest_rows = []
    for path in sorted(source_dir.rglob("*")):
        if path.is_file() and path.name != "SOURCE_INPUT_MANIFEST.tsv":
            manifest_rows.append((path.relative_to(root).as_posix(), path.stat().st_size, sha256_file(path)))
    with (source_dir / "SOURCE_INPUT_MANIFEST.tsv").open("w", encoding="utf-8", newline="\n") as stream:
        stream.write("path\tbytes\tsha256\n")
        for rel, size, digest in manifest_rows:
            stream.write(f"{rel}\t{size}\t{digest}\n")

    print(json.dumps({
        "status": "SOURCE_GENERATED",
        "source_records": len(source_rows),
        "english_records": len(english_rows),
        "apparatus_records": len(apparatus_rows),
        "page_map_rows": len(page_map),
        "source_dir": str(source_dir),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
