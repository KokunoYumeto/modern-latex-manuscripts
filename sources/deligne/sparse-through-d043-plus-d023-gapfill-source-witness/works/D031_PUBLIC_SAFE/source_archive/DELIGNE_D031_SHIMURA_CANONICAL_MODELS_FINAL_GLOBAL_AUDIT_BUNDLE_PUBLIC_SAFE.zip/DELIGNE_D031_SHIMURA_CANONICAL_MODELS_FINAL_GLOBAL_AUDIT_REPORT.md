# Final global audit report — DELIGNE D031

## Scope

This audit covers the complete supplied work, Pierre Deligne, *Variétés de Shimura: interprétation modulaire et techniques de construction de modèles canoniques*: all 43 physical pages, printed pages 247–289; the frozen diplomatic French; the standalone English translation; the restrained apparatus; the page map, coverage ledger, provenance ledgers, state metadata, checkpoint, manifests, and deterministic packaging.

The publication header's pp. 247–290 claim remains a recorded discrepancy. Both exact witnesses contain 43 pages and end at printed page 289. No page 290 was created.

## Independent audit procedure

1. Reopened the exact S08 trio and compared each member byte-for-byte with the individual deliverables.
2. Recomputed every external and internal SHA-256 receipt and verified all 20 state members.
3. Extracted the full state in a clean workspace and reran its embedded validator.
4. Repackaged the state twice with its embedded deterministic packager and reproduced the original S08 full-state hash exactly.
5. Repackaged the S08 trio twice with fixed metadata and reproduced the original trio bundle byte-for-byte.
6. Audited the 43-entry physical/printed page map, all French and English page records, all 43 coverage rows, and all 130 apparatus entries.
7. Compared the two language layers structurally and mathematically: 23 native tikz-cd diagrams per language, 36 tagged displays per language, and 141 numbered structural/result lead-ins per language. Diagram code and numbering sequences agree across the two editions.
8. Rechecked fault gates F01–F04 and terminal matter, including Corollary 2.7.21, bibliography items 1–13, Exposé 389, the SGA line, the IHÉS address, blank remainder, and EOF.
9. Compiled both exact Markdown editions through a clean XeLaTeX smoke-test pipeline after only mechanical adaptation of display wrappers. Both compiled without errors; all diagrams rendered.
10. Performed a headless visual pass over eight authority contact sheets covering all 43 pages, seven French-reader render contact sheets, and seven English-reader render contact sheets. Opening, middle, end, diagrams, tables, bibliography, terminal address, and EOF were legible with no clipped or broken content.

## Results

- State validator: **PASS**.
- Workflow state: **COMPLETE**.
- Accepted units: **43 / 43**.
- Completed prompts: **8 / 8**.
- State members: **20 / 20**, all hashes verified.
- Page map: **physical 1–43 ↔ printed 247–289**, continuous and one-to-one.
- French page records: **43 / 43 COMPLETE**.
- English page records: **43 / 43 COMPLETE**.
- Apparatus coverage: **43 / 43 pages**, **130 COMPLETE entries**.
- Native diagrams: **23 French + 23 English**, exact cross-language code agreement.
- Tagged displays: **36 French + 36 English**, exact numbering agreement.
- Numbered structural/result lead-ins: **141 French + 141 English**, exact sequence agreement.
- Mandatory fault gates F01–F04: **PASS**.
- Bibliography: **13 items**, with item 5 correctly reading **Exposé 389**.
- Page 290: **ABSENT — DO NOT INVENT**.
- Deterministic S08 full-state hash reproduction: **PASS**.
- Deterministic S08 trio hash reproduction: **PASS**.

## Fix disposition

No additional source, translation, apparatus, mapping, or packaging defect was found in this independent global audit. The S08 content is therefore retained byte-for-byte.

The audit explicitly reconfirmed the two English-layer fixes already incorporated during S08:

1. Physical page 34 / printed 280: sentence punctuation is outside display (2.5.1.1), so the display matches the frozen French and authority.
2. Physical page 41 / printed 287: the superscript 0 is present in $\pi_0(M^0_{\overline{\mathbf Q}}(G,X))$, while the immediately following source-local projection from $M_{\overline{\mathbf Q}}(G,X)$ remains without that superscript.

## Final disposition

**PASS — COMPLETE — FINAL CONSOLIDATED STATE.**

The final audit bundle contains the exact S08 full-state ZIP, checkpoint JSON, manifest TSV, this report, the machine-readable audit receipt, and the audit manifest.

## Certified S08 hashes

- Full-state ZIP: `1825E1089B2896F571BDA2AE4E845EED5D81FC05FC6E280192C80ECC2F7EDF64`
- Checkpoint JSON: `91148E16A4C5D72ACE447E8F1EED2CF6BF71AD0DB8D6095023FC05A2648E8930`
- Manifest TSV: `B140CAE2C24874A71BE75AC9B0116DE4C600D1223A0F08BF2121CC9D02899159`
- Original S08 trio bundle: `87F4E6C24EDB34808E9F0461576E7CEE41AA410E833EF58999ADE0905F4D0554`
