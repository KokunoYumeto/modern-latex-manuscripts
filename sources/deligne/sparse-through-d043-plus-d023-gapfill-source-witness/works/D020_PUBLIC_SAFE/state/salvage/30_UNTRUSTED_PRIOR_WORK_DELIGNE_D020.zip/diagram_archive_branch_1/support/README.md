# Deligne_Diagram_Witness_Aid_D001_D020_20260608

Purpose: zoomed source-image witnesses for Deligne diagrams/visual objects.

Source authority: per-paper and per-letter PDFs under `C:/Users/Floris/Documents/Papors/OS/Deligne`.
Naming follows the current Deligne lane convention: `D###` for papers and `L###` for letters.

Detection render DPI: 220. Crop render DPI: 340.
The detector is intentionally overinclusive: extra formula/table-like visual objects are acceptable; missing arrow/topology witnesses are not.

Use `Idx/diagram_witness_manifest.csv` or `.jsonl` for stable IDs, source page numbers, crop boxes, and hashes.
Use `Contact/*.jpg` for quick visual triage. Use `Images/*/*.png` for detailed checking.

Total crops: 1978.
