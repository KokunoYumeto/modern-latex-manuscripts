# **LA CONJECTURE DE WEIL. I**

### *par* PI~RR~ DELIGNE

#### SOMMAIRE

|  | [. La thdorie de Grothendieck : interpr6tation cohomologique de fonctions L | 273 |
|--|-----------------------------------------------------------------------------|-----|
|  | 2. La th6orle de Grothendieck : dualit6 de Poincar6                         | 28o |
|  | 3. La majoration fondamentale                                               | 283 |
|  | 4. La th6orie de Lefschetz : th6orie locale                                 | 287 |
|  | 5. La th6orie de Lefschetz 9 th6orie globale                               | 289 |
|  | 6. Un th6or~me de rationalitd                                               | 294 |
|  | 7- Fin de la d6monstration de (I.7)                                         | 298 |
|  | 8. Premi&res applications                                                   | 3or |

Dans cet article, je d6montre la conjecture de Well sur les valeurs propres des endomorphismes de Frobenius. Un ~nonc~ precis est donn~ en (I. 6). J'ai tent6 de presenter la dfimonstration sous une forme aussi g6om6trique et 616mentaire que possible et j'ai inclus force rappels : seuls sont originaux les r6sultats des w167 3,6, 7 et 8.

Dans un article faisant suite ~ celui-ci, je donnerai divers raffinements des r~sultats interm6diaires, et des applications, parmi lesquelles le th~or~me de Lefschetz ~< difficile >> (sur les cup-produits it~r~s par la classe de cohomologie d'une section hyperplane).

Le texte suit fid~lement celui de six conferences donn~es ~t Cambridge enjuillet 1973. Je remercie N. Katz de m'avoir permis d'utiliser ses notes.

#### **z. La thLr~orie de Grothendieck : interpretation cohomologique de fonctions L.**

(x. z) Soient X un schdma de type fini sur Z, IX[ l'cnsemble des points fermds de X et, pour xe[ X I, soit N(x) le nombrc d'61dments du corps rdsiduel *k(x)* de X en x. La fonction z~ta de Hasse-Weil de X est

$$(\mathbf{r}.\mathbf{r}.\mathbf{r})$$
  $\zeta_{\mathbf{X}}(s) = \prod_{x \in [X]} (\mathbf{r} - \mathbf{N}(x)^{-s})^{-1}$ 

(ce produit converge absolument pour #~(s) assez grand). Pour X=Spec(Z), ~x(S) est la fonction zdta de R.iemann.

Nous consid6rerons exclusivement le cas off X est un sch6ma sur un corps fini Fq.

Pour x lX], nous dcrirons q, plut6t que N(x). Posant *deg(x)----[k(x):Fq],*  q,\_ qd~g(,). II y a intdr~t h introduire la variable t----q-'. Posons on a

(1.1.2) 
$$Z(X; t) = \prod_{x \in |X|} (1 - t^{\deg(x)})^{-1};$$

ce produit infini converge pour It[ assez petit, et on a

(1.1.3) 
$$\zeta_{X}(s) = Z(X; q^{-s}).$$

(z.2) Dwork (On the rationality of the zeta function of an algebraic variety, *Amer. J. Math.,* 82, I96O , p. 631-648 ) et Grothendieck ([i] et SGA5) ont ddmontrd que Z(X, t) est une fonction rationnelle de t.

Pour Grothendieck, c'est I~ un corollaire de r~sultats gfndraux en cohomologie t-adique (g d6signe un nombre premier diffdrent de la caractfiristique p de Fq). Ceux-ci fournissent une interprdtation cohomologique des zdros et des p61es de Z(X; t), et une dquation fonctionnelle lorsque X est propre et lisse. Les m~thodes de Dwork sont p-adiques. Pour X une hypersurface non singuli~re dans l'espaee projectif, elles lui fournissaient 6galement une interpr6tation cohomologique des z6ros et des p61es, et l'dquation fonctionneIle. Elles ont inspir6 la thdorie cristalline de Grothendieck et Berthelot, qui pour X propre et lisse fournit une interprftation cohomologique p-adique des z6ros et p61es, et l'dquation fonctionnelle. Se basant sur des idles de Waslmitzer, Lubkin a crdd une variante de cette thdorie, valable seulement pour X propre, lisse et relevable en caractdristique z6ro (A p-adic proof of Weil's conjectures, *Ann. of Math.,* 87, 1968 , p. I O5-255 ).

Nous ferons un usage essentiel des rdsuhats de Grothendieck, et les rappelons ci-dessous.

- (x. 3) Soit X une vari6t6 alg6brique sur un corps alg~briquement clos k de caract~ ristique p, i.e. un sch~ma s~par~ de type fini sur k. On n'exclut pas le cas p = o. Pour tout nombre premier t+p, Grothendieck a d6fini des groupes de cohomologie g-adiques Hi( X, Qt). II a aussi ddfini des groupes de cohomologie k support propre H~c(X, O.~t). Pour X propre, les deux coincident. Les H~(X, Qt) sont des espaces vectoriels de dimension finie sur Qt, nuls pour i>2 dim(X).
- (x.4) Soient X 0 une vari~t~ alg6brique sur Fq, Fq une cl6ture alg~brique de Fq et X la vari~t~ alg6brique sur Fq d6duite de X0 par extension des scalaires de Fq \$ Fq. Dans le langage de Weil ou Shimura, on exprimerait cette situation par : << Soit X une varidtd alg6brique ddfinie sur Fq >>. Soit F : X~X le morphisme de Frobenius; il envoie le point de coordonn~es x vers le point de coordonnfies xq; en d'autres termes, pour U0 un ouvert de Zariski de X0, d~finissant un ouvert U de X, on a F-I(U)=U; pour xEH~ @), on a F\*x=xL Identifions l'ensemble IX[ des points ferm~s de X ~ Xo(Fq) (l'ensemble Homyq(Spec(F~), X0) des points de Xo ~t coefficients dans Fe), et soit

 $\varphi \in \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  la substitution de Frobenius :  $\varphi(x) = x^q$ . L'action de F sur |X| s'identifie à l'action de  $\varphi$  sur  $X_0(\overline{\mathbf{F}}_q)$ . Dès lors :

- a) L'ensemble  $X^F$  des points fermés de X fixes sous F s'identifie à l'ensemble  $X_0(\mathbf{F}_q) \subset X_0(\widetilde{\mathbf{F}}_q)$  des points de X définis sur  $\mathbf{F}_q$ . Ceci exprime simplement que, pour  $x \in \overline{\mathbf{F}}_q$ , on a  $x \in \mathbf{F}_q \Rightarrow x^q = x$ .
- b) De même, l'ensemble  $X^{F^n}$  des points fermés de X fixes sous le  $n^{\text{tème}}$  itéré de F s'identifie à  $X_n(F_{n^n})$ .
- c) L'ensemble  $|X_0|$  des points fermés de  $X_0$  s'identifie à l'ensemble  $|X|_F$  des orbites de F (ou de  $\varphi$ ) dans |X|. Le degré deg(x) de  $x \in |X_0|$  est le nombre d'éléments de l'orbite correspondante.
  - d) De b) et c) résulte la formule

(1.4.1) 
$$\#X^{\mathbf{F}^n} = \#X_0(\mathbf{F}_{q^n}) = \sum_{\text{deg}(x) \mid n} \deg x$$

(pour  $x \in |X_0|$  et  $\deg(x) | n$ , x définit  $\deg(x)$  points à coordonnées dans  $\mathbf{F}_{q^n}$ , tous conjugués sur  $\mathbf{F}_q$ ).

(1.5) Le morphisme F est fini, en particulier propre. Il induit donc des applications  $F^*: H^i(X, \mathbf{Q}_d) \to H^i(X, \mathbf{Q}_d).$ 

Grothendieck a prouvé la formule de Lefschetz

$$\#X^{F} = \sum_{i} (-1)^{i} \operatorname{Tr}(F^{\bullet}, H_{c}^{i}(X, \mathbf{Q}_{l}));$$

le membre de droite, a priori un nombre  $\ell$ -adique, est entier, et égal au membre de gauche. On notera qu'une telle formule n'est raisonnable que parce que dF = 0, même à l'infini (X n'est pas supposé propre); la relation dF = 0 implique que les points fixes de F sont de multiplicité un.

Une formule analogue vaut pour les itérés de F:

$$(\mathbf{1.5.1}) \hspace{1cm} \# \mathbf{X}^{\mathbf{F}^n} = \# \mathbf{X_0}(\mathbf{F_{\ell^n}}) = \sum_i (-1)^i \, \mathrm{Tr}(\mathbf{F}^{*n}, \, \mathbf{H}^i_c(\mathbf{X}, \, \mathbf{Q}_{\ell})).$$

Prenons la dérivée logarithmique de (1.1.2) :

$$\begin{aligned} (\mathbf{I}.\mathbf{5.2}) \qquad t \frac{d}{dt} \log Z(\mathbf{X}_0, t) &= \frac{t \frac{d}{dt} Z(\mathbf{X}_0, t)}{Z(\mathbf{X}_0, t)} = \sum_{x \in |\mathbf{X}_*|} - \frac{-\deg(x) t^{\deg(x)}}{1 - t^{\deg(x)}} \\ &= \sum_{x \in |\mathbf{X}_*|} \sum_{n > 0} \deg(x) t^{n, \deg(x)} = \sum_{(1.4.1)} \frac{\sum_{n \neq x} \# \mathbf{X}_0(\mathbf{F}_{q^n}) \cdot t^n}{(1.4.1)} \end{aligned}$$

Pour F un endomorphisme d'un espace vectoriel V, on a une identité de séries formelles

$$(\mathbf{1.5.3}) \qquad \qquad t \frac{d}{dt} \log(\det(\mathbf{1} - \mathbf{F}t, \mathbf{V})^{-1}) = \sum_{n>0} \mathrm{Tr}(\mathbf{F}^n, \mathbf{V})t^n$$

(le vérifier pour  $\dim(V)=1$ , et observer que les deux membres sont additifs en V dans une suite exacte courte). Substituant (1.5.1) dans (1.5.2) et appliquant (1.5.3), on trouve

$$t\frac{d}{dt}\log Z(\mathbf{X_0},t) = \sum_i (-1)^i t\frac{d}{dt}\log \det(1-\mathbf{F}^*t,\mathbf{H}_c^i(\mathbf{X},\mathbf{Q}_t))^{-1},$$

soit

(1.5.4) 
$$Z(X_0, t) = \prod_{i} \det(I - F^*t, H_c^i(X, \mathbf{Q}_t))^{(-1)^{i+1}}.$$

Le membre de droite est un élément de  $\mathbf{Q}_{I}(t)$ . La formule affirme que son développement de Taylor en t=0, a priori une série formelle dans  $\mathbf{Q}_{I}[[t]]$  de terme constant un, est dans  $\mathbf{Z}[[t]]$ , et est égal au membre de gauche, lui aussi considéré comme une série formelle en t. Cette formule est l'interprétation cohomologique de Grothendieck de la fonction Z.

Notre résultat principal est le suivant.

Théorème (1.6). — Soit  $X_0$  une variété projective non singulière (= lisse) sur  $\mathbf{F}_q$ . Pour chaque i, le polynôme caractéristique  $\det(t, \mathbf{I} - \mathbf{F}^*, \mathbf{H}^i(\mathbf{X}, \mathbf{Q}_\ell))$  est à coefficients entiers indépendants de  $\ell$  ( $\ell + p$ ). Les racines complexes  $\alpha$  de ce polynôme (les conjugués complexes des valeurs propres de  $\mathbf{F}^*$ ) sont de valeur absolue  $|\alpha| = q^{i2}$ .

Montrons déjà que (1.6) résulte du résultat apparemment plus faible suivant.

Lemme (1.7). — Pour chaque i, et chaque  $l \neq p$ , les valeurs propres de l'endomorphisme  $F^*$  de  $H^i(X, \mathbf{Q}_l)$  sont des nombres algébriques dont tous les conjugués complexes  $\alpha$  sont de valeur absolue  $|\alpha| = q^{i/2}$ .

Preuve de  $(1.7) \Rightarrow (1.6)$ . — Regardons  $Z(X_0, t)$  comme une série formelle de terme constant 1, élément de  $\mathbf{Z}[[t]]: Z(X_0, t) = \sum\limits_n a_n t^n$ . D'après (1.5.3), l'image de  $Z(X_0, t)$  dans  $\mathbf{Q}_t[[t]]$  est le développement de Taylor d'une fraction rationnelle. Ceci signific que pour N et M assez grands  $(\geq les degrés des numérateurs et dénominateurs) les déterminants de Hankel$ 

$$H_k = \det((a_{i+j+k})_{0 \le i, j \le M})$$
  $(k \ge N)$ 

sont nuls. Cette nullité est vraie dans  $\mathbf{Q}_t$  si et seulement si elle l'est dans  $\mathbf{Q}_t$ ;  $\mathbf{Z}(\mathbf{X}_0,t)$  est donc le développement en série de Taylor d'un élément de  $\mathbf{Q}(t)$ . En d'autres termes,

$$Z(X_0, t) \in \mathbb{Z}[[t]] \cap \mathbb{Q}_t(t) \subset \mathbb{Q}(t).$$

Écrivons  $Z(X_0, t) = P/Q$ , avec P,  $Q \in Z[t]$ , premiers entre eux, et de terme constant positif. D'après un lemme de Fatou, que  $Z(X_0, t)$  soit dans Z[[t]] et de terme constant un implique que les termes constants de P et Q sont 1. Posons

$$P_i(t) = \det(\mathbf{1} - \mathbf{F}^{\bullet}t, \mathbf{H}^i(\mathbf{X}, \mathbf{Q}_{\bullet})).$$

D'apr~s l'hypoth~se (I.7) , les Pi sont premiers entre eux. Le membre de droite de (I.5.4) est done sous forme irr6ductible, et

$$P(t) = \prod_{i \text{ impair}} P_i(t)$$

$$\mathbf{Q}(t) = \prod_{i \text{ pair}} \mathbf{P}_i(t).$$

Soit K le sous-corps d'une cl6ture alg6brique Qt de Qt engendr6 sur O par les racines de R(t) = P(t)O(t). Les racines de P~(t) sont celles des racines de R(t) ayant la proprift6 que tous leurs conjugu6s complexes sont de valeur absolue q-~t2. Cet ensemble est stable sous Gal(K/Q). Le polyn6me P~(t) est donc k coefficients rationnels. D'aprbs le lemme de Gauss (ou parce que les racines de Pi, 6tant racines de R,(t), sont des inverses d'entiers alg6briques), il est m~me ~t coefficients entiers. La description ci-dessus des racines de P~(t) est ind6pendante de [; le polyn6me P~(t) lui-mdme est donc ind6pendant de L

La suite de cet article est consacrde ~t la d6monstration de (z.7).

- (x.8) La th~orie de Grothendieck fournit une interpr6tation cohomologique non seulement de fonctions z~ta, mais encore de fonctions L. Les r6sultats sont les suivants.
- (x.9) Soit X une varidt6 algdbrique sur un corps k. Pour la d6finition d'un Q.t-faisceau constructible sur X, je renvoie k SGA 5 VI. Qu'il suffise de dire que:
- *a)* Si ~" est un O\_..t-faisceau construetible sur X, il existe une partition finie de X en parties localement ferm6es X~. telles que ~.~-[X i. soit constant tordu.
- *b)* Supposons X connexe et soit ~ un point gdom6trique de X. Pour ~" constant tordu, rq(X, k-) agit sur la fibre ~,~; le foncteur fibre en ~-est une 6quivalenee de cat6gorie (Qt-faisceaux constructibles constants tordus sur X)

(repr6sentations continues de n~(X, k) sur un Q.t-espace vectoriel de dimension finie).

Une telle repr6sentation ne se factorise pas, en g6n6ral, & travers un quotient fini de l(X,

*c)* Si k =C, les O~t-faisceaux eonstructibles sur X s'identifient aux faisceaux de Qt-espaces vectoriels o~" sur X an, tels qu'il existe une partition finie de X en parties Zariski-localement fermdes X~., et pour chaque i un systSme local de Zt-Modules libres de type fini ~ sur X~., avec

$$\mathscr{F} \mid \mathbf{X}_i = \mathscr{F}_i \otimes_{\mathbf{Z}_\ell} \mathbf{Q}_\ell$$

Nous ne consid6rerons que des Q.t-faiseeaux constructibles, et les appellerons simplement Qt-faisceaux.

(I. IO) Supposons k alg6briquement clos, et soit o~" un Q.t-faisceau sur X. Grothendieck a d6fini des groupes de cohomologie /-adique HI(X, ~-) et H~(X, o,~'). Les Hie(X, o~-) sont des espaces vectoriels de dimension finie sur Qt, nuls pour i>2 dim(X).

Pour k=13, les tI'(X, o~) ct II{(X, o~-) sont les groupes de cohomologie usuels (resp. support propre) de X \*=, ~ coefficients dans o~-.

(I, II ) Soient X 0 une varifitd algdbrique sur u X la varidt~ sur Fq correspondante, et o~-0 un faisceau d'ensembles sur X 0 (pour la topologie dtale). On note o~- son image r~ciproque sur X. Outre le morphisme de Frobenius F : X~X, on dispose alors d'un isomorphisme canonique F" :F'o~--%o~'. En voici une description. On regarde o~ 0 comme un espace ~tal~ sur X0, i.e. on identifie ~0 ~ l'espace algdbrique [~o], muni d'un morphisme dtale f: [o~'0]-+X0, tel que o~o soit le faisceau des sections locales de [~0]. L'espace analogue [~-], dtald sur X, se ddduit de Ion0] par extension des scalaires. On dispose done d'un diagramme commutatif

$$\begin{bmatrix} \mathscr{F} \end{bmatrix} \xrightarrow{\mathsf{F}} \begin{bmatrix} \mathscr{F} \end{bmatrix} \\
\iota \downarrow & \qquad \downarrow \iota \\
\mathsf{X} \xrightarrow{\mathsf{F}} \mathsf{X}$$

&off un morphisme [.~] ~X• [F'o~], qui est un isomorphisme car fest ~tale. Son inverse d6finit l'isomorphisme lv'o~'~o ~- cherchfi.

Cette construction se gdn~ralise aux Q,t-faiseeaux.

(x. I2) Soient X 0 une vari6td alg~brique sur Fq, ~0 un Qt-faisceau sur X0, (X, ~-) d6duit de (X0,~0) par extension des scalaires de Fe ~ Fe, F : X~X et F" : F\*~--+o~-. Le morphisme fini F et F" d6finissent un endomorphisme

$$F^{\bullet}: H^{\bullet}_{e}(X, \mathscr{F}) \to H^{\bullet}_{e}(X, F^{\bullet}\mathscr{F}) \to H^{\bullet}_{e}(X, \mathscr{F}).$$

Pour x~iX], F" d5finit un morphisme F," :~.(~)--+.~. Pour *x~X F,* c'est un endomorphlsme de ~. Grothcndieck a ddmontrs la formulc de Lefschetz

$$\sum_{x \in X'} \operatorname{Tr}(F_x^*, \mathscr{F}_z) = \sum_i (-1)^i \operatorname{Tr}(F^*, H_\varepsilon^i(X, \mathscr{F})).$$

Une formule analogue vaut pour les it~r~s de F : le n i~m' it~rd de F\* d6finit des morphismes F;" :o~'~(~1-+~; pour x fixe sous F", ~" est un endomorphisme, et

$$(\mathbf{1}.\mathbf{12},\mathbf{1}) \qquad \qquad \sum_{x \in X^{t^n}} \operatorname{Tr}(F_x^{\bullet n},\mathscr{F}_x) = \sum_i (-1)^i \operatorname{Tr}(F^{\bullet n},H^i_o(X,\mathscr{F})).$$

(i.i3) Soient *Xoe[X* 0l, Z l'orbitc correspondante de F dans IX Iet xEZ. L'orbite Z a deg(xo) ~I~ments (i.4). On note F~. l'endomorphisme F~ '~(~') de ~, et on pose

$$\det(\mathbf{I} - \mathbf{F}_{x_0}^* t, \mathscr{F}_0) = \det(\mathbf{I} - \mathbf{F}_{x_0}^* t, \mathscr{F}_z).$$

A isomorphisme pros, (o~,, F~.) ne ddpend pas du choix de x. Ceci justifie d'omettre x de la notation. On utilisera une notation analogue pour d'autres fonctions de (o~, F~.). (1.14) Définissons  $Z(X_0, \mathcal{F}_0, t) \in \mathbb{Q}_{\ell}[[t]]$  par le produit

$$(\mathbf{1}.\mathbf{14}.\mathbf{1}) \hspace{1cm} Z(X_0, \mathscr{F}_0, t) = \prod_{x \in [X, 1]} \det(\mathbf{1} - F_x^* t^{\deg(x)}, \mathscr{F}_0)^{-1}.$$

Pour  $\mathscr{F}$  le faisceau constant  $\mathbb{Q}_{\ell}$ , on retrouve (1.1.2). D'après (1.5.3), la dérivée logarithmique de Z est

$$(\mathbf{I.14.2}) \qquad \qquad t\frac{d}{dt}\log \mathbf{Z}(\mathbf{X_0},\mathscr{F_0},t) = \frac{t\frac{d}{dt}\mathbf{Z}(\mathbf{X_0},\mathscr{F_0},t)}{\mathbf{Z}(\mathbf{X_0},\mathscr{F_0},t)} = \sum_{n} \sum_{x \in \mathbf{X}^{p_n} = \mathbf{X_0}(\mathbf{F_0}^{n_n})} \mathrm{Tr}(\mathbf{F}_x^{n_n},\mathscr{F_0})t^n.$$

Substituant (1.12.1) dans (1.14.2), on trouve par le même calcul qu'en (1.5) la généralisation suivante de (1.5.4)

(1.14.3) 
$$Z(X_0, \mathscr{F}_0, t) = \prod_i \det(I - F^*t, H_c^i(X, \mathscr{F}))^{(-1)^{i+1}}$$

Cette formule est une identité dans  $\mathbf{Q}_{t}[[t]]$ .

(1.15) Il est parfois commode d'utiliser un langage galoisien plutôt que géométrique. Voici le dictionnaire.

Si  $\overline{\mathbf{F}}_q^t$  et  $\overline{\mathbf{F}}_q^2$  sont deux clôtures algébriques de  $\mathbf{F}_q$ ,  $(\mathbf{X}_0,\mathscr{F}_0)$  sur  $\mathbf{F}_q$  définit par extension des scalaires  $(\mathbf{X}_1,\mathscr{F}_1)$  sur  $\overline{\mathbf{F}}_q^t$  et  $(\mathbf{X}_2,\mathscr{F}_2)$  sur  $\overline{\mathbf{F}}_q^t$ . Tout  $\mathbf{F}_q$ -isomorphisme  $\sigma:\overline{\mathbf{F}}_q^t \xrightarrow{\sim} \overline{\mathbf{F}}_q^t$  induit un isomorphisme

$$H^{\scriptscriptstyle\bullet}_{\rm c}({\rm X}_1,\mathscr{F}_1)\stackrel{\sim}{\to} H^{\scriptscriptstyle\bullet}_{\rm c}({\rm X}_2,\mathscr{F}_2).$$

En particulier, pour  $\overline{\mathbf{F}}_q^1 = \overline{\mathbf{F}}_q^2$  (noté  $\overline{\mathbf{F}}_q$ ), on trouve que  $\operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  agit sur  $\mathbf{H}_c(\mathbf{X}, \mathscr{F})$  (action par transport de structure). Soit  $\varphi \in \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  la substitution de Frobenius. On vérifie que

$$F^* = \varphi^{-1}$$
 (dans  $End(H^*(X, \mathcal{F}))$ ).

Ceci amène à définir le Frobenius géométrique  $\mathbf{F} \in \mathrm{Gal}(\widetilde{\mathbf{F}}_q/\mathbf{F}_q)$  comme étant  $\phi^{-1}$ . On a  $(\mathbf{1}.\mathbf{15}.\mathbf{1})$   $\mathbf{F}^* = \mathbf{F}.$ 

Soit x un point géométrique de  $X_0$ , localisé en  $x_0 \in |X_0|$ . Par transport de structure, le groupe  $\operatorname{Gal}(k(x)/k(x_0))$  agit sur la fibre  $(\mathscr{F}_0)_x$  de  $\mathscr{F}_0$  en x; en particulier, le Frobenius géométrique relatif à  $k(x_0): F_{x_0} \in \operatorname{Gal}(k(x)/k(x_0))$ , agit. Pour x défini par un point fermé, encore noté x, de X, on a  $\mathscr{F}_x = (\mathscr{F}_0)_x$ , et

$$(\mathbf{1.15.2}) \qquad \qquad \mathbf{F}_{x_{\bullet}}^{\bullet} = \mathbf{F}_{x}^{\bullet \deg(x_{\bullet})} = \mathbf{F}_{x_{\bullet}} \quad \text{(dans End}(\mathscr{F}_{x})).$$

En notations galoisiennes, (1.14.3) s'écrit

$$\prod_{x \in \{X_n\}} \det(\mathbf{I} - \mathbf{F}_x t^{\deg(x)}, \mathscr{F}_0)^{-1} = \prod_i \det(\mathbf{I} - \mathbf{F}t, \mathbf{H}_i^i(\mathbf{X}, \mathscr{F}))^{(-1)^{i+1}}.$$

## **2. La th6orie de Grothendieck : dualit6 de Poincar6.**

- (2. x) Pour expliquer la relation entre racines de l'unit6 et orientations, je vais au pr6alable redire dans un langage farfelu deux cas classiques.
- a) *Varigtgs diffgrentiables. --* Soit X une varift6 diffdrentiable purement de dimension n. Le faisceau d'orientation Z' sur X est le faisceau localement isomorphe au faisceau constant Z, dont les sections inversibles sur un ouvert U de X correspondent aux orientations de U. Une *orientation* de X est un isomorphisme de Z' sur le faisceau constant Z. La *classefondamentale* de X est un morphisme Tr : H2(X, Z')---~Z; si X est orientde, il s'identifie ~t un morphisme Tr :H2(X, Z)-+Z. La dualit6 de Poincar6 s'exprime l'aide de la classe fondamentale.
- b) *Varidtgs complexes. --* Soit C une cl6ture alg6brique de R. Une varidt6 alg6brique complexe lisse, ou plut6t la vari6t6 diff6rentiable sous-jacente, est toujours orientable. Pour l'orienter, il suffit d'orienter C lui-m6me. Ceci revient au choix :
  - *a) ~t* choisir l'une des deux racines de l'6quation X2=--I; on l'appelle +i;
- *b) ~t* choisir un isomorphisme de R/Z avec Ut={z~C[ [z] =I}; +iest l'image de 1/4;
- *c) ~t* choisir l'un des deux isomorphismes x~exp(-t-2rdx) de *Q/Z* sur le groupe des racines de l'unit6 de C, qui se prolonge par continuit6 en un isomorphisme de *R/Z*  sur U ~.

On note Z(I) un Z-module libre de rang un dont l'ensemble ~t deux 616ments des gdn6rateurs soit en correspondance canonique avec Fun des ensembles ~t deux 616 ments *a), b), c).* Le plus simple est de prendre Z(1)=Ker(exp : C-->C\*). Au g6n6 rateur y==E2ni correspond l'isomorphisme *c)* : x~exp(xy).

Soit Z(r) la puissance tensorielle r i~mo de Z(I). Si X est une varidt6 algdbrique complexe lisse purement de dimension complexe r, le faisceau d'orientation de X est le faisceau constant de valeur Z(r).

(2.2) Pour (( orienter )) les varidtds algdbriques sur k algdbriquement clos de caractdristique o, il faut choisir un isomorphisme de *Q/Z* sur le groupe des racines de l'unit6 de k. L'ensemble de ces isomorphismes est un espace principal homog&ne sous Z\* (non plus sous Z\*). Lorsqu'on s'intdresse seulement k la cohomologie l-adique, il suffit de considdrer les racines de l'unit6 d'ordre une puissance de l, et de supposer la caractdristique p de k diffdrente de/. On note Z/t~(x) le groupe des racines de l'unit6 de k d'ordre divisant ln. Pour n variable, les Z/g"(i) forment un syst6me projectif, d'applications de transition les

$$\sigma_{m,n}: \mathbf{Z}/\ell^m(\mathbf{I}) \to \mathbf{Z}/\ell^n(\mathbf{I}): x \mapsto x^{\ell^{m-n}}.$$

On pose Zt(I)=lim proj Z/g"(1) et *Qt(I)=Zt(I)|* On note *Qt(r)* la puissance tensorielle r i~m" de Qt(I); pour r~Z, r ndgatif, on pose encore *Qt(r)=Qt(-r) v.* 

En tant qu'espace vectoriel sur Q,t, Qt(I) est isomorphe ~ Qt. Toutefois le groupe des automorphismes de k agit non trivialement sur Qt(1) : il agit *via* le caract6re valeurs dans Z~ qui donne son action sur les racines de l'unit6. En particulier, si k =Fq, la substitution de Frobenius ? *:x~x q* agit par multiplication par q.

Soit X une vari6t6 alg6brique lisse purement de dimension n sur k. Le *faisceau d'orientation* de X en cohomologie r est le Qt-faisceau constant *Qt(n).* La *classe fondamentale* est un morphisme

$$\operatorname{Tr}: \operatorname{H}^{2n}_{\operatorname{c}}(X, \mathbf{Q}_{\ell}(n)) \to \mathbf{Q}_{\ell},$$

soit encore

$$\operatorname{Tr}: \operatorname{H}^{2n}_{c}(X, \mathbf{Q}_{\ell}) \to \mathbf{Q}_{\ell}(-n).$$

*Thdor~me (2.3)* (dualit6 de Poincar6). -- *Pour X propre et lisse purement de dimension n, la forme bilingaire* 

$$\operatorname{Tr}(x \cup y) : \operatorname{H}^{i}(X, \mathbf{Q}_{i}) \otimes \operatorname{H}^{2n-i}(X, \mathbf{Q}_{i}) \to \mathbf{Q}_{i}(-n)$$

*est une dualitd parfaite (elle identifie* H'(X, *Qt) au dual de* H2"-i(X, *Qt(n)) ).* 

- (2.4) Soient X 0 une vari~t6 alg~brique propre et lisse sur Fq, purement de dimension n, et X sur Fq ddduit de X 0 par extension des scalaires. Le morphisme (2.3) est compatible ~ l'action de Gal(Fq/Fq). Si les (~) sont les valeurs propres du Frobenius g~om~trique F agissant sur Hi(X, Qt), les valeurs propres de F agissant sur H2"-I(X, Qt) sont donc les (qnxj-1).
- (2.5) Supposons pour simplifier X connexe. La d6monstration (2.4) se transpose comme suit dans un langage g6om6trique, plut6t que galoisien (cf. (I. 15) ).
- *a)* Le cup-produit met H~(X, Qt) et I-I2"-.i(X, Qt) en dualit6 parfaite ~ valeur dans H2"(X, *Q,t),* qui est de dimension un.
- *b)* Le cup-produit commute ~ l'image r6ciproque F\* par le morphisme de Frobenius F : X-+X.
- *c) Le* morphisme F est fini et de degr6 q" : sur H2n(X, Q,t), F\* est la multiplication par *q".* 
  - *d)* Les valeurs propres de F\* ont donc Ia propridtd (2.4)-
- (2.6) On pose x(X)=~. (--I) i dim HI(X, Qt)- Sin est impair, la forme Tr(xuy) sur H"(X, Qt) est alternde; l'cntier nz(X ) est donc toujours pair. On d~duit facilement de (1.5.4) et de (2.3), (2.4) que

$$Z(X_0, t) = \varepsilon.q^{\frac{-n\chi(X)}{2}}.t^{-\chi(X)}.Z(X_0, q^{-n}t^{-1})$$

off ~----+ I. Sin est pair, notons N la multiplicit6 de la valeur propre *q"/Z* de F\* agissant sur Hn(X, Qt) (i.e. la dimension du sous-espace propre g6ndralis6 correspondant). On a

$$\epsilon = \begin{cases} 1 & \text{si } n \text{ est impair} \\ (-1)^{N} & \text{si } n \text{ est pair.} \end{cases}$$

C'est l~t la formulation de Grothendieck de l'6quation fonctionnelle des fonctions Z.

(2.7) Nous aurons besoin d'autres formes du th6or6me de dualit6. Le cas des courbes nous suffirait dans celles-ci. Si ~" est un Q,t-faisceau sur une vari6t6 algfbrique X sur k alg6briquement clos, nous noterons o~-(r) le t~aisceau *3~| ).* Ce faisceau est (non canoniquement) isomorphe ~t ~'.

*TMor~me (2.11). -- Supposons X lisse purement de dimension net ~" constant tordu. Soit ~ le dual de o ~'. La forme bilingaire* 

$$\operatorname{Tr}(x \cup y) : \operatorname{H}^{i}(X, \mathscr{F}) \otimes \operatorname{H}^{2n-i}_{c}(X, \mathscr{F}^{\sim}(n)) \to \operatorname{H}^{2n}_{c}(X, \mathscr{F} \otimes \mathscr{F}^{\sim}(n)) \to \operatorname{H}^{2n}_{c}(X, \mathbf{Q}_{l}(n)) \to \mathbf{Q}_{l}$$
 est une dualité parfaite.

(2.9) Supposons X connexe ct soit x un point ferm6 de X. Le foncteur o~-~" z cst une 6quivalence de la catfgorie dcs Qt-faisccaux constants tordus avcc celle des repr6sentations g-adiques de ~x(X, *x). Via* cette 6quivalence, H~ #') s'identifie aux invariants de rq(X, x) agissant dans ~ :

$$(2.9.1)$$

D'apr6s (2.8), pour X lisse et conncxe de dimcnsion n, on a donc

$$H^{2n}_{\varepsilon}(X, \mathscr{F}) = H^{0}(X, \mathscr{F}^{\vee}(n))^{\vee} = ((\mathscr{F}_{\varepsilon}^{\vee}(n))^{\pi_{i}(X, z)})^{\vee}.$$

La dualit6 dchangc invariants (plus grand sous-cspacc invariant) et coinvariants (plus grand quotient invariant). Cette formule se rdcrit donc

$$H_c^{2n}(X, \mathcal{F}) = (\mathcal{F}_x)_{\pi,(X,x)}(-n).$$

Nous ne l'utiliserons que pour n=I.

*Scholie (2.* xo). -- *Soient X une courbe lisse et connexe sur k algdbriquement dos, x un point de X et o~ un Q.t-faisceau constant tordu. On a fermi* 

- (i) H~ ~')= o *si X est affine.*
- (ii) H~(X, o~-)=(~),~l(x,z)(--I ).

L'assertion (i) signifie simplement que ~" n'a pas de section ~t support fini.

(2.xx) Soient X une courbe projective, lisse et connexe sur k algdbriquement clos, U un ouvcrt de X, compl6ment d'un ensemble fini S de points ferm6s de X, j Hnclusion U~-~X et ~ un Q,t-faisceau constant tordu sur U. Soit j.o~- le Q.t-faisceau constructible image directe de .,~'. Sa fibre en x~S est de rang inf6rieur ou 6gal au rang