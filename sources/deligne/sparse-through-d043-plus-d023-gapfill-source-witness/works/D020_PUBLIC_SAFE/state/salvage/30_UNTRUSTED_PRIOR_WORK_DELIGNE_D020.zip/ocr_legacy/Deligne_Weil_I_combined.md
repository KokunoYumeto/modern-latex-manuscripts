<!-- BATCH: p0001-0010 -->
# PUBLICATIONS MATHÉMATIQUES DE L'I.H.É.S.

## PIERRE DELIGNE

La conjecture de Weil : I

*Publications mathématiques de l'I.H.É.S.*, tome 43 (1974), p. 273-307 <[http://www.numdam.org/item?id=PMIHES\\_1974\\_\\_43\\_\\_273\\_0](http://www.numdam.org/item?id=PMIHES_1974__43__273_0)>

© Publications mathématiques de l'I.H.É.S., 1974, tous droits réservés.

L'accès aux archives de la revue « Publications mathématiques de l'I.H.É.S. » ([http://](http://www.ihes.fr/IHES/Publications/Publications.html) [www.ihes.fr/IHES/Publications/Publications.html](http://www.ihes.fr/IHES/Publications/Publications.html)) implique l'accord avec les conditions générales d'utilisation (<http://www.numdam.org/conditions>). Toute utilisation commerciale ou impression systématique est constitutive d'une infraction pénale. Toute copie ou impression de ce fichier doit contenir la présente mention de copyright.

![](_page_0_Picture_6.jpeg)

### LA CONJECTURE DE WEIL. I

#### par PIERRE DELIGNE

#### **SOMMAIRE**

| Ι. : | La  | théorie de | Grothendieck: interprétation cohomologique de fonctions L | 273 |
|------|-----|------------|-----------------------------------------------------------|-----|
| 2.   | La  | théorie de | Grothendieck : dualité de Poincaré                        | 280 |
| 3. Ì | La  | majoration | fondamentale                                              | 283 |
| 4.   | La  | théorie de | Lefschetz: théorie locale                                 | 287 |
| 5    | La  | théorie de | Lefschetz: théorie globale                                | 280 |
| 6.   | Un  | théorème   | de rationalité                                            | 294 |
| 7.   | Fin | de la dén  | nonstration de (1.7)                                      | 298 |
| 8.   | Pre | mières app | lications                                                 | 301 |

Dans cet article, je démontre la conjecture de Weil sur les valeurs propres des endomorphismes de Frobenius. Un énoncé précis est donné en (1.6). J'ai tenté de présenter la démonstration sous une forme aussi géométrique et élémentaire que possible et j'ai inclus force rappels : seuls sont originaux les résultats des §§ 3, 6, 7 et 8.

Dans un article faisant suite à celui-ci, je donnerai divers raffinements des résultats intermédiaires, et des applications, parmi lesquelles le théorème de Lefschetz « difficile » (sur les cup-produits itérés par la classe de cohomologie d'une section hyperplane).

Le texte suit fidèlement celui de six conférences données à Cambridge en juillet 1973. Je remercie N. Katz de m'avoir permis d'utiliser ses notes.

#### 1. La théorie de Grothendieck : interprétation cohomologique de fonctions L.

 $(\mathbf{r}.\mathbf{r})$  Soient X un schéma de type fini sur Z, |X| l'ensemble des points fermés de X et, pour  $x \in |X|$ , soit N(x) le nombre d'éléments du corps résiduel k(x) de X en x. La fonction zêta de Hasse-Weil de X est

(I.I.I) 
$$\zeta_{X}(s) = \prod_{x \in |X|} (1 - N(x)^{-s})^{-1}$$

(ce produit converge absolument pour  $\mathcal{R}(s)$  assez grand). Pour  $X = \operatorname{Spec}(\mathbf{Z})$ ,  $\zeta_X(s)$  est la fonction zêta de Riemann.

Nous considérerons exclusivement le cas où X est un schéma sur un corps fini  $\mathbf{F}_a$ .

Pour  $x \in |X|$ , nous écrirons  $q_x$  plutôt que N(x). Posant  $deg(x) = [k(x) : \mathbf{F}_q]$ , on a  $q_x = q^{deg(x)}$ . Il y a intérêt à introduire la variable  $t = q^{-s}$ . Posons

(1.1.2) 
$$Z(X;t) = \prod_{x \in |X|} (I - t^{\deg(x)})^{-1};$$

ce produit infini converge pour |t| assez petit, et on a

$$(\mathbf{I.I.3})$$
  $\zeta_{\mathbf{X}}(s) = \mathbf{Z}(\mathbf{X}; q^{-s}).$ 

(1.2) Dwork (On the rationality of the zeta function of an algebraic variety, Amer. J. Math., 82, 1960, p. 631-648) et Grothendieck ([1] et SGA 5) ont démontré que Z(X, t) est une fonction rationnelle de t.

Pour Grothendieck, c'est là un corollaire de résultats généraux en cohomologie  $\ell$ -adique ( $\ell$  désigne un nombre premier différent de la caractéristique p de  $\mathbf{F}_q$ ). Ceux-ci fournissent une interprétation cohomologique des zéros et des pôles de Z(X;t), et une équation fonctionnelle lorsque X est propre et lisse. Les méthodes de Dwork sont p-adiques. Pour X une hypersurface non singulière dans l'espace projectif, elles lui fournissaient également une interprétation cohomologique des zéros et des pôles, et l'équation fonctionnelle. Elles ont inspiré la théorie cristalline de Grothendieck et Berthelot, qui pour X propre et lisse fournit une interprétation cohomologique p-adique des zéros et pôles, et l'équation fonctionnelle. Se basant sur des idées de Washnitzer, Lubkin a créé une variante de cette théorie, valable seulement pour X propre, lisse et relevable en caractéristique zéro (X0 p-adic proof of Weil's conjectures, X1 propre, lisse et relevable en caractéristique zéro (X1 p-adic proof of Weil's conjectures, X2 propre, lisse et relevable en caractéristique zéro (X2 p-adic proof of Weil's conjectures, X3 propre et lisse et relevable en caractéristique zéro (X2 p-adic proof of Weil's conjectures, X3 propre et lisse et relevable en caractéristique zéro (X3 p-adic proof of Weil's conjectures, X4 propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse pr

Nous ferons un usage essentiel des résultats de Grothendieck, et les rappelons ci-dessous.

- (1.3) Soit X une variété algébrique sur un corps algébriquement clos k de caractéristique p, i.e. un schéma séparé de type fini sur k. On n'exclut pas le cas p=0. Pour tout nombre premier  $\ell \neq p$ , Grothendieck a défini des groupes de cohomologie  $\ell$ -adiques  $H^i(X, \mathbf{Q}_{\ell})$ . Il a aussi défini des groupes de cohomologie à support propre  $H^i_c(X, \mathbf{Q}_{\ell})$ . Pour X propre, les deux coïncident. Les  $H^i_c(X, \mathbf{Q}_{\ell})$  sont des espaces vectoriels de dimension finie sur  $\mathbf{Q}_{\ell}$ , nuls pour  $i \geq 2 \dim(X)$ .
- (1.4) Soient  $X_0$  une variété algébrique sur  $\mathbf{F}_q$ ,  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$  et X la variété algébrique sur  $\overline{\mathbf{F}}_q$  déduite de  $X_0$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ . Dans le langage de Weil ou Shimura, on exprimerait cette situation par : « Soit X une variété algébrique définie sur  $\mathbf{F}_q$  ». Soit  $F: X \to X$  le morphisme de Frobenius; il envoie le point de coordonnées x vers le point de coordonnées  $x^q$ ; en d'autres termes, pour  $U_0$  un ouvert de Zariski de  $X_0$ , définissant un ouvert U de X, on a  $F^{-1}(U) = U$ ; pour  $x \in H^0(U_0, \mathcal{O})$ , on a  $F^*x = x^q$ . Identifions l'ensemble |X| des points fermés de X à  $X_0(\overline{\mathbf{F}}_q)$  (l'ensemble  $Hom_{\overline{\mathbf{F}}_q}(\operatorname{Spec}(\overline{\mathbf{F}}_q), X_0)$  des points de  $X_0$  à coefficients dans  $\overline{\mathbf{F}}_q$ ), et soit

 $\varphi \in \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  la substitution de Frobenius :  $\varphi(x) = x^q$ . L'action de F sur |X| s'identifie à l'action de  $\varphi$  sur  $X_0(\overline{\mathbf{F}}_q)$ . Dès lors :

- a) L'ensemble  $X^F$  des points fermés de X fixes sous F s'identifie à l'ensemble  $X_0(\mathbf{F}_q) \subset X_0(\overline{\mathbf{F}}_q)$  des points de X définis sur  $\mathbf{F}_q$ . Ceci exprime simplement que, pour  $x \in \overline{\mathbf{F}}_q$ , on a  $x \in \mathbf{F}_q \Leftrightarrow x^q = x$ .
- *b)* De même, l'ensemble  $X^{F^n}$  des points fermés de X fixes sous le  $n^{\text{ième}}$  itéré de F s'identifie à  $X_0(\mathbf{F}_{\sigma^n})$ .
- c) L'ensemble  $|X_0|$  des points fermés de  $X_0$  s'identifie à l'ensemble  $|X|_F$  des orbites de F (ou de  $\varphi$ ) dans |X|. Le degré  $\deg(x)$  de  $x \in |X_0|$  est le nombre d'éléments de l'orbite correspondante.
  - d) De b) et c) résulte la formule

(1.4.1) 
$$\#X^{F^n} = \#X_0(\mathbf{F}_{q^n}) = \sum_{\deg(x)|n} \deg x$$

(pour  $x \in |X_0|$  et  $\deg(x) | n$ , x définit  $\deg(x)$  points à coordonnées dans  $\mathbf{F}_{q^n}$ , tous conjugués sur  $\mathbf{F}_q$ ).

(1.5) Le morphisme F est fini, en particulier propre. Il induit donc des applications  $F^*: H^i_c(X, \mathbf{Q}_\ell) \to H^i_c(X, \mathbf{Q}_\ell)$ .

Grothendieck a prouvé la formule de Lefschetz

$$\#X^{F} = \sum_{i} (-1)^{i} \operatorname{Tr}(F^{*}, H_{c}^{i}(X, \mathbf{Q}_{\ell}));$$

le membre de droite, a priori un nombre  $\ell$ -adique, est entier, et égal au membre de gauche. On notera qu'une telle formule n'est raisonnable que parce que dF=0, même à l'infini (X n'est pas supposé propre); la relation dF=0 implique que les points fixes de F sont de multiplicité un.

Une formule analogue vaut pour les itérés de F:

$$(\mathbf{1.5.1}) \qquad \#\mathbf{X}^{\mathbf{F}^n} = \#\mathbf{X}_0(\mathbf{F}_{q^n}) = \sum_{\ell} (-1)^i \operatorname{Tr}(\mathbf{F}^{*n}, \mathbf{H}_c^i(\mathbf{X}, \mathbf{Q}_{\ell})).$$

Prenons la dérivée logarithmique de (1.1.2):

(1.5.2) 
$$t \frac{d}{dt} \log Z(X_0, t) = \frac{t \frac{d}{dt} Z(X_0, t)}{Z(X_0, t)} = \sum_{x \in |X_0|} -\frac{-\deg(x) t^{\deg(x)}}{1 - t^{\deg(x)}}$$
$$= \sum_{x \in |X_0|} \sum_{n > 0} \deg(x) t^{n \cdot \deg(x)} = \sum_{(1.4.1)} \sum_{n} \# X_0(\mathbf{F}_{q^n}) \cdot t^n.$$

Pour F un endomorphisme d'un espace vectoriel V, on a une identité de séries formelles

$$(\mathbf{1.5.3}) \qquad t \frac{d}{dt} \log(\det(\mathbf{I} - \mathbf{F}t, \mathbf{V})^{-1}) = \sum_{n>0} \mathrm{Tr}(\mathbf{F}^n, \mathbf{V}) t^n$$

(le vérifier pour  $\dim(V)=1$ , et observer que les deux membres sont additifs en V dans une suite exacte courte). Substituant (1.5.1) dans (1.5.2) et appliquant (1.5.3), on trouve

$$t\frac{d}{dt}\log \mathbf{Z}(\mathbf{X_0},t) = \sum_{\mathbf{i}} (-\mathbf{I})^{\mathbf{i}} t\frac{d}{dt}\log \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}_c^{\mathbf{i}}(\mathbf{X}, \mathbf{Q_t}))^{-1},$$

soit

(1.5.4) 
$$Z(X_0, t) = \prod_{i} \det(I - F^*t, H_c^i(X, \mathbf{Q}_\ell))^{(-1)^{i+1}}.$$

Le membre de droite est un élément de  $\mathbf{Q}_{\ell}(t)$ . La formule affirme que son développement de Taylor en t=0, a priori une série formelle dans  $\mathbf{Q}_{\ell}[[t]]$  de terme constant un, est dans  $\mathbf{Z}[[t]]$ , et est égal au membre de gauche, lui aussi considéré comme une série formelle en t. Cette formule est l'interprétation cohomologique de Grothendieck de la fonction  $\mathbf{Z}$ .

Notre résultat principal est le suivant.

Théorème  $(\mathbf{r}.\mathbf{6})$ . — Soit  $X_0$  une variété projective non singulière (= lisse) sur  $\mathbf{F}_q$ . Pour chaque i, le polynôme caractéristique  $\det(t.\mathbf{1}-\mathbf{F}^*,\mathbf{H}^i(\mathbf{X},\mathbf{Q}_\ell))$  est à coefficients entiers indépendants de  $\ell$   $(\ell + p)$ . Les racines complexes  $\alpha$  de ce polynôme (les conjugués complexes des valeurs propres de  $\mathbf{F}^*$ ) sont de valeur absolue  $|\alpha| = q^{i/2}$ .

Montrons déjà que (1.6) résulte du résultat apparemment plus faible suivant.

Lemme (1.7). — Pour chaque i, et chaque  $\ell \neq p$ , les valeurs propres de l'endomorphisme  $F^*$  de  $H^i(X, \mathbf{Q}_{\ell})$  sont des nombres algébriques dont tous les conjugués complexes  $\alpha$  sont de valeur absolue  $|\alpha| = q^{i/2}$ .

Preuve de  $(1.7) \Rightarrow (1.6)$ . — Regardons  $Z(X_0, t)$  comme une série formelle de terme constant 1, élément de  $\mathbf{Z}[[t]]: Z(X_0, t) = \sum_{n} a_n t^n$ . D'après (1.5.3), l'image de  $Z(X_0, t)$  dans  $\mathbf{Q}_t[[t]]$  est le développement de Taylor d'une fraction rationnelle. Ceci signifie que pour N et M assez grands  $(\geq les degrés des numérateurs et dénominateurs) les déterminants de Hankel$ 

$$\mathbf{H}_{k} = \det((a_{i+i+k})_{0 < i, i < \mathbf{M}}) \qquad (k > \mathbf{N})$$

sont nuls. Cette nullité est vraie dans  $\mathbf{Q}_t$  si et seulement si elle l'est dans  $\mathbf{Q}_t$ ;  $Z(X_0, t)$  est donc le développement en série de Taylor d'un élément de  $\mathbf{Q}(t)$ . En d'autres termes,

$$Z(X_0, t) \in \mathbb{Z}[[t]] \cap \mathbb{Q}_{\ell}(t) \subset \mathbb{Q}(t).$$

Écrivons  $Z(X_0, t) = P/Q$ , avec  $P, Q \in \mathbf{Z}[t]$ , premiers entre eux, et de terme constant positif. D'après un lemme de Fatou, que  $Z(X_0, t)$  soit dans  $\mathbf{Z}[[t]]$  et de terme constant un implique que les termes constants de P et Q sont 1. Posons

$$P_{i}(t) = \det(I - F^{*}t, H^{i}(X, \mathbf{Q}_{\ell})).$$

D'après l'hypothèse (1.7), les P<sub>i</sub> sont premiers entre eux. Le membre de droite de (1.5.4) est donc sous forme irréductible, et

$$P(t) = \prod_{i \text{ impair}} P_i(t)$$

$$Q(t) = \prod_{i \text{ pair}} P_i(t).$$

Soit K le sous-corps d'une clôture algébrique  $\overline{\mathbf{Q}}_{\ell}$  de  $\mathbf{Q}_{\ell}$  engendré sur  $\mathbf{Q}$  par les racines de  $R(t) = P(t)\mathbf{Q}(t)$ . Les racines de  $P_i(t)$  sont celles des racines de R(t) ayant la propriété que tous leurs conjugués complexes sont de valeur absolue  $q^{-i/2}$ . Cet ensemble est stable sous  $Gal(K/\mathbf{Q})$ . Le polynôme  $P_i(t)$  est donc à coefficients rationnels. D'après le lemme de Gauss (ou parce que les racines de  $P_i$ , étant racines de R(t), sont des inverses d'entiers algébriques), il est même à coefficients entiers. La description ci-dessus des racines de  $P_i(t)$  est indépendante de  $\ell$ ; le polynôme  $P_i(t)$  lui-même est donc indépendant de  $\ell$ .

La suite de cet article est consacrée à la démonstration de (1.7).

- (1.8) La théorie de Grothendieck fournit une interprétation cohomologique non seulement de fonctions zêta, mais encore de fonctions L. Les résultats sont les suivants.
- $(\mathbf{r}.\mathbf{g})$  Soit X une variété algébrique sur un corps k. Pour la définition d'un  $\mathbf{Q}_{\ell}$ -faisceau constructible sur X, je renvoie à SGA 5 VI. Qu'il suffise de dire que:
- a) Si  $\mathscr{F}$  est un  $\mathbb{Q}_{\ell}$ -faisceau constructible sur X, il existe une partition finie de X en parties localement fermées  $X_{\ell}$  telles que  $\mathscr{F}|X_{\ell}$  soit constant tordu.
- b) Supposons X connexe et soit  $\bar{x}$  un point géométrique de X. Pour  $\mathscr{F}$  constant tordu,  $\pi_1(X, \bar{x})$  agit sur la fibre  $\mathscr{F}_{\bar{x}}$ ; le foncteur fibre en  $\bar{x}$  est une équivalence de catégorie ( $\mathbb{Q}_{\ell}$ -faisceaux constructibles constants tordus sur X) $\mapsto$

 $\mapsto$  (représentations continues de  $\pi_1(X, \bar{x})$  sur un  $\mathbf{Q}_{\ell}$ -espace vectoriel de dimension finie).

Une telle représentation ne se factorise pas, en général, à travers un quotient fini de  $\pi_1(X, \bar{x})$ .

c) Si  $k=\mathbb{C}$ , les  $\mathbb{Q}_{\ell}$ -faisceaux constructibles sur X s'identifient aux faisceaux de  $\mathbb{Q}_{\ell}$ -espaces vectoriels  $\mathscr{F}$  sur  $X^{an}$ , tels qu'il existe une partition finie de X en parties Zariski-localement fermées  $X_i$ , et pour chaque i un système local de  $\mathbb{Z}_{\ell}$ -Modules libres de type fini  $\mathscr{F}_i$  sur  $X_i$ , avec

$$\mathscr{F} \mid \mathbf{X}_i = \mathscr{F}_i \otimes_{\mathbf{Z}_\ell} \mathbf{Q}_\ell$$
.

Nous ne considérerons que des  $\mathbf{Q}_t$ -faisceaux constructibles, et les appellerons simplement  $\mathbf{Q}_t$ -faisceaux.

(1.10) Supposons k algébriquement clos, et soit  $\mathscr{F}$  un  $\mathbb{Q}_{\ell}$ -faisceau sur X. Grothendieck a défini des groupes de cohomologie  $\ell$ -adique  $H^{i}(X,\mathscr{F})$  et  $H^{i}_{c}(X,\mathscr{F})$ . Les  $H^{i}_{c}(X,\mathscr{F})$  sont des espaces vectoriels de dimension finie sur  $\mathbb{Q}_{\ell}$ , nuls pour i > 2 dim(X).

Pour  $k = \mathbb{C}$ , les  $H^i(X, \mathcal{F})$  et  $H^i_c(X, \mathcal{F})$  sont les groupes de cohomologie usuels (resp. à support propre) de  $X^{an}$ , à coefficients dans  $\mathcal{F}$ .

(1.11) Soient  $X_0$  une variété algébrique sur  $\mathbf{F}_q$ , X la variété sur  $\overline{\mathbf{F}}_q$  correspondante, et  $\mathscr{F}_0$  un faisceau d'ensembles sur  $X_0$  (pour la topologie étale). On note  $\mathscr{F}$  son image réciproque sur X. Outre le morphisme de Frobenius  $F: X \to X$ , on dispose alors d'un isomorphisme canonique  $F^*: F^*\mathscr{F} \to \mathscr{F}$ . En voici une description. On regarde  $\mathscr{F}_0$  comme un espace étalé sur  $X_0$ , i.e. on identifie  $\mathscr{F}_0$  à l'espace algébrique  $[\mathscr{F}_0]$ , muni d'un morphisme étale  $f: [\mathscr{F}_0] \to X_0$ , tel que  $\mathscr{F}_0$  soit le faisceau des sections locales de  $[\mathscr{F}_0]$ . L'espace analogue  $[\mathscr{F}]$ , étalé sur X, se déduit de  $[\mathscr{F}_0]$  par extension des scalaires. On dispose donc d'un diagramme commutatif

$$\begin{bmatrix} \mathscr{F} \end{bmatrix} \xrightarrow{F} \begin{bmatrix} \mathscr{F} \end{bmatrix} \\
\downarrow^{f} \\
X \xrightarrow{F} X$$

d'où un morphisme  $[\mathscr{F}] \to X \times_{(F,X,f)} [\mathscr{F}] = [F^*\mathscr{F}]$ , qui est un isomorphisme car f est étale. Son inverse définit l'isomorphisme  $F^*\mathscr{F} \to \mathscr{F}$  cherché.

Cette construction se généralise aux Q<sub>1</sub>-faisceaux.

(1.12) Soient  $X_0$  une variété algébrique sur  $\mathbf{F}_q$ ,  $\mathscr{F}_0$  un  $\mathbf{Q}_\ell$ -faisceau sur  $X_0$ ,  $(X,\mathscr{F})$  déduit de  $(X_0,\mathscr{F}_0)$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ ,  $F:X\to X$  et  $F^*:F^*\mathscr{F}\to\mathscr{F}$ . Le morphisme fini F et  $F^*$  définissent un endomorphisme

$$\mathrm{F}^*:\ \mathrm{H}^{i}_{c}(\mathrm{X},\mathscr{F})\rightarrow \mathrm{H}^{i}_{c}(\mathrm{X},\ \mathrm{F}^*\mathscr{F})\rightarrow \mathrm{H}^{i}_{c}(\mathrm{X},\mathscr{F}).$$

Pour  $x \in |X|$ ,  $F^*$  définit un morphisme  $F_x^* : \mathscr{F}_{F(x)} \to \mathscr{F}_x$ . Pour  $x \in X^F$ , c'est un endomorphisme de  $\mathscr{F}_x$ . Grothendieck a démontré la formule de Lefschetz

$$\sum_{x \in \mathbf{X}^{\mathrm{F}}} \mathrm{Tr}(\mathbf{F}_{x}^{\star}, \mathscr{F}_{x}) = \sum_{i} (-\mathbf{I})^{i} \, \mathrm{Tr}(\mathbf{F}^{\star}, \, \mathbf{H}_{c}^{i}(\mathbf{X}, \, \mathscr{F})).$$

Une formule analogue vaut pour les itérés de F: le  $n^{\text{ième}}$  itéré de  $F^*$  définit des morphismes  $F_x^{*n}: \mathscr{F}_{F_x^{n}(x)} \to \mathscr{F}_x$ ; pour x fixe sous  $F^n$ ,  $F_x^{*n}$  est un endomorphisme, et

(1.12.1) 
$$\sum_{x \in X_F^n} \operatorname{Tr}(F_x^{*n}, \mathscr{F}_x) = \sum_{i} (-1)^i \operatorname{Tr}(F^{*n}, H_c^i(X, \mathscr{F})).$$

(1.13) Soient  $x_0 \in |X_0|$ , Z l'orbite correspondante de F dans |X| et  $x \in Z$ . L'orbite Z a  $\deg(x_0)$  éléments (1.4). On note  $F_{x_0}^*$  l'endomorphisme  $F_x^{*\deg(x_0)}$  de  $\mathscr{F}_x$ , et on pose

$$\det(\mathbf{I} - \mathbf{F}_{x_0}^* t, \mathscr{F}_0) = \det(\mathbf{I} - \mathbf{F}_{x_0}^* t, \mathscr{F}_x).$$

A isomorphisme près,  $(\mathscr{F}_x, F_{x_0}^*)$  ne dépend pas du choix de x. Ceci justifie d'omettre x de la notation. On utilisera une notation analogue pour d'autres fonctions de  $(\mathscr{F}_x, F_{x_0}^*)$ .

(1.14) Définissons  $Z(X_0, \mathscr{F}_0, t) \in \mathbf{Q}_{\ell}[[t]]$  par le produit

(1.14.1) 
$$Z(X_0, \mathscr{F}_0, t) = \prod_{x \in [X_0]} \det(I - F_x^* t^{\deg(x)}, \mathscr{F}_0)^{-1}.$$

Pour  $\mathcal{F}$  le faisceau constant  $\mathbf{Q}_{l}$ , on retrouve (1.1.2). D'après (1.5.3), la dérivée logarithmique de  $\mathbf{Z}$  est

$$(\mathbf{I.14.2}) \qquad \qquad t \frac{d}{dt} \log \mathbf{Z}(\mathbf{X}_0, \mathscr{F}_0, t) \stackrel{t}{=} \frac{t \frac{d}{dt} \mathbf{Z}(\mathbf{X}_0, \mathscr{F}_0, t)}{\mathbf{Z}(\mathbf{X}_0, \mathscr{F}_0, t)} = \sum_{n} \sum_{x \in \mathbf{X}^{p^n} = \mathbf{X}_0(\mathbf{F}_q n)} \mathrm{Tr}(\mathbf{F}_x^{*n}, \mathscr{F}_0) t^n.$$

Substituant (1.12.1) dans (1.14.2), on trouve par le même calcul qu'en (1.5) la généralisation suivante de (1.5.4)

(1.14.3) 
$$Z(X_0, \mathscr{F}_0, t) = \prod_i \det(I - F^*t, H_c^i(X, \mathscr{F}))^{(-1)^{i+1}}.$$

Cette formule est une identité dans  $\mathbf{Q}_{\ell}[[t]]$ .

(1.15) Il est parfois commode d'utiliser un langage galoisien plutôt que géométrique. Voici le dictionnaire.

Si  $\overline{\mathbf{F}}_q^1$  et  $\overline{\mathbf{F}}_q^2$  sont deux clôtures algébriques de  $\mathbf{F}_q$ ,  $(\mathbf{X}_0,\mathscr{F}_0)$  sur  $\mathbf{F}_q$  définit par extension des scalaires  $(\mathbf{X}_1,\mathscr{F}_1)$  sur  $\overline{\mathbf{F}}_q^1$  et  $(\mathbf{X}_2,\mathscr{F}_2)$  sur  $\overline{\mathbf{F}}_q^2$ . Tout  $\mathbf{F}_q$ -isomorphisme  $\sigma:\overline{\mathbf{F}}_q^1 \stackrel{\sim}{\to} \overline{\mathbf{F}}_q^2$  induit un isomorphisme

$$H_c^*(X_1, \mathscr{F}_1) \stackrel{\sim}{\to} H_c^*(X_2, \mathscr{F}_2).$$

En particulier, pour  $\overline{\mathbf{F}}_q^1 = \overline{\mathbf{F}}_q^2$  (noté  $\overline{\mathbf{F}}_q$ ), on trouve que  $\operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  agit sur  $\operatorname{H}_c^*(X, \mathscr{F})$  (action par transport de structure). Soit  $\varphi \in \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  la substitution de Frobenius. On vérifie que

$$F^* = \varphi^{-1}$$
 (dans End( $H_c^*(X, \mathcal{F})$ )).

Ceci amène à définir le Frobenius géométrique  $F \in Gal(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  comme étant  $\phi^{-1}$ . On a

$$(1.15.1)$$
  $F^* = F.$ 

Soit x un point géométrique de  $X_0$ , localisé en  $x_0 \in |X_0|$ . Par transport de structure, le groupe  $Gal(k(x)/k(x_0))$  agit sur la fibre  $(\mathscr{F}_0)_x$  de  $\mathscr{F}_0$  en x; en particulier, le Frobenius géométrique relatif à  $k(x_0) : F_{x_0} \in Gal(k(x)/k(x_0))$ , agit. Pour x défini par un point fermé, encore noté x, de X, on a  $\mathscr{F}_x = (\mathscr{F}_0)_x$ , et

(1.15.2) 
$$F_{x_0}^* \stackrel{=}{\underset{dfn}{=}} F_x^{* \deg(x_0)} = F_{x_0} \quad (dans \quad End(\mathscr{F}_x)).$$

En notations galoisiennes, (1.14.3) s'écrit

$$\prod_{x \in |\mathbf{X}_{\mathbf{0}}|} \det(\mathbf{I} - \mathbf{F}_x t^{\deg(x)}, \mathscr{F}_0)^{-1} = \prod_{\mathbf{i}} \det(\mathbf{I} - \mathbf{F}t, \mathbf{H}_{\mathbf{c}}^{\mathbf{i}}(\mathbf{X}, \mathscr{F}))^{(-1)^{i+1}}.$$

#### 2. La théorie de Grothendieck : dualité de Poincaré.

- (2.1) Pour expliquer la relation entre racines de l'unité et orientations, je vais au préalable redire dans un langage farfelu deux cas classiques.
- a) Variétés différentiables. Soit X une variété différentiable purement de dimension n. Le faisceau d'orientation  $\mathbf{Z}'$  sur X est le faisceau localement isomorphe au faisceau constant  $\mathbf{Z}$ , dont les sections inversibles sur un ouvert U de X correspondent aux orientations de U. Une orientation de X est un isomorphisme de  $\mathbf{Z}'$  sur le faisceau constant  $\mathbf{Z}$ . La classe fondamentale de X est un morphisme  $\operatorname{Tr}: H^n_c(X, \mathbf{Z}') \to \mathbf{Z}$ ; si X est orientée, il s'identifie à un morphisme  $\operatorname{Tr}: H^n_c(X, \mathbf{Z}) \to \mathbf{Z}$ . La dualité de Poincaré s'exprime à l'aide de la classe fondamentale.
- b) Variétés complexes. Soit **C** une clôture algébrique de **R**. Une variété algébrique complexe lisse, ou plutôt la variété différentiable sous-jacente, est toujours orientable. Pour l'orienter, il suffit d'orienter **C** lui-même. Ceci revient au choix :
  - a) à choisir l'une des deux racines de l'équation  $X^2 = -1$ ; on l'appelle +i;
- b) à choisir un isomorphisme de  $\mathbb{R}/\mathbb{Z}$  avec  $U^1 = \{z \in \mathbb{C} \mid |z| = 1\}$ ; +i est l'image de 1/4;
- c) à choisir l'un des deux isomorphismes  $x \mapsto \exp(\pm 2\pi i x)$  de  $\mathbb{Q}/\mathbb{Z}$  sur le groupe des racines de l'unité de  $\mathbb{C}$ , qui se prolonge par continuité en un isomorphisme de  $\mathbb{R}/\mathbb{Z}$  sur  $\mathbb{U}^1$ .

On note  $\mathbf{Z}(1)$  un  $\mathbf{Z}$ -module libre de rang un dont l'ensemble à deux éléments des générateurs soit en correspondance canonique avec l'un des ensembles à deux éléments a), b), c). Le plus simple est de prendre  $\mathbf{Z}(1) = \text{Ker}(\exp : \mathbf{C} \to \mathbf{C}^*)$ . Au générateur  $y = \pm 2\pi i$  correspond l'isomorphisme c) :  $x \mapsto \exp(xy)$ .

Soit  $\mathbf{Z}(r)$  la puissance tensorielle  $r^{\text{ième}}$  de  $\mathbf{Z}(1)$ . Si X est une variété algébrique complexe lisse purement de dimension complexe r, le faisceau d'orientation de X est le faisceau constant de valeur  $\mathbf{Z}(r)$ .

(2.2) Pour « orienter » les variétés algébriques sur k algébriquement clos de caractéristique o, il faut choisir un isomorphisme de  $\mathbb{Q}/\mathbb{Z}$  sur le groupe des racines de l'unité de k. L'ensemble de ces isomorphismes est un espace principal homogène sous  $\widehat{\mathbb{Z}}^*$  (non plus sous  $\mathbb{Z}^*$ ). Lorsqu'on s'intéresse seulement à la cohomologie  $\ell$ -adique, il suffit de considérer les racines de l'unité d'ordre une puissance de  $\ell$ , et de supposer la caractéristique p de k différente de  $\ell$ . On note  $\mathbb{Z}/\ell^n(1)$  le groupe des racines de l'unité de k d'ordre divisant  $\ell^n$ . Pour n variable, les  $\mathbb{Z}/\ell^n(1)$  forment un système projectif, d'applications de transition les

$$\sigma_{m,n}: \mathbb{Z}/\ell^m(\mathbf{1}) \to \mathbb{Z}/\ell^n(\mathbf{1}): x \mapsto x^{\ell^{m-n}}.$$

On pose  $\mathbf{Z}_{\ell}(\mathbf{I}) = \lim \operatorname{proj} \mathbf{Z}/\ell^{n}(\mathbf{I})$  et  $\mathbf{Q}_{\ell}(\mathbf{I}) = \mathbf{Z}_{\ell}(\mathbf{I}) \otimes_{\mathbf{Z}_{\ell}} \mathbf{Q}_{\ell}$ . On note  $\mathbf{Q}_{\ell}(r)$  la puissance tensorielle  $r^{\text{lème}}$  de  $\mathbf{Q}_{\ell}(\mathbf{I})$ ; pour  $r \in \mathbf{Z}$ , r négatif, on pose encore  $\mathbf{Q}_{\ell}(r) = \mathbf{Q}_{\ell}(-r)^{\sim}$ .

En tant qu'espace vectoriel sur  $\mathbf{Q}_{\ell}$ ,  $\mathbf{Q}_{\ell}(1)$  est isomorphe à  $\mathbf{Q}_{\ell}$ . Toutefois le groupe des automorphismes de k agit non trivialement sur  $\mathbf{Q}_{\ell}(1)$ : il agit via le caractère à valeurs dans  $\mathbf{Z}_{\ell}^*$  qui donne son action sur les racines de l'unité. En particulier, si  $k = \overline{\mathbf{F}}_q$ , la substitution de Frobenius  $\varphi: x \mapsto x^q$  agit par multiplication par q.

Soit X une variété algébrique lisse purement de dimension n sur k. Le faisceau d'orientation de X en cohomologie  $\ell$ -adique est le  $\mathbf{Q}_{\ell}$ -faisceau constant  $\mathbf{Q}_{\ell}(n)$ . La classe fondamentale est un morphisme

Tr: 
$$H_c^{2n}(X, \mathbf{Q}_{\ell}(n)) \to \mathbf{Q}_{\ell}$$
,

soit encore

Tr: 
$$H_c^{2n}(X, \mathbf{Q}_{\ell}) \to \mathbf{Q}_{\ell}(-n)$$
.

Théorème (2.3) (dualité de Poincaré). — Pour X propre et lisse purement de dimension n, la forme bilinéaire

$$\mathrm{Tr}(x \cup y) \; : \; \mathrm{H}^{i}(\mathrm{X}, \, \mathbf{Q}_{\ell}) \otimes \mathrm{H}^{2n-i}(\mathrm{X}, \, \mathbf{Q}_{\ell}) \to \mathbf{Q}_{\ell}(-n)$$

est une dualité parfaite (elle identifie  $H^i(X, \mathbf{Q}_{\ell})$  au dual de  $H^{2n-i}(X, \mathbf{Q}_{\ell}(n))$ ).

- (2.4) Soient  $X_0$  une variété algébrique propre et lisse sur  $\mathbf{F}_q$ , purement de dimension n, et X sur  $\overline{\mathbf{F}}_q$  déduit de  $X_0$  par extension des scalaires. Le morphisme (2.3) est compatible à l'action de  $\mathrm{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$ . Si les  $(\alpha_j)$  sont les valeurs propres du Frobenius géométrique F agissant sur  $H^i(X, \mathbf{Q}_\ell)$ , les valeurs propres de F agissant sur  $H^{2n-i}(X, \mathbf{Q}_\ell)$  sont donc les  $(q^n\alpha_i^{-1})$ .
- (2.5) Supposons pour simplifier X connexe. La démonstration (2.4) se transpose comme suit dans un langage géométrique, plutôt que galoisien (cf. (1.15)).
- a) Le cup-produit met  $H^{i}(X, \mathbf{Q}_{\ell})$  et  $H^{2n-i}(X, \mathbf{Q}_{\ell})$  en dualité parfaite à valeur dans  $H^{2n}(X, \mathbf{Q}_{\ell})$ , qui est de dimension un.
- b) Le cup-produit commute à l'image réciproque  $F^*$  par le morphisme de Frobenius  $F: X \rightarrow X$ .
- c) Le morphisme F est fini et de degré  $q^n$ : sur  $H^{2n}(X, \mathbf{Q}_{\ell})$ ,  $F^*$  est la multiplication par  $q^n$ .
  - d) Les valeurs propres de F\* ont donc la propriété (2.4).
- (2.6) On pose  $\chi(X) = \sum_{i} (-1)^{i} \dim H^{i}(X, \mathbf{Q}_{\ell})$ . Si n est impair, la forme  $\operatorname{Tr}(x \cup y)$  sur  $H^{n}(X, \mathbf{Q}_{\ell})$  est alternée; l'entier  $n\chi(X)$  est donc toujours pair. On déduit facilement de (1.5.4) et de (2.3), (2.4) que

$$\mathbf{Z}(\mathbf{X}_0,\,t) = \mathbf{\varepsilon}.\,q^{\frac{-n\chi(\mathbf{X})}{2}}.\,t^{-\chi(\mathbf{X})}.\,\mathbf{Z}(\mathbf{X}_0,\,q^{-n}t^{-1})$$
<!-- BATCH: p0011-0020 -->
où  $\varepsilon = \pm 1$ . Si *n* est pair, notons N la multiplicité de la valeur propre  $q^{n/2}$  de  $F^*$  agissant sur  $H^n(X, \mathbf{Q}_{\ell})$  (i.e. la dimension du sous-espace propre généralisé correspondant). On a

$$\varepsilon = \begin{cases} \mathbf{I} & \text{si } n \text{ est impair} \\ (-\mathbf{I})^{\mathbf{N}} & \text{si } n \text{ est pair.} \end{cases}$$

C'est là la formulation de Grothendieck de l'équation fonctionnelle des fonctions Z.

(2.7) Nous aurons besoin d'autres formes du théorème de dualité. Le cas des courbes nous suffirait dans celles-ci. Si  $\mathscr{F}$  est un  $\mathbb{Q}_{\ell}$ -faisceau sur une variété algébrique X sur k algébriquement clos, nous noterons  $\mathscr{F}(r)$  le faisceau  $\mathscr{F}\otimes\mathbb{Q}_{\ell}(r)$ . Ce faisceau est (non canoniquement) isomorphe à  $\mathscr{F}$ .

Théorème (2.8). — Supposons X lisse purement de dimension n et  $\mathcal{F}$  constant tordu. Soit  $\mathcal{F}^{\sim}$  le dual de  $\mathcal{F}$ . La forme bilinéaire

$$\operatorname{Tr}(x \cup y) : \operatorname{H}^{i}(X, \mathscr{F}) \otimes \operatorname{H}^{2n-i}_{c}(X, \mathscr{F}^{\check{}}(n)) \to \operatorname{H}^{2n}_{c}(X, \mathscr{F} \otimes \mathscr{F}^{\check{}}(n)) \to \operatorname{H}^{2n}_{c}(X, \mathbf{Q}_{\ell}(n)) \to \mathbf{Q}_{\ell}$$
 est une dualité parfaite.

(2.9) Supposons X connexe et soit x un point fermé de X. Le foncteur  $\mathscr{F} \mapsto \mathscr{F}_x$  est une équivalence de la catégorie des  $\mathbb{Q}_{\ell}$ -faisceaux constants tordus avec celle des représentations  $\ell$ -adiques de  $\pi_1(X, x)$ . Via cette équivalence,  $H^0(X, \mathscr{F})$  s'identifie aux invariants de  $\pi_1(X, x)$  agissant dans  $\mathscr{F}_x$ :

(2.9.1) 
$$H^0(X, \mathscr{F}) \stackrel{\sim}{\to} \mathscr{F}_x^{\pi_1(X, x)}$$
.

D'après (2.8), pour X lisse et connexe de dimension n, on a donc

$$\mathrm{H}^{2n}_c(\mathrm{X},\mathscr{F}) = \mathrm{H}^0(\mathrm{X},\mathscr{F}\check{}(n))\check{} = ((\mathscr{F}_x\check{}(n))^{\pi_1(\mathrm{X},x)})\check{}.$$

La dualité échange invariants (plus grand sous-espace invariant) et coinvariants (plus grand quotient invariant). Cette formule se récrit donc

$$H_c^{2n}(X, \mathcal{F}) = (\mathcal{F}_x)_{\pi_1(X, x)}(-n).$$

Nous ne l'utiliserons que pour n=1.

Scholie (2.10). — Soient X une courbe lisse et connexe sur k algébriquement clos, x un point fermé de X et  $\mathcal{F}$  un  $\mathbf{Q}_t$ -faisceau constant tordu. On a

- (i)  $H_c^0(X, \mathcal{F}) = 0$  si X est affine.
- (ii)  $H_c^2(X, \mathscr{F}) = (\mathscr{F}_x)_{\pi_1(X, x)}(-1)$ .

L'assertion (i) signifie simplement que F n'a pas de section à support fini.

(2.11) Soient X une courbe projective, lisse et connexe sur k algébriquement clos, U un ouvert de X, complément d'un ensemble fini S de points fermés de X, j l'inclusion  $U \hookrightarrow X$  et  $\mathscr{F}$  un  $\mathbb{Q}_{\ell}$ -faisceau constant tordu sur U. Soit  $j_*\mathscr{F}$  le  $\mathbb{Q}_{\ell}$ -faisceau constructible image directe de  $\mathscr{F}$ . Sa fibre en  $x \in S$  est de rang inférieur ou égal au rang

de sa fibre en un point général; c'est un espace d'invariants sous un groupe de monodromie locale.

Théorème (2.12). — La forme bilinéaire  $\operatorname{Tr}(x \cup y) : \operatorname{H}^{i}(X, j_{*}\mathscr{F}) \otimes \operatorname{H}^{2-i}(X, j_{*}\mathscr{F}^{\check{}}(1)) \to \operatorname{H}^{2}(X, j_{*}\mathscr{F} \otimes j_{*}\mathscr{F}^{\check{}}(1)) \\ \to \operatorname{H}^{2}(X, j_{*}(\mathscr{F} \otimes \mathscr{F}^{\check{}})(1)) \to \operatorname{H}^{2}(X, j_{*}\mathbf{Q}_{\ell}(1)) = \operatorname{H}^{2}(X, \mathbf{Q}_{\ell}(1)) \to \mathbf{Q}_{\ell}$  est une dualité parfaite.

- (2.13) Il nous sera commode de disposer des  $\mathbf{Q}_{\ell}$ -faisceaux  $\mathbf{Q}_{\ell}(r)$  sur un quelconque schéma X où  $\ell$  est inversible. Le tout est de définir les  $\mathbf{Z}/\ell^n(1)$ . Par définition,  $\mathbf{Z}/\ell^n(1)$  est le faisceau étale des racines  $(\ell^n)^{\text{lèmes}}$  de l'unité.
  - (2.14) Indications bibliographiques sur les §§ 1 et 2.
- A) Tous les résultats importants en cohomologie étale se démontrent d'abord pour des faisceaux de torsion. L'extension aux  $\mathbf{Q}_{\ell}$ -faisceaux se fait par des passages à la limite formels. Dans ce qui suit, pour chaque théorème cité, je renverrai non point à une référence où il est démontré, mais à une référence où son analogue pour les faisceaux de torsion l'est.
- B) A l'exception de la formule de Lefschetz et de (2.12), les résultats de cohomologie étale utilisés dans cet article sont tous démontrés dans SGA 4. Pour ceux déjà énoncés, les références sont : définition des H<sup>i</sup> : VII; définition des H<sup>i</sup> : XVII 5.1; théorème de finitude : XIV 1, complété en XVII 5.3; dimension cohomologique : X; dualité de Poincaré : XVIII.
- C) La relation entre les divers Frobenius ((1.4), (1.11), (1.15)) est expliquée en détail dans SGA 5, XV, §§1, 2.
- D) L'interprétation cohomologique des fonctions Z (1.14.3) est clairement exposée dans [1]; toutefois, la formule de Lefschetz (1.12), pour X une courbe projective et lisse, y est utilisée, mais non démontrée. Pour la démonstration, il faut, hélas, renvoyer à SGA 5.
- E) La forme (2.12) du théorème de dualité de Poincaré résulte du résultat général SGA 4, XVIII (3.2.5) (pour  $S = \operatorname{Spec}(k)$ , X = X,  $K = j_* \mathscr{F}$ ,  $L = \mathbb{Q}_{\ell}$ ) par un calcul local qui n'est pas difficile. L'énoncé figurera explicitement dans la version définitive de SGA 5. Dans le cas où nous l'utiliserons (ramification de  $\mathscr{F}$  modérée), on pourrait l'obtenir par voie transcendante, en relevant X et  $\mathscr{F}$  en caractéristique o.

## 3. La majoration fondamentale.

Le résultat de ce paragraphe a été catalysé par la lecture de Rankin [3].

(3.1) Soient  $U_0$  une courbe sur  $\overline{\mathbf{F}}_q$ , complément dans  $\mathbf{P}^1$  d'un ensemble fini de points fermés, U la courbe sur  $\overline{\mathbf{F}}_q$  qui s'en déduit, u un point fermé de U,  $\mathscr{F}_0$  un  $\mathbf{Q}_\ell$ -faisceau constant tordu sur  $U_0$  et  $\mathscr{F}$  son image réciproque sur U.

Soit  $\beta \in \mathbb{Q}$ . Nous dirons que  $\mathscr{F}_0$  est de *poids*  $\beta$  si pour tout  $x \in |U_0|$ , les valeurs propres de  $F_x$  agissant sur  $\mathscr{F}_0$  (1.13) sont des nombres algébriques dont tous les conjugués complexes sont de valeur absolue  $q_x^{\beta/2}$ . Par exemple,  $\mathbb{Q}_t(r)$  est de poids -2r.

Théorème (3.2). — Faisons les hypothèses suivantes :

(i) Fo est muni d'une forme bilinéaire alternée non dégénérée

$$\psi: \mathscr{F}_0 \otimes \mathscr{F}_0 \to \mathbf{Q}_{\ell}(-\beta) \quad (\beta \in \mathbf{Z}).$$

- (ii) L'image de  $\pi_1(U,u)$  dans  $GL(\mathcal{F}_u)$  est un sous-groupe ouvert du groupe symplectique  $Sp(\mathcal{F}_u,\psi_u)$ .
  - (iii) Pour tout  $x \in |U_0|$ , le polynôme  $\det(I F_x t, \mathcal{F}_0)$  est à coefficients rationnels.

Alors, F est de poids B.

On peut supposer, et nous supposerons, que U est affine et que  $\mathscr{F} \neq 0$ .

Lemme (3.3). — Soit 2k un entier pair et notons  $\otimes \mathscr{F}_0$  la puissance tensorielle  $(2k)^{\text{ième}}$  de  $\mathscr{F}_0$ . Pour  $x \in |U_0|$ , la dérivée logarithmique

$$t\frac{d}{dt}\log(\det(\mathbf{I}-\mathbf{F}_xt^{\deg(x)},\overset{2k}{\bigotimes}\mathscr{F}_0)^{-1})$$

est une série formelle à coefficients rationnels positifs.

L'hypothèse (iii) assure que, pour tout n,  $\operatorname{Tr}(F_x^n, \mathscr{F}_0) \in \mathbb{Q}$ . Le nombre

$$\operatorname{Tr}(\mathbf{F}_{x}^{n}, \overset{2k}{\bigotimes} \mathscr{F}_{0}) = \operatorname{Tr}(\mathbf{F}_{x}^{n}, \mathscr{F}_{0})^{2k}$$

est donc rationnel positif, et on applique (1.5.3).

Lemme (3.4). — Les facteurs locaux  $\det(\mathbf{I} - \mathbf{F}_x t^{\deg(x)}, \overset{2k}{\bigotimes} \mathscr{F}_0)^{-1}$  sont des séries formelles à coefficients rationnels positifs.

La série formelle  $\log \det(\mathbf{1} - \mathbf{F}_x t^{\deg(x)}, \bigotimes^{2k} \mathscr{F}_0)^{-1}$  est sans terme constant; d'après (3.3), ses coefficients sont  $\geq 0$ ; les coefficients de son exponentielle sont donc également positifs.

Lemme (3.5). — Soit  $f_i = \sum_{n} a_{i,n} t^n$  une suite de séries formelles de terme constant un, et à coefficients réels positifs. On suppose que l'ordre de  $f_i - 1$  tend vers l'infini avec i, et on pose  $f = \prod_{i} f_i$ . Alors, le rayon de convergence absolue de  $f_i$  est au moins égal à celui de f.

Si 
$$f = \sum_{n} a_n t^n$$
, on a en effet  $a_{i,n} \le a_n$ .

Lemme (3.6). — Sous les hypothèses de (3.5), si f et les  $f_i$  sont les développements en série de Taylor de fonctions méromorphes, alors

$$\inf\{|z| | f(z) = \infty\} \le \inf\{|z| | f_i(z) = \infty\}.$$

Ces nombres sont en effet les rayons de convergence absolue.

(3.7) Pour chaque partition P de [1, 2k] en parties à deux éléments  $\{i_{\alpha}, j_{\alpha}\}$   $(i_{\alpha} < j_{\alpha})$ , on définit

$$\psi_{\mathbf{P}}: \overset{2k}{\bigotimes} \mathscr{F}_0 \to \mathbf{Q}_{\ell}(-k\beta): x_1 \otimes \ldots \otimes x_{2k} \mapsto \prod_{\alpha} \psi(x_{i_{\alpha}}, x_{j_{\alpha}}).$$

Soit x un point fermé de X. L'hypothèse (ii) assure que les coinvariants de  $\pi_1(U, u)$  dans  $\bigotimes_{u}^{2k}$  sont les coinvariants dans  $\bigotimes_{u}^{2k}$  du groupe symplectique tout entier  $(\pi_1 \text{ est Zariski-dense dans Sp})$ . Soit  $\mathscr P$  l'ensemble des partitions P. D'après H. Weyl (*The classical groups*, Princeton University Press, chap. VI,  $\S$  I), pour  $\mathscr P' \subset \mathscr P$  convenable, dépendant de dim $(\mathscr F_u)$ , les  $\psi_P$  pour  $P \in \mathscr P'$  définissent un isomorphisme

$$(\overset{2k}{\otimes}\mathscr{F}_{\!\!\!u})_{\pi_1} = (\overset{2k}{\otimes}\mathscr{F}_{\!\!\!u})_{\operatorname{Sp}} \overset{\sim}{\to} \mathbf{Q}_{\ell}(-k\beta)^{\mathscr{F}}.$$

Soit N le nombre d'éléments de P'. D'après (2.10), la formule ci-dessus donne

$$\mathrm{H}^2_c(\mathrm{U}, \overset{\mathrm{2}k}{\otimes} \mathscr{F}) \simeq \mathbf{Q}_{\ell}(-k\beta-1)^{\mathrm{N}}.$$

Puisque  $H_c^0(U, \bigotimes^{2k} \mathscr{F}) = 0$ , la formule (1.14.3) se réduit à

$$Z(\mathbf{U_0}, \overset{2k}{\bigotimes} \mathscr{F}_0, t) = \frac{\det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^1(\mathbf{U}, \overset{2k}{\bigotimes} \mathscr{F}))}{(\mathbf{I} - q^{k\beta + 1}t)^{\mathbf{N}}}.$$

Cette fonction Z est donc le développement en série de Taylor d'une fonction rationnelle n'ayant de pôle qu'en  $t=1/q^{k\beta+1}$ . Nous utiliserons seulement le fait que les pôles sont de valeur absolue  $1/q^{k\beta+1}$  dans C. Cela pourrait se déduire d'arguments généraux sur les groupes réductifs. Si  $\alpha$  est une valeur propre de  $F_x$  sur  $\mathscr{F}_0$ , alors  $\alpha^{2k}$  est une valeur propre de  $F_x$  sur  $\otimes \mathscr{F}_0$ . Notons encore  $\alpha$  un quelconque conjugué complexe de  $\alpha$ . La puissance inverse  $1/\alpha^{2k/\deg(x)}$  est un pôle de  $\det(1-F_xt^{\deg(x)}, \bigotimes \mathscr{F})^{-1}$ . D'après (3.4) et (3.6), on a donc

$$|1/q^{k\beta+1}| \le |1/\alpha^{2k/\deg(x)}|,$$
 $|\alpha| < q_x^{\frac{\beta}{2} + \frac{1}{2k}}.$ 

soit

Faisant tendre k vers l'infini, on trouve que

$$|\alpha| \leq q_x^{\beta/2}$$
.

Par ailleurs, l'existence de  $\psi$  assure que  $q_x^{\beta}$   $\alpha^{-1}$  est également valeur propre, d'où l'inégalité

$$|q_x^{\beta}\alpha^{-1}| \leq q_x^{\beta/2}$$

soit

$$q_x^{\beta/2} \leq |\alpha|$$
.

Ceci achève la démonstration.

Corollaire (3.8). — Soit  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^1_c(U, \mathscr{F})$ . Alors,  $\alpha$  est un nombre algébrique, dont tous les conjugués complexes vérifient

$$|\alpha| \leq q^{\frac{\beta+1}{2}+\frac{1}{2}}$$
.

La formule (1.14.3) pour  $\mathcal{F}_0$  se réduit à

$$Z(U_0, \mathscr{F}_0, t) = \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}_c^1(\mathbf{U}, \mathscr{F})).$$

Le premier membre est une série formelle à coefficients rationnels, vu son développement en produit et l'hypothèse (iii). Le second membre est donc un polynôme à coefficients rationnels;  $1/\alpha$  en est racine. Ceci prouve déjà que  $\alpha$  est algébrique. Pour achever la démonstration, il suffit de vérifier que le produit infini qui définit  $Z(U_0, \mathscr{F}_0, t)$  converge

absolument (donc est non nul) pour  $|t| < q^{\frac{-\beta}{2}-1}$ .

Soit N le rang de F, et posons

$$\det(\mathbf{I} - \mathbf{F}_x t, \mathscr{F}) = \prod_{i=1}^{N} (\mathbf{I} - \alpha_{i,x} t).$$

D'après (3.2),  $|\alpha_{i,x}| = q_x^{\beta/2}$ . La convergence du produit infini Z résulte de celle de la série

$$\sum_{i,x} |\alpha_{i,x} t^{\deg(x)}|.$$

Pour  $|t|=q^{\frac{-\beta}{2}-1-\epsilon}$  ( $\epsilon > 0$ ), on a

$$\sum_{i,x} |\alpha_{i,x} t^{\deg(x)}| = N \sum_{x} q_x^{-1-\varepsilon}.$$

Sur la droite affine, il y a  $q^n$  points à valeurs dans  $\mathbf{F}_{q^n}$ , donc au plus  $q^n$  points fermés de degré n. On a donc

$$\sum_{x} q_{x}^{-1-\varepsilon} \leq \sum_{n} q^{n} \cdot q^{n(-1-\varepsilon)} = \sum_{n} q^{-n\varepsilon} < \infty,$$

ce qui achève la démonstration.

Corollaire (3.9) — Soient  $j_0$  l'inclusion de  $U_0$  dans  $\mathbf{P}_{\mathbf{F}_q}^1$ , j celle de U dans  $\mathbf{P}^1$ , et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^1(\mathbf{P}^1, j_*\mathscr{F})$ . Alors  $\alpha$  est un nombre algébrique, dont tous les conjugués complexes vérifient

$$q^{\frac{\beta+1}{2}-\frac{1}{2}} \leq |\alpha| \leq q^{\frac{\beta+1}{2}+\frac{1}{2}}.$$

Un segment de la suite longue de cohomologie définie par la suite exacte courte

$$0 \rightarrow j_! \mathcal{F} \rightarrow j_* \mathcal{F} \rightarrow j_* \mathcal{F} / j_! \mathcal{F} \rightarrow 0$$

 $(j_1 = \text{prolongement par o})$  s'écrit

$$\mathrm{H}^1_c(\mathrm{U},\mathscr{F}) \to \mathrm{H}^1(\mathbf{P}^1,j_*\mathscr{F}) \to \mathrm{o.}$$

La valeur propre  $\alpha$  apparaît donc déjà dans  $H_c^1(U, \mathcal{F})$ , et est justiciable de (3.8):

$$|\alpha| \leq q^{\frac{\beta+1}{2}+\frac{1}{2}}.$$

La dualité de Poincaré (2.12) assure que  $q^{\beta+1}\alpha^{-1}$  est également valeur propre, d'où l'inégalité  $|q^{\beta+1}\alpha^{-1}| < q^{\frac{\beta+1}{2}+\frac{1}{2}}$ 

et le corollaire.

## 4. La théorie de Lefschetz : théorie locale.

(4.1) Sur C, les résultats locaux de Lesschetz sont les suivants.

Soient  $D = \{z \mid |z| \le 1\}$  le disque unité,  $D^* = D - \{0\}$ , et  $f: X \to D$  un morphisme d'espaces analytiques. On suppose que

- a) X est non singulier, et purement de dimension n+1;
- b) f est propre;
- c) f est lisse en dehors d'un point x de la fibre spéciale  $X_0 = f^{-1}(0)$ ;
- d) en x, f présente un point quadratique non dégénéré.

Soient  $t \neq 0$  dans D et  $X_t = f^{-1}(t)$  « la » fibre générale. Aux données précédentes, on associe :

 $\alpha$ ) des morphismes de spécialisation  $sp: H^i(X_0, \mathbf{Z}) \to H^i(X_t, \mathbf{Z})$ :  $X_0$  est un rétracte par déformation de X, et sp est la flèche composée

$$H^{i}(X_{0}, \mathbf{Z}) \stackrel{\sim}{\leftarrow} H^{i}(X, \mathbf{Z}) \rightarrow H^{i}(X_{t}, \mathbf{Z});$$

β) des transformations de monodromie  $T: H^i(X_t, \mathbf{Z}) \to H^i(X_t, \mathbf{Z})$ , qui décrivent l'effet sur les cycles singuliers de  $X_t$  de « faire tourner t autour de o ». C'est encore l'action sur  $H^i(X_t, \mathbf{Z})$ , fibre en t du système local  $R^i f_* \mathbf{Z} | D^*$ , du générateur positif de  $\pi_1(D^*, t)$ .

La théorie de Lefschetz décrit  $\alpha$ ) et  $\beta$ ) en terme du cycle évanescent  $\delta \in H^n(X_t, \mathbb{Z})$ . Ce cycle est bien défini au signe près. Pour  $i \neq n, n+1$ , on a

$$H^i(X_0, \mathbf{Z}) \stackrel{\sim}{\to} H^i(X_t, \mathbf{Z}) \quad (i \neq n, n+1).$$

Pour i=n, n+1, on a une suite exacte

$$0 \to H^n(X_0, \mathbf{Z}) \to H^n(X_t, \mathbf{Z}) \xrightarrow{x \mapsto (x, \delta)} \mathbf{Z} \to H^{n+1}(X_0, \mathbf{Z}) \to H^{n+1}(X_t, \mathbf{Z}) \to 0.$$

Pour  $i \neq n$ , la monodromie T est l'identité. Pour i = n, on a

$$Tx = x \pm (x, \delta)\delta$$
.

Les valeurs de ce  $\pm$ , de T $\delta$ , et de  $(\delta, \delta)$  sont les suivantes :

| $n \mod 4$                     | 0         | I | 2         | 3 |
|--------------------------------|-----------|---|-----------|---|
| $Tx = x \pm (x, \delta)\delta$ |           |   | +         | + |
| $(\delta, \delta)$             | 2         | O | 2         | o |
| Тδ                             | $-\delta$ | 8 | $-\delta$ | δ |

La transformation de monodromie T respecte la forme d'intersection  $\operatorname{Tr}(x \cup y)$  sur  $H^n(X_t, \mathbf{Z})$ . Pour n impair, c'est une transvection symplectique. Pour n pair, c'est une symétrie orthogonale.

(4.2) Voici l'analogue de (4.1) en géométrie algébrique abstraite. Le disque D est remplacé par le spectre d'un anneau de valuation discrète hensélien A à corps résiduel algébriquement clos. Soient S ce spectre,  $\eta$  son point générique (spectre du corps des fractions de A), s son point fermé (spectre du corps résiduel). Le rôle de t est joué par un point générique géométrique  $\overline{\eta}$  (spectre d'une clôture algébrique du corps des fractions de A).

Soit  $f: X \to S$  un morphisme propre, avec X régulier purement de dimension n+1. On suppose f lisse, sauf pour un point quadratique ordinaire x dans la fibre spéciale  $X_s$ . Soit  $\ell$  un nombre premier différent de la caractéristique résiduelle p de S. Notant  $X_{\bar{\eta}}$  la fibre générique géométrique, on dispose encore d'un morphisme de spécialisation

$$(4.2.1) sp: H^{i}(X_{s}, \mathbf{Q}_{\ell}) \stackrel{\sim}{\leftarrow} H^{i}(X, \mathbf{Q}_{\ell}) \rightarrow H^{i}(X_{\overline{n}}, \mathbf{Q}_{\ell}).$$

Le rôle de T est joué par l'action du groupe d'inertie  $I = Gal(\overline{\eta}/\eta)$ , agissant sur  $H^i(X_{\overline{\eta}}, \mathbf{Q}_{\ell})$  par transport de structure (cf. (1.15)) :

$$\mathbf{I} = \operatorname{Gal}(\overline{\eta}/\eta) \to \operatorname{GL}(\mathbf{H}^{i}(\mathbf{X}_{\overline{\eta}}, \mathbf{Q}_{\ell})).$$

Les données (4.2.1), (4.2.2) décrivent entièrement les faisceaux  $R^i f_* \mathbf{Q}_{\ell}$  sur S.

(4.3) Posons n=2m pour n pair, et n=2m+1 pour n impair. (4.2.1) et (4.2.2) se décrivent encore en terme d'un cycle évanescent

$$(4\cdot 3\cdot 1) \qquad \qquad \delta \in H^n(X_{\overline{n}}, \mathbf{Q}_{\ell})(m).$$

Ce cycle est bien défini au signe près.

Pour  $i \neq n$ , n+1, on a

$$(4.3.2)$$

Pour i=n, n+1, on a une suite exacte

(4.3.3)

$$\mathrm{o} \to \mathrm{H}^n(\mathrm{X}_s\,,\,\mathbf{Q}_\ell) \to \mathrm{H}^n(\mathrm{X}_{\overline{\eta}}\,,\,\mathbf{Q}_\ell) \xrightarrow{x \mapsto \mathrm{Tr}(x \cup \delta)} \mathbf{Q}_\ell(m-n) \to \mathrm{H}^{n+1}(\mathrm{X}_s\,,\,\mathbf{Q}_\ell) \to \mathrm{H}^{n+1}(\mathrm{X}_{\overline{\eta}}\,,\,\mathbf{Q}_\ell) \to \mathrm{o}.$$

L'action (4.2.2) de I (la monodromie locale) est triviale si  $i \neq n$ . Pour i = n, elle se décrit comme suit.

A) n impair. — On dispose d'un homomorphisme canonique

$$t_{\ell}: \mathbf{I} \to \mathbf{Z}_{\ell}(1),$$

et l'action de  $\sigma \in I$  est

$$x \mapsto x \pm t_{\ell}(\sigma)(x, \delta)\delta.$$

B) n pair. — Ce cas ne nous servira pas. Disons seulement que, si  $p \neq 2$ , il existe un unique caractère d'ordre deux

$$\epsilon:\ I\to\{\pm {\scriptstyle I}\},$$

et qu'on a

$$\sigma x = x$$
 si  $\varepsilon(\sigma) = I$   
 $\sigma x = x \pm (x, \delta)\delta$  si  $\varepsilon(\sigma) = -I$ .

Les signes ± dans A) et B) sont les mêmes qu'en (4.1).

- (4.4) Ces résultats apportent les informations suivantes sur les  $R^i f_* \mathbf{Q}_{\ell}$ .
- a)  $Si \delta \neq o$ :
  - 1) Pour  $i \neq n$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  est constant.
  - 2) Soit j l'inclusion de  $\eta$  dans S. On a

$$R^n f_* \mathbf{Q}_{\ell} = j_* j^* R^n f_* \mathbf{Q}_{\ell}$$
.

- b) Si  $\delta = 0$ : (C'est là un cas exceptionnel. Puisque  $(\delta, \delta) = \pm 2$  pour n pair, il ne peut se produire que pour n impair.)
  - 1) Pour  $i \neq n+1$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  est constant.
  - 2) Soit  $\mathbf{Q}_{\ell}(m-n)_s$  le faisceau  $\mathbf{Q}_{\ell}(m-n)$  sur  $\{s\}$ , prolongé par zéro sur S. On a une suite exacte

$$\mathbf{o} \rightarrow \mathbf{Q}_{\ell}(m-n)_s \rightarrow \mathbf{R}^{n+1} f_* \mathbf{Q}_{\ell} \rightarrow j_* j^* \mathbf{R}^{n+1} f_* \mathbf{Q}_{\ell} \rightarrow \mathbf{o},$$

où  $j_*j^*R^{n+1}f_*\mathbf{Q}_{\ell}$  est un faisceau constant.

## 5. La théorie de Lefschetz : théorie globale.

(5.1) Sur  $\mathbf{C}$ , les résultats de Lefschetz sont les suivants. Soient  $\mathbf{P}$  un espace projectif de dimension  $\geq 1$ , et  $\check{\mathbf{P}}$  l'espace projectif dual; ses points paramétrisent les hyperplans de  $\mathbf{P}$ , et on note  $\mathbf{H}_t$  l'hyperplan défini par  $t \in \check{\mathbf{P}}$ . Si  $\mathbf{A}$  est un sous-espace linéaire de codimension 2 de  $\mathbf{P}$ , les hyperplans contenant  $\mathbf{A}$  sont paramétrés par les points d'une droite  $\mathbf{D} \subset \check{\mathbf{P}}$ , la duale de  $\mathbf{A}$ . Ces hyperplans  $(\mathbf{H}_t)_{t \in \mathbf{D}}$  forment le pinceau d'axe  $\mathbf{A}$ .

Soit  $X \subset P$  une variété projective non singulière connexe et de dimension n+1. Soit  $\widetilde{X} \subset X \times D$  l'ensemble des couples (x, t) tels que  $x \in H_t$ . Les applications première et seconde coordonnée forment un diagramme

$$\begin{array}{ccc} X \xleftarrow{\pi} & \widetilde{X} \\ & \downarrow^{f} \\ & D \end{array}$$

La fibre de f en  $t \in D$  est la section hyperplane  $X_t = X \cap H_t$  de X.

Fixons X, et prenons A assez général. Alors :

- A) A est transverse à X, et  $\widetilde{X}$  se déduit de X par éclatement de  $A \cap X$ . En particulier,  $\widetilde{X}$  est non singulier.
- B) Il existe une partie finie S de D et pour chaque  $s \in S$  un point  $x_s \in X_s$ , tels que f soit lisse en dehors des  $x_s$ .
  - C) Les  $x_s$  sont des points critiques non dégénérés de f.

Pour chaque  $s \in S$ , la théorie de Lefschetz locale (4.1) s'applique donc à un petit disque  $D_s$  autour de s et à  $f^{-1}(D_s)$ .

(5.2) On pose U=D-S. Soit  $u \in U$ , et choisissons des lacets disjoints  $(\gamma_s)_{s \in S}$  partant de u, avec  $\gamma_s$  tournant une fois autour de s:

![](_page_18_Picture_8.jpeg)

Ces lacets engendrent le groupe fondamental  $\pi_1(U, u)$ . Ce groupe agit sur  $H^i(X_u, \mathbf{Z})$ , fibre en u du système local  $R^i f_* \mathbf{Z} | U$ . D'après la théorie locale (4.1), à chaque  $s \in S$  correspond un cycle évanescent  $\delta_s \in H^n(X_u, \mathbf{Z})$ ; ces cycles dépendent du choix des  $\gamma_s$ . Pour  $i \neq n$ , l'action de  $\pi_1(U, u)$  sur  $H^i(X_u, \mathbf{Z})$  est triviale. Pour i = n, on a

(5.2.1) 
$$\gamma_s x = x \pm (x, \delta_s) \delta_s.$$

Soit E le sous-espace de  $H^n(X_u, \mathbf{Q})$  engendré par les  $\delta_s$  (partie évanescente de la cohomologie).

Proposition (5.3). — E est stable sous l'action du groupe de monodromie  $\pi_1(U, u)$ . L'orthogonal  $E^{\perp}$  de E (pour la forme d'intersection  $Tr(x \cup y)$ ) est le sous-espace des invariants de la monodromie dans  $H^n(X_u, \mathbb{Q})$ .

Les  $\gamma_s$  engendrant le groupe de monodromie, c'est clair sur (5.2.1).

Théorème (5.4). — Les cycles évanescents  $\pm \delta_s$  (pris au signe près) sont conjugués sous l'action de  $\pi_1(U, u)$ .

Soit  $\check{\mathbf{X}} \subset \check{\mathbf{P}}$  la variété duale de  $\mathbf{X}$ : c'est l'ensemble des  $t \in \check{\mathbf{P}}$  tels que  $\mathbf{H}_t$  soit tangent à  $\mathbf{X}$ , i.e. tels que  $\mathbf{X}_t$  soit singulier, ou que  $\mathbf{X} \subset \mathbf{H}_t$ . La variété  $\check{\mathbf{X}}$  est irré290

ductible. Soit  $Y \subset X \times \check{\mathbf{P}}$  l'espace des couples (x, t) tels que  $x \in H_t$ . On dispose d'un diagramme

$$\mathbf{X} \longleftarrow \mathbf{Y}$$

$$\downarrow_{g}$$
 $\check{\mathbf{P}}$ 

La fibre de g en  $t \in \check{\mathbf{P}}$  est la section hyperplane  $X_t = X \cap H_t$  de X, et g est lisse en dehors de l'image réciproque de  $\check{X}$ .

On retrouve la situation de (5.1) en remplaçant  $\check{\mathbf{P}}$  par une droite  $D \subset \check{\mathbf{P}}$  et Y par  $g^{-1}(D)$ . On a  $S = D \cap \check{\mathbf{X}}$ . D'après un théorème de Lefschetz, pour D assez générale, l'application

$$\pi_1(D-S, u) \to \pi_1(\check{\mathbf{P}}-\check{X}, u)$$

est surjective. Il suffit donc de montrer que les  $\pm \delta_s$  sont conjugués sous  $\pi_1(\check{\mathbf{P}}-\check{\mathbf{X}})$ .

Pour x dans le lieu lisse de codimension I de  $\check{X}$ , soient ch un chemin de t à x dans  $\check{P}-\check{X}$ , et  $\gamma_x$  le lacet qui suit ch jusqu'au voisinage de  $\check{X}$ , tourne une fois autour de  $\check{X}$ , puis revient à t par ch. Les lacets  $\gamma_x$  (pour ch variable) sont conjugués entre eux. Puisque  $\check{X}$  est irréductible, deux points du lieu lisse de  $\check{X}$  peuvent toujours, dans  $\check{X}$ , être joints par un chemin qui ne quitte pas le lieu lisse. Il en résulte que la classe de conjugaison de  $\gamma_x$  ne dépend pas de x. En particulier, les  $\gamma_s$  sont conjugués entre eux. On lit sur (5.2.1) que ceci implique la conjugaison des  $\pm \delta_s$ .

Corollaire (5.5). — L'action de  $\pi_1(U, u)$  sur  $E/(E \cap E^{\perp})$  est absolument irréductible. Soit  $F \subset E \otimes \mathbf{C}$  un sous-espace stable sous la monodromie. Si  $F \subset (E \cap E^{\perp}) \otimes \mathbf{C}$ , il existe  $x \in F$  et  $s \in S$  tels que  $(x, \delta_s) \neq o$ . On a alors

$$\gamma_s x - x = \pm (x, \delta_s) \delta_s \in \mathbf{F},$$

et  $\delta_s \in F$ . D'après (5.4), tous les  $\delta_s$  sont alors dans F, et F = E. Ceci prouve (5.5).

(5.6) Ces résultats se transposent comme suit en géométrie algébrique abstraite.

Soient **P** un espace projectif de dimension > 1 sur k algébriquement clos de caractéristique p et  $X \subset \mathbf{P}$  une variété projective non singulière connexe et de dimension n+1. Pour A un sous-espace linéaire de **P** de codimension 2, on définit comme en (5.1) D et le pinceau  $(H_t)_{t \in D}$ , les  $X_t$ ,  $\widetilde{X}$  et le diagramme (5.1.1). On dit que les  $(X_t)_{t \in D}$  forment un pinceau de Lefschetz de sections hyperplanes si les conditions suivantes sont vérifiées:

A) L'axe A est transverse à X. L'espace  $\widetilde{X}$  se déduit alors de X par éclatement de  $A \cap X$ , et est lisse.
<!-- BATCH: p0021-0030 -->
- B) Il existe une partie finie S de D et pour chaque  $s \in S$  un point  $x_s \in X_s$ , tels que f soit lisse en dehors des  $x_s$ .
  - C) x<sub>s</sub> est un point singulier quadratique ordinaire de X<sub>s</sub>.

Pour chaque  $s \in S$ , la théorie de Lefschetz locale du § 4 s'applique au spectre  $D_s$  de l'hensélisé de l'anneau local de D en s, et à  $\widetilde{X}_{D_s} = \widetilde{X} \times_D D_s$ .

- (5.7) Soient N la dimension de  $\mathbf{P}$ , r un entier  $\geq 1$ , et  $\iota_{(r)}$  le plongement de  $\mathbf{P}$  dans l'espace projectif de dimension  $\binom{N+r}{N}-1$ , de coordonnées homogènes les monômes de degré r en les coordonnées homogènes de  $\mathbf{P}$ . Les sections hyperplanes de  $\iota_{(r)}(\mathbf{P})$  sont les hypersurfaces de degré r de  $\mathbf{P}$ .
- Si  $p \neq 0$ , il se peut qu'aucun pinceau de sections hyperplanes de X ne soit de Lefschetz. Toutefois, si  $r \geq 2$  et qu'on remplace le plongement projectif donné  $\iota_1: X \hookrightarrow \mathbf{P}$  par  $\iota_r = \iota_{(r)} \circ \iota_1$ , alors, dans ce nouveau plongement, tout pinceau assez général est de Lefschetz. En d'autres termes, si  $r \geq 2$ , un pinceau assez général de sections hypersurfaces de degré r de X est toujours de Lefschetz.
- (5.8) Dans la suite de cette discussion, nous étudions un pinceau de Lefschetz de sections hyperplanes de X, en excluant le cas p=2, n pair. Le cas où n est impair nous suffirait pour la suite. On pose U=D-S. Soient  $u\in U$  et  $\ell$  un nombre premier  $\neq p$ . Les résultats locaux du § 4 montrent que  $R^n f_* \mathbf{Q}_{\ell}$  est modérément ramifié en chaque  $s\in S$ . Le groupe fondamental modéré de U est un quotient du complété profini du groupe fondamental transcendant analogue (relèvement en caractéristique o des revêtements modérés, et théorème d'existence de Riemann). La situation algébrique est dès lors toute pareille à la situation transcendante, et la transposition de résultats de Lefschetz se fait par des arguments standards. Dans la démonstration de (5.4), le théorème de Lefschetz sur les  $\pi_1$  devient le théorème de Bertini, et on doit invoquer le lemme d'Abhyankar pour contrôler la ramification de  $R^*g_*\mathbf{Q}_{\ell}$  le long du lieu lisse de codimension un de  $\mathbf{X}$ .

Les résultats sont les suivants.

- a) Si les cycles évanescents sont non nuls :
  - 1) Pour  $i \neq n$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  sur D est constant.
  - 2) Soit j l'inclusion de U dans D. On a

$$R^n f_* \mathbf{Q}_{\ell} = j_* j^* R^n f_* \mathbf{Q}_{\ell}.$$

3) Soit  $E \subset H^n(X_u, \mathbf{Q}_\ell)$  le sous-espace de la cohomologie engendré par les cycles évanescents. Ce sous-espace est stable sous  $\pi_1(U, u)$ , et

$$\mathbf{E}^{\perp} = \mathbf{H}^{n}(\mathbf{X}_{u}, \mathbf{Q}_{\ell})^{\pi_{1}(\mathbf{U}, u)}$$

La représentation de  $\pi_1(U, u)$  sur  $E/(E \cap E^{\perp})$  est absolument irréductible, et l'image de  $\pi_1$  dans  $GL(E/(E \cap E^{\perp}))$  est engendrée (topologiquement) par les  $x \to x \pm (x, \delta_s) \delta_s$  ( $s \in S$ ) (le signe  $\pm$  étant déterminé comme en (4.1)).

- b) Si les cycles évanescents sont nuls: (C'est là un cas exceptionnel. Puisque  $(\delta, \delta) = \pm 2$  pour n pair, il ne peut se produire que pour n impair: n = 2m + 1. On notera que si un cycle évanescent est nul, ils le sont tous, car conjugués.)
  - 1) Pour  $i \neq n+1$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  est constant.
  - 2) On a une suite exacte

$$0 \to \bigoplus_{s \in S} \mathbf{Q}_{\ell}(m-n)_s \to \mathbb{R}^{n+1} f_* \mathbf{Q}_{\ell} \to \mathscr{F} \to 0$$

avec F constant.

- 3) E = 0.
- (5.9) Le sous-espace  $E \cap E^{\perp}$  de E est le noyau de la restriction à E de la forme d'intersection  $Tr(x \cup y)$ . Cette forme induit donc une forme bilinéaire non dégénérée

$$\psi: E/(E \cap E^{\perp}) \otimes E/(E \cap E^{\perp}) \to \mathbf{Q}_{\ell}(-n),$$

alternée pour n impair, et symétrique pour n pair. Cette forme est respectée par la monodromie; pour n impair, la représentation de monodromie induit donc

$$\rho: \pi_1(\mathbf{U}, u) \to \operatorname{Sp}(\mathbf{E}/(\mathbf{E} \cap \mathbf{E}^{\perp}), \psi).$$

Théorème (5.10) (Kajdan-Margulis). — L'image de p est ouverte.

L'image de  $\rho$  est un sous-groupe compact, donc analytique  $\ell$ -adique, de  $Sp(E/(E\cap E^\perp), \psi)$ . Il suffit de montrer que son algèbre de Lie  $\mathfrak L$  est égale à  $\mathfrak{sp}(E/(E\cap E^\perp), \psi)$ . L'analogue transcendant de cette algèbre de Lie est l'algèbre de Lie de l'adhérence de Zariski du groupe de monodromie.

On déduit de (5.8) que & est engendrée par les transformations de carré nul

$$N_s: x \mapsto (x, \delta_s)\delta_s \quad (s \in S)$$

et que  $E/(E \cap E^{\perp})$  est une représentation absolument irréductible de  $\mathfrak{L}$ . Le théorème résulte du lemme suivant.

Lemme (5.11). — Soient V un espace vectoriel de dimension finie sur un corps k de caractéristique o,  $\psi$  une forme alternée non dégénérée et  $\mathfrak L$  une sous-algèbre de Lie de  $\mathfrak{sp}(V,\psi)$ . On suppose que :

- (i) V est une représentation simple de \( \mathbb{L} \).
- (ii)  $\mathfrak{L}$  est engendrée par une famille d'endomorphismes de V de la forme  $x \mapsto \psi(x, \delta)\delta$ . Alors,  $\mathfrak{L} = \mathfrak{sp}(V, \psi)$ .

On peut supposer et on supposera que V, donc  $\mathfrak{L}$ , est non nul. Soit  $W \subset V$  l'ensemble des  $\delta \in V$  tels que  $N(\delta) : x \mapsto \psi(x, \delta)\delta$  soit dans  $\mathfrak{L}$ .

- a) W est stable par homothétie (car  $\mathfrak L$  est un sous-espace vectoriel de  $\mathfrak{gl}(V)$ ).
- b) Si  $\delta \in W$ ,  $\exp(\lambda N(\delta))$  est un automorphisme de  $(V, \psi, \Omega)$ , donc transforme W en lui-même. Si  $\delta'$ ,  $\delta'' \in W$ , on a donc  $\exp(\lambda N(\delta')) \cdot \delta'' = \delta'' + \lambda \psi(\delta'', \delta') \delta' \in W$ ; si  $\psi(\delta', \delta'') \neq 0$ , le sous-espace vectoriel tendu par  $\delta'$  et  $\delta''$  est dans W.

c) Il en résulte que W est réunion de ses sous-espaces linéaires maximaux  $W_{\alpha}$ , et que ceux-ci sont deux à deux orthogonaux. Chaque  $W_{\alpha}$  est dès lors stable sous les  $N(\delta)$  ( $\delta \in W$ ), donc stable sous  $\mathfrak L$ . Vu l'hypothèse (i),  $W_{\alpha} = V$  et  $\mathfrak L$  contient tous les  $N(\delta)$  pour  $\delta \in V$ . On conclut en notant que l'algèbre de Lie  $\mathfrak{sp}(V, \psi)$  est engendrée par les  $N(\delta)$  ( $\delta \in V$ ).

Remarque (5.12) (inutile pour la suite). — Il est maintenant facile de prouver (1.6) pour une hypersurface de dimension impaire n dans  $\mathbf{P}_{\mathbf{r}_n}^{n+1}$ .

Soient  $X_0$  une telle hypersurface, et  $\overline{X}_0$  l'hypersurface sur  $\overline{\mathbf{F}}_q$  qui s'en déduit par extension des scalaires. On a

$$\mathrm{H}^{2i}(\overline{\mathbf{X}}_{0}, \mathbf{Q}_{\ell}) = \mathbf{Q}_{\ell}(-i) \quad (0 \leq i \leq n);$$

 $H^{2i}(\overline{X}_0, \mathbf{Q}_{\ell}(i))$  est engendré par la  $i^{\text{ème}}$  cup-puissance de  $\eta$ , la classe de cohomologie  $c_1(\mathcal{O}(1))$  d'une section hyperplane. On a donc

$$Z(X_0, t) = \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^n(\overline{X}_0, \mathbf{Q}_\ell)) / \prod_{i=0}^n (\mathbf{I} - q^i t)$$

et  $\det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^n(\overline{\mathbf{X}}_0, \mathbf{Q}_\ell))$  est un polynôme à coefficients entiers indépendants de  $\ell$ .

Faisons varier  $X_0$  dans un pinceau de Lefschetz d'hypersurfaces, qui soit défini sur  $\mathbf{F}_q$  (cf. (5.7) pour  $X = \mathbf{P}^{n+1}$ ; l'existence d'un tel pinceau n'est pas claire; si on voulait compléter l'argument esquissé ici, il faudrait recourir aux arguments qui seront donnés en (7.1)). On vérifie que E coïncide ici avec le  $H^n$  tout entier, et (3.2) fournit la conjecture de Weil pour toutes les hypersurfaces du pinceau, en particulier pour  $X_0$ .

(5.13) Indications bibliographiques sur les §§ 4 et 5.

- A) Les résultats de Lefschetz (4.1) et (5.1) à (5.5) sont contenus dans son livre [2]. Pour la théorie locale (4.1), il peut être plus commode de consulter SGA 7, XIV (3.2).
  - B) Les résultats du § 4 sont démontrés dans les exposés XIII, XIV et XV de SGA 7.
  - C) (5.7) est démontré dans SGA 7, XVII.
- D) (5.8) est démontré dans SGA 7, XVIII. Le théorème d'irréductibilité y est démontré pour E, mais seulement sous l'hypothèse que  $E \cap E^{\perp} = \{o\}$ . La démonstration dans le cas général (pour  $E/(E \cap E^{\perp})$ ) est pareille.

## 6. Un théorème de rationalité.

(6.1) Soient  $\mathbf{P}_0$  un espace projectif de dimension  $\geq_{\bar{1}}$  sur  $\mathbf{F}_q$ ,  $X_0 \subset \mathbf{P}_0$  une variété projective non singulière,  $A_0 \subset \mathbf{P}_0$  un sous-espace linéaire de codimension deux,  $D_0 \subset \check{\mathbf{P}}_0$  la droite duale,  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$  et  $\mathbf{P}$ , X, A, D sur  $\overline{\mathbf{F}}_q$  déduits de  $\mathbf{P}_0$ ,  $X_0$ ,

 $A_0$ ,  $D_0$  par extension des scalaires. Le diagramme (5.1.1) de (5.6) provient d'un diagramme analogue sur  $\mathbf{F}_q$ :

$$\begin{array}{ccc} X_0 & \stackrel{\pi_0}{\longleftarrow} & \widetilde{X}_0 \\ & & & \downarrow^{f_0} \end{array}$$

On suppose que X est connexe de dimension paire n+1=2m+2, et que le pinceau  $(X_t)_{t\in D}$  de sections hyperplanes de X défini par D est un pinceau de Lefschetz. L'ensemble S des  $t\in D$  tels que  $X_t$  soit singulier est défini sur  $\mathbf{F}_q$ , i.e. provient de  $S_0\subset D_0$ . On pose  $U_0=D_0-S_0$  et U=D-S.

Soit  $u \in U$ . La partie évanescente de la cohomologie  $E \subset H^n(X_u, \mathbf{Q}_{\ell})$  est stable sous  $\pi_1(U, u)$ , donc définit sur U un sous-système local  $\mathscr E$  de  $R^n f_* \mathbf{Q}_{\ell}$ . Ce dernier est défini sur  $\mathbf{F}_q : R^i f_* \mathbf{Q}_{\ell}$  est l'image réciproque du  $\mathbf{Q}_{\ell}$ -faisceau  $R^i f_{0*} \mathbf{Q}_{\ell}$  sur  $D_0$ , et, sur U,  $\mathscr E$  est l'image réciproque d'un sous-système local

$$\mathscr{E}_0 \subset \mathbb{R}^n f_{0*} \mathbf{Q}_{\ell}$$
.

Le cup-produit est une forme alternée

$$\psi: \mathbf{R}^n f_{0*} \mathbf{Q}_{\ell} \otimes \mathbf{R}^n f_{0*} \mathbf{Q}_{\ell} \to \mathbf{Q}_{\ell}(-n).$$

Notant  $\mathscr{E}_0^{\perp}$  l'orthogonal de  $\mathscr{E}_0$  relativement à  $\psi$ , dans  $R^n f_{0*} \mathbf{Q}_{\ell} | U_0$  on voit que  $\psi$  induit une dualité parfaite

$$\psi: \,\mathscr{E}_0/(\mathscr{E}_0\cap\mathscr{E}_0^\perp)\otimes\mathscr{E}_0/(\mathscr{E}_0\cap\mathscr{E}_0^\perp)\to \mathbf{Q}_{\ell}(-n).$$

Théorème (6.2). — Pour tout  $x \in |U_0|$ , le polynôme  $\det(\mathbf{I} - \mathbf{F}_x^*t, \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}))$  est à coefficients rationnels.

Corollaire (6.3). — Soiert  $j_0$  l'inclusion de  $U_0$  dans  $D_0$ , et j celle de U dans D. Les valeurs propres de  $F^*$  agissant sur  $H^1(D, j_* \mathcal{E}/(\mathcal{E} \cap \mathcal{E}^{\perp}))$  sont des nombres algébriques dont tous les conjugués complexes  $\alpha$  vérifient

$$q^{\frac{n+1}{2}-\frac{1}{2}} \le |\alpha| \le q^{\frac{n+1}{2}+\frac{1}{2}}.$$

D'après (5.10) et (6.2), les hypothèses de (3.2) sont en effet vérifiées par  $(U_0, \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}), \psi)$ , pour  $\beta = n$ , et on applique (3.9).

Lemme (6.4). — Soit  $\mathscr{G}_0$  un  $\mathbf{Q}_{\ell}$ -faisceau constant tordu sur  $\mathbf{U}_0$ , tel que son image réciproque  $\mathscr{G}$  sur  $\mathbf{U}$  soit un faisceau constant. Il existe alors dans  $\overline{\mathbf{Q}}_{\ell}$  des unités  $\alpha_i$  telles que, pour tout  $x \in |\mathbf{U}_0|$ , on ait

$$\det(\mathbf{I} - \mathbf{F}_x^* t, \, \mathscr{G}_0) = \prod_i (\mathbf{I} - \alpha_i^{\deg(x)} t).$$

Ce lemme exprime que  $\mathscr{G}_0$  est l'image réciproque d'un faisceau sur  $\operatorname{Spec}(\mathbf{F}_q)$ , à savoir son image directe sur  $\operatorname{Spec}(\mathbf{F}_q)$ . Ce dernier s'identifie à une représentation  $\ell$ -adique  $G_0$  de  $\operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$ , et on prend

$$\det(\mathbf{I} - \mathbf{F}t, \mathbf{G}_0) = \prod_{i} (\mathbf{I} - \alpha_i t).$$

Le lemme (6.4) s'applique aux  $R^i f_{0*} \mathbf{Q}_{\ell}$   $(i \neq n)$ , à  $R^n f_{0*} \mathbf{Q}_{\ell} / \mathscr{E}_0$  et à  $\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}$ .

Pour  $x \in |\mathbf{U}_0|$  la fibre  $\mathbf{X}_x = f_0^{-1}(x)$  est une variété sur le corps fini k(x). Si  $\overline{x}$  est un point de U au-dessus de x,  $\mathbf{X}_{\overline{x}}$  se déduit de  $\mathbf{X}_x$  par extension des scalaires de k(x) à sa clôture algébrique  $k(\overline{x}) = \overline{\mathbf{F}}_q$ , et  $\mathbf{H}^i(\mathbf{X}_{\overline{x}}, \mathbf{Q}_\ell)$  est la fibre de  $\mathbf{R}^i f_* \mathbf{Q}_\ell$  en  $\overline{x}$ . La formule (1.5.4) pour la variété  $\mathbf{X}_x$  sur k(x) s'écrit donc

$$Z(X_x, t) = \prod_i \det(I - F_x^* t, R^i f_{0*} \mathbf{Q}_{\ell})^{(-1)^{i+1}}$$

et  $Z(X_x, t)$  est le produit de

$$\begin{split} \mathbf{Z}^{l} &= \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \ \mathbf{R}^{n}f_{0*}\mathbf{Q}_{\ell}/\mathscr{E}_{0}) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \, \mathscr{E}_{0} \cap \mathscr{E}_{0}^{\perp}) \cdot \prod_{i \neq n} \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \ \mathbf{R}^{i}f_{0*}\mathbf{Q}_{\ell})^{(-1)^{i+1}} \\ \text{par} &\qquad \qquad \mathbf{Z}^{m} = \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \, \mathscr{E}_{0}/(\mathscr{E}_{0} \cap \mathscr{E}_{0}^{\perp})). \end{split}$$

Posons  $\mathscr{F}_0 = \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp})$ ,  $\mathscr{F} = \mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})$  et appliquons (6.4) aux facteurs de  $Z^f$ . On trouve qu'il existe des unités  $\ell$ -adiques  $\alpha_i$   $(i \leq i \leq N)$  et  $\beta_j$   $(i \leq j \leq M)$  dans  $\overline{\mathbf{Q}}_{\ell}$  tels que pour tout  $x \in |\mathbf{U}_0|$ 

$$Z(\mathbf{X}_x, t) = \frac{\prod\limits_{i} (\mathbf{I} - \alpha_i^{\deg x} t)}{\prod\limits_{i} (\mathbf{I} - \beta_j^{\deg x} t)} \cdot \det(\mathbf{I} - \mathbf{F}_x^* t, \mathscr{F}_0)$$

et qu'en particulier le second membre est dans  $\mathbf{Q}(t)$ . Si un  $\alpha_i$  coïncide avec un  $\beta_j$ , il est loisible de supprimer simultanément cet  $\alpha_i$  de la liste des  $\alpha$  et ce  $\beta_j$  de la liste des  $\beta$ . On peut donc supposer, et nous supposerons, que  $\alpha_i \neq \beta_j$  pour tout i et tout j.

(6.5) Il suffit de prouver que les polynômes  $\prod_{i} (1-\alpha_{i}t)$  et  $\prod_{j} (1-\beta_{j}t)$  sont à coefficients rationnels, i.e. que la famille des  $\alpha_{i}$  (resp. la famille des  $\beta_{j}$ ) est définie sur  $\mathbf{Q}$ . Nous le déduirons des propositions suivantes.

Proposition (6.6). — Soient  $(\gamma_i)$   $(1 \le i \le P)$  et  $(\delta_j)$   $(1 \le j \le Q)$  deux familles d'unités  $\ell$ -adiques dans  $\overline{\mathbf{Q}}_{\ell}$ . On suppose que  $\gamma_i + \delta_j$ . Si K est un ensemble fini assez grand d'entiers + 1, et L une partie de densité o assez grande de  $|U_0|$ , alors, si  $x \in |U_0|$  vérifie  $k \nmid \deg(x)$  (pour tout  $k \in K$ ) et  $x \notin L$ , le dénominateur de

$$\det(\mathbf{I} - \mathbf{F}_x^* t, \mathscr{F}_0) \prod_{i} (\mathbf{I} - \gamma_i^{\deg(x)} t) / \prod_{j} (\mathbf{I} - \delta_j^{\deg(x)} t),$$

écrit sous forme irréductible, est  $\prod_{i} (1 - \delta_{j}^{\deg(x)} t)$ .

La démonstration sera donnée en (6.10-13). D'après (6.7) ci-dessous, (6.6) fournit 296

une description intrinsèque de la famille des  $\delta_j$  en terme de la famille des fractions rationnelles (6.6.1) pour  $x \in |U_0|$ .

Lemme (6.7). — Soient K un ensemble fini d'entiers  $\neq 1$  et  $(\delta_j)$   $(1 \leq j \leq Q)$  et  $(\varepsilon_j)$   $(1 \leq j \leq Q)$  deux familles d'éléments d'un corps. Si, pour tout n assez grand, non divisible par aucun des  $k \in K$ , la famille des  $\delta_j^n$  coïncide avec celle des  $\varepsilon_j^n$  (à l'ordre près), alors la famille des  $\delta_j$  coïncide avec celle des  $\varepsilon_j$  (à l'ordre près).

On procède par récurrence sur Q. L'ensemble des entiers n tels que  $\delta_Q^n = \varepsilon_j^n$  est un idéal  $(n_j)$ . Prouvons qu'il existe  $j_0$  tel que  $\delta_Q = \varepsilon_{j_0}$ . Sinon les  $n_j$  seraient distincts de 1, et il existerait des entiers arbitrairement grands n, non divisibles par aucun des  $n_j$ , ni par aucun des  $k \in K$ . On aurait  $\delta_Q^n + \varepsilon_j^n$ , et ceci contredirait l'hypothèse. Il existe donc  $j_0$  tel que  $\delta_Q = \varepsilon_{j_0}$ . On conclut en appliquant l'hypothèse de récurrence aux familles  $(\delta_j)$   $(j \neq Q)$  et  $(\varepsilon_j)$   $(j \neq j_0)$ .

Proposition (6.8). — Soient  $(\gamma_i)$   $(1 \le i \le P)$  et  $(\delta_j)$   $(1 \le j \le Q)$  deux familles d'unités p-adiques dans  $\overline{\mathbf{Q}}_{\ell}$ ,  $\mathbf{R}(t) = \prod_i (1 - \gamma_i t)$  et  $\mathbf{S}(t) = \prod_j (1 - \delta_j t)$ . Supposons que pour tout  $x \in |\mathbf{U}_0|$ ,  $\prod_i (1 - \delta_i^{\deg(x)} t)$  divise

$$\prod_{i} (\mathbf{I} - \gamma_{i}^{\deg(x)} t) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*} t, \mathscr{F}_{0}).$$

Alors S(t) divise R(t).

Supprimons des familles  $(\gamma_i)$  et  $(\delta_j)$  des paires d'éléments communs jusqu'à vérifier l'hypothèse de (6.6). Appliquons (6.6). Par hypothèse, les fractions rationnelles (6.6.1) sont des polynômes. Aucun  $\delta$  n'a donc subsisté, ce qui signifie que S(t) divise R(t).

Cette proposition fournit une caractérisation intrinsèque de  $\mathbf{R}(t)$  en terme de la famille de polynômes

$$\prod_{i} (\mathbf{I} - \gamma_{i}^{\deg(x)} t) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*} t, \mathscr{F}_{0}).$$

C'est le ppcm des polynômes  $S(t) = \prod_{j} (1 - \delta_{j}t)$  vérifiant l'hypothèse de (6.8).

(6.9) Prouvons (6.5) et donc (6.2) (modulo (6.6)). Faisons dans (6.6)  $(\gamma_i) = (\alpha_i)$  et  $(\delta_j) = (\beta_j)$ . On trouve une caractérisation intrinsèque de la famille des  $\beta_j$  en terme de la famille de fractions rationnelles  $Z(X_x, t)$   $(x \in |U_0|)$ . Celles-ci étant dans  $\mathbf{Q}(t)$ , la famille des  $\beta_j$  est définie sur  $\mathbf{Q}$ .

Les polynômes  $\prod_i (\mathbf{1} - \alpha_i^{\deg(x)} t) \cdot \det(\mathbf{1} - \mathbf{F}_x^* t, \mathscr{F}_0)$  sont donc dans  $\mathbf{Q}[t]$ . La proposition (6.8) fournit une description intrinsèque de la famille des  $\alpha_i$  en terme de cette famille de polynômes. La famille des  $\alpha_i$  est donc définie sur  $\mathbf{Q}$ .

(6.10) Préliminaires. — Soient  $u \in U$  et  $\mathscr{F}_u$  la fibre de  $\mathscr{F}$  en u. Le groupe fondamental arithmétique  $\pi_1(U_0, u)$ , extension de  $\hat{\mathbf{Z}} = \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  (générateur :  $\varphi$ ) par le groupe fondamental géométrique  $\pi_1(U, u)$ , agit sur  $\mathscr{F}_u$  par similitudes symplectiques :

$$\rho: \ \pi_1(\mathbf{U}_0, u) \to \mathrm{CSp}(\mathscr{F}_u, \psi).$$

Nous notons  $\mu(g)$  le multiplicateur d'une similitude symplectique g. Soit

$$H \subset \hat{\mathbf{Z}} \times CSp(\mathcal{F}_u, \psi)$$

le sous-groupe défini par l'équation

$$q^{-n} = \mu(g)$$

(q étant une unité  $\ell$ -adique,  $q^n \in \mathbf{Q}_{\ell}^*$  est défini pour tout  $n \in \hat{\mathbf{Z}}$ ). Le fait que  $\psi$  soit à valeurs dans  $\mathbf{Q}_{\ell}(-n)$  s'exprime en disant que l'application de  $\pi_1$  dans  $\hat{\mathbf{Z}} \times \mathrm{CSp}$ , de coordonnées la projection canonique sur  $\hat{\mathbf{Z}}$  et  $\rho$ , se factorise par

$$\rho_1: \pi_1(\mathbf{U}_0, u) \rightarrow \mathbf{H}.$$

Lemme (6.11). — L'image  $H_1$  de  $\rho_1$  est ouverte dans H.

En effet,  $\pi_1(U_0, u)$  se projette sur  $\hat{\mathbf{Z}}$ , et l'image de  $\pi_1(U, u) = \text{Ker}(\pi_1(U_0, u) \to \hat{\mathbf{Z}})$  dans  $\text{Sp}(\mathscr{F}_u, \psi) = \text{Ker}(H \to \hat{\mathbf{Z}})$  est ouverte (5.10).

Lemme (6.12). — Pour  $\delta \in \overline{\mathbb{Q}}_{\ell}$  une unité  $\ell$ -adique, l'ensemble Z des  $(n,g) \in H_1$  tels que  $\delta^n$  soit valeur propre de g est un fermé de mesure nulle.

Il est clair que Z est fermé. Pour chaque  $n \in \widehat{\mathbf{Z}}$ , soit  $\mathrm{CSp}_n$  l'ensemble des  $g \in \mathrm{CSp}(\mathscr{F}_u, \psi)$  tels que  $\mu(g) = q^{-n}$ , et soit  $Z_n$  l'ensemble des  $g \in \mathrm{CSp}_n$  tels que  $\delta^n$  soit valeur propre de g. Alors,  $\mathrm{CSp}_n$  est un espace homogène sous  $\mathrm{Sp}$ , et on vérifie que  $Z_n$  en est un sous-espace algébrique propre, donc de mesure o. D'après (6.11),  $H_1 \cap (\{n\} \times Z_n)$  est donc de mesure o dans l'image inverse dans  $H_1$  de n, et on applique Fubini à la projection  $H_1 \to \widehat{\mathbf{Z}}$ .

(6.13) Prouvons (6.6). Pour chaque i et j, l'ensemble des entiers n tels que  $\gamma_i^n = \delta_j^n$  est l'ensemble des multiples d'un entier fixe  $n_{ij}$  (on n'exclut pas  $n_{ij} = 0$ ). Par hypothèse,  $n_{ij} \neq 1$ .

D'après (6.12) et le théorème de densité de Čebotarev, l'ensemble des  $x \in |U_0|$  tels qu'un  $\beta_j^{\deg(x)}$  soit valeur propre de  $F_x^*$  agissant sur  $\mathscr{F}_0$  est de densité o. On prend pour K l'ensemble des  $n_{ij}$  et pour L l'ensemble des x ci-dessus.

## 7. Fin de la démonstration de 1.7.

Lemme (7.1). — Soit  $X_0$  une variété projective non singulière absolument irréductible de dimension paire d sur  $\mathbf{F}_q$ . Soient X sur  $\overline{\mathbf{F}}_q$  déduit de  $X_0$  par extension des scalaires et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^d(X, \mathbf{Q}_\ell)$ . Alors,  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient

(7.1.1) 
$$q^{\frac{d}{2}-\frac{1}{2}} \le |\alpha| \le q^{\frac{d}{2}+\frac{1}{2}}.$$

On procède par récurrence sur d (toujours supposé pair). Le cas d=0 est trivial, même sans supposer  $X_0$  absolument irréductible; on suppose dorénavant  $d \ge 2$ . On pose d=n+1=2m+2.

Si  $\mathbf{F}_{q'}$  est une extension de degré r de  $\mathbf{F}_q$  et que  $\mathbf{X}_0'/\mathbf{F}_{q'}$  se déduit de  $\mathbf{X}_0/\mathbf{F}_q$  par extension des scalaires, l'assertion (7.1) pour  $\mathbf{X}_0'/\mathbf{F}_q$  équivaut à (7.1) pour  $\mathbf{X}_0'/\mathbf{F}_{q'}$ : de même que q est remplacé par  $q^r$ , les valeurs propres de  $\mathbf{F}^*$  sont remplacées par leurs puissances  $r^{\text{lèmes}}$ .

D'après (5.7), dans un plongement projectif convenable  $i: X \to \mathbf{P}$ , X admet un pinceau de Lefschetz de sections hyperplanes. La remarque précédente nous permet de supposer i et ce pinceau définis sur  $\mathbf{F}_a$  (quitte à remplacer  $\mathbf{F}_a$  par une extension finie).

Supposons donc qu'il existe sur  $\mathbf{F}_q$  un plongement projectif  $X_0 \to \mathbf{P}_0$  et un sous-espace de codimension deux  $A_0$  de  $\mathbf{P}_0$  qui définisse un pinceau de Lefschetz. On reprend les notations de (6.1) et (6.3). Une nouvelle extension des scalaires nous ramène à supposer que :

- a) Les points de S sont définis sur  $\mathbf{F}_a$ .
- b) Les cycles évanescents en  $x_s$  ( $s \in S$ ) sont définis sur  $\mathbf{F}_q$  (puisque seul  $\pm \delta$  est intrinsèque, ils pourraient n'être définis que sur une extension quadratique).
- c) Il existe un point rationnel  $u_0 \in U_0$ . On prend le point correspondant u de U comme point base.
- d)  $X_{u_0} = f_0^{-1}(u_0)$  admet une section hyperplane lisse  $Y_0$ , définie sur  $\mathbf{F}_q$ . On pose  $Y = Y_0 \otimes_{\mathbf{F}_q} \overline{\mathbf{F}}_q$ .

Puisque  $\widetilde{X}$  se déduit de X par éclatement de la sous-variété lisse de codimension deux  $A \cap X$ , on a

$$H^{i}(X, \mathbf{Q}_{\ell}) \hookrightarrow H^{i}(\widetilde{X}, \mathbf{Q}_{\ell})$$

(en fait,  $H^{i}(\widetilde{X}, \mathbf{Q}_{\ell}) = H^{i}(X, \mathbf{Q}_{\ell}) \oplus H^{i-2}(A \cap X, \mathbf{Q}_{\ell})(-1)$ ). Il suffit donc de prouver (7.1.1) pour les valeurs propres  $\alpha$  de  $F^{*}$  agissant sur  $H^{d}(\widetilde{X}, \mathbf{Q}_{\ell})$ .

La suite spectrale de Leray pour f s'écrit

$$E_2^{pq} = H^p(D, R^q f_* \mathbf{Q}_{\ell}) \Rightarrow H^{p+q}(\widetilde{X}, \mathbf{Q}_{\ell}).$$

Il suffit de prouver (7.1.1) pour les valeurs propres  $\alpha$  de F\* agissant sur les  $E_2^{pq}$  pour p+q=d=n+1. Ce sont :

A) 
$$E_2^{2,n-1}$$
. D'après (5.8),  $R^{n-1}f_*\mathbf{Q}_{\ell}$  est constant. D'après (2.10), on a donc  $E_2^{2,n-1} = H^{n-1}(X_{\ell}, \mathbf{Q}_{\ell})(-1)$ .

D'après le théorème de Lefschetz faible (corollaire de SGA 4, XIV (3.2), et de la dualité de Poincaré, SGA 4, XVIII), on a

$$H^{n-1}(X_n, \mathbf{Q}_n)(-1) \hookrightarrow H^{n-1}(Y, \mathbf{Q}_n)(-1),$$

et on applique l'hypothèse de récurrence à Y<sub>0</sub>.

B)  $E_2^{0,n+1}$ . Si les cycles évanescents sont non nuls,  $R^{n+1}f_*\mathbf{Q}_{\ell}$  est constant et

$$E_2^{0,n+1} = H^{n+1}(X_u, \mathbf{Q}_l).$$

Le morphisme de Gysin

$$H^{n-1}(Y, \mathbf{Q}_{\ell})(-1) \to H^{n+1}(X_n, \mathbf{Q}_{\ell})$$

est surjectif (cet argument est dual de A)), et on applique l'hypothèse de récurrence à Y<sub>0</sub>.

Si les cycles évanescents sont nuls, la suite exacte de (5.8) b) fournit une suite exacte

$$\bigoplus_{n \in S} \mathbf{Q}_{\ell}(m-n) \to \mathrm{E}_{2}^{0,n+1} \to \mathrm{H}^{n+1}(\mathrm{X}_{u}, \, \mathbf{Q}_{\ell}).$$

La valeur propre de F agissant sur  $\mathbf{Q}_{\ell}(m-n)$  est  $q^{d/2}$ , et  $\mathbf{H}^{n+1}$  se traite comme plus haut.

C)  $E_2^{1,n}$ . Si on disposait du théorème de Lefschetz « difficile », on saurait que  $\mathscr{E} \cap \mathscr{E}^{\perp}$  est nul, et que  $R^n f_* \mathbf{Q}_{\ell}$  est somme directe de  $j_* \mathscr{E}$  et d'un faisceau constant. Le  $H^1$  d'un faisceau constant sur  $\mathbf{P}^1$  est nul, et il suffirait d'appliquer (6.3).

Faute d'avoir déjà démontré Lefschetz « difficile », il nous va falloir dévisser. Si les cycles évanescents sont nuls,  $R^n f_* \mathbf{Q}_{\ell}$  est constant ((5.8) b)) et  $E_2^{1,n} = 0$ . On peut donc supposer, et on supposera, les cycles évanescents non nuls. Filtrons  $R^n f_* \mathbf{Q}_{\ell} = j_* j^* R^n f_* \mathbf{Q}_{\ell}$  (5.8) par les sous-faisceaux  $j_* \mathscr{E}$  et  $j_* (\mathscr{E} \cap \mathscr{E}^{\perp})$ . Si les cycles évanescents  $\delta$  ne sont pas dans  $\mathscr{E} \cap \mathscr{E}^{\perp}$ , on dispose de suites exactes :

(7.1.2) 
$$0 \rightarrow j_* \mathscr{E} \rightarrow \mathbb{R}^n f_* \mathbf{Q}_{\ell} \rightarrow \text{faisceau constant} \rightarrow 0.$$

(7.1.3) 
$$0 \rightarrow \text{faisceau constant } j_*(\mathscr{E} \cap \mathscr{E}^{\perp}) \rightarrow j_*\mathscr{E} \rightarrow j_*(\mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})) \rightarrow 0.$$

Si, à Dieu ne plaise, les  $\delta$  sont dans  $\mathcal{E} \cap \mathcal{E}^{\perp}$ , on a  $\mathcal{E} \subset \mathcal{E}^{\perp}$ , et des suites exactes :

(7.1.4) 
$$0 \rightarrow \text{le faisceau constant } j_* \mathscr{E}^{\perp} \rightarrow \mathbb{R}^n f_* \mathbf{Q}_{\ell} \rightarrow \text{un faisceau } \mathscr{F} \rightarrow 0$$

(7.1.5) 
$$0 \to \mathscr{F} \to \text{le faisceau constant } j_*j^*\mathscr{F} \to \bigoplus_{s \in S} \mathbf{Q}_{\ell}(n-m)_s \to 0.$$

Dans le premier cas, les suites exactes longues de cohomologie fournissent

$$(7.1.2')$$

$$(\mathbf{7}.\mathbf{r}.\mathbf{3}') \qquad \qquad \mathbf{0} \rightarrow \mathbf{H}^{1}(\mathbf{D}, j_{*}\mathscr{E}) \rightarrow \mathbf{H}^{1}(\mathbf{D}, j_{*}(\mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})))$$

et on applique (6.3).

Dans le second cas, elles fournissent

$$(7.1.4') o \rightarrow H^1(D, R^n f_* \mathbf{Q}_{\ell}) \rightarrow H^1(D, \mathscr{F}),$$

(7.1.5') 
$$\bigoplus_{s \in S} \mathbf{Q}_{\ell}(n-m) \to H^{1}(D, \mathscr{F}) \to 0$$

et on remarque que F agit sur  $\mathbf{Q}_{\ell}(n-m)$  par multiplication par  $q^{d/2}$ .

Lemme (7.2). — Soit  $X_0$  une variété projective non singulière absolument irréductible de dimension d sur  $\mathbf{F}_q$ . Soient X sur  $\overline{\mathbf{F}}_q$  déduit de  $X_0$  par extension des scalaires et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^d(X, \mathbf{Q}_t)$ . Alors,  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient

$$|\alpha|=q^{d/2}$$
.

Prouvons déjà que  $(7.2) \Rightarrow (1.7)$ . Pour  $X_0$  projective non singulière sur  $\mathbf{F}_q$  et i un entier, il faut prouver l'assertion suivante :

- $W(X_{0,i})$ . Soit X déduit de  $X_0$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ . Si  $\alpha$  est une valeur propre de  $F^*$  agissant sur  $H^i(X, \mathbf{Q}_\ell)$ , alors  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient  $|\alpha| = q^{i/2}$ .
- a) Si  $\mathbf{F}_{q^n}$  est une extension de degré n de  $\mathbf{F}_q$ , et que  $\mathbf{X}_0'/\mathbf{F}_{q^n}$  se déduit de  $\mathbf{X}_0/\mathbf{F}_q$  par extension des scalaires, alors  $\mathbf{W}(\mathbf{X}_0,i)$  équivaut à  $\mathbf{W}(\mathbf{X}_0',i)$ : étendre les scalaires revient à remplacer  $\alpha$  par  $\alpha^n$  et q par  $q^n$ .
- b) Si  $X_0$  est purement de dimension n,  $W(X_0,i)$  équivaut à  $W(X_0,2n-i)$  : ceci résulte de la dualité de Poincaré.
  - c) Si  $X_0$  est somme de variétés  $X_0^{\alpha}$ ,  $W(X_0, i)$  équivaut à la conjonction des  $W(X_0^{\alpha}, i)$ .
- d) Si  $X_0$  est purement de dimension n,  $Y_0$  une section hyperplane lisse de  $X_0$ , et que i < n, alors  $W(Y_0, i) \Rightarrow W(X_0, i)$ : ceci résulte du théorème de Lefschetz faible.

Pour prouver les assertions  $W(X_0, i)$ , on se ramène successivement :

- par c), à supposer  $X_0$  purement d'une dimension n;
- par b), à supposer de plus  $0 \le i \le n$ ;
- par a) et d), à supposer de plus i=n;
- par a) et c), à supposer de plus X<sub>0</sub> absolument irréductible.

Ce cas est justiciable de (7.2).

(7.3) Prouvons (7.2). Pour tout entier k,  $\alpha^k$  est valeur propre de  $F^*$  agissant sur  $H^{kd}(X^k, \mathbf{Q}_{\ell})$  (formule de Künneth). Pour k pair,  $X^k$  est justiciable de (7.1), d'où

$$q^{\frac{kd}{2} - \frac{1}{2}} \le |\alpha^k| \le q^{\frac{kd}{2} - \frac{1}{2}}$$

$$q^{\frac{d}{2} - \frac{1}{2k}} \le |\alpha| \le q^{\frac{d}{2} + \frac{1}{2k}}.$$

et

Faisant tendre k vers l'infini, on trouve (7.2).

## 8. Premières applications.

Théorème (8.1). — Soit  $X_0 \subset \mathbf{P}_0^{n+r}$  une intersection complète non singulière sur  $\mathbf{F}_q$ , de dimension n et de multidegré  $(d_1, \ldots, d_r)$ . Soit b' le  $n^{\text{lème}}$  nombre de Betti des intersections complètes non singulières complexes, de mêmes dimension et multidegré. Posons b=b' pour n impair, et b=b'-1 pour n pair. Alors

$$| \# \mathbf{X}_0(\mathbf{F}_q) - \# \mathbf{P}^n(\mathbf{F}_q) | \le b \cdot q^{n/2}.$$

Soient  $X/\overline{\mathbf{F}}_q$  déduit de  $X_0$ , et  $\mathbf{Q}_{\ell}$ .  $\eta^i$  la droite dans  $H^{2i}(X, \mathbf{Q}_{\ell})$  engendrée par la  $i^{\text{ème}}$  cup-puissance de la classe de cohomologie d'une section hyperplane. Sur cette droite,  $\mathbf{F}^*$  agit par multiplication par  $q^i$ . La cohomologie de X est somme des  $\mathbf{Q}_{\ell}$ .  $\eta^i$
<!-- BATCH: p0031-0036 -->
$(o \le i \le n)$  et de la partie primitive de  $H^n(X, \mathbf{Q}_{\ell})$ , de dimension b. D'après (1.5), il existe donc b nombres algébriques  $\alpha_j$ , les valeurs propres de  $F^*$  agissant sur cette cohomologie primitive, tels que

$$\# X_0(\mathbf{F}_q) = \sum_{i=0}^n q^i + (-1)^n \sum_j \alpha_j.$$

D'après (1.7),  $|\alpha_i| = q^{n/2}$  et

$$| \# X_0(\mathbf{F}_q) - \# \mathbf{P}(\mathbf{F}_q) | = | \# X_0(\mathbf{F}_q) - \sum_{i=0}^n q^i | = | \sum_i \alpha_i | \leq \sum_i |\alpha_j| = b \cdot q^{n/2}.$$

Théorème (8.2). — Soient N un entier  $\geq 1$ ,  $\epsilon: (\mathbf{Z}/N)^* \to \mathbf{C}^*$  un caractère, k un entier  $\geq 2$  et f une forme modulaire holomorphe sur  $\Gamma_0(N)$ , de poids k et de caractère  $\epsilon: f$  est une fonction holomorphe sur le demi-plan de Poincaré X, telle que pour  $\begin{pmatrix} a & b \\ c & d \end{pmatrix} \in \mathrm{SL}(2,\mathbf{Z})$ , avec  $c \equiv 0$  (N), on ait

$$f\left(\frac{az+b}{cz+d}\right) = \varepsilon(a)^{-1}(cz+d)^k f(z).$$

On suppose f cuspidale et primitive (« new » au sens d'Atkin-Lehner et de Miyake), en particulier vecteur propre des opérateurs de Hecke  $T_p$  ( $p \nmid N$ ). Posons  $f = \sum_{n=1}^{\infty} a_n q^n$ , avec  $q = e^{2\pi i x}$  (et  $a_1 = 1$ ). Alors, pour p premier ne divisant pas N

$$|a_p| \leq 2 \cdot p^{\frac{k-1}{2}}.$$

En d'autres termes, les racines de l'équation

$$T^2 - a_p T + \varepsilon(p) \cdot p^{k-1}$$

sont de valeur absolue  $p^{\frac{k-1}{2}}$ .

Ces racines sont en effet des valeurs propres de Frobenius agissant sur le  $H^{k-1}$  d'une variété projective non singulière de dimension k-1 définie sur  $\mathbf{F}_p$ .

Sous des hypothèses restrictives, ce fait est démontré dans mon exposé Bourbaki (Formes modulaires et représentations  $\ell$ -adiques, exposé 355, février 1969, dans : Lecture Notes in Mathematics, 179). Le cas général n'est pas beaucoup plus difficile.

Remarque (8.3). — J. P. Serre et moi-même avons récemment démontré que (8.2) reste vrai pour k=1. La démonstration est toute différente.

L'application suivante m'a été suggérée par E. Bombieri.

Théorème (8.4). — Soient Q un polynôme à n variables et de degré d sur  $\mathbf{F}_q$ ,  $Q_d$  la partie homogène de degré d de Q et  $\psi: \mathbf{F}_q \rightarrow \mathbf{C}^*$  un caractère additif non trivial sur  $\mathbf{F}_q$ . On suppose que :

- (i) d est premier à p;
- (ii) l'hypersurface  $\mathbf{H}_0$  dans  $\mathbf{P}_{\mathbf{F}_q}^{n-1}$  définie par  $\mathbf{Q}_d$  est lisse.

302

Alors

$$\left|\sum_{x_1,\ldots,x_n\in\mathbb{F}_q} \psi(Q(x_1,\ldots,x_n))\right| \leq (d-1)^n q^{n/2}.$$

Quitte à remplacer Q par un multiple scalaire, on peut supposer (et on supposera) que

$$\psi(x) = \exp(2\pi i \operatorname{Tr}_{\mathbf{F}_d/\mathbf{F}_p}(x)/p).$$

Soit  $X_0$  le revêtement étale de l'espace affine  $A_0$  de dimension n sur  $\mathbf{F}_q$  d'équation  $T^p - T = Q$ , et soit  $\sigma$  la projection de  $X_0$  sur  $A_0$ :

$$\begin{split} &\sigma:\ \mathbf{X_0}\!\rightarrow\!\mathbf{A_0}\\ \mathbf{X_0}\!=\!\mathrm{Spec}(\mathbf{F}_q[\mathbf{x_1},\ \dots,\ \mathbf{x_n},\ \mathbf{T}]/(\mathbf{T}^p\!-\!\mathbf{T}\!-\!\mathbf{Q})). \end{split}$$

Le revêtement  $X_0$  est galoisien, de groupe de Galois  $\mathbf{Z}/p$ ;  $i \in \mathbf{Z}/p = \mathbf{F}_p$  agit par  $T \mapsto T + i$ . Soit  $x \in A_0(\mathbf{F}_q)$  et calculons l'endomorphisme de Frobenius de la fibre de  $X_0/A_0$  en x. Posons  $q = p^f$  et soit  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$ . Pour  $(x, T) \in X_0(\overline{\mathbf{F}}_q)$  au-dessus de x, on a  $F((x, T)) = (x, T^q)$ , et

$$T^{q} = T + \sum_{i=1}^{f} (T^{p^{i}} - T^{p^{i-1}}) = T + \sum_{i} Q(x)^{p^{i-1}} = T + Tr_{\mathbf{F}_{q}/\mathbf{F}_{p}}(Q(x)).$$

C'est l'action de l'élément  $\operatorname{Tr}_{\mathbf{F}_q/\mathbf{F}_p}(\mathbf{Q}(x))$  du groupe de Galois.

Soient E le corps des racines  $p^{i \ge mes}$  de l'unité et  $\lambda$  une place finie de E première à p. Nous travaillerons en cohomologie  $\lambda$ -adique. Pour  $j \in \mathbf{Z}/p$ , soit  $\mathscr{F}_{j,0}$  le  $\mathbf{E}_{\lambda}$ -système local de rang un sur  $\mathbf{A}_0$  défini par  $\mathbf{X}_0$  et  $\psi(-jx):\mathbf{Z}/p \to \mathbf{E}^* \to \mathbf{E}^*_{\lambda}$ : on dispose de  $\iota: \mathbf{X}_0 \to \mathscr{F}_{j,0}$  et  $\iota(i*x) = \psi(-ji)\iota(x)$ . Notons sans  $_0$  les objets déduits de  $\mathbf{A}_0$ ,  $\mathbf{X}_0$ ,  $\mathscr{F}_{j,0}$  par extension des scalaires à  $\overline{\mathbf{F}}_q$ . La formule des traces (1.12.1) pour  $\mathscr{F}_{j,0}$  s'écrit

(8.4.2) 
$$\sum_{x_1, \ldots, x_n \in \mathbb{F}_q} \psi(Q(x_1, \ldots, x_n)) = \sum_{i} (-1)^{i} \operatorname{Tr}(F^*, H_c^i(A, \mathscr{F}_1)).$$

On a 
$$\sigma_* E_{\lambda} = \bigoplus_j \mathscr{F}_j$$
, et donc

$$(\mathbf{8}.\mathbf{4}.\mathbf{3}) \qquad \qquad \mathbf{H}_{c}^{\star}(\mathbf{X},\,\mathbf{Q}_{\ell}) \otimes_{\mathbf{Q}_{\ell}} \mathbf{E}_{\lambda} = \bigoplus_{i} \mathbf{H}_{c}^{\star}(\mathbf{A},\,\mathscr{F}_{j}).$$

Pour j=0,  $\mathscr{F}_j$  est le faisceau constant  $E_{\lambda}$ ; ce facteur correspond à l'inclusion, par image réciproque, de la cohomologie de A dans celle de X.

Lemme (8.5). — (i) Pour  $j \neq 0$ ,  $H_c^i(A, \mathscr{F}_j)$  est nul pour  $i \neq n$ ; pour i = n, cet espace de cohomologie est de dimension  $(d-1)^n$ .

(ii) Pour  $j \neq 0$ , le cup-produit

$$\mathrm{H}^n_c(\mathrm{A},\mathscr{F}_j)\otimes\mathrm{H}^n_c(\mathrm{A},\mathscr{F}_{-j})\to\mathrm{H}^{2n}_c(\mathrm{A},\mathrm{E}_\lambda)\overset{\mathrm{Tr}}{\to}\mathrm{E}_\lambda(-n)$$

est une dualité parfaite.

(iii)  $X_0$  est un ouvert d'une variété projective non singulière  $Z_0$ .

Déduisons (8.4) de (8.5). Soient *JQ :* XQ^ZQ et *j :* X<-^Z déduit par extension des scalaires à F^. D'après (8.4.2)3 (i), et (i. 7) pour Zg, il suffit de prouver l'injectivité de

$$H^n_c(A, \mathscr{F}_1) \stackrel{\sigma^*}{\to} H^n_c(X, \mathscr{F}_1) = H^n_c(X, E_\lambda) \stackrel{j_1}{\to} H^n(Z, E_\lambda).$$

**On** a Tr(ûu *b)==- Tr(j\G\*auj^(s\*b),* donc cette injectivité résulte de (ii). *P*

(8.6) Prouvons (8.5) (iii). Soient Pg l'espace projectif sur F^ complété de AQ par adjonction d'un hyperplan à l'infini Pô", HoCPo° d'équation Q^=o et Yo le revêtement de PQ normalisé de P() dans XQ.

$$(8.6.1) \qquad \begin{array}{c} X_0 & \longleftrightarrow & Y_0 \\ \downarrow & & \downarrow \\ A_0 & \longleftrightarrow & P_0 & \longleftrightarrow & P_0^\infty & \longleftrightarrow & H_0 \end{array}$$

Étudions YQ/PO près de l'infini, localement pour la topologie étale.

*Lemme* (8.7). — Yo *est lisse en dehors de l'image réciproque de* Ho.

Le diviseur de la fonction rationnelle Q^sur PQ est somme de sa partie finie div(QJ^ et de (—*d )* fois l'hyperplan à l'infini. **On a :**

(8.7.1) 
$$\operatorname{div}(\mathbf{Q}) = \operatorname{div}(\mathbf{Q})_f - dP_0^{\infty}$$
$$\operatorname{div}(\mathbf{Q})_f \cap P_0^{\infty} = H_0.$$

A distance finie, Yo *=* Xo est étale sur AQ, donc lisse. A l'infini, mais en dehors de l'image réciproque de Ho, il existe des coordonnées locales (^, . .., -?J telles que 0^=^^ (ceci utilise que (</,j&)==i). Dans ces coordonnées, Yo apparaît comme produit d'une courbe et d'un espace lisse (correspondant aux coordonnées ^g, .. ., 2'J. Par normalité, il est lisse.

*Lemme* **(8.8).** — *Au voisinage étale d'un point au-dessus de* **Ho,** Yo *est lisse sur une surface singulière normale*, *toujours la même.*

**On** peut cette fois trouver des coordonnées locales telles que O^^f^a- ^<sup>n</sup> effet, puisque Ho est lisse, div(QJ^ est lisse au voisinage de l'infini et coupe Po° transversalement. Cette forme est indépendante du point choisi, et n'utilise que deux coordonnées, d'où l'assertion.

(8.9) On sait que le procédé suivant (dû à Zariski) permet de résoudre les singularités de surfaces : alternativement, on normalise et on éclate le lieu singulier (réduit). Les opérateurs en jeu commutent à la localisation étale et au produit par un espace lisse. Le procédé de Zariski permet donc encore de résoudre les singularités d'un espace qui, comme Yo, est, localement pour la topologie étale, lisse sur une surface. La résolution obtenue de Yo est le ZQ cherché.

Si T est une courbe sur une surface S, contenant le lieu singulier, et que T' est l'image réciproque de T dans la résolution de Zariski S' de S, on sait que si on éclate de façon itérée dans S' le lieu singulier (réduit) de  $(T')_{red}$ , on obtient une surface S' telle que l'image réciproque réduite  $(T'')_{red}$  de T dans S' soit un diviseur à croisements normaux. A nouveau, les opérations en jeu commutent à la localisation étale et au produit par un espace lisse. Raisonnant comme plus haut, et observant que  $(Y_0, l'infini)$  est localement lisse sur un (S, T), on peut même trouver  $Z_0$  tel que  $Z_0-X_0$  soit un diviseur à croisements normaux.

(8.10) Prouvons (8.5) (i), (ii). Ce sont des assertions géométriques; ceci nous permet de travailler dorénavant sur  $\overline{\mathbf{F}}_q$ . Soit S' l'espace affine sur  $\overline{\mathbf{F}}_q$  qui paramétrise les polynômes à n variables de degré  $\leq d$ , et soit S l'ouvert de S' correspondant aux polynômes dont la partie homogène de degré d est de discriminant non nul. On note  $\mathbf{Q}_8 \in \mathbf{H}^0(\mathbf{S}, \mathcal{O}_8[x_1, \ldots, x_n])$  le polynôme universel sur S, et  $\mathbf{X}_8$  le revêtement galoisien étale de  $\mathbf{A}_8 = \mathbf{A}^n \times \mathbf{S}$  d'équation  $\mathbf{T}^p - \mathbf{T} = \mathbf{Q}_8$ , de groupe de Galois  $\mathbf{Z}/p$ . Soient  $\mathbf{P}_8 = \mathbf{P}^n \times \mathbf{S}$  l'espace projectif sur S complété de  $\mathbf{A}_8$  et  $\mathbf{Y}_8$  le normalisé de  $\mathbf{P}_8$  dans  $\mathbf{X}_8$ . On dispose, sur S, d'un diagramme analogue à (8.6.1).

Les expressions de Q en coordonnées locales données en (8.7) et (8.8) restent valables dans la situation présente, avec paramètres, de sorte que, localement pour la topologie étale sur  $Y_8$ ,  $Y_8/S$  est isomorphe au produit de S (qui est lisse) avec une fibre. La méthode canonique de résolution utilisée en (8.9) nous fournit une compactification relative  $Z_8/S$  de  $X_8/S$ , avec  $Z_8-X_8$  un diviseur à croisements normaux relatifs sur S

$$\begin{array}{ccc} X_8 & \stackrel{u}{\longleftrightarrow} & Z_8 \\ \downarrow^{\sigma} & & \downarrow^{f} \\ A_8 & \stackrel{a}{\longleftrightarrow} & S \end{array}$$

(f propre et lisse, u plongement ouvert,  $Z_s-X_s$  diviseur à croisements normaux relatifs).

Soit  $\mathscr{F}_{j,\,8}$  le  $E_\lambda$ -faisceau sur  $A_s$  déduit comme en (8.4) de  $X_s/A_s$ . On a  $\sigma_{\bullet}E_{\lambda}= \bigoplus \mathscr{F}_{i,\,8},$  donc

$$R^*(fu)_!(E_{\lambda}) = \bigoplus_j R^*a_! \mathscr{F}_{j,S}.$$

Les propriétés de  $Z_8$  assurent que les  $R^i(fu)_1E_\lambda=R^if_*(u_1E_\lambda)$  sont des faisceaux localement constants sur S. Dès lors, les  $R^ia_1\mathscr{F}_{j,8}$  également sont localement constants. Puisque S est connexe, il suffit de prouver (8.5) (i), (ii) pour un polynôme Q particulier. On prendra  $Q=\sum_i x_i^d$ . Ce polynôme vérifie la condition de non-singularité car (d,p)=1. Pour ce polynôme, les variables se séparent dans la somme exponentielle de (8.4). Ceci correspond au fait que  $\mathscr{F}_j$  est le produit tensoriel des images réciproques de

faisceaux analogues  $\mathscr{F}_j^1$  sur les facteurs de dimension un  $A^1$  de  $A = A^n$ . Par la formule de Künneth

$$H^*(A, \mathscr{F}_i) = \bigotimes H^*(A^1, \mathscr{F}_i^1).$$

Ceci ramène la preuve de (8.5) (i), (ii) au cas où n=1 et où Q est  $x^d$ .

(8.11) Traitons ce cas particulier. Le revêtement X de A est irréductible, de sorte que pour i=0,2

$$H_c^i(A, E_\lambda) \stackrel{\sim}{\to} H_c^i(X, E_\lambda)$$
.

Pour  $i \neq 1$  et  $j \neq 0$ , on a donc

$$H_c^i(A, \mathscr{F}_i) = 0.$$

L'assertion (ii) résulte de (2.8) ou (2.12) et de ce que  $u_1 \mathscr{F}_j = u_* \mathscr{F}_j$ . Pour prouver (i), il reste à vérifier que

$$\chi_c(\mathbf{A}, \mathscr{F}_i) = \mathbf{I} - d.$$

D'après la formule d'Euler-Poincaré (voir l'exposé Bourbaki 286 de février 1965, par M. Raynaud), ceci équivaut au lemme suivant.

Lemme (8.12). — Le conducteur de Swan de  $\mathcal{F}_j$  à l'infini est égal à d. Cet énoncé équivaut au suivant.

Lemme (8.13). — Soient k un corps fini de caractéristique p,  $y \in k[[x]]$  un élément de valuation d première à p, L l'extension de K = k((x)) engendré par les racines de  $T^p - T = y^{-1}$  et  $\chi$  le caractère suivant de Gal(L/K) à valeurs dans Z/p:

$$\chi(\sigma) = \sigma T - T$$
.

Alors,  $\chi$  est de conducteur d+1.

Par extension du corps résiduel, on se ramène à supposer k algébriquement clos plutôt que fini, et on applique : J. P. Serre, Sur les corps locaux à corps résiduel algébriquement clos, *Bull. Soc. Math. France*, 89 (1961), p. 105-154, nº 4.4.

## BIBLIOGRAPHIE

- [1] A. Grothendieck, Formule de Lefschetz et rationalité des fonctions L, Séminaire Bourbaki, 279, décembre 1964 (Benjamin).
- [2] S. Lefschetz, L'analysis situs et la géométrie algébrique (Gauthier-Villars), 1924. Reproduit dans : Selected papers (Chelsea Publ. Co.).
- [3] R. A. RANKIN, Contributions to the theory of Ramanujan's function τ(n) and similar arithmetical functions. II, Proc. Camb. Phil. Soc., 35 (1939), 351-372.

306

- [4] A. Weil, Numbers of solutions of equations in finite fields, Bull. Am. Math. Soc., 55 (1949), p. 497-508.
- SGA, Séminaire de Géométrie Algébrique du Bois-Marie (IHES) :
- SGA 4, Théorie des topos et cohomologie étale des schémas (dirigé par M. Artin, A. Grothendieck et J.-L. Verdier), Lecture Notes in Math., 269, 270, 305.
- SGA 5, Cohomologie l-adique et fonctions L, diffusé par l'IHES.
- SGA 7, Groupes de monodromie en géométrie algébrique.
  - 1re partie : dirigé par A. Grothendieck, Lecture Notes in Math., 288.
  - 2e partie : par P. Deligne et N. Katz, Lecture Notes in Math., 340.

Manuscrit reçu le 20 septembre 1973.
