- b) *Si les cycles gvanescents sont nuls :* (C'est 1~ un cas exceptionnel. Puisque (S, S) = 2 pour n pair, il ne peut se produire que pour n impair : n----2m + i. On notera que si un cycle dvanescent est nul, ils le sont tous, car conjuguds.)
  - i) Pour i + n + I, le faisceau Rif. Q,t es{ constant.
  - 2) On a une suite exacte

$$0 \to \bigoplus_{s \in S} \mathbf{Q}_{\ell}(m-n)_s \to \mathbb{R}^{n+1} f_* \mathbf{Q}_{\ell} \to \mathscr{F} \to 0$$

avec 5;" constant.

- 3) E=o.
- (5-9) Le sous-espace Erie de E est le noyau de la restriction ~ E de la forme d'intersection Tr(xuy). Cette forme induit done une forme bilin~aire non ddgdndrde

$$\psi: \mathbf{E}/(\mathbf{E} \cap \mathbf{E}^{\perp}) \otimes \mathbf{E}/(\mathbf{E} \cap \mathbf{E}^{\perp}) \to \mathbf{Q}_{\ell}(-n),$$

altern~e pour n impair, et sym6trique pour n pair. Cette forme est respectde par la monodromie; pour n impair, la reprdsentation de monodromie induit done

$$\rho: \pi_1(\mathbf{U}, u) \to \operatorname{Sp}(\mathbf{E}/(\mathbf{E} \cap \mathbf{E}^1), \psi).$$

*TMorkme* (5. xo) (Kajdan-Margulis). -- *L'image de p est ouverte.* 

L'image de p est un sous-groupe compact, donc analytique g-adique, de Sp(E/(EnE• II sufiit de montrer q~ie son alg~bre de Lie t2 est dgale sp(E/(E n El), +). L'analogue transcendant de cette alg~bre de Lie est l'alg~bre de Lie de l'adMrence de Zariski du groupe de monodromie.

On dfiduit de (5.8) que ~ est engendrde par les transformations de carrd nul

$$N_s: x \mapsto (x, \delta_s)\delta_s \quad (s \in S)$$

et que E/(EnE • est une repr6sentation absolument irrdductible de E. Le thdor~me r6sulte du lemme suivant.

- Lemme (5. x x ). -- *Soient V un espace vectoriel de dimension finie sur un corps k de caractgristique o, d? une forme altern6e non dgggn&& et P~ une sous-alg~bre de Lie de* 5p(V, +). *On suppose que :* 
  - (i) V *est une representation simple de P,.*
- (ii) 2 *est engendrge par une famille d'endomorphismes de V de la forme x~-~d/(x, 3)8. Alors, 52* =~p(V, +).

On peut supposer et on supposera que V, done ~, est non nul. Soit WcV l'ensemble des SeV tels que N(S) : *x~-,dg(x, 3)S* soit dans E.

- *a)* W cst stable par homoth6tie (car 52 est un sous-espace vectoriel de gI(V)).
- *b)* Si SeW, exp(ZN(S)) est un automorphisme de (V, +, ~), done transforme W en lui-m~me. Si S', S"eW, on a done exp(XN(S')).S"=S"-t-Z+(S",S')S'eW; si +(S', S")+o, le sous-espace vectoriel tendia par S' et S" est dans W.

*c)* I1 en r~sulte que West r~union de ses sous-espaces lin6aires maximaux W,, et que ceux-ci sont deux ~ deux orthogonaux. Chaque W, est d~s lors stable sous les N(8) (~eW), done stable sous !~. Vu l'hypoth~sc (i), W~=V et E contient tous les N(8) pour ~eV. On conclut en notant que l'alg~bre de Lie ~p(V, +) est engendrde par les N(~) (~V).

*Remarque* (5. I2) (inutile pour Ia suite). -- I1 est maintenant facile de prouver (I. 6) pour une hypersurface de dimension impaire n dans P~,q+ I.

Soient X 0 une telle hypersurface, et Xo l'hypersurface sur H e qui s'en ddduit par extension des scalaires. On a

$$\mathbf{H}^{2i}(\overline{\mathbf{X}}_{\mathbf{0}}, \mathbf{Q}_{t}) = \mathbf{Q}_{t}(-i) \quad (0 \leq i \leq n);$$

H2i(}~0, *Qt(i))* est engendr6 par la i ~m~ cup-puissance de ~, la classe de cohomologic q(O(I)) d'une section hyperplane. On a done

$$Z(X_0, t) = \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^n(\overline{X}_0, \mathbf{Q}_t)) / \prod_{i=0}^n (\mathbf{I} - q^i t)$$

et dct(x--F't, H"(Xo, Qt)) est un polyn6me ~ coefficients entiers inddpendants de t.

Faisons varier X odans un pinceau de Lefschetz d'hypersurfaces, qui soit d~fini sur Fe (cf. (5.7) pour X=P"+I; l'existence d'un tel pinceau n'est pas claire; si on voulait compl6ter l'argument esquissd ici, il faudrait recourir aux arguments qui seront donn~s en (7. i)). On vdrifie que E coincide ici avec le H a tout entier, et (3-2) fournit la conjecture de Weil pour toutes les hypersurfaces du pinceau, en particulier pour X o.

- (5. z3) *Indications bibliographiques sur les ~ 4 et 5.*
- A) Les r6sultats de Lefschetz (4. I) et (5. I) ~ (5"5) sont contenus dans son livre [2]. Pour la thdorie locale (4. I), il peut ~tre plus commode de consulter SGA 7, XIV (3.2).
  - B) Les r6sultats du w 4 sont ddmontrds dans les expos6s XIII, XIV et XV de SGA 7.
  - C) (5.7) est ddmontr6 dans SGA 7, XVII.
- D) (5.8) est ddmontrd dans SGA 7, XVIII. Le thdor~me d'irrdductibilitd y est ddmontrd pour E, mais seulement sous l'hypoth~se que E r~ E • ={o}. La ddmonstration dans le cas gdndral (pour E/(EnE• est pareille.

## **6. Un th~ortlne de ratlonalit6.**

(6. x) Soient Po un espace projectif de dimension >i sur F~, X0cPo une vari6td projective non singuli~re, A ocP0 un sous-espace lindaire de codimension deux, DocP o la droite duale, Fq une cl6ture alg~brique de Fq et P, X, A, D sur Fq ddduits de lFo, No,

 $A_0$ ,  $D_0$  par extension des scalaires. Le diagramme (5.1.1) de (5.6) provient d'un diagramme analogue sur  $\mathbf{F}_q$ :

$$\begin{array}{ccc} X_0 & \stackrel{\pi_\bullet}{\longleftarrow} & \widetilde{X}_0 \\ & & & \downarrow^{f_0} \end{array}$$
 (6.1.1)

On suppose que X est connexe de dimension paire n+1=2m+2, et que le pinceau  $(X_i)_{i\in D}$  de sections hyperplanes de X défini par D est un pinceau de Lefschetz. L'ensemble S des  $t\in D$  tels que  $X_i$  soit singulier est défini sur  $F_q$ , i.e. provient de  $S_0\subset D_0$ . On pose  $U_0=D_0-S_0$  et U=D-S.

Soit  $u \in U$ . La partie évanescente de la cohomologie  $E \subset H^n(X_u, \mathbf{Q}_\ell)$  est stable sous  $\pi_1(U, u)$ , donc définit sur U un sous-système local  $\mathscr E$  de  $R^n f_* \mathbf{Q}_\ell$ . Ce dernier est défini sur  $\mathbf{F}_q$ :  $R^i f_* \mathbf{Q}_\ell$  est l'image réciproque du  $\mathbf{Q}_\ell$ -faisceau  $R^i f_0 * \mathbf{Q}_\ell$  sur  $D_0$ , et, sur U,  $\mathscr E$  est l'image réciproque d'un sous-système local

$$\mathscr{E}_0 \subset \mathbb{R}^n f_0, \mathbf{Q}_\ell$$

Le cup-produit est une forme alternée

$$\psi: \mathbf{R}^n f_0 \cdot \mathbf{Q}_{\ell} \otimes \mathbf{R}^n f_0 \cdot \mathbf{Q}_{\ell} \to \mathbf{Q}_{\ell}(-n).$$

Notant  $\mathscr{E}_0^{\perp}$  l'orthogonal de  $\mathscr{E}_0$  relativement à  $\psi$ , dans  $\mathrm{R}^{\bullet}f_0 \cdot \mathbf{Q}_{\ell} | U_0$  on voit que  $\psi$  induit une dualité parfaite

$$\psi:\,\mathscr{E}_0/(\mathscr{E}_0\cap\mathscr{E}_0^\perp)\otimes\mathscr{E}_0/(\mathscr{E}_0\cap\mathscr{E}_0^\perp)\to\mathbf{Q}_\ell(-n).$$

Théorème (6.2). — Pour tout  $x \in |U_0|$ , le polynôme  $\det(I - F_x^* t, \mathscr{E}_0 / (\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}))$  est à coefficients rationnels.

Corollaire (6.3). — Soiert  $j_0$  l'inclusion de  $U_0$  dans  $D_0$ , et j celle de U dans D. Les valeurs propres de  $F^*$  agissant sur  $H^1(D,j_*\mathcal{E}/(\mathcal{E}\cap\mathcal{E}^1))$  sont des nombres algébriques dont tous les conjugués complexes  $\alpha$  vérifient

$$q^{\frac{n+1}{2}-\frac{1}{2}} \le |\alpha| \le q^{\frac{n+1}{2}+\frac{1}{2}}.$$

D'après (5.10) et (6.2), les hypothèses de (3.2) sont en effet vérifiées par  $(U_0, \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}), \psi)$ , pour  $\beta = n$ , et on applique (3.9).

Lemme (6.4). — Soit  $\mathscr{G}_0$  un  $\mathbf{Q}_{\ell}$ -faisceau constant tordu sur  $\mathbf{U}_0$ , tel que son image réciproque  $\mathscr{G}$  sur  $\mathbf{U}$  soit un faisceau constant. Il existe alors dans  $\overline{\mathbf{Q}}_{\ell}$  des unités  $\alpha_{\ell}$  telles que, pour tout  $x \in ]\mathbf{U}_0[$ , on ait

$$\det(\mathbf{I}-\mathbf{F}_x^{\bullet}t,\,\mathscr{G}_0)=\prod_i \big(\mathbf{I}-\alpha_i^{\deg(x)}t\big).$$

Ce lemme exprime quc go cst l'image rdciproque d'un faisceau sur Spec (Fq), ~ savoir son image directe sur Spec(Fq). Ce dernier s'identifie ~ une reprdsentation g-adique Go de Gal(Fq/Fq), et on prend

$$\det(\mathbf{I} - \mathbf{F}t, \mathbf{G}_0) = \prod_i (\mathbf{I} - \alpha_i t).$$

Le lemme (6.4) s'applique aux R~fo.Q.t *(i:~n), ~ R"fo,~t/8 o* et ~ g0nSo •

Pour xe]Uol la fibre X,=fo~(X) est une varidtd sur le corps fini *k(x).* Si ~ est un point de U au-dessus de x, Xz se d~duit de X, par extension des scalaires de *k(x)*  sa cl6ture algfibrique k(~-):Fq, et H~(X~, Qt) est la fibre de R~.O.~t en ~. La formule (I.5.4) pour la vari~td X, sur *k(x)* s'~crit donc

$$Z(X_x, t) = \prod_i \det(\mathbf{1} - \mathbf{F}_x^* t, \mathbf{R}_f^i f_0 \cdot \mathbf{Q}_f)^{(-1)^{i+1}}$$

et Z(X,, t) est le produit de

$$\begin{split} Z' &= \det(\mathbf{I} - \mathbf{F}_x^*t, \, \mathbf{R}^n f_0 \boldsymbol{\cdot} \mathbf{Q}_\ell / \mathscr{E}_0) \cdot \det(\mathbf{I} - \mathbf{F}_x^*t, \, \mathscr{E}_0 \cap \mathscr{E}_0^\perp) \cdot \prod_{i \neq n} \det(\mathbf{I} - \mathbf{F}_x^*t, \, \mathbf{R}^i f_0 \boldsymbol{\cdot} \mathbf{Q}_\ell)^{(-1)^{i+1}} \\ \text{par} &\qquad \qquad Z''' = \det(\mathbf{I} - \mathbf{F}_x^*t, \, \mathscr{E}_0 / (\mathscr{E}_0 \cap \mathscr{E}_0^\perp)). \end{split}$$

Posons ~o=g0/(gong01), o~-=g/(gng • et appliquons (6.4) aux facteurs de Z t. On trouve qu'il existe des unit~s g-adiques ~ (I < i<N) et [~ (I 5j<M) dans Qt tels que pour tout x~[Uo[

$$Z(\mathbf{X}_{z},t)\!=\!\frac{\prod\limits_{i}(\mathbf{1}-\alpha_{i}^{\deg x}t)}{\prod\limits_{i}(\mathbf{1}-\beta_{i}^{\deg x}t)}.\det(\mathbf{1}-\mathbf{F}_{z}^{\star}t,\mathscr{F}_{0})$$

et qu'en particulier le second membre est dans Q(t). Si un ai coincide avec un ~, il est loisible de supprimer simultandment cet a i de la liste des ~ et ce [~ de la liste des 9. On peut donc supposer, et nous supposerons, que ai4= ~ pour tout iet tout j.

(6.5) II suffit de prouver que lcs polyn6mes I-I(i--a,t) et 1~. (I-~jt) sont i 3 coefficients rationnels, i.e. que la famille des a~ (resp. la famille des ~) est ddfinie sur Q. Nous le ddduirons des propositions suivantes.

*Proposition* (6.6). -- *Soient* (~,i) (I < i < P) *et* (Sj) (I <j<Q) *deux familles d'unitds t-adiques dans Qt. On suppose que Ti+8~. Si K est un ensemble fini assez grand d'entiers 4 = I, et L une partie de densitd o assez grande de* [Uol, *alors, si* xelUo] vdr/fie k~'deg(x) *(pour tout*  keK) *et x\$L, le ddnominateur de* 

(6.6.1) 
$$\det(\mathbf{I} - \mathbf{F}_x^* t, \mathscr{F}_0) \prod_i (\mathbf{I} - \gamma_i^{\deg(x)} t) / \prod_j (\mathbf{I} - \delta_j^{\deg(x)} t),$$

*gcrit sous forme irre'ductible, est ~* (I--~e'Cxlt). *3* 

La d~monstration sera donnde en (6. IO-I 3). D'apr6s (6.7) ci-dessous, (6.6) fournit

une description intrins~que de la famille des 3i en terme de la famille des fractions rationnelles (6.6. i) pour x~]Uol.

*Lemme* (6.7).--SoientKunensemblefinid'entiers *:~ I et* (~) (I~j~Q) *et (ej)* (I<j<Q) *deux familles d'glgments d'un corps. Si, pour tout n assez grand, non divisible par aucun des keK, la famille des 3~ coincide avec celle des ~.~ (d l'ordre prks), alors la famille des ~j coincide avec celle des cj (a l'ordre prks).* 

On proc~de par rdcurrence sur Q. L'ensemble des entiers n tels que ~= ~ est un id6al *(nj).* Prouvons qu'il existe Jo tel que 8q = r Sinon les *nj* seraient distincts de I, et il existerait des entiers arbitrairement grands n, non divisibles par aucun des n~, ni par aucun des keK. On aurait ~4~, et ceci contredirait l'hypoth~se. II existe done J0 tel que 8q=ej. On eonclut en appliquant l'hypoth6se de r6currence aux familles (~j) (j # Q) et (r (j #J0).

*Proposition* (6.8). -- *Soient* (Yi) (x<i~P) *et* (3j) (x<j<Q) *deuxfamilles d'unitgs p-adiques dans f)..t,* R-(t)= ,H. (I--V,t) *et S(t)-~H(r-Sjt ). Supposons que pour tout* xeiU0l , (I -- ~~ *divise* 

$$\prod_{i} (\mathbf{I} - \mathbf{Y}_{i}^{\deg(x)} t) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*} t, \mathscr{F}_{0}).$$

**i** 

*Alors* S(t) *divise* R(t).

Supprimons des familles (u et (~j) des paires d'616ments communs jusqu'~t v6rifier l'hypoth~se de (6.6). Appliquons (6.6). Par hypoth~se, les fractions rationnelles (6.6. i) sont des polyn6mes. Aucun 8 n'a done subsist6, ce qui signifie que S(t) divise R(t).

Cette proposition fournit une caract6risation intrins~que de R(t) en terme de la famille de polyn6mes

$$\prod_{i} (\mathbf{1} - \gamma_i^{\deg(x)} t) \cdot \det(\mathbf{1} - \mathbf{F}_x^* t, \mathscr{F}_0).$$

C'est le ppcm des polyn6mes S(t)=[[(i--Sjt) v6rifiant l'hypoth~se de (6.8). 3

(6.9) Prouvons (6.5) et done (6.2) (modulo (6.6)). Faisons dans (6.6) (Yi)=(ai) et (Sj)=(~j). On trouve une caractdrisation intrins~que de la famille des ~j en terme de la famille de fractions rationnelles Z(X~, t) (xelU0[). Celles-ci 6tant dans Q(t), la famitle des ~j est d6finie sur Q.

Les polyn6mes [I(I--~~ sont donc dans o It]. La proposition (6.8) fournit une description intrins~que de la famille des ai en terme de cette famille de polyn6mes. La famille des ai est donc ddfinie sur Q,.

(6. xo) *PrJliminaires. --* Soient u~U et ~ la fibre de ~- en u. Le groupe fondamentat arithm~tique ~l(U0, u), extension de Z=Gal(Fq/Fq) (gdndrateur : q~) par le groupe fondamental gdomdtrique =I(U, u), agit sur ~ par similitudes symplectiques :

$$\rho: \pi_1(\mathbf{U}_0, u) \to \mathrm{CSp}(\mathscr{F}_u, \psi).$$

Nous notons p~(g) le multiplicateur d'une similitude symplectique g. Soit

$$\mathbf{H} \subset \widehat{\mathbf{Z}} \times \mathbf{CSp}(\mathscr{F}_{\mathbf{u}}, \psi)$$

le sous-groupc ddfini par l'dquation

$$q^{-n} = \mu(g)$$

(q &ant une unitd g-adique, *q"eO~t* est ddfini pour tout neT.). Le fair que + soit ~ valeurs dans Qt(-- n) s'exprime en disant que l'application de ~ dans ~. • de eoordonndes la projection canonique sur 7. et p, se factorise par

$$\rho_1: \ \pi_1(\mathbf{U}_0, u) \to \mathbf{H}.$$

*Lemme* (6.ix). -- *L'image H~ de p~ est ouverte darts H.* 

En effet, 7r~(Uo, u) se projette *sur Z,* et l'image de n~(U, u)----Ker(~(Uo, u)-+Z) dans Sp(~, +)=Ker(H~Z) est ouverte (5. io).

*Lemme* (6. xz). -- *Pour ~e~t une unit~ t-adique, l' ensemble Z des (n, g)eH 1 tels que ~" soit valeur propre de g est un ferm3 de mesure nulle.* 

II est clair que Z est fermd. Pour ehaque ncZ, soit CSp, l'ensemble des gcCSp(o~, +) tels que fz(g)=q-", et soit Z, l'ensemble des gcGSp, tels que ~" soit valeur propre de g. Alors, GSp, est un espace homog~ne sous Sp, et on vdrifie que Z, enest un sous-espaee algdbrique propre, done de mesure o. D'apr~s (6. i i), H x n ({n} • Z,) est done de mesure o dans l'image inverse dans H 1 de n, et on applique Fubini ~ la projection Hi-+ 7..

(6.x3) Prouvons (6.6). Pour chaque i et j, l'ensemble des entiers n tels que y~'=3~ est l'ensemble des multiples d'un entier fixe n o (on n'exclut pas n 0=o). Par hypoth~se, no4: I.

D'apr~s (6. ~) et le thdor~me de densitd de Cebotarev, l'ensemble des xelU01 tels qu'un ~0g(,) soit valeur propre de F\*, agissant sur ~0 est de densitd o. On prend pour K l'ensemble des n~ et pour L l'ensemble des x ci-dessus.

## **7. Fin de la d~monstral~on de 1.7o**

*Lemme* (7-x). -- *Soit* X 0 *une varidtg pr@ctive non singuli~re absolument irrgductible de dimension* paire *d sur Fq. goient X sur Fq dMuit de X o par extension des scalaires et o~ une valeur propre de F\* agissant sur* Ha(X, *Qt). Alors, ~ est un nombre alggbrique dont tousles conjugugs complexes, encore notgs o~, vgrifient* 

(7.1.1) 
$$q^{\frac{d}{2}-\frac{1}{2}} \leq |\alpha| \leq q^{\frac{d}{2}+\frac{1}{2}}.$$

On procAde par rdcurrence sur d (toujours supposd pair). Le cas d-~ o est trivial, mfime sans supposer X o absolument irrdductible; on suppose dordnavant d~2. On pose *d = n + I = 2m + 2.* 

Si Fr est une extension de degrd r de F~ et que Xs162 se ddduit de X0/F , par extension des scalaires, l'assertion (7-i) pour Xo/F q dquivaut ~t (7. i) pour X~/Fd : de mdme que q est remplacd par q', les valeurs propres de F\* sont remplacdes par leurs puissances r i~e~.

D'apr~s (5.7), dans un plongement projectif convenable i : X-+P, X admet un pinceau de Lefsehetz de sections hyperplanes. La remarque pr&ddente nous permet de supposer i et ce pinceau ddfmis sur Fq (quitte ~ remplacer Fq par une extension finie).

Supposons done qu'il existe sur Fq un plongement projectif X0~P 0 et un sousespace de codimension deux A o de Po qui ddfinisse un pinceau de Lefschetz. On reprend les notations de (6. I) et (6.3). Une nouvelle extension des scalaires nous ram~ne supposer que :

- *a)* Les points de S sont ddfinis sur Fq.
- *b)* Les cycles dvanescents en x, (seS) sont ddfinis sur Fq (puisque seul -t-8 est intrins~que, ils pourraient n'&re ddfinis que sur une extension quadratique).
- *c)* I1 existe un point rationnel u0eU 0. On prend le point correspondant u de U comme point base.
- *d)* X~=fo-l(u0) admet une section hyperplane lisse Y0, ddfinie sur F~. On pose Y=Yo|

Puisque X se ddduit de X par &latement de la sous-vari&6 lisse de codimension deux AnX, ona

$$H^i(X,\, {\bf Q}_\ell) \hookrightarrow H^i(\widetilde{X},\, {\bf Q}_\ell)$$

(en fait, Hi(X, Qt):H~(X, Qt)| Qt)(--I)). I1 suffit done de prouver (7. i. x) pour lcs valeurs propres ~ de F" agissant sur Ha(:K, Qt).

La suite spectrale de Lcray pour f s'&rit

$$\mathbf{E}_{2}^{pq} = \mathbf{H}^{p}(\mathbf{D}, \mathbf{R}^{q} f_{\bullet} \mathbf{Q}_{t}) \Rightarrow \mathbf{H}^{p+q}(\widetilde{\mathbf{X}}, \mathbf{Q}_{t}).$$

I1 suffit de prouver (7. I. I) pour les valeurs propres a de F ~ agissant sur les E~ pour *p+q=d=n+i.* Ce sont :

A) 
$$E_2^{2,n-1}$$
. D'après (5.8),  $R^{n-1}f_{\bullet}\mathbf{Q}_{\ell}$  est constant. D'après (2.10), on a donc 
$$E_2^{2,n-1} = H^{n-1}(X_u, \mathbf{Q}_{\ell})(-1).$$

D'apr~s le thdor~me de Lefschetz faible (corollaire de SGA 4, XIV (3- 2), et de ta dualit6 de Poincar6, SGA 4, XVIII), on a

$$\mathrm{H}^{n-1}(\mathrm{X}_u,\,\mathbf{Q}_t)(-1)\hookrightarrow\mathrm{H}^{n-1}(\mathrm{Y},\,\mathbf{Q}_t)(-1),$$

et on applique l'hypothfise de r&urrence ~ Y0.

B) E ~ Si les cycles 6vanescents sont non nuls, R"+lf.Ot est constant et E~ = H"+I(X~, Q,t).

Le morphisme de Gysin

$$H^{n-1}(Y, \mathbf{Q}_{\ell})(-1) \to H^{n+1}(X_{\mu}, \mathbf{Q}_{\ell})$$

est surjeetif (cet argument est dual de A)), et on applique l'hypoth~se de r~currence k Y0- Si les cycles dvanescents sont nuls, la suite exacte de (5.8) b) fournit une suite exaete

$$\bigoplus_{i\in S} \mathbf{Q}_i(m-n) \to \mathrm{E}_2^{0,n+1} \to \mathrm{H}^{n+1}(\mathrm{X}_u,\,\mathbf{Q}_i).$$

La valeur propre de F agissant sur *Q.t(m-n)* est *qda,* et H "+1 se traite comme plus haut.

C) E 2 1,. . Si on disposait du th~or6me de Lefschetz << difficile >>, on saurait que o~no ~• est nul, et que *R"f, Qt* est somme directe de j,g et d'un faisceau constant. Le It 1 d'un faisceau constant sur p1 est nul, et il suffirait d'appliquer (6.3).

Faute d'avoir d~jk ddmontr~ Lefschetz ~< difficile >>, il nous va falloir ddvisser. Si les cycles dvaneseents sont nuls, *R"f, Qt* est constant ((5.8) b)) et E~'n=o. On peut done supposer, et on supposera, les cycles ~vanescents non nuls. Filtrons *R"f,Q.t=Lj\*R"f,Q.t* (5.8) par les sous-faisceaux j,@ et j,(gtagl). Si les cycles dvanescents 8 ne sont pas dans griN• on dispose de suites exactes :

(7.1.2) 
$$0 \rightarrow j_* \mathscr{E} \rightarrow \mathbb{R}^n f_* \mathbf{Q}_{\ell} \rightarrow \text{faisceau constant} \rightarrow 0.$$

(7.1.3) 
$$0 \rightarrow \text{faisceau constant } j_{\bullet}(\mathscr{E} \cap \mathscr{E}^{\perp}) \rightarrow j_{\bullet}\mathscr{E} \rightarrow j_{\bullet}(\mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})) \rightarrow 0.$$

Si, ~ Dieu ne plaise, les ~ sont dans #ng z, on a ,~c# • et des suites exactes :

(7.1.4) 
$$0 \rightarrow lc$$
 faisceau constant  $j_{\bullet} \mathscr{E}^{\perp} \rightarrow R^{n} f_{\bullet} \mathbf{Q}_{l} \rightarrow un$  faisceau  $\mathscr{F} \rightarrow 0$ 

(7.1.5) 
$$0 \to \mathscr{F} \to \text{le faisceau constant } j_*j^*\mathscr{F} \to \bigoplus_{s \in S} \mathbf{Q}_t(n-m)_s \to 0.$$

Dans le premier cas, les suites exactes longues de cohomologie fournissent

$$(7.1.2') \qquad \qquad H'(D, j_*\mathscr{E}) \to H'(R^n f_* \mathbf{Q}_{\ell}) \to 0,$$

$$(7.1.3') \qquad \qquad 0 \rightarrow \mathrm{H}^1(\mathrm{D}, j_{\bullet}\mathscr{E}) \rightarrow \mathrm{H}^1(\mathrm{D}, j_{\bullet}(\mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})))$$

et on applique (6.3).

Dans le second cas, elles fournissent

$$(7.1.4') 0 \rightarrow H^1(D, \mathbb{R}^n f_* \mathbf{Q}_{\ell}) \stackrel{!}{\rightarrow} H^1(D, \mathcal{F}),$$

(7.1.5') 
$$\bigoplus_{l \in \mathcal{B}} \mathbf{Q}_{l}(n-m) \to \mathbf{H}^{1}(\mathbf{D}, \mathscr{F}) \to 0$$

et on remarque que F agit sur *Or(n--m)* par multiplication par q~a.

Lemme (7.2). -- *Soit* X 0 *une vari/t/ projective non singuli~re absolument irr/ductible de dimension d sur Fq. Soient X sur Fq d/duit de* X 0 *par extension des scalaires et ~ une valeur propre de F" agissant sur* Hd(X, *Q.t). Alors, o: est un nombre alg/brique dont tousles conjugugs complexes, encore not/s ~, vgrifient* 

$$|\alpha| = q^{d/2}$$
.

Prouvons déjà que  $(7,2)\Rightarrow (1,7)$ . Pour  $X_0$  projective non singulière sur  $\mathbf{F}_q$  et i un entier, il faut prouver l'assertion suivante :

 $W(X_{0,i})$ . Soit X déduit de  $X_0$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ . Si  $\alpha$  est une valeur propre de  $\mathbf{F}^*$  agissant sur  $\mathbf{H}^i(X, \mathbf{Q}_\ell)$ , alors  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient  $|\alpha| = q^{ii2}$ .

- a) Si  $\mathbf{F}_{q^n}$  est une extension de degré n de  $\mathbf{F}_q$ , et que  $\mathbf{X}_0'/\mathbf{F}_{q^n}$  se déduit de  $\mathbf{X}_0/\mathbf{F}_q$  par extension des scalaires, alors  $\mathbf{W}(\mathbf{X}_0,i)$  équivaut à  $\mathbf{W}(\mathbf{X}_0',i)$ : étendre les scalaires revient à remplacer  $\alpha$  par  $\alpha^n$  et q par  $q^n$ .
- b) Si  $X_0$  est purement de dimension n,  $W(X_0,i)$  équivaut à  $W(X_0,2n-i)$  : ceci résulte de la dualité de Poincaré.
  - c) Si  $X_0$  est somme de variétés  $X_0^{\alpha}$ ,  $W(X_0, i)$  équivant à la conjonction des  $W(X_0^{\alpha}, i)$ .
- d) Si  $X_0$  est purement de dimension n,  $Y_0$  une section hyperplane lisse de  $X_0$ , et que i < n, alors  $W(Y_0, i) \Rightarrow W(X_0, i)$ : ceci résulte du théorème de Lefschetz faible.

Pour prouver les assertions  $W(X_0, i)$ , on se ramène successivement :

- par c), à supposer X<sub>0</sub> purement d'une dimension n;
- par b), à supposer de plus  $0 \le i \le n$ ;
- par a) et d), à supposer de plus i=n;
- par a) et c), à supposer de plus X<sub>0</sub> absolument irréductible.

Ce cas est justiciable de (7.2).

(7.3) Prouvons (7.2). Pour tout entier k,  $\alpha^k$  est valeur propre de  $\mathbf{F}^*$  agissant sur  $\mathbf{H}^{kd}(\mathbf{X}^k, \mathbf{Q}_d)$  (formule de Künneth). Pour k pair,  $\mathbf{X}^k$  est justiciable de (7.1), d'où

$$q^{\frac{kd}{2} - \frac{1}{2}} \le |\alpha^k| \le q^{\frac{kd}{2} - \frac{1}{2}}$$

$$q^{\frac{d}{2} - \frac{1}{2k}} \le |\alpha| \le q^{\frac{\tilde{d}}{2} + \frac{1}{2k}}.$$

ct

Faisant tendre k vers l'infini, on trouve (7.2).

## 8. Premières applications.

Théorème (8.1). — Soit  $X_0 \subset \mathbf{P}_0^{n+r}$  une intersection complète non singulière sur  $\mathbf{F}_q$ , de dimension n et de multidegré  $(d_1, \ldots, d_r)$ . Soit b' le  $n^{\text{two}}$  nombre de Betti des intersections complètes non singulières complexes, de mêmes dimension et multidegré. Posons b=b' pour n impair, et b=b'-1 pour n pair. Alors

$$| \# \mathbf{X}_{\mathbf{0}}(\mathbf{F}_a) - \# \mathbf{P}^n(\mathbf{F}_a) | \leq b \cdot q^{n/2}$$
.

Soient  $X/\overline{F}_q$  déduit de  $X_0$ , et  $\mathbf{Q}_\ell$ ,  $\eta^i$  la droite dans  $H^{2i}(X, \mathbf{Q}_\ell)$  engendrée par la  $i^{2m_0}$  cup-puissance de la classe de cohomologie d'une section hyperplane. Sur cette droite,  $\mathbf{F}^*$  agit par multiplication par  $q^i$ . La cohomologie de X est somme des  $\mathbf{Q}_\ell$ ,  $\eta^i$ 

 $(o \le i \le n)$  et de la partie primitive de  $H^n(X, \mathbf{Q}_t)$ , de dimension b. D'après (1.5), il existe donc b nombres algébriques  $\alpha_j$ , les valeurs propres de  $F^*$  agissant sur cette cohomologie primitive, tels que

$$\# X_0(\mathbf{F}_q) = \sum_{i=0}^n q^i + (-1)^n \sum_i \alpha_i.$$

D'après (1.7),  $|\alpha_i| = q^{n/2}$  et

$$| \# \mathbf{X_0}(\mathbf{F_q}) - \# \mathbf{P}(\mathbf{F_q})| = | \# \mathbf{X_0}(\mathbf{F_q}) - \sum_{i=0}^n q^i| = |\sum_j \alpha_j| \leq \sum_j |\alpha_j| = b \cdot q^{n/2}.$$

Théorème (8.2). — Soient N un entier  $\geq 1$ ,  $\varepsilon : (\mathbf{Z}/N)^* \to \mathbf{C}^*$  un caractère, k un entier  $\geq 2$  et f une forme modulaire holomorphe sur  $\Gamma_0(N)$ , de poids k et de caractère  $\varepsilon : f$  est une fonction holomorphe sur le demi-plan de Poincaré X, telle que pour  $\begin{pmatrix} a & b \\ c & d \end{pmatrix} \in \operatorname{SL}(2,\mathbf{Z})$ , avec  $c \equiv 0$  (N), on ait

$$f\left(\frac{az+b}{cz+d}\right) = \varepsilon(a)^{-1}(cz+d)^k f(z).$$

On suppose f cuspidale et primitive (« new » au sens d'Atkin-Lehner et de Miyake), en particulier vecteur propre des opérateurs de Hecke  $T_p$  (p 
mathrix N). Posons  $f = \sum_{n=1}^{\infty} a_n q^n$ , avec  $q = e^{2\pi i a}$  (et  $a_1 = 1$ ). Alors, pour p premier ne divisant pas N

$$|a_p| \leq 2 \cdot p^{\frac{k-1}{2}}.$$

En d'autres termes, les racines de l'équation

$$T^2-a_nT+\varepsilon(p)\cdot p^{k-1}$$

sont de valeur absolue  $p^{\frac{k-1}{2}}$ .

Ces racines sont en effet des valeurs propres de Frobenius agissant sur le  $\mathbf{H}^{k-1}$  d'une variété projective non singulière de dimension k-1 définie sur  $\mathbf{F}_n$ .

Sous des hypothèses restrictives, ce fait est démontré dans mon exposé Bourbaki (Formes modulaires et représentations l-adiques, exposé 355, février 1969, dans : Lecture Notes in Mathematics, 179). Le cas général n'est pas beaucoup plus difficile.

Remarque (8.3). — J. P. Serre et moi-même avons récemment démontré que (8.2) reste vrai pour k=1. La démonstration est toute différente.

L'application suivante m'a été suggérée par E. Bombieri.

Théorème (8.4). — Soient Q un polynôme à n variables et de degré d sur  $\mathbf{F}_q$ ,  $\mathbf{Q}_d$  la partie homogène de degré d de  $\mathbf{Q}$  et  $\psi: \mathbf{F}_q \rightarrow \mathbf{C}^*$  un caractère additif non trivial sur  $\mathbf{F}_q$ . On suppose que :

- (i) d est premier à p;
- (ii) l'hypersurface  $H_0$  dans  $P_{F_a}^{n-1}$  définie par  $Q_d$  est lisse.