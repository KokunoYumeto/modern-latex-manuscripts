# La conjecture de Weil I

- Entry type: `paper`
- Source language guess: `french`
- Translation track: `transcription_plus_translation`
- Priority: `high`
- Source pages: `741-775`
- Source PDF: `C:\Users\Floris\Documents\Papors\OS\Deligne\01_papers\20_La_conjecture_de_Weil_I.pdf`
- Transcription status: `not_started`
- Translation status: `not_started`

## Notes

- Modern English title: The Weil conjecture I
- Manual note: (none)
