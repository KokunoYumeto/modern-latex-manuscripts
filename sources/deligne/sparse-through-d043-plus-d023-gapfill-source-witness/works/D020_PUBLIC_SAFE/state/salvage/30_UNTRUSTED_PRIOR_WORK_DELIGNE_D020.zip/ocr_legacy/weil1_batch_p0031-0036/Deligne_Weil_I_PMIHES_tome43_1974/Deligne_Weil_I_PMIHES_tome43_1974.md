$(o \le i \le n)$  et de la partie primitive de  $H^n(X, \mathbf{Q}_{\ell})$ , de dimension b. D'après (1.5), il existe donc b nombres algébriques  $\alpha_j$ , les valeurs propres de  $F^*$  agissant sur cette cohomologie primitive, tels que

$$\# X_0(\mathbf{F}_q) = \sum_{i=0}^n q^i + (-1)^n \sum_j \alpha_j.$$

D'après (1.7),  $|\alpha_i| = q^{n/2}$  et

$$| \# X_0(\mathbf{F}_q) - \# \mathbf{P}(\mathbf{F}_q) | = | \# X_0(\mathbf{F}_q) - \sum_{i=0}^n q^i | = | \sum_i \alpha_i | \leq \sum_i |\alpha_j| = b \cdot q^{n/2}.$$

Théorème (8.2). — Soient N un entier  $\geq 1$ ,  $\epsilon: (\mathbf{Z}/N)^* \to \mathbf{C}^*$  un caractère, k un entier  $\geq 2$  et f une forme modulaire holomorphe sur  $\Gamma_0(N)$ , de poids k et de caractère  $\epsilon: f$  est une fonction holomorphe sur le demi-plan de Poincaré X, telle que pour  $\begin{pmatrix} a & b \\ c & d \end{pmatrix} \in \mathrm{SL}(2,\mathbf{Z})$ , avec  $c \equiv 0$  (N), on ait

$$f\left(\frac{az+b}{cz+d}\right) = \varepsilon(a)^{-1}(cz+d)^k f(z).$$

On suppose f cuspidale et primitive (« new » au sens d'Atkin-Lehner et de Miyake), en particulier vecteur propre des opérateurs de Hecke  $T_p$  ( $p \nmid N$ ). Posons  $f = \sum_{n=1}^{\infty} a_n q^n$ , avec  $q = e^{2\pi i x}$  (et  $a_1 = 1$ ). Alors, pour p premier ne divisant pas N

$$|a_p| \leq 2 \cdot p^{\frac{k-1}{2}}.$$

En d'autres termes, les racines de l'équation

$$T^2 - a_p T + \varepsilon(p) \cdot p^{k-1}$$

sont de valeur absolue  $p^{\frac{k-1}{2}}$ .

Ces racines sont en effet des valeurs propres de Frobenius agissant sur le  $H^{k-1}$  d'une variété projective non singulière de dimension k-1 définie sur  $\mathbf{F}_p$ .

Sous des hypothèses restrictives, ce fait est démontré dans mon exposé Bourbaki (Formes modulaires et représentations  $\ell$ -adiques, exposé 355, février 1969, dans : Lecture Notes in Mathematics, 179). Le cas général n'est pas beaucoup plus difficile.

Remarque (8.3). — J. P. Serre et moi-même avons récemment démontré que (8.2) reste vrai pour k=1. La démonstration est toute différente.

L'application suivante m'a été suggérée par E. Bombieri.

Théorème (8.4). — Soient Q un polynôme à n variables et de degré d sur  $\mathbf{F}_q$ ,  $Q_d$  la partie homogène de degré d de Q et  $\psi: \mathbf{F}_q \rightarrow \mathbf{C}^*$  un caractère additif non trivial sur  $\mathbf{F}_q$ . On suppose que :

- (i) d est premier à p;
- (ii) l'hypersurface  $\mathbf{H}_0$  dans  $\mathbf{P}_{\mathbf{F}_q}^{n-1}$  définie par  $\mathbf{Q}_d$  est lisse.

302

Alors

$$\left|\sum_{x_1,\ldots,x_n\in\mathbb{F}_q} \psi(Q(x_1,\ldots,x_n))\right| \leq (d-1)^n q^{n/2}.$$

Quitte à remplacer Q par un multiple scalaire, on peut supposer (et on supposera) que

$$\psi(x) = \exp(2\pi i \operatorname{Tr}_{\mathbf{F}_d/\mathbf{F}_p}(x)/p).$$

Soit  $X_0$  le revêtement étale de l'espace affine  $A_0$  de dimension n sur  $\mathbf{F}_q$  d'équation  $T^p - T = Q$ , et soit  $\sigma$  la projection de  $X_0$  sur  $A_0$ :

$$\begin{split} &\sigma:\ \mathbf{X_0}\!\rightarrow\!\mathbf{A_0}\\ \mathbf{X_0}\!=\!\mathrm{Spec}(\mathbf{F}_q[\mathbf{x_1},\ \dots,\ \mathbf{x_n},\ \mathbf{T}]/(\mathbf{T}^p\!-\!\mathbf{T}\!-\!\mathbf{Q})). \end{split}$$

Le revêtement  $X_0$  est galoisien, de groupe de Galois  $\mathbf{Z}/p$ ;  $i \in \mathbf{Z}/p = \mathbf{F}_p$  agit par  $T \mapsto T + i$ . Soit  $x \in A_0(\mathbf{F}_q)$  et calculons l'endomorphisme de Frobenius de la fibre de  $X_0/A_0$  en x. Posons  $q = p^f$  et soit  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$ . Pour  $(x, T) \in X_0(\overline{\mathbf{F}}_q)$  au-dessus de x, on a  $F((x, T)) = (x, T^q)$ , et

$$T^{q} = T + \sum_{i=1}^{f} (T^{p^{i}} - T^{p^{i-1}}) = T + \sum_{i} Q(x)^{p^{i-1}} = T + Tr_{\mathbf{F}_{q}/\mathbf{F}_{p}}(Q(x)).$$

C'est l'action de l'élément  $\operatorname{Tr}_{\mathbf{F}_q/\mathbf{F}_p}(\mathbf{Q}(x))$  du groupe de Galois.

Soient E le corps des racines  $p^{i \ge mes}$  de l'unité et  $\lambda$  une place finie de E première à p. Nous travaillerons en cohomologie  $\lambda$ -adique. Pour  $j \in \mathbf{Z}/p$ , soit  $\mathscr{F}_{j,0}$  le  $\mathbf{E}_{\lambda}$ -système local de rang un sur  $\mathbf{A}_0$  défini par  $\mathbf{X}_0$  et  $\psi(-jx):\mathbf{Z}/p \to \mathbf{E}^* \to \mathbf{E}^*_{\lambda}$ : on dispose de  $\iota: \mathbf{X}_0 \to \mathscr{F}_{j,0}$  et  $\iota(i*x) = \psi(-ji)\iota(x)$ . Notons sans  $_0$  les objets déduits de  $\mathbf{A}_0$ ,  $\mathbf{X}_0$ ,  $\mathscr{F}_{j,0}$  par extension des scalaires à  $\overline{\mathbf{F}}_q$ . La formule des traces (1.12.1) pour  $\mathscr{F}_{j,0}$  s'écrit

(8.4.2) 
$$\sum_{x_1, \ldots, x_n \in \mathbb{F}_q} \psi(Q(x_1, \ldots, x_n)) = \sum_{i} (-1)^{i} \operatorname{Tr}(F^*, H_c^i(A, \mathscr{F}_1)).$$

On a 
$$\sigma_* E_{\lambda} = \bigoplus_j \mathscr{F}_j$$
, et donc

$$(\mathbf{8}.\mathbf{4}.\mathbf{3}) \qquad \qquad \mathbf{H}_{c}^{\star}(\mathbf{X},\,\mathbf{Q}_{\ell}) \otimes_{\mathbf{Q}_{\ell}} \mathbf{E}_{\lambda} = \bigoplus_{i} \mathbf{H}_{c}^{\star}(\mathbf{A},\,\mathscr{F}_{j}).$$

Pour j=0,  $\mathscr{F}_j$  est le faisceau constant  $E_{\lambda}$ ; ce facteur correspond à l'inclusion, par image réciproque, de la cohomologie de A dans celle de X.

Lemme (8.5). — (i) Pour  $j \neq 0$ ,  $H_c^i(A, \mathscr{F}_j)$  est nul pour  $i \neq n$ ; pour i = n, cet espace de cohomologie est de dimension  $(d-1)^n$ .

(ii) Pour  $j \neq 0$ , le cup-produit

$$\mathrm{H}^n_c(\mathrm{A},\mathscr{F}_j)\otimes\mathrm{H}^n_c(\mathrm{A},\mathscr{F}_{-j})\to\mathrm{H}^{2n}_c(\mathrm{A},\mathrm{E}_\lambda)\overset{\mathrm{Tr}}{\to}\mathrm{E}_\lambda(-n)$$

est une dualité parfaite.

(iii)  $X_0$  est un ouvert d'une variété projective non singulière  $Z_0$ .

Déduisons (8.4) de (8.5). Soient *JQ :* XQ^ZQ et *j :* X<-^Z déduit par extension des scalaires à F^. D'après (8.4.2)3 (i), et (i. 7) pour Zg, il suffit de prouver l'injectivité de

$$H^n_c(A, \mathscr{F}_1) \stackrel{\sigma^*}{\to} H^n_c(X, \mathscr{F}_1) = H^n_c(X, E_\lambda) \stackrel{j_1}{\to} H^n(Z, E_\lambda).$$

**On** a Tr(ûu *b)==- Tr(j\G\*auj^(s\*b),* donc cette injectivité résulte de (ii). *P*

(8.6) Prouvons (8.5) (iii). Soient Pg l'espace projectif sur F^ complété de AQ par adjonction d'un hyperplan à l'infini Pô", HoCPo° d'équation Q^=o et Yo le revêtement de PQ normalisé de P() dans XQ.

$$(8.6.1) \qquad \begin{array}{c} X_0 & \longleftrightarrow & Y_0 \\ \downarrow & & \downarrow \\ A_0 & \longleftrightarrow & P_0 & \longleftrightarrow & P_0^\infty & \longleftrightarrow & H_0 \end{array}$$

Étudions YQ/PO près de l'infini, localement pour la topologie étale.

*Lemme* (8.7). — Yo *est lisse en dehors de l'image réciproque de* Ho.

Le diviseur de la fonction rationnelle Q^sur PQ est somme de sa partie finie div(QJ^ et de (—*d )* fois l'hyperplan à l'infini. **On a :**

(8.7.1) 
$$\operatorname{div}(\mathbf{Q}) = \operatorname{div}(\mathbf{Q})_f - dP_0^{\infty}$$
$$\operatorname{div}(\mathbf{Q})_f \cap P_0^{\infty} = H_0.$$

A distance finie, Yo *=* Xo est étale sur AQ, donc lisse. A l'infini, mais en dehors de l'image réciproque de Ho, il existe des coordonnées locales (^, . .., -?J telles que 0^=^^ (ceci utilise que (</,j&)==i). Dans ces coordonnées, Yo apparaît comme produit d'une courbe et d'un espace lisse (correspondant aux coordonnées ^g, .. ., 2'J. Par normalité, il est lisse.

*Lemme* **(8.8).** — *Au voisinage étale d'un point au-dessus de* **Ho,** Yo *est lisse sur une surface singulière normale*, *toujours la même.*

**On** peut cette fois trouver des coordonnées locales telles que O^^f^a- ^<sup>n</sup> effet, puisque Ho est lisse, div(QJ^ est lisse au voisinage de l'infini et coupe Po° transversalement. Cette forme est indépendante du point choisi, et n'utilise que deux coordonnées, d'où l'assertion.

(8.9) On sait que le procédé suivant (dû à Zariski) permet de résoudre les singularités de surfaces : alternativement, on normalise et on éclate le lieu singulier (réduit). Les opérateurs en jeu commutent à la localisation étale et au produit par un espace lisse. Le procédé de Zariski permet donc encore de résoudre les singularités d'un espace qui, comme Yo, est, localement pour la topologie étale, lisse sur une surface. La résolution obtenue de Yo est le ZQ cherché.

Si T est une courbe sur une surface S, contenant le lieu singulier, et que T' est l'image réciproque de T dans la résolution de Zariski S' de S, on sait que si on éclate de façon itérée dans S' le lieu singulier (réduit) de  $(T')_{red}$ , on obtient une surface S' telle que l'image réciproque réduite  $(T'')_{red}$  de T dans S' soit un diviseur à croisements normaux. A nouveau, les opérations en jeu commutent à la localisation étale et au produit par un espace lisse. Raisonnant comme plus haut, et observant que  $(Y_0, l'infini)$  est localement lisse sur un (S, T), on peut même trouver  $Z_0$  tel que  $Z_0-X_0$  soit un diviseur à croisements normaux.

(8.10) Prouvons (8.5) (i), (ii). Ce sont des assertions géométriques; ceci nous permet de travailler dorénavant sur  $\overline{\mathbf{F}}_q$ . Soit S' l'espace affine sur  $\overline{\mathbf{F}}_q$  qui paramétrise les polynômes à n variables de degré  $\leq d$ , et soit S l'ouvert de S' correspondant aux polynômes dont la partie homogène de degré d est de discriminant non nul. On note  $\mathbf{Q}_8 \in \mathbf{H}^0(\mathbf{S}, \mathcal{O}_8[x_1, \ldots, x_n])$  le polynôme universel sur S, et  $\mathbf{X}_8$  le revêtement galoisien étale de  $\mathbf{A}_8 = \mathbf{A}^n \times \mathbf{S}$  d'équation  $\mathbf{T}^p - \mathbf{T} = \mathbf{Q}_8$ , de groupe de Galois  $\mathbf{Z}/p$ . Soient  $\mathbf{P}_8 = \mathbf{P}^n \times \mathbf{S}$  l'espace projectif sur S complété de  $\mathbf{A}_8$  et  $\mathbf{Y}_8$  le normalisé de  $\mathbf{P}_8$  dans  $\mathbf{X}_8$ . On dispose, sur S, d'un diagramme analogue à (8.6.1).

Les expressions de Q en coordonnées locales données en (8.7) et (8.8) restent valables dans la situation présente, avec paramètres, de sorte que, localement pour la topologie étale sur  $Y_8$ ,  $Y_8/S$  est isomorphe au produit de S (qui est lisse) avec une fibre. La méthode canonique de résolution utilisée en (8.9) nous fournit une compactification relative  $Z_8/S$  de  $X_8/S$ , avec  $Z_8-X_8$  un diviseur à croisements normaux relatifs sur S

$$\begin{array}{ccc} X_8 & \stackrel{u}{\longleftrightarrow} & Z_8 \\ \downarrow^{\sigma} & & \downarrow^{f} \\ A_8 & \stackrel{a}{\longleftrightarrow} & S \end{array}$$

(f propre et lisse, u plongement ouvert,  $Z_s-X_s$  diviseur à croisements normaux relatifs).

Soit  $\mathscr{F}_{j,\,8}$  le  $E_\lambda$ -faisceau sur  $A_s$  déduit comme en (8.4) de  $X_s/A_s$ . On a  $\sigma_{\bullet}E_{\lambda}= \bigoplus \mathscr{F}_{i,\,8},$  donc

$$R^*(fu)_!(E_{\lambda}) = \bigoplus_j R^*a_! \mathscr{F}_{j,S}.$$

Les propriétés de  $Z_8$  assurent que les  $R^i(fu)_1E_\lambda=R^if_*(u_1E_\lambda)$  sont des faisceaux localement constants sur S. Dès lors, les  $R^ia_1\mathscr{F}_{j,8}$  également sont localement constants. Puisque S est connexe, il suffit de prouver (8.5) (i), (ii) pour un polynôme Q particulier. On prendra  $Q=\sum_i x_i^d$ . Ce polynôme vérifie la condition de non-singularité car (d,p)=1. Pour ce polynôme, les variables se séparent dans la somme exponentielle de (8.4). Ceci correspond au fait que  $\mathscr{F}_j$  est le produit tensoriel des images réciproques de

faisceaux analogues  $\mathscr{F}_j^1$  sur les facteurs de dimension un  $A^1$  de  $A = A^n$ . Par la formule de Künneth

$$H^*(A, \mathscr{F}_i) = \bigotimes H^*(A^1, \mathscr{F}_i^1).$$

Ceci ramène la preuve de (8.5) (i), (ii) au cas où n=1 et où Q est  $x^d$ .

(8.11) Traitons ce cas particulier. Le revêtement X de A est irréductible, de sorte que pour i=0,2

$$H_c^i(A, E_\lambda) \stackrel{\sim}{\to} H_c^i(X, E_\lambda)$$
.

Pour  $i \neq 1$  et  $j \neq 0$ , on a donc

$$H_c^i(A, \mathscr{F}_i) = 0.$$

L'assertion (ii) résulte de (2.8) ou (2.12) et de ce que  $u_1 \mathscr{F}_j = u_* \mathscr{F}_j$ . Pour prouver (i), il reste à vérifier que

$$\chi_c(\mathbf{A}, \mathscr{F}_i) = \mathbf{I} - d.$$

D'après la formule d'Euler-Poincaré (voir l'exposé Bourbaki 286 de février 1965, par M. Raynaud), ceci équivaut au lemme suivant.

Lemme (8.12). — Le conducteur de Swan de  $\mathcal{F}_j$  à l'infini est égal à d. Cet énoncé équivaut au suivant.

Lemme (8.13). — Soient k un corps fini de caractéristique p,  $y \in k[[x]]$  un élément de valuation d première à p, L l'extension de K = k((x)) engendré par les racines de  $T^p - T = y^{-1}$  et  $\chi$  le caractère suivant de Gal(L/K) à valeurs dans Z/p:

$$\chi(\sigma) = \sigma T - T$$
.

Alors,  $\chi$  est de conducteur d+1.

Par extension du corps résiduel, on se ramène à supposer k algébriquement clos plutôt que fini, et on applique : J. P. Serre, Sur les corps locaux à corps résiduel algébriquement clos, *Bull. Soc. Math. France*, 89 (1961), p. 105-154, nº 4.4.

## BIBLIOGRAPHIE

- [1] A. Grothendieck, Formule de Lefschetz et rationalité des fonctions L, Séminaire Bourbaki, 279, décembre 1964 (Benjamin).
- [2] S. Lefschetz, L'analysis situs et la géométrie algébrique (Gauthier-Villars), 1924. Reproduit dans : Selected papers (Chelsea Publ. Co.).
- [3] R. A. RANKIN, Contributions to the theory of Ramanujan's function τ(n) and similar arithmetical functions. II, Proc. Camb. Phil. Soc., 35 (1939), 351-372.

306

- [4] A. Weil, Numbers of solutions of equations in finite fields, Bull. Am. Math. Soc., 55 (1949), p. 497-508.
- SGA, Séminaire de Géométrie Algébrique du Bois-Marie (IHES) :
- SGA 4, Théorie des topos et cohomologie étale des schémas (dirigé par M. Artin, A. Grothendieck et J.-L. Verdier), Lecture Notes in Math., 269, 270, 305.
- SGA 5, Cohomologie l-adique et fonctions L, diffusé par l'IHES.
- SGA 7, Groupes de monodromie en géométrie algébrique.
  - 1re partie : dirigé par A. Grothendieck, Lecture Notes in Math., 288.
  - 2e partie : par P. Deligne et N. Katz, Lecture Notes in Math., 340.

Manuscrit reçu le 20 septembre 1973.