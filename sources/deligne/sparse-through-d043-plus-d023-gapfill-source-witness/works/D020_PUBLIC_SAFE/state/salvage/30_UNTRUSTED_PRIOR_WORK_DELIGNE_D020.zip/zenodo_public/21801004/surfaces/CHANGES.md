# Changes — D020 control checkpoint

Concept DOI: <https://doi.org/10.5281/zenodo.20410853>

Version DOI: <https://doi.org/10.5281/zenodo.21801004>

## Added

- Direct D020 identity and boundary receipt from the frozen 36-page authority.
- Exact preservation of the cover's colon-form title and the article heading's period-form title.
- Complete printed-page span 273--307, contents through Sections 1--8, bibliography [1]--[4], SGA 4/5/7 sigla, 20 September 1973 received date, and physical EOF evidence.
- D020 source language and receipt evidence in the 146-record / 144-distinct-work author index.
- Cumulative D010--D020 control and workflow snapshots.

## Refreshed

- Standalone cumulative French and English readers and LaTeX masters retain mathematical coverage D001--D008; only the version DOI and verified-control range changed.
- The identity/source audit cursor advances from D020 to D021.

## Preserved status

- No D020 edition, translation, semantic scaffold, or candidate was opened or certified.
- D009 production remains hard-stopped and not opened.
- D010--D020 control work is not misrepresented as new mathematical reader text.
- Existing bilingual-named files remain rejected historical evidence, not current deliverables.
- No whole-corpus-completion claim is made.
