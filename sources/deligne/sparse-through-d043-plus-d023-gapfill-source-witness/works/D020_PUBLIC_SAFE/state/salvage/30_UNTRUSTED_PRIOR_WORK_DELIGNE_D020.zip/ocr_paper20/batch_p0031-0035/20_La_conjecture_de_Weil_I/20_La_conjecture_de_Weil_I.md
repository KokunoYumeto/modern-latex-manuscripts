Alors

$$\left|\sum_{x_1,\ldots,x_n\in\mathbb{F}_n}\psi(\mathbf{Q}(x_1,\ldots,x_n))\right|\leq (d-1)^nq^{n/2}.$$

Quitte à remplacer Q par un multiple scalaire, on peut supposer (et on supposera) que

$$\psi(x) = \exp(2\pi i \operatorname{Tr}_{\mathbf{r}_{a}/\mathbf{r}_{b}}(x)/p).$$

Soit  $X_0$  le revêtement étale de l'espace affine  $A_0$  de dimension n sur  $\mathbf{F}_q$  d'équation  $T^p - T = \mathbb{Q}$ , et soit  $\sigma$  la projection de  $X_0$  sur  $A_0$ :

$$\begin{split} \sigma: \ X_0 &\to A_0 \\ X_0 &= \operatorname{Spec}(F_{\mathfrak{g}}[x_1, \ \ldots, \ x_n, \ T]/(T^p - T - Q)). \end{split}$$

Le revêtement  $X_0$  est galoisien, de groupe de Galois  $\mathbf{Z}/p$ ;  $i \in \mathbf{Z}/p = \mathbf{F}_p$  agit par  $T \mapsto T + i$ . Soit  $x \in \mathbf{A}_0(\mathbf{F}_q)$  et calculons l'endomorphisme de Frobenius de la fibre de  $\mathbf{X}_0/\mathbf{A}_0$  en x. Posons  $q = p^f$  et soit  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$ . Pour  $(x, T) \in \mathbf{X}_0(\overline{\mathbf{F}}_q)$  au-dessus de x, on a  $\mathbf{F}((x, T)) = (x, T^q)$ , et

$$\mathbf{T}^{q} = \mathbf{T} + \sum_{i=1}^{f} (\mathbf{T}^{p^{i}} - \mathbf{T}^{p^{i-1}}) = \mathbf{T} + \sum_{i} \mathbf{Q}(x)^{p^{i-1}} = \mathbf{T} + \mathbf{Tr}_{\mathbf{F}_{q}/\mathbf{F}_{p}}(\mathbf{Q}(x)).$$

G'est l'action de l'élément  $\operatorname{Tr}_{\mathbf{F}_q/\mathbf{F}_p}(\mathbf{Q}(x))$  du groupe de Galois.

Soient E le corps des racines  $p^{\text{lèmes}}$  de l'unité et  $\lambda$  une place finie de E première à p. Nous travaillerons en cohomologie  $\lambda$ -adique. Pour  $j \in \mathbb{Z}/p$ , soit  $\mathscr{F}_{j,0}$  le  $\mathbb{E}_{\lambda}$ -système local de rang un sur  $A_0$  défini par  $X_0$  et  $\psi(-jx): \mathbb{Z}/p \to \mathbb{E}^* \to \mathbb{E}^*_{\lambda}$  : on dispose de  $\iota: X_0 \to \mathscr{F}_{j,0}$  et  $\iota(i*x) = \psi(-ji)\iota(x)$ . Notons sans 0 les objets déduits de  $A_0$ ,  $X_0$ ,  $\mathscr{F}_{j,0}$  par extension des scalaires à  $\widetilde{\mathbb{F}}_{0}$ . La formule des traces (1.12.1) pour  $\mathscr{F}_{j,0}$  s'écrit

(8.4.2) 
$$\sum_{x_1,...,x_n \in F_n} \psi(Q(x_1,...,x_n)) = \sum_i (-1)^i \operatorname{Tr}(F^i, H^i_r(A,\mathscr{F}_1)).$$

On a 
$$\sigma_{\bullet} \mathbf{E}_{\lambda} = \bigoplus_{i} \mathscr{F}_{i}$$
, et donc

$$(\mathbf{8.4.3}) \qquad \qquad \mathbf{H}_{c}^{\bullet}(\mathbf{X},\,\mathbf{Q}_{\ell}) \otimes_{\mathbf{Q}_{\ell}} \mathbf{E}_{\lambda} = \bigoplus_{j} \mathbf{H}_{c}^{\bullet}(\mathbf{A},\,\mathscr{F}_{j}).$$

Pour j=0,  $\mathscr{F}_j$  est le faisceau constant  $E_{\lambda}$ ; ce facteur correspond à l'inclusion, par image réciproque, de la cohomologie de A dans celle de X.

Lemme (8.5). — (i) Pour  $j \neq 0$ ,  $H'_{i}(A, \mathscr{F}_{j})$  est nul pour  $i \neq n$ ; pour i = n, cet espace de cohomologie est de dimension  $(d-1)^{n}$ .

(ii) Pour  $j \neq 0$ , le cup-produit

$$H^n_c(A,\mathscr{F}_j)\otimes H^n_c(A,\mathscr{F}_{-j})\to H^{2n}_c(A,\mathbb{E}_\lambda)\overset{\mathrm{Tr}}\to \mathbb{E}_\lambda(-n)$$

est une dualité parfaite.

(iii) X<sub>0</sub> est un ouvert d'une variété projective non singulière Z<sub>0</sub>.

Déduisons (8.4) de (8.5). Soient  $j_0: X_0 \hookrightarrow Z_0$  et  $j: X \hookrightarrow Z$  déduit par extension des scalaires à  $\overline{F}_q$ . D'après (8.4.2), (i), et (1.7) pour  $Z_0$ , il suffit de prouver l'injectivité de

$$H^n_c(A, \mathscr{F}_1) \stackrel{\sigma^*}{\to} H^n_c(X, \mathscr{F}_1) = H^n_c(X, E_\lambda) \stackrel{j_1}{\to} H^n(Z, E_\lambda).$$

On a  $\operatorname{Tr}(a \cup b) = \frac{1}{p} \operatorname{Tr}(j_1 \sigma^* a \cup j_1 \sigma^* b)$ , donc cette injectivité résulte de (ii).

(8.6) Prouvons (8.5) (iii). Soient  $P_0$  l'espace projectif sur  $\mathbf{F}_q$  complété de  $A_0$  par adjonction d'un hyperplan à l'infini  $P_0^\infty$ ,  $H_0 \subset P_0^\infty$  d'équation  $Q_d = 0$  et  $Y_0$  le revêtement de  $P_0$  normalisé de  $P_0$  dans  $X_0$ .

$$\begin{array}{cccccccccccccccccccccccccccccccccccc$$

Étudions Y<sub>0</sub>/P<sub>0</sub> près de l'infini, localement pour la topologie étale.

Lemme (8.7). — Yo est lisse en dehors de l'image réciproque de Ho.

Le diviseur de la fonction rationnelle Q sur  $P_0$  est somme de sa partie finie  $\operatorname{div}(Q)_f$  et de (-d) fois l'hyperplan à l'infini. On a :

(8.7.1) 
$$\operatorname{div}(\mathbf{Q}) = \operatorname{div}(\mathbf{Q})_{f} - d\mathbf{P}_{0}^{\infty}$$
$$\operatorname{div}(\mathbf{Q})_{f} \cap \mathbf{P}_{0}^{\infty} = \mathbf{H}_{0}.$$

A distance finic,  $Y_0 = X_0$  est étale sur  $A_0$ , donc lisse. A l'infini, mais en dehors de l'image réciproque de  $H_0$ , il existe des coordonnées locales  $(z_1, \ldots, z_n)$  telles que  $Q = z_1^{-d}$  (ceci utilise que (d, p) = 1). Dans ces coordonnées,  $Y_0$  apparaît comme produit d'une courbe et d'un espace lisse (correspondant aux coordonnées  $z_2, \ldots, z_n$ ). Par normalité, il est lisse.

Lemme (8.8). — Au voisinage étale d'un point au-dessus de  $H_0$ ,  $Y_0$  est lisse sur une surface singulière normale, toujours la même.

On peut cette fois trouver des coordonnées locales telles que  $\mathbf{Q} = z_1^{-d} z_2$ . En effet, puisque  $\mathbf{H}_0$  est lisse,  $\operatorname{div}(\mathbf{Q})_f$  est lisse au voisinage de l'infini et coupe  $\mathbf{P}_0^\infty$  transversalement. Cette forme est indépendante du point choisi, et n'utilise que deux coordonnées, d'où l'assertion.

(8.9) On sait que le procédé suivant (dû à Zariski) permet de résoudre les singularités de surfaces : alternativement, on normalise et on éclate le lieu singulier (réduit). Les opérateurs en jeu commutent à la localisation étale et au produit par un espace lisse. Le procédé de Zariski permet donc encore de résoudre les singularités d'un espace qui, comme  $Y_0$ , est, localement pour la topologie étale, lisse sur une surface. La résolution obtenue de  $Y_0$  est le  $Z_0$  cherché.

Si T est une courbe sur une surface S, contenant le lieu singulier, et que T' est l'image rdciproque de T dans la rdsolution de Zariski S' de S, on salt que si on dclate de faw itdrde dans S' le lieu singulier (rdduit) de (T'),od , on obtient une surface S" telle que l'image rdciproque rdduite (T"),0a de T dans S" soit un diviseur ~t croisements normaux. A nouveau, les opdrations en jeu commutent ~ la localisation dtale et au produit par un espace lisse. Raisonnant comme plus haut, et observant que (Y0, l'infini) est localement lisse sur un (S, T), on pcut m~me trouver Z 0 tel que Z0--X 0 soit un diviseur ~t croisements normaux.

(8. IO) Prouvons (8.5) (i), (ii). Ce sont des assertions gdomdtriques; ceci nous permet de travailler dordnavant sur Fq. Soit S' l'espace affine sur Fq qui paramdtrise les polyn6mes ~ n variables de degrd ~d, et soit S l'ouvert de S' correspondant aux polyn6mes dont la partie homog~ne de degrd d est de discriminant non nul. On note Q.seH~ 0s[Xl, ..., x,]) le polyn6me universe1 sur S, et X s le rev~tement galoisien dtale de As=A"• d'dquation T'--T:Qs, de groupe de Galois *Zip.* Soient Ps = P"• S l'espuce projectif sur S compldt~ de A s et Ys le normalisd de Ps duns X s. On dispose, sur S, d'un diagramme analogue ~t (8.6. I).

Les expressions de Q. en coordonndes locales donndes en (8.7) et (8.8) restent valables duns la situation prdsente, avec param~tres, de sorte que, localement pour la topologie dtale sur Ys, Ys/S est isomorphe au produit de S (qui est lisse) avec une fibre. La mdthode canonique de rdsolution utilisde en (8.9) nous fournit une compactification relative Zs/S de Xs/S , avec Zs--X sun diviseur ~t croisements normaux relatifs sur S

$$\begin{array}{ccc} X_S & \stackrel{u}{\hookrightarrow} & Z_S \\ \downarrow^{\sigma} & & \downarrow^{f} \\ A_S & \stackrel{a}{\longrightarrow} & S \end{array}$$

(fpropre et lisse, u plongement ouvert, Zs--X s diviseur ~ croisements normaux relatifs). Soit ~,s le Ex-faisceau sur A s ddduit comme en (8.4) de Xs/A s. On a a.Ex= @~.s, done

$$\mathbf{R}^{\bullet}(fu)_{\mathbf{I}}(\mathbf{E}_{\lambda}) = \bigoplus_{\mathbf{j}} \mathbf{R}^{\bullet}a_{\mathbf{j}}\mathscr{F}_{\mathbf{j},8}.$$

Les propridtds de Z s assurent que les *R~(fu)tEx=R~f,(utEx)* sont des faisceaux localement constants sur S. D6s lors, les Kiat~,s dgalement sont localement constants. Puisque S est connexe, il suffit de prouver (8.5) (i), (ii) pour *un* polyn6me Q. particulier. On prendra Q.= Zx, d. Ce polynSme vdrifie la condition de non-singularitd car *(d, p) = I.*  Pour ce polyn6me, les variables se sdparent dam la somme exponentielle de (8.4). Ceci correspond au fait que ~ est le produit tensoriel des images rdciproques de faisceaux analogues  $\mathscr{F}_j^1$  sur les facteurs de dimension un  $A^1$  de  $A=A^n$ . Par la formule de Künneth

$$H^{\bullet}(A, \mathscr{F}_{i}) = \bigotimes H^{\bullet}(A^{1}, \mathscr{F}_{i}^{1}).$$

Ceci ramène la preuve de (8.5) (i), (ii) au cas où n=1 et où Q est  $x^d$ .

(8.11) Traitons ce cas particulier. Le revêtement X de A est irréductible, de sorte que pour i=0,2

$$H^i(\Lambda, E_{\lambda}) \stackrel{\sim}{\to} H^i(X, E_{\lambda}).$$

Pour  $i \neq 1$  et  $j \neq 0$ , on a donc

$$\mathbf{H}_{c}^{i}(\mathbf{A}, \mathscr{F}_{i}) = \mathbf{0}.$$

L'assertion (ii) résulte de (2.8) ou (2.12) et de ce que  $u_i \mathscr{F}_j = u_* \mathscr{F}_j$ . Pour prouver (i), il reste à vérifier que

$$\chi_c(A, \mathcal{F}_i) = \mathbf{I} - d.$$

D'après la formule d'Euler-Poincaré (voir l'exposé Bourbaki 286 de février 1965, par M. Raynaud), ceci équivaut au lemme suivant.

Lemme (8.12). — Le conducteur de Swan de F, à l'infini est égal à d. Cet énoncé équivaut au suivant.

Lemme (8.13). — Soient k un corps fini de caractéristique p,  $y \in k[[x]]$  un élément de valuation d première à p, L l'extension de K = k((x)) engendré par les racines de  $T^p + T = y^{-1}$  et  $\chi$  le caractère suivant de Gal(L/K) à valeurs dans  $\mathbf{Z}/p$ :

$$\gamma(\sigma) = \sigma T - T$$
.

Alors,  $\chi$  est de conducteur d+1.

Par extension du corps résiduel, on se ramène à supposer k algébriquement clos plutôt que fini, et on applique : J. P. Serre, Sur les corps locaux à corps résiduel algébriquement clos, *Bull. Soc. Math. France*, 89 (1961), p. 105-154, no 4.4.

## BIBLIOGRAPHIE

- A. GROTHENDIECK, Formule de Lefschetz et rationalité des fonctions L, Séminaire Bourbaki, 279, décembre 1964 (Benjamin).
- [2] S. Lefschetz, L'analysis situs et la géométrie algébrique (Gauthier-Villars), 1924. Reproduit dans : Selected papers (Chelsea Publ. Co.).
- [3] R. A. RANKIN, Contributions to the theory of Ramanujan's function τ(n) and similar arithmetical functions. II, Proc. Camb. Phil. Soc., 35 (1939), 351-372.

- [4] A. Well, Numbers of solutions of equations in finite fields, Bull. Am. Math. Soc., 55 (1949), p. 497-508.
- SGA, Séminaire de Géométrie Algébrique du Bois-Marie (IHES) :
- SGA 4. Théorie des topos et cohomologie étale des schémas (dirigé par M. ARTIN, A. GROTHENDIECK et J.-L. VERDIER),
  Lecture Notes in Math., 269, 270, 305.
- SGA 5, Cohomologie l'adique et fonctions L, disfusé par l'IHES.
- SGA 7, Groupes de monodromie en géométrie algébrique.
  - 1re partie : dirigé par A. Grothendreck, Lecture Notes in Math., 288.
  - 2º partie : par P. Deligne et N. Katz, Lecture Notes in Math., 340.

Manuscrit reçu le 20 septembre 1973.