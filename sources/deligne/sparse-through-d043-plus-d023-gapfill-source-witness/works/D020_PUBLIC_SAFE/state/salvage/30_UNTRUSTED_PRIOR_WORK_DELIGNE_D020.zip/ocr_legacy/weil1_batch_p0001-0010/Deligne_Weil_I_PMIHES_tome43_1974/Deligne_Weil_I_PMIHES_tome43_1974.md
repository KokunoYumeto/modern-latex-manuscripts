# PUBLICATIONS MATHÉMATIQUES DE L'I.H.É.S.

## PIERRE DELIGNE

La conjecture de Weil : I

*Publications mathématiques de l'I.H.É.S.*, tome 43 (1974), p. 273-307 <[http://www.numdam.org/item?id=PMIHES\\_1974\\_\\_43\\_\\_273\\_0](http://www.numdam.org/item?id=PMIHES_1974__43__273_0)>

© Publications mathématiques de l'I.H.É.S., 1974, tous droits réservés.

L'accès aux archives de la revue « Publications mathématiques de l'I.H.É.S. » ([http://](http://www.ihes.fr/IHES/Publications/Publications.html) [www.ihes.fr/IHES/Publications/Publications.html](http://www.ihes.fr/IHES/Publications/Publications.html)) implique l'accord avec les conditions générales d'utilisation (<http://www.numdam.org/conditions>). Toute utilisation commerciale ou impression systématique est constitutive d'une infraction pénale. Toute copie ou impression de ce fichier doit contenir la présente mention de copyright.

![](_page_0_Picture_6.jpeg)

### LA CONJECTURE DE WEIL. I

#### par PIERRE DELIGNE

#### **SOMMAIRE**

| Ι. : | La  | théorie de | Grothendieck: interprétation cohomologique de fonctions L | 273 |
|------|-----|------------|-----------------------------------------------------------|-----|
| 2.   | La  | théorie de | Grothendieck : dualité de Poincaré                        | 280 |
| 3. Ì | La  | majoration | fondamentale                                              | 283 |
| 4.   | La  | théorie de | Lefschetz: théorie locale                                 | 287 |
| 5    | La  | théorie de | Lefschetz: théorie globale                                | 280 |
| 6.   | Un  | théorème   | de rationalité                                            | 294 |
| 7.   | Fin | de la dén  | nonstration de (1.7)                                      | 298 |
| 8.   | Pre | mières app | lications                                                 | 301 |

Dans cet article, je démontre la conjecture de Weil sur les valeurs propres des endomorphismes de Frobenius. Un énoncé précis est donné en (1.6). J'ai tenté de présenter la démonstration sous une forme aussi géométrique et élémentaire que possible et j'ai inclus force rappels : seuls sont originaux les résultats des §§ 3, 6, 7 et 8.

Dans un article faisant suite à celui-ci, je donnerai divers raffinements des résultats intermédiaires, et des applications, parmi lesquelles le théorème de Lefschetz « difficile » (sur les cup-produits itérés par la classe de cohomologie d'une section hyperplane).

Le texte suit fidèlement celui de six conférences données à Cambridge en juillet 1973. Je remercie N. Katz de m'avoir permis d'utiliser ses notes.

#### 1. La théorie de Grothendieck : interprétation cohomologique de fonctions L.

 $(\mathbf{r}.\mathbf{r})$  Soient X un schéma de type fini sur Z, |X| l'ensemble des points fermés de X et, pour  $x \in |X|$ , soit N(x) le nombre d'éléments du corps résiduel k(x) de X en x. La fonction zêta de Hasse-Weil de X est

(I.I.I) 
$$\zeta_{X}(s) = \prod_{x \in |X|} (1 - N(x)^{-s})^{-1}$$

(ce produit converge absolument pour  $\mathcal{R}(s)$  assez grand). Pour  $X = \operatorname{Spec}(\mathbf{Z})$ ,  $\zeta_X(s)$  est la fonction zêta de Riemann.

Nous considérerons exclusivement le cas où X est un schéma sur un corps fini  $\mathbf{F}_a$ .

Pour  $x \in |X|$ , nous écrirons  $q_x$  plutôt que N(x). Posant  $deg(x) = [k(x) : \mathbf{F}_q]$ , on a  $q_x = q^{deg(x)}$ . Il y a intérêt à introduire la variable  $t = q^{-s}$ . Posons

(1.1.2) 
$$Z(X;t) = \prod_{x \in |X|} (I - t^{\deg(x)})^{-1};$$

ce produit infini converge pour |t| assez petit, et on a

$$(\mathbf{I.I.3})$$
  $\zeta_{\mathbf{X}}(s) = \mathbf{Z}(\mathbf{X}; q^{-s}).$ 

(1.2) Dwork (On the rationality of the zeta function of an algebraic variety, Amer. J. Math., 82, 1960, p. 631-648) et Grothendieck ([1] et SGA 5) ont démontré que Z(X, t) est une fonction rationnelle de t.

Pour Grothendieck, c'est là un corollaire de résultats généraux en cohomologie  $\ell$ -adique ( $\ell$  désigne un nombre premier différent de la caractéristique p de  $\mathbf{F}_q$ ). Ceux-ci fournissent une interprétation cohomologique des zéros et des pôles de Z(X;t), et une équation fonctionnelle lorsque X est propre et lisse. Les méthodes de Dwork sont p-adiques. Pour X une hypersurface non singulière dans l'espace projectif, elles lui fournissaient également une interprétation cohomologique des zéros et des pôles, et l'équation fonctionnelle. Elles ont inspiré la théorie cristalline de Grothendieck et Berthelot, qui pour X propre et lisse fournit une interprétation cohomologique p-adique des zéros et pôles, et l'équation fonctionnelle. Se basant sur des idées de Washnitzer, Lubkin a créé une variante de cette théorie, valable seulement pour X propre, lisse et relevable en caractéristique zéro (X0 p-adic proof of Weil's conjectures, X1 propre, lisse et relevable en caractéristique zéro (X1 p-adic proof of Weil's conjectures, X2 propre, lisse et relevable en caractéristique zéro (X2 p-adic proof of Weil's conjectures, X3 propre et lisse et relevable en caractéristique zéro (X2 p-adic proof of Weil's conjectures, X3 propre et lisse et relevable en caractéristique zéro (X3 p-adic proof of Weil's conjectures, X4 propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse propre et lisse pr

Nous ferons un usage essentiel des résultats de Grothendieck, et les rappelons ci-dessous.

- (1.3) Soit X une variété algébrique sur un corps algébriquement clos k de caractéristique p, i.e. un schéma séparé de type fini sur k. On n'exclut pas le cas p=0. Pour tout nombre premier  $\ell \neq p$ , Grothendieck a défini des groupes de cohomologie  $\ell$ -adiques  $H^i(X, \mathbf{Q}_{\ell})$ . Il a aussi défini des groupes de cohomologie à support propre  $H^i_c(X, \mathbf{Q}_{\ell})$ . Pour X propre, les deux coïncident. Les  $H^i_c(X, \mathbf{Q}_{\ell})$  sont des espaces vectoriels de dimension finie sur  $\mathbf{Q}_{\ell}$ , nuls pour  $i \geq 2 \dim(X)$ .
- (1.4) Soient  $X_0$  une variété algébrique sur  $\mathbf{F}_q$ ,  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$  et X la variété algébrique sur  $\overline{\mathbf{F}}_q$  déduite de  $X_0$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ . Dans le langage de Weil ou Shimura, on exprimerait cette situation par : « Soit X une variété algébrique définie sur  $\mathbf{F}_q$  ». Soit  $F: X \to X$  le morphisme de Frobenius; il envoie le point de coordonnées x vers le point de coordonnées  $x^q$ ; en d'autres termes, pour  $U_0$  un ouvert de Zariski de  $X_0$ , définissant un ouvert U de X, on a  $F^{-1}(U) = U$ ; pour  $x \in H^0(U_0, \mathcal{O})$ , on a  $F^*x = x^q$ . Identifions l'ensemble |X| des points fermés de X à  $X_0(\overline{\mathbf{F}}_q)$  (l'ensemble  $Hom_{\overline{\mathbf{F}}_q}(\operatorname{Spec}(\overline{\mathbf{F}}_q), X_0)$  des points de  $X_0$  à coefficients dans  $\overline{\mathbf{F}}_q$ ), et soit

 $\varphi \in \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  la substitution de Frobenius :  $\varphi(x) = x^q$ . L'action de F sur |X| s'identifie à l'action de  $\varphi$  sur  $X_0(\overline{\mathbf{F}}_q)$ . Dès lors :

- a) L'ensemble  $X^F$  des points fermés de X fixes sous F s'identifie à l'ensemble  $X_0(\mathbf{F}_q) \subset X_0(\overline{\mathbf{F}}_q)$  des points de X définis sur  $\mathbf{F}_q$ . Ceci exprime simplement que, pour  $x \in \overline{\mathbf{F}}_q$ , on a  $x \in \mathbf{F}_q \Leftrightarrow x^q = x$ .
- *b)* De même, l'ensemble  $X^{F^n}$  des points fermés de X fixes sous le  $n^{\text{ième}}$  itéré de F s'identifie à  $X_0(\mathbf{F}_{\sigma^n})$ .
- c) L'ensemble  $|X_0|$  des points fermés de  $X_0$  s'identifie à l'ensemble  $|X|_F$  des orbites de F (ou de  $\varphi$ ) dans |X|. Le degré  $\deg(x)$  de  $x \in |X_0|$  est le nombre d'éléments de l'orbite correspondante.
  - d) De b) et c) résulte la formule

(1.4.1) 
$$\#X^{F^n} = \#X_0(\mathbf{F}_{q^n}) = \sum_{\deg(x)|n} \deg x$$

(pour  $x \in |X_0|$  et  $\deg(x) | n$ , x définit  $\deg(x)$  points à coordonnées dans  $\mathbf{F}_{q^n}$ , tous conjugués sur  $\mathbf{F}_q$ ).

(1.5) Le morphisme F est fini, en particulier propre. Il induit donc des applications  $F^*: H^i_c(X, \mathbf{Q}_\ell) \to H^i_c(X, \mathbf{Q}_\ell)$ .

Grothendieck a prouvé la formule de Lefschetz

$$\#X^{F} = \sum_{i} (-1)^{i} \operatorname{Tr}(F^{*}, H_{c}^{i}(X, \mathbf{Q}_{\ell}));$$

le membre de droite, a priori un nombre  $\ell$ -adique, est entier, et égal au membre de gauche. On notera qu'une telle formule n'est raisonnable que parce que dF=0, même à l'infini (X n'est pas supposé propre); la relation dF=0 implique que les points fixes de F sont de multiplicité un.

Une formule analogue vaut pour les itérés de F:

$$(\mathbf{1.5.1}) \qquad \#\mathbf{X}^{\mathbf{F}^n} = \#\mathbf{X}_0(\mathbf{F}_{q^n}) = \sum_{\ell} (-1)^i \operatorname{Tr}(\mathbf{F}^{*n}, \mathbf{H}_c^i(\mathbf{X}, \mathbf{Q}_{\ell})).$$

Prenons la dérivée logarithmique de (1.1.2):

(1.5.2) 
$$t \frac{d}{dt} \log Z(X_0, t) = \frac{t \frac{d}{dt} Z(X_0, t)}{Z(X_0, t)} = \sum_{x \in |X_0|} -\frac{-\deg(x) t^{\deg(x)}}{1 - t^{\deg(x)}}$$
$$= \sum_{x \in |X_0|} \sum_{n > 0} \deg(x) t^{n \cdot \deg(x)} = \sum_{(1.4.1)} \sum_{n} \# X_0(\mathbf{F}_{q^n}) \cdot t^n.$$

Pour F un endomorphisme d'un espace vectoriel V, on a une identité de séries formelles

$$(\mathbf{1.5.3}) \qquad t \frac{d}{dt} \log(\det(\mathbf{I} - \mathbf{F}t, \mathbf{V})^{-1}) = \sum_{n>0} \mathrm{Tr}(\mathbf{F}^n, \mathbf{V}) t^n$$

(le vérifier pour  $\dim(V)=1$ , et observer que les deux membres sont additifs en V dans une suite exacte courte). Substituant (1.5.1) dans (1.5.2) et appliquant (1.5.3), on trouve

$$t\frac{d}{dt}\log \mathbf{Z}(\mathbf{X_0},t) = \sum_{\mathbf{i}} (-\mathbf{I})^{\mathbf{i}} t\frac{d}{dt}\log \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}_c^{\mathbf{i}}(\mathbf{X}, \mathbf{Q_t}))^{-1},$$

soit

(1.5.4) 
$$Z(X_0, t) = \prod_{i} \det(I - F^*t, H_c^i(X, \mathbf{Q}_\ell))^{(-1)^{i+1}}.$$

Le membre de droite est un élément de  $\mathbf{Q}_{\ell}(t)$ . La formule affirme que son développement de Taylor en t=0, a priori une série formelle dans  $\mathbf{Q}_{\ell}[[t]]$  de terme constant un, est dans  $\mathbf{Z}[[t]]$ , et est égal au membre de gauche, lui aussi considéré comme une série formelle en t. Cette formule est l'interprétation cohomologique de Grothendieck de la fonction  $\mathbf{Z}$ .

Notre résultat principal est le suivant.

Théorème  $(\mathbf{r}.\mathbf{6})$ . — Soit  $X_0$  une variété projective non singulière (= lisse) sur  $\mathbf{F}_q$ . Pour chaque i, le polynôme caractéristique  $\det(t.\mathbf{1}-\mathbf{F}^*,\mathbf{H}^i(\mathbf{X},\mathbf{Q}_\ell))$  est à coefficients entiers indépendants de  $\ell$   $(\ell + p)$ . Les racines complexes  $\alpha$  de ce polynôme (les conjugués complexes des valeurs propres de  $\mathbf{F}^*$ ) sont de valeur absolue  $|\alpha| = q^{i/2}$ .

Montrons déjà que (1.6) résulte du résultat apparemment plus faible suivant.

Lemme (1.7). — Pour chaque i, et chaque  $\ell \neq p$ , les valeurs propres de l'endomorphisme  $F^*$  de  $H^i(X, \mathbf{Q}_{\ell})$  sont des nombres algébriques dont tous les conjugués complexes  $\alpha$  sont de valeur absolue  $|\alpha| = q^{i/2}$ .

Preuve de  $(1.7) \Rightarrow (1.6)$ . — Regardons  $Z(X_0, t)$  comme une série formelle de terme constant 1, élément de  $\mathbf{Z}[[t]]: Z(X_0, t) = \sum_{n} a_n t^n$ . D'après (1.5.3), l'image de  $Z(X_0, t)$  dans  $\mathbf{Q}_t[[t]]$  est le développement de Taylor d'une fraction rationnelle. Ceci signifie que pour N et M assez grands  $(\geq les degrés des numérateurs et dénominateurs) les déterminants de Hankel$ 

$$\mathbf{H}_{k} = \det((a_{i+i+k})_{0 < i, i < \mathbf{M}}) \qquad (k > \mathbf{N})$$

sont nuls. Cette nullité est vraie dans  $\mathbf{Q}_t$  si et seulement si elle l'est dans  $\mathbf{Q}_t$ ;  $Z(X_0, t)$  est donc le développement en série de Taylor d'un élément de  $\mathbf{Q}(t)$ . En d'autres termes,

$$Z(X_0, t) \in \mathbb{Z}[[t]] \cap \mathbb{Q}_{\ell}(t) \subset \mathbb{Q}(t).$$

Écrivons  $Z(X_0, t) = P/Q$ , avec  $P, Q \in \mathbf{Z}[t]$ , premiers entre eux, et de terme constant positif. D'après un lemme de Fatou, que  $Z(X_0, t)$  soit dans  $\mathbf{Z}[[t]]$  et de terme constant un implique que les termes constants de P et Q sont 1. Posons

$$P_{i}(t) = \det(I - F^{*}t, H^{i}(X, \mathbf{Q}_{\ell})).$$

D'après l'hypothèse (1.7), les P<sub>i</sub> sont premiers entre eux. Le membre de droite de (1.5.4) est donc sous forme irréductible, et

$$P(t) = \prod_{i \text{ impair}} P_i(t)$$

$$Q(t) = \prod_{i \text{ pair}} P_i(t).$$

Soit K le sous-corps d'une clôture algébrique  $\overline{\mathbf{Q}}_{\ell}$  de  $\mathbf{Q}_{\ell}$  engendré sur  $\mathbf{Q}$  par les racines de  $R(t) = P(t)\mathbf{Q}(t)$ . Les racines de  $P_i(t)$  sont celles des racines de R(t) ayant la propriété que tous leurs conjugués complexes sont de valeur absolue  $q^{-i/2}$ . Cet ensemble est stable sous  $Gal(K/\mathbf{Q})$ . Le polynôme  $P_i(t)$  est donc à coefficients rationnels. D'après le lemme de Gauss (ou parce que les racines de  $P_i$ , étant racines de R(t), sont des inverses d'entiers algébriques), il est même à coefficients entiers. La description ci-dessus des racines de  $P_i(t)$  est indépendante de  $\ell$ ; le polynôme  $P_i(t)$  lui-même est donc indépendant de  $\ell$ .

La suite de cet article est consacrée à la démonstration de (1.7).

- (1.8) La théorie de Grothendieck fournit une interprétation cohomologique non seulement de fonctions zêta, mais encore de fonctions L. Les résultats sont les suivants.
- $(\mathbf{r}.\mathbf{g})$  Soit X une variété algébrique sur un corps k. Pour la définition d'un  $\mathbf{Q}_{\ell}$ -faisceau constructible sur X, je renvoie à SGA 5 VI. Qu'il suffise de dire que:
- a) Si  $\mathscr{F}$  est un  $\mathbb{Q}_{\ell}$ -faisceau constructible sur X, il existe une partition finie de X en parties localement fermées  $X_{\ell}$  telles que  $\mathscr{F}|X_{\ell}$  soit constant tordu.
- b) Supposons X connexe et soit  $\bar{x}$  un point géométrique de X. Pour  $\mathscr{F}$  constant tordu,  $\pi_1(X, \bar{x})$  agit sur la fibre  $\mathscr{F}_{\bar{x}}$ ; le foncteur fibre en  $\bar{x}$  est une équivalence de catégorie ( $\mathbb{Q}_{\ell}$ -faisceaux constructibles constants tordus sur X) $\mapsto$

 $\mapsto$  (représentations continues de  $\pi_1(X, \bar{x})$  sur un  $\mathbf{Q}_{\ell}$ -espace vectoriel de dimension finie).

Une telle représentation ne se factorise pas, en général, à travers un quotient fini de  $\pi_1(X, \bar{x})$ .

c) Si  $k=\mathbb{C}$ , les  $\mathbb{Q}_{\ell}$ -faisceaux constructibles sur X s'identifient aux faisceaux de  $\mathbb{Q}_{\ell}$ -espaces vectoriels  $\mathscr{F}$  sur  $X^{an}$ , tels qu'il existe une partition finie de X en parties Zariski-localement fermées  $X_i$ , et pour chaque i un système local de  $\mathbb{Z}_{\ell}$ -Modules libres de type fini  $\mathscr{F}_i$  sur  $X_i$ , avec

$$\mathscr{F} \mid \mathbf{X}_i = \mathscr{F}_i \otimes_{\mathbf{Z}_\ell} \mathbf{Q}_\ell$$
.

Nous ne considérerons que des  $\mathbf{Q}_t$ -faisceaux constructibles, et les appellerons simplement  $\mathbf{Q}_t$ -faisceaux.

(1.10) Supposons k algébriquement clos, et soit  $\mathscr{F}$  un  $\mathbb{Q}_{\ell}$ -faisceau sur X. Grothendieck a défini des groupes de cohomologie  $\ell$ -adique  $H^{i}(X,\mathscr{F})$  et  $H^{i}_{c}(X,\mathscr{F})$ . Les  $H^{i}_{c}(X,\mathscr{F})$  sont des espaces vectoriels de dimension finie sur  $\mathbb{Q}_{\ell}$ , nuls pour i > 2 dim(X).

Pour  $k = \mathbb{C}$ , les  $H^i(X, \mathcal{F})$  et  $H^i_c(X, \mathcal{F})$  sont les groupes de cohomologie usuels (resp. à support propre) de  $X^{an}$ , à coefficients dans  $\mathcal{F}$ .

(1.11) Soient  $X_0$  une variété algébrique sur  $\mathbf{F}_q$ , X la variété sur  $\overline{\mathbf{F}}_q$  correspondante, et  $\mathscr{F}_0$  un faisceau d'ensembles sur  $X_0$  (pour la topologie étale). On note  $\mathscr{F}$  son image réciproque sur X. Outre le morphisme de Frobenius  $F: X \to X$ , on dispose alors d'un isomorphisme canonique  $F^*: F^*\mathscr{F} \to \mathscr{F}$ . En voici une description. On regarde  $\mathscr{F}_0$  comme un espace étalé sur  $X_0$ , i.e. on identifie  $\mathscr{F}_0$  à l'espace algébrique  $[\mathscr{F}_0]$ , muni d'un morphisme étale  $f: [\mathscr{F}_0] \to X_0$ , tel que  $\mathscr{F}_0$  soit le faisceau des sections locales de  $[\mathscr{F}_0]$ . L'espace analogue  $[\mathscr{F}]$ , étalé sur X, se déduit de  $[\mathscr{F}_0]$  par extension des scalaires. On dispose donc d'un diagramme commutatif

$$\begin{bmatrix} \mathscr{F} \end{bmatrix} \xrightarrow{F} \begin{bmatrix} \mathscr{F} \end{bmatrix} \\
\downarrow^{f} \\
X \xrightarrow{F} X$$

d'où un morphisme  $[\mathscr{F}] \to X \times_{(F,X,f)} [\mathscr{F}] = [F^*\mathscr{F}]$ , qui est un isomorphisme car f est étale. Son inverse définit l'isomorphisme  $F^*\mathscr{F} \to \mathscr{F}$  cherché.

Cette construction se généralise aux Q<sub>1</sub>-faisceaux.

(1.12) Soient  $X_0$  une variété algébrique sur  $\mathbf{F}_q$ ,  $\mathscr{F}_0$  un  $\mathbf{Q}_\ell$ -faisceau sur  $X_0$ ,  $(X,\mathscr{F})$  déduit de  $(X_0,\mathscr{F}_0)$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ ,  $F:X\to X$  et  $F^*:F^*\mathscr{F}\to\mathscr{F}$ . Le morphisme fini F et  $F^*$  définissent un endomorphisme

$$\mathrm{F}^*:\ \mathrm{H}^{i}_{c}(\mathrm{X},\mathscr{F})\rightarrow \mathrm{H}^{i}_{c}(\mathrm{X},\ \mathrm{F}^*\mathscr{F})\rightarrow \mathrm{H}^{i}_{c}(\mathrm{X},\mathscr{F}).$$

Pour  $x \in |X|$ ,  $F^*$  définit un morphisme  $F_x^* : \mathscr{F}_{F(x)} \to \mathscr{F}_x$ . Pour  $x \in X^F$ , c'est un endomorphisme de  $\mathscr{F}_x$ . Grothendieck a démontré la formule de Lefschetz

$$\sum_{x \in \mathbf{X}^{\mathrm{F}}} \mathrm{Tr}(\mathbf{F}_{x}^{\star}, \mathscr{F}_{x}) = \sum_{i} (-\mathbf{I})^{i} \, \mathrm{Tr}(\mathbf{F}^{\star}, \, \mathbf{H}_{c}^{i}(\mathbf{X}, \, \mathscr{F})).$$

Une formule analogue vaut pour les itérés de F: le  $n^{\text{ième}}$  itéré de  $F^*$  définit des morphismes  $F_x^{*n}: \mathscr{F}_{F_x^{n}(x)} \to \mathscr{F}_x$ ; pour x fixe sous  $F^n$ ,  $F_x^{*n}$  est un endomorphisme, et

(1.12.1) 
$$\sum_{x \in X_F^n} \operatorname{Tr}(F_x^{*n}, \mathscr{F}_x) = \sum_{i} (-1)^i \operatorname{Tr}(F^{*n}, H_c^i(X, \mathscr{F})).$$

(1.13) Soient  $x_0 \in |X_0|$ , Z l'orbite correspondante de F dans |X| et  $x \in Z$ . L'orbite Z a  $\deg(x_0)$  éléments (1.4). On note  $F_{x_0}^*$  l'endomorphisme  $F_x^{*\deg(x_0)}$  de  $\mathscr{F}_x$ , et on pose

$$\det(\mathbf{I} - \mathbf{F}_{x_0}^* t, \mathscr{F}_0) = \det(\mathbf{I} - \mathbf{F}_{x_0}^* t, \mathscr{F}_x).$$

A isomorphisme près,  $(\mathscr{F}_x, F_{x_0}^*)$  ne dépend pas du choix de x. Ceci justifie d'omettre x de la notation. On utilisera une notation analogue pour d'autres fonctions de  $(\mathscr{F}_x, F_{x_0}^*)$ .

(1.14) Définissons  $Z(X_0, \mathscr{F}_0, t) \in \mathbf{Q}_{\ell}[[t]]$  par le produit

(1.14.1) 
$$Z(X_0, \mathscr{F}_0, t) = \prod_{x \in [X_0]} \det(I - F_x^* t^{\deg(x)}, \mathscr{F}_0)^{-1}.$$

Pour  $\mathcal{F}$  le faisceau constant  $\mathbf{Q}_{l}$ , on retrouve (1.1.2). D'après (1.5.3), la dérivée logarithmique de  $\mathbf{Z}$  est

$$(\mathbf{I.14.2}) \qquad \qquad t \frac{d}{dt} \log \mathbf{Z}(\mathbf{X}_0, \mathscr{F}_0, t) \stackrel{t}{=} \frac{t \frac{d}{dt} \mathbf{Z}(\mathbf{X}_0, \mathscr{F}_0, t)}{\mathbf{Z}(\mathbf{X}_0, \mathscr{F}_0, t)} = \sum_{n} \sum_{x \in \mathbf{X}^{p^n} = \mathbf{X}_0(\mathbf{F}_q n)} \mathrm{Tr}(\mathbf{F}_x^{*n}, \mathscr{F}_0) t^n.$$

Substituant (1.12.1) dans (1.14.2), on trouve par le même calcul qu'en (1.5) la généralisation suivante de (1.5.4)

(1.14.3) 
$$Z(X_0, \mathscr{F}_0, t) = \prod_i \det(I - F^*t, H_c^i(X, \mathscr{F}))^{(-1)^{i+1}}.$$

Cette formule est une identité dans  $\mathbf{Q}_{\ell}[[t]]$ .

(1.15) Il est parfois commode d'utiliser un langage galoisien plutôt que géométrique. Voici le dictionnaire.

Si  $\overline{\mathbf{F}}_q^1$  et  $\overline{\mathbf{F}}_q^2$  sont deux clôtures algébriques de  $\mathbf{F}_q$ ,  $(\mathbf{X}_0,\mathscr{F}_0)$  sur  $\mathbf{F}_q$  définit par extension des scalaires  $(\mathbf{X}_1,\mathscr{F}_1)$  sur  $\overline{\mathbf{F}}_q^1$  et  $(\mathbf{X}_2,\mathscr{F}_2)$  sur  $\overline{\mathbf{F}}_q^2$ . Tout  $\mathbf{F}_q$ -isomorphisme  $\sigma:\overline{\mathbf{F}}_q^1 \stackrel{\sim}{\to} \overline{\mathbf{F}}_q^2$  induit un isomorphisme

$$H_c^*(X_1, \mathscr{F}_1) \stackrel{\sim}{\to} H_c^*(X_2, \mathscr{F}_2).$$

En particulier, pour  $\overline{\mathbf{F}}_q^1 = \overline{\mathbf{F}}_q^2$  (noté  $\overline{\mathbf{F}}_q$ ), on trouve que  $\operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  agit sur  $\operatorname{H}_c^*(X, \mathscr{F})$  (action par transport de structure). Soit  $\varphi \in \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  la substitution de Frobenius. On vérifie que

$$F^* = \varphi^{-1}$$
 (dans End( $H_c^*(X, \mathcal{F})$ )).

Ceci amène à définir le Frobenius géométrique  $F \in Gal(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  comme étant  $\phi^{-1}$ . On a

$$(1.15.1)$$
  $F^* = F.$ 

Soit x un point géométrique de  $X_0$ , localisé en  $x_0 \in |X_0|$ . Par transport de structure, le groupe  $Gal(k(x)/k(x_0))$  agit sur la fibre  $(\mathscr{F}_0)_x$  de  $\mathscr{F}_0$  en x; en particulier, le Frobenius géométrique relatif à  $k(x_0) : F_{x_0} \in Gal(k(x)/k(x_0))$ , agit. Pour x défini par un point fermé, encore noté x, de X, on a  $\mathscr{F}_x = (\mathscr{F}_0)_x$ , et

(1.15.2) 
$$F_{x_0}^* \stackrel{=}{\underset{dfn}{=}} F_x^{* \deg(x_0)} = F_{x_0} \quad (dans \quad End(\mathscr{F}_x)).$$

En notations galoisiennes, (1.14.3) s'écrit

$$\prod_{x \in |\mathbf{X}_{\mathbf{0}}|} \det(\mathbf{I} - \mathbf{F}_x t^{\deg(x)}, \mathscr{F}_0)^{-1} = \prod_{\mathbf{i}} \det(\mathbf{I} - \mathbf{F}t, \mathbf{H}_{\mathbf{c}}^{\mathbf{i}}(\mathbf{X}, \mathscr{F}))^{(-1)^{i+1}}.$$

#### 2. La théorie de Grothendieck : dualité de Poincaré.

- (2.1) Pour expliquer la relation entre racines de l'unité et orientations, je vais au préalable redire dans un langage farfelu deux cas classiques.
- a) Variétés différentiables. Soit X une variété différentiable purement de dimension n. Le faisceau d'orientation  $\mathbf{Z}'$  sur X est le faisceau localement isomorphe au faisceau constant  $\mathbf{Z}$ , dont les sections inversibles sur un ouvert U de X correspondent aux orientations de U. Une orientation de X est un isomorphisme de  $\mathbf{Z}'$  sur le faisceau constant  $\mathbf{Z}$ . La classe fondamentale de X est un morphisme  $\operatorname{Tr}: H^n_c(X, \mathbf{Z}') \to \mathbf{Z}$ ; si X est orientée, il s'identifie à un morphisme  $\operatorname{Tr}: H^n_c(X, \mathbf{Z}) \to \mathbf{Z}$ . La dualité de Poincaré s'exprime à l'aide de la classe fondamentale.
- b) Variétés complexes. Soit **C** une clôture algébrique de **R**. Une variété algébrique complexe lisse, ou plutôt la variété différentiable sous-jacente, est toujours orientable. Pour l'orienter, il suffit d'orienter **C** lui-même. Ceci revient au choix :
  - a) à choisir l'une des deux racines de l'équation  $X^2 = -1$ ; on l'appelle +i;
- b) à choisir un isomorphisme de  $\mathbb{R}/\mathbb{Z}$  avec  $U^1 = \{z \in \mathbb{C} \mid |z| = 1\}$ ; +i est l'image de 1/4;
- c) à choisir l'un des deux isomorphismes  $x \mapsto \exp(\pm 2\pi i x)$  de  $\mathbb{Q}/\mathbb{Z}$  sur le groupe des racines de l'unité de  $\mathbb{C}$ , qui se prolonge par continuité en un isomorphisme de  $\mathbb{R}/\mathbb{Z}$  sur  $\mathbb{U}^1$ .

On note  $\mathbf{Z}(1)$  un  $\mathbf{Z}$ -module libre de rang un dont l'ensemble à deux éléments des générateurs soit en correspondance canonique avec l'un des ensembles à deux éléments a), b), c). Le plus simple est de prendre  $\mathbf{Z}(1) = \text{Ker}(\exp : \mathbf{C} \to \mathbf{C}^*)$ . Au générateur  $y = \pm 2\pi i$  correspond l'isomorphisme c) :  $x \mapsto \exp(xy)$ .

Soit  $\mathbf{Z}(r)$  la puissance tensorielle  $r^{\text{ième}}$  de  $\mathbf{Z}(1)$ . Si X est une variété algébrique complexe lisse purement de dimension complexe r, le faisceau d'orientation de X est le faisceau constant de valeur  $\mathbf{Z}(r)$ .

(2.2) Pour « orienter » les variétés algébriques sur k algébriquement clos de caractéristique o, il faut choisir un isomorphisme de  $\mathbb{Q}/\mathbb{Z}$  sur le groupe des racines de l'unité de k. L'ensemble de ces isomorphismes est un espace principal homogène sous  $\widehat{\mathbb{Z}}^*$  (non plus sous  $\mathbb{Z}^*$ ). Lorsqu'on s'intéresse seulement à la cohomologie  $\ell$ -adique, il suffit de considérer les racines de l'unité d'ordre une puissance de  $\ell$ , et de supposer la caractéristique p de k différente de  $\ell$ . On note  $\mathbb{Z}/\ell^n(1)$  le groupe des racines de l'unité de k d'ordre divisant  $\ell^n$ . Pour n variable, les  $\mathbb{Z}/\ell^n(1)$  forment un système projectif, d'applications de transition les

$$\sigma_{m,n}: \mathbb{Z}/\ell^m(\mathbf{1}) \to \mathbb{Z}/\ell^n(\mathbf{1}): x \mapsto x^{\ell^{m-n}}.$$

On pose  $\mathbf{Z}_{\ell}(\mathbf{I}) = \lim \operatorname{proj} \mathbf{Z}/\ell^{n}(\mathbf{I})$  et  $\mathbf{Q}_{\ell}(\mathbf{I}) = \mathbf{Z}_{\ell}(\mathbf{I}) \otimes_{\mathbf{Z}_{\ell}} \mathbf{Q}_{\ell}$ . On note  $\mathbf{Q}_{\ell}(r)$  la puissance tensorielle  $r^{\text{lème}}$  de  $\mathbf{Q}_{\ell}(\mathbf{I})$ ; pour  $r \in \mathbf{Z}$ , r négatif, on pose encore  $\mathbf{Q}_{\ell}(r) = \mathbf{Q}_{\ell}(-r)^{\sim}$ .

En tant qu'espace vectoriel sur  $\mathbf{Q}_{\ell}$ ,  $\mathbf{Q}_{\ell}(1)$  est isomorphe à  $\mathbf{Q}_{\ell}$ . Toutefois le groupe des automorphismes de k agit non trivialement sur  $\mathbf{Q}_{\ell}(1)$ : il agit via le caractère à valeurs dans  $\mathbf{Z}_{\ell}^*$  qui donne son action sur les racines de l'unité. En particulier, si  $k = \overline{\mathbf{F}}_q$ , la substitution de Frobenius  $\varphi: x \mapsto x^q$  agit par multiplication par q.

Soit X une variété algébrique lisse purement de dimension n sur k. Le faisceau d'orientation de X en cohomologie  $\ell$ -adique est le  $\mathbf{Q}_{\ell}$ -faisceau constant  $\mathbf{Q}_{\ell}(n)$ . La classe fondamentale est un morphisme

Tr: 
$$H_c^{2n}(X, \mathbf{Q}_{\ell}(n)) \to \mathbf{Q}_{\ell}$$
,

soit encore

Tr: 
$$H_c^{2n}(X, \mathbf{Q}_{\ell}) \to \mathbf{Q}_{\ell}(-n)$$
.

Théorème (2.3) (dualité de Poincaré). — Pour X propre et lisse purement de dimension n, la forme bilinéaire

$$\mathrm{Tr}(x \cup y) \; : \; \mathrm{H}^{i}(\mathrm{X}, \, \mathbf{Q}_{\ell}) \otimes \mathrm{H}^{2n-i}(\mathrm{X}, \, \mathbf{Q}_{\ell}) \to \mathbf{Q}_{\ell}(-n)$$

est une dualité parfaite (elle identifie  $H^i(X, \mathbf{Q}_{\ell})$  au dual de  $H^{2n-i}(X, \mathbf{Q}_{\ell}(n))$ ).

- (2.4) Soient  $X_0$  une variété algébrique propre et lisse sur  $\mathbf{F}_q$ , purement de dimension n, et X sur  $\overline{\mathbf{F}}_q$  déduit de  $X_0$  par extension des scalaires. Le morphisme (2.3) est compatible à l'action de  $\mathrm{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$ . Si les  $(\alpha_j)$  sont les valeurs propres du Frobenius géométrique F agissant sur  $H^i(X, \mathbf{Q}_\ell)$ , les valeurs propres de F agissant sur  $H^{2n-i}(X, \mathbf{Q}_\ell)$  sont donc les  $(q^n\alpha_i^{-1})$ .
- (2.5) Supposons pour simplifier X connexe. La démonstration (2.4) se transpose comme suit dans un langage géométrique, plutôt que galoisien (cf. (1.15)).
- a) Le cup-produit met  $H^{i}(X, \mathbf{Q}_{\ell})$  et  $H^{2n-i}(X, \mathbf{Q}_{\ell})$  en dualité parfaite à valeur dans  $H^{2n}(X, \mathbf{Q}_{\ell})$ , qui est de dimension un.
- b) Le cup-produit commute à l'image réciproque  $F^*$  par le morphisme de Frobenius  $F: X \rightarrow X$ .
- c) Le morphisme F est fini et de degré  $q^n$ : sur  $H^{2n}(X, \mathbf{Q}_{\ell})$ ,  $F^*$  est la multiplication par  $q^n$ .
  - d) Les valeurs propres de F\* ont donc la propriété (2.4).
- (2.6) On pose  $\chi(X) = \sum_{i} (-1)^{i} \dim H^{i}(X, \mathbf{Q}_{\ell})$ . Si n est impair, la forme  $\operatorname{Tr}(x \cup y)$  sur  $H^{n}(X, \mathbf{Q}_{\ell})$  est alternée; l'entier  $n\chi(X)$  est donc toujours pair. On déduit facilement de (1.5.4) et de (2.3), (2.4) que

$$\mathbf{Z}(\mathbf{X}_0,\,t) = \mathbf{\varepsilon}.\,q^{\frac{-n\chi(\mathbf{X})}{2}}.\,t^{-\chi(\mathbf{X})}.\,\mathbf{Z}(\mathbf{X}_0,\,q^{-n}t^{-1})$$