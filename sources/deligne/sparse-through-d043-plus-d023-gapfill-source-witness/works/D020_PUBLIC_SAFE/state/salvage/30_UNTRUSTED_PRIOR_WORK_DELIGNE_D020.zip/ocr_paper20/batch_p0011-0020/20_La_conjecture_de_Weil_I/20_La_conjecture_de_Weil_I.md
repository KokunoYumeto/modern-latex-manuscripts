de sa fibre en un point g~nEral; c'est un espace d'invariants sous un groupe de monodromie locale.

*Ttdorkme (2.* I~,). J *La forme bilingaire*  Tr(xuy) : H'(X, j.~-)| -+ H~(X,j. -~-| H2(X,j.(~'| ~'v) (i)) -+ H~(X, LQt(I))----H~(X, Qt(I)) ~ Qt *est une dualit~ parfaite.* 

- (2. ~3) I1 nous sera commode de disposer des Qt-faisceaux *Qt(r)* sur un quelconque schfma X off test inversible. Le tout est de ddfinir les Z/f'(I). Par d6finition, Z/g"(~) est le faisceau 6tale des racines (~)i~ de l'unit6.
  - (2. I4) *Indications bibliographiques sur les w167 I et 9.*
- A) Tousles r~sultats importants en cohomologie dtale se d6montrent d'abord pour des faisceaux de torsion. L'extension aux Qt-faisceaux se fait par des passages A la limite formels. Dans ce qui suit, pour chaque thdor6me citd, je renverrai non point une rdfdrencc off il cst ddmontrd, mais ~ une rdf~rence off son analogue pour les faisceaux de torsion l'est.
- B) A l'exception de la formule de Lefschetz et de (2. I2), les r~sultats de cohomologic 6tale utilis6s dans cet article sont tous d6montr6s dans SGA 4. Pour ceux d6j~ 6nonc6s, les r6f6renees sont : d6finition des H i : VII; d6finition des Hi0 : XVII 5-I; th6or6me de finitude : XIV I, compldt6 en XVII 5.3; dimension cohomologique : X; dualit6 de Poincar6 : XVIII.
- C) La relation entre les divers Frobenius ((I .4), (I. i i), (I. I5) ) est expliqu~e en ddtail dans SGA 5, XV, w167 2.
- D) L'interpr6tation cohomologique des fonctions Z (I. 14. 3) est clairement exposde dans [i]; toutefois, la formule de Lefschetz (i. I2), pour X une courbe projective et lisse, y est utilisde, mais non d6montr~e. Pour la ddmonstration, il faut, h6las, renvoyer SGA 5-
- E) La forme (2.12) du th~or6me de dualit6 de Poincard r6sulte du rdsultat g6n6ral SGA 4, XVIII (3-2.5) (pour S=Spec(k), X=X, K=j.o~-, L=Qt ) par un calcul local qui n'est pas difficile. L'dnonc6 figurera explicitement dans la version d6finitive de SGA 5. Dans le cas off nous l'utiliserons (ramification de o~" mod6r6e), on pourrait l'obtenir par voie transcendante, en relevant X et o~" en caractdristique o.

## **3. La majoration fondamentale.**

Le rdsultat de ce paragraphea 6t6 catalysd par la lecture de Rankin [3].

(3. i) Soient U 0 une courbe sur Fq, compl6ment dans p1 d'un ensemble fini de points ferm6s, U la courbe sur F~ qui s'en d~duit, u un point ferm6 de U, ~0 un Qt-faisceau constant tordu sur U 0 et o~" son image r6ciproque sur U.

Soit ~3eQ. Nous dirons que ~0 est de *poids ~* si pour tout xelU0l , les valeurs propres de F~ agissant sur o~" 0 (i. i3) sont des nombres alg6briques dont tous los conjugu& complexes sont de valeur absolue ~/2. Par exemple, Qt(r) est de poids --2r.

*TMor~me* (3.2). -- *Faisons les hypothkses suivantes :* 

(i) *No est muni d'une forme bilindaire alternge non ddgdngrde* 

$$\psi: \mathscr{F}_0 \otimes \mathscr{F}_0 \to \mathbf{Q}_{\ell}(-\beta) \qquad (\beta \in \mathbf{Z}).$$

- (ii) *L'image de* 7q(U, *u) dans* GL(o~) *est un sous-groupe ouvert du groupe symplectique*  **Sp(~,** +~).
  - (iii) *Pour tout* x~lUo[, *le polyn6me* det(l--F,t,~0) *est ?z coefficients rationnels.*

*Alors, ~" est de poids ~.* 

On peut supposer, et nous supposerons, que U est affine et que ~'~ o.

2k Lemme (3.3). -- *Soit 2k un entier pair et notons (~o la puissance tensorieUe (2k) ~~ de N o. Pour x~ t* Uol , *la ddrivde logarithmique* 

$$t\frac{d}{dt}\log(\det(\mathbf{I}-\mathbf{F}_xt^{\deg(x)},\overset{2k}{\bigotimes}\mathscr{F}_0)^{-1})$$

*est une sdrie formelle ?z coefficients rationnels positifs.* 

L'hypoth~se (iii) assure que, pour tout n, Tr(F2,~o)~Q.. Le nombre

$$\operatorname{Tr}(\mathbf{F}_{x}^{n}, \overset{2k}{\otimes} \mathscr{F}_{0}) = \operatorname{Tr}(\mathbf{F}_{x}^{n}, \mathscr{F}_{0})^{2k}$$

est donc rationnel positif, et on applique (I .5-3).

2k *Lemme* (3.4:)- -- *Lesfacteurs locaux* det(I--F,t a'eC~/, @~o) -1 *sont des sdries formelles d coefficients rationnels positifs.* 

*2k*  La s6rie formelle log det(l--F~t dgCxl, @~'0) -x est sans terme constant; d'apr& (3.3), ses coefficients sont >o; les coefficients de son exponentielle sont done 6galement positifs.

Lemme (3.5). -- *Soit f=Y~a~,t" une suite de sgries formelles de terme constant un, fl ' et ?z coefficients rdels positifs. On suppose que l'ordre de f -- I tend vers l'infini avec i, et on pose f =H f~. Alors, le rayon de convergence absolue de f~ est au moins dgal ?z celui def.* 

Si 
$$f = \sum_{n} a_n t^n$$
, on a en effet  $a_{i,n} \le a_n$ .

Lemme (3.6). -- *Sous les hypotheses de* (3.5), *si f er les f~ sont les ddveloppements en sdrie de Taylor de fonctions m&omorphes, alors* 

$$\inf\{|z| | f(z) = \infty\} \le \inf\{|z| | f_i(z) = \infty\}.$$

Ces nombrcs sont cn effct les rayons de convergcnce absolue.

(3-7) Pour chaque partition P de [I, 2k] en parties ~ deux 616ments {i~,L} (i~<J~), on dEfinit

$$\psi_{\mathbf{P}}: \overset{2k}{\otimes} \mathscr{F}_{\mathbf{0}} \to \mathbf{Q}_{\mathbf{f}}(-k\beta): x_{\mathbf{1}} \otimes \ldots \otimes x_{2k} \mapsto \prod_{\alpha} \psi(x_{i_{\alpha}}, x_{j_{\alpha}}).$$

Soit x un point ferm6 de X. L'hypoth6se (ii) assure que les coinvariants de nl(U, u) 2k 2/r dans | sont les coinvariants dans | du groupe sympleetique tout entier (re x est Zariski-dense dans Sp). Soit ~ l'ensemble des partitions P. D'aprbs H. Weyl *(The classical groups,* Princeton University Press, chap. VI, w I), pour ~' c~ eonvenable, d6pendant de dim(o~), les +p pour Pe~' d6finissent un isomorphisme

$$(\overset{2k}{\otimes}\mathscr{F}_{u})_{\pi_{1}} = (\overset{2k}{\otimes}\mathscr{F}_{u})_{\operatorname{Sp}} \overset{\sim}{\to} \mathbf{Q}_{\ell}(-k\beta)^{\mathscr{P}}.$$

Soit N le nombre d'~l~ments de ~'. D'apr~s (2. io), la formule ei-dessus donne

$$H_c^2(\mathbf{U}, \overset{2k}{\bigotimes} \mathscr{F}) \simeq \mathbf{Q}_d(-k\beta-1)^N.$$

2J~ Puisque H~ @~)=o, la formule (I.I4.3) se rdduit

$$Z(\mathbf{U}_0, \overset{2k}{\otimes} \mathscr{F}_0, t) = \frac{\det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^1(\mathbf{U}, \overset{2k}{\otimes} \mathscr{F}))}{(1 - q^{k\beta + 1}t)^N}.$$

Gette fonction Zest done le dfveloppement en sfrie de Taylor d'une fonction rationnelle n'ayant de p61e qu'en *t=I/q ~+1.* Nous utiliserons seulement le fait que les p61es sont de valeur absolue I/q ~+1 dans C. Gela pourrait se dfduire d'arguments g6n6raux sur les groupes r6duetifs. Si 0~ est une valeur propre de F, sur ~0, alors ~ est une valeur 2k propre de F x sur | o~ 0. Notons encore ~ un quelconque conjugu6 complexe de 0~. La 2k puissance inverse I/~ ~'/d~') est un p61e de det(I--F,t d~ @o~-)-a. D'apr~s (3.4) et (3.6), on a done

$$|1/q^{k\beta+1}| \leq |1/\alpha^{2k/\deg(x)}|,$$

soit 
$$|\alpha| \leq q_x^{\frac{9}{2} + \frac{1}{2k}}$$
.

Faisant tendre k vers l'infini, on trouve que

$$|\alpha| \leq q_x^{\beta/2}$$

Par ailleurs, l'existence de + assure que q~ ~-1 est figalement valeur propre, d'ofl l'in6galitfi

$$|q_x^{\beta} \alpha^{-1}| \leq q_x^{\beta/2}$$

soit 
$$q_x^{p/2} \leq |\alpha|$$
.

Ceci ach~ve la d6monstration.

Corollaire (3.8). — Soit  $\alpha$  une valeur propre de F\* agissant sur  $H^1_c(U, \mathcal{F})$ . Alors,  $\alpha$  est un nombre algébrique, dont tous les conjugués complexes vérifient

$$|\alpha| < q^{\frac{\beta+1}{2}+\frac{1}{2}}$$
.

La formule (1.14.3) pour Fo se réduit à

$$Z(U_0, \mathscr{F}_0, t) = \det(I - F^*t, H_c^1(U, \mathscr{F})).$$

Le premier membre est une série formelle à coefficients rationnels, vu son développement en produit et l'hypothèse (iii). Le second membre est donc un polynôme à coefficients rationnels;  $1/\alpha$  en est racine. Ceci prouve déjà que  $\alpha$  est algébrique. Pour achever la démonstration, il suffit de vérifier que le produit infini qui définit  $Z(U_0, \mathscr{F}_0, t)$  converge absolument (donc est non nul) pour  $|t| < q^{\frac{-\beta}{2}-1}$ .

Soit N le rang de F, et posons

$$\det(\mathbf{I} - \mathbf{F}_x t, \mathscr{F}) = \prod_{i=1}^{N} (\mathbf{I} - \alpha_{i, x} t).$$

D'après (3.2),  $|\alpha_{i,z}| = q_z^{9/2}$ . La convergence du produit infini Z résulte de celle de la série

$$\sum_{i,x} |\alpha_{i,x} t^{\deg(x)}|.$$

Pour  $|t|=q^{\frac{-\beta}{2}-1-\varepsilon}$  ( $\varepsilon > 0$ ), on a

$$\sum_{i,s} |\alpha_{i,s} t^{\deg(s)}| = N \sum_{s} q_s^{-1-s}.$$

Sur la droite affine, il y a  $q^n$  points à valeurs dans  $\mathbf{F}_{q^n}$ , donc au plus  $q^n$  points fermés de degré n. On a donc

$$\sum_{x} q_{x}^{-1-\epsilon} \leq \sum_{n} q^{n} \cdot q^{n(-1-\epsilon)} = \sum_{n} q^{-n\epsilon} \leq \infty,$$

ce qui achève la démonstration.

Corollaire (3.9) — Soient  $j_0$  l'inclusion de  $U_0$  dans  $P_{p_q}^1$ , j celle de U dans  $P^1$ , et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^1(P^1, j_*\mathcal{F})$ . Alors  $\alpha$  est un nombre algébrique, dont tous les conjugués complexes vérissent

$$q^{\frac{3+1}{2}-\frac{1}{2}} \le |\alpha| \le q^{\frac{3+1}{2}+\frac{1}{2}}.$$

Un segment de la suite longue de cohomologie définie par la suite exacte courte

$$0 \rightarrow j_1 \mathcal{F} \rightarrow j_* \mathcal{F} \rightarrow j_* \mathcal{F} / j_1 \mathcal{F} \rightarrow 0$$

 $(j_1 := prolongement par o)$  s'écrit

$$H^1(\mathbf{U}, \mathscr{F}) \to H^1(\mathbf{P}^1, j_*\mathscr{F}) \to 0.$$

La valeur propre ~ apparalt donc d6j~ dans H~(U, ~-), et est justiciable de (3.8) :

$$|\alpha| < q^{\frac{\beta+1}{2}+\frac{1}{2}}$$

La dualit~ de Poincar6 (e. I2) assure que q~+t~-i est dgalement valeur propre, d'ofi B+I . 1 l'inEgalitE I q~ + 1 e- a [ < **q 9 2** 

et le corollaire.

## **4" La th~rle de Lei'schetz : th~orle locale.**

(4. x) Sur C, les rdsultats locaux de Lefschetz sont les suivants.

Soient D={z] Izl<I } le disque unit6, D\*=D--{o}, et f: X-+D un morphisme d'espaces analytiques. On suppose que

- *a)* X est non singulier, et purement de dimension n+I;
- *b) f* est propre;
- *c) f* est lisse en dehors d'un point x de la fibre sp6ciale X0=f-l(o);
- *d)* en x, f pr6sente un point quadratique non d6g6n6r6.

Soient t@o dans D et X t *=f-l(t) <<* la >> fibre g6ndrale. Aux donn6es pr6c6dentes, on associe :

~) des morphismes de sp6cialisation sp :Hi(X0, Z)-+H~(XI, Z) : X o est un r6tracte par ddformation de X, et *sp* est la fl~che compos6e

$$H^{i}(X_{0}, \mathbf{Z}) \stackrel{\sim}{\leftarrow} H^{i}(X, \mathbf{Z}) \rightarrow H^{i}(X_{i}, \mathbf{Z});$$

~) des transformations de monodromie T : Hi(Xt, Z) -~ H~(X~, Z), qui d6crivent l'effet sur les cycles singuliers de X~ de << iZaire tourner t autour de o >>. C'est encore l'action sur H~(Xt, Z), fibre en t du syst~me local K~f.ZlD ", du g6n6rateur positif de ~I(D', t).

La th6orie de Lefschetz ddcrit ~) et ~) en terme du *cycle gvanescent* 3eH"(Xt, Z). Ce cycle est bien d6fmi au signe pr~s. Pour *i#n,* n + i, on a

$$H^i(X_0, \mathbb{Z}) \stackrel{\sim}{\to} H^i(X_i, \mathbb{Z}) \quad (i \neq n, n+1).$$

Pour i----n, n+l, on a unesuite exacte

$$o \to H^n(X_0, \mathbf{Z}) \to H^n(X_t, \mathbf{Z}) \xrightarrow{\mathbf{z} \mapsto \{\mathbf{z}, \, \delta\}} \mathbf{Z} \to H^{n+1}(X_0, \mathbf{Z}) \to H^{n+1}(X_t, \mathbf{Z}) \to o.$$

Pour i4: n, la monodromie T est l'identit6. Pour i = n, on a

$$\mathbf{T}\mathbf{x} = \mathbf{x} \pm (\mathbf{x}, \, \delta) \delta.$$

Les valeurs de ce +, de TS, et de (8, 3) sont les suivantes :

$$n \mod 4$$

La transformation de monodromie T respecte la forme d'intersection Tr(xoy) sur H"(Xt, Z). Pour n impair, c'est une transvection symplectique. Pour n pair, c'est une sym&rie orthogonale.

(4.2) Voici l'analogue de (4. I) en g~om&rie algdbrique abstraite. Le disque D est remplac6 par le spectre d'un anneau de valuation discr&e hens~lien A k corps rdsiduel algdbriquement clos. Soient S ce spectre, B son point g6n6rique (spectre du corps des fractions de A), s son point ferm~ (spectre du corps r&iduel). Le r61e de test joud par un point g~n6rique g6om&rique ~ (spectre d'une cl6ture algdbrique du corps des fractions de A).

Soit f : X-+S un morphisme propre, avec X r~gulier purement de dimension n+ I. On supposeflisse, sauf pour un point quadratique ordinaire x dans la fibre sp&iale X,. Soit g un nombre premier diffdrent de la caract6ristique r&iduelle p de S. Notant X~ la fibre g~n6rique g~om&rique, on dispose encore d'un morphisme de sp&ialisation

$$(4.2.1) sp: H^i(X_{\epsilon}, \mathbf{Q}_{\ell}) \stackrel{\sim}{\leftarrow} H^i(X, \mathbf{Q}_{\ell}) \rightarrow H^i(X_{\overline{\eta}}, \mathbf{Q}_{\ell}).$$

Le r6Ie de Test jou6 par Faction du groupe d'inertie I=GaI(~/~), agissant sur H~(X~, Qt) par transport de structure (cf. (I. 15) ) :

$$(\mathbf{4}.\mathbf{2}.\mathbf{2}) \qquad \qquad \mathbf{I} = \mathrm{Gal}(\widetilde{\eta}/\eta) \to \mathrm{GL}(\mathbf{H}^i(\mathbf{X}_{\widetilde{\eta}}, \mathbf{Q}_{\ell})).$$

Les donndes (4.2. I), (4.2.2) ddcrivcnt entifirement les faisceaux *R~f.Qt* sur S.

(4-3) Posons *n=2m* pour n pair, et n=2m+I pour n impair. (4.2. I) et (4.2.2) se d&rivent encore en terme d'un cycle Evanescent

$$(4.3.1) \delta \in H^n(X_{\overline{\eta}}, \mathbf{Q}_{\ell})(m).$$

Ce cycle est bien ddfini au signe pr&.

Pour *i4=n,* n+I, on a

$$(4.3.2)$$

Pour i~ n~ n-t-l, on a une suite exacte

(4.3.3)

$$0 \to H^{n}(X_{\epsilon}, \mathbf{Q}_{\ell}) \to H^{n}(X_{\overline{\eta}}, \mathbf{Q}_{\ell}) \xrightarrow{z \mapsto T_{n}(z \cup \delta)} \mathbf{Q}_{\ell}(m-n) \to H^{n+1}(X_{\epsilon}, \mathbf{Q}_{\ell}) \to H^{n+1}(X_{\overline{\eta}}, \mathbf{Q}_{\ell}) \to 0.$$

L'action (4.2.2) de I (la monodromie locale) est triviale si elle se ddcrit comme suit. *i4=n.* Pour *i---n,* 

A) *n impair. --* On dispose d'un homomorphisme canonique

$$t_{\ell}: \mathbf{I} \to \mathbf{Z}_{\ell}(\mathbf{I}),$$

et l'action de eel est

$$x \mapsto x \pm t_{\ell}(\sigma)(x, \delta)\delta$$
.

B) *n pair. --* Ce cas ne nous servira pas. Disons seulement que, si poe2, un unique caract~re d'ordrc deux il cxiste

$$\varepsilon: \mathbf{I} \to \{\pm 1\},$$

et qu'on a

$$\sigma x = x$$
 si  $\varepsilon(\sigma) = 1$   
 $\sigma x = x \pm (x, \delta)\delta$  si  $\varepsilon(\sigma) = -1$ 

Les signes \_+\_ dans A) et B) sont les retirees qu'en (4. i).

- (4.4) Ces r~sultats apportent les informations suivantes sur les *Rif, Qt .*
- a) *Si ~+o :* 
  - I) Pour *i4:n,* le faisceau *R~f.Qt* est constant.
  - 2) Soit j l'inclusion de ~ dans S. On a

$$\mathbf{R}^n f_{\bullet} \mathbf{Q}_{\ell} = j_{\bullet} j^{\bullet} \mathbf{R}^n f_{\bullet} \mathbf{Q}_{\ell}.$$

- b) Si ~ = o : (C'est 1~ un cas exceptionnel. Puisque (~, ~)= ~ pour n pair, il ne peut se produire que pour n impair.)
  - I) Pour *i4=n+I,* le faisceau Rif.Qt est constant.
  - 2) Soit *Qt(m-n),* le faisceau *Qt(m-n)* sur {s}, prolong8 par z~ro sur S. On a une suite exacte

$$0 \rightarrow \mathbf{Q}_{\ell}(m-n)_{\bullet} \rightarrow \mathbf{R}^{n+1} f_{\bullet} \mathbf{Q}_{\ell} \rightarrow f_{\bullet} f^{\bullet} \mathbf{R}^{n+1} f_{\bullet} \mathbf{Q}_{\ell} \rightarrow 0,$$

<sup>9</sup>.,Rn + 1 ~c g-~ off *j,j d,',c,t* est un faisceau constant.

## **5. La th6orie de Lefschetz : thc~rie globale.**

(5- x) Sur C, les r6sultats de Lefschetz sont les suivants. Soient Pun espace projectif de dimension > I, et P l'espace projectif dual; ses points paramdtrisent les hyperplans de P, et on note H L l'hyperplan d6fini par t~P. Si A est un sous-espace lin6aire de codimension 2 de P, les hyperplans contenant A sont paramdtr6s par les points d'une droite DcP, la *duale* de A. Ces hyperplans (Ht)te D forment le *pinceau d'axe A.* 

Soit X r une vari6t6 projective non singuli~re connexe et de dimension n + I. Soit XcX• l'ensemble des couples (x, t) tels que x~H t. Les applications premiere et seconde coordonnfe forment un diagramme

$$\begin{array}{ccc} X \xleftarrow{\pi} & \widetilde{X} \\ & & \downarrow \\ & & D \end{array}$$

La fibre de fen tED est l a section hyperplane Xt----XnH t de X.

*290* 

Fixons X, et prenons A assez gdndral. Alors :

- A) A est transverse ~ X, et X se ddduit de X par 6clatement de A n X. En particulier, ,X est non singulier.
- B) I1 existe une partie finie S de D et pour chaque sr un point xseX,, tels que f soit lisse en dehors des x,..
  - C) Les x, sont des points critiques non ddgdnfirds de f.

Pour chaque *seS,* la thdorie de Lefschetz locale (4. I) s'applique donc ~un petit disque D, autour de set ~f-l(D,).

(5.2) On pose U~D--S. Soit ueU, et choisissons des lacets disjoints (Y~),es partant de u, avec u tournant une lois autour de s :

![](_page_17_Picture_8.jpeg)

Ges lacets engendrent le groupe fondamental =I(U, u). Ge groupe agit sur H~(X~, Z), fibre en u du syst~me local R~f.ZtU. D'apr~s la thdorie locale (4. I), k chaque seS correspond un cycle dvanescent ~seH"(X~, Z); ces cycles dependent du choix des y,. Pour *i+-n,* l'action de nl(U, u) sur H~(X~, Z) est triviale. Pour *i~-n,* on a

(5.2.1) 
$$\gamma_s x = x \pm (x, \delta_s) \delta_s.$$

Soit E le sous-espace de H"(X~, O,~) engendr6 par les 8, (pattie *&anescente* de la cohomologie).

*Proposition* (5.3). -- E *est stable sous l'action du groupe de monodromie* nl(U , *u). L'orthogonal E • de E (pour la forme d'intersection* Tr(xuy)) *est le sous-espace des invariants de la monodromie dans* H"(X~, Q).

Les "(, engendrant le groupe de monodromie, c'est clair sur (5.2. i).

*TMorkme* (5.4). *-- Les cycles gvanescents • 8, (pris au signe prks) sont conjugugs sous l'action de* ~I(U, u).

Soit X c~' la varidtd duale de X : c'est 1'ensemble des teP tels que H t soit tangent ~ X, i.e. tels que X t soit singulier, ou que XcH t. La variEtE X est irrE-

ductible. Soit YcX• l'espace des couples (x, t) tels que xeH t. On dispose d'un diagramme

$$\begin{array}{ccc} \mathbf{X} &\longleftarrow & \mathbf{Y} \\ && & \downarrow_{\mathbf{J}} \\ && \check{\mathbf{P}} \end{array}$$

La fibre de g en teP est la section hyperplane X t = X n H~ de X, et g est lisse en dehors de l'image r&iproque de X.

On retrouve la situation de (5. ~) en rempla~ant P par une droite DcP et Y par g-~(D). On a S---= D nX. D'apr6s un th~or~me de Lefschetz, pour D assez g~n~rale, l'application

$$\pi_1(D-S, u) \rightarrow \pi_1(\check{\mathbf{P}}-\check{\mathbf{X}}, u)$$

cst surjcctive. I1 suffit donc de montrer que les • sont conjuguds sous =1(P--X).

Pour x dans lc lieu lisse de codimension I de X, soient *ch* un chemin de t ~ x dans P--X, et y~ le lacet qui suit *ch* jusqu'au voisinage de X, tourne une lois autour de :~, puis revicnt ~ t par *ch.* Les laccts Yz (pour *ch* variable) sont conjugu6s entre eux. Puisquc :~ est irrdductible, dcux points du lieu lissc dc X pcuvcnt toujours, dans )(, 6tre joints par un chemin qui ne quitte pas le lieu lissc. I1 en r&uhc quc la classc dc conjugaison dc 7~ ne ddpend pas de x. En particulier, les Y, sont conjuguds entre eux. On lit sur (5.2. i) quc ceci impliquc la conjugaison des • 3,.

*Corollaire* (5.5). -- *L' action de* =I(U, *u) sur* ]~/(E n E • *est absolument irrgductible.* 

Soit FcE| un sous-espace stable sous la monodromie. Si Fqz(EnE• il existe xeF et seS tels que (x, 3,)+o. On a alors

$$\gamma_s x - x = \pm (x, \delta_s) \delta_s \in \mathbf{F},$$

et 88~F. D'apr& (5-4), tous les 88 sont alors dans F, et F----E. Ceci prouve (5-5).

(5-6) Ces rdsultats se transposent comme suit en g6om6tric algdbrique abstraite.

Soient Pun espace projectif de dimension 2> i sur k algdbriquemcnt clos de caract&istique pet X r P une varidtd projective non singuli~re connexe et de dimension n+ I. Pour A un sous-espace lin6aire de P de codimension 2, on ddfinit comme en (5. I) D et le pinceau (Ht)teD, les X,, ,X et le diagramme (5. I. I). On dit que les (Xt),e D forment un *pinceau de Lefschetz* de sections hyperplanes si les conditions suivantes sont vdrifides :

A) L'axe A est transverse h X. L'espace X se ddduit alors de X par &latement de AnX, et est lisse.

- B) I1 existe une partie finie S de D et pour chaque seS un point *xseX,,* tels que f soit lisse en dehors des x,.
  - C) x, est un point singulier quadratique ordinaire de X,.

Pour chaque *seS,* la th6orie de Lefschetz locale du w 4 s'applique au spectre D, de l'hensdlis6 de l'anneau local de Den *s,* et /~ .~ =X•

(5.7) Soient N la dimension de P, r un entier > i, et ~(rl le plongement de P dans l'espace projectif de dimension (s+')-i, de coordonn~es homog~nes les monSmes de degr6 r en les coordonn~es homog~nes de P. Les sections hyperplanes de t(,l(P) sont les hypersurfaces de degr~ r de P.

Si poeo, il se peut qu'aucun pinceau de sections hyperplanes de X ne soit de Lefschetz. Toutefois, si r>2 et qu'on remplace le plongement projectif donnfi t~ :X~+P par ,~=~(r)oh, alors, dans ce nouveau plongement, tout pinceau assez g6n6ral est de Lefschetz. En d'autres termes, si r~ 2, un pinceau assez g6ndral de sections hypersurfaces de degr6 r de X est toujours de Lefschetz.

(5.8) Dans la suite de cette discussion, nous 6tudions un pinceau de Lefschetz de sections hyperplanes de X, *en excluant le cas p -= 2, n pair. Le* cas off nest impair nous suffirait pour la suite. On pose U=D--S. Soient ueU et l un nombre premier -~ep. Les r6sultats locaux du w 4 montrent que *Rnf.Qt* est *moddrdment* ramifi6 en chaque seS. Le groupe fondamental mod~r6 de U est un quotient du compldt6 profini du groupe fondamental transcendant analogue (rel6vement en caract6ristique o des rev6tements mod6r6s, et th6or6me d'existence de Riemann). La situation algdbrique est d6s lors toute pareille ~ la situation transcendante, et la transposition de r6sultats de Lefschetz se fait par des arguments standards. Dans la d6monstration de (5.4), le th6or6me de Lefschetz sur les nl devient le th6or6me de Bertini, et on dolt invoquer le lemme d'Abhyankar pour contr61er la ramification de *R'g.Q t* le long du lieu lisse de codimension un de N:.

Les rdsultats sont les suivants.

- a) *Si les cycles gvanescents sont non nuls :* 
  - I) Pour *iOen,* le faisceau *R~f.Q,t* sur D est constant.
  - 2) Soit j l'inclusion de U dans D. On a

$$R^{n}f_{\bullet}Q_{i}=f_{\bullet}f^{\bullet}R^{n}f_{\bullet}Q_{i}$$

3) Soit E cH"(X,, Qt) le sous-espace de la cohomologie engendr6 par les cycles 6vanescents. Ce sous-espace est stable sous ha(U, u), et

$$\mathbf{E}^{\perp} = \mathbf{H}^{n}(\mathbf{X}_{u}, \mathbf{Q}_{\ell})^{\pi_{i}(\mathbf{U}, u)}.$$

La reprdsentation de nl(U, u) sur E/(EnE • est absolument irr6ductible, et l'image de nx dans GL(E/(EcaE• est engendrde (topologiquement) par les *x-+x+(x, 3s)8 .* (s~S) (le signe i 6tant dftermin6 comme en (4. I)).