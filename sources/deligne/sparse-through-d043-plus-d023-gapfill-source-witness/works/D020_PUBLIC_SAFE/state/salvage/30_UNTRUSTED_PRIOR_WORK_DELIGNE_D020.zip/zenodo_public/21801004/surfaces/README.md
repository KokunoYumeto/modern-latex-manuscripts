# Pierre Deligne corpus archive

This is the maintained public archive for the Pierre Deligne author corpus.

- Concept DOI: <https://doi.org/10.5281/zenodo.20410853>
- This version: <https://doi.org/10.5281/zenodo.21801004>
- Release date: 2026-08-05
- Release scope: cumulative standalone French and English readers through D008; D010--D020 authority identity and boundary receipts; live corpus index; cumulative provenance

## Edition model

The only current edition deliverables are two independent editions:

1. a standalone French edition;
2. a standalone English edition.

No bilingual, side-by-side, paired, parallel, or interleaved reader is current production. The two inherited files whose names contain `Bilingual` are preserved solely as rejected historical evidence; they are not current canonical outputs.

## Exact state at this checkpoint

- D001--D007: source work reached EOF, but combined-layout lineage is rejected; separate French and English resealing remains pending.
- D008: separate French and English masters reached EOF and passed the recorded local QA; they have not been promoted beyond their recorded status.
- D009: production is hard-stopped and not opened.
- D010--D020: identity, authority hash, physical/printed boundaries, and EOF were replayed from the frozen authorities. No French or English production root was opened and no candidate was certified.
- Identity/source audit cursor: D021.
- Production cursor: D009, physical page 1, not opened while the direct production stop remains in force.

This is a bounded cumulative checkpoint, not a claim that the entire author corpus is complete.

## Current control delta

- D020 is directly confirmed as Pierre Deligne's French *La conjecture de Weil I*.
- The authority preserves the NUMDAM cover's colon form and the article heading's period form without conflating them.
- One vector cover plus 35 article scans prove the complete printed-page span 273--307, contents through Sections 1--8, terminal bibliography [1]--[4], SGA 4/5/7 sigla, 20 September 1973 received date, and physical EOF.
- All 35 article-image streams and all 36 page-content streams are distinct.

## Navigation

- `Deligne_FR.pdf`: active cumulative French reader, D001--D008, refreshed for this version's DOI/status.
- `Deligne_EN.pdf`: active cumulative English reader, D001--D008, refreshed for this version's DOI/status.
- `Deligne_FR.tex` and `Deligne_EN.tex`: independent cumulative LaTeX masters.
- `Deligne_Source.zip`: both masters plus the exact D001--D008 component TeX and PDF files they append.
- `DELIGNE_INDEX.csv` and `DELIGNE_INDEX.md`: author/work/status index.
- `CONTROL_D010-D020.zip`: exact D010--D020 identity receipts plus the cumulative custody, index, log, and workflow snapshot.
- `CHANGES.md`: concise release delta and reversals.
- `STATUS.json`: machine-readable scope and cursor state.
- `MANIFEST.csv`: filename, byte count, MD5, SHA-256, and lineage for every data file in this version.
- `MANIFEST.sha256`: self-excluding SHA-256 list covering every data file plus `MANIFEST.csv`.
- `DELIGNE_WORKFLOW.zip`: controlling archive workflow and cumulative append-only logs.

All inherited files retain their original names, bytes, checksums, and historical status. Release-ready translations in other languages remain producer-owned and retain producer-supplied status when incorporated.
