où  $\varepsilon = \pm 1$ . Si *n* est pair, notons N la multiplicité de la valeur propre  $q^{n/2}$  de  $F^*$  agissant sur  $H^n(X, \mathbf{Q}_{\ell})$  (i.e. la dimension du sous-espace propre généralisé correspondant). On a

$$\varepsilon = \begin{cases} \mathbf{I} & \text{si } n \text{ est impair} \\ (-\mathbf{I})^{\mathbf{N}} & \text{si } n \text{ est pair.} \end{cases}$$

C'est là la formulation de Grothendieck de l'équation fonctionnelle des fonctions Z.

(2.7) Nous aurons besoin d'autres formes du théorème de dualité. Le cas des courbes nous suffirait dans celles-ci. Si  $\mathscr{F}$  est un  $\mathbb{Q}_{\ell}$ -faisceau sur une variété algébrique X sur k algébriquement clos, nous noterons  $\mathscr{F}(r)$  le faisceau  $\mathscr{F}\otimes\mathbb{Q}_{\ell}(r)$ . Ce faisceau est (non canoniquement) isomorphe à  $\mathscr{F}$ .

Théorème (2.8). — Supposons X lisse purement de dimension n et  $\mathcal{F}$  constant tordu. Soit  $\mathcal{F}^{\sim}$  le dual de  $\mathcal{F}$ . La forme bilinéaire

$$\operatorname{Tr}(x \cup y) : \operatorname{H}^{i}(X, \mathscr{F}) \otimes \operatorname{H}^{2n-i}_{c}(X, \mathscr{F}^{\check{}}(n)) \to \operatorname{H}^{2n}_{c}(X, \mathscr{F} \otimes \mathscr{F}^{\check{}}(n)) \to \operatorname{H}^{2n}_{c}(X, \mathbf{Q}_{\ell}(n)) \to \mathbf{Q}_{\ell}$$
 est une dualité parfaite.

(2.9) Supposons X connexe et soit x un point fermé de X. Le foncteur  $\mathscr{F} \mapsto \mathscr{F}_x$  est une équivalence de la catégorie des  $\mathbb{Q}_{\ell}$ -faisceaux constants tordus avec celle des représentations  $\ell$ -adiques de  $\pi_1(X, x)$ . Via cette équivalence,  $H^0(X, \mathscr{F})$  s'identifie aux invariants de  $\pi_1(X, x)$  agissant dans  $\mathscr{F}_x$ :

(2.9.1) 
$$H^0(X, \mathscr{F}) \stackrel{\sim}{\to} \mathscr{F}_x^{\pi_1(X, x)}$$
.

D'après (2.8), pour X lisse et connexe de dimension n, on a donc

$$\mathrm{H}^{2n}_c(\mathrm{X},\mathscr{F}) = \mathrm{H}^0(\mathrm{X},\mathscr{F}\check{}(n))\check{} = ((\mathscr{F}_x\check{}(n))^{\pi_1(\mathrm{X},x)})\check{}.$$

La dualité échange invariants (plus grand sous-espace invariant) et coinvariants (plus grand quotient invariant). Cette formule se récrit donc

$$H_c^{2n}(X, \mathcal{F}) = (\mathcal{F}_x)_{\pi_1(X, x)}(-n).$$

Nous ne l'utiliserons que pour n=1.

Scholie (2.10). — Soient X une courbe lisse et connexe sur k algébriquement clos, x un point fermé de X et  $\mathcal{F}$  un  $\mathbf{Q}_t$ -faisceau constant tordu. On a

- (i)  $H_c^0(X, \mathcal{F}) = 0$  si X est affine.
- (ii)  $H_c^2(X, \mathscr{F}) = (\mathscr{F}_x)_{\pi_1(X, x)}(-1)$ .

L'assertion (i) signifie simplement que F n'a pas de section à support fini.

(2.11) Soient X une courbe projective, lisse et connexe sur k algébriquement clos, U un ouvert de X, complément d'un ensemble fini S de points fermés de X, j l'inclusion  $U \hookrightarrow X$  et  $\mathscr{F}$  un  $\mathbb{Q}_{\ell}$ -faisceau constant tordu sur U. Soit  $j_*\mathscr{F}$  le  $\mathbb{Q}_{\ell}$ -faisceau constructible image directe de  $\mathscr{F}$ . Sa fibre en  $x \in S$  est de rang inférieur ou égal au rang

de sa fibre en un point général; c'est un espace d'invariants sous un groupe de monodromie locale.

Théorème (2.12). — La forme bilinéaire  $\operatorname{Tr}(x \cup y) : \operatorname{H}^{i}(X, j_{*}\mathscr{F}) \otimes \operatorname{H}^{2-i}(X, j_{*}\mathscr{F}^{\check{}}(1)) \to \operatorname{H}^{2}(X, j_{*}\mathscr{F} \otimes j_{*}\mathscr{F}^{\check{}}(1)) \\ \to \operatorname{H}^{2}(X, j_{*}(\mathscr{F} \otimes \mathscr{F}^{\check{}})(1)) \to \operatorname{H}^{2}(X, j_{*}\mathbf{Q}_{\ell}(1)) = \operatorname{H}^{2}(X, \mathbf{Q}_{\ell}(1)) \to \mathbf{Q}_{\ell}$  est une dualité parfaite.

- (2.13) Il nous sera commode de disposer des  $\mathbf{Q}_{\ell}$ -faisceaux  $\mathbf{Q}_{\ell}(r)$  sur un quelconque schéma X où  $\ell$  est inversible. Le tout est de définir les  $\mathbf{Z}/\ell^n(1)$ . Par définition,  $\mathbf{Z}/\ell^n(1)$  est le faisceau étale des racines  $(\ell^n)^{\text{lèmes}}$  de l'unité.
  - (2.14) Indications bibliographiques sur les §§ 1 et 2.
- A) Tous les résultats importants en cohomologie étale se démontrent d'abord pour des faisceaux de torsion. L'extension aux  $\mathbf{Q}_{\ell}$ -faisceaux se fait par des passages à la limite formels. Dans ce qui suit, pour chaque théorème cité, je renverrai non point à une référence où il est démontré, mais à une référence où son analogue pour les faisceaux de torsion l'est.
- B) A l'exception de la formule de Lefschetz et de (2.12), les résultats de cohomologie étale utilisés dans cet article sont tous démontrés dans SGA 4. Pour ceux déjà énoncés, les références sont : définition des H<sup>i</sup> : VII; définition des H<sup>i</sup> : XVII 5.1; théorème de finitude : XIV 1, complété en XVII 5.3; dimension cohomologique : X; dualité de Poincaré : XVIII.
- C) La relation entre les divers Frobenius ((1.4), (1.11), (1.15)) est expliquée en détail dans SGA 5, XV, §§1, 2.
- D) L'interprétation cohomologique des fonctions Z (1.14.3) est clairement exposée dans [1]; toutefois, la formule de Lefschetz (1.12), pour X une courbe projective et lisse, y est utilisée, mais non démontrée. Pour la démonstration, il faut, hélas, renvoyer à SGA 5.
- E) La forme (2.12) du théorème de dualité de Poincaré résulte du résultat général SGA 4, XVIII (3.2.5) (pour  $S = \operatorname{Spec}(k)$ , X = X,  $K = j_* \mathscr{F}$ ,  $L = \mathbb{Q}_{\ell}$ ) par un calcul local qui n'est pas difficile. L'énoncé figurera explicitement dans la version définitive de SGA 5. Dans le cas où nous l'utiliserons (ramification de  $\mathscr{F}$  modérée), on pourrait l'obtenir par voie transcendante, en relevant X et  $\mathscr{F}$  en caractéristique o.

## 3. La majoration fondamentale.

Le résultat de ce paragraphe a été catalysé par la lecture de Rankin [3].

(3.1) Soient  $U_0$  une courbe sur  $\overline{\mathbf{F}}_q$ , complément dans  $\mathbf{P}^1$  d'un ensemble fini de points fermés, U la courbe sur  $\overline{\mathbf{F}}_q$  qui s'en déduit, u un point fermé de U,  $\mathscr{F}_0$  un  $\mathbf{Q}_\ell$ -faisceau constant tordu sur  $U_0$  et  $\mathscr{F}$  son image réciproque sur U.

Soit  $\beta \in \mathbb{Q}$ . Nous dirons que  $\mathscr{F}_0$  est de *poids*  $\beta$  si pour tout  $x \in |U_0|$ , les valeurs propres de  $F_x$  agissant sur  $\mathscr{F}_0$  (1.13) sont des nombres algébriques dont tous les conjugués complexes sont de valeur absolue  $q_x^{\beta/2}$ . Par exemple,  $\mathbb{Q}_t(r)$  est de poids -2r.

Théorème (3.2). — Faisons les hypothèses suivantes :

(i) Fo est muni d'une forme bilinéaire alternée non dégénérée

$$\psi: \mathscr{F}_0 \otimes \mathscr{F}_0 \to \mathbf{Q}_{\ell}(-\beta) \quad (\beta \in \mathbf{Z}).$$

- (ii) L'image de  $\pi_1(U,u)$  dans  $GL(\mathcal{F}_u)$  est un sous-groupe ouvert du groupe symplectique  $Sp(\mathcal{F}_u,\psi_u)$ .
  - (iii) Pour tout  $x \in |U_0|$ , le polynôme  $\det(I F_x t, \mathcal{F}_0)$  est à coefficients rationnels.

Alors, F est de poids B.

On peut supposer, et nous supposerons, que U est affine et que  $\mathscr{F} \neq 0$ .

Lemme (3.3). — Soit 2k un entier pair et notons  $\otimes \mathscr{F}_0$  la puissance tensorielle  $(2k)^{\text{ième}}$  de  $\mathscr{F}_0$ . Pour  $x \in |U_0|$ , la dérivée logarithmique

$$t\frac{d}{dt}\log(\det(\mathbf{I}-\mathbf{F}_xt^{\deg(x)},\overset{2k}{\bigotimes}\mathscr{F}_0)^{-1})$$

est une série formelle à coefficients rationnels positifs.

L'hypothèse (iii) assure que, pour tout n,  $\operatorname{Tr}(F_x^n, \mathscr{F}_0) \in \mathbb{Q}$ . Le nombre

$$\operatorname{Tr}(\mathbf{F}_{x}^{n}, \overset{2k}{\bigotimes} \mathscr{F}_{0}) = \operatorname{Tr}(\mathbf{F}_{x}^{n}, \mathscr{F}_{0})^{2k}$$

est donc rationnel positif, et on applique (1.5.3).

Lemme (3.4). — Les facteurs locaux  $\det(\mathbf{I} - \mathbf{F}_x t^{\deg(x)}, \overset{2k}{\bigotimes} \mathscr{F}_0)^{-1}$  sont des séries formelles à coefficients rationnels positifs.

La série formelle  $\log \det(\mathbf{1} - \mathbf{F}_x t^{\deg(x)}, \bigotimes^{2k} \mathscr{F}_0)^{-1}$  est sans terme constant; d'après (3.3), ses coefficients sont  $\geq 0$ ; les coefficients de son exponentielle sont donc également positifs.

Lemme (3.5). — Soit  $f_i = \sum_{n} a_{i,n} t^n$  une suite de séries formelles de terme constant un, et à coefficients réels positifs. On suppose que l'ordre de  $f_i - 1$  tend vers l'infini avec i, et on pose  $f = \prod_{i} f_i$ . Alors, le rayon de convergence absolue de  $f_i$  est au moins égal à celui de f.

Si 
$$f = \sum_{n} a_n t^n$$
, on a en effet  $a_{i,n} \le a_n$ .

Lemme (3.6). — Sous les hypothèses de (3.5), si f et les  $f_i$  sont les développements en série de Taylor de fonctions méromorphes, alors

$$\inf\{|z| | f(z) = \infty\} \le \inf\{|z| | f_i(z) = \infty\}.$$

Ces nombres sont en effet les rayons de convergence absolue.

(3.7) Pour chaque partition P de [1, 2k] en parties à deux éléments  $\{i_{\alpha}, j_{\alpha}\}$   $(i_{\alpha} < j_{\alpha})$ , on définit

$$\psi_{\mathbf{P}}: \overset{2k}{\bigotimes} \mathscr{F}_0 \to \mathbf{Q}_{\ell}(-k\beta): x_1 \otimes \ldots \otimes x_{2k} \mapsto \prod_{\alpha} \psi(x_{i_{\alpha}}, x_{j_{\alpha}}).$$

Soit x un point fermé de X. L'hypothèse (ii) assure que les coinvariants de  $\pi_1(U, u)$  dans  $\bigotimes_{u}^{2k}$  sont les coinvariants dans  $\bigotimes_{u}^{2k}$  du groupe symplectique tout entier  $(\pi_1 \text{ est Zariski-dense dans Sp})$ . Soit  $\mathscr P$  l'ensemble des partitions P. D'après H. Weyl (*The classical groups*, Princeton University Press, chap. VI,  $\S$  I), pour  $\mathscr P' \subset \mathscr P$  convenable, dépendant de dim $(\mathscr F_u)$ , les  $\psi_P$  pour  $P \in \mathscr P'$  définissent un isomorphisme

$$(\overset{2k}{\otimes}\mathscr{F}_{\!\!\!u})_{\pi_1} = (\overset{2k}{\otimes}\mathscr{F}_{\!\!\!u})_{\operatorname{Sp}} \overset{\sim}{\to} \mathbf{Q}_{\ell}(-k\beta)^{\mathscr{F}}.$$

Soit N le nombre d'éléments de P'. D'après (2.10), la formule ci-dessus donne

$$\mathrm{H}^2_c(\mathrm{U}, \overset{\mathrm{2}k}{\otimes} \mathscr{F}) \simeq \mathbf{Q}_{\ell}(-k\beta-1)^{\mathrm{N}}.$$

Puisque  $H_c^0(U, \bigotimes^{2k} \mathscr{F}) = 0$ , la formule (1.14.3) se réduit à

$$Z(\mathbf{U_0}, \overset{2k}{\bigotimes} \mathscr{F}_0, t) = \frac{\det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^1(\mathbf{U}, \overset{2k}{\bigotimes} \mathscr{F}))}{(\mathbf{I} - q^{k\beta + 1}t)^{\mathbf{N}}}.$$

Cette fonction Z est donc le développement en série de Taylor d'une fonction rationnelle n'ayant de pôle qu'en  $t=1/q^{k\beta+1}$ . Nous utiliserons seulement le fait que les pôles sont de valeur absolue  $1/q^{k\beta+1}$  dans C. Cela pourrait se déduire d'arguments généraux sur les groupes réductifs. Si  $\alpha$  est une valeur propre de  $F_x$  sur  $\mathscr{F}_0$ , alors  $\alpha^{2k}$  est une valeur propre de  $F_x$  sur  $\otimes \mathscr{F}_0$ . Notons encore  $\alpha$  un quelconque conjugué complexe de  $\alpha$ . La puissance inverse  $1/\alpha^{2k/\deg(x)}$  est un pôle de  $\det(1-F_xt^{\deg(x)}, \bigotimes \mathscr{F})^{-1}$ . D'après (3.4) et (3.6), on a donc

$$|1/q^{k\beta+1}| \le |1/\alpha^{2k/\deg(x)}|,$$
 $|\alpha| < q_x^{\frac{\beta}{2} + \frac{1}{2k}}.$ 

soit

Faisant tendre k vers l'infini, on trouve que

$$|\alpha| \leq q_x^{\beta/2}$$
.

Par ailleurs, l'existence de  $\psi$  assure que  $q_x^{\beta}$   $\alpha^{-1}$  est également valeur propre, d'où l'inégalité

$$|q_x^{\beta}\alpha^{-1}| \leq q_x^{\beta/2}$$

soit

$$q_x^{\beta/2} \leq |\alpha|$$
.

Ceci achève la démonstration.

Corollaire (3.8). — Soit  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^1_c(U, \mathscr{F})$ . Alors,  $\alpha$  est un nombre algébrique, dont tous les conjugués complexes vérifient

$$|\alpha| \leq q^{\frac{\beta+1}{2}+\frac{1}{2}}$$
.

La formule (1.14.3) pour  $\mathcal{F}_0$  se réduit à

$$Z(U_0, \mathscr{F}_0, t) = \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}_c^1(\mathbf{U}, \mathscr{F})).$$

Le premier membre est une série formelle à coefficients rationnels, vu son développement en produit et l'hypothèse (iii). Le second membre est donc un polynôme à coefficients rationnels;  $1/\alpha$  en est racine. Ceci prouve déjà que  $\alpha$  est algébrique. Pour achever la démonstration, il suffit de vérifier que le produit infini qui définit  $Z(U_0, \mathscr{F}_0, t)$  converge

absolument (donc est non nul) pour  $|t| < q^{\frac{-\beta}{2}-1}$ .

Soit N le rang de F, et posons

$$\det(\mathbf{I} - \mathbf{F}_x t, \mathscr{F}) = \prod_{i=1}^{N} (\mathbf{I} - \alpha_{i,x} t).$$

D'après (3.2),  $|\alpha_{i,x}| = q_x^{\beta/2}$ . La convergence du produit infini Z résulte de celle de la série

$$\sum_{i,x} |\alpha_{i,x} t^{\deg(x)}|.$$

Pour  $|t|=q^{\frac{-\beta}{2}-1-\epsilon}$  ( $\epsilon > 0$ ), on a

$$\sum_{i,x} |\alpha_{i,x} t^{\deg(x)}| = N \sum_{x} q_x^{-1-\varepsilon}.$$

Sur la droite affine, il y a  $q^n$  points à valeurs dans  $\mathbf{F}_{q^n}$ , donc au plus  $q^n$  points fermés de degré n. On a donc

$$\sum_{x} q_{x}^{-1-\varepsilon} \leq \sum_{n} q^{n} \cdot q^{n(-1-\varepsilon)} = \sum_{n} q^{-n\varepsilon} < \infty,$$

ce qui achève la démonstration.

Corollaire (3.9) — Soient  $j_0$  l'inclusion de  $U_0$  dans  $\mathbf{P}_{\mathbf{F}_q}^1$ , j celle de U dans  $\mathbf{P}^1$ , et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^1(\mathbf{P}^1, j_*\mathscr{F})$ . Alors  $\alpha$  est un nombre algébrique, dont tous les conjugués complexes vérifient

$$q^{\frac{\beta+1}{2}-\frac{1}{2}} \leq |\alpha| \leq q^{\frac{\beta+1}{2}+\frac{1}{2}}.$$

Un segment de la suite longue de cohomologie définie par la suite exacte courte

$$0 \rightarrow j_! \mathcal{F} \rightarrow j_* \mathcal{F} \rightarrow j_* \mathcal{F} / j_! \mathcal{F} \rightarrow 0$$

 $(j_1 = \text{prolongement par o})$  s'écrit

$$\mathrm{H}^1_c(\mathrm{U},\mathscr{F}) \to \mathrm{H}^1(\mathbf{P}^1,j_*\mathscr{F}) \to \mathrm{o.}$$

La valeur propre  $\alpha$  apparaît donc déjà dans  $H_c^1(U, \mathcal{F})$ , et est justiciable de (3.8):

$$|\alpha| \leq q^{\frac{\beta+1}{2}+\frac{1}{2}}.$$

La dualité de Poincaré (2.12) assure que  $q^{\beta+1}\alpha^{-1}$  est également valeur propre, d'où l'inégalité  $|q^{\beta+1}\alpha^{-1}| < q^{\frac{\beta+1}{2}+\frac{1}{2}}$ 

et le corollaire.

## 4. La théorie de Lefschetz : théorie locale.

(4.1) Sur C, les résultats locaux de Lesschetz sont les suivants.

Soient  $D = \{z \mid |z| \le 1\}$  le disque unité,  $D^* = D - \{0\}$ , et  $f: X \to D$  un morphisme d'espaces analytiques. On suppose que

- a) X est non singulier, et purement de dimension n+1;
- b) f est propre;
- c) f est lisse en dehors d'un point x de la fibre spéciale  $X_0 = f^{-1}(0)$ ;
- d) en x, f présente un point quadratique non dégénéré.

Soient  $t \neq 0$  dans D et  $X_t = f^{-1}(t)$  « la » fibre générale. Aux données précédentes, on associe :

 $\alpha$ ) des morphismes de spécialisation  $sp: H^i(X_0, \mathbf{Z}) \to H^i(X_t, \mathbf{Z})$ :  $X_0$  est un rétracte par déformation de X, et sp est la flèche composée

$$H^{i}(X_{0}, \mathbf{Z}) \stackrel{\sim}{\leftarrow} H^{i}(X, \mathbf{Z}) \rightarrow H^{i}(X_{t}, \mathbf{Z});$$

β) des transformations de monodromie  $T: H^i(X_t, \mathbf{Z}) \to H^i(X_t, \mathbf{Z})$ , qui décrivent l'effet sur les cycles singuliers de  $X_t$  de « faire tourner t autour de o ». C'est encore l'action sur  $H^i(X_t, \mathbf{Z})$ , fibre en t du système local  $R^i f_* \mathbf{Z} | D^*$ , du générateur positif de  $\pi_1(D^*, t)$ .

La théorie de Lefschetz décrit  $\alpha$ ) et  $\beta$ ) en terme du cycle évanescent  $\delta \in H^n(X_t, \mathbb{Z})$ . Ce cycle est bien défini au signe près. Pour  $i \neq n, n+1$ , on a

$$H^i(X_0, \mathbf{Z}) \stackrel{\sim}{\to} H^i(X_t, \mathbf{Z}) \quad (i \neq n, n+1).$$

Pour i=n, n+1, on a une suite exacte

$$0 \to H^n(X_0, \mathbf{Z}) \to H^n(X_t, \mathbf{Z}) \xrightarrow{x \mapsto (x, \delta)} \mathbf{Z} \to H^{n+1}(X_0, \mathbf{Z}) \to H^{n+1}(X_t, \mathbf{Z}) \to 0.$$

Pour  $i \neq n$ , la monodromie T est l'identité. Pour i = n, on a

$$Tx = x \pm (x, \delta)\delta$$
.

Les valeurs de ce  $\pm$ , de T $\delta$ , et de  $(\delta, \delta)$  sont les suivantes :

| $n \mod 4$                     | 0         | I | 2         | 3 |
|--------------------------------|-----------|---|-----------|---|
| $Tx = x \pm (x, \delta)\delta$ |           |   | +         | + |
| $(\delta, \delta)$             | 2         | O | 2         | o |
| Тδ                             | $-\delta$ | 8 | $-\delta$ | δ |

La transformation de monodromie T respecte la forme d'intersection  $\operatorname{Tr}(x \cup y)$  sur  $H^n(X_t, \mathbf{Z})$ . Pour n impair, c'est une transvection symplectique. Pour n pair, c'est une symétrie orthogonale.

(4.2) Voici l'analogue de (4.1) en géométrie algébrique abstraite. Le disque D est remplacé par le spectre d'un anneau de valuation discrète hensélien A à corps résiduel algébriquement clos. Soient S ce spectre,  $\eta$  son point générique (spectre du corps des fractions de A), s son point fermé (spectre du corps résiduel). Le rôle de t est joué par un point générique géométrique  $\overline{\eta}$  (spectre d'une clôture algébrique du corps des fractions de A).

Soit  $f: X \to S$  un morphisme propre, avec X régulier purement de dimension n+1. On suppose f lisse, sauf pour un point quadratique ordinaire x dans la fibre spéciale  $X_s$ . Soit  $\ell$  un nombre premier différent de la caractéristique résiduelle p de S. Notant  $X_{\bar{\eta}}$  la fibre générique géométrique, on dispose encore d'un morphisme de spécialisation

$$(4.2.1) sp: H^{i}(X_{s}, \mathbf{Q}_{\ell}) \stackrel{\sim}{\leftarrow} H^{i}(X, \mathbf{Q}_{\ell}) \rightarrow H^{i}(X_{\overline{n}}, \mathbf{Q}_{\ell}).$$

Le rôle de T est joué par l'action du groupe d'inertie  $I = Gal(\overline{\eta}/\eta)$ , agissant sur  $H^i(X_{\overline{\eta}}, \mathbf{Q}_{\ell})$  par transport de structure (cf. (1.15)) :

$$\mathbf{I} = \operatorname{Gal}(\overline{\eta}/\eta) \to \operatorname{GL}(\mathbf{H}^{i}(\mathbf{X}_{\overline{\eta}}, \mathbf{Q}_{\ell})).$$

Les données (4.2.1), (4.2.2) décrivent entièrement les faisceaux  $R^i f_* \mathbf{Q}_{\ell}$  sur S.

(4.3) Posons n=2m pour n pair, et n=2m+1 pour n impair. (4.2.1) et (4.2.2) se décrivent encore en terme d'un cycle évanescent

$$(4\cdot 3\cdot 1) \qquad \qquad \delta \in H^n(X_{\overline{n}}, \mathbf{Q}_{\ell})(m).$$

Ce cycle est bien défini au signe près.

Pour  $i \neq n$ , n+1, on a

$$(4.3.2)$$

Pour i=n, n+1, on a une suite exacte

(4.3.3)

$$\mathrm{o} \to \mathrm{H}^n(\mathrm{X}_s\,,\,\mathbf{Q}_\ell) \to \mathrm{H}^n(\mathrm{X}_{\overline{\eta}}\,,\,\mathbf{Q}_\ell) \xrightarrow{x \mapsto \mathrm{Tr}(x \cup \delta)} \mathbf{Q}_\ell(m-n) \to \mathrm{H}^{n+1}(\mathrm{X}_s\,,\,\mathbf{Q}_\ell) \to \mathrm{H}^{n+1}(\mathrm{X}_{\overline{\eta}}\,,\,\mathbf{Q}_\ell) \to \mathrm{o}.$$

L'action (4.2.2) de I (la monodromie locale) est triviale si  $i \neq n$ . Pour i = n, elle se décrit comme suit.

A) n impair. — On dispose d'un homomorphisme canonique

$$t_{\ell}: \mathbf{I} \to \mathbf{Z}_{\ell}(1),$$

et l'action de  $\sigma \in I$  est

$$x \mapsto x \pm t_{\ell}(\sigma)(x, \delta)\delta.$$

B) n pair. — Ce cas ne nous servira pas. Disons seulement que, si  $p \neq 2$ , il existe un unique caractère d'ordre deux

$$\epsilon:\ I\to\{\pm {\scriptstyle I}\},$$

et qu'on a

$$\sigma x = x$$
 si  $\varepsilon(\sigma) = I$   
 $\sigma x = x \pm (x, \delta)\delta$  si  $\varepsilon(\sigma) = -I$ .

Les signes ± dans A) et B) sont les mêmes qu'en (4.1).

- (4.4) Ces résultats apportent les informations suivantes sur les  $R^i f_* \mathbf{Q}_{\ell}$ .
- a)  $Si \delta \neq o$ :
  - 1) Pour  $i \neq n$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  est constant.
  - 2) Soit j l'inclusion de  $\eta$  dans S. On a

$$R^n f_* \mathbf{Q}_{\ell} = j_* j^* R^n f_* \mathbf{Q}_{\ell}$$
.

- b) Si  $\delta = 0$ : (C'est là un cas exceptionnel. Puisque  $(\delta, \delta) = \pm 2$  pour n pair, il ne peut se produire que pour n impair.)
  - 1) Pour  $i \neq n+1$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  est constant.
  - 2) Soit  $\mathbf{Q}_{\ell}(m-n)_s$  le faisceau  $\mathbf{Q}_{\ell}(m-n)$  sur  $\{s\}$ , prolongé par zéro sur S. On a une suite exacte

$$\mathbf{o} \rightarrow \mathbf{Q}_{\ell}(m-n)_s \rightarrow \mathbf{R}^{n+1} f_* \mathbf{Q}_{\ell} \rightarrow j_* j^* \mathbf{R}^{n+1} f_* \mathbf{Q}_{\ell} \rightarrow \mathbf{o},$$

où  $j_*j^*R^{n+1}f_*\mathbf{Q}_{\ell}$  est un faisceau constant.

## 5. La théorie de Lefschetz : théorie globale.

(5.1) Sur  $\mathbf{C}$ , les résultats de Lefschetz sont les suivants. Soient  $\mathbf{P}$  un espace projectif de dimension  $\geq 1$ , et  $\check{\mathbf{P}}$  l'espace projectif dual; ses points paramétrisent les hyperplans de  $\mathbf{P}$ , et on note  $\mathbf{H}_t$  l'hyperplan défini par  $t \in \check{\mathbf{P}}$ . Si  $\mathbf{A}$  est un sous-espace linéaire de codimension 2 de  $\mathbf{P}$ , les hyperplans contenant  $\mathbf{A}$  sont paramétrés par les points d'une droite  $\mathbf{D} \subset \check{\mathbf{P}}$ , la duale de  $\mathbf{A}$ . Ces hyperplans  $(\mathbf{H}_t)_{t \in \mathbf{D}}$  forment le pinceau d'axe  $\mathbf{A}$ .

Soit  $X \subset P$  une variété projective non singulière connexe et de dimension n+1. Soit  $\widetilde{X} \subset X \times D$  l'ensemble des couples (x, t) tels que  $x \in H_t$ . Les applications première et seconde coordonnée forment un diagramme

$$\begin{array}{ccc} X \xleftarrow{\pi} & \widetilde{X} \\ & \downarrow^{f} \\ & D \end{array}$$

La fibre de f en  $t \in D$  est la section hyperplane  $X_t = X \cap H_t$  de X.

Fixons X, et prenons A assez général. Alors :

- A) A est transverse à X, et  $\widetilde{X}$  se déduit de X par éclatement de  $A \cap X$ . En particulier,  $\widetilde{X}$  est non singulier.
- B) Il existe une partie finie S de D et pour chaque  $s \in S$  un point  $x_s \in X_s$ , tels que f soit lisse en dehors des  $x_s$ .
  - C) Les  $x_s$  sont des points critiques non dégénérés de f.

Pour chaque  $s \in S$ , la théorie de Lefschetz locale (4.1) s'applique donc à un petit disque  $D_s$  autour de s et à  $f^{-1}(D_s)$ .

(5.2) On pose U=D-S. Soit  $u \in U$ , et choisissons des lacets disjoints  $(\gamma_s)_{s \in S}$  partant de u, avec  $\gamma_s$  tournant une fois autour de s:

![](_page_18_Picture_8.jpeg)

Ces lacets engendrent le groupe fondamental  $\pi_1(U, u)$ . Ce groupe agit sur  $H^i(X_u, \mathbf{Z})$ , fibre en u du système local  $R^i f_* \mathbf{Z} | U$ . D'après la théorie locale (4.1), à chaque  $s \in S$  correspond un cycle évanescent  $\delta_s \in H^n(X_u, \mathbf{Z})$ ; ces cycles dépendent du choix des  $\gamma_s$ . Pour  $i \neq n$ , l'action de  $\pi_1(U, u)$  sur  $H^i(X_u, \mathbf{Z})$  est triviale. Pour i = n, on a

(5.2.1) 
$$\gamma_s x = x \pm (x, \delta_s) \delta_s.$$

Soit E le sous-espace de  $H^n(X_u, \mathbf{Q})$  engendré par les  $\delta_s$  (partie évanescente de la cohomologie).

Proposition (5.3). — E est stable sous l'action du groupe de monodromie  $\pi_1(U, u)$ . L'orthogonal  $E^{\perp}$  de E (pour la forme d'intersection  $Tr(x \cup y)$ ) est le sous-espace des invariants de la monodromie dans  $H^n(X_u, \mathbb{Q})$ .

Les  $\gamma_s$  engendrant le groupe de monodromie, c'est clair sur (5.2.1).

Théorème (5.4). — Les cycles évanescents  $\pm \delta_s$  (pris au signe près) sont conjugués sous l'action de  $\pi_1(U, u)$ .

Soit  $\check{\mathbf{X}} \subset \check{\mathbf{P}}$  la variété duale de  $\mathbf{X}$ : c'est l'ensemble des  $t \in \check{\mathbf{P}}$  tels que  $\mathbf{H}_t$  soit tangent à  $\mathbf{X}$ , i.e. tels que  $\mathbf{X}_t$  soit singulier, ou que  $\mathbf{X} \subset \mathbf{H}_t$ . La variété  $\check{\mathbf{X}}$  est irré290

ductible. Soit  $Y \subset X \times \check{\mathbf{P}}$  l'espace des couples (x, t) tels que  $x \in H_t$ . On dispose d'un diagramme

$$\mathbf{X} \longleftarrow \mathbf{Y}$$

$$\downarrow_{g}$$
 $\check{\mathbf{P}}$ 

La fibre de g en  $t \in \check{\mathbf{P}}$  est la section hyperplane  $X_t = X \cap H_t$  de X, et g est lisse en dehors de l'image réciproque de  $\check{X}$ .

On retrouve la situation de (5.1) en remplaçant  $\check{\mathbf{P}}$  par une droite  $D \subset \check{\mathbf{P}}$  et Y par  $g^{-1}(D)$ . On a  $S = D \cap \check{\mathbf{X}}$ . D'après un théorème de Lefschetz, pour D assez générale, l'application

$$\pi_1(D-S, u) \to \pi_1(\check{\mathbf{P}}-\check{X}, u)$$

est surjective. Il suffit donc de montrer que les  $\pm \delta_s$  sont conjugués sous  $\pi_1(\check{\mathbf{P}}-\check{\mathbf{X}})$ .

Pour x dans le lieu lisse de codimension I de  $\check{X}$ , soient ch un chemin de t à x dans  $\check{P}-\check{X}$ , et  $\gamma_x$  le lacet qui suit ch jusqu'au voisinage de  $\check{X}$ , tourne une fois autour de  $\check{X}$ , puis revient à t par ch. Les lacets  $\gamma_x$  (pour ch variable) sont conjugués entre eux. Puisque  $\check{X}$  est irréductible, deux points du lieu lisse de  $\check{X}$  peuvent toujours, dans  $\check{X}$ , être joints par un chemin qui ne quitte pas le lieu lisse. Il en résulte que la classe de conjugaison de  $\gamma_x$  ne dépend pas de x. En particulier, les  $\gamma_s$  sont conjugués entre eux. On lit sur (5.2.1) que ceci implique la conjugaison des  $\pm \delta_s$ .

Corollaire (5.5). — L'action de  $\pi_1(U, u)$  sur  $E/(E \cap E^{\perp})$  est absolument irréductible. Soit  $F \subset E \otimes \mathbf{C}$  un sous-espace stable sous la monodromie. Si  $F \subset (E \cap E^{\perp}) \otimes \mathbf{C}$ , il existe  $x \in F$  et  $s \in S$  tels que  $(x, \delta_s) \neq o$ . On a alors

$$\gamma_s x - x = \pm (x, \delta_s) \delta_s \in \mathbf{F},$$

et  $\delta_s \in F$ . D'après (5.4), tous les  $\delta_s$  sont alors dans F, et F = E. Ceci prouve (5.5).

(5.6) Ces résultats se transposent comme suit en géométrie algébrique abstraite.

Soient **P** un espace projectif de dimension > 1 sur k algébriquement clos de caractéristique p et  $X \subset \mathbf{P}$  une variété projective non singulière connexe et de dimension n+1. Pour A un sous-espace linéaire de **P** de codimension 2, on définit comme en (5.1) D et le pinceau  $(H_t)_{t \in D}$ , les  $X_t$ ,  $\widetilde{X}$  et le diagramme (5.1.1). On dit que les  $(X_t)_{t \in D}$  forment un pinceau de Lefschetz de sections hyperplanes si les conditions suivantes sont vérifiées:

A) L'axe A est transverse à X. L'espace  $\widetilde{X}$  se déduit alors de X par éclatement de  $A \cap X$ , et est lisse.