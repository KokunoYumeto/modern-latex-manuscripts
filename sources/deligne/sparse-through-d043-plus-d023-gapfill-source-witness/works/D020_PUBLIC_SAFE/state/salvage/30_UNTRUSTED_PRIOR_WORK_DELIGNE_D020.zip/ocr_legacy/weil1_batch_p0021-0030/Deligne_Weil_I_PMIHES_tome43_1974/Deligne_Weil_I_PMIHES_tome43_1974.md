- B) Il existe une partie finie S de D et pour chaque  $s \in S$  un point  $x_s \in X_s$ , tels que f soit lisse en dehors des  $x_s$ .
  - C) x<sub>s</sub> est un point singulier quadratique ordinaire de X<sub>s</sub>.

Pour chaque  $s \in S$ , la théorie de Lefschetz locale du § 4 s'applique au spectre  $D_s$  de l'hensélisé de l'anneau local de D en s, et à  $\widetilde{X}_{D_s} = \widetilde{X} \times_D D_s$ .

- (5.7) Soient N la dimension de  $\mathbf{P}$ , r un entier  $\geq 1$ , et  $\iota_{(r)}$  le plongement de  $\mathbf{P}$  dans l'espace projectif de dimension  $\binom{N+r}{N}-1$ , de coordonnées homogènes les monômes de degré r en les coordonnées homogènes de  $\mathbf{P}$ . Les sections hyperplanes de  $\iota_{(r)}(\mathbf{P})$  sont les hypersurfaces de degré r de  $\mathbf{P}$ .
- Si  $p \neq 0$ , il se peut qu'aucun pinceau de sections hyperplanes de X ne soit de Lefschetz. Toutefois, si  $r \geq 2$  et qu'on remplace le plongement projectif donné  $\iota_1: X \hookrightarrow \mathbf{P}$  par  $\iota_r = \iota_{(r)} \circ \iota_1$ , alors, dans ce nouveau plongement, tout pinceau assez général est de Lefschetz. En d'autres termes, si  $r \geq 2$ , un pinceau assez général de sections hypersurfaces de degré r de X est toujours de Lefschetz.
- (5.8) Dans la suite de cette discussion, nous étudions un pinceau de Lefschetz de sections hyperplanes de X, en excluant le cas p=2, n pair. Le cas où n est impair nous suffirait pour la suite. On pose U=D-S. Soient  $u\in U$  et  $\ell$  un nombre premier  $\neq p$ . Les résultats locaux du § 4 montrent que  $R^n f_* \mathbf{Q}_{\ell}$  est modérément ramifié en chaque  $s\in S$ . Le groupe fondamental modéré de U est un quotient du complété profini du groupe fondamental transcendant analogue (relèvement en caractéristique o des revêtements modérés, et théorème d'existence de Riemann). La situation algébrique est dès lors toute pareille à la situation transcendante, et la transposition de résultats de Lefschetz se fait par des arguments standards. Dans la démonstration de (5.4), le théorème de Lefschetz sur les  $\pi_1$  devient le théorème de Bertini, et on doit invoquer le lemme d'Abhyankar pour contrôler la ramification de  $R^*g_*\mathbf{Q}_{\ell}$  le long du lieu lisse de codimension un de  $\mathbf{X}$ .

Les résultats sont les suivants.

- a) Si les cycles évanescents sont non nuls :
  - 1) Pour  $i \neq n$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  sur D est constant.
  - 2) Soit j l'inclusion de U dans D. On a

$$R^n f_* \mathbf{Q}_{\ell} = j_* j^* R^n f_* \mathbf{Q}_{\ell}.$$

3) Soit  $E \subset H^n(X_u, \mathbf{Q}_\ell)$  le sous-espace de la cohomologie engendré par les cycles évanescents. Ce sous-espace est stable sous  $\pi_1(U, u)$ , et

$$\mathbf{E}^{\perp} = \mathbf{H}^{n}(\mathbf{X}_{u}, \mathbf{Q}_{\ell})^{\pi_{1}(\mathbf{U}, u)}$$

La représentation de  $\pi_1(U, u)$  sur  $E/(E \cap E^{\perp})$  est absolument irréductible, et l'image de  $\pi_1$  dans  $GL(E/(E \cap E^{\perp}))$  est engendrée (topologiquement) par les  $x \to x \pm (x, \delta_s) \delta_s$  ( $s \in S$ ) (le signe  $\pm$  étant déterminé comme en (4.1)).

- b) Si les cycles évanescents sont nuls: (C'est là un cas exceptionnel. Puisque  $(\delta, \delta) = \pm 2$  pour n pair, il ne peut se produire que pour n impair: n = 2m + 1. On notera que si un cycle évanescent est nul, ils le sont tous, car conjugués.)
  - 1) Pour  $i \neq n+1$ , le faisceau  $R^i f_* \mathbf{Q}_{\ell}$  est constant.
  - 2) On a une suite exacte

$$0 \to \bigoplus_{s \in S} \mathbf{Q}_{\ell}(m-n)_s \to \mathbb{R}^{n+1} f_* \mathbf{Q}_{\ell} \to \mathscr{F} \to 0$$

avec F constant.

- 3) E = 0.
- (5.9) Le sous-espace  $E \cap E^{\perp}$  de E est le noyau de la restriction à E de la forme d'intersection  $Tr(x \cup y)$ . Cette forme induit donc une forme bilinéaire non dégénérée

$$\psi: E/(E \cap E^{\perp}) \otimes E/(E \cap E^{\perp}) \to \mathbf{Q}_{\ell}(-n),$$

alternée pour n impair, et symétrique pour n pair. Cette forme est respectée par la monodromie; pour n impair, la représentation de monodromie induit donc

$$\rho: \pi_1(\mathbf{U}, u) \to \operatorname{Sp}(\mathbf{E}/(\mathbf{E} \cap \mathbf{E}^{\perp}), \psi).$$

Théorème (5.10) (Kajdan-Margulis). — L'image de p est ouverte.

L'image de  $\rho$  est un sous-groupe compact, donc analytique  $\ell$ -adique, de  $Sp(E/(E\cap E^\perp), \psi)$ . Il suffit de montrer que son algèbre de Lie  $\mathfrak L$  est égale à  $\mathfrak{sp}(E/(E\cap E^\perp), \psi)$ . L'analogue transcendant de cette algèbre de Lie est l'algèbre de Lie de l'adhérence de Zariski du groupe de monodromie.

On déduit de (5.8) que & est engendrée par les transformations de carré nul

$$N_s: x \mapsto (x, \delta_s)\delta_s \quad (s \in S)$$

et que  $E/(E \cap E^{\perp})$  est une représentation absolument irréductible de  $\mathfrak{L}$ . Le théorème résulte du lemme suivant.

Lemme (5.11). — Soient V un espace vectoriel de dimension finie sur un corps k de caractéristique o,  $\psi$  une forme alternée non dégénérée et  $\mathfrak L$  une sous-algèbre de Lie de  $\mathfrak{sp}(V,\psi)$ . On suppose que :

- (i) V est une représentation simple de \( \mathbb{L} \).
- (ii)  $\mathfrak{L}$  est engendrée par une famille d'endomorphismes de V de la forme  $x \mapsto \psi(x, \delta)\delta$ . Alors,  $\mathfrak{L} = \mathfrak{sp}(V, \psi)$ .

On peut supposer et on supposera que V, donc  $\mathfrak{L}$ , est non nul. Soit  $W \subset V$  l'ensemble des  $\delta \in V$  tels que  $N(\delta) : x \mapsto \psi(x, \delta)\delta$  soit dans  $\mathfrak{L}$ .

- a) W est stable par homothétie (car  $\mathfrak L$  est un sous-espace vectoriel de  $\mathfrak{gl}(V)$ ).
- b) Si  $\delta \in W$ ,  $\exp(\lambda N(\delta))$  est un automorphisme de  $(V, \psi, \Omega)$ , donc transforme W en lui-même. Si  $\delta'$ ,  $\delta'' \in W$ , on a donc  $\exp(\lambda N(\delta')) \cdot \delta'' = \delta'' + \lambda \psi(\delta'', \delta') \delta' \in W$ ; si  $\psi(\delta', \delta'') \neq 0$ , le sous-espace vectoriel tendu par  $\delta'$  et  $\delta''$  est dans W.

c) Il en résulte que W est réunion de ses sous-espaces linéaires maximaux  $W_{\alpha}$ , et que ceux-ci sont deux à deux orthogonaux. Chaque  $W_{\alpha}$  est dès lors stable sous les  $N(\delta)$  ( $\delta \in W$ ), donc stable sous  $\mathfrak L$ . Vu l'hypothèse (i),  $W_{\alpha} = V$  et  $\mathfrak L$  contient tous les  $N(\delta)$  pour  $\delta \in V$ . On conclut en notant que l'algèbre de Lie  $\mathfrak{sp}(V, \psi)$  est engendrée par les  $N(\delta)$  ( $\delta \in V$ ).

Remarque (5.12) (inutile pour la suite). — Il est maintenant facile de prouver (1.6) pour une hypersurface de dimension impaire n dans  $\mathbf{P}_{\mathbf{r}_n}^{n+1}$ .

Soient  $X_0$  une telle hypersurface, et  $\overline{X}_0$  l'hypersurface sur  $\overline{\mathbf{F}}_q$  qui s'en déduit par extension des scalaires. On a

$$\mathrm{H}^{2i}(\overline{\mathbf{X}}_{0}, \mathbf{Q}_{\ell}) = \mathbf{Q}_{\ell}(-i) \quad (0 \leq i \leq n);$$

 $H^{2i}(\overline{X}_0, \mathbf{Q}_{\ell}(i))$  est engendré par la  $i^{\text{ème}}$  cup-puissance de  $\eta$ , la classe de cohomologie  $c_1(\mathcal{O}(1))$  d'une section hyperplane. On a donc

$$Z(X_0, t) = \det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^n(\overline{X}_0, \mathbf{Q}_\ell)) / \prod_{i=0}^n (\mathbf{I} - q^i t)$$

et  $\det(\mathbf{I} - \mathbf{F}^*t, \mathbf{H}^n(\overline{\mathbf{X}}_0, \mathbf{Q}_\ell))$  est un polynôme à coefficients entiers indépendants de  $\ell$ .

Faisons varier  $X_0$  dans un pinceau de Lefschetz d'hypersurfaces, qui soit défini sur  $\mathbf{F}_q$  (cf. (5.7) pour  $X = \mathbf{P}^{n+1}$ ; l'existence d'un tel pinceau n'est pas claire; si on voulait compléter l'argument esquissé ici, il faudrait recourir aux arguments qui seront donnés en (7.1)). On vérifie que E coïncide ici avec le  $H^n$  tout entier, et (3.2) fournit la conjecture de Weil pour toutes les hypersurfaces du pinceau, en particulier pour  $X_0$ .

(5.13) Indications bibliographiques sur les §§ 4 et 5.

- A) Les résultats de Lefschetz (4.1) et (5.1) à (5.5) sont contenus dans son livre [2]. Pour la théorie locale (4.1), il peut être plus commode de consulter SGA 7, XIV (3.2).
  - B) Les résultats du § 4 sont démontrés dans les exposés XIII, XIV et XV de SGA 7.
  - C) (5.7) est démontré dans SGA 7, XVII.
- D) (5.8) est démontré dans SGA 7, XVIII. Le théorème d'irréductibilité y est démontré pour E, mais seulement sous l'hypothèse que  $E \cap E^{\perp} = \{o\}$ . La démonstration dans le cas général (pour  $E/(E \cap E^{\perp})$ ) est pareille.

## 6. Un théorème de rationalité.

(6.1) Soient  $\mathbf{P}_0$  un espace projectif de dimension  $\geq_{\bar{1}}$  sur  $\mathbf{F}_q$ ,  $X_0 \subset \mathbf{P}_0$  une variété projective non singulière,  $A_0 \subset \mathbf{P}_0$  un sous-espace linéaire de codimension deux,  $D_0 \subset \check{\mathbf{P}}_0$  la droite duale,  $\overline{\mathbf{F}}_q$  une clôture algébrique de  $\mathbf{F}_q$  et  $\mathbf{P}$ , X, A, D sur  $\overline{\mathbf{F}}_q$  déduits de  $\mathbf{P}_0$ ,  $X_0$ ,

 $A_0$ ,  $D_0$  par extension des scalaires. Le diagramme (5.1.1) de (5.6) provient d'un diagramme analogue sur  $\mathbf{F}_q$ :

$$\begin{array}{ccc} X_0 & \stackrel{\pi_0}{\longleftarrow} & \widetilde{X}_0 \\ & & & \downarrow^{f_0} \end{array}$$

On suppose que X est connexe de dimension paire n+1=2m+2, et que le pinceau  $(X_t)_{t\in D}$  de sections hyperplanes de X défini par D est un pinceau de Lefschetz. L'ensemble S des  $t\in D$  tels que  $X_t$  soit singulier est défini sur  $\mathbf{F}_q$ , i.e. provient de  $S_0\subset D_0$ . On pose  $U_0=D_0-S_0$  et U=D-S.

Soit  $u \in U$ . La partie évanescente de la cohomologie  $E \subset H^n(X_u, \mathbf{Q}_{\ell})$  est stable sous  $\pi_1(U, u)$ , donc définit sur U un sous-système local  $\mathscr E$  de  $R^n f_* \mathbf{Q}_{\ell}$ . Ce dernier est défini sur  $\mathbf{F}_q : R^i f_* \mathbf{Q}_{\ell}$  est l'image réciproque du  $\mathbf{Q}_{\ell}$ -faisceau  $R^i f_{0*} \mathbf{Q}_{\ell}$  sur  $D_0$ , et, sur U,  $\mathscr E$  est l'image réciproque d'un sous-système local

$$\mathscr{E}_0 \subset \mathbb{R}^n f_{0*} \mathbf{Q}_{\ell}$$
.

Le cup-produit est une forme alternée

$$\psi: \mathbf{R}^n f_{0*} \mathbf{Q}_{\ell} \otimes \mathbf{R}^n f_{0*} \mathbf{Q}_{\ell} \to \mathbf{Q}_{\ell}(-n).$$

Notant  $\mathscr{E}_0^{\perp}$  l'orthogonal de  $\mathscr{E}_0$  relativement à  $\psi$ , dans  $R^n f_{0*} \mathbf{Q}_{\ell} | U_0$  on voit que  $\psi$  induit une dualité parfaite

$$\psi: \,\mathscr{E}_0/(\mathscr{E}_0\cap\mathscr{E}_0^\perp)\otimes\mathscr{E}_0/(\mathscr{E}_0\cap\mathscr{E}_0^\perp)\to \mathbf{Q}_{\ell}(-n).$$

Théorème (6.2). — Pour tout  $x \in |U_0|$ , le polynôme  $\det(\mathbf{I} - \mathbf{F}_x^*t, \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}))$  est à coefficients rationnels.

Corollaire (6.3). — Soiert  $j_0$  l'inclusion de  $U_0$  dans  $D_0$ , et j celle de U dans D. Les valeurs propres de  $F^*$  agissant sur  $H^1(D, j_* \mathcal{E}/(\mathcal{E} \cap \mathcal{E}^{\perp}))$  sont des nombres algébriques dont tous les conjugués complexes  $\alpha$  vérifient

$$q^{\frac{n+1}{2}-\frac{1}{2}} \le |\alpha| \le q^{\frac{n+1}{2}+\frac{1}{2}}.$$

D'après (5.10) et (6.2), les hypothèses de (3.2) sont en effet vérifiées par  $(U_0, \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}), \psi)$ , pour  $\beta = n$ , et on applique (3.9).

Lemme (6.4). — Soit  $\mathscr{G}_0$  un  $\mathbf{Q}_{\ell}$ -faisceau constant tordu sur  $\mathbf{U}_0$ , tel que son image réciproque  $\mathscr{G}$  sur  $\mathbf{U}$  soit un faisceau constant. Il existe alors dans  $\overline{\mathbf{Q}}_{\ell}$  des unités  $\alpha_i$  telles que, pour tout  $x \in |\mathbf{U}_0|$ , on ait

$$\det(\mathbf{I} - \mathbf{F}_x^* t, \, \mathscr{G}_0) = \prod_i (\mathbf{I} - \alpha_i^{\deg(x)} t).$$

Ce lemme exprime que  $\mathscr{G}_0$  est l'image réciproque d'un faisceau sur  $\operatorname{Spec}(\mathbf{F}_q)$ , à savoir son image directe sur  $\operatorname{Spec}(\mathbf{F}_q)$ . Ce dernier s'identifie à une représentation  $\ell$ -adique  $G_0$  de  $\operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$ , et on prend

$$\det(\mathbf{I} - \mathbf{F}t, \mathbf{G}_0) = \prod_{i} (\mathbf{I} - \alpha_i t).$$

Le lemme (6.4) s'applique aux  $R^i f_{0*} \mathbf{Q}_{\ell}$   $(i \neq n)$ , à  $R^n f_{0*} \mathbf{Q}_{\ell} / \mathscr{E}_0$  et à  $\mathscr{E}_0 \cap \mathscr{E}_0^{\perp}$ .

Pour  $x \in |\mathbf{U}_0|$  la fibre  $\mathbf{X}_x = f_0^{-1}(x)$  est une variété sur le corps fini k(x). Si  $\overline{x}$  est un point de U au-dessus de x,  $\mathbf{X}_{\overline{x}}$  se déduit de  $\mathbf{X}_x$  par extension des scalaires de k(x) à sa clôture algébrique  $k(\overline{x}) = \overline{\mathbf{F}}_q$ , et  $\mathbf{H}^i(\mathbf{X}_{\overline{x}}, \mathbf{Q}_\ell)$  est la fibre de  $\mathbf{R}^i f_* \mathbf{Q}_\ell$  en  $\overline{x}$ . La formule (1.5.4) pour la variété  $\mathbf{X}_x$  sur k(x) s'écrit donc

$$Z(X_x, t) = \prod_i \det(I - F_x^* t, R^i f_{0*} \mathbf{Q}_{\ell})^{(-1)^{i+1}}$$

et  $Z(X_x, t)$  est le produit de

$$\begin{split} \mathbf{Z}^{l} &= \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \ \mathbf{R}^{n}f_{0*}\mathbf{Q}_{\ell}/\mathscr{E}_{0}) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \, \mathscr{E}_{0} \cap \mathscr{E}_{0}^{\perp}) \cdot \prod_{i \neq n} \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \ \mathbf{R}^{i}f_{0*}\mathbf{Q}_{\ell})^{(-1)^{i+1}} \\ \text{par} &\qquad \qquad \mathbf{Z}^{m} = \det(\mathbf{I} - \mathbf{F}_{x}^{*}t, \, \mathscr{E}_{0}/(\mathscr{E}_{0} \cap \mathscr{E}_{0}^{\perp})). \end{split}$$

Posons  $\mathscr{F}_0 = \mathscr{E}_0/(\mathscr{E}_0 \cap \mathscr{E}_0^{\perp})$ ,  $\mathscr{F} = \mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})$  et appliquons (6.4) aux facteurs de  $Z^f$ . On trouve qu'il existe des unités  $\ell$ -adiques  $\alpha_i$   $(i \leq i \leq N)$  et  $\beta_j$   $(i \leq j \leq M)$  dans  $\overline{\mathbf{Q}}_{\ell}$  tels que pour tout  $x \in |\mathbf{U}_0|$ 

$$Z(\mathbf{X}_x, t) = \frac{\prod\limits_{i} (\mathbf{I} - \alpha_i^{\deg x} t)}{\prod\limits_{i} (\mathbf{I} - \beta_j^{\deg x} t)} \cdot \det(\mathbf{I} - \mathbf{F}_x^* t, \mathscr{F}_0)$$

et qu'en particulier le second membre est dans  $\mathbf{Q}(t)$ . Si un  $\alpha_i$  coïncide avec un  $\beta_j$ , il est loisible de supprimer simultanément cet  $\alpha_i$  de la liste des  $\alpha$  et ce  $\beta_j$  de la liste des  $\beta$ . On peut donc supposer, et nous supposerons, que  $\alpha_i \neq \beta_j$  pour tout i et tout j.

(6.5) Il suffit de prouver que les polynômes  $\prod_{i} (1-\alpha_{i}t)$  et  $\prod_{j} (1-\beta_{j}t)$  sont à coefficients rationnels, i.e. que la famille des  $\alpha_{i}$  (resp. la famille des  $\beta_{j}$ ) est définie sur  $\mathbf{Q}$ . Nous le déduirons des propositions suivantes.

Proposition (6.6). — Soient  $(\gamma_i)$   $(1 \le i \le P)$  et  $(\delta_j)$   $(1 \le j \le Q)$  deux familles d'unités  $\ell$ -adiques dans  $\overline{\mathbf{Q}}_{\ell}$ . On suppose que  $\gamma_i + \delta_j$ . Si K est un ensemble fini assez grand d'entiers + 1, et L une partie de densité o assez grande de  $|U_0|$ , alors, si  $x \in |U_0|$  vérifie  $k \nmid \deg(x)$  (pour tout  $k \in K$ ) et  $x \notin L$ , le dénominateur de

$$\det(\mathbf{I} - \mathbf{F}_x^* t, \mathscr{F}_0) \prod_{i} (\mathbf{I} - \gamma_i^{\deg(x)} t) / \prod_{j} (\mathbf{I} - \delta_j^{\deg(x)} t),$$

écrit sous forme irréductible, est  $\prod_{i} (1 - \delta_{j}^{\deg(x)} t)$ .

La démonstration sera donnée en (6.10-13). D'après (6.7) ci-dessous, (6.6) fournit 296

une description intrinsèque de la famille des  $\delta_j$  en terme de la famille des fractions rationnelles (6.6.1) pour  $x \in |U_0|$ .

Lemme (6.7). — Soient K un ensemble fini d'entiers  $\neq 1$  et  $(\delta_j)$   $(1 \leq j \leq Q)$  et  $(\varepsilon_j)$   $(1 \leq j \leq Q)$  deux familles d'éléments d'un corps. Si, pour tout n assez grand, non divisible par aucun des  $k \in K$ , la famille des  $\delta_j^n$  coïncide avec celle des  $\varepsilon_j^n$  (à l'ordre près), alors la famille des  $\delta_j$  coïncide avec celle des  $\varepsilon_j$  (à l'ordre près).

On procède par récurrence sur Q. L'ensemble des entiers n tels que  $\delta_Q^n = \varepsilon_j^n$  est un idéal  $(n_j)$ . Prouvons qu'il existe  $j_0$  tel que  $\delta_Q = \varepsilon_{j_0}$ . Sinon les  $n_j$  seraient distincts de 1, et il existerait des entiers arbitrairement grands n, non divisibles par aucun des  $n_j$ , ni par aucun des  $k \in K$ . On aurait  $\delta_Q^n + \varepsilon_j^n$ , et ceci contredirait l'hypothèse. Il existe donc  $j_0$  tel que  $\delta_Q = \varepsilon_{j_0}$ . On conclut en appliquant l'hypothèse de récurrence aux familles  $(\delta_j)$   $(j \neq Q)$  et  $(\varepsilon_j)$   $(j \neq j_0)$ .

Proposition (6.8). — Soient  $(\gamma_i)$   $(1 \le i \le P)$  et  $(\delta_j)$   $(1 \le j \le Q)$  deux familles d'unités p-adiques dans  $\overline{\mathbf{Q}}_{\ell}$ ,  $\mathbf{R}(t) = \prod_i (1 - \gamma_i t)$  et  $\mathbf{S}(t) = \prod_j (1 - \delta_j t)$ . Supposons que pour tout  $x \in |\mathbf{U}_0|$ ,  $\prod_i (1 - \delta_i^{\deg(x)} t)$  divise

$$\prod_{i} (\mathbf{I} - \gamma_{i}^{\deg(x)} t) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*} t, \mathscr{F}_{0}).$$

Alors S(t) divise R(t).

Supprimons des familles  $(\gamma_i)$  et  $(\delta_j)$  des paires d'éléments communs jusqu'à vérifier l'hypothèse de (6.6). Appliquons (6.6). Par hypothèse, les fractions rationnelles (6.6.1) sont des polynômes. Aucun  $\delta$  n'a donc subsisté, ce qui signifie que S(t) divise R(t).

Cette proposition fournit une caractérisation intrinsèque de  $\mathbf{R}(t)$  en terme de la famille de polynômes

$$\prod_{i} (\mathbf{I} - \gamma_{i}^{\deg(x)} t) \cdot \det(\mathbf{I} - \mathbf{F}_{x}^{*} t, \mathscr{F}_{0}).$$

C'est le ppcm des polynômes  $S(t) = \prod_{j} (1 - \delta_{j}t)$  vérifiant l'hypothèse de (6.8).

(6.9) Prouvons (6.5) et donc (6.2) (modulo (6.6)). Faisons dans (6.6)  $(\gamma_i) = (\alpha_i)$  et  $(\delta_j) = (\beta_j)$ . On trouve une caractérisation intrinsèque de la famille des  $\beta_j$  en terme de la famille de fractions rationnelles  $Z(X_x, t)$   $(x \in |U_0|)$ . Celles-ci étant dans  $\mathbf{Q}(t)$ , la famille des  $\beta_j$  est définie sur  $\mathbf{Q}$ .

Les polynômes  $\prod_i (\mathbf{1} - \alpha_i^{\deg(x)} t) \cdot \det(\mathbf{1} - \mathbf{F}_x^* t, \mathscr{F}_0)$  sont donc dans  $\mathbf{Q}[t]$ . La proposition (6.8) fournit une description intrinsèque de la famille des  $\alpha_i$  en terme de cette famille de polynômes. La famille des  $\alpha_i$  est donc définie sur  $\mathbf{Q}$ .

(6.10) Préliminaires. — Soient  $u \in U$  et  $\mathscr{F}_u$  la fibre de  $\mathscr{F}$  en u. Le groupe fondamental arithmétique  $\pi_1(U_0, u)$ , extension de  $\hat{\mathbf{Z}} = \operatorname{Gal}(\overline{\mathbf{F}}_q/\mathbf{F}_q)$  (générateur :  $\varphi$ ) par le groupe fondamental géométrique  $\pi_1(U, u)$ , agit sur  $\mathscr{F}_u$  par similitudes symplectiques :

$$\rho: \ \pi_1(\mathbf{U}_0, u) \to \mathrm{CSp}(\mathscr{F}_u, \psi).$$

Nous notons  $\mu(g)$  le multiplicateur d'une similitude symplectique g. Soit

$$H \subset \hat{\mathbf{Z}} \times CSp(\mathcal{F}_u, \psi)$$

le sous-groupe défini par l'équation

$$q^{-n} = \mu(g)$$

(q étant une unité  $\ell$ -adique,  $q^n \in \mathbf{Q}_{\ell}^*$  est défini pour tout  $n \in \hat{\mathbf{Z}}$ ). Le fait que  $\psi$  soit à valeurs dans  $\mathbf{Q}_{\ell}(-n)$  s'exprime en disant que l'application de  $\pi_1$  dans  $\hat{\mathbf{Z}} \times \mathrm{CSp}$ , de coordonnées la projection canonique sur  $\hat{\mathbf{Z}}$  et  $\rho$ , se factorise par

$$\rho_1: \pi_1(\mathbf{U}_0, u) \rightarrow \mathbf{H}.$$

Lemme (6.11). — L'image  $H_1$  de  $\rho_1$  est ouverte dans H.

En effet,  $\pi_1(U_0, u)$  se projette sur  $\hat{\mathbf{Z}}$ , et l'image de  $\pi_1(U, u) = \text{Ker}(\pi_1(U_0, u) \to \hat{\mathbf{Z}})$  dans  $\text{Sp}(\mathscr{F}_u, \psi) = \text{Ker}(H \to \hat{\mathbf{Z}})$  est ouverte (5.10).

Lemme (6.12). — Pour  $\delta \in \overline{\mathbb{Q}}_{\ell}$  une unité  $\ell$ -adique, l'ensemble Z des  $(n,g) \in H_1$  tels que  $\delta^n$  soit valeur propre de g est un fermé de mesure nulle.

Il est clair que Z est fermé. Pour chaque  $n \in \widehat{\mathbf{Z}}$ , soit  $\mathrm{CSp}_n$  l'ensemble des  $g \in \mathrm{CSp}(\mathscr{F}_u, \psi)$  tels que  $\mu(g) = q^{-n}$ , et soit  $Z_n$  l'ensemble des  $g \in \mathrm{CSp}_n$  tels que  $\delta^n$  soit valeur propre de g. Alors,  $\mathrm{CSp}_n$  est un espace homogène sous  $\mathrm{Sp}$ , et on vérifie que  $Z_n$  en est un sous-espace algébrique propre, donc de mesure o. D'après (6.11),  $H_1 \cap (\{n\} \times Z_n)$  est donc de mesure o dans l'image inverse dans  $H_1$  de n, et on applique Fubini à la projection  $H_1 \to \widehat{\mathbf{Z}}$ .

(6.13) Prouvons (6.6). Pour chaque i et j, l'ensemble des entiers n tels que  $\gamma_i^n = \delta_j^n$  est l'ensemble des multiples d'un entier fixe  $n_{ij}$  (on n'exclut pas  $n_{ij} = 0$ ). Par hypothèse,  $n_{ij} \neq 1$ .

D'après (6.12) et le théorème de densité de Čebotarev, l'ensemble des  $x \in |U_0|$  tels qu'un  $\beta_j^{\deg(x)}$  soit valeur propre de  $F_x^*$  agissant sur  $\mathscr{F}_0$  est de densité o. On prend pour K l'ensemble des  $n_{ij}$  et pour L l'ensemble des x ci-dessus.

## 7. Fin de la démonstration de 1.7.

Lemme (7.1). — Soit  $X_0$  une variété projective non singulière absolument irréductible de dimension paire d sur  $\mathbf{F}_q$ . Soient X sur  $\overline{\mathbf{F}}_q$  déduit de  $X_0$  par extension des scalaires et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^d(X, \mathbf{Q}_\ell)$ . Alors,  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient

(7.1.1) 
$$q^{\frac{d}{2}-\frac{1}{2}} \le |\alpha| \le q^{\frac{d}{2}+\frac{1}{2}}.$$

On procède par récurrence sur d (toujours supposé pair). Le cas d=0 est trivial, même sans supposer  $X_0$  absolument irréductible; on suppose dorénavant  $d \ge 2$ . On pose d=n+1=2m+2.

Si  $\mathbf{F}_{q'}$  est une extension de degré r de  $\mathbf{F}_q$  et que  $\mathbf{X}_0'/\mathbf{F}_{q'}$  se déduit de  $\mathbf{X}_0/\mathbf{F}_q$  par extension des scalaires, l'assertion (7.1) pour  $\mathbf{X}_0'/\mathbf{F}_q$  équivaut à (7.1) pour  $\mathbf{X}_0'/\mathbf{F}_{q'}$ : de même que q est remplacé par  $q^r$ , les valeurs propres de  $\mathbf{F}^*$  sont remplacées par leurs puissances  $r^{\text{lèmes}}$ .

D'après (5.7), dans un plongement projectif convenable  $i: X \to \mathbf{P}$ , X admet un pinceau de Lefschetz de sections hyperplanes. La remarque précédente nous permet de supposer i et ce pinceau définis sur  $\mathbf{F}_a$  (quitte à remplacer  $\mathbf{F}_a$  par une extension finie).

Supposons donc qu'il existe sur  $\mathbf{F}_q$  un plongement projectif  $X_0 \to \mathbf{P}_0$  et un sous-espace de codimension deux  $A_0$  de  $\mathbf{P}_0$  qui définisse un pinceau de Lefschetz. On reprend les notations de (6.1) et (6.3). Une nouvelle extension des scalaires nous ramène à supposer que :

- a) Les points de S sont définis sur  $\mathbf{F}_a$ .
- b) Les cycles évanescents en  $x_s$  ( $s \in S$ ) sont définis sur  $\mathbf{F}_q$  (puisque seul  $\pm \delta$  est intrinsèque, ils pourraient n'être définis que sur une extension quadratique).
- c) Il existe un point rationnel  $u_0 \in U_0$ . On prend le point correspondant u de U comme point base.
- d)  $X_{u_0} = f_0^{-1}(u_0)$  admet une section hyperplane lisse  $Y_0$ , définie sur  $\mathbf{F}_q$ . On pose  $Y = Y_0 \otimes_{\mathbf{F}_q} \overline{\mathbf{F}}_q$ .

Puisque  $\widetilde{X}$  se déduit de X par éclatement de la sous-variété lisse de codimension deux  $A \cap X$ , on a

$$H^{i}(X, \mathbf{Q}_{\ell}) \hookrightarrow H^{i}(\widetilde{X}, \mathbf{Q}_{\ell})$$

(en fait,  $H^{i}(\widetilde{X}, \mathbf{Q}_{\ell}) = H^{i}(X, \mathbf{Q}_{\ell}) \oplus H^{i-2}(A \cap X, \mathbf{Q}_{\ell})(-1)$ ). Il suffit donc de prouver (7.1.1) pour les valeurs propres  $\alpha$  de  $F^{*}$  agissant sur  $H^{d}(\widetilde{X}, \mathbf{Q}_{\ell})$ .

La suite spectrale de Leray pour f s'écrit

$$E_2^{pq} = H^p(D, R^q f_* \mathbf{Q}_{\ell}) \Rightarrow H^{p+q}(\widetilde{X}, \mathbf{Q}_{\ell}).$$

Il suffit de prouver (7.1.1) pour les valeurs propres  $\alpha$  de F\* agissant sur les  $E_2^{pq}$  pour p+q=d=n+1. Ce sont :

A) 
$$E_2^{2,n-1}$$
. D'après (5.8),  $R^{n-1}f_*\mathbf{Q}_{\ell}$  est constant. D'après (2.10), on a donc  $E_2^{2,n-1} = H^{n-1}(X_{\ell}, \mathbf{Q}_{\ell})(-1)$ .

D'après le théorème de Lefschetz faible (corollaire de SGA 4, XIV (3.2), et de la dualité de Poincaré, SGA 4, XVIII), on a

$$H^{n-1}(X_n, \mathbf{Q}_n)(-1) \hookrightarrow H^{n-1}(Y, \mathbf{Q}_n)(-1),$$

et on applique l'hypothèse de récurrence à Y<sub>0</sub>.

B)  $E_2^{0,n+1}$ . Si les cycles évanescents sont non nuls,  $R^{n+1}f_*\mathbf{Q}_{\ell}$  est constant et

$$E_2^{0,n+1} = H^{n+1}(X_u, \mathbf{Q}_l).$$

Le morphisme de Gysin

$$H^{n-1}(Y, \mathbf{Q}_{\ell})(-1) \to H^{n+1}(X_n, \mathbf{Q}_{\ell})$$

est surjectif (cet argument est dual de A)), et on applique l'hypothèse de récurrence à Y<sub>0</sub>.

Si les cycles évanescents sont nuls, la suite exacte de (5.8) b) fournit une suite exacte

$$\bigoplus_{n \in S} \mathbf{Q}_{\ell}(m-n) \to \mathrm{E}_{2}^{0,n+1} \to \mathrm{H}^{n+1}(\mathrm{X}_{u}, \, \mathbf{Q}_{\ell}).$$

La valeur propre de F agissant sur  $\mathbf{Q}_{\ell}(m-n)$  est  $q^{d/2}$ , et  $\mathbf{H}^{n+1}$  se traite comme plus haut.

C)  $E_2^{1,n}$ . Si on disposait du théorème de Lefschetz « difficile », on saurait que  $\mathscr{E} \cap \mathscr{E}^{\perp}$  est nul, et que  $R^n f_* \mathbf{Q}_{\ell}$  est somme directe de  $j_* \mathscr{E}$  et d'un faisceau constant. Le  $H^1$  d'un faisceau constant sur  $\mathbf{P}^1$  est nul, et il suffirait d'appliquer (6.3).

Faute d'avoir déjà démontré Lefschetz « difficile », il nous va falloir dévisser. Si les cycles évanescents sont nuls,  $R^n f_* \mathbf{Q}_{\ell}$  est constant ((5.8) b)) et  $E_2^{1,n} = 0$ . On peut donc supposer, et on supposera, les cycles évanescents non nuls. Filtrons  $R^n f_* \mathbf{Q}_{\ell} = j_* j^* R^n f_* \mathbf{Q}_{\ell}$  (5.8) par les sous-faisceaux  $j_* \mathscr{E}$  et  $j_* (\mathscr{E} \cap \mathscr{E}^{\perp})$ . Si les cycles évanescents  $\delta$  ne sont pas dans  $\mathscr{E} \cap \mathscr{E}^{\perp}$ , on dispose de suites exactes :

(7.1.2) 
$$0 \rightarrow j_* \mathscr{E} \rightarrow \mathbb{R}^n f_* \mathbf{Q}_{\ell} \rightarrow \text{faisceau constant} \rightarrow 0.$$

(7.1.3) 
$$0 \rightarrow \text{faisceau constant } j_*(\mathscr{E} \cap \mathscr{E}^{\perp}) \rightarrow j_*\mathscr{E} \rightarrow j_*(\mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})) \rightarrow 0.$$

Si, à Dieu ne plaise, les  $\delta$  sont dans  $\mathcal{E} \cap \mathcal{E}^{\perp}$ , on a  $\mathcal{E} \subset \mathcal{E}^{\perp}$ , et des suites exactes :

(7.1.4) 
$$0 \rightarrow \text{le faisceau constant } j_* \mathscr{E}^{\perp} \rightarrow \mathbb{R}^n f_* \mathbf{Q}_{\ell} \rightarrow \text{un faisceau } \mathscr{F} \rightarrow 0$$

(7.1.5) 
$$0 \to \mathscr{F} \to \text{le faisceau constant } j_*j^*\mathscr{F} \to \bigoplus_{s \in S} \mathbf{Q}_{\ell}(n-m)_s \to 0.$$

Dans le premier cas, les suites exactes longues de cohomologie fournissent

$$(7.1.2')$$

$$(\mathbf{7}.\mathbf{r}.\mathbf{3}') \qquad \qquad \mathbf{0} \rightarrow \mathbf{H}^{1}(\mathbf{D}, j_{*}\mathscr{E}) \rightarrow \mathbf{H}^{1}(\mathbf{D}, j_{*}(\mathscr{E}/(\mathscr{E} \cap \mathscr{E}^{\perp})))$$

et on applique (6.3).

Dans le second cas, elles fournissent

$$(7.1.4') o \rightarrow H^1(D, R^n f_* \mathbf{Q}_{\ell}) \rightarrow H^1(D, \mathscr{F}),$$

(7.1.5') 
$$\bigoplus_{s \in S} \mathbf{Q}_{\ell}(n-m) \to H^{1}(D, \mathscr{F}) \to 0$$

et on remarque que F agit sur  $\mathbf{Q}_{\ell}(n-m)$  par multiplication par  $q^{d/2}$ .

Lemme (7.2). — Soit  $X_0$  une variété projective non singulière absolument irréductible de dimension d sur  $\mathbf{F}_q$ . Soient X sur  $\overline{\mathbf{F}}_q$  déduit de  $X_0$  par extension des scalaires et  $\alpha$  une valeur propre de  $F^*$  agissant sur  $H^d(X, \mathbf{Q}_t)$ . Alors,  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient

$$|\alpha|=q^{d/2}$$
.

Prouvons déjà que  $(7.2) \Rightarrow (1.7)$ . Pour  $X_0$  projective non singulière sur  $\mathbf{F}_q$  et i un entier, il faut prouver l'assertion suivante :

- $W(X_{0,i})$ . Soit X déduit de  $X_0$  par extension des scalaires de  $\mathbf{F}_q$  à  $\overline{\mathbf{F}}_q$ . Si  $\alpha$  est une valeur propre de  $F^*$  agissant sur  $H^i(X, \mathbf{Q}_\ell)$ , alors  $\alpha$  est un nombre algébrique dont tous les conjugués complexes, encore notés  $\alpha$ , vérifient  $|\alpha| = q^{i/2}$ .
- a) Si  $\mathbf{F}_{q^n}$  est une extension de degré n de  $\mathbf{F}_q$ , et que  $\mathbf{X}_0'/\mathbf{F}_{q^n}$  se déduit de  $\mathbf{X}_0/\mathbf{F}_q$  par extension des scalaires, alors  $\mathbf{W}(\mathbf{X}_0,i)$  équivaut à  $\mathbf{W}(\mathbf{X}_0',i)$ : étendre les scalaires revient à remplacer  $\alpha$  par  $\alpha^n$  et q par  $q^n$ .
- b) Si  $X_0$  est purement de dimension n,  $W(X_0,i)$  équivaut à  $W(X_0,2n-i)$  : ceci résulte de la dualité de Poincaré.
  - c) Si  $X_0$  est somme de variétés  $X_0^{\alpha}$ ,  $W(X_0, i)$  équivaut à la conjonction des  $W(X_0^{\alpha}, i)$ .
- d) Si  $X_0$  est purement de dimension n,  $Y_0$  une section hyperplane lisse de  $X_0$ , et que i < n, alors  $W(Y_0, i) \Rightarrow W(X_0, i)$ : ceci résulte du théorème de Lefschetz faible.

Pour prouver les assertions  $W(X_0, i)$ , on se ramène successivement :

- par c), à supposer  $X_0$  purement d'une dimension n;
- par b), à supposer de plus  $0 \le i \le n$ ;
- par a) et d), à supposer de plus i=n;
- par a) et c), à supposer de plus X<sub>0</sub> absolument irréductible.

Ce cas est justiciable de (7.2).

(7.3) Prouvons (7.2). Pour tout entier k,  $\alpha^k$  est valeur propre de  $F^*$  agissant sur  $H^{kd}(X^k, \mathbf{Q}_{\ell})$  (formule de Künneth). Pour k pair,  $X^k$  est justiciable de (7.1), d'où

$$q^{\frac{kd}{2} - \frac{1}{2}} \le |\alpha^k| \le q^{\frac{kd}{2} - \frac{1}{2}}$$

$$q^{\frac{d}{2} - \frac{1}{2k}} \le |\alpha| \le q^{\frac{d}{2} + \frac{1}{2k}}.$$

et

Faisant tendre k vers l'infini, on trouve (7.2).

## 8. Premières applications.

Théorème (8.1). — Soit  $X_0 \subset \mathbf{P}_0^{n+r}$  une intersection complète non singulière sur  $\mathbf{F}_q$ , de dimension n et de multidegré  $(d_1, \ldots, d_r)$ . Soit b' le  $n^{\text{lème}}$  nombre de Betti des intersections complètes non singulières complexes, de mêmes dimension et multidegré. Posons b=b' pour n impair, et b=b'-1 pour n pair. Alors

$$| \# \mathbf{X}_0(\mathbf{F}_q) - \# \mathbf{P}^n(\mathbf{F}_q) | \le b \cdot q^{n/2}.$$

Soient  $X/\overline{\mathbf{F}}_q$  déduit de  $X_0$ , et  $\mathbf{Q}_{\ell}$ .  $\eta^i$  la droite dans  $H^{2i}(X, \mathbf{Q}_{\ell})$  engendrée par la  $i^{\text{ème}}$  cup-puissance de la classe de cohomologie d'une section hyperplane. Sur cette droite,  $\mathbf{F}^*$  agit par multiplication par  $q^i$ . La cohomologie de X est somme des  $\mathbf{Q}_{\ell}$ .  $\eta^i$