Presentation derivatives remain separate from untouched authority crops and must be independently hashed and logged.
