Untouched lossless crops must come from the controlling authority only and be logged in edition/asset_ledger.tsv.
