# Build and QA summary

Date: 2026-08-01

Status: `PASS_SOURCE_ALIGNED_WORKING_RELEASE`

- Corrected French: four A4 pages; four XeLaTeX passes; required diagnostics 0.
- English translation: four A4 pages; four XeLaTeX passes; required diagnostics 0.
- Bilingual reader: eight A4 pages; four XeLaTeX passes; required diagnostics 0.
- Pass-3 and pass-4 console output was byte-identical for each reader.
- Bilingual PDF: unencrypted; two language outline entries; no page annotations
  or external actions.
- All eight bilingual pages were rendered at 600 dpi and inspected for compiled
  layout. No blank page, clipping, overlap, missing glyph, or language-seam
  defect was found. Those output renders are intentionally not bundled.
- Source reading used direct 1200-1800 dpi page renders and the bundled decisive
  2400/5600/9600 dpi crops. Every bundled crop is identity- and coordinate-bound.
- Four source defects R1, R2, R3, and A1 have exact machine checks and visible
  disclosure in both corrected language editions.
