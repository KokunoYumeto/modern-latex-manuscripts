# Rights and provenance

## Controlling source

- Work: Pierre Deligne, *Congruences sur le nombre de sous-groupes d'ordre p^k
  dans un groupe fini*.
- Source witness: publicly accessible IAS scan, four PDF pages, printed pages
  129-132.
- Archive-neutral source name: `Congruence_sous_groupes_pk_IAS_scan.pdf`.
- Source bytes: 1,116,696.
- Source SHA-256: `4078B5827B016B7F0FA3F3ECB3A7D710AC7D63E7A1EDD889F86FCAA847078C2C`.
- Source role: sole page, formula, glyph, and layout authority for this package.
- OCR role: locator only; no OCR body is bundled or promoted as authority.

The source PDF is not redistributed here. Fourteen tightly bounded crops from
that public scan are included because they are the decisive source evidence for
the four disclosed repairs. Their exact page, bounding box, dimensions, DPI,
and identities are recorded in the visual-evidence ledgers.

## Claim boundary

The package provides public working access to reconstructed French and English
readers, editable TeX, exact source-defect disclosures, machine checks, and
decisive source crops. It does not assert a new license over Deligne's work or
the source scan, and it is not a critical edition, peer review, mathematical
certification, accessibility certification, or legal determination. Rights in
the underlying work and scan remain with their respective holders.
