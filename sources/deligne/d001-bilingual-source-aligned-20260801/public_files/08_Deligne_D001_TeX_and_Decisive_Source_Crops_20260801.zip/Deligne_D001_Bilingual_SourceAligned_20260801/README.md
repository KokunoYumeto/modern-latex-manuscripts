# Deligne D001 bilingual source-aligned checkpoint

This package preserves a complete corrected French edition, a complete English
translation, and an eight-page bilingual reader of Pierre Deligne's
*Congruences sur le nombre de sous-groupes d'ordre p^k dans un groupe fini*.
Coverage is the complete four-page paper, printed pages 129-132, through EOF.

The IAS scan identified in `RIGHTS_AND_PROVENANCE.md` is the controlling source.
The scan itself is not bundled. Four source defects are disclosed in both
language editions and in `controls/SOURCE_DEFECT_REGISTER.csv`; the source text
has not been silently normalized. Exact arithmetic checks are in
`controls/D001_SOURCE_MATH_CHECKS.json`.

The visual-evidence directory contains only the 14 decisive 2400-9600 dpi crops
used to adjudicate the disputed formulas and glyphs. The accompanying CSV and
JSONL ledgers bind each crop to the parent scan hash, PDF and printed page,
bounding box, dimensions, DPI, issue ID, and crop hash. These crops are source
evidence, not rendered copies of the reconstructed reader.

Start with
`build/bilingual_source_aligned_eof_r1/D001_Congruences_Bilingual_Reader.pdf`.
The three files in `tex` are the editable source closure. Their original
relative build topology is preserved byte-for-byte. This is a scholarly working
edition and translation, not a critical edition, peer review, mathematical
certification, accessibility certification, or new license grant.
