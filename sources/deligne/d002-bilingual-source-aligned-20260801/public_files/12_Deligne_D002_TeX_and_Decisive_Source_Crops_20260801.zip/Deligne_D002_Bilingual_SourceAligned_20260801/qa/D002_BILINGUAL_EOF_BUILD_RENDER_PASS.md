# D002 bilingual EOF build/render PASS

Date: 2026-08-01

- French source: 29,971 bytes; SHA-256 `2EB15D430385807CBAC58CB9F67AF28C047FA63E4CB00A9DF45074672C115889`.
- French PDF: 106,349 bytes; 12 pages; SHA-256 `6DE66CDAD91E61756EA228D48AAD413C8287A8AC2A6B825D7E3B33B90325F345`.
- English source: 28,099 bytes; SHA-256 `B78354B3ED9637008A8687312EF61EB5095BA6651A1A0BC385738E202EC6F1C6`.
- English PDF: 106,630 bytes; 12 pages; SHA-256 `BDE6B832859555994F889C0CFDA7642B8D6848A1D4907503B6A52B3A0C3E2C71`.
- Bilingual wrapper: 731 bytes; SHA-256 `A97C0F4AC69EEEC61D0A4D5D81577C1C6DDB7A88F94181F6BE99668C11A2F8EE`.
- Bilingual PDF: 222,429 bytes; 24 pages; SHA-256 `F272A0CAEF2853469A4AAEE29C6FF6F066818772364CD1BE0D635B73DAAE5F37`.

Builds: French 3/3 exit 0; English 3/3 exit 0; bilingual 4/4 exit 0. Final bilingual log diagnostic scan: zero. Final component logs: no horizontal overfull boxes or hard diagnostics. Poppler/PyPDF replay: 24 pages, unencrypted, two language outline nodes. Final 600-dpi render review: French 12/12, English 12/12, bilingual 24/24; no clipping, overlap, blank-page defect, broken vector diagram, language seam defect, or bibliography cutoff.

Result: **PASS — LOCAL SOURCE-ALIGNED BILINGUAL EOF READER**.
