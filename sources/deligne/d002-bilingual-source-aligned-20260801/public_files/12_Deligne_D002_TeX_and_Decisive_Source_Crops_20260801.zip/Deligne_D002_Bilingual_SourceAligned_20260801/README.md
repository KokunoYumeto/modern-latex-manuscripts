# Deligne D002 bilingual source-aligned checkpoint

Start with `build/bilingual_source_aligned_eof_r1/D002_ProperSupport_Bilingual_Reader.pdf`.
It contains the complete corrected-French and English readers of Pierre
Deligne's *Cohomologie a support propre et construction du foncteur f!*.
Coverage is the complete eighteen-page paper, printed pages 404-421, through
the terminal bibliography.

The three files in `tex` are the complete editable source closure. Twelve
source-alignment decisions are recorded in
`controls/D002_SOURCE_ALIGNMENT_CORRECTIONS.csv`; the source-surprising final
term on printed page 415 is retained and disclosed rather than silently
normalized.

The four images in `visual_evidence/source_crops` are the decisive source crops
used for the diagram and formula decisions on printed pages 411, 413, and 415.
They are not page renders of the reconstructed reader. Their ledger binds each
crop to the parent scan hash, PDF and printed page, 1200-dpi source-render
coordinates, dimensions, review presentation scale, correction IDs, and crop
hash. The source PDF, full-page renders, output screenshots, raw logs, and build
auxiliaries are not bundled.

This is a source-aligned scholarly working edition and translation, not a
critical edition, peer review, mathematical certification, accessibility
certification, or new license grant.
