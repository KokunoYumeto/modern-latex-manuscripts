# D002 source-alignment report

Date: 2026-08-01

## Result

D002 is continuous through the end of the bibliography on printed page 421. The French edition and English edition were replayed against every page of the controlling 18-page IAS witness. The bilingual reader concatenates the final French and English outputs and contains two language bookmarks.

The exact row-level disposition is `D002_SOURCE_ALIGNMENT_CORRECTIONS.csv`. It records eight substantive inherited defects, two omitted source notes, one source-visible anomaly retained without silent normalization, and two layout/source-retention decisions. All mathematical and diagram decisions were made by the top-level session from direct authority renders; no agent performed mathematical or visual judgment.

## Authority and image policy

- Controlling IAS witness: `2_CohomologieFoncteur [~300dpi].pdf`, 745,800 bytes, 18 pages, SHA-256 `613CB973E466DD5ED414335B6C86B5E04E3E6138DCC607C638F235B2AE6A44A9`.
- Its embedded pages are 2400 by 3270 pixels. The nominal PDF dpi is not the review resolution: all 18 source pages were enlarged for direct reading, with formula/arrow details examined at approximately 5000 dpi equivalent and the page-415 chain at approximately 9000 dpi equivalent.
- The lower-resolution collected-papers split is comparison/locator evidence only.
- Existing GPU OCR was used only as locator evidence. No OCR was generated or delegated.

## Source coverage and checks

- Authority coverage: printed pages 404–421, 18/18 pages, including title, all numbered sections, seven copyist notes, all diagrams, and terminal bibliography.
- High-detail source checks included the p.405 implication proof; p.406 representability arrows; p.408 corollary arrows; p.409 pro-derived-category glyphs; p.410 note 5 and Proposition 4 formula; p.411 note 6 and Cech diagram; p.412 Proposition 5 proof; p.413 compactification towers; p.414 note 7; p.415 comparison diagram and compatibility chain; p.417 Proposition 6 fiber; p.420 definition of I_1; and p.421 terminal formulas and bibliography.
- The page-415 final compatibility term remains exactly as printed even though it is mathematically surprising; this is a disclosed source retention, not an editorial endorsement.

## Build and visual QA

- French: three stable XeLaTeX passes, 12 pages, no overfull boxes, fatal errors, undefined controls, duplicate destinations, missing characters, or rerun requests. Two harmless underfull page-height notices were inspected directly.
- English: three stable XeLaTeX passes, 12 pages, no overfull horizontal boxes, fatal errors, undefined controls, duplicate destinations, missing characters, or rerun requests. The 1.23903-point page-height notice was inspected directly.
- Bilingual: four stable XeLaTeX passes, 24 pages, two outline entries, zero build diagnostics.
- All 12 French pages, all 12 English pages, and all 24 bilingual pages were rendered from the final bytes at 600 dpi for layout review. No clipping, overlap, blank-page defect, broken diagram, seam error, or terminal-page defect was found.
- All diagrams remain native vector TeX/Xy-pic. Poppler reports zero image objects in the French, English, and bilingual PDFs. All 27 fonts in each language PDF are embedded and none is Type 3.

This is a local source-aligned completion, not an archive/publication/readback claim.
