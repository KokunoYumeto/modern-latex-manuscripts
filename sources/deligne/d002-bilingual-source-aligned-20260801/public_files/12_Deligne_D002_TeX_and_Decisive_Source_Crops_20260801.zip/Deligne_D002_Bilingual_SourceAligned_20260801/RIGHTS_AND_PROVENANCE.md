# Rights and provenance

- Work: Pierre Deligne, *Cohomologie a support propre et construction du
  foncteur f!*.
- Controlling witness: publicly accessible IAS scan, 18 PDF
  pages, printed pages 404-421.
- Archive-neutral witness name: `Cohomologie_support_propre_foncteur_f_shriek_IAS_scan.pdf`.
- Witness bytes: 745,800.
- Witness SHA-256: `613CB973E466DD5ED414335B6C86B5E04E3E6138DCC607C638F235B2AE6A44A9`.
- Source role: sole page, formula, glyph, and layout authority for this package.
- OCR role: locator only; no OCR body is bundled or promoted as authority.

The complete source PDF is not redistributed in this package. Four tightly
bounded source crops are included as the decisive evidence for reconstructed
diagrams and the page-415 compatibility chain. The visual-evidence ledgers
record source-render coordinates and distinguish the true 1200-dpi source
render from higher inspection-presentation scales.

This package does not assert a new license over Deligne's work or the IAS scan.
Rights in the underlying work and source witness remain with their respective
holders. The package is a scholarly working edition and translation, not a
critical edition, peer review, mathematical certification, accessibility
certification, or legal determination.
