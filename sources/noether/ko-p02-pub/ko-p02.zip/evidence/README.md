# Noether Paper 2 Korean T01--T32 / U01--U226 producer evidence

This is a source-synchronized, machine-readable producer-evidence freeze for ED0001 lines 473--3568 and 199 frozen Korean producer targets across 32 separate unchecked tranches, plus two separately versioned checker-confirmed TeX-repair siblings. The identifier space U01--U226 contains 27 deliberate unused reservations, so 199 original units are present with no substantive source gap. Paper 2 terminal controls at lines 3569--3572 are bound separately and excluded from target coverage; Paper 3 begins at line 3573. The continuation cursor is `NOE-P02-KO:SOURCE_LINE_3573:P03_BEGIN_OUT_OF_SCOPE`.

- `structural_index/` contains the authoritative hierarchical JSONL, deterministic CSV projection, field-documented schema, and PASS report.
- `difficulty_ledger/` contains the append-only SHA-256 predecessor chain for twenty-one observed operational failures, forty source/translation difficulty holds, and two personally checker-confirmed TeX-repair returns. It preserves the original/sibling/source/probe identities and every still-open linguistic/full-build/render/visual gate.
- `visual_evidence/` contains a schema-documented zero-record JSONL, header-only CSV, PASS report, and explicit no-render/rights/disposition status.
- `protected_inputs/` rehashes ED0001, producer pointer v004, adopted pointer v005, 199 frozen original targets, and 120 producer metadata files; it publishes canonical target/metadata/combined TSV manifests and requires zero mutations. The two repair siblings are separately listed and do not alter protected-set semantics.
- `csv_artifact_validation/` imports and inspects all three CSV projections without rendering.

Primary structural records partition every scoped physical source/target line exactly once. Overlapping annotations expose displays/equations, nested arrays, footnotes/markers, bibliography items, symbols, and important references. Cross-language links are unit/tag/occurrence mechanics only and never assert translation or formula equivalence.

HARD-015 preserves the historical first-builder preflight abort before generated evidence write when live producer metadata outran the earlier baseline. The final freeze dynamically harvests all completed work through T32/U226. Sixty-six early targets remain producer-bound to pointer v004 and 133 later targets to pointer v005; v005 supersedes v004 while both bind unchanged ED0001. No target/header/metadata rewrite was made.

Boundary: two preexisting producer-owned siblings carry only the exact U02/U29 TeX-syntax repairs personally confirmed by checker task `019fcc0e-b6fb-7782-9603-36befa045276`; every frozen original remains byte-identical. No German defect, linguistic approval, full build, extraction, rendering, visual inspection, assembly, packaging, certification, approval, source/scan adjudication, Paper 6 mutation, or SGA work was performed by this evidence pass.
