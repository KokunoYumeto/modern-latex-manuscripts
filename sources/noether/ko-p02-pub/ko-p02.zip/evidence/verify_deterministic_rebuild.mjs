import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const scriptPath = fileURLToPath(import.meta.url);
const evidenceRoot = path.dirname(scriptPath);
const builderPath = path.join(evidenceRoot, "build_and_validate_evidence.mjs");
const reportPath = path.join(evidenceRoot, "DETERMINISTIC_REBUILD_VALIDATION_REPORT.json");

function sha256(bytes) { return crypto.createHash("sha256").update(bytes).digest("hex").toUpperCase(); }

async function listFiles(dir) {
  const out = [];
  for (const entry of await fs.readdir(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await listFiles(fullPath));
    else if (entry.isFile()) out.push(fullPath);
  }
  return out;
}

async function identities() {
  const files = (await listFiles(evidenceRoot)).filter((fullPath) => {
    const rel = path.relative(evidenceRoot, fullPath).replace(/\\/g, "/");
    return rel !== "DETERMINISTIC_REBUILD_VALIDATION_REPORT.json"
      && rel !== "csv_artifact_validation/CSV_PROJECTIONS_ARTIFACT_TOOL_VALIDATION_REPORT.json";
  }).sort();
  const out = {};
  for (const fullPath of files) {
    const bytes = await fs.readFile(fullPath);
    out[path.relative(evidenceRoot, fullPath).replace(/\\/g, "/")] = { bytes: bytes.length, sha256: sha256(bytes) };
  }
  return out;
}

function runBuilder() {
  return spawnSync(process.execPath, [builderPath], { cwd: evidenceRoot, encoding: "utf8", windowsHide: true });
}

const firstRun = runBuilder();
if (firstRun.status !== 0) throw new Error(`First deterministic rebuild failed: ${firstRun.stderr || firstRun.stdout}`);
const first = await identities();
const secondRun = runBuilder();
if (secondRun.status !== 0) throw new Error(`Second deterministic rebuild failed: ${secondRun.stderr || secondRun.stdout}`);
const second = await identities();
const allPaths = Array.from(new Set([...Object.keys(first), ...Object.keys(second)])).sort();
const changed = allPaths.filter((rel) => JSON.stringify(first[rel] || null) !== JSON.stringify(second[rel] || null));
const report = {
  schema_version: "1.0.0", status: changed.length === 0 ? "PASS" : "FAIL", errors: changed.map((rel) => `Identity changed between rebuilds: ${rel}`),
  validator: path.basename(scriptPath), validator_sha256: sha256(await fs.readFile(scriptPath)), builder: path.basename(builderPath),
  builder_sha256: sha256(await fs.readFile(builderPath)), evidence_date: "2026-08-04",
  rebuild_count: 2, compared_file_count: allPaths.length, changed_file_count: changed.length,
  first_run_exit_code: firstRun.status, second_run_exit_code: secondRun.status,
  exclusions: ["DETERMINISTIC_REBUILD_VALIDATION_REPORT.json (self)", "csv_artifact_validation/CSV_PROJECTIONS_ARTIFACT_TOOL_VALIDATION_REPORT.json (separate runtime validator)"],
  identities_after_second_rebuild: second,
  validation_scope: "Two complete consecutive runs of the evidence builder with byte-count/SHA-256 comparison of every builder-controlled or static evidence file except this self-report and the separately executed spreadsheet-runtime report.",
  protected_input_note: "Each builder run independently rehashes and requires byte identity for ED0001, pointers v004/v005, all 199 frozen original targets, and all 120 completed producer metadata files; three canonical producer-input manifests are regenerated and compared. The two versioned TeX-repair siblings and the personal checker adjudication are separately identity-bound and do not alter the protected-original set.",
};
await fs.writeFile(reportPath, JSON.stringify(report, null, 2) + "\n", "utf8");
if (report.status !== "PASS") throw new Error(`Deterministic rebuild failed: ${changed.join(", ")}`);
console.log(JSON.stringify({ status: report.status, rebuild_count: report.rebuild_count, compared_file_count: report.compared_file_count, changed_file_count: report.changed_file_count }, null, 2));
