import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const scriptPath = fileURLToPath(import.meta.url);
const evidenceRoot = path.dirname(scriptPath);
const projectRoot = path.dirname(evidenceRoot);
const workspaceRoot = path.resolve(projectRoot, "../../../../..");
const authorityPath = path.join(
  workspaceRoot,
  "03_projects", "noether", "07_german_canon_control", "candidates",
  "NOETH-DE-ED-0001", "Noether_German_NOETH-DE-ED-0001.tex",
);
const pointerPath = path.join(
  workspaceRoot,
  "03_projects", "noether", "07_german_canon_control", "pointers",
  "NOETH_DE_AUTHORITY_POINTER_v005_20260804.json",
);
const producerPointerPath = path.join(
  workspaceRoot,
  "03_projects", "noether", "07_german_canon_control", "pointers",
  "NOETH_DE_AUTHORITY_POINTER_v004_20260804.json",
);
const checkerRoot = path.join(
  workspaceRoot,
  "03_projects", "language_management", "cjk", "05_independent_checking",
  "noether_korean", "paper02", "check_001_20260804",
);
const checkerAdjudicationPath = path.join(
  checkerRoot, "evidence", "redo_primary_adjudication",
  "P02_U02_U29_PRIMARY_ADJUDICATION_001.json",
);

const WORK_ID = "NOE-P02-KO";
const SCHEMA_VERSION = "1.0.0";
const POINTER_ID = "NOETH-DE-AUTH-v005-20260804";
const POINTER_BYTES = 19889;
const POINTER_SHA256 = "42E6844BFCBFB2133E9AA323A823604351CF9C49550AFCF34ECAAF7887185660";
const PRODUCER_POINTER_ID = "NOETH-DE-AUTH-v004-20260804";
const PRODUCER_POINTER_BYTES = 16536;
const PRODUCER_POINTER_SHA256 = "A1C62FDACAA34DFC1B806DC18258F2E732539F7AE9D85AA4BD9E1067B8749D9F";
const AUTHORITY_BYTES = 2153565;
const AUTHORITY_SHA256 = "D1F06B311F6CBD991DD247D745DD9A72DDE326A20396DF43CFE0C8EDB1593CDB";
const CURSOR = "NOE-P02-KO:SOURCE_LINE_3573:P03_BEGIN_OUT_OF_SCOPE";
const COMPLETION_STATE = "producer_draft_text_and_terminal_table_coverage_t01_t32_199_units_through_u226_indexed";
const REVIEW_STATE = "unchecked";
const FORMULA_REVIEW_STATE = "not_performed";
const BUILD_STATE = "not_compiled";
const RENDER_STATE = "not_rendered";
const PUBLICATION_STATE = "not_published";
const TEX_REPAIR_REVIEW_STATE = "unchecked_linguistically_checker_confirmed_tex_repair_only";
const TEX_REPAIR_FORMULA_REVIEW_STATE = "checker_confirmed_tex_delimiter_repair_only";
const TEX_REPAIR_BUILD_STATE = "checker_isolated_probe_pass_only_full_build_not_performed";
const CHECKER_TASK_ID = "019fcc0e-b6fb-7782-9603-36befa045276";
const CHECKER_ADJUDICATION_ID = "KOCHK-P02-REDO-PRIMARY-U02-U29-001";
const CHECKER_ADJUDICATION_BYTES = 7486;
const CHECKER_ADJUDICATION_SHA256 = "83ACDB717904EA1FB224136AFDF1C406A695736C151C9AE0BEFF4A56C72D93C9";

// Retained verbatim as a historical pre-expansion input baseline; the live freeze below is
// harvested and cross-replayed from all completed producer custody files through T32/U226.
const legacyUnitRowsT01T12 = [
  ["T01", "U01", 473, 479, "B19880EC75730F48AA8D30423B1F43506482BD01DBBA9738B3BBDA2B0E3B249E", "Noether_P02_Korean_T01_U01_UNCHECKED.tex", 844, "CAD11967D6497AEEE5FE1C37AC016A954BD40A413400CFE3D9E33B3FE78CC78C"],
  ["T01", "U02", 483, 496, "D9660703F6FBF0A3106AEF04FAB4777FCDD07121D402CE0C728E94CC713D7012", "Noether_P02_Korean_T01_U02_UNCHECKED.tex", 2928, "081252F90A544382AE7AAF11FDE4755CE99E5F640AC3F20C0F0CBD3A39D6C2BF"],
  ["T01", "U03", 498, 502, "1B4569A4148CF11BFEB799A994819C4CA144F7E0093E33A41568D78A6870CF21", "Noether_P02_Korean_T01_U03_UNCHECKED.tex", 2072, "1C31C069199BA2C36A146142D3AE29990D8D6BF9BB19C4F3FF6A487794D60E46"],
  ["T02", "U04", 504, 508, "5D444888D0CF99A33BEA8492D51ABAE52ACA5773B7D154E6BB9D508B69A71392", "Noether_P02_Korean_T02_U04_UNCHECKED.tex", 897, "B43F6E583C9EF9E19F7C98F6CA2944C3F26C94E076BFEC672A8CFA63EB6E8274"],
  ["T02", "U05", 510, 517, "66FE01DD58FC0EBC1958535074A139B9B7AFC7F99F1DB99EBE8A7EC7EC5F5397", "Noether_P02_Korean_T02_U05_UNCHECKED.tex", 1853, "51FCF8F3308E9506CFF753A98A7E81F5C474E9214AA723ED370ED26C7207F917"],
  ["T02", "U06", 519, 538, "42E98B50EA314690AFED9CFF22DA511DE9E1177448F85FB2D47EF32616DA53EA", "Noether_P02_Korean_T02_U06_UNCHECKED.tex", 1199, "91D1AEDE82C311ABCD7F5F0D6B159F340DD9270CD48F4ABB4CCA00484B97AB2B"],
  ["T03", "U07", 540, 566, "649EB9AF74241AE09A1F8AD382EA45C2D03DFE254C9E0C2B466FD462612C88DB", "Noether_P02_Korean_T03_U07_UNCHECKED.tex", 1340, "6DC2898B793F958C194AAC22D5FAF23B00CAFA6E47359C3FF45878CB6233F4CD"],
  ["T03", "U08", 568, 583, "EB0FFC4F23C73AD76E740917D8A57B320861C446F2B16C0D4B70D3477615CF6F", "Noether_P02_Korean_T03_U08_UNCHECKED.tex", 1936, "03E42551EC74FCA965680A680CAC0D45B2B482E4C78D6658A41E98753FA20722"],
  ["T03", "U09", 585, 597, "77956EF2A8DB26BC9CA1934A68622734D6AFEB1295E4B8DB7A5B63646E5E84DB", "Noether_P02_Korean_T03_U09_UNCHECKED.tex", 1053, "D0E8FC772D8D352F3477D857EDDCAE7678975D8328E2268EB08AD1D2D793E34E"],
  ["T03", "U10", 599, 603, "BF24F4A6AC52C0E4594E4618C22668C78D57AF6D2E94FCCFFCB307EFF6A02E5D", "Noether_P02_Korean_T03_U10_UNCHECKED.tex", 1644, "C0129B7E39032A51EA9F2701D506AD3482C19CECF3E055C34D10D22DCD817B93"],
  ["T03", "U11", 605, 658, "84434162153FADCB69FB887EE93B98FD0B5176B899A8DE7939A2425F74476D6C", "Noether_P02_Korean_T03_U11_UNCHECKED.tex", 1994, "5D5040BF7B2547565BCCA608DD84B0B23818C9A641C5203E7283BEC0D43A82D3"],
  ["T03", "U12", 660, 668, "44C8DDED4FCB47D0F44B6D0946DCBA1BDF9633A6276E0456F1FC3EECE18F964F", "Noether_P02_Korean_T03_U12_UNCHECKED.tex", 1260, "C137EFA41218012899DF7DB19C3F9B5368A39573DE35D6E70A1050F44F0BED1B"],
  ["T03", "U13", 670, 690, "DEC3A3216CA2C2D9260201F7F03881C8619A42BBAE8526CB18F02F42EC9CEE71", "Noether_P02_Korean_T03_U13_UNCHECKED.tex", 1264, "9E66EEE7BD1412E5C251919D73D35EFCA5BE2411C794E53EC13769256EFD1D8C"],
  ["T04", "U14", 692, 714, "0BA8392FCB89243F2F579B480B501B624AD8181ADA9B81C9063CB6E3B35C9FEB", "Noether_P02_Korean_T04_U14_UNCHECKED.tex", 2167, "E4EA45CC6E9CF43F71B22B84EBB75D545679D588D158008BF2EA1CB99B9D4CCF"],
  ["T04", "U15", 716, 731, "737D7A2197E4FABB259D81993500AEAA59B195109ED3A6551C772DC69EB4FD8A", "Noether_P02_Korean_T04_U15_UNCHECKED.tex", 1481, "DD4A438DAFC2D3779DE165B8C86F2157C43A0C72C0BF0EC21DFE0589A8488251"],
  ["T04", "U16", 733, 739, "A53566131881BFF525AC8F53C8E08A99F8FF4311CA0C5752A5A686B853DC34A2", "Noether_P02_Korean_T04_U16_UNCHECKED.tex", 1268, "3373680A739CF0DAA4F577DEF0F2EB9C3D258A331AC365AD68EB548D27E89267"],
  ["T04", "U17", 741, 754, "61CEA035D29C93A45B9953F0101E9069852785C82662DC8F7718CA2B4DFFF77D", "Noether_P02_Korean_T04_U17_UNCHECKED.tex", 1418, "A984E0FCC41245E5B92E68E65FD45920862D90E858A0FAB2F773372B641E7DE4"],
  ["T04", "U18", 756, 804, "E6DA3B55C8CC5BF0E4EACB48EF920344E928FA94993CCEBBF63529D07C05C48D", "Noether_P02_Korean_T04_U18_UNCHECKED.tex", 2336, "AC9E075C49B82565858C88CB2D75A170344A43B64B5FE5C8EB6A537F0BE27149"],
  ["T04", "U19", 805, 821, "4ECADD6328527700BBFBBB0E33C7B9707573AE9F51A1FA78F9EAE378AB396EEE", "Noether_P02_Korean_T04_U19_UNCHECKED.tex", 1367, "E5074116B8D4CE64D5683D15E0B0F12F149F3E2303F6F4925D4F4BC855639542"],
  ["T05", "U20", 823, 835, "A69C642322B1C87D96DD46D1298F390B9661D29FF3A7394B2AB38CE062BBC9E8", "Noether_P02_Korean_T05_U20_UNCHECKED.tex", 1799, "BFA155BF1A3FDDED4C4772B5F3038FE86CE5AC41E96DCDCDDBD0457C4215E116"],
  ["T05", "U21", 837, 851, "30697AB95E52EB555F051E3AE98DE59F7E905FC7840960A33700498487124F99", "Noether_P02_Korean_T05_U21_UNCHECKED.tex", 1859, "3AF1EFF132DBEC3A4573DF6C44F5FFEB0D5E11DC6BFDABA7F92F1AC2E2AF9765"],
  ["T05", "U22", 853, 859, "5FFD5066BD95B582131985895E0A87B66AB42AE391557098AC9F54126BE8488D", "Noether_P02_Korean_T05_U22_UNCHECKED.tex", 1537, "6BDE79C7A7FEC4A059218594E38E3321EC634336B77C77D88D767EF5C7140FA1"],
  ["T05", "U23", 861, 878, "1DDC3439D9ECC8156397E0BA964D27FCA0D75E991E9229B9EB009759A5A17911", "Noether_P02_Korean_T05_U23_UNCHECKED.tex", 2359, "71ADA33BCEFFB608ED678FA88E239A7D6B853E5C1CF967DDBB76130910017092"],
  ["T05", "U24", 879, 891, "5442388FA855E35E45258D2CA5AFD00E9D9E9D572EFD416AE4E62151CAA0C59A", "Noether_P02_Korean_T05_U24_UNCHECKED.tex", 1053, "74F5F6230A155FD4D059232D892F756856628D9DC1CB0B16547514A510EC79BC"],
  ["T05", "U25", 893, 895, "52ABE2BB1E5CEB92B5B544F24F2BBCDA72187BA475BD441553B9344829170B9D", "Noether_P02_Korean_T05_U25_UNCHECKED.tex", 1366, "2038228E0DF3834E2AD3D2B804C7BC8DDF7197295220E355C3B3E20204D37E78"],
  ["T06", "U26", 897, 926, "244D2E475C6E50BD9DD77B1ED8F0217F370A598B536F23F3A2D706937E750845", "Noether_P02_Korean_T06_U26_UNCHECKED.tex", 1504, "FC4C9DF3C01A72D68EF72D523DEF0222EF114B13328F2629A250D597FF64BF47"],
  ["T06", "U27", 928, 944, "1AE455C23F1F0C2EB8B4A8AA97EC4FFCAA096479FCB594F3F7055516B283DC26", "Noether_P02_Korean_T06_U27_UNCHECKED.tex", 1468, "D95501425A53AA5DFA59B178F7AAA1E1523F8DFCD88DD42EDE036484AC123B40"],
  ["T06", "U28", 945, 955, "B799CE228CEBDBC42A39E7B7AC4EA2B46BCE21325B2B2E190FF902C9ED9AB797", "Noether_P02_Korean_T06_U28_UNCHECKED.tex", 778, "00E6662910F2859DF937132D037EA36894B6B4B62BD00279E88E50DBCD5863CA"],
  ["T07", "U29", 957, 981, "D1896603195874E5D1C3B7C1B828193A07AC5ABB954927516208F9BAC7C196A0", "Noether_P02_Korean_T07_U29_UNCHECKED.tex", 1193, "1424FE01364DF9495EFDF9F9EA6A7D98E3A0071D98CE1EAE3FF98544F871625A"],
  ["T07", "U30", 983, 1001, "9FBE371DEA21FBC7FCC5612B6E12553272D07A50F5F9AB55F7DE51B1F2739988", "Noether_P02_Korean_T07_U30_UNCHECKED.tex", 1052, "85A15F0D8625FB426EE485672B91A72BBC2B35A39B0A24B20CDC895EE01EE3FD"],
  ["T07", "U31", 1003, 1023, "B866ACBCE749D55076391785D41EEB91E3A79A86283C3E79D4252911F27C8623", "Noether_P02_Korean_T07_U31_UNCHECKED.tex", 1604, "B857852737512EA7A42779E9286A8D7376E0376597B3B41DCFFAF926F5347FB4"],
  ["T07", "U32", 1025, 1045, "8960F74496AC215A8D61876321338C0E1252C651513D4503A2B80F5AC527423D", "Noether_P02_Korean_T07_U32_UNCHECKED.tex", 1314, "C2882E0A1E3103D403F5012CCFD8930D52E4B4E6ED180A23054CD6FAF4DD42EB"],
  ["T07", "U33", 1047, 1066, "C1CCC92A7F3EF234A04E6CB1399327DCA904576A75D99FD6BB911AD75A02E194", "Noether_P02_Korean_T07_U33_UNCHECKED.tex", 1454, "DE012BABCCA5B58E66C2B65FA26DC0AAEFDF3F8BACA6E7CC037A1A3B3E10CAB0"],
  ["T07", "U34", 1068, 1083, "0C96F0ED8729BDECB0AE29A4782BDA47C70D1083B86572DC5BE6CD399DD3BBD8", "Noether_P02_Korean_T07_U34_UNCHECKED.tex", 1266, "3D941420042813E2F604847FBEE1EE4DEC34955F2AD7CC27B3187428D82BD24A"],
  ["T07", "U35", 1084, 1110, "05652F2C315219B95B0A8C44F747665776E9A45A75331F08E18621E86C781B30", "Noether_P02_Korean_T07_U35_UNCHECKED.tex", 1218, "9D6D205AB9AEF2984C462CBC4472A36A9249A49A1D51445682597BDC1F529401"],
  ["T07", "U36", 1112, 1130, "DC0E13FB3DBF9E78BA66F570CCB830CDF088DC8806C80E9A652624B14B5DE583", "Noether_P02_Korean_T07_U36_UNCHECKED.tex", 1505, "8191C0DB71924B3957431FBCBEF22A18AB705682B227746962200AA394DE63F5"],
  ["T07", "U37", 1132, 1149, "708CA65AE277779805B0872EB8E3ABFBA83AC54092120803EE1F05505D5286C4", "Noether_P02_Korean_T07_U37_UNCHECKED.tex", 1413, "FE94279496767C5DE99EAE9B18D5C311494D61C4AEF4D2ADCACBF343FAD6E7A8"],
  ["T08", "U38", 1151, 1169, "B16EDCBA6DF672305903B959D18A0A7E9B3DA41D694C179CD5537EBF5E83445A", "Noether_P02_Korean_T08_U38_UNCHECKED.tex", 1722, "B17A0666B0A7B97AF26322FB0DCE8DBF44743C89D123EA87A546F230F11991B5"],
  ["T08", "U39", 1170, 1201, "0431B729F967BFB99C5B87501F2284F01C14B2AD096BE2F68F63A75F5A18C0D0", "Noether_P02_Korean_T08_U39_UNCHECKED.tex", 1938, "429786E189AB1BAEB8AD980E8E865F12DB71160E273CBACF2B7CECBF0C63A67C"],
  ["T08", "U40", 1203, 1210, "32BF9A8FCFCCA8001C4209776C5E6172F6F3D85B9EF1D8F713D617AE94BF7374", "Noether_P02_Korean_T08_U40_UNCHECKED.tex", 999, "702145461A4C04C16EE75608D71B5F57121F371AF1ABC30807F589D2AFFB4750"],
  ["T08", "U41", 1212, 1229, "B5E101434BE0B5BD9A01D1090A11ED72E63777B3F16502117784CD4833EBD0D3", "Noether_P02_Korean_T08_U41_UNCHECKED.tex", 2024, "624C64DE3ACB6BBC24447E67F27D5989664E67BD4837B4298935196EC54945E2"],
  ["T08", "U42", 1230, 1253, "4196DE83C0701990EAE5143E725AA676C60A0B19E1891F6673F4D42400FA8B04", "Noether_P02_Korean_T08_U42_UNCHECKED.tex", 2589, "E2551348279B7D5AEA85606D1E0B55DD1CFC5A62C55465E16DF6509CADD6AA43"],
  ["T08", "U43", 1255, 1266, "63BFE9F9AA3E9B92653CAEB487CADE9ABF7B0D64119208361612964728215663", "Noether_P02_Korean_T08_U43_UNCHECKED.tex", 1447, "3BE177A12A9AF5D88A0735F173E4584E70656243EB633D8C47472C15379B6421"],
  ["T08", "U44", 1267, 1275, "C642D79A2497992CEEE41BD673CA5ECE61A468FB85BE039D6584D938AF51FFD5", "Noether_P02_Korean_T08_U44_UNCHECKED.tex", 1381, "2ADF9E02425CD74FAB3315A820A54CF5E58D1BF4296ED20492FC1A167CDAD372"],
  ["T08", "U45", 1277, 1300, "3F91581442BE5A8D885850BBE6DBAABF9847339A0704183078DA5715FFE7825D", "Noether_P02_Korean_T08_U45_UNCHECKED.tex", 1514, "0576200DDC934F6063F499CC7E29EE4CB3FD05300E1282470B8CBC758859620D"],
  ["T09", "U46", 1302, 1320, "16F9FD5C9178C4A427E5B14000ACAC8BA9BA6293DA772ADE85A7FA763DC75B67", "Noether_P02_Korean_T09_U46_UNCHECKED.tex", 1762, "F2A520ABAD615F3FAA3D95075B4D0976BCA24E01D1C97437E273C18AE5766C24"],
  ["T09", "U47", 1322, 1338, "22AE72CE9FB456EC35F61FD989AFE9DC9AA0B7C5A57554F76C7B137723DE33EA", "Noether_P02_Korean_T09_U47_UNCHECKED.tex", 1068, "5598B17A075FBA6E17536A346C98853364B30198CC9C1F29E4D74B9F39CC97C6"],
  ["T09", "U48", 1340, 1348, "AE1425B2AEB9D2BEFEACFAD49A734BFF191ACA01CF477C7C31FBACC1A83CBF20", "Noether_P02_Korean_T09_U48_UNCHECKED.tex", 1173, "A0D636A3F0E29E08C2AC05AB991CCCE58BB7BDC889F61651B40409AD2AD8DD23"],
  ["T09", "U49", 1350, 1367, "D5A7BF0E64F8C98C9E3C2B838CE4A9F9B753B5CD1B4192E59EA9F567D5753145", "Noether_P02_Korean_T09_U49_UNCHECKED.tex", 1278, "92D04D78360B67EA6A37CF65DD6E7898771CED8A311D991E41952131CBB90C88"],
  ["T09", "U50", 1369, 1383, "2EB21B920B39E6E780351C250C65A6633E9931D8DC20F275BEFFA5FAB4969DED", "Noether_P02_Korean_T09_U50_UNCHECKED.tex", 1061, "26EEC7BE91A0A0D1D7B8DF97F606D64E9710C995E8CABA3388DFB86FC242EF6D"],
  ["T09", "U51", 1385, 1405, "B8F94103D1467E95E805202A350F82336D31A908AC2343B5033670DCBAD5F299", "Noether_P02_Korean_T09_U51_UNCHECKED.tex", 1265, "772B236A3CE082FA7DA2F6FABCE7BD3724A784CF4AA687FC01585C725A39D22A"],
  ["T09", "U52", 1407, 1415, "581C1F1C4666E57B5994AFED2B9E2F54C3D882E1F7CD05022C4553645E4A3DF6", "Noether_P02_Korean_T09_U52_UNCHECKED.tex", 834, "29240A4BCAA7B5E2597685ED0E6A44CD43293D4D1FE3C7E0982CF4CB942070A5"],
  ["T09", "U53", 1416, 1424, "CEBF430E6D0BFFD1EE0C1E8A1E35332F32AA51B41CF681B273C697FC190B2374", "Noether_P02_Korean_T09_U53_UNCHECKED.tex", 838, "DA6F9A4E3DFB6CF7AA7729A82882254DE5B0EF897D4FDEC3B761CA80B6980C5D"],
  ["T10", "U54", 1426, 1446, "ECD615DE88939EF480F70666C3D5C2425F8B7C7E1E9A3BF732245292F9B7EE47", "Noether_P02_Korean_T10_U54_UNCHECKED.tex", 1043, "E49592E9335EFE7F42BFAED9A4E0853D6DFA48EB84F32A38DE0D9199CD369657"],
  ["T11", "U55", 1448, 1464, "804D9870540118C189717346DBA6415FC4E4B4DACE19B898A22689A6CD0ADA9D", "Noether_P02_Korean_T11_U55_UNCHECKED.tex", 997, "926200615B8D59EC2A155146E0BC3E10A5333570FB08912ACBD85BE5B2BA28D3"],
  ["T11", "U56", 1465, 1494, "830F42268B40E5C61C2E9C097D082F582C45D8CCA7EF6A904CC62D1E270F398D", "Noether_P02_Korean_T11_U56_UNCHECKED.tex", 1571, "1AA8A05A411DAD85219BF47DFC33AD164571951042CC8A5D83727BDFFE43DF84"],
  ["T12", "U57", 1496, 1529, "085EBCB8CE7A84B7D703F62AD8193D562558EE6AC1229E075C6B81EB412F0A71", "Noether_P02_Korean_T12_U57_UNCHECKED.tex", 1244, "234E53B8B9199BC14BA4077D2365DEB91FD5F5BE1068AF0CDF80AF66418FE89F"],
  ["T12", "U58", 1531, 1539, "41199EB2C6ED9F651C0DF527D63FB01ADB075495586995D7D40E71AD8BAD678D", "Noether_P02_Korean_T12_U58_UNCHECKED.tex", 706, "00492270E77478BD6ED80CD05058C9C5DDF32F50F54766A1262E3E10B68F8ED8"],
  ["T12", "U59", 1541, 1555, "F013ABDE041C7338E893DEB518A701FE59F9459616CBDC252732E5E7B72637DA", "Noether_P02_Korean_T12_U59_UNCHECKED.tex", 909, "7ED11389ACA5A89B2A8423FD03CEF0ED58E8C62987B00080DB90289A24ACB61C"],
  ["T12", "U60", 1557, 1565, "3680DF43F17C9A94799F655789AE9ACD639574C83D848DE26A7CB197A4F76295", "Noether_P02_Korean_T12_U60_UNCHECKED.tex", 914, "16790D69C41F065C371648F9346A0798D53D355DAC445BD4A1B9A34FDCFDD892"],
  ["T12", "U61", 1567, 1578, "840C3B77EBBA5F9BC96AC29CDBB50EB7876237AFF1D696776645BB838E9C1AB2", "Noether_P02_Korean_T12_U61_UNCHECKED.tex", 767, "A456657D7EDAC80843A431E3E457169C6DD92B0AB0DCCD3A32F97BACE4F7672F"],
  ["T12", "U62", 1580, 1596, "A717AC489AB5E9AF26490CC6DBF1579395FEB55BC65D373BDBDCD75F1CB581EA", "Noether_P02_Korean_T12_U62_UNCHECKED.tex", 1012, "A1035AAEBF0934EF6BAA484E61BC99C606A097CCA136C4738A431E2903A74FF2"],
  ["T12", "U63", 1597, 1608, "22D0ADFFF97AD120A7D32345CF2CF37460D5D9423B0FE813D5634D426C1AE090", "Noether_P02_Korean_T12_U63_UNCHECKED.tex", 914, "A159E06DE772751B48DF1B464E7799C98227FFD5B3B2BB827BB9B2A20C9FF7CF"],
  ["T12", "U64", 1609, 1621, "FB706C8A89D45B63603147FA28E3ABCCBDBB2D7C6D881175CBF65F1A376377F5", "Noether_P02_Korean_T12_U64_UNCHECKED.tex", 960, "DEF1101C0B34B1C6AE7FD82373DA45FB5FBB8AF1ABAFDAD9FD59BA9656CB27D5"],
  ["T12", "U65", 1622, 1633, "D85A8DAAFD1FA68476E5555663F5973A5530D455E8F8FB30A0EF09FBBD5DA750", "Noether_P02_Korean_T12_U65_UNCHECKED.tex", 812, "FDE71068EC508A8FDAE2706B4BE0231C59ED1B4EE74BD3FFB8152E364B92F2D0"],
  ["T12", "U66", 1635, 1651, "86AE15479B00AC60D9D33A1F6AB794ABB15884664A2793AA15C46F57623DB166", "Noether_P02_Korean_T12_U66_UNCHECKED.tex", 1180, "6DDEBA55C921A90381E8DF040AFDCABBF121CC5BB7216533CDF3B6636E3ABBFF"],
];

const legacyUnitsT01T12 = legacyUnitRowsT01T12.map((row) => ({
  tranche: row[0], unit: row[1], sourceStart: row[2], sourceEnd: row[3],
  sourceSliceSha256: row[4], targetName: row[5], targetBytes: row[6], targetSha256: row[7],
  targetPath: path.join(projectRoot, "targets", row[5]),
}));

const legacyTrancheBoundsT01T12 = {
  T01: [473, 502, 4831, "E37700CD2C682326459AB3EF05C14EA09B41093CB4FF298DAA707567A9E86BA6"],
  T02: [504, 538, 2627, "08B12200C54484340FD7EDD94B72010822C65BC66CF487E293DADD1CF06C7E10"],
  T03: [540, 690, 7260, "7C9A1EC505C9DA6F1A775535EB0706FACF4E68C2F577DC68F22A1468B152AD14"],
  T04: [692, 821, 7304, "8C67A490EFE25B0C2AF3DFAEEB814B47681F0345D787CAF331C8E874CFF50CDA"],
  T05: [823, 895, 7111, "1BE61D60953273BD01763ECC59F202E11E03639C73DFCC7804A3D1ECD5973177"],
  T06: [897, 955, 2401, "99268AE3C3EF1B20891E030761F97AFE16E8A4BC32C5A62CFF1F0185AD25190C"],
  T07: [957, 1149, 7734, "69ABE4F16190B0495A6EF3F835BA909C561046307FE45DFFD8994E73FC9DF826"],
  T08: [1151, 1300, 9993, "DA15CC3081859BBF9B1C4D798ACC75ED5360A99F2662E57BBD76F2E50615C838"],
  T09: [1302, 1424, 5623, "F4812DDC93A637734E8BEF5A36ED45979B28F9920317A6F624E0CB12837BF739"],
  T10: [1426, 1446, 595, "ECD615DE88939EF480F70666C3D5C2425F8B7C7E1E9A3BF732245292F9B7EE47"],
  T11: [1448, 1494, 1676, "D23570704558E76556A6B00CF8C39104F522F30B3C6ED18F46AD6F8B1BC869E9"],
  T12: [1496, 1651, 4879, "34C6CCF6B461BA96141E91494FFA344F0D25EA30CE217B08D4D0328EC7C890DE"],
};

const legacyProtectedMetadataRowsT01T12 = [
  ["CHECKER_HANDOFF_INTRO_T01_T02_U01_U06.md", 1536, "08186B6F1AEF1B4F234A6821A85167820C2EDA024E24D8EDF6DFEDCCDFD7BDA8"],
  ["CHECKER_HANDOFF_T03_U07_U13.md", 1430, "D76E099FF23BF70046433A2FC9C21C6E129C22B20039A4B5128B57EC5C776228"],
  ["CHECKER_HANDOFF_T04_U14_U19.md", 1117, "7DF55811D1575F7220F3084BC99C2C177E933D75A4C3E86C083BA0565F644F5F"],
  ["SOURCE_CUSTODY_INTRO_T01_T02.md", 2409, "B32CBDD3DD3F36A0A087BACBE4E285ECC026C89BCAFFCD93FF285BF8B8D5CDF9"],
  ["SOURCE_CUSTODY_T03_SECTION1.md", 2243, "112A772F4B948489C80CAEB5441C706E44FFF77838EAFF4F8950916982E9ADDF"],
  ["SOURCE_CUSTODY_T04_SECTION2.md", 1823, "6F1F26C829D0C5A70481985A045513E1A30C330FF5A703CA19E89D7C7B02FF55"],
  ["STATUS_INTRO_T01_T02.md", 998, "8F89BB2917B9D98951FC76D72AE5BBFFF50C625A8F4514447D52AF496361D142"],
  ["STATUS_T03_SECTION1.md", 832, "0F2737572FDDFE84E04ACC8FD0F813A68D4877137D9A5E37AF3EA0FD1573754D"],
  ["STATUS_T04_SECTION2.md", 698, "CBCBDD46A8B0D65744AA104F49EDB76D4B09BFECA45CA2421F3F56D5CA848467"],
  ["TRANSLATION_CHOICES_INTRO_T01_T02.md", 3173, "B4ADE18F1AA96CAEDBB5493281019E2BB7ED113216C62398B34242AC6E101EC3"],
  ["TRANSLATION_CHOICES_T03_SECTION1.md", 2065, "14F7B4AB1CA4A6B360256C40F1DAA12CDF1610D4F0BDA967DA4E6A1363FA44EE"],
  ["TRANSLATION_CHOICES_T04_SECTION2.md", 1328, "E172EACF0C59711BFE7A0C789035794B4A8353A13EB25326A12E6AE70E849FA9"],
  ["CHECKER_HANDOFF_T05_U20_U25.md", 1261, "F693FC3217BFD3FDE6CB094A202D3F2FA725D03D8DCDDAE532137CCCA5B504C3"],
  ["SOURCE_CUSTODY_T05_SECTION3.md", 1938, "B04955B8FE6D55316862697951450854A232D5AB59E0DC036AAB8A994E6A538C"],
  ["STATUS_T05_SECTION3.md", 584, "92523507BFA84542742B9E1CB0DF12EA04EACB2FE4B40393FF180C8C0B9AD014"],
  ["TRANSLATION_CHOICES_T05_SECTION3.md", 1856, "FFACC96C06596865266DDF6A18DD79B523B7151966D7AEE98ADCBF261BFB2ADA"],
  ["CHECKER_HANDOFF_T06_U26_U28.md", 1126, "FE5350B422AC622A760D6D3EF1564EAA1ECA741051A45AEA7D3E83954C8E403F"],
  ["SOURCE_CUSTODY_T06_SECTION4.md", 1497, "E322BA57BEC36D935D0A8E1BD6B9222AA646EADA7C2701F6715BE5771772CF4E"],
  ["STATUS_T06_SECTION4.md", 616, "6F95281D1E09BACF50D5681BC0D07C342702BC43A0EC03877EBEF997410C6AD9"],
  ["TRANSLATION_CHOICES_T06_SECTION4.md", 1788, "7C626C5A29772248A4AB0A70C4853A118B3552E8F7728660E8C72862EE63E836"],
  ["CHECKER_HANDOFF_T07_U29_U37.md", 1295, "72F4430BC617D28C6E2B14A4A789117B8F5210CD7B623438FC2021B3EA94ACFC"],
  ["SOURCE_CUSTODY_T07_SECTION5.md", 2503, "7354664A2BB6E477497477454350DE13176211E57826C4339041F7AE9E1AC926"],
  ["STATUS_T07_SECTION5.md", 556, "45C80ACE8A9DE4CCFBCE3147181A15AC74D51CD4775ABD4384CF01F004E152A1"],
  ["TRANSLATION_CHOICES_T07_SECTION5.md", 1505, "FC17D9D2739C293A8414FABD7800FDCE601BAA826611F97AD0A453432E31E0F9"],
  ["CHECKER_HANDOFF_T08_U38_U45.md", 1356, "8307B6F837B1D1FE806C3500805C1C328E1BF24DCB118EAE3DA39B602916D0E4"],
  ["SOURCE_CUSTODY_T08_SECTION6.md", 2299, "FB01CAD1D80BB532A6C702ED84A0F6600774C72001E1982C63660E5CAA475AED"],
  ["STATUS_T08_SECTION6.md", 565, "B5152B9F98C545E71C663A56DE3659DE8DA416F642DE6459133175A6940D861B"],
  ["TRANSLATION_CHOICES_T08_SECTION6.md", 1721, "90FB50668E34EAC96F584303300821B809CC3EE2FC81B73856A5EE47E9F1A934"],
  ["CHECKER_HANDOFF_T09_U46_U53.md", 1261, "429765BAEC2898D9358FC07D5BB03D4CBBEB3B1FA54D2965EEBAAA096B457CFD"],
  ["SOURCE_CUSTODY_T09_SECTION7.md", 2302, "900D7DE3FB8677B037D3B876B1C139589DA2D787CFAD82B7C917A4D33CDFF84E"],
  ["STATUS_T09_SECTION7.md", 578, "45DA7942079EEAE350F4798F3704F96BFB61BF9206B6347E141B6DA2D92DC6F7"],
  ["TRANSLATION_CHOICES_T09_SECTION7.md", 1552, "ABC817A2F0D07A7DB8B2DC38F6008BF679FDFFC5C50A81D8CB45329235289CD7"],
  ["CHECKER_HANDOFF_T10_T11_U54_U56.md", 1037, "1EC17A67ACBD9C78819D40C4CEA140648C61F1D0FDCE4D2416770035CEA688E5"],
  ["SOURCE_CUSTODY_T10_T11_SECTIONS8_9.md", 1426, "C5A95FE3032959D326332448C05EB871BF6D13B430477316E3133F0B9E9F5A38"],
  ["STATUS_T10_T11_SECTIONS8_9.md", 543, "71D5F0CA9E95936CE1EF60000752F376C81E37240A0E7D7282EA5DD2B3D5B50F"],
  ["TRANSLATION_CHOICES_T10_T11_SECTIONS8_9.md", 1353, "4D44349F6CAF4F514A7065D5E13CFDB2B975026FA0B14E2CD979208D083E47F0"],
  ["CHECKER_HANDOFF_T12_U57_U66.md", 1163, "5FF8AF0084BAC1E798284D3831634E667C7D123AA83DAE4987C703B6139C4CD0"],
  ["SOURCE_CUSTODY_T12_SECTION10.md", 2621, "A09A4B727BA4258C872E5B4BEE9AF04B34443EEC968A4DE5A2CD8F0ACEC7808D"],
  ["STATUS_T12_SECTION10.md", 539, "241DA8DC7BF6BF1BD3C2A7F6D8FAD2866D06A82AD76068456A3526958EBAF059"],
  ["TRANSLATION_CHOICES_T12_SECTION10.md", 1417, "E65D453DC8681B35997CDAA507DFB6CE63C46D58F43550441F6CA076136BBDAB"],
];

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex").toUpperCase();
}

function stableValue(value) {
  if (Array.isArray(value)) return value.map(stableValue);
  if (value && typeof value === "object") {
    const out = {};
    for (const key of Object.keys(value).sort()) out[key] = stableValue(value[key]);
    return out;
  }
  return value;
}

function canonical(value) { return JSON.stringify(stableValue(value)); }

function withoutKey(value, key) {
  const out = {};
  for (const current of Object.keys(value)) {
    if (current !== key && !current.startsWith("_")) out[current] = value[current];
  }
  return out;
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function normalizeLf(text) { return text.replace(/\r\n/g, "\n").replace(/\r/g, "\n"); }

function csvEscape(value) {
  if (value === null || value === undefined) return "";
  const text = String(value);
  return /[",\r\n]/.test(text) ? '"' + text.replace(/"/g, '""') + '"' : text;
}

function toCsv(headers, rows) {
  return [headers.map(csvEscape).join(",")]
    .concat(rows.map((row) => headers.map((header) => csvEscape(row[header])).join(",")))
    .join("\n") + "\n";
}

function parseCsv(text) {
  const rows = [];
  let row = [], field = "", quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const ch = text[index];
    if (quoted) {
      if (ch === '"' && text[index + 1] === '"') { field += '"'; index += 1; }
      else if (ch === '"') quoted = false;
      else field += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") { row.push(field); field = ""; }
    else if (ch === "\n") { row.push(field); rows.push(row); row = []; field = ""; }
    else if (ch !== "\r") field += ch;
  }
  if (field.length || row.length) { row.push(field); rows.push(row); }
  return rows;
}

async function readTextFile(fullPath) {
  const bytes = await fs.readFile(fullPath);
  const text = normalizeLf(bytes.toString("utf8"));
  const lines = text.endsWith("\n") ? text.slice(0, -1).split("\n") : text.split("\n");
  return { fullPath, bytes, text, lines, fileSha256: sha256(bytes) };
}

function lineSlice(file, start, end) {
  assert(start >= 1 && end >= start && end <= file.lines.length, `Invalid line slice ${start}--${end} for ${file.fullPath}`);
  return file.lines.slice(start - 1, end).join("\n") + "\n";
}

function relPath(fullPath) { return path.relative(workspaceRoot, fullPath).replace(/\\/g, "/"); }

async function writeText(fullPath, text) {
  await fs.mkdir(path.dirname(fullPath), { recursive: true });
  await fs.writeFile(fullPath, text, "utf8");
}

async function writeJson(fullPath, value) {
  await writeText(fullPath, JSON.stringify(value, null, 2) + "\n");
}

async function fileIdentity(fullPath) {
  const bytes = await fs.readFile(fullPath);
  return { bytes: bytes.length, sha256: sha256(bytes) };
}

function parseCount(text) { return Number(String(text).replace(/,/g, "")); }

async function harvestCompletedScope(authority) {
  const metadataEntries = (await fs.readdir(projectRoot, { withFileTypes: true }))
    .filter((entry) => entry.isFile() && /^(?:CHECKER_HANDOFF|SOURCE_CUSTODY|STATUS|TRANSLATION_CHOICES).*\.md$/.test(entry.name))
    .sort((a, b) => a.name.localeCompare(b.name));
  assert(metadataEntries.length === 120, `Expected 120 completed T01--T32 producer metadata files, found ${metadataEntries.length}`);
  const metadataRows = [];
  const custodyByUnit = new Map();
  for (const entry of metadataEntries) {
    const fullPath = path.join(projectRoot, entry.name);
    const identity = await fileIdentity(fullPath);
    metadataRows.push([entry.name, identity.bytes, identity.sha256]);
    if (!entry.name.startsWith("SOURCE_CUSTODY")) continue;
    const text = normalizeLf(await fs.readFile(fullPath, "utf8"));
    const rowRegex = /^\|\s*(T\d{2})-(U\d+)\s*\|\s*(\d+)--(\d+)\s*\|\s*([\d,]+)\s*\|\s*`([A-F0-9]{64})`\s*\|\s*([\d,]+)\s*\|\s*`([A-F0-9]{64})`\s*\|$/gm;
    let match;
    while ((match = rowRegex.exec(text))) {
      const key = `${match[1]}-${match[2]}`;
      assert(!custodyByUnit.has(key), `Duplicate custody row ${key}`);
      custodyByUnit.set(key, {
        tranche: match[1], unit: match[2], sourceStart: Number(match[3]), sourceEnd: Number(match[4]),
        sourceBytes: parseCount(match[5]), sourceSha256: match[6], targetBytes: parseCount(match[7]), targetSha256: match[8],
        custodyName: entry.name, custodyPath: fullPath, custodySha256: identity.sha256,
      });
    }
    const singleton = text.match(/unit\s+(T\d{2})-(U\d+):\s*lines(\d+)--(\d+);\s*([\d,]+) LF bytes; SHA-256 `([A-F0-9]{64})`; target ([\d,]+) bytes \/ `([A-F0-9]{64})`/);
    if (singleton) {
      const key = `${singleton[1]}-${singleton[2]}`;
      assert(!custodyByUnit.has(key), `Duplicate singleton custody row ${key}`);
      custodyByUnit.set(key, {
        tranche: singleton[1], unit: singleton[2], sourceStart: Number(singleton[3]), sourceEnd: Number(singleton[4]),
        sourceBytes: parseCount(singleton[5]), sourceSha256: singleton[6], targetBytes: parseCount(singleton[7]), targetSha256: singleton[8],
        custodyName: entry.name, custodyPath: fullPath, custodySha256: identity.sha256,
      });
    }
  }

  const prefixCounts = Object.fromEntries(["CHECKER_HANDOFF", "SOURCE_CUSTODY", "STATUS", "TRANSLATION_CHOICES"].map((prefix) => [prefix, metadataEntries.filter((entry) => entry.name.startsWith(prefix)).length]));
  for (const [prefix, count] of Object.entries(prefixCounts)) assert(count === 30, `Expected 30 ${prefix} files, found ${count}`);
  assert(custodyByUnit.size === 199, `Expected 199 custody unit rows, found ${custodyByUnit.size}`);

  const targetEntries = (await fs.readdir(path.join(projectRoot, "targets"), { withFileTypes: true }))
    .filter((entry) => entry.isFile() && /^Noether_P02_Korean_T\d{2}_U\d+_UNCHECKED\.tex$/.test(entry.name))
    .sort((a, b) => {
      const am = a.name.match(/_T(\d+)_U(\d+)_/); const bm = b.name.match(/_T(\d+)_U(\d+)_/);
      return Number(am[1]) - Number(bm[1]) || Number(am[2]) - Number(bm[2]);
    });
  assert(targetEntries.length === 199, `Expected 199 completed target files, found ${targetEntries.length}`);
  const harvestedUnits = [];
  const harvestedRows = [];
  for (const entry of targetEntries) {
    const targetPath = path.join(projectRoot, "targets", entry.name);
    const target = await readTextFile(targetPath);
    const filenameMatch = entry.name.match(/^Noether_P02_Korean_(T\d{2})_(U\d+)_UNCHECKED\.tex$/);
    const unitMatch = target.text.match(/^% Unit:\s*(T\d{2})-(U\d+); current-authority whole lines? (\d+)(?:--(\d+))?$/m);
    const sourceMatch = target.text.match(/^% Source slice:\s*([\d,]+) LF UTF-8 bytes; SHA-256 ([A-F0-9]{64})$/m);
    const pointerMatch = target.text.match(/^% Pointer:\s*(NOETH-DE-AUTH-v00[45]-20260804); SHA-256 ([A-F0-9]{64})$/m);
    assert(filenameMatch && unitMatch && sourceMatch && pointerMatch, `Unparseable frozen target header: ${entry.name}`);
    assert(filenameMatch[1] === unitMatch[1] && filenameMatch[2] === unitMatch[2], `Filename/header unit mismatch: ${entry.name}`);
    const key = `${unitMatch[1]}-${unitMatch[2]}`;
    const custody = custodyByUnit.get(key);
    assert(custody, `No custody row for ${key}`);
    const sourceStart = Number(unitMatch[3]); const sourceEnd = Number(unitMatch[4] || unitMatch[3]);
    const sourceBytes = parseCount(sourceMatch[1]); const sourceSha256 = sourceMatch[2];
    assert(custody.sourceStart === sourceStart && custody.sourceEnd === sourceEnd && custody.sourceBytes === sourceBytes && custody.sourceSha256 === sourceSha256, `Target header/custody source mismatch for ${key}`);
    assert(custody.targetBytes === target.bytes.length && custody.targetSha256 === target.fileSha256, `Target/custody identity mismatch for ${key}`);
    const expectedPointerSha = pointerMatch[1] === PRODUCER_POINTER_ID ? PRODUCER_POINTER_SHA256 : POINTER_SHA256;
    assert(pointerMatch[2] === expectedPointerSha, `Target header pointer mismatch for ${key}`);
    const sourceSlice = lineSlice(authority, sourceStart, sourceEnd);
    assert(Buffer.byteLength(sourceSlice, "utf8") === sourceBytes && sha256(Buffer.from(sourceSlice, "utf8")) === sourceSha256, `ED0001 replay mismatch for ${key}`);
    const unit = {
      tranche: unitMatch[1], unit: unitMatch[2], sourceStart, sourceEnd, sourceSliceSha256: sourceSha256,
      sourceSliceBytes: sourceBytes, targetName: entry.name, targetBytes: target.bytes.length, targetSha256: target.fileSha256,
      targetPath, target, producerPointerId: pointerMatch[1], producerPointerSha256: pointerMatch[2],
      custodyName: custody.custodyName, custodyPath: custody.custodyPath, custodySha256: custody.custodySha256,
    };
    harvestedUnits.push(unit);
    harvestedRows.push([unit.tranche, unit.unit, sourceStart, sourceEnd, sourceSha256, entry.name, unit.targetBytes, unit.targetSha256]);
  }
  assert(harvestedUnits.every((unit) => Number(unit.tranche.slice(1)) >= 1 && Number(unit.tranche.slice(1)) <= 32 && Number(unit.unit.slice(1)) >= 1 && Number(unit.unit.slice(1)) <= 226), "Harvested unit outside T01--T32/U01--U226");
  assert(new Set(harvestedUnits.map((unit) => unit.tranche)).size === 32, "Expected all 32 tranches");
  assert(Math.max(...harvestedUnits.map((unit) => Number(unit.unit.slice(1)))) === 226, "Expected U226 terminal unit");

  const bounds = {};
  for (let trancheNumber = 1; trancheNumber <= 32; trancheNumber += 1) {
    const tranche = `T${String(trancheNumber).padStart(2, "0")}`;
    const scoped = harvestedUnits.filter((unit) => unit.tranche === tranche);
    assert(scoped.length > 0, `No units in ${tranche}`);
    const start = Math.min(...scoped.map((unit) => unit.sourceStart));
    const end = Math.max(...scoped.map((unit) => unit.sourceEnd));
    const slice = lineSlice(authority, start, end);
    bounds[tranche] = [start, end, Buffer.byteLength(slice, "utf8"), sha256(Buffer.from(slice, "utf8"))];
  }

  const actualNumbers = new Set(harvestedUnits.map((unit) => Number(unit.unit.slice(1))));
  const deliberateUnitIdGaps = [];
  for (let number = 1; number <= 226; number += 1) if (!actualNumbers.has(number)) deliberateUnitIdGaps.push(`U${String(number).padStart(2, "0")}`);
  assert(deliberateUnitIdGaps.length === 27, `Expected 27 deliberate unit-ID gaps, found ${deliberateUnitIdGaps.length}`);

  for (const legacy of legacyUnitRowsT01T12) {
    const current = harvestedRows.find((row) => row[0] === legacy[0] && row[1] === legacy[1]);
    assert(current && canonical(current) === canonical(legacy), `Historical T01--T12 identity baseline changed at ${legacy[0]}-${legacy[1]}`);
  }

  return { unitRows: harvestedRows, units: harvestedUnits, trancheBounds: bounds, protectedMetadataRows: metadataRows, deliberateUnitIdGaps, metadataPrefixCounts: prefixCounts };
}

const authority = await readTextFile(authorityPath);
const pointer = await readTextFile(pointerPath);
const producerPointer = await readTextFile(producerPointerPath);
assert(authority.bytes.length === AUTHORITY_BYTES && authority.fileSha256 === AUTHORITY_SHA256, "ED0001 authority identity changed");
assert(pointer.bytes.length === POINTER_BYTES && pointer.fileSha256 === POINTER_SHA256, "Pointer v005 identity changed");
assert(producerPointer.bytes.length === PRODUCER_POINTER_BYTES && producerPointer.fileSha256 === PRODUCER_POINTER_SHA256, "Producer pointer v004 identity changed");
const pointerData = JSON.parse(pointer.text);
assert(pointerData.pointer_id === POINTER_ID && pointerData.supersedes_pointer_id === PRODUCER_POINTER_ID && pointerData.supersedes_pointer_sha256 === PRODUCER_POINTER_SHA256, "Pointer v005 lineage changed");
assert(pointerData.default_translation_authority.raw_bytes === AUTHORITY_BYTES && pointerData.default_translation_authority.raw_sha256 === AUTHORITY_SHA256, "Pointer v005 no longer binds unchanged ED0001");

const harvestedScope = await harvestCompletedScope(authority);
const unitRows = harvestedScope.unitRows;
const units = harvestedScope.units;
const trancheBounds = harvestedScope.trancheBounds;
const protectedMetadataRows = harvestedScope.protectedMetadataRows;
const deliberateUnitIdGaps = harvestedScope.deliberateUnitIdGaps;
const metadataPrefixCounts = harvestedScope.metadataPrefixCounts;

for (const unit of units) {
  unit.target = await readTextFile(unit.targetPath);
  assert(unit.target.bytes.length === unit.targetBytes, `Target byte count changed for ${unit.unit}`);
  assert(unit.target.fileSha256 === unit.targetSha256, `Target SHA-256 changed for ${unit.unit}`);
  const sourceSlice = lineSlice(authority, unit.sourceStart, unit.sourceEnd);
  assert(sha256(Buffer.from(sourceSlice, "utf8")) === unit.sourceSliceSha256, `Source slice SHA-256 changed for ${unit.unit}`);
}

const repairSiblingSpecs = [
  {
    tranche: "T01", unit: "U02",
    targetName: "Noether_P02_Korean_T01_U02_UNCHECKED_TEXREPAIR_v002_20260804.tex",
    bytes: 2930, sha256: "1D39A01D8908BBEBF41BDE6D6A9E691756BE57CC493BFEE59337371FAEEB8BD7",
    originalBytes: 2928, originalSha256: "081252F90A544382AE7AAF11FDE4755CE99E5F640AC3F20C0F0CBD3A39D6C2BF",
    documentRecordId: "NOE-P02-KO-T01-U02-TGT-DOCUMENT-002",
    repairRecordId: "NOE-P02-KO-T01-U02-TGT-TEX-REPAIR-001",
    repairStructureType: "equation", repairLineStart: 18, repairLineEnd: 18,
    repairFragment: "\\(f=x_1^3x_2+x_2^3x_3+x_3^3x_1\\)",
    originalDocumentRecordId: "NOE-P02-KO-T01-U02-TGT-DOCUMENT-001",
    originalAffectedRecordIds: ["NOE-P02-KO-T01-U02-TGT-PARAGRAPH-003"],
    sourceAffectedRecordIds: ["NOE-P02-KO-T01-U02-SRC-PARAGRAPH-003"],
    repairLabel: "U02 checker-confirmed inline-math delimiter repair only",
  },
  {
    tranche: "T07", unit: "U29",
    targetName: "Noether_P02_Korean_T07_U29_UNCHECKED_TEXREPAIR_v002_20260804.tex",
    bytes: 1190, sha256: "B380060629B2733D4460DBB583DD2866DCD0B017F3CAB84A07EE855A9A9241DA",
    originalBytes: 1193, originalSha256: "1424FE01364DF9495EFDF9F9EA6A7D98E3A0071D98CE1EAE3FF98544F871625A",
    documentRecordId: "NOE-P02-KO-T07-U29-TGT-DOCUMENT-002",
    repairRecordId: "NOE-P02-KO-T07-U29-TGT-TEX-REPAIR-001",
    repairStructureType: "display_math", repairLineStart: 24, repairLineEnd: 31,
    repairFragment: "\\]",
    originalDocumentRecordId: "NOE-P02-KO-T07-U29-TGT-DOCUMENT-001",
    originalAffectedRecordIds: ["NOE-P02-KO-T07-U29-TGT-DISPLAY-003", "NOE-P02-KO-T07-U29-TGT-PARAGRAPH-002"],
    sourceAffectedRecordIds: ["NOE-P02-KO-T07-U29-SRC-DISPLAY-003"],
    repairLabel: "U29 checker-confirmed duplicate display-close deletion only",
  },
];
for (const spec of repairSiblingSpecs) {
  spec.targetPath = path.join(projectRoot, "targets", spec.targetName);
  spec.file = await readTextFile(spec.targetPath);
  assert(spec.file.bytes.length === spec.bytes && spec.file.fileSha256 === spec.sha256, `Repair sibling identity changed for ${spec.unit}`);
  const original = units.find((unit) => unit.unit === spec.unit);
  assert(original && original.targetBytes === spec.originalBytes && original.targetSha256 === spec.originalSha256, `Frozen original identity changed for ${spec.unit}`);
}
const repairSiblingByWorkspacePath = new Map(repairSiblingSpecs.map((spec) => [relPath(spec.targetPath), spec.file]));
const checkerAdjudicationIdentity = await fileIdentity(checkerAdjudicationPath);
assert(checkerAdjudicationIdentity.bytes === CHECKER_ADJUDICATION_BYTES && checkerAdjudicationIdentity.sha256 === CHECKER_ADJUDICATION_SHA256, "Checker primary adjudication identity changed");
const checkerAdjudication = JSON.parse(await fs.readFile(checkerAdjudicationPath, "utf8"));
assert(checkerAdjudication.evidence_id === CHECKER_ADJUDICATION_ID && checkerAdjudication.checker_task_id === CHECKER_TASK_ID && checkerAdjudication.performance_mode.includes("no subagent evidence"), "Checker primary adjudication boundary changed");

for (const [tranche, bounds] of Object.entries(trancheBounds)) {
  const slice = lineSlice(authority, bounds[0], bounds[1]);
  assert(Buffer.byteLength(slice, "utf8") === bounds[2], `Tranche LF byte count changed for ${tranche}`);
  assert(sha256(Buffer.from(slice, "utf8")) === bounds[3], `Tranche SHA-256 changed for ${tranche}`);
}

const continuousSlice = lineSlice(authority, 473, 3568);
assert(Buffer.byteLength(continuousSlice, "utf8") === 149508, "Continuous 473--3568 LF byte count changed");
assert(sha256(Buffer.from(continuousSlice, "utf8")) === "D410ECC6B0ABA26400254CEE26867D92F21147BA38D2EDB93C3D7E37AFCEA3BD", "Continuous 473--3568 SHA-256 changed");
const terminalControlSlice = lineSlice(authority, 3569, 3572);
assert(Buffer.byteLength(terminalControlSlice, "utf8") === 28 && sha256(Buffer.from(terminalControlSlice, "utf8")) === "B18FF0CE4073E19DBDAD6E0DDDA1084C09D83162933D356F6D673C926AFFB8F9", "Paper 2 terminal control boundary changed");
const paper3CursorSlice = lineSlice(authority, 3573, 3573);
assert(Buffer.byteLength(paper3CursorSlice, "utf8") === 15 && sha256(Buffer.from(paper3CursorSlice, "utf8")) === "582AD93A86C9F7C48EC6EB5E04BDE2CF073A2AF04BE449E09739C1BD44C38A14", "Paper 3 cursor line changed");

const protectedMetadata = [];
for (const [name, bytes, expectedSha256] of protectedMetadataRows) {
  const fullPath = path.join(projectRoot, name);
  const current = await fileIdentity(fullPath);
  assert(current.bytes === bytes && current.sha256 === expectedSha256, `Protected human metadata changed: ${name}`);
  protectedMetadata.push({ name, path_workspace_relative: relPath(fullPath), bytes, sha256: expectedSha256 });
}
const currentHumanMetadataNames = (await fs.readdir(projectRoot, { withFileTypes: true }))
  .filter((entry) => entry.isFile() && /^(?:CHECKER_HANDOFF|SOURCE_CUSTODY|STATUS|TRANSLATION_CHOICES).*\.md$/.test(entry.name))
  .map((entry) => entry.name).sort();
const protectedMetadataNames = protectedMetadataRows.map((row) => row[0]).sort();
assert(canonical(protectedMetadataNames) === canonical(currentHumanMetadataNames), "Completed T01--T32 producer metadata inventory changed during preflight");
const adjacentHumanMetadataNamesAtPreflight = currentHumanMetadataNames.filter((name) => !protectedMetadataNames.includes(name));
const adjacentTargetNamesAtPreflight = (await fs.readdir(path.join(projectRoot, "targets"), { withFileTypes: true }))
  .filter((entry) => {
    if (!entry.isFile()) return false;
    const match = entry.name.match(/^Noether_P02_Korean_T\d+_U(\d+)_UNCHECKED\.tex$/);
    return match && Number(match[1]) > 226;
  })
  .map((entry) => entry.name).sort();

const assignedSourceLines = new Set();
for (const unit of units) for (let line = unit.sourceStart; line <= unit.sourceEnd; line += 1) assignedSourceLines.add(line);
const unassignedSourceLines = [];
for (let line = 473; line <= 3568; line += 1) if (!assignedSourceLines.has(line)) unassignedSourceLines.push(line);
const sourceBoundaryIntervals = [];
for (const line of unassignedSourceLines) {
  const previous = sourceBoundaryIntervals[sourceBoundaryIntervals.length - 1];
  if (previous && previous.end + 1 === line) previous.end = line;
  else sourceBoundaryIntervals.push({ start: line, end: line });
}
for (const interval of sourceBoundaryIntervals) {
  const slice = lineSlice(authority, interval.start, interval.end);
  const nonblank = slice.split("\n").filter((line) => line.trim() !== "");
  interval.classification = nonblank.length === 0 ? "blank_separator" : nonblank.every((line) => /^\s*\\(?:clearpage|setcounter|begingroup|endgroup|thispagestyle|vspace|small|tiny|footnotesize)\b/.test(line)) ? "control_boundary" : "unassigned_boundary";
  interval.lf_utf8_bytes = Buffer.byteLength(slice, "utf8");
  interval.sha256_lf = sha256(Buffer.from(slice, "utf8"));
}
assert(sourceBoundaryIntervals.every((interval) => interval.classification !== "unassigned_boundary"), "A substantive source line is outside the 199 completed unit slices");

function fileLocator(file, side, start, end, fragment = null) {
  const slice = lineSlice(file, start, end);
  return {
    side,
    language: side === "source" ? "de" : "ko-KR",
    path_workspace_relative: relPath(file.fullPath),
    line_basis: side === "source" ? "whole_authority" : "target_file",
    line_start: start,
    line_end: end,
    file_bytes: file.bytes.length,
    file_sha256: file.fileSha256,
    slice_utf8_bytes_lf: Buffer.byteLength(slice, "utf8"),
    slice_sha256_lf: sha256(Buffer.from(slice, "utf8")),
    fragment_kind: fragment ? fragment.kind : null,
    fragment_ordinal: fragment ? fragment.ordinal : null,
    fragment_text: fragment ? fragment.text : null,
    fragment_sha256_utf8: fragment ? sha256(Buffer.from(fragment.text, "utf8")) : null,
    authority_pointer_id: POINTER_ID,
    authority_pointer_sha256: POINTER_SHA256,
  };
}

function locator(unit, side, start, end, fragment = null) {
  const file = side === "source" ? authority : unit.target;
  return fileLocator(file, side, start, end, fragment);
}

const records = [];
const byId = new Map();
const idCounters = new Map();
const siblingCounters = new Map();
let globalOrder = 0;

function typeToken(type) {
  const aliases = {
    source_document: "SRC-DOCUMENT",
    target_document: "TGT-DOCUMENT",
    metadata_header: "METADATA",
    table_heading: "TABLE-HEADING",
    source_boundary: "SOURCE-BOUNDARY",
    chapter_heading: "CHAPTER",
    section_heading: "SECTION",
    theorem_statement: "THEOREM",
    display_math: "DISPLAY",
    table_array: "ARRAY",
    footnote_marker: "FN-MARKER",
    bibliographic_item: "BIB",
    numbered_list_item: "LIST-ITEM",
    symbol_item: "SYMBOL",
    cross_reference: "XREF",
    blank_separator: "BLANK",
    control_line: "CONTROL",
  };
  return aliases[type] || type.toUpperCase().replace(/_/g, "-");
}

function nextRecordId(spec) {
  if (spec.recordId) return spec.recordId;
  const sideToken = spec.side === "source" ? "SRC" : spec.side === "target" ? "TGT" : "AGG";
  const token = typeToken(spec.structureType);
  const key = [spec.trancheId || "ALL", spec.unitId || "ALL", sideToken, token].join("|");
  const next = (idCounters.get(key) || 0) + 1;
  idCounters.set(key, next);
  return [WORK_ID, spec.trancheId, spec.unitId, sideToken, token, String(next).padStart(3, "0")]
    .filter((value) => value && value !== "ALL")
    .join("-");
}

function addRecord(spec) {
  const recordId = nextRecordId(spec);
  assert(!byId.has(recordId), `Duplicate record ID ${recordId}`);
  const parent = spec.parentId ? byId.get(spec.parentId) : null;
  assert(!spec.parentId || parent, `Parent ${spec.parentId} must precede ${recordId}`);
  const siblingKey = spec.parentId || "__ROOT__";
  const siblingOrder = (siblingCounters.get(siblingKey) || 0) + 1;
  siblingCounters.set(siblingKey, siblingOrder);
  globalOrder += 1;
  const record = {
    schema_version: SCHEMA_VERSION,
    record_id: recordId,
    work_id: WORK_ID,
    tranche_id: spec.trancheId || "ALL",
    unit_id: spec.unitId || "ALL",
    side: spec.side,
    language: spec.language,
    structure_type: spec.structureType,
    label: spec.label,
    structural_tag: spec.tag || null,
    parent_id: spec.parentId || null,
    order: globalOrder,
    sibling_order: siblingOrder,
    depth: parent ? parent.depth + 1 : 0,
    coverage_role: spec.coverageRole,
    record_basis: spec.recordBasis || ["computation"],
    locators: spec.locators,
    crossrefs: spec.crossrefs || [],
    completion_state: spec.completionState || COMPLETION_STATE,
    review_state: spec.reviewState || REVIEW_STATE,
    formula_review_state: spec.formulaReviewState || FORMULA_REVIEW_STATE,
    build_state: spec.buildState || BUILD_STATE,
    render_state: spec.renderState || RENDER_STATE,
    publication_state: spec.publicationState || PUBLICATION_STATE,
    continuation_cursor: CURSOR,
    _text: spec.text || "",
    _tag: spec.tag || null,
    _primaryStart: spec.primaryStart || null,
    _primaryEnd: spec.primaryEnd || null,
  };
  records.push(record);
  byId.set(recordId, record);
  return record;
}

function aggregateLocators(scopeUnits) {
  const out = [];
  for (const unit of scopeUnits) {
    out.push(locator(unit, "source", unit.sourceStart, unit.sourceEnd));
    out.push(locator(unit, "target", 1, unit.target.lines.length));
  }
  return out;
}

const workRecord = addRecord({
  recordId: `${WORK_ID}-WORK-001`,
  side: "aggregate", language: "mul", structureType: "work",
  label: "Noether Paper 2 Korean producer evidence freeze T01--T32 / 199 actual units through U226",
  coverageRole: "container", locators: aggregateLocators(units),
});

const sourceBoundaryRecords = [];
for (let index = 0; index < sourceBoundaryIntervals.length; index += 1) {
  const interval = sourceBoundaryIntervals[index];
  sourceBoundaryRecords.push(addRecord({
    recordId: `${WORK_ID}-SRC-SOURCE-BOUNDARY-${String(index + 1).padStart(3, "0")}`,
    side: "source", language: "de", structureType: "source_boundary",
    label: `Unassigned ${interval.classification.replace(/_/g, " ")} lines ${interval.start}--${interval.end}`,
    parentId: workRecord.record_id, coverageRole: "annotation", recordBasis: ["source_fact", "computation"],
    locators: [locator(units[0], "source", interval.start, interval.end)],
    text: lineSlice(authority, interval.start, interval.end),
  }));
}
const terminalControlBoundaryRecord = addRecord({
  recordId: `${WORK_ID}-SRC-SOURCE-BOUNDARY-TERMINAL`,
  side: "source", language: "de", structureType: "source_boundary",
  label: "Excluded Paper 2 terminal controls lines 3569--3572 before Paper 3 cursor",
  parentId: workRecord.record_id, coverageRole: "annotation", recordBasis: ["source_fact", "computation"],
  locators: [locator(units[0], "source", 3569, 3572)], text: terminalControlSlice,
});

const trancheRecords = new Map();
const unitRecords = new Map();
const documentRecords = new Map();
const primaryRecords = new Map();

function documentKey(unitId, side) { return `${unitId}|${side}`; }
function primaryKey(unitId, side) { return `${unitId}|${side}`; }

function lineEntries(unit, side) {
  if (side === "source") {
    const out = [];
    for (let line = unit.sourceStart; line <= unit.sourceEnd; line += 1) {
      out.push({ number: line, text: authority.lines[line - 1] });
    }
    return out;
  }
  return unit.target.lines.map((text, index) => ({ number: index + 1, text }));
}

function findEnvironmentEnd(entries, startIndex, environment) {
  let depth = 0;
  const beginToken = `\\begin{${environment}}`;
  const endToken = `\\end{${environment}}`;
  for (let index = startIndex; index < entries.length; index += 1) {
    const text = entries[index].text;
    depth += text.split(beginToken).length - 1;
    depth -= text.split(endToken).length - 1;
    if (depth === 0) return index;
  }
  throw new Error(`Unclosed ${environment} environment at ${entries[startIndex].number}`);
}

function findDisplay(entries, startIndex) {
  const text = entries[startIndex].text;
  if (/^\s*\\\[\s*$/.test(text)) {
    for (let index = startIndex + 1; index < entries.length; index += 1) {
      if (/^\s*\\\]\s*$/.test(entries[index].text)) return { endIndex: index, environment: "bracket_display" };
    }
    throw new Error(`Unclosed bracket display at ${entries[startIndex].number}`);
  }
  const match = text.match(/^\s*\\begin\{(align\*?|equation\*?|gather\*?|multline\*?)\}/);
  return match ? { endIndex: findEnvironmentEnd(entries, startIndex, match[1]), environment: match[1] } : null;
}

function centerKind(unit, side, entries, startIndex, endIndex) {
  const text = entries.slice(startIndex, endIndex + 1).map((entry) => entry.text).join("\n");
  if (unit.unit === "U01") return "title_block";
  if (/\\begin\{tabular\}/.test(text)) return "table_array";
  if (/TABELLE\s+[IVX]+|표\s*[IVX]+/iu.test(text)) return "table_heading";
  if (/Kapitel|제\s*(?:[IVXLC]+|\d+)\s*장/iu.test(text)) return "chapter_heading";
  return "section_heading";
}

function sectionTag(text) {
  const match = text.match(/(?:§|\\S\\?)\s*\\?\s*(\d+)/);
  return match ? match[1] : null;
}

function isTheorem(text, side) {
  return side === "source"
    ? /^\s*(?:\\noindent)?\\?textbf\{Satz\s+[IVXLC]+/i.test(text) || /^\s*\\emph\{Satz\s+[IVXLC]+/i.test(text)
    : /^\s*(?:\\noindent)?\\?textbf\{정리\s+[IVXLC]+/u.test(text) || /^\s*\\emph\{정리\s+[IVXLC]+/u.test(text);
}

function theoremTag(text) {
  const match = text.match(/(?:Satz|정리)\s+([IVXLC]+)/u);
  return match ? match[1] : null;
}

function isProof(text, side) {
  return side === "source" ? /(?:\\textbf|\\noindent\\textbf)\{Beweis:?}/i.test(text) : /(?:\\textbf|\\noindent\\textbf)\{증명:?\}/u.test(text);
}

function isDefinition(text, side) {
  return side === "source" ? /\\textbf\{Definition:?\}/i.test(text) : /\\textbf\{정의:?\}/u.test(text);
}

function isNote(text, side) {
  return side === "source" ? /^\s*Nachbemerkung[:.]/i.test(text) : /^\s*후기[:.]/u.test(text);
}

function isNumberedItem(text) {
  return /^\s*(?:[0-9]+|[a-d])\)\s+/i.test(text);
}

function isControlLine(text) {
  return /^\s*\\(?:clearpage|setcounter|begingroup|endgroup|noindent|thispagestyle|vspace|small|tiny|footnotesize)\b/.test(text)
    || /^\s*\\(?:begin|end)\{(?:landscape|adjustbox|minipage|tabular)\}/.test(text);
}

function addPrimary(unit, side, parentId, type, start, end, label, entries) {
  const record = addRecord({
    trancheId: unit.tranche, unitId: unit.unit,
    side, language: side === "source" ? "de" : "ko-KR",
    structureType: type, label, parentId, coverageRole: "primary",
    recordBasis: [side === "source" ? "source_fact" : "target_fact", "producer_structural_inference"],
    locators: [locator(unit, side, start, end)],
    text: entries.filter((entry) => entry.number >= start && entry.number <= end).map((entry) => entry.text).join("\n"),
    primaryStart: start, primaryEnd: end,
  });
  primaryRecords.get(primaryKey(unit.unit, side)).push(record);
  return record;
}

function parentPrimary(unit, side, line) {
  const candidates = primaryRecords.get(primaryKey(unit.unit, side)) || [];
  return candidates.find((record) => record._primaryStart <= line && record._primaryEnd >= line) || documentRecords.get(documentKey(unit.unit, side));
}

function addInnerDisplays(unit, side, entries, parent, startIndex, endIndex) {
  for (let index = startIndex; index <= endIndex; index += 1) {
    const display = findDisplay(entries, index);
    if (!display || display.endIndex > endIndex) continue;
    const start = entries[index].number;
    const end = entries[display.endIndex].number;
    const blockEntries = entries.slice(index, display.endIndex + 1);
    const text = blockEntries.map((entry) => entry.text).join("\n");
    const record = addRecord({
      trancheId: unit.tranche, unitId: unit.unit,
      side, language: side === "source" ? "de" : "ko-KR",
      structureType: "display_math", label: `${unit.unit} ${side} embedded display ${start}--${end}`,
      parentId: parent.record_id, coverageRole: "annotation",
      recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
      locators: [locator(unit, side, start, end)], text,
    });
    annotateDisplay(unit, side, blockEntries, record);
    index = display.endIndex;
  }
}

function findArraySpans(entries) {
  const stack = [];
  const spans = [];
  for (const entry of entries) {
    const tokenRegex = /\\(begin|end)\{(array|tabular)\}/g;
    let token;
    while ((token = tokenRegex.exec(entry.text))) {
      if (token[1] === "begin") stack.push({ start: entry.number, environment: token[2] });
      else {
        const open = stack.pop();
        assert(open && open.environment === token[2], `Table/array close without matching open at line ${entry.number}`);
        spans.push({ start: open.start, end: entry.number, environment: token[2] });
      }
    }
  }
  assert(stack.length === 0, `Unclosed table/array beginning at ${stack.map((item) => item.start).join(",")}`);
  return spans.sort((a, b) => a.start - b.start || b.end - a.end);
}

function annotateDisplay(unit, side, entries, displayRecord) {
  const text = entries.map((entry) => entry.text).join("\n");
  const arrayRecords = [];
  for (const span of findArraySpans(entries)) {
    let parent = displayRecord;
    for (const candidate of arrayRecords) {
      if (candidate.span.start <= span.start && candidate.span.end >= span.end) parent = candidate.record;
    }
    const record = addRecord({
      trancheId: unit.tranche, unitId: unit.unit,
      side, language: side === "source" ? "de" : "ko-KR",
      structureType: "table_array", label: `${unit.unit} ${side} TeX ${span.environment} ${span.start}--${span.end}`,
      parentId: parent.record_id, coverageRole: "annotation",
      recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
      locators: [locator(unit, side, span.start, span.end)],
      text: entries.filter((entry) => entry.number >= span.start && entry.number <= span.end).map((entry) => entry.text).join("\n"),
    });
    arrayRecords.push({ span, record });
  }

  const tags = [];
  const tagRegex = /\\tag\{([^}]+)\}|\\srcnumdisplay\{([^}]+)\}/g;
  let tagMatch;
  while ((tagMatch = tagRegex.exec(text))) tags.push((tagMatch[1] || tagMatch[2]).replace(/[().]/g, ""));
  const isPureArray = /\\begin\{array\}/.test(text) && !/[=&] *=|\\tag|\\srcnumdisplay/.test(text);
  if (!isPureArray || tags.length) {
    const tagList = tags.length ? tags : [null];
    for (const tag of tagList) {
      addRecord({
        trancheId: unit.tranche, unitId: unit.unit,
        side, language: side === "source" ? "de" : "ko-KR",
        structureType: "equation", label: tag ? `equation (${tag})` : `${unit.unit} ${side} display equation`,
        parentId: displayRecord.record_id, coverageRole: "annotation",
        recordBasis: [side === "source" ? "source_fact" : "target_fact", "producer_structural_inference"],
        locators: [locator(unit, side, entries[0].number, entries[entries.length - 1].number)],
        text, tag,
      });
    }
  }

  for (const entry of entries) {
    const inlineLabel = entry.text.match(/^\s*\((\d+)\.\)\s*&/);
    if (!inlineLabel || tags.includes(inlineLabel[1])) continue;
    addRecord({
      trancheId: unit.tranche, unitId: unit.unit,
      side, language: side === "source" ? "de" : "ko-KR",
      structureType: "equation", label: `equation (${inlineLabel[1]}.) embedded array row`,
      parentId: displayRecord.record_id, coverageRole: "annotation",
      recordBasis: [side === "source" ? "source_fact" : "target_fact", "producer_structural_inference"],
      locators: [locator(unit, side, entry.number, entry.number, { kind: "embedded_array_equation_label", ordinal: 1, text: entry.text })],
      text: entry.text, tag: inlineLabel[1],
    });
  }

  let symbolOrdinal = 0;
  for (const entry of entries) {
    if (!/&=/.test(entry.text)) continue;
    symbolOrdinal += 1;
    const fragment = entry.text.trim();
    addRecord({
      trancheId: unit.tranche, unitId: unit.unit,
      side, language: side === "source" ? "de" : "ko-KR",
      structureType: "symbol_item", label: `${unit.unit} ${side} left-hand symbol/expression row ${symbolOrdinal}`,
      parentId: displayRecord.record_id, coverageRole: "annotation",
      recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
      locators: [locator(unit, side, entry.number, entry.number, { kind: "left_hand_symbol_or_expression_row", ordinal: symbolOrdinal, text: fragment })],
      text: fragment,
    });
  }
}

function structuralStart(entries, index, side) {
  const text = entries[index].text;
  return text.trim() === "" || /^\s*%/.test(text) || /^\s*\\begin\{center\}/.test(text)
    || Boolean(findDisplay(entries, index)) || isTheorem(text, side) || isProof(text, side)
    || isDefinition(text, side) || isNote(text, side) || isNumberedItem(text) || isControlLine(text);
}

function parseDocument(unit, side, documentId) {
  const entries = lineEntries(unit, side);
  primaryRecords.set(primaryKey(unit.unit, side), []);
  for (let index = 0; index < entries.length;) {
    const entry = entries[index];
    const text = entry.text;
    if (text.trim() === "") {
      addPrimary(unit, side, documentId, "blank_separator", entry.number, entry.number, `${unit.unit} ${side} blank line`, entries);
      index += 1;
      continue;
    }
    if (/^\s*%/.test(text)) {
      let endIndex = index;
      while (endIndex + 1 < entries.length && /^\s*%/.test(entries[endIndex + 1].text)) endIndex += 1;
      addPrimary(unit, side, documentId, "metadata_header", entry.number, entries[endIndex].number, `${unit.unit} target custody header`, entries);
      index = endIndex + 1;
      continue;
    }
    if (/^\s*\\begin\{center\}/.test(text)) {
      const endIndex = findEnvironmentEnd(entries, index, "center");
      const kind = centerKind(unit, side, entries, index, endIndex);
      const block = addPrimary(unit, side, documentId, kind, entry.number, entries[endIndex].number, `${unit.unit} ${side} ${kind.replace(/_/g, " ")}`, entries);
      addInnerDisplays(unit, side, entries, block, index, endIndex);
      if (unit.unit === "U01") {
        const authorEntry = entries.slice(index, endIndex + 1).find((item) => side === "source" ? /Emmy Noether/.test(item.text) : /에미 뇌터/u.test(item.text));
        const publicationEntry = entries.slice(index, endIndex + 1).find((item) => /Journal f\. d\. reine/.test(item.text));
        for (const [role, found] of [["author", authorEntry], ["publication_note", publicationEntry]]) {
          if (!found) continue;
          addRecord({
            trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
            structureType: role, label: `${unit.unit} ${side} ${role.replace(/_/g, " ")}`,
            parentId: block.record_id, coverageRole: "annotation",
            recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
            locators: [locator(unit, side, found.number, found.number)], text: found.text,
          });
        }
      }
      if (kind === "chapter_heading") {
        const sectionEntries = entries.slice(index, endIndex + 1).filter((item) => sectionTag(item.text));
        for (const sectionEntry of sectionEntries) {
          const tag = sectionTag(sectionEntry.text);
          addRecord({
            trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
            structureType: "section_heading", label: `${unit.unit} ${side} section ${tag} heading`,
            parentId: block.record_id, coverageRole: "annotation",
            recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
            locators: [locator(unit, side, sectionEntry.number, sectionEntry.number, { kind: "section_heading_line", ordinal: 1, text: sectionEntry.text })],
            text: sectionEntry.text, tag,
          });
        }
      }
      index = endIndex + 1;
      continue;
    }
    const display = findDisplay(entries, index);
    if (display) {
      const blockEntries = entries.slice(index, display.endIndex + 1);
      const block = addPrimary(unit, side, documentId, "display_math", entry.number, entries[display.endIndex].number, `${unit.unit} ${side} display ${entry.number}--${entries[display.endIndex].number}`, entries);
      annotateDisplay(unit, side, blockEntries, block);
      index = display.endIndex + 1;
      continue;
    }
    if (isTheorem(text, side)) {
      const block = addPrimary(unit, side, documentId, "theorem_statement", entry.number, entry.number, `${unit.unit} ${side} theorem ${theoremTag(text) || "statement"}`, entries);
      block._tag = theoremTag(text);
      addInnerDisplays(unit, side, entries, block, index, index);
      index += 1;
      continue;
    }
    if (isProof(text, side)) {
      let endIndex = index;
      while (endIndex + 1 < entries.length && entries[endIndex + 1].text.trim() !== "" && !isTheorem(entries[endIndex + 1].text, side)) endIndex += 1;
      const block = addPrimary(unit, side, documentId, "proof", entry.number, entries[endIndex].number, `${unit.unit} ${side} proof`, entries);
      addInnerDisplays(unit, side, entries, block, index, endIndex);
      index = endIndex + 1;
      continue;
    }
    if (isDefinition(text, side)) {
      addPrimary(unit, side, documentId, "definition", entry.number, entry.number, `${unit.unit} ${side} definition`, entries);
      index += 1;
      continue;
    }
    if (isNote(text, side)) {
      const block = addPrimary(unit, side, documentId, "note", entry.number, entry.number, `${unit.unit} ${side} after-note`, entries);
      addInnerDisplays(unit, side, entries, block, index, index);
      index += 1;
      continue;
    }
    if (isNumberedItem(text)) {
      addPrimary(unit, side, documentId, "numbered_list_item", entry.number, entry.number, `${unit.unit} ${side} numbered/lettered item`, entries);
      index += 1;
      continue;
    }
    if (isControlLine(text)) {
      addPrimary(unit, side, documentId, "control_line", entry.number, entry.number, `${unit.unit} ${side} TeX control line`, entries);
      index += 1;
      continue;
    }
    let endIndex = index;
    while (endIndex + 1 < entries.length && !structuralStart(entries, endIndex + 1, side)) endIndex += 1;
    addPrimary(unit, side, documentId, "paragraph", entry.number, entries[endIndex].number, `${unit.unit} ${side} paragraph`, entries);
    index = endIndex + 1;
  }
}

for (const tranche of Object.keys(trancheBounds)) {
  const trancheUnits = units.filter((unit) => unit.tranche === tranche);
  const trancheRecord = addRecord({
    recordId: `${WORK_ID}-${tranche}-TRANCHE-001`,
    trancheId: tranche, side: "aggregate", language: "mul", structureType: "tranche",
    label: `${tranche} independent unchecked structural scope`, parentId: workRecord.record_id,
    coverageRole: "container", locators: aggregateLocators(trancheUnits),
  });
  trancheRecords.set(tranche, trancheRecord);
  for (const unit of trancheUnits) {
    const unitRecord = addRecord({
      recordId: `${WORK_ID}-${tranche}-${unit.unit}-UNIT-001`,
      trancheId: tranche, unitId: unit.unit, side: "aggregate", language: "mul", structureType: "unit",
      label: `${tranche}-${unit.unit} closed source/target unit`, parentId: trancheRecord.record_id,
      coverageRole: "container",
      locators: [locator(unit, "source", unit.sourceStart, unit.sourceEnd), locator(unit, "target", 1, unit.target.lines.length)],
    });
    unitRecords.set(unit.unit, unitRecord);
    const sourceDocument = addRecord({
      recordId: `${WORK_ID}-${tranche}-${unit.unit}-SRC-DOCUMENT-001`,
      trancheId: tranche, unitId: unit.unit, side: "source", language: "de", structureType: "source_document",
      label: `${unit.unit} ED0001 authority slice`, parentId: unitRecord.record_id, coverageRole: "container",
      recordBasis: ["source_fact", "computation"], locators: [locator(unit, "source", unit.sourceStart, unit.sourceEnd)],
    });
    documentRecords.set(documentKey(unit.unit, "source"), sourceDocument);
    parseDocument(unit, "source", sourceDocument.record_id);
    const targetDocument = addRecord({
      recordId: `${WORK_ID}-${tranche}-${unit.unit}-TGT-DOCUMENT-001`,
      trancheId: tranche, unitId: unit.unit, side: "target", language: "ko-KR", structureType: "target_document",
      label: `${unit.unit} Korean producer target`, parentId: unitRecord.record_id, coverageRole: "container",
      recordBasis: ["target_fact", "computation"], locators: [locator(unit, "target", 1, unit.target.lines.length)],
    });
    documentRecords.set(documentKey(unit.unit, "target"), targetDocument);
    parseDocument(unit, "target", targetDocument.record_id);
  }
}

const terminalTableMetrics = {};
for (const unitId of ["U225", "U226"]) {
  const unit = units.find((candidate) => candidate.unit === unitId);
  terminalTableMetrics[unitId] = {};
  for (const side of ["source", "target"]) {
    const entries = lineEntries(unit, side);
    const parent = records.find((record) => record.unit_id === unitId && record.side === side && record.structure_type === "table_array");
    assert(parent, `Missing terminal table parent for ${unitId} ${side}`);
    const tableText = entries.map((entry) => entry.text).join("\n");
    const rowEntries = entries.filter((entry) => /&/.test(entry.text) && /\\\\(?:\s*\\hline)?\s*$/.test(entry.text));
    terminalTableMetrics[unitId][side] = {
      table_row_count: rowEntries.length,
      mcell_count: (tableText.match(/\\mcell\{/g) || []).length,
      hline_count: (tableText.match(/\\hline/g) || []).length,
      begin_landscape_count: (tableText.match(/\\begin\{landscape\}/g) || []).length,
      begin_adjustbox_count: (tableText.match(/\\begin\{adjustbox\}/g) || []).length,
      begin_tabular_count: (tableText.match(/\\begin\{tabular\}/g) || []).length,
    };
    for (let index = 0; index < rowEntries.length; index += 1) {
      const entry = rowEntries[index];
      const rowLabel = (entry.text.match(/^\s*([^&]+)&/) || [null, "header"])[1].trim();
      addRecord({
        trancheId: "T32", unitId, side, language: side === "source" ? "de" : "ko-KR",
        structureType: "table_row", label: `${unitId} ${side} terminal table row ${index + 1} (${rowLabel})`,
        parentId: parent.record_id, coverageRole: "annotation", recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
        locators: [locator(unit, side, entry.number, entry.number, { kind: "terminal_table_row", ordinal: index + 1, text: entry.text })],
        text: entry.text, tag: rowLabel,
      });
    }
  }
}

function offsetLine(text, offset, firstLine) {
  let count = 0;
  for (let index = 0; index < offset; index += 1) if (text[index] === "\n") count += 1;
  return firstLine + count;
}

function parseBrace(text, start) {
  assert(text[start] === "{", `Expected brace at offset ${start}`);
  let depth = 0;
  for (let index = start; index < text.length; index += 1) {
    if (text[index] === "{" && text[index - 1] !== "\\") depth += 1;
    else if (text[index] === "}" && text[index - 1] !== "\\") {
      depth -= 1;
      if (depth === 0) return { start, end: index, value: text.slice(start + 1, index) };
    }
  }
  throw new Error(`Unclosed brace at offset ${start}`);
}

function extractMacros(text, names) {
  const results = [];
  const regex = new RegExp(`\\\\(${names.join("|")})(?![A-Za-z])`, "g");
  let match;
  while ((match = regex.exec(text))) {
    const name = match[1];
    const expectedArgs = name === "srcfnmark" ? 1 : 2;
    let cursor = regex.lastIndex;
    const args = [];
    for (let argIndex = 0; argIndex < expectedArgs; argIndex += 1) {
      while (/\s/.test(text[cursor])) cursor += 1;
      const arg = parseBrace(text, cursor);
      args.push(arg.value);
      cursor = arg.end + 1;
    }
    results.push({ name, start: match.index, end: cursor, args, fullText: text.slice(match.index, cursor) });
    regex.lastIndex = cursor;
  }
  return results;
}

const footnoteRecords = [];
for (const unit of units) {
  for (const side of ["source", "target"]) {
    const entries = lineEntries(unit, side);
    const joined = entries.map((entry) => entry.text).join("\n");
    const firstLine = entries[0].number;
    let ordinal = 0;
    for (const macro of extractMacros(joined, ["srcfn", "srcfnmark", "srcfntext"])) {
      ordinal += 1;
      const start = offsetLine(joined, macro.start, firstLine);
      const end = offsetLine(joined, Math.max(macro.start, macro.end - 1), firstLine);
      const parent = parentPrimary(unit, side, start);
      const isMarkerOnly = macro.name === "srcfnmark";
      const record = addRecord({
        trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
        structureType: isMarkerOnly ? "footnote_marker" : "footnote",
        label: `${unit.unit} ${side} ${macro.name} ${ordinal}`,
        parentId: parent.record_id, coverageRole: "annotation",
        recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
        locators: [locator(unit, side, start, end, { kind: macro.name, ordinal, text: macro.fullText })],
        text: macro.fullText,
      });
      footnoteRecords.push(record);
      if (macro.name === "srcfn") {
        const marker = macro.args[0];
        addRecord({
          trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
          structureType: "footnote_marker", label: `${unit.unit} ${side} inline footnote marker ${marker}`,
          parentId: record.record_id, coverageRole: "annotation",
          recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
          locators: [locator(unit, side, start, start, { kind: "footnote_marker_text", ordinal, text: marker })],
          text: marker,
        });
      }
    }

    let displayOrdinal = 0;
    for (const macro of extractMacros(joined, ["srcnumdisplay"])) {
      displayOrdinal += 1;
      const start = offsetLine(joined, macro.start, firstLine);
      const end = offsetLine(joined, Math.max(macro.start, macro.end - 1), firstLine);
      const parent = parentPrimary(unit, side, start);
      const display = addRecord({
        trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
        structureType: "display_math", label: `${unit.unit} ${side} srcnumdisplay ${macro.args[0]}`,
        parentId: parent.record_id, coverageRole: "annotation",
        recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
        locators: [locator(unit, side, start, end, { kind: "srcnumdisplay", ordinal: displayOrdinal, text: macro.fullText })],
        text: macro.fullText, tag: macro.args[0].replace(/[().]/g, ""),
      });
      addRecord({
        trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
        structureType: "equation", label: `equation ${macro.args[0]}`,
        parentId: display.record_id, coverageRole: "annotation",
        recordBasis: [side === "source" ? "source_fact" : "target_fact", "producer_structural_inference"],
        locators: [locator(unit, side, start, end, { kind: "srcnumdisplay", ordinal: displayOrdinal, text: macro.fullText })],
        text: macro.fullText, tag: macro.args[0].replace(/[().]/g, ""),
      });
    }
  }
}

const bibliographySpecs = [
  ["U01", 474, 474, 8, 8, "Sitzungsberichte der phys.-med. Sozietät Erlangen 1907"],
  ["U02", 487, 491, 11, 15, "P. Gordan, Über das volle Formensystem der ternären biquadratischen Form"],
  ["U02", 492, 492, 16, 16, "G. Maisano bibliography item 1"],
  ["U02", 493, 493, 17, 17, "G. Maisano bibliography item 2"],
  ["U02", 494, 494, 18, 18, "E. Pascal, Contributo alla teoria della forma ternaria biquadratica"],
  ["U05", 515, 515, 12, 12, "Clebsch-Lindemann, Vorlesungen über Geometrie"],
  ["U05", 515, 515, 12, 12, "Gordan, Über Büschel von Kegelschnitten"],
  ["U07", 566, 566, 33, 33, "Gordan, Math. Annalen XVII, p. 219"],
  ["U08", 579, 579, 18, 18, "Gordan, Math. Annalen V, p. 104"],
  ["U10", 599, 599, 7, 7, "Clebsch, Über eine Fundamentalaufgabe der Invariantentheorie"],
  ["U14", 693, 699, 8, 14, "Study, Methoden zur Theorie der ternären Formen"],
  ["U14", 702, 702, 17, 17, "Gordan, Über Kombinanten"],
  ["U17", 741, 741, 7, 7, "Gordan, Die Resultante binärer Formen"],
  ["U20", 829, 829, 13, 13, "Gordan-Kerschensteiner, Vorlesungen über Invariantentheorie II"],
  ["U20", 833, 833, 17, 17, "Gordan, Math. Annalen XVII, p. 222"],
  ["U21", 843, 843, 13, 13, "Gordan previously cited work, p. 231"],
  ["U24", 879, 879, 7, 7, "Gordan previously cited work, § 3"],
  ["U27", 939, 939, 18, 18, "Gordan-Kerschensteiner previously cited work, p. 134"],
  ["U34", 1077, 1077, 16, 16, "Gordan-Kerschensteiner previously cited work, p. 92"],
  ["U45", 1290, 1290, 20, 20, "Gordan-Kerschensteiner previously cited work, p. 181"],
];

for (const spec of bibliographySpecs) {
  const unit = units.find((candidate) => candidate.unit === spec[0]);
  for (const side of ["source", "target"]) {
    const start = side === "source" ? spec[1] : spec[3];
    const end = side === "source" ? spec[2] : spec[4];
    const parent = footnoteRecords.find((record) => record.unit_id === unit.unit && record.side === side && record.locators[0].line_start <= start && record.locators[0].line_end >= end)
      || parentPrimary(unit, side, start);
    addRecord({
      trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
      structureType: "bibliographic_item", label: spec[5], parentId: parent.record_id, coverageRole: "annotation",
      recordBasis: [side === "source" ? "source_fact" : "target_fact", "producer_structural_inference"],
      locators: [locator(unit, side, start, end)], text: spec[5],
    });
  }
}

for (const footnote of footnoteRecords.filter((record) => record.structure_type === "footnote")) {
  if (!/(?:Gordan|Clebsch|Hilbert|Study|Maisano|Pascal|Math\.|Annalen|a\.\s*a\.\s*O\.|S\.\s*\d+|쪽|참조|문헌|논문|책)/iu.test(footnote._text)) continue;
  const footnoteLocator = footnote.locators[0];
  const alreadyIndexed = records.some((record) => record.structure_type === "bibliographic_item" && record.unit_id === footnote.unit_id && record.side === footnote.side
    && record.locators.some((loc) => loc.line_start >= footnoteLocator.line_start && loc.line_end <= footnoteLocator.line_end));
  if (alreadyIndexed) continue;
  const unit = units.find((candidate) => candidate.unit === footnote.unit_id);
  addRecord({
    trancheId: unit.tranche, unitId: unit.unit, side: footnote.side, language: footnote.language,
    structureType: "bibliographic_item", label: `${unit.unit} ${footnote.side} citation-bearing footnote cue`,
    parentId: footnote.record_id, coverageRole: "annotation", recordBasis: [footnote.side === "source" ? "source_fact" : "target_fact", "producer_structural_inference"],
    locators: footnote.locators, text: footnote._text,
  });
}

const u28SymbolSpecs = [
  ["f", 947, 947, 9, 9], ["theta", 948, 948, 10, 10], ["K", 950, 950, 12, 12],
  ["j", 951, 951, 13, 13], ["nu", 952, 952, 14, 14],
];
const u28 = units.find((unit) => unit.unit === "U28");
for (const spec of u28SymbolSpecs) {
  for (const side of ["source", "target"]) {
    const start = side === "source" ? spec[1] : spec[3];
    const end = side === "source" ? spec[2] : spec[4];
    const parent = records.find((record) => record.unit_id === "U28" && record.side === side && record.structure_type === "display_math");
    addRecord({
      trancheId: "T06", unitId: "U28", side, language: side === "source" ? "de" : "ko-KR",
      structureType: "symbol_item", label: `U28 ${side} symbol ${spec[0]}`,
      parentId: parent.record_id, coverageRole: "annotation",
      recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
      locators: [locator(u28, side, start, end)], text: spec[0],
    });
  }
}

function addCrossref(record, crossref) {
  if (!record.crossrefs.some((current) => canonical(current) === canonical(crossref))) record.crossrefs.push(crossref);
}

for (const unit of units) {
  const sourceDocument = documentRecords.get(documentKey(unit.unit, "source"));
  const targetDocument = documentRecords.get(documentKey(unit.unit, "target"));
  addCrossref(sourceDocument, {
    kind: "parallel_document", label: `${unit.unit} Korean producer target`, target_record_id: targetDocument.record_id,
    resolution_state: "resolved_mechanically", basis: "closed_unit_identity_only_unchecked",
  });
  addCrossref(targetDocument, {
    kind: "parallel_document", label: `${unit.unit} ED0001 source slice`, target_record_id: sourceDocument.record_id,
    resolution_state: "resolved_mechanically", basis: "closed_unit_identity_only_unchecked",
  });
}

function deriveTag(record) {
  if (record.structural_tag || record._tag) return String(record.structural_tag || record._tag).replace(/[().]/g, "");
  if (record.structure_type === "section_heading") {
    return sectionTag(record._text);
  }
  if (record.structure_type === "theorem_statement") {
    const match = record._text.match(/(?:Satz|정리)\s+([IVXLC]+)/u);
    return match ? match[1] : null;
  }
  return null;
}

const referenceTargets = {
  section: records.filter((record) => record.structure_type === "section_heading" && deriveTag(record)),
  theorem: records.filter((record) => record.structure_type === "theorem_statement" && deriveTag(record)),
  equation: records.filter((record) => record.structure_type === "equation" && deriveTag(record)),
};

function resolveReference(kind, tag, side) {
  const candidates = referenceTargets[kind].filter((record) => record.side === side && deriveTag(record) === tag);
  return candidates.length === 1 ? candidates[0] : null;
}

function collectMatches(text, regex, kind, tagFunction) {
  const out = [];
  let match;
  while ((match = regex.exec(text))) out.push({ start: match.index, text: match[0], kind, tag: tagFunction(match) });
  return out;
}

for (const unit of units) {
  for (const side of ["source", "target"]) {
    const entries = lineEntries(unit, side);
    const joined = entries.map((entry) => entry.text).join("\n");
    const firstLine = entries[0].number;
    const matches = [];
    matches.push(...collectMatches(joined, /§{1,2}\s*\d+[a-z]?|\\S(?:\\S)?\\?\s*\\?\s*\d+[a-z]?/gi, "section", (match) => (match[0].match(/\d+/) || [null])[0]));
    matches.push(...collectMatches(joined, side === "source" ? /Satz\s+[IVXLC]+/g : /정리\s+[IVXLC]+/gu, "theorem", (match) => match[0].match(/[IVXLC]+$/)[0]));
    matches.push(...collectMatches(joined, /\((?:a|I{1,3}|IV|[0-9]{1,2})\.?\)/g, "equation", (match) => match[0].replace(/[().]/g, "")));
    matches.push(...collectMatches(joined, side === "source" ? /S\.\s*\d+\b/g : /\d+쪽/gu, "page", (match) => (match[0].match(/\d+/) || [null])[0]));
    matches.sort((a, b) => a.start - b.start || a.kind.localeCompare(b.kind));
    let ordinal = 0;
    for (const match of matches) {
      const line = offsetLine(joined, match.start, firstLine);
      const parent = parentPrimary(unit, side, line);
      if (parent.structure_type === "section_heading" && match.kind === "section") continue;
      if (parent.structure_type === "theorem_statement" && match.kind === "theorem" && deriveTag(parent) === match.tag) continue;
      const lineText = entries.find((entry) => entry.number === line).text;
      if (match.kind === "equation" && (/\\tag\{/.test(lineText) || /\\srcnumdisplay\{/.test(lineText))) continue;
      ordinal += 1;
      const resolved = match.kind === "page" ? null : resolveReference(match.kind, match.tag, side);
      const record = addRecord({
        trancheId: unit.tranche, unitId: unit.unit, side, language: side === "source" ? "de" : "ko-KR",
        structureType: "cross_reference", label: `${match.kind} reference ${match.text}`,
        parentId: parent.record_id, coverageRole: "annotation",
        recordBasis: [side === "source" ? "source_fact" : "target_fact", "computation"],
        locators: [locator(unit, side, line, line, { kind: `${match.kind}_reference`, ordinal, text: match.text })],
        text: match.text,
        crossrefs: [{
          kind: `${match.kind}_reference`, label: match.text,
          target_record_id: resolved ? resolved.record_id : null,
          resolution_state: resolved ? "resolved_mechanically" : "out_of_scope_or_unresolved",
          basis: resolved ? "same_side_explicit_tag_only_unchecked" : "explicit_reference_has_no_unique_in_scope_target",
        }],
      });
      record._tag = match.tag;
    }
  }
}

const pairableTypes = [
  "title_block", "chapter_heading", "section_heading", "table_heading", "author", "publication_note", "paragraph",
  "theorem_statement", "proof", "definition", "note", "display_math", "equation", "table_array",
  "table_row", "footnote", "footnote_marker", "bibliographic_item", "numbered_list_item", "symbol_item", "cross_reference",
];
for (const unit of units) {
  for (const type of pairableTypes) {
    const source = records.filter((record) => record.unit_id === unit.unit && record.side === "source" && record.structure_type === type);
    const target = records.filter((record) => record.unit_id === unit.unit && record.side === "target" && record.structure_type === type);
    if (source.length !== target.length) continue;
    for (let index = 0; index < source.length; index += 1) {
      addCrossref(source[index], {
        kind: "parallel_structure_occurrence", label: `${unit.unit} target ${type} occurrence ${index + 1}`,
        target_record_id: target[index].record_id, resolution_state: "resolved_mechanically",
        basis: "same_type_equal_count_and_occurrence_within_closed_unit_unchecked",
      });
      addCrossref(target[index], {
        kind: "parallel_structure_occurrence", label: `${unit.unit} source ${type} occurrence ${index + 1}`,
        target_record_id: source[index].record_id, resolution_state: "resolved_mechanically",
        basis: "same_type_equal_count_and_occurrence_within_closed_unit_unchecked",
      });
    }
  }
}

const repairStructuralRecordIds = [];
for (const spec of repairSiblingSpecs) {
  const unitParent = unitRecords.get(spec.unit);
  assert(unitParent, `Missing original unit parent for repair sibling ${spec.unit}`);
  const documentRecord = addRecord({
    recordId: spec.documentRecordId,
    trancheId: spec.tranche, unitId: spec.unit, side: "target", language: "ko-KR",
    structureType: "target_document", label: `${spec.unit} versioned TeX-repair sibling; frozen original retained`,
    parentId: unitParent.record_id, coverageRole: "container",
    recordBasis: ["target_fact", "computation", "external_checker_validation"],
    locators: [fileLocator(spec.file, "target", 1, spec.file.lines.length)],
    crossrefs: [{
      kind: "tex_repair_sibling_of_frozen_original", label: `${spec.unit} frozen producer original`,
      target_record_id: spec.originalDocumentRecordId, resolution_state: "resolved_mechanically",
      basis: `${CHECKER_ADJUDICATION_ID}; target-byte relation only; linguistic/full-build/visual states remain unchecked`,
    }],
    reviewState: TEX_REPAIR_REVIEW_STATE,
    formulaReviewState: TEX_REPAIR_FORMULA_REVIEW_STATE,
    buildState: TEX_REPAIR_BUILD_STATE,
  });
  repairStructuralRecordIds.push(documentRecord.record_id);
  const repairCrossrefs = [
    ...spec.originalAffectedRecordIds.map((recordId) => ({
      kind: "tex_repair_of_frozen_original_structure", label: `${spec.unit} frozen original affected structure`,
      target_record_id: recordId, resolution_state: "resolved_mechanically",
      basis: `${CHECKER_ADJUDICATION_ID}; exact target TeX correction only; original remains immutable`,
    })),
    ...spec.sourceAffectedRecordIds.map((recordId) => ({
      kind: "checker_source_locator", label: `${spec.unit} source structure used by checker`,
      target_record_id: recordId, resolution_state: "resolved_mechanically",
      basis: `${CHECKER_ADJUDICATION_ID}; source locator relation, not German adjudication`,
    })),
  ];
  const repairRecord = addRecord({
    recordId: spec.repairRecordId,
    trancheId: spec.tranche, unitId: spec.unit, side: "target", language: "ko-KR",
    structureType: spec.repairStructureType, label: spec.repairLabel,
    parentId: documentRecord.record_id, coverageRole: "annotation",
    recordBasis: ["target_fact", "computation", "external_checker_validation"],
    locators: [fileLocator(spec.file, "target", spec.repairLineStart, spec.repairLineEnd, {
      kind: "checker_confirmed_tex_repair", ordinal: 1, text: spec.repairFragment,
    })],
    crossrefs: repairCrossrefs,
    reviewState: TEX_REPAIR_REVIEW_STATE,
    formulaReviewState: TEX_REPAIR_FORMULA_REVIEW_STATE,
    buildState: TEX_REPAIR_BUILD_STATE,
  });
  repairStructuralRecordIds.push(repairRecord.record_id);
}

for (const record of records) {
  if (record.structural_tag === null) record.structural_tag = deriveTag(record);
  record.record_sha256 = sha256(Buffer.from(canonical(withoutKey(record, "record_sha256")), "utf8"));
}

const structureTypes = [
  "work", "tranche", "unit", "source_document", "target_document", "metadata_header", "title_block",
  "chapter_heading", "section_heading", "table_heading", "author", "publication_note", "paragraph", "theorem_statement",
  "proof", "definition", "note", "display_math", "equation", "table_array", "footnote", "footnote_marker",
  "table_row", "bibliographic_item", "numbered_list_item", "symbol_item", "cross_reference", "blank_separator", "control_line", "source_boundary", "other",
];

const structuralHeaders = [
  "schema_version", "record_id", "work_id", "tranche_id", "unit_id", "side", "language", "structure_type",
  "label", "structural_tag", "parent_id", "order", "sibling_order", "depth", "coverage_role", "record_basis_json", "locators_json",
  "crossrefs_json", "completion_state", "review_state", "formula_review_state", "build_state", "render_state",
  "publication_state", "continuation_cursor", "record_sha256",
];

const structuralSchema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:interlanguage:noether:p02:ko:structural-index:1.0.0",
  title: "Noether Paper 2 Korean T01--T32 producer structural record",
  description: "Hierarchical, hash-bound structure for ED0001 source slices, 199 frozen unchecked Korean producer targets, and separately versioned checker-confirmed TeX-repair siblings. Primary records partition each frozen source/target physical line once; annotations may overlap. Repair records encode only exact external-checker TeX-syntax evidence and never linguistic, full-build, render, visual, publication, or approval judgment.",
  type: "object",
  required: structuralHeaders.filter((header) => !header.endsWith("_json")).concat(["record_basis", "locators", "crossrefs"]),
  properties: {
    schema_version: { const: SCHEMA_VERSION, description: "Structural schema version." },
    record_id: { type: "string", pattern: "^NOE-P02-KO-[A-Z0-9-]+$", description: "Stable work/tranche/unit/side/type/occurrence identifier." },
    work_id: { const: WORK_ID, description: "Stable Paper 2 Korean work identifier." },
    tranche_id: { enum: ["ALL", ...Object.keys(trancheBounds)], description: "Independent unchecked tranche scope." },
    unit_id: { enum: ["ALL", ...units.map((unit) => unit.unit)], description: "Closed producer unit identifier." },
    side: { enum: ["aggregate", "source", "target"], description: "Aggregate hierarchy, German authority, or Korean target." },
    language: { enum: ["mul", "de", "ko-KR"], description: "BCP-47 language; mul only for aggregate containers." },
    structure_type: { enum: structureTypes, description: "Typed structural role, including every requested prose, heading, theorem/proof, display/equation, array, note, bibliography, list, symbol, and cross-reference class." },
    label: { type: "string", minLength: 1, description: "Non-authoritative structural label." },
    structural_tag: { type: ["string", "null"], description: "Explicit section/theorem/equation tag when mechanically present." },
    parent_id: { type: ["string", "null"], description: "Immediate hierarchy parent; null only for the work root." },
    order: { type: "integer", minimum: 1, description: "Global deterministic creation order." },
    sibling_order: { type: "integer", minimum: 1, description: "One-based order among siblings." },
    depth: { type: "integer", minimum: 0, description: "Hierarchy depth." },
    coverage_role: { enum: ["container", "primary", "annotation"], description: "Primary records partition physical lines; annotations can overlap; containers aggregate." },
    record_basis: { type: "array", minItems: 1, uniqueItems: true, items: { enum: ["source_fact", "target_fact", "computation", "producer_structural_inference", "external_checker_validation"] }, description: "Epistemic basis; external_checker_validation is used only for the two personally adjudicated TeX-repair siblings." },
    locators: { type: "array", minItems: 1, items: { "$ref": "#/$defs/locator" }, description: "Hash-bound line and optional exact-fragment locators." },
    crossrefs: { type: "array", items: { "$ref": "#/$defs/crossref" }, description: "Mechanical parallel or explicit-reference links only." },
    completion_state: { const: COMPLETION_STATE, description: "Evidence indexing state, not review completion." },
    review_state: { enum: [REVIEW_STATE, TEX_REPAIR_REVIEW_STATE], description: "Frozen originals remain unchecked; repair siblings are unchecked linguistically and carry only checker-confirmed TeX-syntax repair evidence." },
    formula_review_state: { enum: [FORMULA_REVIEW_STATE, TEX_REPAIR_FORMULA_REVIEW_STATE], description: "No general formula review; the repair value records only a checker-confirmed delimiter correction." },
    build_state: { enum: [BUILD_STATE, TEX_REPAIR_BUILD_STATE], description: "No producer or full-corpus compilation; the repair value records only the checker's isolated one-page probe." },
    render_state: { const: RENDER_STATE, description: "Targets were not rendered." },
    publication_state: { const: PUBLICATION_STATE, description: "This evidence pass did not publish." },
    continuation_cursor: { const: CURSOR, description: "Paper 3 begins at whole-authority line 3573 after excluded Paper 2 terminal controls 3569--3572." },
    record_sha256: { type: "string", pattern: "^[A-F0-9]{64}$", description: "SHA-256 of canonical record JSON excluding this field and private builder keys." },
  },
  "$defs": {
    locator: {
      type: "object", additionalProperties: false,
      required: ["side", "language", "path_workspace_relative", "line_basis", "line_start", "line_end", "file_bytes", "file_sha256", "slice_utf8_bytes_lf", "slice_sha256_lf", "fragment_kind", "fragment_ordinal", "fragment_text", "fragment_sha256_utf8", "authority_pointer_id", "authority_pointer_sha256"],
      properties: {
        side: { enum: ["source", "target"], description: "Physical side." },
        language: { enum: ["de", "ko-KR"], description: "Locator language." },
        path_workspace_relative: { type: "string", minLength: 1, description: "Forward-slash path relative to workspace root." },
        line_basis: { enum: ["whole_authority", "target_file"], description: "Line coordinate system." },
        line_start: { type: "integer", minimum: 1, description: "Inclusive line start." },
        line_end: { type: "integer", minimum: 1, description: "Inclusive line end." },
        file_bytes: { type: "integer", minimum: 0, description: "Raw file bytes." },
        file_sha256: { type: "string", pattern: "^[A-F0-9]{64}$", description: "Raw file SHA-256." },
        slice_utf8_bytes_lf: { type: "integer", minimum: 1, description: "LF-normalized UTF-8 slice bytes." },
        slice_sha256_lf: { type: "string", pattern: "^[A-F0-9]{64}$", description: "LF-normalized line-slice SHA-256." },
        fragment_kind: { type: ["string", "null"], description: "Optional exact fragment selector class." },
        fragment_ordinal: { type: ["integer", "null"], minimum: 1, description: "One-based fragment occurrence." },
        fragment_text: { type: ["string", "null"], description: "Exact fragment bytes as Unicode text." },
        fragment_sha256_utf8: { type: ["string", "null"], pattern: "^[A-F0-9]{64}$", description: "UTF-8 fragment hash." },
        authority_pointer_id: { const: POINTER_ID, description: "Exact pointer identity." },
        authority_pointer_sha256: { const: POINTER_SHA256, description: "Exact pointer SHA-256." },
      },
    },
    crossref: {
      type: "object", additionalProperties: false,
      required: ["kind", "label", "target_record_id", "resolution_state", "basis"],
      properties: {
        kind: { type: "string", minLength: 1, description: "Parallel, section, theorem, equation, or page link class." },
        label: { type: "string", minLength: 1, description: "Visible reference label." },
        target_record_id: { type: ["string", "null"], description: "Unique in-scope target or null." },
        resolution_state: { enum: ["resolved_mechanically", "out_of_scope_or_unresolved"], description: "Non-semantic mechanical resolution." },
        basis: { type: "string", minLength: 1, description: "Exact non-semantic link basis." },
      },
    },
  },
  additionalProperties: false,
  "x-csv-projection": {
    headers: structuralHeaders,
    nested_json_columns: ["record_basis_json", "locators_json", "crossrefs_json"],
    description: "CSV is a deterministic flat projection; nested values are canonical compact JSON strings.",
  },
};

const structuralDir = path.join(evidenceRoot, "structural_index");
const structuralSchemaPath = path.join(structuralDir, "PRODUCER_STRUCTURAL_INDEX.schema.json");
const structuralJsonlPath = path.join(structuralDir, "PRODUCER_STRUCTURAL_INDEX.jsonl");
const structuralCsvPath = path.join(structuralDir, "PRODUCER_STRUCTURAL_INDEX.csv");
const structuralReportPath = path.join(structuralDir, "PRODUCER_STRUCTURAL_INDEX_VALIDATION_REPORT.json");
await writeJson(structuralSchemaPath, structuralSchema);

const publicRecords = records.map((record) => withoutKey(record, "__never_present__"));
const structuralJsonl = publicRecords.map((record) => JSON.stringify(record)).join("\n") + "\n";
await writeText(structuralJsonlPath, structuralJsonl);
const structuralRows = publicRecords.map((record) => ({
  schema_version: record.schema_version,
  record_id: record.record_id,
  work_id: record.work_id,
  tranche_id: record.tranche_id,
  unit_id: record.unit_id,
  side: record.side,
  language: record.language,
  structure_type: record.structure_type,
  label: record.label,
  structural_tag: record.structural_tag,
  parent_id: record.parent_id,
  order: record.order,
  sibling_order: record.sibling_order,
  depth: record.depth,
  coverage_role: record.coverage_role,
  record_basis_json: canonical(record.record_basis),
  locators_json: canonical(record.locators),
  crossrefs_json: canonical(record.crossrefs),
  completion_state: record.completion_state,
  review_state: record.review_state,
  formula_review_state: record.formula_review_state,
  build_state: record.build_state,
  render_state: record.render_state,
  publication_state: record.publication_state,
  continuation_cursor: record.continuation_cursor,
  record_sha256: record.record_sha256,
}));
const structuralCsv = toCsv(structuralHeaders, structuralRows);
await writeText(structuralCsvPath, structuralCsv);

const structuralErrors = [];
function structuralCheck(condition, message) { if (!condition) structuralErrors.push(message); }
const parsedStructural = normalizeLf(await fs.readFile(structuralJsonlPath, "utf8")).trimEnd().split("\n").filter(Boolean).map(JSON.parse);
structuralCheck(parsedStructural.length === publicRecords.length, "JSONL record count changed after write/read");
structuralCheck(new Set(parsedStructural.map((record) => record.record_id)).size === parsedStructural.length, "Record IDs are not unique");
for (let index = 0; index < parsedStructural.length; index += 1) {
  const record = parsedStructural[index];
  structuralCheck(record.order === index + 1, `Non-contiguous order at ${record.record_id}`);
  structuralCheck(record.record_sha256 === sha256(Buffer.from(canonical(withoutKey(record, "record_sha256")), "utf8")), `Record hash mismatch at ${record.record_id}`);
  if (record.parent_id) {
    const parent = parsedStructural.find((candidate) => candidate.record_id === record.parent_id);
    structuralCheck(Boolean(parent), `Missing parent for ${record.record_id}`);
    if (parent) structuralCheck(parent.order < record.order && parent.depth + 1 === record.depth, `Parent order/depth mismatch at ${record.record_id}`);
  } else structuralCheck(record.record_id === workRecord.record_id, `Unexpected null parent at ${record.record_id}`);
  for (const loc of record.locators) {
    const file = loc.side === "source"
      ? authority
      : units.find((unit) => relPath(unit.targetPath) === loc.path_workspace_relative)?.target || repairSiblingByWorkspacePath.get(loc.path_workspace_relative);
    structuralCheck(Boolean(file), `Locator file not in frozen scope at ${record.record_id}`);
    if (!file) continue;
    structuralCheck(file.bytes.length === loc.file_bytes && file.fileSha256 === loc.file_sha256, `Locator file identity mismatch at ${record.record_id}`);
    const slice = lineSlice(file, loc.line_start, loc.line_end);
    structuralCheck(Buffer.byteLength(slice, "utf8") === loc.slice_utf8_bytes_lf && sha256(Buffer.from(slice, "utf8")) === loc.slice_sha256_lf, `Locator slice mismatch at ${record.record_id}`);
    if (loc.fragment_text !== null) {
      structuralCheck(slice.includes(loc.fragment_text), `Locator fragment is absent from slice at ${record.record_id}`);
      structuralCheck(sha256(Buffer.from(loc.fragment_text, "utf8")) === loc.fragment_sha256_utf8, `Fragment hash mismatch at ${record.record_id}`);
    }
  }
  for (const crossref of record.crossrefs) {
    if (crossref.target_record_id) structuralCheck(parsedStructural.some((candidate) => candidate.record_id === crossref.target_record_id), `Cross-reference target missing at ${record.record_id}`);
  }
}

let sourcePrimaryLines = 0;
let targetPrimaryLines = 0;
let uncoveredPrimaryLines = 0;
let overlappingPrimaryLines = 0;
for (const unit of units) {
  for (const side of ["source", "target"]) {
    const start = side === "source" ? unit.sourceStart : 1;
    const end = side === "source" ? unit.sourceEnd : unit.target.lines.length;
    if (side === "source") sourcePrimaryLines += end - start + 1;
    else targetPrimaryLines += end - start + 1;
    const primary = parsedStructural.filter((record) => record.unit_id === unit.unit && record.side === side && record.coverage_role === "primary");
    for (let line = start; line <= end; line += 1) {
      const count = primary.filter((record) => record.locators.some((loc) => loc.line_start <= line && loc.line_end >= line)).length;
      if (count === 0) uncoveredPrimaryLines += 1;
      if (count > 1) overlappingPrimaryLines += 1;
      structuralCheck(count === 1, `Primary coverage count ${count} for ${unit.unit} ${side} line ${line}`);
    }
  }
}

const parsedStructuralCsv = parseCsv(structuralCsv);
structuralCheck(canonical(parsedStructuralCsv[0]) === canonical(structuralHeaders), "Structural CSV header differs from schema");
structuralCheck(parsedStructuralCsv.length === structuralRows.length + 1, "Structural CSV row count mismatch");
for (let index = 0; index < structuralRows.length; index += 1) {
  const expected = structuralHeaders.map((header) => structuralRows[index][header] === null || structuralRows[index][header] === undefined ? "" : String(structuralRows[index][header]));
  structuralCheck(canonical(parsedStructuralCsv[index + 1]) === canonical(expected), `Structural CSV projection mismatch at row ${index + 2}`);
}

const typeCounts = Object.fromEntries(structureTypes.map((type) => [type, 0]));
for (const record of parsedStructural) typeCounts[record.structure_type] = (typeCounts[record.structure_type] || 0) + 1;
for (const requiredType of ["title_block", "chapter_heading", "section_heading", "table_heading", "paragraph", "theorem_statement", "proof", "definition", "note", "display_math", "equation", "table_array", "table_row", "footnote", "bibliographic_item", "numbered_list_item", "symbol_item", "cross_reference", "source_boundary"]) {
  structuralCheck(typeCounts[requiredType] > 0, `Required structural class has zero records: ${requiredType}`);
}
structuralCheck(parsedStructural.filter((record) => record.structure_type === "unit").length === units.length, `Expected ${units.length} unit containers`);
structuralCheck(parsedStructural.filter((record) => record.structure_type === "tranche").length === Object.keys(trancheBounds).length, `Expected ${Object.keys(trancheBounds).length} tranche containers`);
structuralCheck(parsedStructural.filter((record) => record.structure_type === "target_document" && record.record_id.endsWith("-TGT-DOCUMENT-001")).length === units.length, `Expected ${units.length} frozen original target documents`);
structuralCheck(parsedStructural.filter((record) => record.structure_type === "target_document" && record.record_id.endsWith("-TGT-DOCUMENT-002")).length === repairSiblingSpecs.length, `Expected ${repairSiblingSpecs.length} versioned TeX-repair sibling documents`);
for (const recordId of repairStructuralRecordIds) structuralCheck(parsedStructural.some((record) => record.record_id === recordId), `Missing repair structural record ${recordId}`);
for (const record of parsedStructural.filter((candidate) => repairStructuralRecordIds.includes(candidate.record_id))) {
  structuralCheck(record.review_state === TEX_REPAIR_REVIEW_STATE && record.formula_review_state === TEX_REPAIR_FORMULA_REVIEW_STATE && record.build_state === TEX_REPAIR_BUILD_STATE && record.render_state === RENDER_STATE, `Repair-only status boundary changed at ${record.record_id}`);
}
structuralCheck(parsedStructural.some((record) => record.unit_id === "U02" && record.structure_type === "footnote" && record.locators[0].line_end > record.locators[0].line_start), "U02 nested long footnote was not retained");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U11" && record.structure_type === "table_array"), "U11 rectangular array was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U13" && record.structure_type === "note" && record.locators[0].line_start === (record.side === "source" ? 670 : 7)), "U13 line-670 after-note was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U14" && record.structure_type === "footnote"), "U14 Study footnote was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U18" && record.structure_type === "equation" && deriveTag(record) === "II"), "U18 equation II was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U26" && record.structure_type === "equation" && deriveTag(record) === "1"), "U26 tagged equation 1 was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U27" && record.structure_type === "footnote_marker"), "U27 split footnote marker was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U32" && record.structure_type === "footnote_marker"), "U32 split cyclic-sum footnote marker was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U42" && record.structure_type === "display_math"), "U42 dense §6 derivation display was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U46" && record.structure_type === "chapter_heading"), "U46 Chapter III heading was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U56" && record.structure_type === "equation" && deriveTag(record) === "9"), "U56 equation 9 was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U61" && record.structure_type === "equation" && deriveTag(record) === "10"), "U61 equation 10 was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U66" && record.structure_type === "equation" && deriveTag(record) === "11"), "U66 equation 11 was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U76" && record.structure_type === "footnote_marker"), "U76 formula-13 split footnote marker was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U89" && record.structure_type === "footnote_marker"), "U89 formula-17 split footnote marker was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U125" && record.structure_type === "footnote_marker") && parsedStructural.some((record) => record.unit_id === "U128" && record.structure_type === "footnote"), "T19 cross-unit U125 marker/U128 footnote text was not indexed");
structuralCheck(parsedStructural.some((record) => record.unit_id === "U201" && record.structure_type === "equation" && deriveTag(record) === "32"), "U201 equation 32 was not indexed");
structuralCheck(terminalTableMetrics.U225.target.table_row_count === 23 && terminalTableMetrics.U225.target.mcell_count === 87 && terminalTableMetrics.U225.target.hline_count === 24, "U225 terminal Table I row/cell/grid metrics changed");
structuralCheck(terminalTableMetrics.U226.target.table_row_count === 25 && terminalTableMetrics.U226.target.mcell_count === 104 && terminalTableMetrics.U226.target.hline_count === 26, "U226 terminal Table II row/cell/grid metrics changed");
structuralCheck(parsedStructural.filter((record) => record.structure_type === "table_row" && record.side === "target").length === 48, "Expected 48 target terminal table-row records");
structuralCheck(parsedStructural.filter((record) => record.structure_type === "source_boundary").length === sourceBoundaryIntervals.length + 1, "Source boundary record count mismatch");

const sourceFootnoteMacroCount = units.reduce((sum, unit) => sum + extractMacros(lineEntries(unit, "source").map((entry) => entry.text).join("\n"), ["srcfn", "srcfntext"]).length, 0);
const targetFootnoteMacroCount = units.reduce((sum, unit) => sum + extractMacros(lineEntries(unit, "target").map((entry) => entry.text).join("\n"), ["srcfn", "srcfntext"]).length, 0);
structuralCheck(parsedStructural.filter((record) => record.side === "source" && record.structure_type === "footnote").length === sourceFootnoteMacroCount, "Source footnote count does not reconcile to macros");
structuralCheck(parsedStructural.filter((record) => record.side === "target" && record.structure_type === "footnote").length === targetFootnoteMacroCount, "Target footnote count does not reconcile to macros");

const structuralSchemaIdentity = await fileIdentity(structuralSchemaPath);
const structuralJsonlIdentity = await fileIdentity(structuralJsonlPath);
const structuralCsvIdentity = await fileIdentity(structuralCsvPath);
const builderIdentity = await fileIdentity(scriptPath);
const sideCounts = { aggregate: 0, source: 0, target: 0 };
for (const record of parsedStructural) sideCounts[record.side] += 1;
const sourceUnitHashes = Object.fromEntries(units.map((unit) => [unit.unit, unit.sourceSliceSha256]));
const targetFileHashes = Object.fromEntries(units.map((unit) => [unit.unit, unit.targetSha256]));
const excludedSourceLines = unassignedSourceLines;
const structuralReport = {
  schema_version: SCHEMA_VERSION,
  status: structuralErrors.length === 0 ? "PASS" : "FAIL",
  errors: structuralErrors,
  validator: path.basename(scriptPath),
  builder_sha256: builderIdentity.sha256,
  evidence_date: "2026-08-04",
  scope: {
    tranches: Object.keys(trancheBounds), units: units.map((unit) => unit.unit),
    source_unit_line_count: sourcePrimaryLines, target_file_line_count: targetPrimaryLines,
    primary_line_coverage_uncovered: uncoveredPrimaryLines, primary_line_coverage_overlap: overlappingPrimaryLines,
    source_unassigned_separator_or_control_lines_inside_473_3568: excludedSourceLines,
    source_boundary_intervals: sourceBoundaryIntervals,
    deliberate_unused_unit_ids: deliberateUnitIdGaps,
    deliberate_unused_unit_id_count: deliberateUnitIdGaps.length,
    actual_unit_count: units.length,
    terminal_control_boundary: { line_start: 3569, line_end: 3572, lf_utf8_bytes: 28, sha256_lf: "B18FF0CE4073E19DBDAD6E0DDDA1084C09D83162933D356F6D673C926AFFB8F9" },
    paper3_cursor_line: { line: 3573, lf_utf8_bytes: 15, sha256_lf: "582AD93A86C9F7C48EC6EB5E04BDE2CF073A2AF04BE449E09739C1BD44C38A14" },
    next_cursor: CURSOR,
    adjacent_mutable_target_names_observed_at_preflight: adjacentTargetNamesAtPreflight,
    adjacent_mutable_human_metadata_names_observed_at_preflight: adjacentHumanMetadataNamesAtPreflight,
  },
  record_count: parsedStructural.length,
  unique_record_count: new Set(parsedStructural.map((record) => record.record_id)).size,
  latest_record_id: parsedStructural[parsedStructural.length - 1].record_id,
  side_counts: sideCounts,
  type_counts_including_zero: typeCounts,
  authority: {
    path_workspace_relative: relPath(authorityPath), bytes: AUTHORITY_BYTES, sha256: AUTHORITY_SHA256,
    continuous_interval: "473--3568", continuous_interval_lf_utf8_bytes: 149508,
    continuous_interval_sha256_lf: "D410ECC6B0ABA26400254CEE26867D92F21147BA38D2EDB93C3D7E37AFCEA3BD",
    pointer_id: POINTER_ID, pointer_bytes: POINTER_BYTES, pointer_sha256: POINTER_SHA256,
    producer_pointer_id: PRODUCER_POINTER_ID, producer_pointer_bytes: PRODUCER_POINTER_BYTES, producer_pointer_sha256: PRODUCER_POINTER_SHA256,
    pointer_adoption_note: "Pointer v005 supersedes producer-bound v004 and continues to bind byte-identical ED0001; no target or producer metadata was rewritten.",
  },
  source_unit_hashes_verified: sourceUnitHashes,
  target_file_hashes_verified: targetFileHashes,
  tex_repair_siblings: repairSiblingSpecs.map((spec) => ({
    unit_id: spec.unit, path_workspace_relative: relPath(spec.targetPath), bytes: spec.bytes, sha256: spec.sha256,
    frozen_original_bytes: spec.originalBytes, frozen_original_sha256: spec.originalSha256,
    status: "checker_confirmed_tex_defect_repaired_only; linguistically_unchecked; full_build_not_performed; not_rendered; not_visually_inspected",
    structural_record_ids: [spec.documentRecordId, spec.repairRecordId],
  })),
  checker_primary_adjudication: {
    evidence_id: CHECKER_ADJUDICATION_ID, checker_task_id: CHECKER_TASK_ID, personal_no_subagents: true,
    path_workspace_relative: relPath(checkerAdjudicationPath), bytes: CHECKER_ADJUDICATION_BYTES, sha256: CHECKER_ADJUDICATION_SHA256,
    pointer_id_at_adjudication: checkerAdjudication.authority.pointer_id,
  },
  macro_reconciliation: { source_footnote_text_macros: sourceFootnoteMacroCount, target_footnote_text_macros: targetFootnoteMacroCount },
  terminal_table_metrics: terminalTableMetrics,
  structural_definition: {
    primary_partition: "Every physical line in every scoped source slice and each of the 199 frozen original target files is covered by exactly one primary record; versioned repair siblings are separate containers with bounded repair annotations and do not redefine the protected 199-file partition.",
    overlapping_annotations: "Equations, arrays, footnotes, bibliography items, symbols, and cross-references may overlap their parent primary record and are explicitly labeled annotation.",
    paragraph: "Maximal contiguous top-level nonblank prose lines outside comments, headings, displays, theorem/proof/definition/note starts, numbered items, and TeX control lines.",
    parallel_links: "Only closed-unit identity or equal same-type occurrence parity; all links remain unchecked and non-semantic.",
  },
  schema: { path: path.basename(structuralSchemaPath), ...structuralSchemaIdentity },
  jsonl: { path: path.basename(structuralJsonlPath), ...structuralJsonlIdentity },
  csv: { path: path.basename(structuralCsvPath), ...structuralCsvIdentity },
  review_boundary: "Machine-readable producer evidence plus two exact personally checker-confirmed TeX-syntax repairs. No linguistic approval, German defect, producer/full-corpus compilation, extraction, rendering, visual inspection, assembly, packaging, certification, approval, source/scan adjudication, or SGA operation.",
};
await writeJson(structuralReportPath, structuralReport);
assert(structuralReport.status === "PASS", `Structural validation failed: ${structuralErrors.join("; ")}`);

const difficultyHeaders = [
  "schema_version", "record_id", "recorded_at", "time_precision", "timezone", "append_sequence",
  "previous_record_sha256", "work_id", "tranche_ids_json", "unit_ids_json", "category", "sense_window",
  "symptom", "cause_evidence_json", "attempted_approaches_json", "resolution_state", "resolution",
  "artifact_effect", "related_paths_json", "related_structural_ids_json", "review_state", "publication_state",
  "supersession_state", "revisit_condition", "record_sha256",
];

const difficultySchema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:interlanguage:noether:p02:ko:difficulty-ledger:1.0.0",
  title: "Noether Paper 2 Korean T01--T32 append-only producer difficulty record",
  description: "Hash-chained observed operational failures, source/translation difficulty holds, and explicitly attributed external-checker TeX-defect repair returns. Records are append-only. External-checker repair records authorize only the exact versioned sibling mutation stated there and never imply linguistic, full-build, render, visual, publication, or approval completion.",
  type: "object",
  required: difficultyHeaders.filter((header) => !header.endsWith("_json")).concat(["tranche_ids", "unit_ids", "cause_evidence", "attempted_approaches", "related_paths", "related_structural_ids"]),
  properties: {
    schema_version: { const: SCHEMA_VERSION, description: "Difficulty schema version." },
    record_id: { type: "string", pattern: "^CJK-KO-P02-HARD-[0-9]{3}$", description: "Stable append-only sequence ID." },
    recorded_at: { const: "2026-08-04", description: "Observed event date; no time is invented." },
    time_precision: { const: "day", description: "Timestamp precision." },
    timezone: { const: "Europe/Berlin", description: "Session timezone." },
    append_sequence: { type: "integer", minimum: 1, description: "Contiguous one-based sequence." },
    previous_record_sha256: { type: ["string", "null"], pattern: "^[A-F0-9]{64}$", description: "Predecessor self-hash; null only for sequence 1." },
    work_id: { const: WORK_ID, description: "Stable work ID." },
    tranche_ids: { type: "array", uniqueItems: true, items: { enum: Object.keys(trancheBounds) }, description: "Affected tranches." },
    unit_ids: { type: "array", uniqueItems: true, items: { enum: units.map((unit) => unit.unit) }, description: "Affected units." },
    category: { enum: ["discovery_failure", "delegation_failure", "tooling_failure", "translation_difficulty", "structure_difficulty", "source_compression_risk", "formula_risk", "terminology_trap"], description: "Observed event/difficulty class." },
    sense_window: { type: "string", minLength: 1, description: "Exact local scope." },
    symptom: { type: "string", minLength: 1, description: "Observed failure or hard-part description without defect inference." },
    cause_evidence: { type: "array", minItems: 1, items: { "$ref": "#/$defs/evidence" }, description: "Direct observed/file evidence." },
    attempted_approaches: { type: "array", minItems: 1, items: { "$ref": "#/$defs/attempt" }, description: "Failed, accepted, or held approaches." },
    resolution_state: { enum: ["resolved_operationally", "held_for_independent_check"], description: "Operational resolution or explicit semantic hold." },
    resolution: { type: "string", minLength: 1, description: "What happened next, without overclaim." },
    artifact_effect: { type: "string", minLength: 1, description: "Exact mutation/non-mutation effect." },
    related_paths: { type: "array", uniqueItems: true, items: { type: "string" }, description: "Workspace-relative affected/evidence paths." },
    related_structural_ids: { type: "array", uniqueItems: true, items: { type: "string" }, description: "Existing structural records only." },
    review_state: { enum: ["producer_difficulty_unchecked", "external_checker_tex_defect_confirmed_repaired_only"], description: "Producer-only difficulty state or exact personal external-checker TeX repair state; neither is linguistic/full-build/visual approval." },
    publication_state: { const: PUBLICATION_STATE, description: "No publication action in this pass." },
    supersession_state: { const: "current", description: "Current append-only observation." },
    revisit_condition: { type: "string", minLength: 1, description: "Trigger for a later appended record." },
    record_sha256: { type: "string", pattern: "^[A-F0-9]{64}$", description: "SHA-256 of canonical record excluding this field." },
  },
  "$defs": {
    evidence: {
      type: "object", additionalProperties: false, required: ["kind", "detail", "path_workspace_relative", "sha256"],
      properties: {
        kind: { type: "string", minLength: 1 }, detail: { type: "string", minLength: 1 },
        path_workspace_relative: { type: ["string", "null"] }, sha256: { type: ["string", "null"], pattern: "^[A-F0-9]{64}$" },
      },
    },
    attempt: {
      type: "object", additionalProperties: false, required: ["approach", "outcome", "status"],
      properties: { approach: { type: "string", minLength: 1 }, outcome: { type: "string", minLength: 1 }, status: { enum: ["failed", "accepted", "held"] } },
    },
  },
  additionalProperties: false,
  "x-csv-projection": {
    headers: difficultyHeaders,
    nested_json_columns: ["tranche_ids_json", "unit_ids_json", "cause_evidence_json", "attempted_approaches_json", "related_paths_json", "related_structural_ids_json"],
    description: "CSV is a checked projection of the append-only JSONL chain.",
  },
};

function unitEvidence(unitId, detail) {
  const unit = units.find((candidate) => candidate.unit === unitId);
  return [
    { kind: "source_slice_identity", detail: `${detail}; ED0001 whole lines ${unit.sourceStart}--${unit.sourceEnd}.`, path_workspace_relative: relPath(authorityPath), sha256: unit.sourceSliceSha256 },
    { kind: "target_file_identity", detail: `${detail}; unchanged unchecked Korean producer target.`, path_workspace_relative: relPath(unit.targetPath), sha256: unit.targetSha256 },
  ];
}

function metadataEvidence(name, detail, kind = "producer_checker_handoff") {
  const item = protectedMetadata.find((candidate) => candidate.name === name);
  assert(item, `Missing protected metadata evidence ${name}`);
  return { kind, detail, path_workspace_relative: item.path_workspace_relative, sha256: item.sha256 };
}

function docStructuralIds(unitIds) {
  const out = [];
  for (const unitId of unitIds) {
    out.push(documentRecords.get(documentKey(unitId, "source")).record_id);
    out.push(documentRecords.get(documentKey(unitId, "target")).record_id);
  }
  return out;
}

function unitIdsForTranches(trancheIds) {
  return units.filter((unit) => trancheIds.includes(unit.tranche)).map((unit) => unit.unit);
}

const laterToolingRecords = [
  {
    record_id: "CJK-KO-P02-HARD-027", tranche_ids: ["T15", "T16", "T17", "T18"], unit_ids: unitIdsForTranches(["T15", "T16", "T17", "T18"]), category: "tooling_failure",
    sense_window: "Append of authorized P02 decisions CJK-KO-P02-026--033 to the 769,867-byte lane decision log.",
    symptom: "apply_patch could not locate the expected last-line context although bounded Get-Content and hex inspection showed the exact UTF-8 LF line; large-file/context matching or concurrent-read sensitivity was suspected only, not established.",
    cause_evidence: [{ kind: "observed_apply_patch_failure", detail: "Expected tail context was reported absent while independent bounded text and hex reads showed it present; the failed patch changed no byte.", path_workspace_relative: "03_projects/language_management/cjk/00_lane_control/CJK_DECISION_LOGBOOK_20260718.md", sha256: null }],
    attempted_approaches: [
      { approach: "Append with the original single-line tail context in the very large log.", outcome: "Context match failed; no write.", status: "failed" },
      { approach: "Use a smaller append patch with a unique multi-line tail anchor and verify prefix/tail identities.", outcome: "Authorized decisions were appended by the owning lane without changing target TeX.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The owner used a short unique multi-line tail anchor; cause remains unadjudicated beyond the observed context miss.",
    artifact_effect: "The failed patch changed no log, source, target, metadata, canon, or evidence byte.", related_paths: ["03_projects/language_management/cjk/00_lane_control/CJK_DECISION_LOGBOOK_20260718.md"], related_structural_ids: docStructuralIds(unitIdsForTranches(["T15", "T16", "T17", "T18"])),
    revisit_condition: "For very large append-only logs, use short unique multi-line anchors and verify both preserved prefix and new tail.",
  },
  {
    record_id: "CJK-KO-P02-HARD-028", tranche_ids: ["T19", "T20"], unit_ids: unitIdsForTranches(["T19", "T20"]), category: "tooling_failure",
    sense_window: "Read-only T19/T20 producer-metadata replay across 22 actual targets.",
    symptom: "PowerShell transiently rejected an unbraced variable immediately before `:`.",
    cause_evidence: [{ kind: "observed_parser_error", detail: "Variable/colon adjacency was parsed incorrectly; no filesystem operation executed.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Use the unbraced variable immediately before a colon.", outcome: "Parser error; no writes.", status: "failed" },
      { approach: "Brace the variable in the corrected command.", outcome: "VALIDATION_ERRORS=0 and all 22 target identities replayed.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Braced variable interpolation removed the ambiguity and the read-only replay passed.",
    artifact_effect: "No source, target, producer metadata, log, or evidence input changed.", related_paths: [], related_structural_ids: docStructuralIds(unitIdsForTranches(["T19", "T20"])),
    revisit_condition: "Brace PowerShell variables whenever punctuation, especially `:`, follows immediately.",
  },
  {
    record_id: "CJK-KO-P02-HARD-029", tranche_ids: ["T23"], unit_ids: unitIdsForTranches(["T23"]), category: "tooling_failure",
    sense_window: "Read-only T23/U158--U164 metadata replay helper.",
    symptom: "A helper function named `H` collided with the host history alias, shadowing the intended replay helper.",
    cause_evidence: [{ kind: "observed_alias_collision", detail: "The single-letter helper name resolved against an existing PowerShell alias; no write ran.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Define/use the single-letter helper `H`.", outcome: "History-alias collision; replay did not run as intended.", status: "failed" },
      { approach: "Rename the helper to a task-specific non-alias name.", outcome: "Read-only replay passed.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "A task-specific helper name removed the alias collision.",
    artifact_effect: "No filesystem byte changed.", related_paths: [], related_structural_ids: docStructuralIds(unitIdsForTranches(["T23"])),
    revisit_condition: "Avoid single-letter PowerShell helper names and inspect aliases before defining helpers.",
  },
  {
    record_id: "CJK-KO-P02-HARD-030", tranche_ids: ["T23"], unit_ids: unitIdsForTranches(["T23"]), category: "tooling_failure",
    sense_window: "Read-only T23 filename search on Windows.",
    symptom: "The initial rg invocation used a wildcard path and failed with Windows error 123 (invalid path syntax).",
    cause_evidence: [{ kind: "observed_command_error", detail: "The shell passed an invalid wildcard path to rg; no target was opened for write.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Pass a wildcard-bearing Windows path directly to rg.", outcome: "Error 123; no write.", status: "failed" },
      { approach: "Pass explicit filenames (or let rg apply its own glob semantics).", outcome: "Read-only search passed.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Explicit filenames removed the Windows wildcard-path ambiguity.",
    artifact_effect: "No source, target, metadata, or evidence input changed.", related_paths: [], related_structural_ids: docStructuralIds(unitIdsForTranches(["T23"])),
    revisit_condition: "Use rg --glob or explicit LiteralPath-derived filenames on Windows; do not rely on shell wildcard expansion.",
  },
  {
    record_id: "CJK-KO-P02-HARD-031", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "Read-only filesystem projection during terminal inventory.",
    symptom: "`Sort-Object PSIsContainer -Descending,Name` failed to parse with `Missing argument in parameter list`.",
    cause_evidence: [{ kind: "observed_parser_error", detail: "Mixed shorthand/comma property syntax was rejected before the read-only projection ran.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Use `Sort-Object PSIsContainer -Descending,Name`.", outcome: "Parser failure; no write.", status: "failed" },
      { approach: "Use an unsorted projection or explicit property-expression objects.", outcome: "Read-only inventory proceeded.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The shorthand sort syntax was abandoned; ordering is either omitted or expressed explicitly.",
    artifact_effect: "No filesystem byte changed.", related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Use explicit `Sort-Object -Property` expressions when per-property descending behavior is required.",
  },
  {
    record_id: "CJK-KO-P02-HARD-032", tranche_ids: ["T32"], unit_ids: ["U225", "U226"], category: "tooling_failure",
    sense_window: "Read-only T32 terminal-table metric inventory.",
    symptom: "Direct `foreach($u in 225,226){...} | Format-List` again failed with `ParserError: An empty pipe element is not allowed`.",
    cause_evidence: [{ kind: "observed_parser_recurrence", detail: "Exact direct foreach-to-pipeline cause family already observed in HARD-004 and HARD-016; no writes.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Pipe directly from foreach to Format-List.", outcome: "ParserError before inventory execution.", status: "failed" },
      { approach: "Materialize `$rows=foreach(...){...}; $rows | Format-List`.", outcome: "U225/U226 identities and metrics replayed.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Materializing foreach output again resolved the known host parser limitation.",
    artifact_effect: "No target, metadata, table, or evidence input changed.", related_paths: [], related_structural_ids: docStructuralIds(["U225", "U226"]),
    revisit_condition: "Do not use direct statement-to-pipeline foreach syntax on this host; this recurrence cross-links HARD-004/HARD-016.",
  },
  {
    record_id: "CJK-KO-P02-HARD-033", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "Read-only extraction of the terminal Paper 2 control boundary and Paper 3 cursor.",
    symptom: "PowerShell `-split \"`n\",-1` was mistakenly used as if `-1` preserved a terminal element; it suppressed the intended split and yielded a false 1-byte slice.",
    cause_evidence: [{ kind: "observed_split_semantics_error", detail: "The incorrect split-limit assumption affected only a transient read-only calculation.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Use `-split \"`n\",-1` to preserve a terminal LF element.", outcome: "False 1-byte slice; no write.", status: "failed" },
      { approach: "Use ordinary splitting and account for the terminal LF explicitly.", outcome: "Lines 3569--3572 and line 3573 replayed to their correct byte counts/hashes.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Explicit terminal-LF accounting produced the authoritative boundary identities.",
    artifact_effect: "No source, target, metadata, or cursor file changed.", related_paths: [relPath(authorityPath)], related_structural_ids: [terminalControlBoundaryRecord.record_id],
    revisit_condition: "Avoid negative split-limit assumptions; verify line slices against explicit UTF-8 bytes and hashes.",
  },
  {
    record_id: "CJK-KO-P02-HARD-034", tranche_ids: ["T27"], unit_ids: ["U201"], category: "tooling_failure",
    sense_window: "First full T01--T32 structural-validator run after mechanical scope expansion.",
    symptom: "Builder stopped with exactly `Structural validation failed: U201 equation 32 was not indexed`.",
    cause_evidence: [{ kind: "observed_validation_failure", detail: "The validator expected a tagged equation, but source/target encode `(32.)&` as an embedded array-row label rather than `\\tag`/`\\srcnumdisplay`.", path_workspace_relative: relPath(scriptPath), sha256: null }],
    attempted_approaches: [
      { approach: "Require formula (32) to appear under the existing explicit-tag parser.", outcome: "Validator failed after generated structural sidecars were written; protected inputs were untouched.", status: "failed" },
      { approach: "Index exact leading `(number.)&` array-row labels as equation annotations and rerun the full validator.", outcome: "U201 formula (32) became hash-bound and the builder passed.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The mechanical parser now recognizes embedded array-row equation labels without changing source or target TeX.",
    artifact_effect: "The failed run wrote only replaceable generated structural sidecars under evidence/; it changed no protected input. The passing rerun regenerated those sidecars deterministically.", related_paths: [relPath(scriptPath), relPath(path.join(evidenceRoot, "structural_index", "PRODUCER_STRUCTURAL_INDEX_VALIDATION_REPORT.json"))], related_structural_ids: docStructuralIds(["U201"]),
    revisit_condition: "Retain explicit tests for both TeX tags and embedded array-row labels in later structural parsers.",
  },
];

function metadataNameForTranche(prefix, tranche) {
  const item = protectedMetadata.find((candidate) => candidate.name.startsWith(prefix) && candidate.name.includes(`_${tranche}_`));
  assert(item, `Missing ${prefix} metadata for ${tranche}`);
  return item.name;
}

const extendedRiskSpecs = [
  ["CJK-KO-P02-HARD-035", "T13", "structure_difficulty", "Complete §11 system with arrays, formula tags (12)--(16), long derivations, and minipage panels.", "U76 preserves the exact `\\tag{13.)\\srcfnmark{*)}}` plus detached footnote text; U82/U83 carry minipage-labelled (15)/(16). Bildungsgesetz, a priori, identische Relation, diagonal symmetry, Ansatz, higher symbols/form series, and Kontravariante/Kovariante remain distinct unchecked sense windows."],
  ["CJK-KO-P02-HARD-036", "T14", "formula_risk", "Complete §12 formula/array sequence (17)--(20) and conclusions.", "U89 splits the formula-(17) marker/text; U92/U94/U95 combine arrays, aligned equations, and minipages. The a_sigma^3/a_sigma^2 sequence and §10 A_eta^3 reference, plus Faltung/Überschiebung, zerfallen, Funktionaldeterminante, Produktsatz, Spezialisierung, Polarisation, and Schlußform, require independent review."],
  ["CJK-KO-P02-HARD-037", "T15", "formula_risk", "§13 irreducible arrays and successive reductions through the conclusion.", "U97 contains irreducible arrays; U98--U103 carry reductions, symbol exchange, congruences, and mod scope, including Korean display prose `법`. Sukzessive einmalige Faltung, decomposable/reducer, Symbolvertauschung, duality, Kontravariante, and kontragredient must not be collapsed."],
  ["CJK-KO-P02-HARD-038", "T16", "structure_difficulty", "§14 dense arrays, replacement/reduction identities, and terminal N_l inference.", "U105 holds both dense arrays; U106--U110 carry replacement identities and mod scope; U111 closes with the N_l inference. Faltung, successive single Faltung, Überschiebung, zerfallen/reducibility, Formenreihe, Reduzent, and Funktionaldeterminante remain separate."],
  ["CJK-KO-P02-HARD-039", "T17", "structure_difficulty", "Single-unit §15 contraction system.", "U115 contains the complete order-10 contraction list, arrays A--C, reductions, dual-opposition clause, and conclusion. The whole contraction array is unrendered; Faltung, zerfallen, dualistisch gegenüberstehende Betrachtung, and Schema zur Faltung remain unchecked."],
  ["CJK-KO-P02-HARD-040", "T18", "formula_risk", "§16 order-specific arrays A--H and terminal 117-form exhaustion statement.", "U116/U117 contain cell-sensitive arrays; U118 carries reductions and the declared 117-form/exhaustion conclusion. Faltung, Reduzent, zerfallen, Reduzibilität, and erschöpft must remain distinct, and 117 is an unchecked source count."],
  ["CJK-KO-P02-HARD-041", "T19", "structure_difficulty", "Chapter IV/§17 relative-to-absolute construction with formulas (21)--(24) and cross-unit footnotes.", "U121 begins a marker, U122 supplies text; U125 carries a separate marker and U128 delayed text. U123 has a nested-mod chain, U126 a four-subsystem array. Relative/absolute complete system, Modul/mod, reduction/reducer, Faltung/Überschiebung/Polarisation, Ordnung/Grad, and higher-form ordering remain unchecked."],
  ["CJK-KO-P02-HARD-042", "T20", "formula_risk", "§18 contraction schema, dense order arrays, reductions, and conclusions.", "U135 opens the schema; U137/U138/U139/U141 are dense arrays; U142/U143 are aligned reductions. Irreducible/reducible/reducer/decomposable, Ordnung versus Grad/bidegree, contragredient forms, and Funktionaldeterminante must not be conflated."],
  ["CJK-KO-P02-HARD-043", "T21", "translation_difficulty", "§19 coefficient-order table, reducer relations, and product conclusions.", "U149 is a coefficient-order table; U150 references formula (7.)a; U151 closes product conclusions. Faltung, Formenreihe, Reduzent, zerfallen, adjective kontragredient versus noun Kovariante, full Überschiebung, and the scope of `als Kovariante betrachtet` remain held."],
  ["CJK-KO-P02-HARD-044", "T22", "formula_risk", "§20 irreducible list, omission convention, double reduction, and formulas (25)--(27).", "U154 carries the double-reduction derivation; U155--U157 carry formula arrays/alignment and page-71/mod scope. Faltung versus Überschiebung, Zerfallen, Ansatz, lower forms, Funktionaldeterminante, and mod require independent checking."],
  ["CJK-KO-P02-HARD-045", "T23", "source_compression_risk", "§21 cell-sensitive arrays and formulas (28)--(29).", "U158/U159 contain two arrays; U160/U161 retain literal `§12 C))`; U162 combines formula (28) with the line-2898 `Letzteres` antecedent; U164 has formula (29). Antecedent, punctuation, Folgerungen force, double reduction, form series, reducer, and Funktionaldeterminante are held."],
  ["CJK-KO-P02-HARD-046", "T24", "formula_risk", "§22 arrays A--D, reduction chains, formula (30), and quantified conclusion.", "U170 contains four arrays; U171--U174 contain reducer/double-reduction chains; U175 is aligned formula (30). One-/twofold Faltung versus double reduction, factor/reducer/decomposition/reducibility, corresponding/higher form, Ansatz, and Überschiebung over Funktionaldeterminante remain distinct."],
  ["CJK-KO-P02-HARD-047", "T25", "structure_difficulty", "§23 arrays A--C, reductions, omission-rule footnote, nested formula (31), and conclusion.", "U181 has a `letztere Form` antecedent; U185 combines one-contraction/double-reduction alignment with a source omission-rule footnote; U186 nests array/aligned formula (31). Hats, primes, equivalences, antecedents, and source notation are unchecked."],
  ["CJK-KO-P02-HARD-048", "T26", "formula_risk", "§24 arrays A--D, reductions, two-line E reduction, and one-line conclusion.", "U192--U195 retain (18.)a and glyph/case distinctions: lowercase k versus K, a_l versus L, (KHu)^2 versus `(K_eta(KHu),s,u)^4`, and theta·H versus f·H. `entsprechende Formen` attachment and one contraction must not import double reduction."],
  ["CJK-KO-P02-HARD-049", "T27", "formula_risk", "§25 order-12--15 arrays, double-reduction chain, formula (32), and conclusion.", "U198 has adjustbox-wrapped arrays; U200 an align* chain; U201 embeds (32.) as an array-row label; U204 switches H to H' and quantifies simultaneous decomposable forms. Direct Faltung, double reduction, Zerfallen/reducer/product, and Überschiebung remain held."],
  ["CJK-KO-P02-HARD-050", "T28", "translation_difficulty", "§26 parts 1--2 and ordered I·III/II·III product arrays.", "U211 distinguishes kontragredient/kogredient relative to j and simultaneous I/III exclusion; U212 carries arrays A--F; U213 references (27)c/(29)c. Relative adjectives must remain distinct from later noun Kontravarianten, and product order must not be normalized."],
  ["CJK-KO-P02-HARD-051", "T29", "formula_risk", "§26 part 3A, III·III products, Syzygie relations, and formulas 1--11.", "U216 introduces product ranking and `Relationen ... (Syzygien)`; U217 contains formulas 4--11 with discrepant L_vartheta expressions. The gloss/loan, higher-product ordering, Kontravarianten distinction, and symbolic Ordnung remain unchecked."],
  ["CJK-KO-P02-HARD-052", "T30", "formula_risk", "§26 part 3B relations 1--14, stopping conditions, and reducer families.", "U219/U220 carry relations 1--14; U221 is a tabular a/b stopping-condition block with `polarisierbar` and only-one-new-product scope; U222 closes equivalence/reducer families. Relationen here is not automatically Syzygie; theta/vartheta and nu/nu1 are case-sensitive debts."],
  ["CJK-KO-P02-HARD-053", "T31", "formula_risk", "§26 conclusion and two nine-category count arrays.", "U223/U224 contain brace arrays, modulus attachment, Table I/II references, subsystem counts, and declared total 331. Every count and total must reconcile against T32; relative completeness, mod scope, subsystem labels, and conclusion force remain unvalidated."],
  ["CJK-KO-P02-HARD-054", "T32", "structure_difficulty", "Terminal Tables I--II at lines 3480--3568.", "U225/Table I has rows/columns 0--21, 87 mcell and 24 hline occurrences; U226/Table II has rows 0--23, columns 0--16, 104 mcell and 26 hline occurrences. Every cell/empty cell/coordinate, 331 reconciliation, source-page 90 reference, TABELLE/Horizontalreihe/Vertikalreihe/Grad senses, landscape fit, and legibility remain unchecked and unrendered."],
];

const laterRiskRecords = extendedRiskSpecs.map(([recordId, tranche, category, senseWindow, symptom]) => {
  const trancheUnitIds = unitIdsForTranches([tranche]);
  const checkerName = metadataNameForTranche("CHECKER_HANDOFF", tranche);
  const choicesName = metadataNameForTranche("TRANSLATION_CHOICES", tranche);
  return {
    record_id: recordId, tranche_ids: [tranche], unit_ids: trancheUnitIds, category,
    sense_window: senseWindow, symptom,
    cause_evidence: [
      metadataEvidence(checkerName, `${tranche} exact independent-checker priorities`),
      metadataEvidence(choicesName, `${tranche} producer terminology sense windows and held alternatives`, "producer_translation_choices"),
    ],
    attempted_approaches: [
      { approach: "Freeze every physical source/target line, display, equation label, nested array/table, footnote/marker, symbol/expression row, list item, and explicit cross-reference mechanically.", outcome: "Hash-bound topology and custody identities are queryable without changing producer files.", status: "accepted" },
      { approach: "Infer linguistic, formula, table-cell, count, layout, or source correctness from transcription, hashing, occurrence parity, or metadata.", outcome: "Held for independent checking and separately authorized build/render work.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: `${tranche} remains UNCHECKED, uncompiled, unrendered, unassembled, and uncertified; the risk is indexed without defect inference.`,
    artifact_effect: `Evidence sidecars only; every ${tranche} target and producer metadata file remains byte-identical.`,
    related_paths: [protectedMetadata.find((item) => item.name === checkerName).path_workspace_relative, protectedMetadata.find((item) => item.name === choicesName).path_workspace_relative],
    related_structural_ids: docStructuralIds(trancheUnitIds),
    revisit_condition: "Append only on a stable independent finding, an authority change, or separately authorized build/render evidence.",
  };
});

const postFreezeToolingRecords = [
  {
    record_id: "CJK-KO-P02-HARD-055", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "First dynamically constructed apply_patch attempt for the complete Paper 2 producer-input manifest.",
    symptom: "apply_patch returned exactly `invalid patch: The last line of the patch must be '*** End Patch'`.",
    cause_evidence: [{ kind: "observed_patch_framing_error", detail: "A trailing newline in generated content produced a synthetic `+` line immediately before the patch terminator, so `*** End Patch` was not the final patch line.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Prefix every element from a newline-terminated generated-content split and then append the patch terminator.", outcome: "The terminal empty split element became an extra `+` line; apply_patch rejected the patch before any write.", status: "failed" },
      { approach: "Drop the synthetic terminal empty element before prefixing content lines and assert that `*** End Patch` is the last line.", outcome: "The corrected framing was used for the completed manifest workflow and final evidence was regenerated and validated.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Dynamic patch construction now strips only the synthetic terminal empty element and checks the terminator position before submission.",
    artifact_effect: "The rejected patch performed no filesystem write: no file was created and no source, target, producer metadata, decision log, canon, archive, or evidence byte was mutated.",
    related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "For dynamically generated patches, test terminal-newline handling and require the exact patch terminator to be the final line before calling apply_patch.",
  },
  {
    record_id: "CJK-KO-P02-HARD-056", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "Post-write reporting expression after apply_patch successfully created the complete Paper 2 producer manifest.",
    symptom: "The orchestration reporting expression threw exactly `ReferenceError: TextEncoder is not defined` after manifest creation had succeeded.",
    cause_evidence: [
      { kind: "created_manifest_identity_at_failure", detail: "The successfully created manifest was independently rehashed at 88,676 bytes; the reporting failure occurred afterward.", path_workspace_relative: relPath(path.join(projectRoot, "P02_COMPLETE_UNCHECKED_TRANSLATION_PRODUCER_MANIFEST_20260804.json")), sha256: "7296DB8911F3A02C1D671FF8F602B42A832FD50FE145C77872A2AFB15438D9B9" },
      { kind: "observed_runtime_error", detail: "The V8 orchestration isolate did not expose Web TextEncoder to that reporting expression; this records the observed expression failure, not a general claim about every runtime.", path_workspace_relative: null, sha256: null },
    ],
    attempted_approaches: [
      { approach: "Derive the manifest byte count in the orchestration result with Web `TextEncoder` after apply_patch returned success.", outcome: "The reporting expression threw `ReferenceError: TextEncoder is not defined`; the already-created manifest remained intact.", status: "failed" },
      { approach: "Derive bytes and SHA-256 from a read-only filesystem rehash of the created file.", outcome: "Readback confirmed 88,676 bytes and SHA-256 `7296DB8911F3A02C1D671FF8F602B42A832FD50FE145C77872A2AFB15438D9B9`.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Post-write reporting now uses filesystem identity output; orchestration code must not assume Web TextEncoder exists in the V8 isolate.",
    artifact_effect: "Manifest creation itself succeeded. The later reporting exception changed no target, source, producer metadata, decision log, canon, or archive byte; the manifest was not mutated during evidence recording.",
    related_paths: [relPath(path.join(projectRoot, "P02_COMPLETE_UNCHECKED_TRANSLATION_PRODUCER_MANIFEST_20260804.json"))], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Use a read-only filesystem rehash for post-write byte/hash reporting in future orchestration and record runtime-specific globals only after explicit capability checks.",
  },
  {
    record_id: "CJK-KO-P02-HARD-057", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "First orchestration source for the intended v002 complete Paper 2 producer manifest, before any nested tool call.",
    symptom: "The orchestration source failed to parse with exactly `SyntaxError: Unexpected identifier 't'`.",
    cause_evidence: [{ kind: "observed_outer_parser_error", detail: "Unescaped PowerShell backtick strings (`\"`t\"` / `\"`n\"`) were embedded inside a JavaScript template literal, so the outer source became invalid before execution.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Embed PowerShell tab/newline backtick syntax directly inside a JavaScript template literal.", outcome: "The outer orchestration parser stopped at identifier `t`; no nested tool call began.", status: "failed" },
      { approach: "Avoid nested backtick syntaxes entirely; express PowerShell separators as `[char]9` / `[char]10` or use separately quoted strings.", outcome: "Adopted as the parser-safe construction rule for any later v002 attempt.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Future orchestration must not nest PowerShell backtick escapes inside JavaScript template literals; use `[char]9`, `[char]10`, or separate quoting layers.",
    artifact_effect: "Parsing failed before any nested tool call. No v002 file was created and no filesystem byte changed; v001, targets, source, producer metadata, decision log, canon, and archive remained untouched.",
    related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Before any later v002 attempt, syntax-check the outer JavaScript and eliminate all nested PowerShell backtick escapes.",
  },
  {
    record_id: "CJK-KO-P02-HARD-058", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "Independent canonicalization check of frozen complete producer manifest v002 and its 344-file payload inventory.",
    symptom: "The checker confirmed a manifest canonicalization-description defect: v002 says the inventory is sorted ordinally, but its 39,113-byte digest `380D3E5BFCBB45A721D335F991340AB81A541994AA28F2911C4F0013C3F29DE6` reproduces manifest/listed invariant-culture order; true .NET ordinal order yields `B825BE5AAEFEE784274AE5171656809AEC7E4AC6803152C26DEA00EDEC1488FD`.",
    cause_evidence: [
      { kind: "frozen_manifest_identity", detail: "Manifest v002 is frozen at 90,122 bytes and contains the inaccurate ordinal canonicalization description plus the listed-order digest.", path_workspace_relative: relPath(path.join(projectRoot, "P02_COMPLETE_UNCHECKED_TRANSLATION_PRODUCER_MANIFEST_v002_20260804.json")), sha256: "C5ADFD7B00C283BACED7C9F2E47E381D37740622F9F2DB5988AFF352D6794D3B" },
      { kind: "independent_inventory_replay", detail: "All 344 payload files / 19,760,565 bytes matched; both projections are 39,113 bytes. Listed order reproduces 380D3E...F29DE6, while `[Array]::Sort(...,[StringComparer]::Ordinal)` yields B825BE...1488FD.", path_workspace_relative: null, sha256: "B825BE5AAEFEE784274AE5171656809AEC7E4AC6803152C26DEA00EDEC1488FD" },
    ],
    attempted_approaches: [
      { approach: "Accept the v002 prose label `ordinally` from the stored digest alone.", outcome: "Independent dual-order recomputation disproved the description while leaving every payload identity valid.", status: "failed" },
      { approach: "Rehash all payloads, reproduce the stored listed-order digest, and compute a separate true .NET ordinal projection with `StringComparer.Ordinal`.", outcome: "344/344 files and 19,760,565 bytes passed; the two exact canonical digests were distinguished without changing v002.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Keep v002 immutable as adverse history. A v003 manifest must describe and compute true .NET ordinal ordering and carry `B825BE5AAEFEE784274AE5171656809AEC7E4AC6803152C26DEA00EDEC1488FD`.",
    artifact_effect: "No v002 or payload byte changed. Targets, source, producer metadata, decision log, canon, archive, and SGA remained untouched; the defect is confined to v002's canonicalization description/digest pairing.",
    related_paths: [relPath(path.join(projectRoot, "P02_COMPLETE_UNCHECKED_TRANSLATION_PRODUCER_MANIFEST_v002_20260804.json"))], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Append the exact v003 identity only after a separately generated manifest proves true ordinal ordering and repeats the 344-file payload replay.",
  },
  {
    record_id: "CJK-KO-P02-HARD-059", tranche_ids: [], unit_ids: [], category: "tooling_failure",
    sense_window: "Read-only canon-receipt rehash after the independent v002 canonicalization check.",
    symptom: "PowerShell rejected exactly `foreach($p in$paths)` because required whitespace around `in` was missing.",
    cause_evidence: [{ kind: "observed_parser_recurrence", detail: "The compact foreach tokenization repeated the known whitespace family before the read-only receipt rehash could execute.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Run the rehash loop as `foreach($p in$paths)`.", outcome: "Parser failure before execution; no identity output and no writes.", status: "failed" },
      { approach: "Retry as `foreach ($p in $paths)` with explicit grammar whitespace.", outcome: "The corrected read-only canon-receipt rehash passed.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The whitespace-corrected foreach form completed the read-only rehash; compact PowerShell loop grammar remains prohibited.",
    artifact_effect: "The failed parse and corrected read-only retry wrote no file and changed no manifest, handoff, target, source, producer metadata, decision log, canon, archive, or SGA byte.",
    related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Keep PowerShell loop grammar visibly spaced and syntax-check repeated receipt-rehash commands before execution.",
  },
];

const postRepairEvidenceRecords = [
  {
    record_id: "CJK-KO-P02-HARD-060", tranche_ids: ["T01", "T07"], unit_ids: ["U02", "U29"], category: "tooling_failure",
    sense_window: "Producer read-only identity validation for the two versioned TeX-repair sibling targets before evidence append.",
    symptom: "PowerShell raised `ParserError: An empty pipe element is not allowed` when a `foreach` block was piped directly; parsing failed before execution.",
    cause_evidence: [{ kind: "observed_read_only_parser_error", detail: "The exact command is unavailable outside tool history and is not reconstructed. The observed cause was direct piping of a foreach block instead of first collecting its output.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Pipe a foreach block directly into a downstream cmdlet; exact command unavailable outside tool history.", outcome: "ParserError `An empty pipe element is not allowed`; failed before execution and wrote zero files.", status: "failed" },
      { approach: "Collect foreach output into an array variable, then pipe the materialized array.", outcome: "Corrected read-only validation passed for both original/sibling byte and SHA-256 identities.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Array materialization replaced the invalid direct-pipe form and the identity check passed without writes.",
    artifact_effect: "Failed parse and corrected validation wrote zero files and changed no source, frozen original, repair sibling, manifest, handoff, metadata, decision log, canon, archive, evidence, Paper 6, or SGA byte.",
    related_paths: repairSiblingSpecs.map((spec) => relPath(spec.targetPath)), related_structural_ids: [workRecord.record_id],
    revisit_condition: "Materialize foreach results before piping and retain the exact no-write boundary in future validation commands.",
  },
  {
    record_id: "CJK-KO-P02-HARD-061", tranche_ids: ["T01", "T07"], unit_ids: ["U02", "U29"], category: "tooling_failure",
    sense_window: "Read-only JavaScript query for the frozen U02/U29 structural records needed by repair cross-references.",
    symptom: "Node.js rejected the first query with exactly `SyntaxError: Unexpected identifier 'console'` because the compact nested filter/for expression was missing valid closing structure.",
    cause_evidence: [{ kind: "observed_node_parser_error", detail: "The one-line query failed in the JavaScript parser before the intended structural JSONL read. The corrected query used an intermediate `rows` array and a braced loop.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Use one compact nested `for (... of a.filter(...)) console.log(...)` expression.", outcome: "Parser stopped at `console`; no script execution, file read, or write occurred.", status: "failed" },
      { approach: "Materialize the filtered records as `rows` and iterate them in a separate braced loop.", outcome: "Read-only query passed and returned the exact original U02/U29 document and affected-structure IDs.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The explicit intermediate-array query completed and its returned IDs were used only in generated evidence cross-references.",
    artifact_effect: "The failed parse wrote zero files. The successful retry was read-only; no source, target, metadata, decision-log, canon, archive, Paper 6, or SGA byte changed.",
    related_paths: [relPath(path.join(evidenceRoot, "structural_index", "PRODUCER_STRUCTURAL_INDEX.jsonl"))], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Prefer explicit intermediate collections and braced loops for bounded JSONL queries; record any recurrence append-only.",
  },
  {
    record_id: "CJK-KO-P02-HARD-062", tranche_ids: ["T01"], unit_ids: ["U02"], category: "formula_risk",
    sense_window: "U02 source ED0001 line 494 and Korean target line 18; frozen original versus versioned TeX-repair sibling.",
    symptom: "Personal checker adjudication confirmed that the frozen target dropped both backslashes around `f=x_1^3x_2+x_2^3x_3+x_3^3x_1`, leaving TeX math tokens outside math mode; the original isolated probe failed at target line 18 with `Missing $ inserted`.",
    cause_evidence: [
      { kind: "external_checker_primary_adjudication", detail: `${CHECKER_ADJUDICATION_ID}; checker task ${CHECKER_TASK_ID}; personal primary comparison and XeLaTeX probes with no subagent evidence.`, path_workspace_relative: relPath(checkerAdjudicationPath), sha256: CHECKER_ADJUDICATION_SHA256 },
      { kind: "source_slice_identity", detail: "ED0001 whole lines 483--496; line 494 contains exact source fragment `\\(f=x_1^3x_2+x_2^3x_3+x_3^3x_1\\)`.", path_workspace_relative: relPath(authorityPath), sha256: "D9660703F6FBF0A3106AEF04FAB4777FCDD07121D402CE0C728E94CC713D7012" },
      { kind: "frozen_original_target", detail: "Immutable producer target, 2,928 bytes; target line 18 lacks both math delimiters.", path_workspace_relative: relPath(units.find((unit) => unit.unit === "U02").targetPath), sha256: "081252F90A544382AE7AAF11FDE4755CE99E5F640AC3F20C0F0CBD3A39D6C2BF" },
      { kind: "producer_owned_repair_sibling", detail: "Versioned sibling, 2,930 bytes; exact +2-byte correction only.", path_workspace_relative: relPath(repairSiblingSpecs.find((spec) => spec.unit === "U02").targetPath), sha256: "1D39A01D8908BBEBF41BDE6D6A9E691756BE57CC493BFEE59337371FAEEB8BD7" },
      { kind: "checker_original_probe_log", detail: "Original isolated probe exit 1, zero pages, first fatal `Missing $ inserted`.", path_workspace_relative: relPath(path.join(checkerRoot, "build", "redo_unit_probes", "u02_probe.log")), sha256: "DDBCD5E572C713DFD90DE004FE198BA1EE6C5989F4E3F66C43146BD903463EB3" },
      { kind: "checker_candidate_probe_log", detail: "Corrected isolated probe exit 0, one page; not a full build or visual review.", path_workspace_relative: relPath(path.join(checkerRoot, "build", "redo_unit_probes", "u02_candidate_v002_probe.log")), sha256: "0CD4E2D8015C84F1429E4CDCB915980C490AD15D42EF3841259288261D6E86B0" },
      { kind: "checker_candidate_probe_pdf", detail: "One-page probe output retained by checker; visual QA explicitly not performed.", path_workspace_relative: relPath(path.join(checkerRoot, "build", "redo_unit_probes", "u02_candidate_v002_probe.pdf")), sha256: "A5C6C0B3701DB480D78465F9AF212F430615CC3F3DCACEBCC9B550858F00434B" },
    ],
    attempted_approaches: [
      { approach: "Keep the formula-body underscores/exponents outside math mode because their token text otherwise matches source.", outcome: "Rejected by personal checker comparison and failing original probe.", status: "failed" },
      { approach: "Create a producer-owned sibling replacing only the bare parentheses with `\\(` and `\\)` while retaining the frozen original.", outcome: "Exact sibling matches the checker candidate and its isolated probe exits 0 with one page.", status: "accepted" },
      { approach: "Treat the isolated TeX repair as linguistic, formula-semantic, full-build, extraction, render, or visual approval.", outcome: "Held; every such gate remains open.", status: "held" },
    ],
    resolution_state: "resolved_operationally", resolution: "The confirmed delimiter omission is repaired only in the versioned sibling; the frozen original remains immutable. U02 remains linguistically UNCHECKED and lacks full-build/render/visual approval.",
    artifact_effect: "One preexisting producer-owned sibling is indexed at 2,930 bytes / 1D39A0...8BD7. No original, source, manifest v001/v002/v003, handoff, top metadata, canon, archive, Paper 6, or SGA byte was changed by this evidence append.",
    related_paths: [relPath(checkerAdjudicationPath), relPath(units.find((unit) => unit.unit === "U02").targetPath), relPath(repairSiblingSpecs.find((spec) => spec.unit === "U02").targetPath)],
    related_structural_ids: ["NOE-P02-KO-T01-U02-TGT-DOCUMENT-001", "NOE-P02-KO-T01-U02-TGT-PARAGRAPH-003", "NOE-P02-KO-T01-U02-SRC-PARAGRAPH-003", "NOE-P02-KO-T01-U02-TGT-DOCUMENT-002", "NOE-P02-KO-T01-U02-TGT-TEX-REPAIR-001"],
    review_state: "external_checker_tex_defect_confirmed_repaired_only",
    revisit_condition: "Revisit only on the persistent checker's sequential Korean/formula return or authorized full-build, extraction, render, and every-page visual evidence; never promote the isolated probe to approval.",
  },
  {
    record_id: "CJK-KO-P02-HARD-063", tranche_ids: ["T07"], unit_ids: ["U29"], category: "formula_risk",
    sense_window: "U29 source ED0001 line 981 and Korean target lines 31--32; frozen original versus versioned TeX-repair sibling.",
    symptom: "Personal checker adjudication confirmed three display opens versus four closes in the frozen target: lines 31 and 32 duplicated exact `\\]`; the original isolated probe failed at target line 32 with `Bad math environment delimiter`.",
    cause_evidence: [
      { kind: "external_checker_primary_adjudication", detail: `${CHECKER_ADJUDICATION_ID}; checker task ${CHECKER_TASK_ID}; personal primary comparison and XeLaTeX probes with no subagent evidence.`, path_workspace_relative: relPath(checkerAdjudicationPath), sha256: CHECKER_ADJUDICATION_SHA256 },
      { kind: "source_slice_identity", detail: "ED0001 whole lines 957--981; source has three display opens and three closes and ends with one exact `\\]`.", path_workspace_relative: relPath(authorityPath), sha256: "D1896603195874E5D1C3B7C1B828193A07AC5ABB954927516208F9BAC7C196A0" },
      { kind: "frozen_original_target", detail: "Immutable producer target, 1,193 bytes; lines 31 and 32 duplicate the display close.", path_workspace_relative: relPath(units.find((unit) => unit.unit === "U29").targetPath), sha256: "1424FE01364DF9495EFDF9F9EA6A7D98E3A0071D98CE1EAE3FF98544F871625A" },
      { kind: "producer_owned_repair_sibling", detail: "Versioned sibling, 1,190 bytes; exact deletion of final duplicate `\\]<LF>` only.", path_workspace_relative: relPath(repairSiblingSpecs.find((spec) => spec.unit === "U29").targetPath), sha256: "B380060629B2733D4460DBB583DD2866DCD0B017F3CAB84A07EE855A9A9241DA" },
      { kind: "checker_original_probe_log", detail: "Original isolated probe exit 1, zero pages, first fatal `Bad math environment delimiter`.", path_workspace_relative: relPath(path.join(checkerRoot, "build", "redo_unit_probes", "u29_probe.log")), sha256: "9BC143D35D7B85625F4F39AA9A51D310108DB3AF118886855F6BB68967CB9F80" },
      { kind: "checker_candidate_probe_log", detail: "Corrected isolated probe exit 0, one page; not a full build or visual review.", path_workspace_relative: relPath(path.join(checkerRoot, "build", "redo_unit_probes", "u29_candidate_v002_probe.log")), sha256: "5211E679DA25A69EF02B0E00F938F1F8F4EC04D04C3E109418F68697D17BF338" },
      { kind: "checker_candidate_probe_pdf", detail: "One-page probe output retained by checker; visual QA explicitly not performed.", path_workspace_relative: relPath(path.join(checkerRoot, "build", "redo_unit_probes", "u29_candidate_v002_probe.pdf")), sha256: "5A769266E5E95BA13734EF9A59D300456D60C4B77E605FA0D09AE82214F46042" },
    ],
    attempted_approaches: [
      { approach: "Retain both identical terminal display closes because formula bodies otherwise match source structure.", outcome: "Rejected by personal checker delimiter counts and failing original probe.", status: "failed" },
      { approach: "Create a producer-owned sibling deleting only target line 32, the final duplicate `\\]<LF>` suffix, while retaining the frozen original.", outcome: "Exact sibling matches the checker candidate and its isolated probe exits 0 with one page.", status: "accepted" },
      { approach: "Treat the isolated TeX repair as linguistic, formula-semantic, full-build, extraction, render, or visual approval.", outcome: "Held; every such gate remains open.", status: "held" },
    ],
    resolution_state: "resolved_operationally", resolution: "The confirmed duplicate display close is removed only in the versioned sibling; the frozen original remains immutable. U29 remains linguistically UNCHECKED and lacks full-build/render/visual approval.",
    artifact_effect: "One preexisting producer-owned sibling is indexed at 1,190 bytes / B38006...1DA. No original, source, manifest v001/v002/v003, handoff, top metadata, canon, archive, Paper 6, or SGA byte was changed by this evidence append.",
    related_paths: [relPath(checkerAdjudicationPath), relPath(units.find((unit) => unit.unit === "U29").targetPath), relPath(repairSiblingSpecs.find((spec) => spec.unit === "U29").targetPath)],
    related_structural_ids: ["NOE-P02-KO-T07-U29-TGT-DOCUMENT-001", "NOE-P02-KO-T07-U29-TGT-DISPLAY-003", "NOE-P02-KO-T07-U29-TGT-PARAGRAPH-002", "NOE-P02-KO-T07-U29-SRC-DISPLAY-003", "NOE-P02-KO-T07-U29-TGT-DOCUMENT-002", "NOE-P02-KO-T07-U29-TGT-TEX-REPAIR-001"],
    review_state: "external_checker_tex_defect_confirmed_repaired_only",
    revisit_condition: "Revisit only on the persistent checker's sequential Korean/formula return or authorized full-build, extraction, render, and every-page visual evidence; never promote the isolated probe to approval.",
  },
];

const difficultyRecords = [
  {
    record_id: "CJK-KO-P02-HARD-001", tranche_ids: [], unit_ids: [], category: "discovery_failure",
    sense_window: "Initial live-file discovery before any Paper 2 Korean target write.",
    symptom: "The initial broad Paper 2 filename regex lacked a post-2 numeric boundary and falsely matched Paper 26 and higher-numbered names; a corrected boundary-aware search found no pre-existing P02 Korean file.",
    cause_evidence: [
      { kind: "observed_false_positive_family", detail: "Matches beginning with Paper2 were not restricted after the digit 2, so Paper26+ entered the candidate set.", path_workspace_relative: null, sha256: null },
      { kind: "observed_corrected_search_result", detail: "The post-2 boundary-aware retry returned no P02 Korean file at that historical pre-write point.", path_workspace_relative: null, sha256: null },
    ],
    attempted_approaches: [
      { approach: "Search for Paper 2 with a broad filename pattern lacking a post-2 boundary.", outcome: "False positives from Paper 26 and higher-numbered works.", status: "failed" },
      { approach: "Repeat discovery with an explicit post-2 numeric boundary.", outcome: "No pre-existing P02 Korean file found at that point; local production could proceed without collision evidence.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The bounded retry replaced the false-positive candidate set; this was a discovery correction, not a claim about later-created files.",
    artifact_effect: "Both searches were read-only and occurred before any P02 target write.", related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Append if a future collision scan reproduces the missing-boundary failure or discovers a genuine conflicting P02 claim.",
  },
  {
    record_id: "CJK-KO-P02-HARD-002", tranche_ids: [], unit_ids: [], category: "delegation_failure",
    sense_window: "Attempted producer subtask delegation before any P02 target write.",
    symptom: "spawn_agent returned exactly 'agent thread limit reached'.",
    cause_evidence: [{ kind: "observed_tool_return", detail: "The delegation attempt returned 'agent thread limit reached' before any target write.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Delegate a bounded P02 producer subtask with spawn_agent.", outcome: "agent thread limit reached; no child work began.", status: "failed" },
      { approach: "Keep the target write boundary closed while seeking an existing-agent route.", outcome: "No target mutation occurred.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The failed delegation was abandoned without target mutation and work remained local.",
    artifact_effect: "No P02 source, target, metadata, decision log, or evidence file was written by the failed call.", related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Append only if agent capacity becomes a recurring constraint or a later delegation actually starts work.",
  },
  {
    record_id: "CJK-KO-P02-HARD-003", tranche_ids: [], unit_ids: [], category: "delegation_failure",
    sense_window: "Fallback attempt to route the same pre-write producer subtask to an existing agent.",
    symptom: "followup_task also returned exactly 'agent thread limit reached'.",
    cause_evidence: [{ kind: "observed_tool_return", detail: "The follow-up routing attempt returned 'agent thread limit reached' before any target write.", path_workspace_relative: null, sha256: null }],
    attempted_approaches: [
      { approach: "Route the bounded task with followup_task after spawn_agent failed.", outcome: "agent thread limit reached; no remote target write began.", status: "failed" },
      { approach: "Continue the scoped work locally.", outcome: "Local production continued while preserving the no-collision and no-parallel-write boundary.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Work continued locally after both delegation paths failed.",
    artifact_effect: "No P02 source, target, metadata, or decision-log byte was changed by the failed routing call.", related_paths: [], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Append if another delegation path is tried or a concurrency conflict is later observed.",
  },
  {
    record_id: "CJK-KO-P02-HARD-004", tranche_ids: ["T06"], unit_ids: ["U26", "U27", "U28"], category: "tooling_failure",
    sense_window: "Read-only T06 source-hash computation during the evidence inventory.",
    symptom: "PowerShell rejected direct `foreach (...) { ... } | Format-Table` with `ParserError: An empty pipe element is not allowed`.",
    cause_evidence: [
      { kind: "observed_parser_error", detail: "The pipeline operator followed a foreach statement directly; parsing stopped with 'An empty pipe element is not allowed'.", path_workspace_relative: null, sha256: null },
      { kind: "artifact_effect_observation", detail: "The failure happened in a read-only hash command and caused no file mutation.", path_workspace_relative: null, sha256: null },
    ],
    attempted_approaches: [
      { approach: "Pipe directly from `foreach (...) { ... }` to `Format-Table`.", outcome: "ParserError before execution; no identity output.", status: "failed" },
      { approach: "Assign `$rows = foreach (...) {...}; $rows | Format-Table`.", outcome: "Successful retry returned T05/T06/continuous hashes without mutation.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The foreach output was materialized in `$rows` before piping; the corrected read-only command succeeded.",
    artifact_effect: "The failed parse and successful retry changed no source, target, metadata, decision log, or evidence input.", related_paths: [], related_structural_ids: docStructuralIds(["U26", "U27", "U28"]),
    revisit_condition: "Append if direct statement-to-pipeline syntax recurs in this host.",
  },
  {
    record_id: "CJK-KO-P02-HARD-005", tranche_ids: ["T01"], unit_ids: ["U02"], category: "translation_difficulty",
    sense_window: "U02 long introduction footnotes: nested bibliography plus Maisano/Pascal dispute and numerical-error explanation.",
    symptom: "The unit combines four bibliographic items, an embedded display, two distinct linear-dependence claims, cross-references to formulas (13)/(22), and a reported numerical-error explanation inside long footnote scope.",
    cause_evidence: unitEvidence("U02", "Long nested bibliography/dispute footnotes retained exactly"),
    attempted_approaches: [
      { approach: "Preserve bibliography titles, footnote topology, display, and dispute clauses in one unchecked producer unit.", outcome: "Exact structure retained; semantic and historical validation remains open.", status: "accepted" },
      { approach: "Treat fluent preservation as independent verification.", outcome: "Rejected; hashing and structural indexing are not source/Korean/formula review.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "The structure is indexed and the target remains UNCHECKED; the independent checker must adjudicate scope, claims, names, pages, and formula references.",
    artifact_effect: "Evidence sidecars only; U02 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U02").targetPath)], related_structural_ids: docStructuralIds(["U02"]),
    revisit_condition: "Append on a stable independent finding or an authority change.",
  },
  {
    record_id: "CJK-KO-P02-HARD-006", tranche_ids: ["T03"], unit_ids: ["U11"], category: "structure_difficulty",
    sense_window: "U11 rectangular forms-series schema with starred continuation block.",
    symptom: "The large rectangular array contains nested array environments, a star-linked continuation, ellipses, physical rows/columns, and an explanatory footnote; layout preservation is especially vulnerable without a render.",
    cause_evidence: unitEvidence("U11", "Starred rectangular array retained as editable TeX"),
    attempted_approaches: [
      { approach: "Index every display and nested array while retaining the star footnote and source/target hashes.", outcome: "Machine topology recorded without rendering.", status: "accepted" },
      { approach: "Infer cell-by-cell correctness from TeX preservation.", outcome: "Held because no formula or visual check exists.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "The array is machine-located but remains unrendered and formula-unchecked.",
    artifact_effect: "Evidence sidecars only; U11 bytes were not changed and no image was created.", related_paths: [relPath(units.find((unit) => unit.unit === "U11").targetPath)], related_structural_ids: docStructuralIds(["U11"]),
    revisit_condition: "Append after independent cell-level formula checking and authorized rendering/visual QA.",
  },
  {
    record_id: "CJK-KO-P02-HARD-007", tranche_ids: ["T03"], unit_ids: ["U13"], category: "source_compression_risk",
    sense_window: "ED0001 whole line 670 compressed parenthetical exception to Satz I.",
    symptom: "Line 670 states that contractions I, II, and IV disappear while III (respectively IV) remains; the compressed parenthetical dependency is difficult, but no source defect was inferred.",
    cause_evidence: unitEvidence("U13", "Compressed exception and diagonal schema retained without adjudication"),
    attempted_approaches: [
      { approach: "Preserve the compressed German dependency in an unchecked Korean producer draft and expose exact line locators.", outcome: "No silent German patch or defect inference.", status: "accepted" },
      { approach: "Normalize the wording based on producer discomfort.", outcome: "Held for a separate source/Korean checker.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "Line 670 is explicitly flagged for independent scope/direction checking; the authority and target remain unchanged.",
    artifact_effect: "Evidence sidecars only; no German or Korean edit.", related_paths: [relPath(units.find((unit) => unit.unit === "U13").targetPath)], related_structural_ids: docStructuralIds(["U13"]),
    revisit_condition: "Append only on a checker finding or canon-owner source decision.",
  },
  {
    record_id: "CJK-KO-P02-HARD-008", tranche_ids: ["T04"], unit_ids: ["U14"], category: "formula_risk",
    sense_window: "U14 §2 Study footnote and Clebsch--Study comparison formula, followed by tagged formula I.",
    symptom: "A section-heading footnote embeds a long comparison formula and omitted-u_x simplification before the main numbered formula (I); footnote/display scope and coefficients require independent checking.",
    cause_evidence: unitEvidence("U14", "Study footnote, embedded formula, and formula I retained"),
    attempted_approaches: [
      { approach: "Index the heading, footnote, embedded display, bibliography item, list items, and formula I separately.", outcome: "Mechanical evidence is queryable.", status: "accepted" },
      { approach: "Treat tag/occurrence parity as formula equivalence.", outcome: "Held; no formula review occurred.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "All structures remain UNCHECKED and unrendered for independent token-by-token review.",
    artifact_effect: "Evidence sidecars only; U14 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U14").targetPath)], related_structural_ids: docStructuralIds(["U14"]),
    revisit_condition: "Append after independent footnote/formula review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-009", tranche_ids: ["T04"], unit_ids: ["U18"], category: "formula_risk",
    sense_window: "U18 multiplication, u_x-power expansion, tagged formula II, primed sum, ellipsis, and coefficient conditions.",
    symptom: "Formula II spans many aligned lines with hats, signs, primed sums, nested indices, an ellipsis, endpoint term, and a coefficient array; exact TeX preservation does not establish correctness.",
    cause_evidence: unitEvidence("U18", "Long formula II and coefficient conditions retained"),
    attempted_approaches: [
      { approach: "Index each display, equation tag II, and nested condition array with hash-bound locators.", outcome: "Mechanical topology retained.", status: "accepted" },
      { approach: "Certify signs, hats, sums, or ranges from the producer index.", outcome: "Held for independent formula checking.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "Formula II remains editable, uncompiled, unrendered, and formula-unchecked.",
    artifact_effect: "Evidence sidecars only; U18 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U18").targetPath)], related_structural_ids: docStructuralIds(["U18"]),
    revisit_condition: "Append after token-by-token independent formula review and, if authorized, render inspection.",
  },
  {
    record_id: "CJK-KO-P02-HARD-010", tranche_ids: ["T01", "T04", "T05", "T06"], unit_ids: ["U03", "U17", "U21", "U23", "U27"], category: "terminology_trap",
    sense_window: "Classical invariant-theory Überschiebung/Polaren versus Clebsch Übertragungsprinzip across the current Paper 2 scope.",
    symptom: "German Überschiebung and Übertragungsprinzip attract overlapping Korean transfer language but denote distinct operation/principle windows; the producer uses 전이연산 versus 전이 원리 provisionally.",
    cause_evidence: [
      ...unitEvidence("U03", "Introduction uses Überschiebung"),
      ...unitEvidence("U17", "§2 uses Übertragungsprinzip"),
      ...unitEvidence("U21", "Proof uses Polaren (Überschiebungen)"),
      ...unitEvidence("U23", "Reduction method uses Polaren (Überschiebungen)"),
      ...unitEvidence("U27", "Satz III uses Clebschsches Übertragungsprinzip"),
    ],
    attempted_approaches: [
      { approach: "Maintain separate provisional Korean surfaces and one cross-unit checker trap record.", outcome: "The distinction remains visible across all current occurrences.", status: "accepted" },
      { approach: "Normalize both German terms to one Korean word because of shared transfer semantics.", outcome: "Held; lexical attraction is not specialist evidence.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "The distinction is preserved provisionally and awaits Korean specialist evidence; no terminology certification is claimed.",
    artifact_effect: "Evidence sidecars only; no target or decision-log wording changed.", related_paths: ["03_projects/language_management/cjk/03_working_translations/noether_paper02_ko_translation_001_20260804/TRANSLATION_CHOICES_INTRO_T01_T02.md", "03_projects/language_management/cjk/03_working_translations/noether_paper02_ko_translation_001_20260804/TRANSLATION_CHOICES_T04_SECTION2.md"], related_structural_ids: docStructuralIds(["U03", "U17", "U21", "U23", "U27"]),
    revisit_condition: "Append on Korean specialist evidence or an independent terminology finding; do not conflate automatically.",
  },
  {
    record_id: "CJK-KO-P02-HARD-011", tranche_ids: ["T05"], unit_ids: ["U21"], category: "formula_risk",
    sense_window: "U21 theorem II with a long example footnote, two embedded displays, zero underbrace, and proof dependency.",
    symptom: "The theorem statement opens a multi-line example footnote containing two displays and a zero underbrace before the proof; theorem/footnote/display scope is mechanically complex.",
    cause_evidence: unitEvidence("U21", "Theorem II example footnote and proof retained"),
    attempted_approaches: [
      { approach: "Index theorem, footnote, both displays, equation records, bibliography cue, and proof independently.", outcome: "Mechanical boundaries recorded without semantic judgment.", status: "accepted" },
      { approach: "Infer reduction validity from preserved TeX.", outcome: "Held for independent theorem/formula checking.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "U21 remains UNCHECKED, uncompiled, and unrendered.",
    artifact_effect: "Evidence sidecars only; U21 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U21").targetPath)], related_structural_ids: docStructuralIds(["U21"]),
    revisit_condition: "Append after independent theorem, footnote, and formula review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-012", tranche_ids: ["T05"], unit_ids: ["U23"], category: "translation_difficulty",
    sense_window: "U23 second reduction method with product identity and dependent a/b/c branch conditions.",
    symptom: "The unit distinguishes decomposable forms, nonlinear products, first/second polars, one/two contractions, and three dependent branch conditions with distant section references.",
    cause_evidence: unitEvidence("U23", "Reduction method and a/b/c dependency structure retained"),
    attempted_approaches: [
      { approach: "Keep each numbered/lettered item, display, paragraph, and cross-reference separately indexed.", outcome: "Dependency topology exposed for checking.", status: "accepted" },
      { approach: "Collapse repeated transfer/contraction vocabulary for fluency.", outcome: "Held because operation counts and dependency direction matter.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "U23 is structurally indexed but semantically unchecked.",
    artifact_effect: "Evidence sidecars only; U23 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U23").targetPath)], related_structural_ids: docStructuralIds(["U23"]),
    revisit_condition: "Append on independent dependency/terminology findings.",
  },
  {
    record_id: "CJK-KO-P02-HARD-013", tranche_ids: ["T06"], unit_ids: ["U26"], category: "formula_risk",
    sense_window: "U26 chapter/section double heading and cubic-form footnote with three displays and tagged equation (1).",
    symptom: "One center environment contains both chapter II and §4 headings; the following footnote embeds a displayed IV formula, gathered definitions, and a tagged aligned brace system.",
    cause_evidence: unitEvidence("U26", "Double heading and cubic-form footnote formulas retained"),
    attempted_approaches: [
      { approach: "Index chapter and section separately, then index the footnote and each embedded display/equation.", outcome: "Mechanical topology retained.", status: "accepted" },
      { approach: "Treat the tagged brace system as reviewed because its tag is located.", outcome: "Held; formula semantics and rendering remain unchecked.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "U26 remains UNCHECKED with no compile/render evidence.",
    artifact_effect: "Evidence sidecars only; U26 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U26").targetPath)], related_structural_ids: docStructuralIds(["U26"]),
    revisit_condition: "Append after independent formula/heading-scope review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-014", tranche_ids: ["T06"], unit_ids: ["U27"], category: "structure_difficulty",
    sense_window: "U27 theorem III/proof with clearpage and split srcfnmark/srcfntext footnote topology.",
    symptom: "The proof display carries a footnote marker while its footnote text is emitted separately on the next line, between two displayed relations; marker/text pairing and theorem scope are vulnerable to assembly errors.",
    cause_evidence: unitEvidence("U27", "Split footnote marker/text and theorem III proof retained"),
    attempted_approaches: [
      { approach: "Index clearpage, theorem, proof, both displays, footnote marker, footnote text, and bibliography item independently.", outcome: "The split topology is queryable without compiling.", status: "accepted" },
      { approach: "Assume assembly placement from the source macros alone.", outcome: "Held because no compilation or render occurred.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "U27 remains UNCHECKED, uncompiled, and unrendered.",
    artifact_effect: "Evidence sidecars only; U27 bytes were not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U27").targetPath)], related_structural_ids: docStructuralIds(["U27"]),
    revisit_condition: "Append after authorized assembly/build and independent theorem/footnote review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-015", tranche_ids: ["T07", "T08", "T09", "T10", "T11"], unit_ids: ["U29", "U30", "U31", "U32", "U33", "U34", "U35", "U36", "U37", "U38", "U39", "U40", "U41", "U42", "U43", "U44", "U45", "U46", "U47", "U48", "U49", "U50", "U51", "U52", "U53", "U54", "U55", "U56"], category: "tooling_failure",
    sense_window: "First evidence-builder execution while the producer was extending the live Paper 2 root beyond the earlier T01--T06 baseline.",
    symptom: "Builder exited 1 at preflight with exactly `Error: Producer human-metadata inventory changed; refresh the protected baseline before freezing evidence`.",
    cause_evidence: [{ kind: "observed_preflight_abort", detail: "The protected producer metadata inventory changed during the live scope race; the builder stopped before its first generated JSONL/CSV write.", path_workspace_relative: relPath(scriptPath), sha256: null }],
    attempted_approaches: [
      { approach: "Run the builder against the earlier protected inventory while producer metadata was still arriving.", outcome: "Preflight abort before generated evidence write.", status: "failed" },
      { approach: "Keep all target/producer files untouched, obtain explicit scope extension, refresh only the builder's read-only identity baseline through T12/U66, and retain this abort as append-only evidence.", outcome: "Freeze boundary became explicit; no adverse byte was overwritten or hidden.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "The failed run was preserved as HARD-015 and the evidence builder was re-scoped only after explicit authorization through T12/U66.",
    artifact_effect: "The failed execution wrote no generated JSONL/CSV and changed no authority, pointer, target, producer metadata, or decision-log byte.", related_paths: [relPath(scriptPath)], related_structural_ids: [workRecord.record_id],
    revisit_condition: "Append if another live-scope race reaches a protected preflight or if any supposedly frozen input identity changes.",
  },
  {
    record_id: "CJK-KO-P02-HARD-016", tranche_ids: ["T12"], unit_ids: ["U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U66"], category: "tooling_failure",
    sense_window: "Read-only post-T12 inventory and pointer-v005 adoption check at the line-1653 evidence cursor.",
    symptom: "A second direct PowerShell `foreach(...) { ... } | Format-List` attempt produced `ParserError: An empty pipe element is not allowed`.",
    cause_evidence: [
      { kind: "observed_parser_error", detail: "Same direct statement-to-pipeline parser cause family as HARD-004, now recurring after T12.", path_workspace_relative: null, sha256: null },
      { kind: "authority_pointer_identity", detail: "Pointer v005 was adopted only after verifying that it supersedes v004 and binds unchanged ED0001.", path_workspace_relative: relPath(pointerPath), sha256: POINTER_SHA256 },
    ],
    attempted_approaches: [
      { approach: "Pipe directly from `foreach(...) { ... }` to `Format-List`.", outcome: "ParserError before the read-only inventory executed.", status: "failed" },
      { approach: "Assign `$prows=foreach(...){...}; $prows | Format-List`.", outcome: "Successful retry returned the read-only inventory and pointer identities.", status: "accepted" },
    ],
    resolution_state: "resolved_operationally", resolution: "Materializing foreach output before formatting again resolved the recurring host parser limitation.",
    artifact_effect: "Neither the failed parse nor retry changed authority, pointer, target, producer metadata, decision log, or adjacent T13 work.", related_paths: [relPath(pointerPath), relPath(producerPointerPath)], related_structural_ids: docStructuralIds(["U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U66"]),
    revisit_condition: "Treat direct foreach-to-pipeline syntax as unsupported on this host; append if the same cause recurs despite materialization.",
  },
  {
    record_id: "CJK-KO-P02-HARD-017", tranche_ids: ["T07"], unit_ids: ["U29", "U30", "U31", "U32", "U33", "U34", "U35", "U36", "U37"], category: "formula_risk",
    sense_window: "Complete §5 reduction argument, inherited cubic forms, equation systems, reductions, large arrays, and enumerated replacements.",
    symptom: "The checker handoff requires token-level checking of formulas (2), (IV), and (1), cyclic sums, coefficients, signs, hats, underlines, array cells, congruence modules, and symbol exchanges; producer preservation is not formula validation.",
    cause_evidence: [metadataEvidence("CHECKER_HANDOFF_T07_U29_U37.md", "Exact independent-checker priorities for T07"), ...unitEvidence("U29", "T07 opening reduction"), ...unitEvidence("U37", "T07 terminal reduction")],
    attempted_approaches: [
      { approach: "Index every T07 display, equation, array, list item, footnote, symbol/expression row, and cross-reference with exact source/target identities.", outcome: "Mechanical topology is queryable through the full tranche.", status: "accepted" },
      { approach: "Infer coefficient, sign, or formula correctness from preserved TeX or source/target occurrence parity.", outcome: "Held for independent token-level formula checking and authorized rendering.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T07 remains UNCHECKED, uncompiled, unrendered, and formula-unreviewed.",
    artifact_effect: "Evidence sidecars only; all nine T07 targets remain byte-identical.", related_paths: [protectedMetadata.find((item) => item.name === "CHECKER_HANDOFF_T07_U29_U37.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U29", "U30", "U31", "U32", "U33", "U34", "U35", "U36", "U37"]),
    revisit_condition: "Append after independent formula/array review or an authority change.",
  },
  {
    record_id: "CJK-KO-P02-HARD-018", tranche_ids: ["T07"], unit_ids: ["U32"], category: "structure_difficulty",
    sense_window: "U32 cyclic-sum equation block with a separated srcfnmark/srcfntext explanatory footnote.",
    symptom: "The equation carries a `*)` marker while the cyclic-variable explanation is emitted later with srcfntext; the marker/text relation and sum scope are vulnerable without assembly/render evidence.",
    cause_evidence: unitEvidence("U32", "Split cyclic-sum marker/text topology retained"),
    attempted_approaches: [
      { approach: "Index the display, symbol/expression rows, footnote marker, and later footnote text independently.", outcome: "The split topology is mechanically exposed.", status: "accepted" },
      { approach: "Assume rendered placement or equation scope from macro preservation.", outcome: "Held because no compilation or rendering occurred.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "U32 remains structurally indexed but visually and formula unchecked.",
    artifact_effect: "Evidence sidecars only; U32 was not changed.", related_paths: [relPath(units.find((unit) => unit.unit === "U32").targetPath)], related_structural_ids: docStructuralIds(["U32"]),
    revisit_condition: "Append after authorized assembly/render and independent cyclic-sum review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-019", tranche_ids: ["T07"], unit_ids: ["U29", "U30", "U31", "U32", "U33", "U34", "U35", "U36", "U37"], category: "terminology_trap",
    sense_window: "T07 §5 local distinction among Zurückführung, module Reihen, form-series Reihen, physical/tabular Reihen, Faltung, Polarisation, and inherited forms.",
    symptom: "The provisional Korean surface `열` can denote different local structures, while `수축`, `편극`, and classical `전이연산` are related but not interchangeable operations.",
    cause_evidence: [metadataEvidence("TRANSLATION_CHOICES_T07_SECTION5.md", "T07 terminology sense windows and unresolved specialist surfaces", "producer_translation_choices")],
    attempted_approaches: [
      { approach: "Retain distinct local surfaces and attach exact unit/line evidence.", outcome: "Attractor basins remain visible without normalization.", status: "accepted" },
      { approach: "Collapse every Reihe to one structural sense or every related operation to one Korean term.", outcome: "Held because local German scope and operation counts differ.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "The T07 terminology remains provisional and requires specialist Korean checking.",
    artifact_effect: "Evidence sidecars only; no target or terminology decision log was changed.", related_paths: [protectedMetadata.find((item) => item.name === "TRANSLATION_CHOICES_T07_SECTION5.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U29", "U30", "U31", "U32", "U33", "U34", "U35", "U36", "U37"]),
    revisit_condition: "Append on independent specialist evidence; never normalize from surface similarity alone.",
  },
  {
    record_id: "CJK-KO-P02-HARD-020", tranche_ids: ["T08"], unit_ids: ["U38", "U39", "U40", "U41", "U42", "U43", "U44", "U45"], category: "formula_risk",
    sense_window: "Complete §6 reduction, six-form conclusion, detailed series-expansion example, cases 1)--9), afterword, and footnote.",
    symptom: "The checker handoff requires token-level review of formulas (3)/(4), all case labels, coefficients, signs, hats, bracket substitutions, underlines, parameter values, omitted-u_x statement, congruences, and terminal identities.",
    cause_evidence: [metadataEvidence("CHECKER_HANDOFF_T08_U38_U45.md", "Exact independent-checker priorities for T08"), ...unitEvidence("U42", "Dense series-expansion derivation"), ...unitEvidence("U45", "Terminal identities and bibliography footnote")],
    attempted_approaches: [
      { approach: "Index the full derivation, case items, displays, equation tags, symbol/expression rows, note, and footnote.", outcome: "Machine topology and exact identities are frozen.", status: "accepted" },
      { approach: "Treat syntactic preservation as formula or omission verification.", outcome: "Held for independent token-level checking.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T08 remains UNCHECKED and unrendered.",
    artifact_effect: "Evidence sidecars only; all eight T08 targets remain byte-identical.", related_paths: [protectedMetadata.find((item) => item.name === "CHECKER_HANDOFF_T08_U38_U45.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U38", "U39", "U40", "U41", "U42", "U43", "U44", "U45"]),
    revisit_condition: "Append after independent case/formula/footnote checking.",
  },
  {
    record_id: "CJK-KO-P02-HARD-021", tranche_ids: ["T08"], unit_ids: ["U38", "U39", "U40", "U41", "U42", "U43", "U44", "U45"], category: "terminology_trap",
    sense_window: "T08 distinction among Übertragung, Überschiebung, and Clebsch's Übertragungsprinzip, plus Reduzent and form-series ordering.",
    symptom: "Shared transfer attraction does not authorize lexical collapse: provisional `전이`, `전이연산`, and `전이 원리` encode three different local German concepts, while `환원자` is not the reduction formula itself.",
    cause_evidence: [metadataEvidence("TRANSLATION_CHOICES_T08_SECTION6.md", "T08 transfer/reduction terminology sense windows", "producer_translation_choices")],
    attempted_approaches: [
      { approach: "Preserve three separate provisional transfer surfaces and keep Reduzent distinct from Reduktionsformel.", outcome: "Local distinctions remain explicit.", status: "accepted" },
      { approach: "Authorize one term from a cognate surface or neighboring section.", outcome: "Held; no external Korean terminology validation exists.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T08 terminology remains provisional pending specialist evidence.",
    artifact_effect: "Evidence sidecars only; no target or decision log changed.", related_paths: [protectedMetadata.find((item) => item.name === "TRANSLATION_CHOICES_T08_SECTION6.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U38", "U39", "U40", "U41", "U42", "U43", "U44", "U45"]),
    revisit_condition: "Append on independent specialist evidence for all three German terms.",
  },
  {
    record_id: "CJK-KO-P02-HARD-022", tranche_ids: ["T09"], unit_ids: ["U46", "U47", "U48", "U49", "U50", "U51", "U52", "U53"], category: "formula_risk",
    sense_window: "Chapter III/§7 system-I/system-II construction, ordered modules, tabular method I--IV, test forms, afterword, and formulas (5)--(8).",
    symptom: "System membership, coefficients, signs, hats, primes, cyclic sums, zeros, underlines, array cells, and labels must be checked token by token; chapter/system hierarchy is mechanically dense.",
    cause_evidence: [metadataEvidence("CHECKER_HANDOFF_T09_U46_U53.md", "Exact independent-checker priorities for T09"), ...unitEvidence("U46", "Chapter III and §7 opening system"), ...unitEvidence("U53", "Formula (8) conclusion")],
    attempted_approaches: [
      { approach: "Index chapter/section hierarchy, system arrays, formula tags (5)--(8), notes, symbols, and cross-references.", outcome: "The full T09 topology is queryable.", status: "accepted" },
      { approach: "Infer system membership or coefficient correctness from equal structure counts.", outcome: "Held for independent formula checking.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T09 remains UNCHECKED, uncompiled, and unrendered.",
    artifact_effect: "Evidence sidecars only; all eight T09 targets remain byte-identical.", related_paths: [protectedMetadata.find((item) => item.name === "CHECKER_HANDOFF_T09_U46_U53.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U46", "U47", "U48", "U49", "U50", "U51", "U52", "U53"]),
    revisit_condition: "Append after independent system/formula/table review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-023", tranche_ids: ["T09"], unit_ids: ["U46", "U47", "U48", "U49", "U50", "U51", "U52", "U53"], category: "terminology_trap",
    sense_window: "T09 local senses of duality, Grundform, adjungierte/höhere Moduln, Ordnung, Formenreihe, and operation labels.",
    symptom: "`계수차수` must stay coefficient order rather than variable degree; `더 높은 모듈` and `더 높은 형식` belong to different orderings, and Faltung remains distinct from Überschiebung.",
    cause_evidence: [metadataEvidence("TRANSLATION_CHOICES_T09_SECTION7.md", "T09 terminology sense windows", "producer_translation_choices")],
    attempted_approaches: [
      { approach: "Keep each ordered structure and operation label separate in the evidence ledger.", outcome: "The checker trap remains explicit.", status: "accepted" },
      { approach: "Normalize shared higher/order/transfer surfaces without local German scope.", outcome: "Held for specialist review.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T09 terms remain provisional and unchecked.",
    artifact_effect: "Evidence sidecars only; no producer choices were edited.", related_paths: [protectedMetadata.find((item) => item.name === "TRANSLATION_CHOICES_T09_SECTION7.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U46", "U47", "U48", "U49", "U50", "U51", "U52", "U53"]),
    revisit_condition: "Append on independent specialist evidence for Ordnung and the ordered module/form structures.",
  },
  {
    record_id: "CJK-KO-P02-HARD-024", tranche_ids: ["T10", "T11"], unit_ids: ["U54", "U55", "U56"], category: "formula_risk",
    sense_window: "Complete §§8--9 contractions, irreducible-form arrays, three-line double reduction, formula (9), and abbreviated adj. Modul.",
    symptom: "Formula (2), the double reduction, formula (9), every coefficient/sign/hat/prime/underlined term, array cell, and appended-module label require independent checking; abbreviated `adj. Modul` is context-sensitive.",
    cause_evidence: [metadataEvidence("CHECKER_HANDOFF_T10_T11_U54_U56.md", "Exact independent-checker priorities for T10/T11"), ...unitEvidence("U56", "Formula (9) and array conclusion")],
    attempted_approaches: [
      { approach: "Index the two section headings, contractions, arrays, displays, formula (9), and references while retaining `첨가 모듈` as provisional.", outcome: "Exact structure and terminology hold are recorded.", status: "accepted" },
      { approach: "Treat contextual expansion of the abbreviation or formula preservation as approval.", outcome: "Held for independent checking.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T10/T11 remain UNCHECKED and unrendered.",
    artifact_effect: "Evidence sidecars only; U54--U56 remain byte-identical.", related_paths: [protectedMetadata.find((item) => item.name === "CHECKER_HANDOFF_T10_T11_U54_U56.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U54", "U55", "U56"]),
    revisit_condition: "Append after independent formula/array/abbreviation review.",
  },
  {
    record_id: "CJK-KO-P02-HARD-025", tranche_ids: ["T12"], unit_ids: ["U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U66"], category: "formula_risk",
    sense_window: "Complete §10 fifth-coefficient-order system, irreducible arrays, reductions A)--D), derivations, formulas (10)--(11), conclusions, and §11 B forward reference.",
    symptom: "Every coefficient, sign, hat, prime, bracket substitution, underline, congruence module, array cell, and cross-reference requires token-level review; the §11 B reference points into explicitly out-of-scope adjacent work.",
    cause_evidence: [metadataEvidence("CHECKER_HANDOFF_T12_U57_U66.md", "Exact independent-checker priorities for T12"), ...unitEvidence("U57", "§10 opening system and arrays"), ...unitEvidence("U66", "Formula (11) and §11 B forward reference")],
    attempted_approaches: [
      { approach: "Index all T12 displays, equations, nested arrays, A)--D) items, symbols, and cross-references while leaving §11 B unresolved/out of scope.", outcome: "The completed T12 boundary and forward-reference status are explicit.", status: "accepted" },
      { approach: "Treat the forward reference as a reviewed proof or import mutable T13/U67+ structure.", outcome: "Held; T13 starts at line 1653 and is excluded.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T12 remains UNCHECKED, uncompiled, unrendered, and formula-unreviewed; §11 B is unresolved/out of scope.",
    artifact_effect: "Evidence sidecars only; all ten T12 targets and all adjacent T13 files remain untouched.", related_paths: [protectedMetadata.find((item) => item.name === "CHECKER_HANDOFF_T12_U57_U66.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U66"]),
    revisit_condition: "Append after independent formula/array checking; handle §11 B only under a later explicit scope.",
  },
  {
    record_id: "CJK-KO-P02-HARD-026", tranche_ids: ["T12"], unit_ids: ["U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U66"], category: "terminology_trap",
    sense_window: "T12 distinction among coefficient Ordnung, irreducible/reducible versus decomposable forms, Reduzent, double reduction, Anlaß zur Reduktion, dualistic calculation, and module adjunction.",
    symptom: "`분해 가능` and `환원 가능` are distinct states; `환원할 계기` does not certify causality, and `쌍대인 계산` repeats a source claim rather than independent validation.",
    cause_evidence: [metadataEvidence("TRANSLATION_CHOICES_T12_SECTION10.md", "T12 terminology sense windows and unresolved Anlaß surface", "producer_translation_choices")],
    attempted_approaches: [
      { approach: "Retain the source distinctions and explicit uncertainty in one tranche-level terminology hold.", outcome: "No state or causal overclaim is introduced.", status: "accepted" },
      { approach: "Collapse reducible/decomposable or treat source duality language as checker confirmation.", outcome: "Held for independent specialist review.", status: "held" },
    ],
    resolution_state: "held_for_independent_check", resolution: "T12 terminology remains provisional and unchecked.",
    artifact_effect: "Evidence sidecars only; no target, choices file, or decision log changed.", related_paths: [protectedMetadata.find((item) => item.name === "TRANSLATION_CHOICES_T12_SECTION10.md").path_workspace_relative], related_structural_ids: docStructuralIds(["U57", "U58", "U59", "U60", "U61", "U62", "U63", "U64", "U65", "U66"]),
    revisit_condition: "Append on independent specialist evidence, especially for Anlaß zur Reduktion and adjunction language.",
  },
  ...laterToolingRecords,
  ...laterRiskRecords,
  ...postFreezeToolingRecords,
  ...postRepairEvidenceRecords,
].map((record, index) => ({
  schema_version: SCHEMA_VERSION,
  recorded_at: "2026-08-04", time_precision: "day", timezone: "Europe/Berlin",
  append_sequence: index + 1, previous_record_sha256: null, work_id: WORK_ID,
  review_state: "producer_difficulty_unchecked", publication_state: PUBLICATION_STATE,
  supersession_state: "current", ...record,
}));

for (let index = 0; index < difficultyRecords.length; index += 1) {
  difficultyRecords[index].previous_record_sha256 = index === 0 ? null : difficultyRecords[index - 1].record_sha256;
  difficultyRecords[index].record_sha256 = sha256(Buffer.from(canonical(withoutKey(difficultyRecords[index], "record_sha256")), "utf8"));
}

const difficultyDir = path.join(evidenceRoot, "difficulty_ledger");
const difficultySchemaPath = path.join(difficultyDir, "DIFFICULTY_LEDGER.schema.json");
const difficultyJsonlPath = path.join(difficultyDir, "DIFFICULTY_LEDGER.jsonl");
const difficultyCsvPath = path.join(difficultyDir, "DIFFICULTY_LEDGER.csv");
const difficultyReportPath = path.join(difficultyDir, "DIFFICULTY_LEDGER_VALIDATION_REPORT.json");
await writeJson(difficultySchemaPath, difficultySchema);
const difficultyJsonl = difficultyRecords.map((record) => JSON.stringify(record)).join("\n") + "\n";
try {
  const existing = normalizeLf(await fs.readFile(difficultyJsonlPath, "utf8"));
  if (existing !== difficultyJsonl) {
    let prefixCount = 0;
    for (let count = 1; count < difficultyRecords.length; count += 1) {
      const prefix = difficultyRecords.slice(0, count).map((record) => JSON.stringify(record)).join("\n") + "\n";
      if (existing === prefix) prefixCount = count;
    }
    assert(prefixCount > 0, "Append-only difficulty JSONL differs from the deterministic chain; refusing overwrite");
    await fs.appendFile(difficultyJsonlPath, difficultyRecords.slice(prefixCount).map((record) => JSON.stringify(record)).join("\n") + "\n", "utf8");
  }
} catch (error) {
  if (error && error.code === "ENOENT") await writeText(difficultyJsonlPath, difficultyJsonl);
  else throw error;
}

const difficultyRows = difficultyRecords.map((record) => ({
  schema_version: record.schema_version, record_id: record.record_id, recorded_at: record.recorded_at,
  time_precision: record.time_precision, timezone: record.timezone, append_sequence: record.append_sequence,
  previous_record_sha256: record.previous_record_sha256, work_id: record.work_id,
  tranche_ids_json: canonical(record.tranche_ids), unit_ids_json: canonical(record.unit_ids), category: record.category,
  sense_window: record.sense_window, symptom: record.symptom, cause_evidence_json: canonical(record.cause_evidence),
  attempted_approaches_json: canonical(record.attempted_approaches), resolution_state: record.resolution_state,
  resolution: record.resolution, artifact_effect: record.artifact_effect, related_paths_json: canonical(record.related_paths),
  related_structural_ids_json: canonical(record.related_structural_ids), review_state: record.review_state,
  publication_state: record.publication_state, supersession_state: record.supersession_state,
  revisit_condition: record.revisit_condition, record_sha256: record.record_sha256,
}));
const difficultyCsv = toCsv(difficultyHeaders, difficultyRows);
await writeText(difficultyCsvPath, difficultyCsv);

const difficultyErrors = [];
const parsedDifficulty = normalizeLf(await fs.readFile(difficultyJsonlPath, "utf8")).trimEnd().split("\n").filter(Boolean).map(JSON.parse);
if (parsedDifficulty.length !== difficultyRecords.length) difficultyErrors.push(`Expected ${difficultyRecords.length} difficulty records`);
for (let index = 0; index < parsedDifficulty.length; index += 1) {
  const record = parsedDifficulty[index];
  if (record.append_sequence !== index + 1) difficultyErrors.push(`Non-contiguous sequence at ${record.record_id}`);
  const expectedPrevious = index === 0 ? null : parsedDifficulty[index - 1].record_sha256;
  if (record.previous_record_sha256 !== expectedPrevious) difficultyErrors.push(`Chain link mismatch at ${record.record_id}`);
  if (record.record_sha256 !== sha256(Buffer.from(canonical(withoutKey(record, "record_sha256")), "utf8"))) difficultyErrors.push(`Self-hash mismatch at ${record.record_id}`);
  for (const id of record.related_structural_ids) if (!byId.has(id)) difficultyErrors.push(`Missing structural link ${id} at ${record.record_id}`);
}
if (!parsedDifficulty[0].symptom.includes("post-2 numeric boundary") || !parsedDifficulty[0].symptom.includes("Paper 26")) difficultyErrors.push("HARD-001 does not preserve the filename-boundary failure");
if (parsedDifficulty[1].symptom !== "spawn_agent returned exactly 'agent thread limit reached'.") difficultyErrors.push("HARD-002 does not preserve spawn_agent return");
if (parsedDifficulty[2].symptom !== "followup_task also returned exactly 'agent thread limit reached'.") difficultyErrors.push("HARD-003 does not preserve followup_task return");
if (!parsedDifficulty[3].symptom.includes("An empty pipe element is not allowed") || !parsedDifficulty[3].attempted_approaches.some((attempt) => attempt.status === "accepted" && attempt.approach.includes("$rows = foreach"))) difficultyErrors.push("HARD-004 does not preserve failed and successful PowerShell forms");
for (const [recordIndex, unitId] of [[4, "U02"], [5, "U11"], [6, "U13"], [7, "U14"], [8, "U18"], [10, "U21"], [11, "U23"], [12, "U26"], [13, "U27"]]) {
  if (!parsedDifficulty[recordIndex].unit_ids.includes(unitId) || parsedDifficulty[recordIndex].resolution_state !== "held_for_independent_check") difficultyErrors.push(`${parsedDifficulty[recordIndex].record_id} does not preserve ${unitId} hold`);
}
if (!parsedDifficulty[9].symptom.includes("Überschiebung") || !parsedDifficulty[9].symptom.includes("Übertragungsprinzip")) difficultyErrors.push("HARD-010 does not preserve the terminology trap");
if (!parsedDifficulty[14].symptom.includes("Error: Producer human-metadata inventory changed; refresh the protected baseline before freezing evidence") || !parsedDifficulty[14].artifact_effect.includes("wrote no generated JSONL/CSV")) difficultyErrors.push("HARD-015 does not preserve the exact scope-race preflight abort and no-write result");
if (!parsedDifficulty[15].symptom.includes("An empty pipe element is not allowed") || !parsedDifficulty[15].attempted_approaches.some((attempt) => attempt.status === "accepted" && attempt.approach.includes("$prows=foreach")) || !parsedDifficulty[15].cause_evidence.some((item) => item.sha256 === POINTER_SHA256)) difficultyErrors.push("HARD-016 does not preserve the repeated parser failure, successful materialization, and pointer-v005 link");
for (const [recordIndex, unitId] of [[16, "U29"], [17, "U32"], [18, "U37"], [19, "U42"], [20, "U45"], [21, "U46"], [22, "U53"], [23, "U56"], [24, "U66"], [25, "U66"]]) {
  if (!parsedDifficulty[recordIndex].unit_ids.includes(unitId) || parsedDifficulty[recordIndex].resolution_state !== "held_for_independent_check") difficultyErrors.push(`${parsedDifficulty[recordIndex].record_id} does not preserve ${unitId} extended-scope hold`);
}
if (!parsedDifficulty[24].symptom.includes("§11 B") || !parsedDifficulty[24].resolution.includes("out of scope")) difficultyErrors.push("HARD-025 does not preserve the T12-to-T13 forward-reference boundary");
const difficultyById = new Map(parsedDifficulty.map((record) => [record.record_id, record]));
const expectedLatestDifficultyId = "CJK-KO-P02-HARD-063";
if (parsedDifficulty.at(-1)?.record_id !== expectedLatestDifficultyId) difficultyErrors.push(`Difficulty ledger does not end at ${expectedLatestDifficultyId}`);
const toolingChecks = [
  ["CJK-KO-P02-HARD-027", "apply_patch could not locate", "changed no log, source, target, metadata, canon, or evidence byte"],
  ["CJK-KO-P02-HARD-028", "unbraced variable immediately before `:`", "VALIDATION_ERRORS=0"],
  ["CJK-KO-P02-HARD-029", "history alias", "No filesystem byte changed"],
  ["CJK-KO-P02-HARD-030", "Windows error 123", "No source, target, metadata, or evidence input changed"],
  ["CJK-KO-P02-HARD-031", "Missing argument in parameter list", "No filesystem byte changed"],
  ["CJK-KO-P02-HARD-032", "An empty pipe element is not allowed", "No target, metadata, table, or evidence input changed"],
  ["CJK-KO-P02-HARD-033", "false 1-byte slice", "No source, target, metadata, or cursor file changed"],
  ["CJK-KO-P02-HARD-034", "U201 equation 32 was not indexed", "only replaceable generated structural sidecars"],
  ["CJK-KO-P02-HARD-055", "invalid patch: The last line of the patch must be '*** End Patch'", "no file was created"],
  ["CJK-KO-P02-HARD-056", "ReferenceError: TextEncoder is not defined", "Manifest creation itself succeeded"],
  ["CJK-KO-P02-HARD-057", "SyntaxError: Unexpected identifier 't'", "No v002 file was created"],
  ["CJK-KO-P02-HARD-058", "canonicalization-description defect", "true .NET ordinal order yields"],
  ["CJK-KO-P02-HARD-059", "foreach($p in$paths)", "corrected read-only retry wrote no file"],
  ["CJK-KO-P02-HARD-060", "An empty pipe element is not allowed", "wrote zero files"],
  ["CJK-KO-P02-HARD-061", "Unexpected identifier 'console'", "failed parse wrote zero files"],
];
for (const [recordId, symptomFragment, effectFragment] of toolingChecks) {
  const record = difficultyById.get(recordId);
  if (!record || !record.symptom.includes(symptomFragment) || !canonical(record).includes(effectFragment) || record.resolution_state !== "resolved_operationally") difficultyErrors.push(`${recordId} does not preserve its exact operational failure and artifact effect`);
}
for (let sequence = 35; sequence <= 54; sequence += 1) {
  const recordId = `CJK-KO-P02-HARD-${String(sequence).padStart(3, "0")}`;
  const record = difficultyById.get(recordId);
  if (!record || record.resolution_state !== "held_for_independent_check") difficultyErrors.push(`${recordId} does not preserve the T13--T32 independent-check hold`);
}
const terminalTableRisk = difficultyById.get("CJK-KO-P02-HARD-054");
if (!terminalTableRisk?.unit_ids.includes("U225") || !terminalTableRisk?.unit_ids.includes("U226") || !terminalTableRisk?.symptom.includes("87 mcell") || !terminalTableRisk?.symptom.includes("104 mcell") || !terminalTableRisk?.symptom.includes("331 reconciliation")) difficultyErrors.push("HARD-054 does not preserve both terminal-table metrics and the 331 reconciliation hold");
if (parsedDifficulty.filter((record) => ["discovery_failure", "delegation_failure", "tooling_failure"].includes(record.category)).length !== 21) difficultyErrors.push("Expected 21 observed operational failures");
if (parsedDifficulty.filter((record) => record.resolution_state === "held_for_independent_check").length !== 40) difficultyErrors.push("Expected 40 source/translation difficulty holds");
for (const [recordId, unitId, siblingSha256, originalSha256] of [
  ["CJK-KO-P02-HARD-062", "U02", "1D39A01D8908BBEBF41BDE6D6A9E691756BE57CC493BFEE59337371FAEEB8BD7", "081252F90A544382AE7AAF11FDE4755CE99E5F640AC3F20C0F0CBD3A39D6C2BF"],
  ["CJK-KO-P02-HARD-063", "U29", "B380060629B2733D4460DBB583DD2866DCD0B017F3CAB84A07EE855A9A9241DA", "1424FE01364DF9495EFDF9F9EA6A7D98E3A0071D98CE1EAE3FF98544F871625A"],
]) {
  const record = difficultyById.get(recordId);
  const serialized = canonical(record || {});
  if (!record || record.review_state !== "external_checker_tex_defect_confirmed_repaired_only" || record.resolution_state !== "resolved_operationally" || !record.unit_ids.includes(unitId) || !serialized.includes(CHECKER_ADJUDICATION_ID) || !serialized.includes(siblingSha256) || !serialized.includes(originalSha256) || !serialized.includes("full-build") || !serialized.includes("visual")) difficultyErrors.push(`${recordId} does not preserve the exact checker-confirmed repair and remaining-gate boundary`);
}
const parsedDifficultyCsv = parseCsv(difficultyCsv);
if (canonical(parsedDifficultyCsv[0]) !== canonical(difficultyHeaders) || parsedDifficultyCsv.length !== difficultyRows.length + 1) difficultyErrors.push("Difficulty CSV header/row count mismatch");
for (let index = 0; index < difficultyRows.length; index += 1) {
  const expected = difficultyHeaders.map((header) => difficultyRows[index][header] === null || difficultyRows[index][header] === undefined ? "" : String(difficultyRows[index][header]));
  if (canonical(parsedDifficultyCsv[index + 1]) !== canonical(expected)) difficultyErrors.push(`Difficulty CSV projection mismatch at row ${index + 2}`);
}

const difficultySchemaIdentity = await fileIdentity(difficultySchemaPath);
const difficultyJsonlIdentity = await fileIdentity(difficultyJsonlPath);
const difficultyCsvIdentity = await fileIdentity(difficultyCsvPath);
const difficultyReport = {
  schema_version: SCHEMA_VERSION, status: difficultyErrors.length === 0 ? "PASS" : "FAIL", errors: difficultyErrors,
  validator: path.basename(scriptPath), evidence_date: "2026-08-04", append_only: true,
  record_count: parsedDifficulty.length, unique_record_count: new Set(parsedDifficulty.map((record) => record.record_id)).size,
  latest_record_id: parsedDifficulty[parsedDifficulty.length - 1].record_id,
  chain_head_sha256: parsedDifficulty[parsedDifficulty.length - 1].record_sha256,
  observed_operational_failure_ids: parsedDifficulty.filter((record) => ["discovery_failure", "delegation_failure", "tooling_failure"].includes(record.category)).map((record) => record.record_id),
  hard_source_translation_unit_ids: parsedDifficulty.filter((record) => record.resolution_state === "held_for_independent_check").map((record) => record.record_id),
  schema: { path: path.basename(difficultySchemaPath), ...difficultySchemaIdentity },
  jsonl: { path: path.basename(difficultyJsonlPath), ...difficultyJsonlIdentity },
  csv: { path: path.basename(difficultyCsvPath), ...difficultyCsvIdentity },
  review_boundary: "Observed operational/difficulty evidence plus two explicitly attributed personal-checker TeX-defect repairs. Frozen originals remain immutable; no linguistic approval, German defect, full build, extraction, rendering, visual QA, assembly, certification, or approval is inferred.",
};
await writeJson(difficultyReportPath, difficultyReport);
assert(difficultyReport.status === "PASS", `Difficulty validation failed: ${difficultyErrors.join("; ")}`);

const visualHeaders = [
  "schema_version", "visual_id", "work_id", "tranche_id", "unit_id", "visual_type",
  "parent_path_workspace_relative", "parent_sha256", "source_page", "bounding_box_json", "coordinate_basis",
  "dimensions_json", "dpi", "rotation_degrees", "image_path_workspace_relative", "image_sha256",
  "linked_structural_ids_json", "qa_state", "review_state", "render_state", "rights_status", "rights_basis",
  "disposition", "publication_state", "continuation_cursor",
];
const visualSchema = {
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "$id": "urn:interlanguage:noether:p02:ko:visual-evidence:1.0.0",
  title: "Noether Paper 2 Korean T01--T32 visual-evidence record",
  description: "Schema for any source crop, scan, page image, equation crop, target render, contact sheet, comparison image, segmentation artifact, or overlay. The current JSONL intentionally has zero records because no visual was used or created and no target was compiled or rendered.",
  type: "object",
  required: visualHeaders.filter((header) => !header.endsWith("_json")).concat(["bounding_box", "dimensions", "linked_structural_ids"]),
  properties: {
    schema_version: { const: SCHEMA_VERSION, description: "Visual schema version." },
    visual_id: { type: "string", pattern: "^CJK-KO-P02-VIS-[0-9]{3}$", description: "Stable visual ID." },
    work_id: { const: WORK_ID, description: "Stable work ID." },
    tranche_id: { enum: Object.keys(trancheBounds), description: "Scoped tranche." },
    unit_id: { enum: units.map((unit) => unit.unit), description: "Scoped unit." },
    visual_type: { enum: ["source_crop", "equation_crop", "diagram_crop", "page_image", "target_render", "contact_sheet", "before_after", "segmentation_artifact", "model_overlay", "other"], description: "Visual artifact class." },
    parent_path_workspace_relative: { type: ["string", "null"], description: "Optional parent scan/image." },
    parent_sha256: { type: ["string", "null"], pattern: "^[A-F0-9]{64}$", description: "Optional parent hash." },
    source_page: { type: ["integer", "null"], minimum: 1, description: "Optional physical page." },
    bounding_box: { type: ["object", "null"], properties: { x: { type: "integer" }, y: { type: "integer" }, width: { type: "integer", minimum: 1 }, height: { type: "integer", minimum: 1 } }, required: ["x", "y", "width", "height"], additionalProperties: false, description: "Optional pixel box." },
    coordinate_basis: { type: ["string", "null"], description: "Coordinate basis." },
    dimensions: { type: ["object", "null"], properties: { width: { type: "integer", minimum: 1 }, height: { type: "integer", minimum: 1 } }, required: ["width", "height"], additionalProperties: false, description: "Image dimensions." },
    dpi: { type: ["number", "null"], minimum: 0, description: "Image DPI." },
    rotation_degrees: { type: ["number", "null"], description: "Image rotation." },
    image_path_workspace_relative: { type: ["string", "null"], description: "Visual path." },
    image_sha256: { type: ["string", "null"], pattern: "^[A-F0-9]{64}$", description: "Visual hash." },
    linked_structural_ids: { type: "array", uniqueItems: true, items: { type: "string" }, description: "Linked structural IDs." },
    qa_state: { enum: ["not_performed", "pending", "complete"], description: "Visual QA state." },
    review_state: { enum: ["not_reviewed", "reviewed"], description: "Visual review state." },
    render_state: { enum: ["not_rendered", "rendered"], description: "Render state." },
    rights_status: { enum: ["not_assessed", "cleared", "restricted", "unknown"], description: "Rights status; absence of a record is not clearance." },
    rights_basis: { type: ["string", "null"], description: "Rights evidence basis." },
    disposition: { enum: ["not_created", "retain_private", "eligible_for_archive_projection", "exclude_rights", "published"], description: "Visual disposition." },
    publication_state: { enum: ["not_published", "published"], description: "Visual publication state." },
    continuation_cursor: { type: ["string", "null"], description: "Next authorized visual action." },
  },
  additionalProperties: false,
  "x-csv-projection": {
    headers: visualHeaders,
    nested_json_columns: ["bounding_box_json", "dimensions_json", "linked_structural_ids_json"],
    description: "Header-only CSV is the flat projection of the intentionally empty authoritative JSONL.",
  },
};

const visualDir = path.join(evidenceRoot, "visual_evidence");
const visualSchemaPath = path.join(visualDir, "VISUAL_EVIDENCE_INDEX.schema.json");
const visualJsonlPath = path.join(visualDir, "VISUAL_EVIDENCE_INDEX.jsonl");
const visualCsvPath = path.join(visualDir, "VISUAL_EVIDENCE_INDEX.csv");
const visualReportPath = path.join(visualDir, "VISUAL_EVIDENCE_INDEX_VALIDATION_REPORT.json");
await writeJson(visualSchemaPath, visualSchema);
await writeText(visualJsonlPath, "");
await writeText(visualCsvPath, visualHeaders.join(",") + "\n");
const visualErrors = [];
if ((await fs.readFile(visualJsonlPath)).length !== 0) visualErrors.push("Visual JSONL must be zero bytes");
const visualCsvRows = parseCsv(await fs.readFile(visualCsvPath, "utf8"));
if (visualCsvRows.length !== 1 || canonical(visualCsvRows[0]) !== canonical(visualHeaders)) visualErrors.push("Visual CSV must be header-only");
const visualSchemaIdentity = await fileIdentity(visualSchemaPath);
const visualJsonlIdentity = await fileIdentity(visualJsonlPath);
const visualCsvIdentity = await fileIdentity(visualCsvPath);
const visualReport = {
  schema_version: SCHEMA_VERSION, status: visualErrors.length === 0 ? "PASS" : "FAIL", errors: visualErrors,
  validator: path.basename(scriptPath), evidence_date: "2026-08-04", record_count: 0,
  image_file_count: 0, image_bytes: 0, source_image_count: 0, target_render_count: 0,
  compiled_target_count: 0, visually_inspected_target_count: 0,
  rights_assessed_count: 0, rights_cleared_count: 0, rights_restricted_count: 0,
  retained_private_count: 0, archive_projection_eligible_count: 0, publication_included_count: 0,
  rights_disposition_state: "not_applicable_no_visual_created_or_used",
  continuation_cursor: null,
  schema: { path: path.basename(visualSchemaPath), ...visualSchemaIdentity },
  jsonl: { path: path.basename(visualJsonlPath), ...visualJsonlIdentity },
  csv: { path: path.basename(visualCsvPath), ...visualCsvIdentity },
  validation_scope: "Schema parse plus explicit zero-byte JSONL and header-only CSV projection.",
  excluded_scope: "No image, scan, crop, render, compilation, visual QA, rights clearance, disposition decision, or publication action occurred.",
};
await writeJson(visualReportPath, visualReport);
assert(visualReport.status === "PASS", `Visual validation failed: ${visualErrors.join("; ")}`);

const visualStatus = [
  "# Noether Paper 2 Korean T01--T32 visual-evidence status",
  "",
  "- State: explicit zero-record inventory.",
  "- Visuals used or created: 0 files / 0 bytes.",
  "- Source images/crops and target renders: 0 / 0.",
  "- Compilation, rendering, and visual inspection: not performed.",
  "- Rights assessed/cleared/restricted: 0 / 0 / 0.",
  "- Disposition: not applicable because no visual exists; absence is not rights clearance or visual QA.",
  "- Publication included: 0.",
  "- Visual continuation cursor: none until a separately authorized visual is actually used or created.",
  "",
].join("\n");
await writeText(path.join(visualDir, "STATUS.md"), visualStatus);

const protectedInputsDir = path.join(evidenceRoot, "protected_inputs");
const protectedAuditPath = path.join(protectedInputsDir, "PROTECTED_INPUT_NO_TOUCH_AUDIT.json");
const targetManifestPath = path.join(protectedInputsDir, "TARGET_INPUT_MANIFEST.tsv");
const metadataManifestPath = path.join(protectedInputsDir, "METADATA_INPUT_MANIFEST.tsv");
const producerManifestPath = path.join(protectedInputsDir, "PRODUCER_INPUT_MANIFEST.tsv");
const targetManifestLines = units.map((unit) => `${path.relative(projectRoot, unit.targetPath).replace(/\\/g, "/")}\t${unit.targetBytes}\t${unit.targetSha256}`).sort();
const metadataManifestLines = protectedMetadata.map((item) => `${path.relative(projectRoot, path.join(workspaceRoot, item.path_workspace_relative.replace(/\//g, path.sep))).replace(/\\/g, "/")}\t${item.bytes}\t${item.sha256}`).sort();
const targetManifest = targetManifestLines.join("\n") + "\n";
const metadataManifest = metadataManifestLines.join("\n") + "\n";
const producerManifest = [...targetManifestLines, ...metadataManifestLines].sort((left, right) => {
  const leftFolded = left.toUpperCase(); const rightFolded = right.toUpperCase();
  return leftFolded < rightFolded ? -1 : leftFolded > rightFolded ? 1 : left < right ? -1 : left > right ? 1 : 0;
}).join("\n") + "\n";
const expectedManifestIdentities = {
  targets: { bytes: 23696, sha256: "9B010E22D3D1E14C0BBB91607ADC835B81FD666F3F7D359996F70B0907C2EE36" },
  metadata: { bytes: 12250, sha256: "560CB8456FD1A7AD3EC7B44F2B073AE6C11BDC14589FC3503F18CB7FF2A60EFA" },
  combined: { bytes: 35946, sha256: "A7B65BD77131CF1B8F3D0323A07E074422EC8ACC672D532D36EB96076426F5AD" },
};
for (const [label, text, expected] of [["targets", targetManifest, expectedManifestIdentities.targets], ["metadata", metadataManifest, expectedManifestIdentities.metadata], ["combined", producerManifest, expectedManifestIdentities.combined]]) {
  assert(Buffer.byteLength(text, "utf8") === expected.bytes && sha256(Buffer.from(text, "utf8")) === expected.sha256, `${label} producer-input manifest identity changed`);
}
await writeText(targetManifestPath, targetManifest);
await writeText(metadataManifestPath, metadataManifest);
await writeText(producerManifestPath, producerManifest);
const targetManifestIdentity = await fileIdentity(targetManifestPath);
const metadataManifestIdentity = await fileIdentity(metadataManifestPath);
const producerManifestIdentity = await fileIdentity(producerManifestPath);
const protectedRows = [
  { kind: "authority", name: path.basename(authorityPath), path_workspace_relative: relPath(authorityPath), expected_bytes: AUTHORITY_BYTES, expected_sha256: AUTHORITY_SHA256 },
  { kind: "pointer", name: path.basename(producerPointerPath), path_workspace_relative: relPath(producerPointerPath), expected_bytes: PRODUCER_POINTER_BYTES, expected_sha256: PRODUCER_POINTER_SHA256 },
  { kind: "pointer", name: path.basename(pointerPath), path_workspace_relative: relPath(pointerPath), expected_bytes: POINTER_BYTES, expected_sha256: POINTER_SHA256 },
  ...units.map((unit) => ({ kind: "target", name: unit.targetName, path_workspace_relative: relPath(unit.targetPath), expected_bytes: unit.targetBytes, expected_sha256: unit.targetSha256 })),
  ...protectedMetadata.map((item) => ({ kind: "human_metadata", name: item.name, path_workspace_relative: item.path_workspace_relative, expected_bytes: item.bytes, expected_sha256: item.sha256 })),
];
const protectedAuditRecords = [];
for (const expected of protectedRows) {
  const fullPath = path.join(workspaceRoot, expected.path_workspace_relative.replace(/\//g, path.sep));
  const current = await fileIdentity(fullPath);
  protectedAuditRecords.push({ ...expected, final_bytes: current.bytes, final_sha256: current.sha256, byte_identical: current.bytes === expected.expected_bytes && current.sha256 === expected.expected_sha256 });
}
const protectedErrors = protectedAuditRecords.filter((record) => !record.byte_identical).map((record) => `${record.kind}:${record.name}`);
const protectedAudit = {
  schema_version: SCHEMA_VERSION, status: protectedErrors.length === 0 ? "PASS" : "FAIL", errors: protectedErrors,
  evidence_date: "2026-08-04", audit_phase: "post_generation_rehash_against_frozen_prework_identities",
  authority_count: protectedAuditRecords.filter((record) => record.kind === "authority").length,
  pointer_count: protectedAuditRecords.filter((record) => record.kind === "pointer").length,
  target_count: protectedAuditRecords.filter((record) => record.kind === "target").length,
  human_metadata_count: protectedAuditRecords.filter((record) => record.kind === "human_metadata").length,
  byte_identical_count: protectedAuditRecords.filter((record) => record.byte_identical).length,
  mutation_count: protectedErrors.length,
  decision_log_write_count: 0,
  decision_log_note: "The builder contains no decision-log path and performs no decision-log write; this is an execution-scope statement, not a semantic audit.",
  manifests: {
    targets: { path: path.basename(targetManifestPath), ...targetManifestIdentity, record_count: units.length, input_bytes: units.reduce((sum, unit) => sum + unit.targetBytes, 0) },
    human_metadata: { path: path.basename(metadataManifestPath), ...metadataManifestIdentity, record_count: protectedMetadata.length, input_bytes: protectedMetadata.reduce((sum, item) => sum + item.bytes, 0) },
    combined_producer_inputs: { path: path.basename(producerManifestPath), ...producerManifestIdentity, record_count: units.length + protectedMetadata.length, input_bytes: units.reduce((sum, unit) => sum + unit.targetBytes, 0) + protectedMetadata.reduce((sum, item) => sum + item.bytes, 0) },
  },
  records: protectedAuditRecords,
  versioned_tex_repair_siblings_outside_frozen_original_set: repairSiblingSpecs.map((spec) => ({
    unit_id: spec.unit, path_workspace_relative: relPath(spec.targetPath), bytes: spec.bytes, sha256: spec.sha256,
    frozen_original_sha256: spec.originalSha256,
    status: "checker_confirmed_tex_defect_repaired_only; linguistically_unchecked; full_build_not_performed; not_rendered; not_visually_inspected",
  })),
  adjacent_mutable_target_names_observed_at_preflight: adjacentTargetNamesAtPreflight,
  adjacent_mutable_human_metadata_names_observed_at_preflight: adjacentHumanMetadataNamesAtPreflight,
  protected_boundary: "ED0001, producer pointer v004, adopted pointer v005, all 199 frozen original scoped targets, and all 120 scoped producer metadata files were read/hashed only. The two versioned TeX-repair siblings are separately identity-bound and do not replace, mutate, or increase the frozen-original count. Paper 3 begins at line 3573 and is out of scope. Evidence writes are confined to evidence/ and the methodology append.",
};
await writeJson(protectedAuditPath, protectedAudit);
assert(protectedAudit.status === "PASS", `Protected input mutation detected: ${protectedErrors.join("; ")}`);

const rootReadme = [
  "# Noether Paper 2 Korean T01--T32 / U01--U226 producer evidence",
  "",
  "This is a source-synchronized, machine-readable producer-evidence freeze for ED0001 lines 473--3568 and 199 frozen Korean producer targets across 32 separate unchecked tranches, plus two separately versioned checker-confirmed TeX-repair siblings. The identifier space U01--U226 contains 27 deliberate unused reservations, so 199 original units are present with no substantive source gap. Paper 2 terminal controls at lines 3569--3572 are bound separately and excluded from target coverage; Paper 3 begins at line 3573. The continuation cursor is `" + CURSOR + "`.",
  "",
  "- `structural_index/` contains the authoritative hierarchical JSONL, deterministic CSV projection, field-documented schema, and PASS report.",
  "- `difficulty_ledger/` contains the append-only SHA-256 predecessor chain for twenty-one observed operational failures, forty source/translation difficulty holds, and two personally checker-confirmed TeX-repair returns. It preserves the original/sibling/source/probe identities and every still-open linguistic/full-build/render/visual gate.",
  "- `visual_evidence/` contains a schema-documented zero-record JSONL, header-only CSV, PASS report, and explicit no-render/rights/disposition status.",
  "- `protected_inputs/` rehashes ED0001, producer pointer v004, adopted pointer v005, 199 frozen original targets, and 120 producer metadata files; it publishes canonical target/metadata/combined TSV manifests and requires zero mutations. The two repair siblings are separately listed and do not alter protected-set semantics.",
  "- `csv_artifact_validation/` imports and inspects all three CSV projections without rendering.",
  "",
  "Primary structural records partition every scoped physical source/target line exactly once. Overlapping annotations expose displays/equations, nested arrays, footnotes/markers, bibliography items, symbols, and important references. Cross-language links are unit/tag/occurrence mechanics only and never assert translation or formula equivalence.",
  "",
  "HARD-015 preserves the historical first-builder preflight abort before generated evidence write when live producer metadata outran the earlier baseline. The final freeze dynamically harvests all completed work through T32/U226. Sixty-six early targets remain producer-bound to pointer v004 and 133 later targets to pointer v005; v005 supersedes v004 while both bind unchanged ED0001. No target/header/metadata rewrite was made.",
  "",
  "Boundary: two preexisting producer-owned siblings carry only the exact U02/U29 TeX-syntax repairs personally confirmed by checker task `" + CHECKER_TASK_ID + "`; every frozen original remains byte-identical. No German defect, linguistic approval, full build, extraction, rendering, visual inspection, assembly, packaging, certification, approval, source/scan adjudication, Paper 6 mutation, or SGA work was performed by this evidence pass.",
  "",
].join("\n");
await writeText(path.join(evidenceRoot, "README.md"), rootReadme);

const buildSummary = {
  schema_version: SCHEMA_VERSION, status: "PASS", evidence_date: "2026-08-04",
  builder: { path: path.basename(scriptPath), ...builderIdentity },
  scope: { tranches: Object.keys(trancheBounds), units: units.map((unit) => unit.unit), actual_unit_count: units.length, deliberate_unused_unit_ids: deliberateUnitIdGaps, deliberate_unused_unit_id_count: deliberateUnitIdGaps.length, source_interval: "473--3568", terminal_control_interval: "3569--3572", paper3_cursor_line: 3573, next_cursor: CURSOR, adjacent_mutable_targets_observed_at_preflight: adjacentTargetNamesAtPreflight, adjacent_mutable_metadata_observed_at_preflight: adjacentHumanMetadataNamesAtPreflight },
  structural: { status: structuralReport.status, record_count: structuralReport.record_count, latest_record_id: structuralReport.latest_record_id, jsonl_sha256: structuralJsonlIdentity.sha256, csv_sha256: structuralCsvIdentity.sha256 },
  difficulty: { status: difficultyReport.status, record_count: difficultyReport.record_count, latest_record_id: difficultyReport.latest_record_id, chain_head_sha256: difficultyReport.chain_head_sha256, jsonl_sha256: difficultyJsonlIdentity.sha256, csv_sha256: difficultyCsvIdentity.sha256 },
  visual: { status: visualReport.status, record_count: 0, jsonl_sha256: visualJsonlIdentity.sha256, csv_sha256: visualCsvIdentity.sha256, render_calls: 0 },
  protected_inputs: { status: protectedAudit.status, authority_count: 1, pointer_count: 2, frozen_original_target_count: units.length, versioned_tex_repair_sibling_count: repairSiblingSpecs.length, human_metadata_count: protectedMetadata.length, protected_record_count: protectedAuditRecords.length, mutation_count: 0, target_manifest: { ...targetManifestIdentity }, metadata_manifest: { ...metadataManifestIdentity }, combined_manifest: { ...producerManifestIdentity } },
  checker_tex_repairs: { evidence_id: CHECKER_ADJUDICATION_ID, checker_task_id: CHECKER_TASK_ID, personally_rederived_without_subagents: true, unit_ids: repairSiblingSpecs.map((spec) => spec.unit), linguistic_state: "unchecked", full_build_state: "not_performed", render_state: "not_rendered", visual_qa_state: "not_performed" },
  boundary: "Producer evidence generation plus exact indexing of two personally checker-confirmed TeX-syntax repair siblings; no linguistic approval, German defect, full build, extraction, render, visual, assembly, package, certification, source/scan adjudication, Paper 6, or SGA operation.",
};
await writeJson(path.join(evidenceRoot, "EVIDENCE_BUILD_VALIDATION_REPORT.json"), buildSummary);

console.log(JSON.stringify({
  status: "PASS", structural_records: structuralReport.record_count,
  structural_latest_id: structuralReport.latest_record_id,
  difficulty_records: difficultyReport.record_count,
  difficulty_latest_id: difficultyReport.latest_record_id,
  difficulty_chain_head: difficultyReport.chain_head_sha256,
  visual_records: 0, protected_mutations: 0, continuation_cursor: CURSOR,
}, null, 2));
