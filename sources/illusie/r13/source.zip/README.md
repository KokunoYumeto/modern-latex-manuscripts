# Complexe cotangent et déformations I–II

This is the public working-edition checkpoint for Luc Illusie's
`Complexe cotangent et déformations`, Springer Lecture Notes in Mathematics
239 and 283.

Two independent cumulative editions are maintained:

- `french.pdf` from the cumulative French master `fr.tex`;
- `english.pdf` from the cumulative English master `en.tex`.

Each reader opens on a clean author-and-work cover: Luc Illusie and the
language-appropriate title only. No LNM masthead, series number, editors,
Springer device, or publisher imprint is placed on the visible edition cover.
The reconstructed historical source cover remains internal diplomatic
evidence.

The current admitted scope is LNM 239 physical pages 1–22. The front matter is
complete, and Chapter I section 1.1 is present through printed page 4. It
includes the simplicial indexing category; simplicial, cosimplicial, mixed,
diagonal, constant, and augmented objects; equations (1.1.1)–(1.1.5.1);
the representable coequalizer and adjoint triple for `pi_0`; the definition
of homotopy and its native-TeX diagrams; the homotopy category
`Hotsimpl(C)`; homotopy equivalences; the cosimplicial analogue
`Hotcosimpl(C)`; and the beginning of relative homotopy. The final sentence
continues on physical page 23 / printed page 5 after French
`la relation d'équivalence` / English `the equivalence relation`.
LNM 283 has not started. No chapter, volume, or two-volume completion is
claimed.

The internal diplomatic French preserves the physical carrier split
`homo-/topisme`. The French edition joins it as `homotopisme`; page 22
has no textual correction. The direct reading `Simp(p)` is deliberately
preserved rather than silently modernized.

The source archive contains the active TeX modules, internal diplomatic French
evidence, corrected French source, English translation, semantic and reference
tables, append-only decisions, and compact validation receipts. The Springer
authority scans and direct page images are identified by exact hashes but are
not redistributed here.

This is a scholarly working edition, not a complete translation, critical
edition, peer review, mathematical certification, or claim of redistribution
permission for the underlying Springer publication.
