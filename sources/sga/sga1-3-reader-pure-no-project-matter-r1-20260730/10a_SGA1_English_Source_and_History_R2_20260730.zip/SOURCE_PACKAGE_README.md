# SGA 1 English source and history package

This archive preserves the editable source lineage for the direct
259-page English reader. The public reader suppresses project-facing
status and production notes; those historical source annotations remain
available here for review.

- TeX files: 139
- Root: `SGA1_English_source_sync_workpass.tex`
- Text authority: corrected French arXiv `math/0206203v2` TeX.
- External comparisons, build logs, scans, rejected states, and
  operational/private evidence are excluded.
- Underlying French rights are not conveyed by this package.

The direct reader preserves the verified predecessor body and link
structure byte-for-byte from page 2 onward while replacing only its
title-page presentation. This source/history archive is therefore not a
claim of byte-for-byte PDF reproducibility.

`SHA256SUMS.csv` enumerates every other member and excludes itself.
