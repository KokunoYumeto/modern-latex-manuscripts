# SGA2 English reader clean R10

This successor keeps the mathematical body, references, and the
historical editorial apparatus of the source edition while moving
project correction-history and source-status commentary out of the
direct reading PDF.

R10 also removes the project build date from the title page. No
mathematical text, historical preface, source-era editor note, reference,
or page geometry changes.

The removed material remains hash-bound in the removal ledger and
in immutable predecessor/source history. This is a reading-surface
change, not a silent alteration of the French authority.
