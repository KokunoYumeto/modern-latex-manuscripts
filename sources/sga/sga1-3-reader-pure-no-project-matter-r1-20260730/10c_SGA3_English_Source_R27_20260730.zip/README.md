# SGA 3 English Reader

The direct PDF is the current cumulative reading edition of SGA 3. It
contains the Introduction, Exposes I--XXVI, the Tome-I subject index, the
Tome-III mathematical guide, and the terminal index.

The reader presents the mathematics directly. Production commentary, source
locators, and working source-reading notes are not printed in the PDF.
Source-defect annotations remain preserved in the grouped editable-source
archive.

R27 removes the remaining two project page-locator banners, the visible
source-version footnote in Expose XV, and the technical `TeX edition`
subtitle. Historical editorial apparatus intrinsic to the Polo--Gille
edition remains part of the scholarly text.

This is an English scholarly edition in active correction, not a critical
edition or a blanket rights clearance. Earlier versions remain preserved.
