from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parent / "inputs"


def balanced_commands(text: str, command: str):
    pattern = re.compile(rf"\\{command}(?:\[[^\]]*\])?\s*\{{")
    cursor = 0
    while match := pattern.search(text, cursor):
        start = match.start()
        brace = match.end() - 1
        depth = 0
        pos = brace
        while pos < len(text):
            if text[pos] == "{" and (pos == 0 or text[pos - 1] != "\\"):
                depth += 1
            elif text[pos] == "}" and (pos == 0 or text[pos - 1] != "\\"):
                depth -= 1
                if depth == 0:
                    yield start, pos + 1, text[brace + 1 : pos]
                    cursor = pos + 1
                    break
            pos += 1
        else:
            raise ValueError(f"Unbalanced \\{command} command at byte {start}")


def normalized_head(body: str) -> str:
    head = " ".join(body[:700].replace("~", " ").split()).lower()
    return re.sub(r"^\\label\{[^{}]*\}\s*", "", head)


def is_project_footnote(body: str) -> bool:
    head = normalized_head(body)
    if "editor's note in the french source" in head[:180]:
        return False
    if "editor’s note in the french source" in head[:180]:
        return False
    if re.search(r"translator['’]s\s+note", head[:180]):
        return True
    if re.search(r"\bsource(?:-reading| notation)?\s+note\s*[:.]", head[:180]):
        return True
    if "source pdf" in head[:220]:
        return True
    if "polo--gille re-edition prints" in head[:250]:
        return True
    if "polo–gille re-edition prints" in head[:250]:
        return True
    return bool(
        re.search(
            r"\b(?:the )?(?:displayed |printed )?french "
            r"(?:source|re-edition|text)\b",
            head[:250],
        )
    )


def is_inline_translator_note(body: str) -> bool:
    head = " ".join(body[:220].split()).lower()
    return bool(re.match(r"\(?translator['’]s\s+note\s*:", head))


def already_archived(text: str, start: int) -> bool:
    return "\\SGAArchiveOnly{" in text[max(0, start - 80) : start]


changed_files = 0
archived_footnotes = 0
archived_inline_notes = 0

for path in sorted(ROOT.rglob("*.tex")):
    original = path.read_text(encoding="utf-8")
    updated = original

    replacements = []
    for start, end, body in balanced_commands(updated, "footnote"):
        if is_project_footnote(body) and not already_archived(updated, start):
            replacements.append((start, end, "\\SGAArchiveOnly{" + updated[start:end] + "}"))

    for start, end, body in balanced_commands(updated, "emph"):
        if is_inline_translator_note(body) and not already_archived(updated, start):
            replacements.append((start, end, "\\SGAArchiveOnly{" + updated[start:end] + "}"))

    for start, end, replacement in sorted(replacements, reverse=True):
        updated = updated[:start] + replacement + updated[end:]
        if replacement.startswith("\\SGAArchiveOnly{\\footnote"):
            archived_footnotes += 1
        else:
            archived_inline_notes += 1

    updated = updated.replace(
        "Editor's note in the French source:", "Editor's note:"
    ).replace(
        "Editor’s note in the French source:", "Editor’s note:"
    )

    if updated != original:
        path.write_text(updated, encoding="utf-8", newline="")
        changed_files += 1

print(f"changed_files={changed_files}")
print(f"archived_footnotes={archived_footnotes}")
print(f"archived_inline_notes={archived_inline_notes}")
