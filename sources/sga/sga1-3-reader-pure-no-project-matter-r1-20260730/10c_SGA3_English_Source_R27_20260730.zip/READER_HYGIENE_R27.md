# SGA 3 reader hygiene R27

The direct reader contains no project-status, source-locator, AI/tool,
workflow, or publication-state prose.

R27 removes the two visible `Page numbers refer to the Polo--Gille
re-edition` banners, suppresses the Expose XV source-version footnote, and
simplifies the title subtitle to `English Translation`.

The suppressed wording remains in this source/history archive where it is
useful for provenance. Genuine historical editorial apparatus from the
Polo--Gille source edition remains visible in the reader.
