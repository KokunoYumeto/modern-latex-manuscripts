# Publication caveats — SGA 3 Exposé V Loop 1 R3

This is a bounded English Exposé-V reader, not a completed SGA 3 volume and
not a critical edition.

- The corrected Polo--Gille PDF is the controlling source but is not
  redistributed in this payload. Publication of the English reconstruction
  does not grant rights in the underlying French source.
- Jacob Reinhold's CC BY 4.0 Markdown translation is credited as a comparison
  and drafting lineage. Attribution must remain with any reuse derived from
  that lineage. It is not source authority or independent corroboration.
- Because no public editor LaTeX source was available, this editable reader
  was reconstructed from the PDF. OCR served only as locator/drafting
  material and is not included as authority.
- Loop 1 retains 66 source-PDF-derived PNG diagram assets. They provide a
  usable, visually checked reader; Loop 2 must replace them with native LaTeX
  diagrams.
- Cross-exposé references whose destinations are outside standalone Exposé V
  remain classified residuals rather than false internal links. They can be
  linked only in a later cumulative reader with admitted destinations.
- All fonts are embedded. Thirteen Type 3 bitmap fonts lack ToUnicode; 23 Type
  1 fonts include ToUnicode. Page-by-page extraction equality is verified,
  but the Type 3 subset remains an accessibility caveat.
- PDF Title, Author, Subject, and Keywords are blank. There is no XMP packet,
  tagged-PDF structure, or `/MarkInfo`. These are descriptive-metadata and
  accessibility limitations, not mathematical-content defects.
- Raw and sanitized build logs are excluded from the public projection. Build
  evidence is represented only by privacy-clean counts and hashes.
- Occurrence-ledger byte/line coordinates use the packaged reference-free
  baseline. The reversible mutation ledger and component hashes map that
  baseline exactly to the delivered wrapped TeX. Target `pdf_page` values,
  by contrast, are physical pages in the delivered reader.
- No GitHub publication, Zenodo deposition, DOI, or public readback is claimed
  by this producer workspace. Archive maintenance owns publication.
