# SGA 3, Exposé V — English Loop-1 reference-v2 R3

This no-overwrite R3 successor contains a complete standalone English
reconstruction of SGA 3, Exposé V, from its opening through the bibliography.
It preserves the approved reader text and layout while adding exhaustive,
machine-readable clickable-reference data under convention v2.

## Source and comparison provenance

The controlling source is the Polo--Gille corrected re-edition PDF
`Exp5-13oct24.pdf`: 439,522 bytes, SHA-256
`9198200633F929FE1822520371A9200DA4F8CF2513EFAB3D6A0C7E9330DB84CF`.
Its Exposé-V envelope is 41 component-local pages, corresponding to combined
reader pages 263--303. It controls French prose, formulas, numbering, notes,
and diagram appearance.

Jacob Reinhold's English Markdown translation is credited as a comparison and
drafting lineage: <https://github.com/jcreinhold/sga>, repository revision
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`, matched Exposé-V file SHA-256
`4FE1ED8361FDF66DCEED6D6E534E4A37B4E2DB7AF9BF9FFA29A023579FC9FE30`.
That lineage is not source authority and does not constitute independent
source corroboration. Reinhold declares CC BY 4.0 for his translation; the
underlying French-source rights remain separate.

No public editor LaTeX source for this SGA 3 re-edition was available during
the reconstruction. The editable English was therefore reconstructed from
the controlling PDF, with OCR used only as locator/drafting material. The 66
diagrams are clean PDF-derived PNGs in Loop 1. Replacing them with native
LaTeX diagrams is the separate Loop-2 task.

## Primary artifacts

- `tex/SGA3_Expose_V_English_Loop1_ReferenceV2_00_23.tex`: master TeX,
  6,679 bytes, SHA-256
  `A97D3114929A937AC8F764C003B2CE2BDC7B1D476500C0FE1B2092E8BC2661AA`;
- `tex/components/`: 24 sequential editable TeX components;
- `figures/exp5/`: 66 temporary Loop-1 diagram PNGs;
- `r3_release_build_final2/SGA3_Expose_V_English_Loop1_ReferenceV2_00_23.pdf`:
  54-page standalone reader, 1,047,599 bytes, SHA-256
  `8EC0CCB72F10022160D65494AA38CFC2340FBE0DC4C3EC7528BBC0AA9B44C6EE`;
- `controls/REFERENCE_TARGETS_R3.csv`: 273 semantic targets;
- `controls/REFERENCE_EDGES_R3.csv`: 333 closed internal edges, including 29
  bibliography edges;
- `controls/REFERENCE_CANDIDATES_R3.csv` and
  `controls/REFERENCE_RESIDUALS_R3.csv`: exhaustive 4,328-occurrence
  partition into 333 linked edges and 3,995 adjudicated residuals;
- `controls/REFERENCE_REVISION_EVENTS_R3.jsonl` and
  `controls/SOURCE_MUTATIONS_R3.jsonl`: append-only revision and reversible
  source-mutation evidence;
- `controls/R3_PDF_RELEASE_EVIDENCE_VALIDATION.json`: compiled PDF, action,
  render, text, figure, font, and metadata gate.

## Coordinate and validation policy

The source coordinates in the candidate, edge, residual, detector, and
locator ledgers are against the packaged 24-component reference-free
baseline, not the longer delivered wrapped TeX. The coordinate basis is
explicit in `controls/LEDGER_COORDINATE_BASIS_R3.csv`; the exact reversible
mapping to `tex/components/` is `controls/SOURCE_MUTATIONS_R3.jsonl`.
`SOURCE_PRESERVATION_R3.csv` binds both generations by bytes and SHA-256.

In `REFERENCE_TARGETS_R3.csv`, `body_local_page` is the TeX body-page value
and `pdf_page` is the one-based physical page in the delivered 54-page PDF.
All 273 `pdf_page` values replay exactly from the PDF named-destination map.

The narrow producer-stage validation is not a co-current release control and
is omitted from the public projection. The sole public reference validation
is the exhaustive 273-target / 4,328-candidate / 3,995-residual surface.

This is an Exposé-V checkpoint, not a complete SGA 3 volume. Exposé VI and
later are outside this payload.
