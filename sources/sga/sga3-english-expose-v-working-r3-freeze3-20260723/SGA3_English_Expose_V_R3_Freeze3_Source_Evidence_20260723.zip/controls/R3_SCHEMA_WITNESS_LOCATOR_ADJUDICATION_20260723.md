# R3 schema and coordinate adjudication

Scope: SGA 3, Exposé V, reference-convention-v2 R3 successor, components
00–23 only.

The independent R2 schema memo remains an external adverse/design witness,
identified by SHA-256
`8B7B984E52B01C0434F8A412B6EBAC9C052033F51094D084804DD42881C4BB49`.
It is not a payload path and the superseded narrow R2/R3 validation is not a
co-current release control.

R3 uses the following exact coordinate rules:

- candidates, edges, residuals, detector hits, and locator signatures use
  the packaged reference-free baseline at
  `controls/reference_free_baseline/components/<source_file>`;
- targets use delivered `tex/components/<source_file>` declaration
  coordinates;
- target `body_local_page` is the final AUX body-page value;
- target `pdf_page` is the one-based physical page in the delivered PDF.

`SOURCE_PRESERVATION_R3.csv` binds all 24 baseline and delivered components.
`SOURCE_MUTATIONS_R3.jsonl` supplies 282 reversible reference-only changes.
`VISIBLE_SOURCE_CORRECTIONS_R3.jsonl` separately supplies the single
Section-6 visible correction. Final replay passes 24/24 source identities and
273/273 physical PDF target-page identities.

The literal `\tag{3}` regression witness remains at baseline component
`01_expose_V_pp253_255_en.tex`, line 124, and retains the classification
`structural_declaration_or_tag`.
