# R3 coordinate basis and self-contained reconstruction map

The source locators in the Exposé-V reference tables are deliberately stable
coordinates against the **reference-free approved English baseline**, not
against the longer delivered TeX after `\hyperref` wrappers and inserted
anchors.

## Exact coordinate basis

- `REFERENCE_CANDIDATES_R3.csv`, `REFERENCE_EDGES_R3.csv`,
  `REFERENCE_RESIDUALS_R3.csv`, `DETECTOR_HITS_R3.csv`, and
  `LOCATOR_SIGNATURE_AUDIT_R3.csv` use
  `reference_free_baseline_r3/components/<source_file>` in the producer tree,
  packaged as `controls/reference_free_baseline/components/<source_file>`,
  as their text and byte-coordinate basis unless an individual column
  explicitly says `successor`.
- The 24 exact reference-free components are included in the public
  projection under `controls/reference_free_baseline/components/`.
- `SOURCE_PRESERVATION_R3.csv` binds every baseline component and delivered
  component to exact byte counts and SHA-256 values.
- `SOURCE_MUTATIONS_R3.jsonl` gives the complete ordered, reversible mapping
  from each reference-free component to the delivered wrapped component.
  Each atomic record supplies baseline and successor byte intervals, Base64
  original/replacement bytes, hashes, component ID, and associated target,
  edge, and candidate IDs.
- The exhaustive validator replays both directions and requires 24/24 exact
  reconstruction. Thus every baseline coordinate can be resolved into the
  delivered source without inference.

`REFERENCE_TARGETS_R3.csv` is different: its declaration coordinates are
against delivered `tex/components/<source_file>`. Its `body_local_page`
column records the final AUX body-page value, while `pdf_page` is the
one-based physical page in the delivered 54-page PDF. The validator requires
all 273 physical page values to equal the PDF named-destination replay.

## R2-to-R3 visible correction

`VISIBLE_SOURCE_CORRECTIONS_R3.jsonl` separately records the one non-reference
change in this successor: `SGA3-V-S6-NUMBER-R3-001`, which replaces the
incorrect class-generated visible Section `0.1` heading with the
Polo--Gille-controlled visible Section `6` heading while retaining the stable
label `sec:sga3-V-6` and a correct table-of-contents entry.

This separation prevents a source-visible correction from being mislabeled
as a reference-only mutation. The R2 source, the R3 reference-free baseline,
and the R3 delivered wrapped source remain independently hash-bound.
