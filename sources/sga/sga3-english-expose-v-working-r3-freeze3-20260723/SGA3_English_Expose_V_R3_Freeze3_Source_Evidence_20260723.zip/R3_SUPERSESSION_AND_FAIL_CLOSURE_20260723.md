# R3 supersession and R2 fail closure

The immutable Exposé-V R2 freeze remains preserved and is **FAIL-CLOSED**. It
must not be archived or treated as a releasable checkpoint.

## R2 blockers

1. Its rendered page 27 shows `0.1 Passage to the quotient when a
   quasi-section exists`; the controlling Polo--Gille Exposé-V PDF,
   component-local page 20 / combined-reader page 282, visibly prints Section
   `6`. This also exposed a machine false positive: the R2 semantic-target
   row claimed compiled visible locator `6` although the delivered PDF
   actually rendered `0.1`.
2. It packages a narrow historical validation surface with
   251 targets / 478 candidates / 145 residuals beside the active exhaustive
   surface with 273 targets / 4,326 candidates / 3,993 residuals, without an
   adequate supersession declaration.
3. Its `STATUS.md` claims SHA-256
   `CD2C889D55122A89DF1B66DC1FDC0005F58BD45EA338E1A8303415FD5B29D382`
   for the public exhaustive validation, while the file sealed by the R2
   freeze manifest is 5,961 bytes, SHA-256
   `8FC08278E3D9F8C7F61EFE90C70FA32793A81B1AD8AE95245B1B71D161DEB183`.
4. The coordinate basis of most reference-occurrence tables is the
   reference-free baseline, but the R2 public package does not explain that
   distinction clearly enough.
5. Its release ledgers literally reference 114 absent QA images and two
   absent PDF paths after the projection renames those files.
6. Its six 16-bit contact sheets render blank in the independent audit
   viewer and are not portable QA evidence.
7. Thirteen of 24 `SOURCE_PRESERVATION` successor identities are stale
   against delivered components, all 273 target-ledger `pdf_page` values are
   body-local rather than physical delivered-PDF pages, and the narrow
   validation points to earlier absent control identities.

The controlling R2 adverse parents are:

- `ROOT_INDEPENDENT_RELEASE_AUDIT_FAIL_SGA3_EXPOSE_V_R2_FREEZE1_20260723.md`,
  13,726 bytes, SHA-256
  `9E90C7400342A671E2A4C0847B7EA8C8A2C95AF430570598D5D4B39AF11A5AB1`;
- `SGA3_EXPOSE_V_R2_FREEZE1_INDEPENDENT_TREE_PRIVACY_MACHINE_AUDIT_FAIL_20260723.md`,
  21,251 bytes, SHA-256
  `37531BF5AB0AF34E4C58A55812BC3A49403E1EC0349C11825818E7D6B6067A83`.

## R3 policy

- R2 bytes are never overwritten.
- R3 applies the visible Section-6 correction under stable ID
  `SGA3-V-S6-NUMBER-R3-001`.
- The narrow source-machine validation remains producer-internal and is not
  shipped as a co-current public validation surface. The public package
  exposes only the exhaustive 273 / 4,328 / 3,995 surface.
- R3 includes a self-contained 24-component reference-free baseline,
  reversible atomic mutation mapping, and explicit coordinate-basis document.
- `SOURCE_PRESERVATION_R3.csv` matches all 24 final delivered components and
  all 24 corrected baselines. The target ledger separates `body_local_page`
  from physical delivered-PDF `pdf_page`, with 273/273 destination equality.
- Public evidence keeps literal paths stable: 54 baseline renders, 54
  successor renders, six portable 8-bit contact sheets, and the reader PDF
  are present exactly where the machine evidence points.
- Every public identity is regenerated from the final exact R3 tree.
- Archive dispatch remains prohibited until a fresh comprehensive independent
  audit explicitly passes the immutable R3 freeze.
