# SGA 3 Exposé V reference-v2 R3 status

## Scope

Exposé V is complete and continuous from component-local source page 1
through page 41, including the bibliography. Its combined-reader span is
263--303. There is no remaining Exposé-V translation cursor. Exposé IV and
Exposé VI+ are outside this workspace.

## Producer gate

R3 producer validation is PASS:

- 24/24 current component byte/hash identities match
  `SOURCE_PRESERVATION_R3.csv`, and all 24 reconstruct the corrected
  reference-free baseline exactly after inverse replay of 282 reference-only
  mutations;
- the one separate visible-source successor record,
  `SGA3-V-S6-NUMBER-R3-001`, changes only the Section-6 heading and table of
  contents from the erroneous class-generated `0.1` to the source-controlled
  visible `6`;
- 273 semantic targets, including all 58 visible editor/source-note anchors;
- 333 internal edges, including 29 bibliography edges;
- 4,328 detected candidate occurrences partition exactly into 333 edges and
  3,995 positively adjudicated residuals; unadjudicated count 0;
- all 220 changed edges have append-only mutation coverage;
- 273/273 target destinations and physical delivered-PDF page values agree
  with the named-destination replay; 333/333 edge actions close in the PDF;
- 355 named destinations and 411 valid internal GoTo annotations; no external
  actions, invalid rectangles, OpenAction, JavaScript, form, or attachment;
- three-pass build converged; passes 2 and 3 are byte-identical and the final
  log has no TeX errors, unresolved references, rerun request, PDF-string
  warning, or box diagnostic;
- 52/54 extracted-text pages and 52/54 120-dpi renders equal the approved
  predecessor exactly; only TOC page 3 and heading page 27 differ, and both
  prove the intended `0.1` to `6` correction;
- all six contact sheets are portable 8-bit PNGs and were visually inspected;
- 66/66 diagram PNGs are present, unique, used once, and bound to an exact
  delivered-component line locator;
- 36/36 fonts are embedded; 13 embedded Type 3 fonts without ToUnicode remain
  a disclosed accessibility caveat;
- all generated CSV files are rectangular and formula-safe; JSON/JSONL parse,
  stable-ID, reference-closure, and forward/inverse replay gates pass.

Current identities:

- master TeX: 6,679 bytes, SHA-256
  `A97D3114929A937AC8F764C003B2CE2BDC7B1D476500C0FE1B2092E8BC2661AA`;
- PDF: 1,047,599 bytes, 54 pages, SHA-256
  `8EC0CCB72F10022160D65494AA38CFC2340FBE0DC4C3EC7528BBC0AA9B44C6EE`;
- producer-internal exhaustive reference validation:
  `controls/REFERENCE_V2_EXHAUSTIVE_VALIDATION_R3.json`, 7,016 bytes,
  SHA-256
  `0DA3DADD8F799A6A44F95CB57D511823DF6521F194D706D1C59B35BC720DD32F`;
- co-current public exhaustive reference validation:
  `controls/REFERENCE_V2_EXHAUSTIVE_VALIDATION_R3_PUBLIC.json`, 6,583 bytes,
  SHA-256
  `6286E28412FB6E8D89B4B7F23F571562E50067ABFE0755C29ECBBCAF8A5FA836`;
- PDF release-evidence validation: SHA-256
  `770F2E94062EF314750666E698FCF330C940A88E8BF3EC82FCF9E2B50A13A955`;
- exact regenerated figure inventory: 66 rows, 19,505 bytes, SHA-256
  `EC820536182DCC1D338045E8195D06956EF57A965964EEEA12387702EF02A8A8`.

The source coordinates in the five occurrence ledgers use the packaged
reference-free baseline; target `pdf_page` values use physical delivered-PDF
pages. These are distinct and explicitly documented.

## Release state

Freeze 2 is preserved under
`R3_FREEZE2_FIGURE_LOCATOR_HOLD_20260723.md`: five figure rows retained
predecessor line numbers after the Section-6 component gained one line.
The no-overwrite freeze-3 public projection regenerates those locators from
the delivered TeX and excludes every raw or sanitized build log, auxiliary
build file, diagnostic build, predecessor failure artifact, source PDF, OCR
witness, and private local path. Fresh independent freeze-3 review remains
the final bounded release gate. No GitHub, Zenodo, DOI, archive
acknowledgment, or public readback is claimed here.
