# R3 public freeze 2 — figure-locator hold

The immutable freeze-2 public projection is preserved unchanged and must not
be archived, promoted, or described as the current release checkpoint.

Exact held projection:

- directory:
  `public_projection_r3_exposeV_reference_v2_freeze2`;
- 267 files, 33,928,229 bytes;
- external manifest:
  `controls/PUBLIC_PROJECTION_R3_FREEZE2_SHA256.csv`, 267 rows,
  48,793 bytes, SHA-256
  `0863CCA9E68DB17C43DDCF18F63386490FC7010A4A73F8B0635B4597643679E8`;
- external producer validation:
  `controls/PUBLIC_PROJECTION_R3_FREEZE2_VALIDATION.json`, 842 bytes,
  SHA-256
  `B9F683D7CE172D8A6F56AD55527F0C220383BC7B631F3A313755A68B22B16337`.

Two independent reviews passed the gates they replayed. A subsequent exact
lead replay found that the packaged `controls/FIGURE_INVENTORY_R3.csv`
(SHA-256
`B43E3ED9DA5BC45367E9F129C030A9E931329798281E8834121A8031CE8C4D7B`)
retained five predecessor line locators after the Section-6 component gained
one source line:

| Figure ID | Component | Freeze-2 line | Delivered-source line |
|---|---|---:|---:|
| `sga3.e05.figure.035` | `12_expose_V_section6_quasisection_setup_en.tex` | 13 | 14 |
| `sga3.e05.figure.036` | `12_expose_V_section6_quasisection_setup_en.tex` | 41 | 42 |
| `sga3.e05.figure.037` | `12_expose_V_section6_quasisection_setup_en.tex` | 54 | 55 |
| `sga3.e05.figure.038` | `12_expose_V_section6_quasisection_setup_en.tex` | 61 | 62 |
| `sga3.e05.figure.039` | `12_expose_V_section6_quasisection_setup_en.tex` | 76 | 77 |

The remaining 61 figure locators are exact. The image identities, image
references, TeX, PDF, reference graph, and rendered pages are not changed by
this machine-locator correction. Nevertheless, a public machine ledger with
five false delivered-source coordinates is not release-exact.

The no-overwrite freeze-3 projection regenerates the figure ledger directly
from the delivered TeX, regenerates dependent validation and manifests, and
supersedes freeze 2 only for release consideration. Freeze-2 independent PASS
reports remain historical evidence for the exact tree they audited; they do
not authorize freeze 2 after this later defect was found. No archive
acknowledgment, GitHub publication, Zenodo publication, DOI, or public
readback is claimed.
