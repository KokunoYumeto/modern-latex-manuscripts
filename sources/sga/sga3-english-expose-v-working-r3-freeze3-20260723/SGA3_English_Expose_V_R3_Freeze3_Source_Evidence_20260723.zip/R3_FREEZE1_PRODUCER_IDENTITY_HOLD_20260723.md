# R3 public freeze 1 — producer identity hold

The first R3 public projection is preserved unchanged and must not be
archived or promoted.

Exact held projection:

- directory:
  `public_projection_r3_exposeV_reference_v2_freeze1`;
- 265 files, 33,925,200 bytes;
- external manifest:
  `PUBLIC_PROJECTION_R3_FREEZE_SHA256.csv`, 265 rows, 48,437 bytes,
  SHA-256
  `E89B0F75DA7DFB177BAA94CFDD6D607B5EA61E96F6B898F166EB2994319C068B`;
- external producer validation:
  `PUBLIC_PROJECTION_R3_FREEZE_VALIDATION.json`, 842 bytes, SHA-256
  `8C349C4CC478B100BEEB4CC3A7C9C800B6F06CBDBF67A59F9C56A56086E25AC7`.

The tree and mechanical validation passed, but its public `STATUS.md`
reported the producer-internal exhaustive-validation SHA-256
`0DA3DADD8F799A6A44F95CB57D511823DF6521F194D706D1C59B35BC720DD32F`
without separately identifying the packaged sanitized exhaustive control.
The co-current public file is 6,583 bytes, SHA-256
`6286E28412FB6E8D89B4B7F23F571562E50067ABFE0755C29ECBBCAF8A5FA836`.
That ambiguity repeats the class of active-identity defect that invalidated
R2, so freeze 1 is producer-held append-only.

The no-overwrite freeze-2 projection corrects the status surface by naming
both identities and their distinct roles. It supersedes freeze 1 only for
release consideration. No archive dispatch, upload, DOI, or publication is
claimed.
