# SGA 1-6

## English readers

- `00a_SGA1_English_Reader.pdf`
- `00b_SGA2_English_Reader.pdf`
- `00c_SGA3_English_Reader.pdf`
- `00d_SGA4_English_Reader.pdf`
- `00e_SGA5_English_Reader.pdf`
- `00f_SGA6_English_Reader.pdf`

The SGA2 R9 direct reader preserves the mathematical body, references, and
historical edition apparatus while moving project correction history,
source-status commentary, and production notes into its grouped archive.
The SGA3 R22 reader includes completed native-diagram successors for
Exposes VIII, IX, XI, and XV.

Direct reading PDFs contain mathematics and genuine historical edition
apparatus. Project workflow, model, source-reading, and correction-history
records are kept outside reader pages.

## French texts

Direct French reader and TeX files are present for SGA5 and SGA6.

## Editable sources and archives

The `02*` files are direct English master TeX files. The `03*` files are the
available direct French master TeX files. Supporting source, provenance,
quality-control, and historical material is grouped in the `10*`, `11*`,
and `12*` ZIP archives.

Rights in the underlying works remain with their respective holders.
Historical versions remain available through Zenodo. The corresponding
source packages are mirrored in the project's GitHub repository.
