# SGA 3 English working reader through Exposé IV

This is a bounded English reconstruction checkpoint containing:

- the Editorial Notice and Introduction;
- Exposés I-IV, ending with the Exposé IV bibliography;
- the complete editable TeX dependency tree;
- the diagram assets required by that TeX tree;
- a compiled 266-page A4 PDF;
- the active convention-v2 reference graph in machine-readable CSV form.

Exposé V and every later exposé are absent. This package is not the complete
SGA 3 English reader and must not be described as such.

## Reader and source

- PDF: `build/SGA3_English_Through_Expose_IV_Public_Checkpoint_20260723.pdf`
- master TeX: `tex/SGA3_English_Loop1.tex`
- components: `tex/components/`
- macros: `tex/sga3_loop1_macros.tex`
- diagram assets: `figures/` and `assets/diagrams/`
- reference data: `machine/reference_v2/`

All literal TeX input and image dependencies needed by the master are included.
Build from this directory with XeLaTeX:

```text
xelatex -interaction=nonstopmode -halt-on-error tex/SGA3_English_Loop1.tex
xelatex -interaction=nonstopmode -halt-on-error tex/SGA3_English_Loop1.tex
xelatex -interaction=nonstopmode -halt-on-error tex/SGA3_English_Loop1.tex
```

The public checkpoint rebuild used three passes and produced a 266-page PDF.
Passes 2 and 3 converged. Five inherited underfull-box diagnostics remain; no
hard error, undefined reference, duplicate destination, missing glyph,
overfull box, or rerun request remains.

## Editorial status

The Polo-Gille re-edition PDFs listed in `PROVENANCE_AND_SCOPE.md` control the
French text, formulae, and page-level comparison. OCR was used only as a
drafting and location witness. Exposé IV has completed its native diagram
replacement pass. Exposés I-III still contain Loop-1 PNG diagram
reproductions and therefore remain subject to the eventual whole-reader
native-diagram pass.

Jacob C. Reinhold's English Markdown lineage was consulted as an attributed
comparison witness, not as source authority. See `RIGHTS_AND_ATTRIBUTION.md`.

## Release caution

This is a privacy-clean working checkpoint for archival review. It is not a
claim of whole-SGA 3 completion, a critical edition, or a rights clearance for
the underlying French work and reproduced diagram material. See
`PUBLICATION_READINESS.md` and `RIGHTS_AND_ATTRIBUTION.md`.
