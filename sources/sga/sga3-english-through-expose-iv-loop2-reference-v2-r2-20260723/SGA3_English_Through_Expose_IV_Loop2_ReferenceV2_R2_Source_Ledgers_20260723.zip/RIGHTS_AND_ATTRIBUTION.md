# Rights and attribution

This checkpoint separates provenance from legal conclusions. It does not
grant a blanket license over the original French SGA 3 text, the Polo-Gille
re-edition, or source-derived diagram imagery. Rights in those materials
remain with their respective rights holders.

## French authority

The Polo-Gille re-edition PDFs are the controlling scholarly witnesses. They
are not bundled here. The TeX reconstruction and English rendering are
derivative scholarly work and must retain the source attribution and this
rights caveat.

Some PNG files in `figures/` and `assets/diagrams/` reproduce bounded diagram
regions needed by the present Loop-1 reader. Their inclusion is documented
for scholarly reconstruction and review; it does not assert independent
copyright ownership or unrestricted relicensing. Exposé IV has completed its
native-diagram pass, while Exposés I-III still require that later replacement.

## English comparison lineage

Jacob C. Reinhold's public English Markdown project was used as a comparison
witness:

- author: Jacob C. Reinhold;
- repository: `https://github.com/jcreinhold/sga`;
- compared commit:
  `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- upstream declaration: CC BY 4.0 for Reinhold's translation contribution,
  with underlying French rights retained.

This package credits that lineage wherever it was consulted. The
Polo-Gille French PDFs, not Reinhold's English, control the reconstruction.
Nothing here expands the scope of Reinhold's license to the original French
work or to third-party source images.

## Redistribution

Any public host should preserve:

1. this file;
2. `PROVENANCE_AND_SCOPE.md`;
3. the Reinhold attribution above;
4. the statement that the package is an incomplete I-IV working checkpoint;
5. the caveat that rights in the underlying French work and source-derived
   diagram material remain with their rights holders.

No claim is made here that every jurisdiction permits every form of public
redistribution. The archive maintainer must apply the repository's rights
policy before publication.
