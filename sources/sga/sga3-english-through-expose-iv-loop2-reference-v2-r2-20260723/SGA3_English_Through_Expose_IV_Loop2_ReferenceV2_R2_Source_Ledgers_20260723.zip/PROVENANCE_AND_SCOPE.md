# Provenance and scope

## Controlling French witnesses

The English reconstruction was checked against the current Polo-Gille
re-edition PDFs. These PDFs are the page, prose, formula, and diagram
authority for this checkpoint; they are not included in this payload.

| Unit | Authority filename | Pages | Bytes | SHA-256 |
|---|---:|---:|---:|---|
| Editorial Notice and Introduction | `AaIntro-18fev11.pdf` | 6 | 164,202 | `3D70B22B42C60CBBB289885C92ACC23A7DFA7A41C74C11BADF651E817D9E99E6` |
| Exposé I | `Exp1-13oct24.pdf` | 48 | 470,608 | `D078C08E00C69FB13F92EE1AE83915A4F8CEA0694E6490E0FD5B898A8366CDAD` |
| Exposé II | `Exp2-14oct24.pdf` | 52 | 504,805 | `B1BCC804E4C1E610AA1D0269E8F617C5E56F399E09F8C7A65E7E08DEF4AB4A25` |
| Exposé III | `Exp3-14oct24.pdf` | 78 | 706,483 | `B799DE7CA975B738BDC293D703C257E63CAFFD6FA9365F5A398D6E01CB9599E6` |
| Exposé IV | `Exp4-13oct24.pdf` | 74 | 624,810 | `7126C52925A0CC320F28D68B139B6763EEACD59ED8907714B4AD7CA8C6C14D5D` |

The wider frozen Polo-Gille reader is a locator convenience only. The unit
files above are the explicit controls for this bounded package.

## Reconstruction lineage

The controlling immutable input to this public projection was the
post-Loop-2, convention-v2 I-IV source stage dated 2026-07-23:

- source stage: 187 files, 3,361,072 bytes;
- source-stage framework identity:
  `1F42B0534DE8C329E87CCEF60BF42A890A107FC489251E9D83FB12213C2C6A61`;
- master TeX: 8,859 bytes,
  SHA-256 `BD31E621C52AA7228BCD82A2AF827E68BB374DCF4473CBC4CF3E7E7D34E0CCE5`;
- producer `STATUS.md`:
  SHA-256 `CEC297EE1B24541727A26BCEF066A986053A47FA4378AB74CE78D3FD90B07821`;
- producer `FINAL_LOCAL_VALIDATION.json`: 1,715 bytes,
  SHA-256 `B000E177BCD51DCEF334F3E7FB847786F38212E4E9988D1A49A4000A7097E947`,
  status `PASS`, errors `[]`.

The public projection copies 185 reader-relevant files byte-for-byte from the
187-file source stage: all 56 TeX files, all 128 referenced PNG assets, and
the diagram README. Two unreferenced `contact_crops.png` QA contact sheets
were deliberately excluded. The four active reference-v2 CSV ledgers were
copied byte-for-byte from the same admitted generation. Internal build trees,
absolute-path controls, earlier generations, failed controls, and
workflow-only evidence were not projected.

## Comparison and drafting witnesses

OCR output was used only to locate and draft text. It does not establish a
French reading, formula, or diagram.

The external English comparison was Jacob C. Reinhold's `jcreinhold/sga`
Markdown lineage at commit
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`. It was used as a phrasing and
comparison witness. The Polo-Gille PDFs remained controlling whenever the
lineages differed.

## Exact stopping point

The final included unit is the Exposé IV bibliography. The continuation point
is Exposé V. No Exposé V or later source, translation, machine record, or
claim is included.
