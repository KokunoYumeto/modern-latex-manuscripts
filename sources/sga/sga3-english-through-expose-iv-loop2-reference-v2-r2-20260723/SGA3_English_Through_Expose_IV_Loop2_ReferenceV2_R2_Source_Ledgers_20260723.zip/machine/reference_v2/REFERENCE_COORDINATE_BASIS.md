# Reference-v2 coordinate basis

The `source_file`, `source_sha256`, `source_line`, and `source_column` fields
in the four reference ledgers are coordinates in the immutable,
reference-free post-Loop-2 baseline used to generate the delivered linked
TeX. They are not line coordinates in the delivered files after reference
wrappers were inserted.

All paths are relative to the payload root. `SOURCE_COORDINATE_MAP.csv` maps
the 26 source files represented in the ledgers from their reference-free
baseline hashes to the hashes of the delivered wrapped TeX files.

The producer's reversible convention-v2 transformation inserted:

- 373 `\SGARefTarget{...}` markers;
- 38 equation labels declared by equation target rows;
- 611 `\SGARefLink{...}{visible text}` wrappers;
- the two macro definitions required by those markers.

The producer independently replayed the inverse operation: remove the exact
generated macro block and target markers, unwrap each link to its visible
payload, and remove only the 38 declared generated equation labels. The
result reproduced the complete reference-free baseline byte-for-byte.

Consumers should use stable target, candidate, edge, and residual IDs for
joins. They should not treat a baseline `source_line` as a delivered-source
line number without first reconstructing the reference-free view.
