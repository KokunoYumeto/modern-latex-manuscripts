# Publication readiness

Status: `BOUNDED_CHECKPOINT_READY_FOR_ARCHIVE_REVIEW`

This package is technically ready for archive-maintenance review as the
English SGA 3 checkpoint through Exposé IV. It is not the complete SGA 3
reader and is not the final SGA 3 release.

## Included release surface

- editable source through Exposé IV;
- all literal TeX and image dependencies;
- 266-page rebuilt PDF;
- active convention-v2 target/candidate/edge/residual CSVs;
- public provenance, attribution, scope, and rights caveats;
- a self-excluding SHA-256 manifest and public validation receipt.

## Technical gate

- selected source-stage copy: 185/185 reader-relevant files byte-identical;
- source-stage omissions: two unreferenced internal QA contact sheets;
- master TeX SHA-256:
  `BD31E621C52AA7228BCD82A2AF827E68BB374DCF4473CBC4CF3E7E7D34E0CCE5`;
- rebuilt PDF: 266 A4 pages, 2,675,562 bytes,
  SHA-256 `B717DC08C2C77546638274C7F05266F5F24C1562999117ACF4D1874AFD79EA1D`;
- XeLaTeX: three passes, passes 2 and 3 converged;
- hard/undefined/duplicate/missing-glyph/overfull/rerun diagnostics: zero;
- inherited underfull diagnostics: five;
- reference graph: 411 targets, 1,157 candidates, 611 linked edges,
  1,157 residual dispositions;
- all PDF actions checked in the rebuilt file are internal `GoTo` actions;
- no URI actions or Type 3 fonts;
- selected front matter, exposé boundaries, and closing pages rendered and
  visually checked;
- privacy scan: zero private absolute paths, credentials, email addresses, or
  internal workflow markers in the proposed public files.

## Open work and rights caveats

- Exposé V and every later exposé are absent.
- Exposés I-III still use source-derived PNG diagrams in Loop 1.
- Whole-SGA 3 integration, native-diagram completion, final reference-v2
  replay, and final release audit remain open.
- Rights in the original French work, the Polo-Gille re-edition, and
  source-derived diagram material remain with their rights holders.
- No global license declaration is made by this package.

Accordingly, archival custody is appropriate, but a public host must retain
the rights and incompleteness caveats and apply its own rights policy.
