# SGA 3 English through Expose IV: Loop2/reference-v2 R2

This package accompanies the cumulative 266-page English working reader
through the end of Expose IV. Expose V is published separately; Exposes VI-XXVI
are not included here.

The Expose IV portion has complete native TeX diagram reconstruction and a
closed convention-v2 graph: 411 targets, 1,157 candidates/residuals, and 611
linked edges. The compiled PDF has 1,519 named destinations and 1,062 internal
GoTo rectangles. The final three-pass build, independent graph audit, PDF
action/font/text audit, and rendered visual QA all pass.

The 130 PNG assets in the source stage are byte-identical to assets already
published in the predecessor cumulative-through-Expose-III source package.
Ninety-six are needed by that inherited Loop1 build; thirty-four are retained
recovery/QA assets. Expose IV uses native TeX diagrams and adds no new source
pixels. The image inventory records every identity and its build role.

The controlling Expose IV authority is the Polo-Gille current reader,
SHA-256 7126C52925A0CC320F28D68B139B6763EEACD59ED8907714B4AD7CA8C6C14D5D.
OCR and external English material were locator/comparison material only.
Jacob C. Reinhold's jcreinhold/sga snapshot
e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e is credited comparison/drafting
lineage, not authority. Reinhold states CC BY 4.0 for his translation
contribution only.

No new rights grant is asserted for the underlying French work or inherited
source-derived diagram pixels. This is a machine-assisted working translation
and reconstruction, not a critical edition, mathematical certification,
independent human peer review, rights determination, accessibility
certification, or complete SGA 3.
