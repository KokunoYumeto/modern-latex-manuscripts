# Independent post-Loop2 reference-graph audit — PASS

Audit time: 2026-07-23T16:03:55.0611934+02:00  
Scope: corrected no-overwrite SGA3 Exposé IV r2 generation only  
Mutation: none

## Disposition

**PASS.** The corrected preflight, supplemental locator set, and rebased graph
are internally exact and close against the repaired Exposé-IV source. They
may proceed to the next reversible label/link stage. This is a graph/control
pass, not by itself a PDF/build/release certification.

The preserved r1 independent FAIL remains valid and unchanged. Its only
blocker—the stale preflight entry for an in-directory captured stdout
log—is absent from the corrected no-overwrite r2 generation.

## Independently verified

- The graph contains 411 unique targets and LaTeX labels, 1,157 unique
  candidate occurrences, 1,157 bijective residuals, and 611 linked edges.
- Stable target/candidate/edge/residual ID sets equal the independently
  audited pre-Loop2 graph. Every non-coordinate/non-source-hash field,
  including visible tokens and semantic dispositions, is unchanged.
- The four corrected graph CSV ledgers are byte-identical to the corresponding
  preserved r1 graph ledgers.
- Fresh discovery closes exactly:
  960 primary + 197 disjoint supplemental candidates = 1,157 candidates;
  400 primary IV + 11 supplemental targets = 411 targets.
- All 411 target anchors, 1,157 candidate tokens, 611 edge tokens, and 1,157
  residual tokens replay at their exact repaired-source path, SHA-256, line,
  column, and token SHA-256.
- Edges are exactly the `linked_internal_edge` subset; every edge target
  closes; there are no duplicated occurrences or unadjudicated rows.
- All 22 TOC mirrors are correctly partitioned as non-edge structural
  declarations immediately after their matching subsection targets.
- Nine Exposé-IV occurrences close to eight unique I–III targets.
- The three supplemental IV targets—two diagrams and one untagged display—
  each have exactly one closing edge.
- Exact TeX closure is 56 files / 55 input edges. No Exposé V or later source,
  heading, dependency, or graph row is present.
- Eighteen relevant CSVs / 8,390 data rows are rectangular and formula-safe.
- All three corrected manifests are complete and exact:
  - preflight: 10 rows, SHA-256
    `ED76642E1250084679EA6883546473AD22EDB0B7A4DC5CD6F253C5ED37E309DF`;
  - supplemental: 2 rows, SHA-256
    `F76D2987CF1D71956C853A5A19FB7A609A8976F58BB68CEE38695DFB123912E0`;
  - graph: 6 rows, SHA-256
    `004B5672B18B84B80C7F78CAEBC4B2C37706EAF9423BD261E48B17E55DEA5363`.

The raw preflight-to-admitted normalization of 38 tagged displays from
`equation_or_display` to `equation` is expected and identical to the prior
audited graph; it is not a post-Loop2 semantic change.

## Exact audited graph identities

| File | Bytes | SHA-256 |
|---|---:|---|
| `REFERENCE_TARGETS.csv` | 159,098 | `5389E7AB49F4511527ABD533C0231A7FFADFCD035924030651F1D9C016809C72` |
| `REFERENCE_CANDIDATES.csv` | 681,462 | `0EF82086C3ED84EFB3D7BA57F8E9ED98DF0BB6606749C40C1901F4DFB6F04C83` |
| `REFERENCE_EDGES.csv` | 331,816 | `E9AC5BE4B55220B9CCE115DA1607DC3BA2636D3E94C0301D88810A80EEDD9903` |
| `REFERENCE_RESIDUALS.csv` | 641,599 | `989928078D7C4D3AA680CD216E00EC4629D448BC6F52B45D4ADD12A3F22C825A` |
| `REFERENCE_SET_RELATION.json` | 2,720 | `2BBAC31292E07686E4DAB3E5CB518981D703DB5A9729C93A4836F47FC5FF9448` |
| `REBASE_VALIDATION.json` | 2,490 | `226224E506D56459391F3A356E93351D3C4C60B3CA3E532119373612D312D00D` |
| graph `SHA256SUMS.csv` | 597 | `004B5672B18B84B80C7F78CAEBC4B2C37706EAF9423BD261E48B17E55DEA5363` |

Master source: 8,859 bytes; SHA-256
`BD31E621C52AA7228BCD82A2AF827E68BB374DCF4473CBC4CF3E7E7D34E0CCE5`.

The machine-readable result records every tested assertion, special
partition, source delta, and controlling identity.
