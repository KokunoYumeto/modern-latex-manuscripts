# SGA3 I--IV convention-v2 PDF audit

Status: `PASS`.

- targets: 411
- linked source occurrences: 611
- linked/control PDF pages: 266/266
- PDF link annotation rectangles, linked/control/delta: 1062/441/621
- fragmented extra rectangles on expected destinations: 10
- named destinations in each PDF: 1519
- hard build diagnostics: 0
- inherited underfull diagnostics: 5
- errors: []

The target-only control retains all 411 destinations and removes only the 611 source hyperlink wrappers. Every expected destination gains at least its required number of GoTo rectangles, no unexpected destination gains one, all 411 custom labels map identically in the two AUX files, and the whitespace-normalized PDF text is identical.
