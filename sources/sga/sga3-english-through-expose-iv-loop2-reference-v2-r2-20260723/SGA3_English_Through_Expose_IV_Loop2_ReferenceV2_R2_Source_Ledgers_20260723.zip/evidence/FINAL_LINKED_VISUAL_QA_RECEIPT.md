# SGA3 I–IV Loop2 / reference-v2 final linked visual QA

Date: 2026-07-23

## Candidate

- PDF: `build_reference_v2_post_loop2_r2/SGA3_English_Loop1_Through_ExposeIV_Loop2_ReferenceV2_R2.pdf`
- Size: 2,675,569 bytes
- Pages: 266
- SHA-256: `3BD2F1B760F63F2EB43ABFB0EA4A66ACE48906599CE24F97D67434C8390A4F35`
- Scope: cumulative English Exposés I–IV only; Exposé V and later are excluded.

## Render coverage and inspection

The final linked PDF was copied byte-identically to a short-path render workspace because the installed Poppler build cannot open the full workspace path. Poppler rendered physical pages 202–266 at 96 dpi. Those 65 pages were inspected in eight legible contact sheets. This covers the end of Exposé III, its bibliography, the complete Exposé IV, and the Exposé IV bibliography.

The exact boundary is:

- physical page 202: late Exposé III;
- physical page 203: final Exposé III bibliography page;
- physical page 204: Exposé IV opening;
- physical page 266: Exposé IV close and bibliography.

The earlier working locator that described physical page 203 as the Exposé IV opening was therefore off by one; the evidence and this receipt use the corrected physical-page boundary.

Ten pages were also inspected at 180 dpi:

- 202: late Exposé III boundary;
- 203: final Exposé III bibliography;
- 204: Exposé IV opening;
- 226: repaired diagram `DIAG-0034`;
- 229: repaired diagram `DIAG-0039`;
- 242: repaired diagram `DIAG-0059`;
- 257: repaired diagram `DIAG-0074`;
- 258: repaired diagram `DIAG-0077`;
- 265: retained correction/disclosure for `DIAG-0084`;
- 266: Exposé IV closing page and bibliography.

## Result

PASS for the inspected final-linked layout.

- All 65 rendered boundary/Exposé-IV pages are present and nonblank.
- No visible clipping, page-edge loss, text collision, broken formula, or missing diagram was found.
- The five reconstructed degraded diagrams are legible, retain their required objects/arrows/labels, and do not collide with prose.
- The disclosed `DIAG-0084` square and its source note are visible and legible.
- The Exposé III-to-IV transition and the end of Exposé IV are orderly.

This visual receipt establishes rendered-layout quality only. Reference destinations/actions, font types, normalized text equality, and build diagnostics are controlled separately by `control/reference_pdf_action_audit_post_loop2_r2`. It does not certify Exposé V or later, and it is not a claim that the whole SGA3 reader is complete.
