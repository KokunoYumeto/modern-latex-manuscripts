# Build instructions

Run XeLaTeX from the `source` directory on:

`SGA3_English_Full_Volume_Native_Cumulative.tex`

The converged producer build used repeated XeLaTeX passes.  The packaged PDF
then received the deterministic convention-v2 named-destination overlay
described by `reference/SYNCTEX_TARGET_DESTINATIONS.csv` and
`reference/PDF_NAMES_TREE_OVERLAY_REPLAY.csv`.

The authoritative packaged-reader identity is recorded in
`FINAL_PACKAGE_VALIDATION.json`.  A plain TeX rebuild verifies editable
content and existing links; byte-identical reconstruction of the final PDF
also requires replaying the named-destination overlay.
