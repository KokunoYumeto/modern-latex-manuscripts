# Status

Status: **PASS — final local package**

- editable source files: 914
- editable source bytes: 5516236
- PDF pages: 1,482
- PDF bytes: 12002055
- PDF SHA-256: `8AEC2FAD878CB1AE4DCDCB128B8E66332D674531D383BC5A68568F5E8C635D22`
- reference candidates: 23880
- internal edges: 10498
- structural declarations: 4586
- residual/nonedges: 8796
- physical target actions/coordinates: 3744/3744
- internal PDF GoTo actions: 12,492; broken: 0
- active raster calls/PDF image objects: 0/0
- embedded font resources: 63; Type 3: 0
- lead layout sample: 24/24 PASS at 600 dpi

The 600-dpi page sample is layout evidence only.  Transcription and diagram
authority decisions use direct source images at approximately 5,000 dpi,
escalating to approximately 9,000 dpi for ambiguity.

No archive handoff, publication, DOI, or public readback is claimed.
