# SGA 3 R29 reference and QA controls

This optional archive groups the producer reference graph, native-diagram QA controls, and the clean-reader rebuild/SyncTeX/destination-overlay receipts. It is evidence for the current reader, not material a reader must download. The cumulative PDF and complete buildable TeX are in the earlier reader/source ZIP.
