# SGA 3 English reader and buildable TeX

This archive contains the complete cumulative English reader PDF and its complete native-TeX build closure. Run XeLaTeX four times on `source/SGA3_English_Master.tex`. The direct PDF is the preferred reading object. Production notes are retained only in non-rendering `\SGAArchiveOnly{...}` blocks. Rights and provenance caveats are in `RIGHTS_AND_PROVENANCE.md`.
