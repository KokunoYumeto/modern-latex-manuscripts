# English — SGA 3 Translation Reconstruction

## Durable objective

Reconstruct and complete the SGA 3 English reader from the best available OCR
and English prose comparison lineage, while taking every formula, number,
footnote, and diagram from the current Polo--Gille PDF witness. Loop 1 produces
a complete English TeX/PDF reader with PDF-derived PNG diagrams. Loop 2 replaces
those images with native LaTeX diagrams. Jacob Reinhold's English Markdown is
comparison material and must receive appropriate credit wherever reused.

This task is SGA 3 only. SGA 2 is complete and closed; SGA 4 and SGA 4½ belong
to other lanes.

## Current state — 2026-07-23

- Integrated continuous body: Editorial Notice and Introduction, all of
  Exposé I, all of Exposé II, and all of Exposé III through §4.38 and its
  bibliography.
- Current integrated source cursor: end of Exposé III, component-local PDF
  page 77 (combined-reader page 187; re-edition page 177). Component-local
  page 78 / combined-reader page 188 is the trailing blank verso.
- Current master: `tex/SGA3_English_Loop1.tex`.
- Current build: `build/SGA3_English_Loop1.pdf`, 200 A4 pages, SHA-256
  `949EC8B60FB67BA6181610EC7221B7171BA2C3C105EE9F2243146AA6F458226B`.
  Master TeX SHA-256:
  `027BFDFB648E9636E60B6240EDBF2F17703349912DF706C9EF0994C1A73AE497`.
- Latest compile: two-pass `pdflatex` success; no errors or overfull boxes and
  only five harmless underfull-box diagnostics. The latest seven-page master
  tail is rendered at `qa/master_expose_III_complete_20260723`;
  contact-sheet SHA-256
  `E27E3F308DD9391E216CD373652E840D4AAB383F47BA2DCA85A77CF94A9389AB`.
- Exposé III components 15--32 are integrated continuously; Exposé III is
  complete at the translation/reconstruction layer. The exhaustive clickable-
  reference convention-v2 retrofit is a separate release gate now in
  progress, so this cumulative reader is not yet promoted as reference-
  complete.
- The complete-through-Exposé-II custody checkpoint is frozen separately at
  `checkpoint/expose_II_complete_20260722`; its 102-row closed manifest is
  `SHA256SUMS.csv`, SHA-256
  `E142ECB264B05AF7E782E3A98EF92A512113AE23F2BD2F9A48447E1544A25EB0`.
  Its successor path was sent to archive maintenance because the live master
  correctly continued changing after the first handoff.
- Standing delegated-QA rule: intermittently sample delegated prose and
  mathematics against the controlling PDF, the declared Reinhold comparison,
  and adjacent lead-written translation. Weak work is corrected or redone, not
  silently integrated. The first recorded sample covered component 09,
  Definition 6.1, Proposition 6.4.1, Remark 6.8.4, and Proposition 6.8.6; no
  material register or fidelity degradation was found. Two deliberate,
  source-disclosed mathematical normalizations were retained: `H\times_S X`
  in 6.8.4 and `N_{Y/X}\otimes\mathcal O_{Y'}` in 6.8.6.
  Independent lead samples of delegated Exposé II components 11--13 covered
  Proposition 3.4, Lemma 3.10, Corollary 3.11.1, right translation and crossed
  homomorphisms in §4, Corollary 4.2.3, Lemma 4.6.2, and Remark 4.11.4. No
  material degradation was found. Three transparent mathematical corrections
  were retained against the printed/comparison wording: `Lie(Y/S,M)` rather
  than the ill-typed `Lie(X/S,M)`, `End(F)` rather than `Aut(F)` in the
  Proposition 4.8 proof, and the two component-09 normalizations above.
  Exposé III sampling covered Theorem 0.1.8 and Corollary 0.1.10 in component
  16, Corollary 0.7 in component 18, the group-action identities in component
  19, and Proposition 0.11 / Remark 0.14 in component 20. Component 18's
  initially weaker statement styling was corrected before integration, and
  component 19 retained the PDF-authoritative (P((m,m')\cdot(x,x'))) term
  omitted by Reinhold. No material remaining degradation was found.
  Component 21's three-way review found a genuine logical-quantifier weakness
  in the delegated prose at Proposition 1.2.4: the existence of a splitting
  section had been phrased pointwise. The lead rewrote it with explicit
  existential quantification before integration; the corrected component is
  SHA-256
  `07B1B7076C03D8D0B322AF61CE32850FA258EE7AC754E7D7F6BCFE9202DE37A7`.
  Component 23's review likewise caught mechanical inline-math damage, an
  unnamed complex `C`, and an omitted transition from Lemma 2.7 to Corollary
  2.8. All were corrected before acceptance. Theorem 2.1, Remark 2.3, Lemma
  2.7, and Corollaries 2.11--2.14 then passed the PDF/Reinhold/lead-register
  comparison; the six-page render contact SHA-256 is
  `5A63CC25726D95387E38CC290E854ABEE5C012C506419E595AF5534330F7A2C6`.
  Component 22's lead check sampled Lemma 1.3.4, Proposition 1.3.6, both
  source-derived diagrams, and the cohomological conclusion against the PDF,
  Reinhold, and component 23. It found and fixed only a punctuation-order typo;
  no material register or formula weakness remained. The English retains the
  mathematically required `Y` in Proposition 1.3.6(ii), with the PDF's printed
  `G` treated as a transparent local typo because the setup, proof, and
  comparison all use `Y`. Final component-22 TeX SHA-256 is
  `A95A5189B00F4B4D15920343BAF484F79783FC788CFBE4A18B0E4E5C934F7834`.
  Component 24's lead review sampled Proposition 3.3, Theorem 3.5, and
  Corollary 3.10 against the PDF, Reinhold, and component 23. It retained the
  mathematically required `X_0=X\times_S S_0` in place of the PDF's local
  `X\times_X S_0`, and corrected one malformed inline-math boundary before
  integration. Final component-24 TeX SHA-256 is
  `FBB12C7F9D29C55B62DC64849D3BC97F9867B701AD7BBD4421CAFCB05A7A315A`.
  Component 25 then passed both the producer's three-way comparison and a
  separate read-only audit of Lemma 4.1, Proposition 4.2's diagrams,
  Proposition 4.3, Corollary 4.4, Complement 4.4.1, and all seven authority-
  derived diagram crops. No material prose, formula, sign, or register defect
  remained. Final component-25 TeX SHA-256 is
  `47D07455AB2668329093646CD1DB7CCDFE05745F41F7D5FD908948B3B9694C6A`.
  Component 26's lead review covered Proposition 4.5, the Koszul definitions
  and bicomplex, Lemmas 4.6.3--4.6.4, Proposition 4.6.5, and Remark 4.6.6.
  The source-derived bicomplex is complete and legible. The target restores
  the lift `XZ-YT+\lambda\varepsilon`, matching the polynomial actually being
  lifted, and visibly records the PDF's inconsistent `XY-ZT` reading. No
  remaining mathematical or register weakness was found. A subsequent lead
  locator check corrected comments from an erroneous original-page range to
  the actual side-pages 131--132; body and rendering were unchanged. Final
  component-26 TeX SHA-256 is
  `EF22C2F972BC7BDAF088A317A2C96212F645F98190A960D9BEAA80DD824C9AFF`.
  Component 27's producer and lead reviews sampled Remark 4.8.0, all three
  parts and proofs of Proposition 4.8, Remark 4.9, the four authority-derived
  diagrams, and the local obstruction formulas against the PDF, Reinhold,
  and component 24. The lead corrected the original-side-page envelope to
  133--136 and made explicit that `S'` is a closed subscheme of `S`; no
  remaining formula or register defect was found. Final component-27 TeX
  SHA-256 is
  `7D2A21373D20C728DF307A580DBE5A9F13F229026E2B94C51E5DAE56BC9A96E2`.
  Component 28's lead review sampled Lemma 4.12, Proposition 4.13,
  Proposition 4.15, Definition 4.16.1, and all thirteen PDF-derived diagrams.
  It corrected one material base-space error (`Y_J` is locally complete
  intersection in `X_J`, not `X`) and retained the PDF-authoritative bold
  `\mathbf n_{Y_0/X_0}` after a high-resolution source check. Final C28 TeX
  SHA-256 is
  `A6B2E5AE4E672C34B619A723DE93EB6CAC861CFE635BA159ADE9EAF3FD31DEFC`.
  Component 29 was then normalized to the same bold symbol and the source's
  adjacent-letter obstruction notation `DY`; Lemma 4.17, the three proofs,
  Theorem 4.21, Remark 4.22, all four diagrams, and signs/tags (1)--(5)
  passed the source/Reinhold/lead-register comparison. Final C29 TeX SHA-256
  is `41F1818FB373767E511B5FE4AE9587FBED1D006DD6A90C8A222E58360B4D4EFC`.
  Component 30's producer and lead checks covered Lemmas 4.25 and 4.27,
  Corollaries 4.28--4.30, both exact-complex diagrams, all boundary-map
  superscripts and signs, and the source's `Y_0\times_S Y_0` and
  `\overline D_0` notation. Corollary 4.28 uses the mathematically required
  ambient `X` and visibly records that the French re-edition prints undefined
  `G`. Final C30 TeX SHA-256 is
  `C45C1C25A10A2865C556A78EA8227A8238A3A422D2309DA9EB36CC30237CF8BF`.
  Component 31's three-way review covered Corollaries 4.31--4.34, the locally
  split sequence and cochain diagram in 4.35, and Proposition 4.35.1. It
  restored the PDF-authoritative `\mathscr F_0`, `\mathscr K`, `\mathscr R`,
  and the bar on `\overline{\delta(Y,Y_1)}`, while preserving the distinction
  between cocycles and their cohomology classes. Final C31 TeX SHA-256 is
  `A54480FE29ACEFC296295C3ECB77767D84D43DEFB8B6FC63F3F51C6DFE9AB3F4`.
  Component 32's producer and lead checks covered Proposition 4.36,
  Corollary 4.37, every term and boundary map in 4.38's exact cohomology
  sequence, items (a)--(g) and (1)--(5), and the bibliography. In item (4),
  the English uses `\mathbf n^\vee_{K_0/G_0}` in the three places where the
  French re-edition retains stale `X_0` and omits the dual; a visible source
  note records that correction. Final C32 TeX SHA-256 is
  `EEDE81640E90596C10098AB7E1D2F7423E0596A3854545B943BCB1120722AA21`.

## Source roles

- Authority: `SGA3_Polo_Gille_current_complete_reader_20260718.pdf`, SHA-256
  `B0984B5BF322A88AB455709578E4E41EB43D6E1C91931282CFEE64F2C1F69BE2`.
- Drafting locator: frozen `ocr_fo` force-OCR generation. It is not authority.
- English comparison: Jacob Reinhold, `jcreinhold/sga`, acquired lineage
  `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`; LLM-generated Markdown,
  translation contribution declared CC BY 4.0, not mathematical authority.

The current Polo--Gille public component set supplies its tables of contents,
editorial introduction, Exposés, indices, and separate errata sheets. Any
front-matter pages absent from that public component envelope remain a source
acquisition gap and are not silently represented as translated.

## Post-SGA3 routing

After both SGA3 loops are complete, the next handoff preflight is to locate and
assess the reported EGA OCR already somewhere in the workspace. That work does
not begin while SGA3 remains active.

## Frozen multi-task division — 2026-07-23

- This lead task retains all of Exposé III, including active components
  30--32 through the bibliography.
- Exact current ordered continuation: component 30 begins at §4.23 on local
  PDF page 67; component 31 begins at Corollary 4.31 on local page 71; and
  component 32 begins at Proposition 4.36 on local page 73. Components
  24--29 are integrated through Remark 4.22.
- No Exposé IV worker is active in this task. The completed former SGA4-proper
  lane is therefore cleared to claim all of Exposé IV from its opening page.
- No later Exposé is assigned by this acknowledgement.
