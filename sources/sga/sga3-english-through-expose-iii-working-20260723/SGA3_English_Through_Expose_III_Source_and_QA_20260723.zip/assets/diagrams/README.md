# Loop-1 diagram images

This directory may hold temporary PNG reproductions of diagrams from the
controlling Polo-Gille PDF. Images are a deliberate Loop-1 device: they keep
the complete translation readable while the native LaTeX diagram layer is
deferred to Loop 2.

Each image must retain a stable diagram identifier and an exact source-page
locator in the component TeX. Loop 2 replaces the image with native diagram
code and checks the result against the same PDF page.

