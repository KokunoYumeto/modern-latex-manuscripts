# License and attribution — SGA 3 Exposé VII

The controlling French sources are the corrected Polo–Gille re-edition PDFs
`Exp7A-13oct24.pdf` and `Exp7B-13oct24.pdf`. They are identified in
`README.md` but are not redistributed in this checkpoint.

Jacob Reinhold's English Markdown translation was used as a credited
comparison and drafting lineage:

- author: Jacob Reinhold;
- repository: <https://github.com/jcreinhold/sga>;
- revision: `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- VIIA SHA-256 `AED6CCC5A778FE431C3235F3566F4B362DEEAB8F7F0596D6A9335AFA48E037E1`;
- VIIB SHA-256 `D5BF8BED7B6217AF6F072BBE8B1032C5FE6D656A8980CEAC6927020C4CD1433C`;
- declared license for that translation lineage: CC BY 4.0.

Reinhold's material is not the controlling source and is not independent
source corroboration.

The underlying French-source rights are not granted by this checkpoint. The
native diagram reconstructions do not purport to broaden rights in the
underlying edition. Any later publication must preserve this attribution and
caveat and must not describe this bounded Exposé-VII checkpoint as the complete
SGA 3 volume or as a critical edition.
