# SGA 3 Exposé VII — high-zoom native-diagram successor

This bounded checkpoint contains the English Exposé-VII reader with all 135
diagrams delivered as native TikZ/TikZ-cd sources. It supersedes earlier
300-dpi-only fidelity approvals for these diagrams; it does not claim that the
whole SGA 3 cumulative reader has completed its final reference-v2 or release
gate.

## Source and translation lineage

The controlling sources are the Polo–Gille re-edition PDFs:

- `Exp7A-13oct24.pdf`: 60 pages, 596,394 bytes,
  SHA-256 `D46DB8C79D0385643B6EED4B96900613248375F9B73B4202478A4F57FD3E8522`;
- `Exp7B-13oct24.pdf`: 99 pages, 990,954 bytes,
  SHA-256 `D303690E0195654BBE7C3DAA5D89EA23E24CD709A3575217234AC19AE8836694`.

The authority PDFs are identified but not redistributed here. No editable
Polo–Gille LaTeX source was publicly available when this reconstruction was
made, so formulas and diagrams were reconstructed from the PDFs.

Jacob Reinhold's English Markdown was used as a credited comparison and
drafting lineage:

- author: Jacob Reinhold;
- repository: <https://github.com/jcreinhold/sga>;
- revision: `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- VIIA file `07A-infinitesimal-study-differential-operators.md`, 192,617
  bytes, SHA-256 `AED6CCC5A778FE431C3235F3566F4B362DEEAB8F7F0596D6A9335AFA48E037E1`;
- VIIB file `07B-infinitesimal-study-formal-groups.md`, 329,609
  bytes, SHA-256 `D5BF8BED7B6217AF6F072BBE8B1032C5FE6D656A8980CEAC6927020C4CD1433C`;
- declared translation license: CC BY 4.0.

Reinhold's Markdown is comparison/drafting lineage, not the source authority
or independent source corroboration.

## Reader identities

- master: `tex/SGA3_Expose_VII_English_Loop2.tex`,
  8,771 bytes, SHA-256 `B3694FEEA9770FD45CC8301A5A6739C9B0831E5F3EED237B4A2CC9ED3F6991BB`;
- PDF: `build/SGA3_Expose_VII_English_Loop2.pdf`, 208 pages,
  980,608 bytes, SHA-256 `FF96CE59AC0068F520F29C5AAD370ADE637D81C2AC6B2C747C5CE9E80E95AE6B`;
- editable source manifest: 233 rows, SHA-256
  `E56227C00722454912FCCFB4F944EFEE5FCADC99700706550C14EC151CD45CD5`;
- canonical editable-source tree digest: `791C5137DE26B0B257F34639605417701BA4F42C7DB04FF06E258A51A0DA6219`.

## Diagram and layout gates

- 135/135 native diagram sources and 135/135 unique native invocations;
- zero `includegraphics` calls and zero PDF image objects;
- all 135 diagrams manually compared by the lead against direct authority
  crops at 5,000 dpi;
- diagrams 019, 028, 040, 046, 049, 107, 108, 126, 127, and 128 corrected
  and rechecked at 5,000 dpi;
- 22 changed/adjacent reader pages checked at 600 dpi for integration layout,
  clipping, overlap, and seams after fidelity had already been decided at
  5,000 dpi;
- 208/208 PDF pages contain extractable text;
- 312 internal named actions and zero broken
  internal actions.

The 600-dpi page ledger is layout-only evidence. It does not substitute for
the separate 5,000-dpi diagram-fidelity ledger. Earlier 600/1,200-dpi evidence
remains valid history/context; 300-dpi-only fidelity approval is insufficient.

## Build

Run XeLaTeX from this projection root so `tex/components` and
`native_diagrams/exp7` resolve as packaged. The privacy-clean build summary is
`build/SGA3_Expose_VII_English_Loop2_BUILD_PUBLIC.log`.

Authority crops, OCR, source-derived raster witnesses, private paths, raw logs,
temporary renders, and the accidental non-adjudicative `$out` subtree are
intentionally excluded.
