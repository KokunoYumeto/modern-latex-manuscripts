# Publication caveats

- This is a bounded Exposé-VII native-diagram successor, not the complete SGA 3 volume.
- The Polo–Gille PDFs control the source and are not redistributed.
- No public editor LaTeX source was available when the reconstruction was made.
- Reinhold's CC BY 4.0 Markdown is credited comparison/drafting lineage.
- Delivered diagrams are native TeX only. Source crops, OCR, PNG witnesses,
  private paths, temporary renders, and raw build logs are excluded.
- Standalone links are technically closed; full cumulative reference-v2
  coordinates and residual classification must be regenerated after integration.
- The PDF is not claimed to be tagged or fully accessibility-remediated.
- Publication, DOI mutation, archive dispatch, and public readback are not claimed here.
