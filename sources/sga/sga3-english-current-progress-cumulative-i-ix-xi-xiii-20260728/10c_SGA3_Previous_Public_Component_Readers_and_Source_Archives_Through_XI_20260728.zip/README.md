# Previous public SGA 3 component archive

This directory preserves the exact SGA 3 files read back from Zenodo record
21631485 before the 2026-07-28 compact-reader update.

The component readers, direct master files, rights-blocked witness ledgers, and
source/QA archives remain immutable historical and scholarly evidence. They are
grouped here so the Zenodo landing surface can place one cumulative
current-progress reader first without discarding any prior public bytes.

These files do not collectively claim complete SGA 3 coverage. The cumulative
reader that supersedes them as the preferred reading surface contains the
available English work for Exposes I-IX, XI, and XIII, with visible gap pages
for X and XII and an explicit unfinished-state notice for VII.

`PREVIOUS_PUBLIC_SGA3_SHA256.csv` records the exact filename, byte count, and
SHA-256 identity of every preserved Zenodo file in this archive.
