# SGA 4 proper English source bundle

This bundle contains the cumulative English LaTeX source for SGA 4 proper,
Exposés I–XIX including Exposé V bis. It excludes SGA 4½.

The controlling French text is the frozen Orgogozo TeX snapshot at commit
`71766d9`. The archive SHA-256 is
`DA2D939D3BD66B03E7BEFF4353550F7A27982847AE4F798D0872F1DB5D64C7DC`.

## Build

XeLaTeX is required because the included Xy-pic material is not rendered
correctly by the LuaLaTeX compatibility route used during diagnosis.

From `source/tomes`, run three times:

```text
xelatex -interaction=nonstopmode -halt-on-error SGA4_English_translation_workpass.tex
```

The validated release build has 864 pages. The source tree contains exactly
300 files: 271 `.texfrag`, 24 `.tex`, 3 `.cls`, 1 `.sty`, and 1 `.bib`.
`SOURCE_FILE_MANIFEST.csv` records the exact source hashes and action counts.

## Rights and status

Read `RIGHTS_AND_PROVENANCE.md` before reuse. No license grant is asserted for
the underlying French text, the English translation, or third-party TeX
support files. This is a source-controlled working edition, not a claim of a
new critical edition.

The source preserves 19 inherited `XXX` strings only inside TeX comments.
None appears in the rendered PDF. Their exact disposition is included in the
separate QA evidence bundle.
