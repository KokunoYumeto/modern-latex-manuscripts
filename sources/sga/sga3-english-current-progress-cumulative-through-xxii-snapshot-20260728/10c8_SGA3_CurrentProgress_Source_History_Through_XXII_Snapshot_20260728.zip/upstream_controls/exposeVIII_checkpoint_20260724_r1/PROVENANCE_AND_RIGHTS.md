# SGA 3 Exposé VIII English checkpoint — provenance and rights

## Scope

This package contains the English reconstruction of **Exposé VIII only**,
from its title page through Remark 7.13, bibliography, and terminal notes.
It stops before Exposé IX. It is **not the whole of SGA 3**, and it does not
claim that the cumulative SGA 3 English reader is complete.

## Controlling source

The text, formulas, numbering, notes, page order, and diagrams were checked
against the Polo–Gille PDF `Exp8-8nov09.pdf`:

- 30 A4 pages;
- 440,912 bytes;
- SHA-256
  `06E43E0571D411CC5579975778FCC03C8ECAA67189248D1A053E61DC653AF510`;
- complete-reader pages 617–646.

The Polo–Gille PDF is the authority and page locator for this reconstruction.
It is **not recovered editor TeX**. No authority PDF or scan is included in
this checkpoint.

OCR is not authority. OCR output was not admitted as a translation substrate
or as evidence for formulas.

## English comparison control

Jacob C. Reinhold's `08-diagonalizable-groups.md` was used as credited
comparison material only and is not authority or independent corroboration:

- 93,914 bytes;
- SHA-256
  `0F40998343EF83A68FFABE585262F8C64E415AF0DF9468C425AEA59B97FE73F3`;
- acquired from commit
  `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`.

That contributor declares CC BY 4.0 for the English translation contribution,
while excluding underlying French rights. This attribution is recorded
without treating the comparison as source evidence.

## Rights statement

No license grant is asserted by this package for the underlying French text,
the English reconstruction, editorial additions, or third-party TeX support.
Rights remain with their respective holders. The comparison's declared
CC BY 4.0 terms are **no broader license** for the French source, this
independently revised reconstruction, or the package as a whole.

Redistribution rights are not asserted. Preservation metadata, source
attribution, checksums, and technical validation do not by themselves confer
permission to reproduce or redistribute copyrighted material. This is a
provenance and package-scope statement, not legal advice.

The package contains no source scan, OCR body, private path, raw build cache,
or internal task conversation.
