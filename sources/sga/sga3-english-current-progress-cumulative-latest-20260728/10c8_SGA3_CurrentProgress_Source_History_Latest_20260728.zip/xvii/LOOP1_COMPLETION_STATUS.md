# SGA 3 Exposé XVII — English Loop 1

- Allocation: Session B, entire Exposé XVII only.
- Authority: `Expo17.pdf`, 50 A4 pages, SHA-256 `687F333C4F86221E7898F44C1706845D8E0B79AF50AB31F3ED9A3B0F696AE25B`.
- Authority envelope: standalone local pp. 1–50; combined-reader pp. 963–1012.
- Hard stop: before Exposé XVIII, combined-reader p. 1013.
- Comparison-only drafting witness: `17-unipotent-algebraic-groups-extensions.md`, SHA-256 `944F946E4A5B2B9EE16338C34A114FE6CA443AC70B15E65AFA5C3E4D5A825BE3`.
- Loop-1 coverage: complete through the end of Appendix III on authority local p. 49 / combined p. 1011 / printed p. 631. Authority local p. 50 / combined p. 1012 is blank. No Exposé XVIII material is included.
- Final component: `tex/components/37_expose_XVII_appendixC_sections2_through5_and_end_pages047_049.tex`, 9,351 bytes, SHA-256 `E6E0E2C82C61512947ED68E8943B733E1DCEC957D787FBA502A260A76B14ADF5`.
- Current master: `tex/SGA3_Expose_XVII_English.tex`, 4,178 bytes, SHA-256 `6167501EAD3A9E447BE7CE0B3C4075B232969ADC1D81EDB269AAEE4B761A20A8`.
- Current build: `build_loop1_complete_exposeXVII_r31/SGA3_Expose_XVII_English.pdf`, 57 A4 pages, 761,898 bytes, SHA-256 `85448B0830DE96823C5C22B9C82B415DB4323EB8A761115EC160E4678B34210D`.
- Build gate: two-pass `pdflatex` succeeds with zero errors and zero undefined references. One visually harmless 1.55 pt overfull box remains in a Greenberg citation line.
- Tail QA: English PDF pp. 52–57 rendered and reviewed. The final source diagram was read from direct 2400-DPI authority bands and targeted 5000-DPI crops; its nodes, six directed arrows, labels, label sides, and surrounding formulas were reproduced in native `tikzcd`.
- Method: lead-session manual page-by-page authority review; existing OCR and external English are locator/drafting witnesses only.
- Session-B Loop-2 diagram ownership: every diagram in Exposés IV, VIII, IX, XI, XIII, XV, and XVII; all other exposés excluded. Exact control: `..\sga3_sessionB_owned_diagrams_loop2_successor_20260728\DIAGRAM_OWNERSHIP_AND_LOOP2_SCOPE.md`, 3,425 bytes, SHA-256 `C813B8B4086CDD141A829EAB71C61E84338334B083ABC5ED2E848130AEACC58F`.
- Next disjoint Loop-1 queue item: Exposé XIX under the corrected three-session routing. Exposé XVIII remains owned elsewhere and untouched.
