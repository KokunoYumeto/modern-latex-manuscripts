# SGA 4 proper English reader — final public QA evidence

This privacy-clean bundle supports the 864-page cumulative English reader for
SGA 4 proper, Exposés I–XIX including V bis and excluding SGA 4½.

The controlling final identities are:

- source generation r7: 300 files; canonical tree SHA-256
  `AE306A05563020D4996679269C52EDFC80EBB0861A10CBC31CB581D71A90C92D`;
- reader PDF: 4,421,240 bytes; SHA-256
  `A4057C39E5BF54AD12E7B2E5DBBACA884B9738F376B3418E8D97EDAB4E3A88B2`;
- complete graph r5: 8,701 candidates, 3,388 targets, 6,114 edges,
  8,701 exhaustive disposition rows, and 116 supplemental source records;
- graph validation SHA-256
  `E8CC17A1A30BAF7D461184AED6280F21C728113E5820D570006DBC143C5F161E`.

## Evidence layout

- `reference_v2/complete_graph_r5/`: the complete co-current candidate,
  target, edge, residual, source-closure, AUX-binding, classifier, correction,
  schema, revision, validation, and checksum records;
- `reference_v2/complete_graph_r5_independent_pass/`: the independent 5,998-row
  linked-candidate join replay and two-row correction replay;
- `reference_v2/graph_set_relation_audit_r5/`: an independently replayed
  8,701-row candidate/disposition proof and 6,114-row edge-partition proof;
- `r7_source_pdf_evidence/`: exact r7 source, AUX, PDF, graph-group, raster,
  and freeze evidence;
- `build/`: fresh extracted-source three-pass build and all-page equivalence
  results;
- `visual_final/`: final Poppler contact sheets and visual PASS receipt;
- `source/`: exact final public source manifest.

`REFERENCE_CANDIDATES.csv` is the complete source-visible occurrence universe.
`REFERENCE_RESIDUALS.csv` is an exhaustive one-row-per-candidate disposition
projection, not an unresolved-only set. Thus all 8,701 unique candidate IDs
and occurrence keys map bijectively to 8,701 residual rows. The 5,998 linked
candidates each have exactly one candidate-bound edge and a residual marked
`closed_internal_edge`; the other 2,703 candidates have a
`closed_positive_nonedge` disposition and no candidate-bound edge. The 116
supplemental source records each own one disjoint supplemental edge, proving
the full edge partition `5,998 + 116 = 6,114`. No occurrence is omitted,
duplicated, or simultaneously active contrary to this schema. All forty
legacy-label AUX bindings resolve to stable semantic destinations.

Raw local logs, original scans, restricted print witnesses, superseded package
evidence, workstation paths, and internal task conversation are excluded. All
packaged CSV cells pass the formula-safety gate. No license grant is asserted;
read `RIGHTS_AND_PROVENANCE.md`.

This is release evidence for local custody. It does not claim archive
acceptance, publication, or public readback.
