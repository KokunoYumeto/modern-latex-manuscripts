# Independent SGA4 convention-v2 graph r5 audit

Status: **PASS**.

This receipt independently replays the corrected complete-public graph
`complete_public_graph_r5_source_r7_20260723` against its rejected r4
predecessor and the frozen r7 source/PDF/AUX identities.

Verified closure:

- exact 15-file graph set and its self-excluding 14-row graph manifest;
- 8,701 candidates, 8,701 residuals, 3,388 targets, and 6,114 edges;
- all 5,998 linked candidates have one residual and one unique edge, with
  identical target ID, target kind, LaTeX label, PDF destination, and source
  action across the applicable records;
- all target, candidate-source, supplemental-source, and source-action foreign
  keys close;
- the only r4-to-r5 final-state corrections are candidates `000976` and
  `001007`, and both correction rows replay their old and new values exactly;
- 300/300 r7 source files, the 864-page PDF, and the AUX identity close;
- all 40 direct legacy-label AUX bindings and all 2,119 PDF destination groups
  pass;
- all CSV, JSON, and JSONL controls parse; CSVs are rectangular and
  formula-safe; the graph and this receipt contain no detected private local
  paths or workflow identifiers.

`INDEPENDENT_LINKED_JOIN_REPLAY.csv` is the complete 5,998-row join replay.
`INDEPENDENT_CORRECTION_REPLAY.csv` is the complete two-row supersession
replay. `INDEPENDENT_GRAPH_R5_AUDIT_PASS.json` is the machine summary.

This PASS covers the frozen graph/source/PDF identities. Release-package
extraction, archive acceptance, publication, and public readback are separate
gates.
