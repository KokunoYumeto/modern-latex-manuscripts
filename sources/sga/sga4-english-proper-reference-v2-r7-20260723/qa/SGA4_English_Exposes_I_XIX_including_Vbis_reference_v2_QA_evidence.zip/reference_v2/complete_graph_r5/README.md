# SGA4 proper convention-v2 complete public graph

Status: **PASS**.

This graph is pinned to the frozen 8,701 source-visible candidate universe and the supplied no-overwrite final source/PDF successor. It replaces the defective post-wrapper 8,818-candidate inventory and the independently rejected graph-r4 projection.

- candidates: 8701
- semantic targets: 3388
- internal edges: 6114
- supplemental source records: 116
- direct legacy-label AUX bindings: 40
- linked candidate/residual/unique-edge invariants: 5998
- append-only graph corrections: 2
- PDF pages: 864
- PDF SHA-256: `A4057C39E5BF54AD12E7B2E5DBBACA884B9738F376B3418E8D97EDAB4E3A88B2`

The five rejected Appendix adjudication regressions and the two cross-table corrections are preserved explicitly.  Applied local source links take precedence.  No source or PDF bytes are stored in this graph directory.
