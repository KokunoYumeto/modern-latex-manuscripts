# SGA 4 convention-v2 graph set relation

Status: **PASS**.

`REFERENCE_CANDIDATES.csv` is the complete source-visible occurrence universe, not an unresolved-only list. `REFERENCE_RESIDUALS.csv` is an exhaustive disposition projection with exactly one row for every candidate. A linked candidate therefore intentionally has both one active edge and one residual row marked `closed_internal_edge`; this is not double activity. A positive nonedge has one residual row marked `closed_positive_nonedge` and no candidate-bound edge.

The replay proves:

- 8,701 unique candidate IDs and unique occurrence keys;
- a bijection to 8,701 residual disposition rows;
- 5,998 linked candidates, each with exactly one candidate-bound edge;
- 2,703 nonlinked dispositions with zero candidate-bound edges;
- 116 supplemental source records, each with exactly one disjoint supplemental edge;
- total edges: 5,998 + 116 = 6,114;
- unique edge/target/supplemental IDs and closed foreign keys;
- no omitted, duplicated, or schema-conflicting occurrence.

The two replay CSVs serialize every candidate and every edge. `GRAPH_SET_RELATION_AUDIT.json` records the machine checks and exact input hashes.
