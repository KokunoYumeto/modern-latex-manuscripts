#!/usr/bin/env python3
"""Prove the exhaustive SGA4 convention-v2 graph set relation."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable


FORMULA_RE = re.compile(r"^\s*[=+\-@]")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def safe_cell(value: Any) -> str:
    text = "" if value is None else str(value)
    return "'" + text if FORMULA_RE.match(text) else text


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty CSV: {path.name}")
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: safe_cell(row.get(key, "")) for key in fields})


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def unique(values: Iterable[str]) -> bool:
    materialized = list(values)
    return len(materialized) == len(set(materialized))


def occurrence_key(row: dict[str, str]) -> str:
    fields = (
        row["source_file"],
        row["source_line_preapplication"],
        row["source_column_1based_preapplication"],
        row["pattern_kind"],
        row["visible_reference_tex"],
    )
    return sha256_bytes("\x1f".join(fields).encode("utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--graph-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    graph_root = args.graph_root.resolve()
    output_root = args.output_root.resolve()
    if output_root.exists():
        raise SystemExit(f"refusing overwrite: {output_root}")
    output_root.mkdir(parents=True)

    input_names = (
        "REFERENCE_CANDIDATES.csv",
        "REFERENCE_RESIDUALS.csv",
        "REFERENCE_EDGES.csv",
        "REFERENCE_TARGETS.csv",
        "SUPPLEMENTAL_SOURCE_REFERENCES.csv",
        "GRAPH_SCHEMA.json",
        "VALIDATION.json",
    )
    input_paths = {name: graph_root / name for name in input_names}
    missing = [name for name, path in input_paths.items() if not path.is_file()]
    if missing:
        raise SystemExit(f"missing graph inputs: {missing}")

    candidates = read_csv(input_paths["REFERENCE_CANDIDATES.csv"])
    residuals = read_csv(input_paths["REFERENCE_RESIDUALS.csv"])
    edges = read_csv(input_paths["REFERENCE_EDGES.csv"])
    targets = read_csv(input_paths["REFERENCE_TARGETS.csv"])
    supplemental = read_csv(input_paths["SUPPLEMENTAL_SOURCE_REFERENCES.csv"])

    errors: list[str] = []
    candidate_ids = [row["candidate_id"] for row in candidates]
    residual_ids = [row["residual_id"] for row in residuals]
    residual_candidate_ids = [row["candidate_id"] for row in residuals]
    edge_ids = [row["edge_id"] for row in edges]
    target_ids = [row["target_id"] for row in targets]
    supplemental_ids = [
        row["supplemental_source_record_id"] for row in supplemental
    ]
    occurrence_keys = [occurrence_key(row) for row in candidates]

    uniqueness_checks = {
        "candidate_ids_unique": unique(candidate_ids),
        "candidate_occurrence_keys_unique": unique(occurrence_keys),
        "residual_ids_unique": unique(residual_ids),
        "residual_candidate_ids_unique": unique(residual_candidate_ids),
        "edge_ids_unique": unique(edge_ids),
        "target_ids_unique": unique(target_ids),
        "supplemental_source_ids_unique": unique(supplemental_ids),
    }
    for name, passed in uniqueness_checks.items():
        if not passed:
            errors.append(name)

    candidate_by_id = {row["candidate_id"]: row for row in candidates}
    residual_by_candidate = {row["candidate_id"]: row for row in residuals}
    target_id_set = set(target_ids)
    supplemental_id_set = set(supplemental_ids)

    candidate_edges: dict[str, list[dict[str, str]]] = defaultdict(list)
    supplemental_edges: dict[str, list[dict[str, str]]] = defaultdict(list)
    invalid_edge_source_types: list[str] = []
    edge_replay: list[dict[str, Any]] = []
    for edge in edges:
        source_type = edge["source_record_type"]
        if source_type == "frozen_candidate":
            candidate_edges[edge["candidate_id"]].append(edge)
            bucket = "candidate_bound_edge"
            source_fk_ok = (
                edge["candidate_id"] in candidate_by_id
                and edge["source_record_id"] == edge["candidate_id"]
            )
        elif source_type == "supplemental_source_record":
            supplemental_edges[edge["source_record_id"]].append(edge)
            bucket = "supplemental_source_edge"
            source_fk_ok = (
                edge["source_record_id"] in supplemental_id_set
                and not edge["candidate_id"]
            )
        else:
            bucket = "invalid_source_type"
            source_fk_ok = False
            invalid_edge_source_types.append(edge["edge_id"])
        target_fk_ok = edge["target_id"] in target_id_set
        if not source_fk_ok:
            errors.append(f"edge source FK: {edge['edge_id']}")
        if not target_fk_ok:
            errors.append(f"edge target FK: {edge['edge_id']}")
        edge_replay.append(
            {
                "edge_id": edge["edge_id"],
                "source_record_type": source_type,
                "source_record_id": edge["source_record_id"],
                "candidate_id": edge["candidate_id"],
                "target_id": edge["target_id"],
                "membership_bucket": bucket,
                "source_foreign_key_status": "PASS" if source_fk_ok else "FAIL",
                "target_foreign_key_status": "PASS" if target_fk_ok else "FAIL",
                "partition_status": (
                    "PASS" if source_fk_ok and target_fk_ok else "FAIL"
                ),
            }
        )

    linked_ids = {
        row["candidate_id"]
        for row in candidates
        if row["final_class"] == "linked_internal_edge"
    }
    nonlinked_ids = set(candidate_ids) - linked_ids
    candidate_edge_ids = set(candidate_edges)
    supplemental_edge_ids = set(supplemental_edges)

    candidate_replay: list[dict[str, Any]] = []
    relation_failures: list[str] = []
    for candidate, key in zip(candidates, occurrence_keys):
        candidate_id = candidate["candidate_id"]
        residual = residual_by_candidate.get(candidate_id)
        bound_edges = candidate_edges.get(candidate_id, [])
        linked = candidate["final_class"] == "linked_internal_edge"
        state = (
            "linked_candidate_one_edge"
            if linked
            else "positive_nonedge_zero_edges"
        )
        status = True
        failure_reasons: list[str] = []

        if residual is None:
            status = False
            failure_reasons.append("missing_residual")
        elif linked:
            if residual["closure_status"] != "closed_internal_edge":
                status = False
                failure_reasons.append("linked_residual_status")
            if len(bound_edges) != 1:
                status = False
                failure_reasons.append("linked_edge_count")
            if len(bound_edges) == 1:
                edge = bound_edges[0]
                comparisons = (
                    ("candidate_target", candidate["final_target_id"], edge["target_id"]),
                    ("candidate_kind", candidate["final_target_kind"], edge["target_kind"]),
                    (
                        "candidate_label",
                        candidate["target_latex_label"],
                        edge["target_latex_label"],
                    ),
                    (
                        "candidate_destination",
                        candidate["compiled_pdf_destination_name"],
                        edge["compiled_pdf_destination_name"],
                    ),
                    (
                        "candidate_action",
                        candidate["source_action_id"],
                        edge["source_action_id"],
                    ),
                    ("residual_target", residual["final_target_id"], edge["target_id"]),
                    (
                        "residual_kind",
                        residual["final_target_kind"],
                        edge["target_kind"],
                    ),
                    (
                        "residual_label",
                        residual["target_latex_label"],
                        edge["target_latex_label"],
                    ),
                    (
                        "residual_destination",
                        residual["compiled_pdf_destination_name"],
                        edge["compiled_pdf_destination_name"],
                    ),
                    (
                        "residual_action",
                        residual["source_action_id"],
                        edge["source_action_id"],
                    ),
                )
                for field, actual, expected in comparisons:
                    if actual != expected:
                        status = False
                        failure_reasons.append(field)
        else:
            if residual and residual["closure_status"] != "closed_positive_nonedge":
                status = False
                failure_reasons.append("nonlinked_residual_status")
            if bound_edges:
                status = False
                failure_reasons.append("nonlinked_has_candidate_edge")

        if not status:
            relation_failures.append(candidate_id)
            errors.append(
                f"candidate relation {candidate_id}: {','.join(failure_reasons)}"
            )
        edge = bound_edges[0] if len(bound_edges) == 1 else {}
        candidate_replay.append(
            {
                "candidate_id": candidate_id,
                "occurrence_key_sha256": key,
                "source_file": candidate["source_file"],
                "source_line_preapplication": candidate[
                    "source_line_preapplication"
                ],
                "source_column_1based_preapplication": candidate[
                    "source_column_1based_preapplication"
                ],
                "pattern_kind": candidate["pattern_kind"],
                "final_class": candidate["final_class"],
                "residual_id": residual["residual_id"] if residual else "",
                "residual_closure_status": (
                    residual["closure_status"] if residual else ""
                ),
                "candidate_edge_count": len(bound_edges),
                "candidate_edge_id": edge.get("edge_id", ""),
                "candidate_edge_target_id": edge.get("target_id", ""),
                "relation_state": state,
                "relation_status": "PASS" if status else "FAIL",
                "failure_reasons": "|".join(failure_reasons),
            }
        )

    set_checks = {
        "candidate_residual_bijection": (
            set(candidate_ids) == set(residual_candidate_ids)
            and len(candidate_ids) == len(residual_candidate_ids)
        ),
        "linked_candidate_edge_bijection": (
            linked_ids == candidate_edge_ids
            and all(len(candidate_edges[key]) == 1 for key in linked_ids)
        ),
        "nonlinked_candidates_have_zero_edges": not (
            nonlinked_ids & candidate_edge_ids
        ),
        "supplemental_record_edge_bijection": (
            supplemental_id_set == supplemental_edge_ids
            and all(
                len(supplemental_edges[key]) == 1
                for key in supplemental_id_set
            )
        ),
        "candidate_and_supplemental_ids_disjoint": set(candidate_ids).isdisjoint(
            supplemental_id_set
        ),
        "edge_partition_formula_5998_plus_116_equals_6114": (
            sum(len(value) for value in candidate_edges.values())
            + sum(len(value) for value in supplemental_edges.values())
            == len(edges)
        ),
        "candidate_relation_failures_zero": not relation_failures,
        "invalid_edge_source_types_zero": not invalid_edge_source_types,
    }
    for name, passed in set_checks.items():
        if not passed:
            errors.append(name)

    class_counts = Counter(row["final_class"] for row in candidates)
    closure_counts = Counter(row["closure_status"] for row in residuals)
    edge_source_counts = Counter(row["source_record_type"] for row in edges)
    count_checks = {
        "candidate_count_8701": len(candidates) == 8701,
        "residual_count_8701": len(residuals) == 8701,
        "linked_candidate_count_5998": len(linked_ids) == 5998,
        "nonlinked_candidate_count_2703": len(nonlinked_ids) == 2703,
        "candidate_edge_count_5998": (
            edge_source_counts["frozen_candidate"] == 5998
        ),
        "supplemental_record_count_116": len(supplemental) == 116,
        "supplemental_edge_count_116": (
            edge_source_counts["supplemental_source_record"] == 116
        ),
        "edge_count_6114": len(edges) == 6114,
    }
    for name, passed in count_checks.items():
        if not passed:
            errors.append(name)

    candidate_replay_path = output_root / "GRAPH_CANDIDATE_DISPOSITION_REPLAY.csv"
    edge_replay_path = output_root / "GRAPH_EDGE_SOURCE_PARTITION_REPLAY.csv"
    write_csv(candidate_replay_path, candidate_replay)
    write_csv(edge_replay_path, edge_replay)

    validation = {
        "schema": "sga4_graph_set_relation_audit_v1",
        "status": "PASS" if not errors else "FAIL",
        "semantic_explanation": (
            "REFERENCE_CANDIDATES is the complete source-visible occurrence "
            "universe. REFERENCE_RESIDUALS is an exhaustive one-row-per-"
            "candidate disposition projection, not an unresolved-only set. "
            "Thus linked candidates intentionally have both an edge and a "
            "residual row whose closure_status is closed_internal_edge. "
            "Nonlinked candidates have a closed_positive_nonedge residual "
            "and no candidate-bound edge."
        ),
        "counts": {
            "candidate_occurrences": len(candidates),
            "candidate_disposition_rows": len(residuals),
            "linked_candidates": len(linked_ids),
            "nonlinked_candidates": len(nonlinked_ids),
            "candidate_bound_edges": edge_source_counts["frozen_candidate"],
            "supplemental_source_records": len(supplemental),
            "supplemental_edges": edge_source_counts[
                "supplemental_source_record"
            ],
            "total_edges": len(edges),
            "targets": len(targets),
        },
        "candidate_class_counts": dict(sorted(class_counts.items())),
        "residual_closure_counts": dict(sorted(closure_counts.items())),
        "edge_source_type_counts": dict(sorted(edge_source_counts.items())),
        "uniqueness_checks": uniqueness_checks,
        "set_relation_checks": set_checks,
        "count_checks": count_checks,
        "candidate_replay_rows": len(candidate_replay),
        "edge_replay_rows": len(edge_replay),
        "errors": errors,
        "input_sha256": {
            name: sha256_file(path) for name, path in input_paths.items()
        },
    }
    validation_path = output_root / "GRAPH_SET_RELATION_AUDIT.json"
    write_json(validation_path, validation)

    readme_path = output_root / "README.md"
    readme_path.write_text(
        "# SGA 4 convention-v2 graph set relation\n\n"
        f"Status: **{validation['status']}**.\n\n"
        "`REFERENCE_CANDIDATES.csv` is the complete source-visible occurrence "
        "universe, not an unresolved-only list. "
        "`REFERENCE_RESIDUALS.csv` is an exhaustive disposition projection "
        "with exactly one row for every candidate. A linked candidate "
        "therefore intentionally has both one active edge and one residual "
        "row marked `closed_internal_edge`; this is not double activity. A "
        "positive nonedge has one residual row marked "
        "`closed_positive_nonedge` and no candidate-bound edge.\n\n"
        "The replay proves:\n\n"
        "- 8,701 unique candidate IDs and unique occurrence keys;\n"
        "- a bijection to 8,701 residual disposition rows;\n"
        "- 5,998 linked candidates, each with exactly one candidate-bound "
        "edge;\n"
        "- 2,703 nonlinked dispositions with zero candidate-bound edges;\n"
        "- 116 supplemental source records, each with exactly one disjoint "
        "supplemental edge;\n"
        "- total edges: 5,998 + 116 = 6,114;\n"
        "- unique edge/target/supplemental IDs and closed foreign keys;\n"
        "- no omitted, duplicated, or schema-conflicting occurrence.\n\n"
        "The two replay CSVs serialize every candidate and every edge. "
        "`GRAPH_SET_RELATION_AUDIT.json` records the machine checks and exact "
        "input hashes.\n",
        encoding="utf-8",
    )

    script_copy = output_root / Path(__file__).name
    shutil.copy2(Path(__file__).resolve(), script_copy)

    output_files = [
        candidate_replay_path,
        edge_replay_path,
        validation_path,
        readme_path,
        script_copy,
    ]
    manifest_rows = [
        {
            "relative_path": path.name,
            "bytes": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in sorted(output_files, key=lambda item: item.name)
    ]
    write_csv(output_root / "SHA256SUMS.csv", manifest_rows)

    print(json.dumps(validation, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    sys.exit(main())
