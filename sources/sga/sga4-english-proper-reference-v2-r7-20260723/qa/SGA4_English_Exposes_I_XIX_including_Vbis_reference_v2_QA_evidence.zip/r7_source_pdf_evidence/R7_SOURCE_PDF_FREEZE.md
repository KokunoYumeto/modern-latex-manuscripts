# SGA 4 proper r7 source/PDF freeze

Status: **PASS — frozen input for the final complete-graph and extracted-package gates**

This freeze supersedes r6 for release preparation.  It does not itself claim
archive acceptance, publication, or public readback.

## Exact source identity

- Source tree: `source_release_projection_reference_v2_r7_20260723`
- Files: 300
- Canonical tree SHA-256:
  `AE306A05563020D4996679269C52EDFC80EBB0861A10CBC31CB581D71A90C92D`
- r6-to-r7 changed files: 1
- Changed file:
  `18/drafts/SGA4_XVIII_LINES_2451_2850_English.texfrag`
- Changed-file size: 15,359 bytes in both r6 and r7
- r6 changed-file SHA-256:
  `7E27DF69C2317AD3FC3CAE72FC4EAAE8E5AE97301833C4C368799ED54DCE989C`
- r7 changed-file SHA-256:
  `41A1371FF2E9BE879A2E63B1D90DD69228D79AF1E325F216B7B954DBE779AF93`

The single r7 action replaces the failed pre-display direct target for the
tagged AMS equation `1.4.12.2'` with Hyperref's public
`\NextLinkTarget` binding immediately before the inherited label.  English
prose, mathematical content, the visible tag, and all other source bytes are
unchanged.

Reconstruction controls:

- `INDEPENDENT_R7_SOURCE_ACTION.csv`: 1 row, 1,177 bytes,
  SHA-256
  `B59E8A42B93F3F7281E52507FDEDA87B760A1623635259F39D13811B3DA15DB5`
- `INDEPENDENT_R7_SOURCE_CLOSURE.csv`: 300 rows, 77,093 bytes,
  SHA-256
  `9C134A695819FF0EB802E23C959B0F9FA46682465813B6D5AAFD8769FA75724D`
- Independent validation: `INDEPENDENT_R7_VALIDATION.json`,
  SHA-256
  `46A29E1F70F9CC824949CB4C97D07292FDA2A4838FC41551EB4D1C81FD16DE6F`

The action replays forward and backward byte-exactly.  The closure is
rectangular and formula-safe and reconstructs the stated 300-file tree.

## Exact build identity

Build directory: `build/reference_v2_r7_ams_binding_20260723`

- Pass 1: exit 0; stdout SHA-256
  `44521940568CEE32C33FDC75AE509861866BE84BEE5945097AC2669C59A0497F`
- Pass 2: exit 0; stdout SHA-256
  `0EC7FB0ECE69F1E3698D2990147AB4E2CD9C7EE669802A730DE7E519BC81A0DC`
- Pass 3: exit 0; stdout SHA-256
  `1984BA2421C0B1EC11B619F74306D1191C007E4305988808243F3B98481FB645`
- Final log: 130,238 bytes, SHA-256
  `7B3D7C0E18A10DBBBB35F135BDE1179E6C5CA3E35F161C4CEB3B286A5C003AF5`
- Final AUX: 403,247 bytes, SHA-256
  `953E7B393E98373E06E2EBAA8C648F115768C4BA19AAE95AD45CB548B0A044F3`
- Final PDF: 4,421,240 bytes, 864 pages, SHA-256
  `A4057C39E5BF54AD12E7B2E5DBBACA884B9738F376B3418E8D97EDAB4E3A88B2`

The converged log has zero LaTeX errors, undefined references, multiply
defined labels, duplicate-destination diagnostics, missing-character
diagnostics, or unresolved `??` markers.  Its 149 overfull hboxes and two
overfull vboxes are unchanged from r6 and are not introduced by the r7 action.

## Target and visual checks

- Stable direct-label bindings: 40/40 labels across 39 planned destinations
- Special AUX binding:
  `1.4.12.2' -> sga4.exp.XVIII.equation.1.4.12.2-prime`
- PDF named destinations: 9,421
- PDF GoTo actions: 6,800
- PDF URI actions: 2
- Expected graph edges: 6,114 across 2,119 destination groups
- Missing or short destination groups: 0

Rendered PDF page 796 (printed page 788) is preserved in `visual_qa`.
The r6 and r7 144-dpi PNGs are byte-identical: each is 235,894 bytes with
SHA-256
`0D20B4CD55F077735650062588089CD504B47D02C4A78E32A5636CA92C652393`.
Direct inspection confirms the tag, formula, adjacent prose, and diagrams
remain visibly intact.

An independent full-document raster comparison also rendered all 864 pages of
the admitted r4 reader and r7 reader at 72 dpi grayscale.  All 864 page images
are byte-identical; the ordered raster-set SHA-256 is
`7407784AA768A8207CA95927B12114F0EA52370EEEB505CB90FD2A88B1B3C5D5`.
The durable result is `INDEPENDENT_R7_FULL_RASTER_COMPARISON.json`, 608 bytes,
SHA-256
`54C1DDA4B1D81582C8A4D714E487E5304B1926BA94AA13B9239E1539FB13A249`.

The next required gates are a fresh r7-bound complete graph and a no-overwrite
privacy-clean extracted package containing all co-current graph and residual
ledgers.  Archive handoff remains prohibited until those gates independently
pass.
