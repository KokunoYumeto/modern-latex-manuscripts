# Independent SGA4 r7 AMS-label binding audit

Status: **PASS**

Scope: one no-overwrite r6→r7 source repair for the tagged unnumbered equation label `1.4.12.2'`, plus the complete 40-label AUX binding and PDF graph closure.

- r7 source files: 300
- changed files: 1
- action rows: 1
- AUX bindings: 40 (40 PASS, 0 FAIL)
- PDF pages: 864
- PDF SHA-256: `A4057C39E5BF54AD12E7B2E5DBBACA884B9738F376B3418E8D97EDAB4E3A88B2`
- r7 tree SHA-256: `AE306A05563020D4996679269C52EDFC80EBB0861A10CBC31CB581D71A90C92D`
- graph destination groups: 2119
- errors: []

This receipt independently verifies the r7 source/build objects only. Public package identity, archive acceptance, publication, and public readback require separate evidence.
