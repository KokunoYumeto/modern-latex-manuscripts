# Privacy-clean independent r7 evidence subset

The public evidence subset is the exact file set listed in
`PRIVACY_CLEAN_SHA256SUMS.csv`.

Internal validator source and its internal all-file manifest are deliberately
excluded from this subset. The selected CSV, JSON, and Markdown evidence uses
logical relative source coordinates only and contains no absolute workstation
path.

This subset proves the independent r6-to-r7 source replay, 300-file closure,
40-of-40 AUX destination binding, 2,119-group PDF graph closure, build status,
and exact source/PDF identities. It does not claim archive acceptance,
publication, or public readback.
