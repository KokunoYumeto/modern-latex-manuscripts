# Current SGA 1-6 English readers and buildable TeX

This one-click archive contains one cumulative English reader PDF and its
complete buildable TeX closure for each of SGA 1 through SGA 6. It omits
provenance archives, QA images, raw logs, historical releases, source scans,
and internal project notes.

The SGA3 subtree is the clean R29 complete reader: 1,470 A4 pages, native TeX
diagrams, 13,119 named destinations, and 12,337 valid internal GoTo actions.
The other five SGA subtrees are byte-identical to the preceding bundle.

Each subtree carries a direct cumulative PDF under `reader/` and a buildable
master plus recursive inputs under `source/`. `SHA256SUMS.csv` covers every
other archive member exactly.
