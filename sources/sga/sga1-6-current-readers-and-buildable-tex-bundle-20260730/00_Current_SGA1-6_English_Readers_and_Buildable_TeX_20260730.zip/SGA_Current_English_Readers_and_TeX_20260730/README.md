# Current SGA English Readers and TeX

This bundle contains the current public English reader PDF and the complete
build-source closure for SGA 1 through SGA 6 as of 2026-07-30.

It is deliberately reader-focused. It excludes provenance archives, QA
images, machine ledgers, build logs, historical releases, authority scans,
and internal project notes. Those materials remain available separately in
the public archive.

## Contents and build entry points

| Volume | Reader | Build entry point | Engine |
| --- | --- | --- | --- |
| SGA 1 | `SGA1/reader/SGA1_English_Reader.pdf` | `SGA1/source/SGA1_English_source_sync_workpass.tex` | pdfLaTeX |
| SGA 2 | `SGA2/reader/SGA2_English_Reader.pdf` | `SGA2/source/SGA2_English_Full_Reader.tex` | pdfLaTeX |
| SGA 3 | `SGA3/reader/SGA3_English_Reader.pdf` | `SGA3/source/02c_SGA3_English_Master.tex` | pdfLaTeX |
| SGA 4 | `SGA4/reader/SGA4_English_Reader.pdf` | `SGA4/source/tomes/SGA4_English_translation_workpass.tex` | XeLaTeX |
| SGA 5 | `SGA5/reader/SGA5_English_Reader.pdf` | `SGA5/source/SGA5_English_ReferenceLinked_R9_Master_20260723.tex` | pdfLaTeX |
| SGA 6 | `SGA6/reader/SGA6_English_Reader.pdf` | `SGA6/source/02f_SGA6_English_Master.tex` | pdfLaTeX |

Run the stated engine from the directory containing the entry point. Use
multiple passes when cross-references or tables of contents need convergence.

These are scholarly working translations and reading editions. Their
presence here does not create a critical-edition claim or a new license for
underlying source works. See the separate public provenance and rights
materials for detailed scope and attribution.

`SHA256SUMS.csv` records every other member by relative path, byte count,
and SHA-256.
