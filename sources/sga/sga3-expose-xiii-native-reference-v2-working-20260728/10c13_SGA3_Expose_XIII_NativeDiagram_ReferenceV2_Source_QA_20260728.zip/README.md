# SGA 3 Exposé XIII — English Loop2/reference-v2 checkpoint

This bounded checkpoint contains the complete English Exposé XIII body,
editable LaTeX, a 32-page A4 reader, seven native TeX diagram blocks, an
exhaustive reference-v2 graph, a 360-row source/formula audit ledger,
all-page renders, target-only 5000-dpi diagram evidence, and an exact package
validator.

## Exact scope

- Authority component: `Expo13.pdf`, standalone pages 1–30,
  complete-reader pages 805–834.
- Substantive source extent: standalone pages 1–29; page 30 is blank.
- English body: Sections 1–6 through terminal Remarks 6.6(c).
- Hard stop: before complete-reader page 835 and Exposé XIV.
- Exposés XII and XIV are outside this checkpoint.
- This is a bounded Exposé XIII checkpoint, not a complete SGA 3 reader.

## Principal files

- `source/tex/SGA3_Expose_XIII_English.tex`
- `reader/SGA3_Expose_XIII_English.pdf`
- `reference/REFERENCE_TARGETS.csv`
- `reference/REFERENCE_CANDIDATES.csv`
- `reference/REFERENCE_EDGES.csv`
- `reference/REFERENCE_RESIDUALS.csv`
- `qa/source_formula_audit/SOURCE_FORMULA_AUDIT_LEDGER.csv`
- `qa/diagram_highzoom/DIAGRAM_DISPOSITION.csv`
- `qa/ALL_PAGE_VISUAL_REVIEW.csv`
- `FINAL_PACKAGE_VALIDATION.json`
- `SHA256SUMS.csv`

## Local build

From the extracted package, change into `source`, create a separate output
directory, and run XeLaTeX four times:

```text
cd source
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XIII_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XIII_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XIII_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XIII_English.tex
```

Generated build files are not part of the checkpoint.

The package contains target-side English diagram renders only. Authority
PDFs, source crops, OCR bodies, comparison bodies, private paths, raw build
caches, and internal task conversations are excluded.

See `PROVENANCE_AND_RIGHTS.md` before any redistribution.
