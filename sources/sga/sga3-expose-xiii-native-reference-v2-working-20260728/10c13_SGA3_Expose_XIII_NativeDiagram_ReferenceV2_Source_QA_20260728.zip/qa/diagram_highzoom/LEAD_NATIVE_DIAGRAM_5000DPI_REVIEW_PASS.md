# Exposé XIII — lead native-diagram 5000-dpi review

Status: **PASS**

Review date: 2026-07-28  
Scope: all seven diagram blocks in Exposé XIII  
Authority: `Expo13.pdf`, 30 pages, 406,288 bytes, SHA-256 `24735CAFA57291A71C603712C0588358977856D5971503E6E73F3F2E40A70798`  
English target: reference-v2 r9 PDF, 32 pages, SHA-256 `69810FAAF7FF1A502E26B2488D57F95421F4786409D03DD1842E7DFD9ED92BD9`

## Method

The session lead personally compared every diagram against direct rasterizations of the controlling Polo–Gille authority. The evidence set contains 21 authority crops and 21 corresponding English-target crops, all rendered directly at 5000 dpi (42 PNG files, 12,057,821 bytes). No contact sheet or 300-dpi image carried the decision. No ambiguity remained after the 5000-dpi comparison, so no 9000-dpi escalation was necessary.

For each block I checked the complete node inventory, arrow count and direction, hook/ordinary/dashed decoration, attachment point, label text and side, subscripts, punctuation, and attachment to the surrounding sentence. I also checked the applied TeX: seven `tikzcd` environments are present and `\includegraphics` is absent.

Earlier 600/1200-dpi nonauthor evidence remains legitimate history and is not superseded. The present review adds the required lead-level 5000-dpi closure.

## Result

- D01–D03: exact mathematical and layout agreement.
- D04: exact nodes/arrows/labels. The English period in place of the source comma is an intentional grammatical close, not a diagram-reading change. The printed arrow-direction/prose conflict is preserved and disclosed immediately below the diagram.
- D05–D07: exact mathematical and layout agreement.
- Native source: 7/7 diagram blocks.
- Raster delivery: 0.
- Material defects found in this pass: 0.
- Repairs required in this pass: 0.

The per-diagram result is machine-readable in `DIAGRAM_DISPOSITION.csv`.
