from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "SHA256SUMS.csv"
VALIDATION = ROOT / "FINAL_PACKAGE_VALIDATION.json"
MANIFEST_EXCLUDES = {
    MANIFEST.relative_to(ROOT).as_posix(),
    VALIDATION.relative_to(ROOT).as_posix(),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def package_files() -> list[Path]:
    return sorted(
        (path for path in ROOT.rglob("*") if path.is_file()),
        key=lambda path: path.relative_to(ROOT).as_posix(),
    )


def write_manifest() -> None:
    rows = []
    for path in package_files():
        rel = path.relative_to(ROOT).as_posix()
        if rel in MANIFEST_EXCLUDES:
            continue
        rows.append((rel, path.stat().st_size, sha256(path)))
    with MANIFEST.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["relative_path", "bytes", "sha256"])
        writer.writerows(rows)


def read_csv(path: Path, errors: list[str]) -> list[dict[str, str]]:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.DictReader(stream)
            if not reader.fieldnames:
                errors.append(f"missing CSV header: {path.relative_to(ROOT)}")
                return []
            rows = list(reader)
            for index, row in enumerate(rows, start=2):
                if None in row or any(value is None for value in row.values()):
                    errors.append(
                        f"non-rectangular CSV row {index}: {path.relative_to(ROOT)}"
                    )
            return rows
    except Exception as exc:
        errors.append(f"CSV parse failure {path.relative_to(ROOT)}: {exc}")
        return []


def object_key(obj: Any) -> tuple[Any, ...]:
    if hasattr(obj, "idnum"):
        return ("indirect", obj.idnum, getattr(obj, "generation", 0))
    return ("direct", id(obj))


def dereference(obj: Any) -> Any:
    return obj.get_object() if hasattr(obj, "get_object") else obj


def page_content(page: Any) -> bytes:
    contents = page.get_contents()
    return b"" if contents is None else contents.get_data()


def normalize_destination(value: Any) -> str:
    value = dereference(value)
    if isinstance(value, str):
        return value.lstrip("/")
    return repr(value)


def pdf_facts(path: Path) -> dict[str, Any]:
    reader = PdfReader(str(path))
    destination_map = {
        str(name).lstrip("/"): reader.get_destination_page_number(destination)
        for name, destination in reader.named_destinations.items()
    }
    links: list[list[tuple[Any, ...]]] = []
    goto_count = 0
    broken_goto_count = 0
    uri_count = 0
    other_action_count = 0
    font_refs: dict[tuple[Any, ...], Any] = {}
    image_refs: set[tuple[Any, ...]] = set()

    for page in reader.pages:
        page_links: list[tuple[Any, ...]] = []
        for annotation_ref in page.get("/Annots", []):
            annotation = dereference(annotation_ref)
            if str(annotation.get("/Subtype")) != "/Link":
                continue
            rect = tuple(round(float(value), 4) for value in annotation.get("/Rect", []))
            if "/A" in annotation:
                action = dereference(annotation["/A"])
                action_type = str(action.get("/S"))
                if action_type == "/GoTo":
                    goto_count += 1
                    destination = normalize_destination(action.get("/D"))
                    if destination not in destination_map:
                        broken_goto_count += 1
                    page_links.append(("GoTo", destination, rect))
                elif action_type == "/URI":
                    uri_count += 1
                    page_links.append(("URI", str(action.get("/URI")), rect))
                else:
                    other_action_count += 1
                    page_links.append((action_type, repr(action), rect))
            elif "/Dest" in annotation:
                goto_count += 1
                destination = normalize_destination(annotation.get("/Dest"))
                if destination not in destination_map:
                    broken_goto_count += 1
                page_links.append(("GoTo", destination, rect))
        links.append(sorted(page_links))

        resources = dereference(page.get("/Resources", {}))
        fonts = dereference(resources.get("/Font", {}))
        for _, font_ref in fonts.items():
            font_refs[object_key(font_ref)] = font_ref
        xobjects = dereference(resources.get("/XObject", {}))
        for _, xobject_ref in xobjects.items():
            xobject = dereference(xobject_ref)
            if str(xobject.get("/Subtype")) == "/Image":
                image_refs.add(object_key(xobject_ref))

    type3_count = 0
    unembedded_count = 0
    for font_ref in font_refs.values():
        font = dereference(font_ref)
        if str(font.get("/Subtype")) == "/Type3":
            type3_count += 1
        descriptors = []
        if "/FontDescriptor" in font:
            descriptors.append(dereference(font["/FontDescriptor"]))
        for descendant_ref in font.get("/DescendantFonts", []):
            descendant = dereference(descendant_ref)
            if "/FontDescriptor" in descendant:
                descriptors.append(dereference(descendant["/FontDescriptor"]))
        if descriptors and not any(
            any(key in descriptor for key in ("/FontFile", "/FontFile2", "/FontFile3"))
            for descriptor in descriptors
        ):
            unembedded_count += 1

    metadata = {str(key).lstrip("/"): str(value) for key, value in (reader.metadata or {}).items()}
    return {
        "pages": len(reader.pages),
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
        "named_destinations": len(destination_map),
        "destination_map": destination_map,
        "goto_actions": goto_count,
        "broken_goto_actions": broken_goto_count,
        "uri_actions": uri_count,
        "other_actions": other_action_count,
        "font_resources": len(font_refs),
        "type3_fonts": type3_count,
        "unembedded_fonts": unembedded_count,
        "raster_xobjects": len(image_refs),
        "metadata": metadata,
        "text_sha256_by_page": [
            hashlib.sha256((page.extract_text() or "").encode("utf-8")).hexdigest().upper()
            for page in reader.pages
        ],
        "content_sha256_by_page": [
            hashlib.sha256(page_content(page)).hexdigest().upper()
            for page in reader.pages
        ],
        "links_by_page": links,
    }


def validate_manifest(errors: list[str]) -> dict[str, Any]:
    rows = read_csv(MANIFEST, errors)
    expected_files = {
        path.relative_to(ROOT).as_posix()
        for path in package_files()
        if path.relative_to(ROOT).as_posix() not in MANIFEST_EXCLUDES
    }
    listed_files = [row.get("relative_path", "") for row in rows]
    if len(listed_files) != len(set(listed_files)):
        errors.append("manifest contains duplicate relative paths")
    if set(listed_files) != expected_files:
        missing = sorted(expected_files - set(listed_files))
        extra = sorted(set(listed_files) - expected_files)
        errors.append(f"manifest exact-set mismatch: missing={missing}, extra={extra}")
    replayed = 0
    for row in rows:
        path = ROOT / row["relative_path"]
        if not path.is_file():
            errors.append(f"manifest file missing: {row['relative_path']}")
            continue
        if str(path.stat().st_size) != row["bytes"]:
            errors.append(f"manifest byte mismatch: {row['relative_path']}")
            continue
        if sha256(path) != row["sha256"].upper():
            errors.append(f"manifest hash mismatch: {row['relative_path']}")
            continue
        replayed += 1
    return {
        "rows": len(rows),
        "replayed": replayed,
        "sha256": sha256(MANIFEST),
    }


def validate_graph(errors: list[str]) -> dict[str, Any]:
    reference = ROOT / "reference"
    targets = read_csv(reference / "REFERENCE_TARGETS.csv", errors)
    candidates = read_csv(reference / "REFERENCE_CANDIDATES.csv", errors)
    edges = read_csv(reference / "REFERENCE_EDGES.csv", errors)
    residuals = read_csv(reference / "REFERENCE_RESIDUALS.csv", errors)
    remaining_actions = read_csv(reference / "REFERENCE_APPLICATION_PLAN.csv", errors)
    pre_actions = read_csv(
        reference / "PRE_APPLICATION_REFERENCE_APPLICATION_PLAN.csv", errors
    )
    source_closure = read_csv(reference / "SOURCE_CLOSURE.csv", errors)
    reconstruction = read_csv(reference / "BASELINE_RECONSTRUCTION.csv", errors)

    def unique(rows: list[dict[str, str]], field: str) -> set[str]:
        values = [row.get(field, "") for row in rows]
        if not all(values) or len(values) != len(set(values)):
            errors.append(f"{field} is blank or non-unique")
        return set(values)

    target_ids = unique(targets, "target_id")
    candidate_ids = unique(candidates, "candidate_id")
    unique(edges, "edge_id")
    unique(residuals, "residual_id")
    edge_candidates = {row["candidate_id"] for row in edges}
    residual_candidates = {row["candidate_id"] for row in residuals}
    if edge_candidates & residual_candidates:
        errors.append("candidate appears in both active edge and residual")
    if edge_candidates | residual_candidates != candidate_ids:
        errors.append("candidate partition is not exhaustive")
    if any(row["target_id"] not in target_ids for row in edges):
        errors.append("edge target closure failure")
    if any(
        row["final_class"] == "structural_declaration" and not row["target_id"]
        for row in candidates
    ):
        errors.append("unanchored structural declaration candidate")
    if remaining_actions:
        errors.append("post-application action table is not empty")

    source_root = ROOT / "source"
    for row in source_closure:
        path = source_root / row["source_file"]
        if not path.is_file():
            errors.append(f"source closure missing file: {row['source_file']}")
            continue
        if path.stat().st_size != int(row["bytes"]) or sha256(path) != row["sha256"]:
            errors.append(f"source closure mismatch: {row['source_file']}")
    if any(row["reconstruction_status"] != "exact_byte_reconstruction_pass" for row in reconstruction):
        errors.append("baseline reverse reconstruction is not exact")

    validation = json.loads((reference / "VALIDATION.json").read_text(encoding="utf-8"))
    if validation.get("status") != "PASS" or validation.get("errors"):
        errors.append("reference validator is not PASS/errors[]")
    if validation.get("partition_identity") != "899 = 453 + 446":
        errors.append("reference partition identity mismatch")

    return {
        "targets": len(targets),
        "candidates": len(candidates),
        "edges": len(edges),
        "residuals": len(residuals),
        "pre_application_actions": len(pre_actions),
        "remaining_actions": len(remaining_actions),
        "source_files": len(source_closure),
        "partition": f"{len(candidates)} = {len(edges)} + {len(residuals)}",
    }


def validate_qa(errors: list[str]) -> dict[str, Any]:
    source_validation = json.loads(
        (ROOT / "qa/source_formula_audit/VALIDATION.json").read_text(encoding="utf-8")
    )
    if source_validation.get("verdict") != "PASS" or source_validation.get("errors"):
        errors.append("source/formula audit is not PASS/errors[]")
    source_rows = read_csv(
        ROOT / "qa/source_formula_audit/SOURCE_FORMULA_AUDIT_LEDGER.csv", errors
    )
    diagram_rows = read_csv(
        ROOT / "qa/diagram_highzoom/DIAGRAM_DISPOSITION.csv", errors
    )
    page_rows = read_csv(ROOT / "qa/ALL_PAGE_VISUAL_REVIEW.csv", errors)
    if len(source_rows) != 360:
        errors.append(f"source/formula row count is {len(source_rows)}, expected 360")
    if len(diagram_rows) != 7 or any(
        not row["result"].startswith("PASS") for row in diagram_rows
    ):
        errors.append("diagram disposition is not seven PASS rows")
    if len(page_rows) != 32 or any(row["result"] != "PASS" for row in page_rows):
        errors.append("all-page visual review is not 32 PASS rows")
    target_crops = sorted(
        (ROOT / "qa/diagram_highzoom/target_5000dpi").glob("*.png")
    )
    renders = sorted((ROOT / "qa/renders").glob("*.png"))
    if len(target_crops) != 21:
        errors.append(f"target 5000-dpi crop count is {len(target_crops)}, expected 21")
    if len(renders) != 32:
        errors.append(f"page render count is {len(renders)}, expected 32")
    return {
        "source_formula_rows": len(source_rows),
        "diagram_rows": len(diagram_rows),
        "target_5000dpi_crops": len(target_crops),
        "page_visual_rows": len(page_rows),
        "page_renders": len(renders),
    }


def validate_source(errors: list[str]) -> dict[str, Any]:
    tex_files = sorted((ROOT / "source/tex").rglob("*.tex"))
    body = "\n".join(path.read_text(encoding="utf-8") for path in tex_files)
    master = (ROOT / "source/tex/SGA3_Expose_XIII_English.tex").read_text(
        encoding="utf-8"
    )
    diagram_count = body.count(r"\begin{tikzcd}")
    raster_count = body.count(r"\includegraphics")
    if len(tex_files) != 6:
        errors.append(f"editable TeX file count is {len(tex_files)}, expected 6")
    if diagram_count != 7:
        errors.append(f"native diagram count is {diagram_count}, expected 7")
    if raster_count:
        errors.append("raster includegraphics found in delivered TeX")
    forbidden_xiv_inclusion = any(
        marker in master
        for marker in (
            r"\input{tex/components/14",
            r"\input{tex/components/XIV",
            r"\chapter{Exposé XIV",
            r"\chapter*{Exposé XIV",
        )
    ) or any("XIV" in path.name for path in tex_files)
    if forbidden_xiv_inclusion:
        errors.append("Exposé XIV source inclusion found")
    if r"\SGARefTarget{sga3:xiii:remarks:6:6:part:c}" not in body:
        errors.append("terminal Remarks 6.6 not found")
    return {
        "tex_files": len(tex_files),
        "native_diagram_blocks": diagram_count,
        "includegraphics_occurrences": raster_count,
        "hard_stop_before_expose_xiv": not forbidden_xiv_inclusion,
    }


def validate_privacy(errors: list[str]) -> dict[str, Any]:
    backslash = bytes([92])
    slash = bytes([47])
    patterns = [
        b"C:" + backslash + b"Users" + backslash,
        b"C:" + slash + b"Users" + slash,
        b"C:" + backslash * 2 + b"Users" + backslash * 2,
        slash + b"Users" + slash,
        b"." + b"codex",
    ]
    hits: list[str] = []
    for path in package_files():
        if path == VALIDATION:
            continue
        data = path.read_bytes()
        if any(pattern in data for pattern in patterns):
            hits.append(path.relative_to(ROOT).as_posix())
    if hits:
        errors.append(f"privacy patterns found in: {hits}")
    forbidden_names = [
        path.relative_to(ROOT).as_posix()
        for path in package_files()
        if path.name.lower() in {"expo13.pdf"}
        or "authority" in path.name.lower()
        or "source_crop" in path.name.lower()
    ]
    if forbidden_names:
        errors.append(f"authority/source-crop payload found: {forbidden_names}")
    return {"privacy_hits": hits, "forbidden_authority_payloads": forbidden_names}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--write-manifest", action="store_true")
    parser.add_argument("--replay-pdf", type=Path)
    parser.add_argument("--replay-render-dir", type=Path)
    parser.add_argument("--output", type=Path, default=VALIDATION)
    args = parser.parse_args()

    if args.write_manifest:
        write_manifest()

    errors: list[str] = []
    required = [
        ROOT / "README.md",
        ROOT / "PROVENANCE_AND_RIGHTS.md",
        ROOT / "PACKAGE_METADATA.json",
        ROOT / "reader/SGA3_Expose_XIII_English.pdf",
        ROOT / "source/tex/SGA3_Expose_XIII_English.tex",
        MANIFEST,
    ]
    for path in required:
        if not path.is_file():
            errors.append(f"required file missing: {path.relative_to(ROOT)}")

    manifest = validate_manifest(errors) if MANIFEST.is_file() else {}
    graph = validate_graph(errors)
    qa = validate_qa(errors)
    source = validate_source(errors)
    privacy = validate_privacy(errors)

    reader_pdf = ROOT / "reader/SGA3_Expose_XIII_English.pdf"
    pdf = pdf_facts(reader_pdf)
    expected_pdf = {
        "pages": 32,
        "sha256": "69810FAAF7FF1A502E26B2488D57F95421F4786409D03DD1842E7DFD9ED92BD9",
        "named_destinations": 274,
        "goto_actions": 494,
        "broken_goto_actions": 0,
        "uri_actions": 0,
        "other_actions": 0,
        "font_resources": 32,
        "type3_fonts": 0,
        "unembedded_fonts": 0,
        "raster_xobjects": 0,
    }
    for field, expected in expected_pdf.items():
        if pdf[field] != expected:
            errors.append(f"PDF {field}={pdf[field]!r}, expected {expected!r}")
    expected_metadata = {
        "Title": "SGA 3, Exposé XIII: Regular Elements of Algebraic Groups and Lie Algebras",
        "Author": "A. Grothendieck",
        "Subject": "English reconstruction of SGA 3, Exposé XIII, from the Polo–Gille French edition",
    }
    for field, expected in expected_metadata.items():
        if pdf["metadata"].get(field) != expected:
            errors.append(f"PDF metadata {field} mismatch")

    replay: dict[str, Any] = {"performed": False}
    if args.replay_pdf:
        replay_pdf = args.replay_pdf.resolve()
        if not replay_pdf.is_file():
            errors.append("replay PDF does not exist")
        else:
            fresh = pdf_facts(replay_pdf)
            replay = {
                "performed": True,
                "pages": fresh["pages"],
                "bytes": fresh["bytes"],
                "sha256": fresh["sha256"],
                "text_pages_exact": sum(
                    left == right
                    for left, right in zip(
                        pdf["text_sha256_by_page"], fresh["text_sha256_by_page"]
                    )
                ),
                "content_stream_pages_exact": sum(
                    left == right
                    for left, right in zip(
                        pdf["content_sha256_by_page"],
                        fresh["content_sha256_by_page"],
                    )
                ),
                "link_pages_exact": sum(
                    left == right
                    for left, right in zip(pdf["links_by_page"], fresh["links_by_page"])
                ),
                "destination_map_exact": pdf["destination_map"]
                == fresh["destination_map"],
                "object_counts_exact": all(
                    pdf[field] == fresh[field]
                    for field in (
                        "named_destinations",
                        "goto_actions",
                        "broken_goto_actions",
                        "uri_actions",
                        "other_actions",
                        "font_resources",
                        "type3_fonts",
                        "unembedded_fonts",
                        "raster_xobjects",
                    )
                ),
            }
            if replay["text_pages_exact"] != 32:
                errors.append("fresh replay text differs")
            if replay["content_stream_pages_exact"] != 32:
                errors.append("fresh replay content streams differ")
            if replay["link_pages_exact"] != 32:
                errors.append("fresh replay link sets differ")
            if not replay["destination_map_exact"] or not replay["object_counts_exact"]:
                errors.append("fresh replay PDF object graph differs")

    render_replay: dict[str, Any] = {"performed": False}
    if args.replay_render_dir:
        replay_renders = sorted(args.replay_render_dir.resolve().glob("*.png"))
        package_renders = sorted((ROOT / "qa/renders").glob("*.png"))
        matched = sum(
            left.name == right.name and sha256(left) == sha256(right)
            for left, right in zip(package_renders, replay_renders)
        )
        render_replay = {
            "performed": True,
            "package_render_count": len(package_renders),
            "replay_render_count": len(replay_renders),
            "pixel_exact_pages": matched,
        }
        if len(package_renders) != 32 or len(replay_renders) != 32 or matched != 32:
            errors.append("fresh replay renders are not 32/32 pixel exact")

    result = {
        "schema": "sga3-xiii-extracted-package-validation-v1",
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "scope": "SGA3 Expose XIII only; local pages 1-30 / combined 805-834; hard stop before XIV/835",
        "checks": {
            "manifest_exact_set_and_replay": not any(
                "manifest" in error for error in errors
            ),
            "graph_partition_stable_ids_and_target_closure": not any(
                token in error
                for error in errors
                for token in (
                    "candidate",
                    "target closure",
                    "structural declaration",
                    "remaining action",
                    "reference validator",
                    "partition identity",
                )
            ),
            "source_closure_and_reverse_reconstruction": not any(
                "source closure" in error or "reverse reconstruction" in error
                for error in errors
            ),
            "source_formula_audit": not any(
                "source/formula" in error for error in errors
            ),
            "native_diagram_and_highzoom_evidence": not any(
                "diagram" in error or "5000-dpi" in error for error in errors
            ),
            "all_page_visual_review": not any(
                "all-page" in error or "page render count" in error
                for error in errors
            ),
            "pdf_destinations_actions_fonts_and_raster": not any(
                error.startswith("PDF ") for error in errors
            ),
            "fresh_build_object_content_link_replay": replay.get("performed")
            and not any("fresh replay" in error for error in errors),
            "fresh_render_pixel_replay": render_replay.get("performed")
            and not any("replay renders" in error for error in errors),
            "privacy_and_authority_payload_exclusion": not privacy.get("privacy_hits")
            and not privacy.get("forbidden_authority_payloads"),
            "hard_stop_before_expose_xiv": source.get(
                "hard_stop_before_expose_xiv", False
            ),
        },
        "manifest": manifest,
        "source": source,
        "reference_graph": graph,
        "qa": qa,
        "pdf": {
            key: value
            for key, value in pdf.items()
            if key
            not in {
                "destination_map",
                "text_sha256_by_page",
                "content_sha256_by_page",
                "links_by_page",
            }
        },
        "fresh_build_replay": replay,
        "fresh_render_replay": render_replay,
        "privacy": privacy,
    }
    args.output.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
