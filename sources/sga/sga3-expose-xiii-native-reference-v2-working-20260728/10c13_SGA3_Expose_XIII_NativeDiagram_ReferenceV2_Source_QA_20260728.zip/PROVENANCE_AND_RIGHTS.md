# SGA 3 Exposé XIII English checkpoint — provenance and rights

## Scope and authority

This package contains Exposé XIII only, covering complete-reader pages
805–834 and stopping before page 835 / Exposé XIV. It is not the whole of
SGA 3.

The controlling source is the Polo–Gille PDF `Expo13.pdf`:

- 30 A4 pages;
- 406,288 bytes;
- SHA-256
  `24735CAFA57291A71C603712C0588358977856D5971503E6E73F3F2E40A70798`;
- complete-reader pages 805–834.

That PDF controls text, formulas, numbering, page order, and diagrams. It is
not recovered editor TeX. No authority PDF, scan, source-derived crop, or OCR
body is included in this package.

## English comparison control

Jacob C. Reinhold's Exposé XIII Markdown from commit
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` was used as credited comparison
material only:

- SHA-256
  `BBE9ADEED0840396AC40F5A44246DDEB661583476A43F541812199042DDD5F64`.

It is not authority or independent corroboration. Its contributor declares
CC BY 4.0 for that translation contribution while excluding underlying French
rights. That declaration is no broader license for the French source, this
independently revised reconstruction, or this package.

## Rights statement

No license grant is asserted by this package for the underlying French text,
this English reconstruction, editorial additions, or third-party TeX
support. Rights remain with their respective holders.

Redistribution rights are not asserted. Preservation metadata, attribution,
checksums, and technical validation do not themselves confer permission to
reproduce or redistribute copyrighted material. This is a provenance and
scope statement, not legal advice.

The included 5000-dpi QA images are target-side renders of the English
reconstruction. They are technical evidence only and carry no new license
grant. Authority-derived source images used locally for comparison are
deliberately excluded.
