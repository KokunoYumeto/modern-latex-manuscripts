# Exposé XIII reference-v2 r9 — semantic audit

Status: **PASS**

The r9 application was reviewed against the visible English text and the Exposé XIII target inventory, rather than accepted from regular-expression output alone.

Exact graph:

- targets: 166 (151 inherited, 15 inserted);
- candidates: 899;
- active internal edges: 453;
- residual/nonedge candidates: 446;
- partition: `899 = 453 + 446`;
- pre-application actions: 468;
- remaining actions: 0.

The r8 semantic failure is preserved as adverse history. R9 replaces the broad “preceded by any TeX command” function heuristic with an exact whitelist limited to `\operatorname{ad}` and `\psi^{-1}` in the relevant argument contexts.

The ten r8→r9 corrections were individually checked:

- Lemma 1.1: `(i bis)`, `(ii)`, `(iii)`;
- Corollary 2.2: `(iii)`, `(ii)`;
- Proposition 4.4: `(i bis)`, `(ii bis)`;
- Theorem 5.1: `(vi)`, `(vii)`, `(vi)`.

Each now links to its exact internal item target. The previously established r1–r6 corrections remain present: all four visible `(iv bis)` occurrences are candidates, the three internally addressable occurrences are exact edges, cross-exposé locators remain external nonedges, deictic diagram/display references point to exact local targets, and ordinary mathematical arguments remain residual rather than false links.

Validation status is `PASS` with `errors: []`, stable IDs unique, edge-target closure exact, zero unanchored structural items, exact reverse reconstruction, and a hard stop before Exposé XIV.
