
        # Build summary

        Two fresh isolated builds were run from the exact pinned source
        closure. Each used three XeLaTeX passes and returned exit code zero.
        The resulting PDFs were byte-identical at SHA-256
        `2AF40B568061CA07489B592B0783D6332FFC885ED7128B115F3B1D0EA9A46C8C`.

        Final diagnostics: `{"fatal_errors": 0, "missing_characters": 0, "multiply_defined_labels": 0, "overfull_boxes": 0, "rerun_warnings": 0, "undefined_references": 0, "underfull_boxes": 0}`.
        PDF: 45 A4 pages, 248
        named destinations, 112 link rectangles,
        23 unique image objects, and
        16 unique page font resources.
        Link actions: `{"/GoTo": 112}`.

        `pdffonts` reports 16/16 font rows
        embedded, subset, and Unicode mapped. There are no attachments, forms,
        JavaScript, additional actions, or external URI links.

        Canonical `pdftotext -layout` extraction is 146,125
        bytes at SHA-256 `2CD48DD11ACCB94E679AD757E390BDFF2D808B7EB25FBB598BED3E852B9FDB3D`, with
        0 replacement characters,
        0 NUL bytes, and no forbidden controls.
        PyPDF independently parsed every page and link; its math-font extraction
        reports 0 NUL placeholders on
        0 pages, which is retained as a
        parser-specific observation rather than used as the canonical text
        extraction.

        All pages were rendered at 120 dpi into temporary local QA files for
        archive-maintainer inspection. Those routine page renders are not
        duplicated in the public package.
