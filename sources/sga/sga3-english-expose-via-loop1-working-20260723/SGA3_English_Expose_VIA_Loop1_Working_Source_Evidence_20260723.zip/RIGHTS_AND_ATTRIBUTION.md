
        # Rights and attribution

        This working package asserts no blanket license over the underlying
        French work, the Polo-Gille re-edition, or the source-derived diagram
        pixels. Rights in those materials remain with their respective
        holders.

        Credit the Interlanguage project for this English reconstruction and
        its source-audit workflow. Machine-assisted contributions include
        Anthropic Claude and OpenAI Codex / ChatGPT.

        Jacob C. Reinhold's `jcreinhold/sga` snapshot
        `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` is credited comparison and
        drafting lineage under his stated CC BY 4.0 terms for his translation
        contribution. Do not present it as source authority or as this
        project's work.
