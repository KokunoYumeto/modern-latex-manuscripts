# Independent QA PASS — SGA 3 Exposé VI_A components 22–25

Date: 2026-07-23  
Status: **PASS after the concrete corrections recorded below**  
Scope of this receipt: components 22–25 only, from paragraph 5.4 through
the Exposé VI_A bibliography. This is not a whole-SGA3 release claim and
does not close the later native-diagram Loop 2.

## Controlling and comparison witnesses

- Controlling source: `Exp6A-13oct24.pdf`, local pages 32–38,
  427,698 bytes, SHA-256
  `6C8795572D1FC3B21BD02D24B1BFB20A8FB447475702C2674C96939B1EB69582`.
  The audited source envelope is combined-reader pages 335–341 and
  printed pages 324–330.
- Layout extraction of those seven source pages:
  `source_pages32_38_layout.txt`, 21,910 bytes, SHA-256
  `C5CB85C3C6BCEDF1465A97EB23EC117C09682A16B70392B7C535359E617FDC12`.
- Secondary comparison only: Jacob Reinhold,
  `iii/06A-generalities-on-algebraic-groups.md`, 134,386 bytes,
  SHA-256
  `CBA8277A3187AFB989FB5B7AA741AE14ED96B08C911A21190CBFFE60E2748DC3`.
  It is not treated as source authority or independent corroboration.

## Scope and source-fidelity result

The four components form one continuous body:

1. component 22: 5.4, Proposition 5.4.1, Theorem 5.4.2, and
   Corollary 5.4.3;
2. component 23: 5.5 and 5.6 through Proposition 5.6.2 and its proof;
3. component 24: Section 6 through Proposition 6.4 and its proof;
4. component 25: Theorem 6.5 through Corollary 6.10 and the
   bibliography.

The opening follows the complete 5.3.3 body in component 21 without a
textual gap. The closing matches the final substantive line of local
page 38. Section, proposition, theorem, corollary, reminder, and
bibliography numbering agree with the controlling PDF.

Every displayed formula, subscript, superscript, quotient direction,
map direction, kernel/image/coimage expression, local-ring expression,
limit, and citation in local pages 32–38 was checked against the
controlling PDF. No formula or symbol discrepancy remains in the
audited English components.

The duplicated editor's note 53 is intentionally preserved as two
uniquely labelled notes. Notes 54, 55, 56, 57, 58, and 59 are present
in source order and their content agrees with the source. The
standalone counter replay confirms the visible sequence
53, 53, 54, 55, 56, 57, 58, 59.

The English mathematical register is consistent with the neighboring
lead-edited prose: `faithfully flat`, `locally of finite presentation`,
`schematically dominant`, `closed image`, `thick`, `effective
epimorphism`, and `geometrically reduced` are used correctly. A
passage-by-passage comparison with Reinhold found no stronger
alternative reading that should replace the audited prose. Reinhold
also repeats the relevant French ambient-group and symbol slips, so it
cannot independently validate them.

## Transparent source corrections

The following intended mathematical readings are correct and visible
in the English:

- Component 22: the French prints a closed subgroup scheme \(K\) of
  \(G\), but \(v:C\to H\), the fiber product lies in \(H\), and the
  next paragraph identifies \(K=\ker(H\to\overline H)\). The English
  correctly uses \(H\).
- Component 24: after defining multiplication as \(\mu_H,\mu_G\), the
  French proof prints \(\pi_H,\pi_G\) in the multiplication identity.
  The English correctly uses
  \(f\circ\mu_H=\mu_G\circ(f\times f)\) and
  \(\mu_G^{-1}(H')\).
- Component 25: for \(u:G\to H\), the French says that the closed image
  \(G'\) is a subgroup scheme of \(G\). The English correctly places
  the image in \(H\).

One additional type error was found and corrected during this review:
the French declares \(e:\operatorname{Spec}A\to G\), but immediately
forms \(q\circ e\) with \(q:H\to X\). The corrected English now declares
\(e:\operatorname{Spec}A\to H\), and the existing visible translator's
note was expanded to disclose both §5.4 ambient-group corrections.

## Component patches made by this independent review

### Component 22 — mathematical type correction and note disclosure

Before:

```tex
e:\operatorname{Spec}A\longrightarrow G
...
denotes the unit section of \(G\)
```

After:

```tex
e:\operatorname{Spec}A\longrightarrow H
...
denotes the unit section of \(H\)
```

The translator's note now states that the French source both declares
the unit section on \(G\) and places \(K\) in \(G\), and explains why
both intended ambients are \(H\).

### Components 22, 24, and 25 — rendered word-space correction

Each symbolic translator's-note group ended with bare `\endgroup`.
Because a TeX control word consumes the following newline, the
standalone render showed `*(This`, `*On`, and `*Clearly`. Each site was
changed to `\endgroup{}`, restoring the required visible space after
the footnote marker. No prose or mathematics changed in this spacing
repair.

Pre-review component hashes:

- component 22: 5,378 bytes, SHA-256
  `02DC8D6BF360B909DD57AE16AD5078768F77168DC760553283E95DCADDB65F51`;
- component 23: 6,123 bytes, SHA-256
  `60D58D3360258E6B8CB122DF5EF590422FB4AA570F8B1FFB25292E4E795A70CD`;
- component 24: 6,377 bytes, SHA-256
  `1F1DC746DE773F54B8443EC027CB4D024EB23CD32A0B9A2E13596D1B8DBC39BD`;
- component 25: 8,797 bytes, SHA-256
  `22BB080ADA0668AE0B5ECF9B70F8587CE94093D95725AB0DFEBC1C63C7A60E1B`.

Final audited component hashes:

- `22_expose_VIA_par54_abelian_categories_en.tex`: 5,576 bytes,
  SHA-256
  `1388DDCD2DF10C2777ABFEE8EB47D8EB52828FEB4FD5247E0470D7F6567EB7E2`;
- `23_expose_VIA_par55_56_en.tex`: 6,123 bytes, SHA-256
  `60D58D3360258E6B8CB122DF5EF590422FB4AA570F8B1FFB25292E4E795A70CD`;
- `24_expose_VIA_section6_through_prop64_en.tex`: 6,379 bytes,
  SHA-256
  `229592284119DF13ADEC4AA559DF04D00C4F350D99B16A9E113A8575B9732542`;
- `25_expose_VIA_theorem65_through_bibliography_en.tex`: 8,799 bytes,
  SHA-256
  `5B5CE731C76B1EBB8F4785A8009CE7112D02116C9FC06D0C71EF38179FB14860`.

## Diagram audit

All six Loop-1 diagrams are exact, tightly bounded crops of the
controlling source page and were visually compared against the full
180-dpi source-page renders. Labels, arrows, arrow direction, quotient
notation, primes, subscripts, and object placement agree.

- `Exp6A_localp032_prop541_factorization.png`: 4,891 bytes,
  260×150, 8-bit sRGB, SHA-256
  `963D8C96DEDE10CFDA58B44B82CFA07C6282F2077434154C1AAD486ED277957E`;
- `Exp6A_localp034_prop562_quotient_square.png`: 6,190 bytes,
  300×155, 8-bit sRGB, SHA-256
  `9C782D68206C74487086322DFD287EB6388309600A831F2E55C1C6EB61D9E96D`;
- `Exp6A_localp034_prop562_local_flatness_square.png`: 8,360 bytes,
  350×150, 8-bit sRGB, SHA-256
  `C2AD3A77396FFD7540F2112023F7A5E3D3B0023574EBB34658473B4EEBFBB550`;
- `Exp6A_localp035_prop64_factorization.png`: 2,155 bytes,
  190×145, 8-bit gray, SHA-256
  `9572615C76C9128254A449463E068189ECB07399E1D82A045E6F6CA3C78C4127`;
- `Exp6A_localp037_cor66_square.png`: 2,746 bytes,
  230×175, 8-bit gray, SHA-256
  `753A04ACC1E4E8884C9EF0D86DE601248C82DE8678A289782AB22F5BA455C107`;
- `Exp6A_localp037_cor67_factorization.png`: 2,522 bytes,
  200×145, 8-bit gray, SHA-256
  `3BB2D5AE77FD4DD20B2B9FA59B88A4BFB3E9C1B7AB4A3D87700F2FCC101EF68B`.

The final PDF contains exactly six image objects, one for each expected
diagram. `pdfimages_list.txt` is 752 bytes, SHA-256
`93A483AF28FA2B39E983AD6ADA9D075807DB3F36574FCC837EE04965093EBF48`.
Native reconstruction of these six diagrams remains ordinary Loop-2
work, not a defect in this Loop-1 PASS.

## Build and rendered QA

Standalone wrapper:

- `SGA3_Expose_VIA_components22_25_QA.tex`: 1,276 bytes, SHA-256
  `A573BF4599A82E8D6FE85403FDA7E2C3613727198739BD1733399322760D581E`.

Final standalone reader:

- `build/SGA3_Expose_VIA_components22_25_QA.pdf`: 10 A4 pages,
  128,752 bytes, SHA-256
  `AD784DD21551C1E32D5FAB53EA540B12ADFFA7ACDD430DF89141B788C0878A84`.

Three final XeLaTeX passes exited zero. Each final log is 7,828 bytes
with SHA-256
`C717E2FA5998ECC484C0DF480E1F48C5F23468516FB4F9D5E2CC701C8A48CCC9`.
The tracked diagnostic count is zero on every pass: no fatal error,
undefined reference, multiply defined label, missing character,
overfull box, or underfull box.

All 10 PDF pages were rendered at 150 dpi and inspected at full
resolution. Text, formulas, six diagrams, section transitions,
footnotes, bibliography, margins, and page breaks are legible and
unclipped; there is no overlap, black box, missing glyph, or malformed
diagram. Final 8-bit sRGB contact sheets:

- `contact_pages01_05.png`: 938,509 bytes, SHA-256
  `3874EC90BD9A9465971670CCE6C6C893C14E40BA2024FFAD48B5BCE53A3E07DA`;
- `contact_pages06_10.png`: 1,322,010 bytes, SHA-256
  `FE0FAF247D936D904D32A754CBB4229853FD8609ADFE174AC8CC78F73E2ACE2D`.

The final PDF text extraction contains no Unicode replacement
characters:

- `qa_pdf_text_layout.txt`: 21,764 bytes, SHA-256
  `F43E002BFA9F446E8686216A795F0404F51404263F74CDF85FCBF44A6056D320`.

All listed fonts are embedded and subset:

- `pdffonts.txt`: 2,945 bytes, SHA-256
  `5EC6B4407D59DF34CFD347920AE96892DA45823850FBD382C20BC39270E1789B`.

## Final disposition

Components 22–25 pass this independent source, translation, formula,
diagram, numbering, build, and visual review at the final hashes above.
There is no remaining blocker within this bounded VI_A closing range.
The six source-bound diagram PNGs remain explicitly pending native
Loop-2 replacement.
