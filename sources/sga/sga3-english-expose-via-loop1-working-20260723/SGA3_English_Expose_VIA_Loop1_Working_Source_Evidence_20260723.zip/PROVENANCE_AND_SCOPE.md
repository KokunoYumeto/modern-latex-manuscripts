
        # Provenance and scope

        This package is the bounded SGA 3 Expose VI A English working
        checkpoint through the VI A bibliography. It covers Polo-Gille
        Expose VI A local pages 1-38, corresponding to combined-reader pages
        304-341. Expose VI B and all later exposes are excluded.

        The sole controlling French prose, formula, page, note, and diagram
        witness is `Exp6A-13oct24.pdf`, 38 pages, 427,698 bytes,
        SHA-256 `6C8795572D1FC3B21BD02D24B1BFB20A8FB447475702C2674C96939B1EB69582`. The authority PDF is not redistributed
        here. OCR was locator and drafting witness only.

        Jacob C. Reinhold's English Markdown in `jcreinhold/sga` at commit
        `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` is credited comparison and
        drafting lineage. Reinhold describes that contribution as LLM
        generated and licenses his translation contribution CC BY 4.0. It is
        neither authority nor independent corroboration.

        The 26 editable components are pinned in
        `controls/COMPONENT_MANIFEST.csv`. The 23 required Loop-1 diagram
        images are pinned and page-mapped in `controls/FIGURE_MANIFEST.csv`.
