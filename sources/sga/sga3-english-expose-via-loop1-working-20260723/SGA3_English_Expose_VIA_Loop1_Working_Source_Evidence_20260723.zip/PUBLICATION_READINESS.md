
        # Publication readiness

        Status: READY_FOR_BOUNDED_WORKING_PUBLICATION_WITH_CAVEATS.

        This is complete Expose VI A only. It is not complete SGA 3, a
        critical edition, rights clearance, human peer review, or exhaustive
        convention-v2 internal-reference certification. Expose VI B and later
        are not included.

        All 23 diagrams are required Loop-1 source-derived images. Native
        diagram reconstruction remains open Loop-2 work. The PDF is an
        untagged working reader and is not claimed to satisfy archival PDF
        accessibility requirements.
