
        # SGA 3 Expose VI A English working checkpoint

        Build the reader by running XeLaTeX three times on
        `SGA3_English_Expose_VIA_Loop1_Working_20260723.tex` from this
        directory.

        The 26 component files are under `tex/components`; all 23 required
        Loop-1 diagram assets are under `figures`. Provenance, rights,
        readiness, build, machine manifests, and independent closing-range QA
        are included.
