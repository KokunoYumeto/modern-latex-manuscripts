# SGA 3 Exposé XVI — lead native-diagram review

Status: **PASS** for the complete Exposé-XVI diagram inventory.

The session lead compared every delivered native diagram directly against
the controlling Polo--Gille `Expo16.pdf` at 5,000 dpi.  The 600-dpi page
renders were used only to check placement in the English page envelope.
No 300-dpi evidence was used.  No feature remained ambiguous after the
5,000-dpi comparison, so escalation to 9,000 dpi was unnecessary.

## Authority

- `Expo16.pdf`, 352,766 B
- SHA-256:
  `3DB23F1A2E7942FE7C63C7A4475F76C67944F8A51996241D9E40127435FB892B`
- Exposé XVI: local pages 1–24 / combined-reader pages 939–962.

## Diagram dispositions

### SGA3-XVI-DIAG-001 — Theorem 2.2

- Authority: local page 11 / combined page 949.
- Exact nodes: \(G\), \(G/H\), and \(X\), with the source's terminal
  period after \(X\).
- Exact arrows: \(G\to G/H\), \(G\to X\), and \(G/H\to X\).
- Exact labels and sides: \(p\) left of the vertical arrow; \(f\) above
  the descending diagonal; \(i\) above the horizontal arrow.
- The native triangle's row spacing was reduced after the first build so
  that its relatively shallow source geometry is preserved.
- Disposition: `PASS_NATIVE_5000DPI`.

### SGA3-XVI-DIAG-002 — Corollary 2.3

- Authority: local page 12 / combined page 950.
- Exact nodes: \(G\), \(H\), and \(G/K\).
- Exact arrows: top \(G\to H\), descending \(G\to G/K\), and ascending
  \(G/K\to H\).
- Exact labels and sides: \(u\) above the top arrow; \(p\) on the lower
  side of the descending diagonal; \(i\) on the lower side of the
  ascending diagonal.
- No terminal punctuation is present in the source diagram.
- Disposition: `PASS_NATIVE_5000DPI`.

### SGA3-XVI-DIAG-003 — Proposition 3.1

- Authority: local page 13 / combined page 951.
- Exact nodes: \(G\), \(G/Z\), and
  \(\operatorname{GL}_S(G^{(n)})\).
- Exact arrows: top \(G\to\operatorname{GL}_S(G^{(n)})\), an unlabeled
  descending arrow \(G\to G/Z\), and an ascending arrow
  \(G/Z\to\operatorname{GL}_S(G^{(n)})\).
- Exact labels and sides: \(\rho_n\) above the top arrow and \(i_n\) on
  the lower side of the ascending diagonal.
- No label was invented for the source's unlabeled descending arrow.
- Disposition: `PASS_NATIVE_5000DPI`.

## English-page placement

- Physical page 13 contains DIAG-001 and DIAG-002.
- Physical page 15 contains DIAG-003.
- Both 600-dpi page-context renders show clean spacing, no clipping, and
  no collision with the surrounding theorem/corollary/proposition text.

The three inactive Loop-1 raster crops remain only as historical source
witnesses.  The delivered TeX source has three native inputs and zero
active `\includegraphics` calls.
