# SGA 3 Exposé XVI — English Loop 2 native-diagram successor

Status: **native Loop-2 PASS for Exposé XVI**.

This no-overwrite successor preserves the complete Loop-1 English
translation and replaces all three active raster diagram placeholders with
native `tikz-cd` source.  It is a bounded Exposé-XVI integration input, not
a whole-SGA3 release or archive dispatch.

## Scope and authority

- Session-A ownership: all of Exposé XVI only.
- Authority: Polo--Gille `Expo16.pdf`, 352,766 B,
  SHA-256
  `3DB23F1A2E7942FE7C63C7A4475F76C67944F8A51996241D9E40127435FB892B`.
- Authority envelope: local pages 1–24 / combined-reader pages 939–962.
- English content: local pages 1–23 / combined pages 939–961.
- Local page 24 / combined page 962 is the terminal blank.
- Hard stop: before Exposé XVII.

## Native-diagram closure

- Exact inventory: 3 diagrams.
- Active native TeX inputs: 3.
- Active `\includegraphics` calls: 0.
- Lead authority/native comparisons: 3/3 PASS at 5,000 dpi.
- No 300-dpi fidelity evidence was used.
- No ambiguity remained after the 5,000-dpi comparisons; 9,000-dpi
  escalation was unnecessary.
- Physical English page 13 contains the two Section-2 factorization
  triangles; physical page 15 contains the Proposition-3.1 triangle.
- The 600-dpi full-page renders are context evidence only and show no
  clipping, collision, or bad seam.

Exact controls:

- `NATIVE_DIAGRAM_INVENTORY.csv`: 3 rows / 1,683 B,
  SHA-256
  `B1B6540E4958A8F2D4FD99CB868032A0DABA7E7609C4142CABD344E3007AC834`.
- `LEAD_NATIVE_DIAGRAM_5000DPI_REVIEW_PASS.md`: 2,702 B,
  SHA-256
  `2EF88A691B0ACADDA7DE59DF8AA07C65CC9954AC359F9D56DEC17DF77A288A69`.
- `LOOP2_NATIVE_VALIDATION.json`: 2,551 B,
  SHA-256
  `12C4295AE6FD3C9D441116D22E4AD8FBA1632D64C094E930F10031DB45BD000A`,
  status `PASS_NATIVE_LOOP2_EXPOSE_XVI`, errors `[]`.

The predecessor's three PNGs remain in `figures/` solely as inactive
historical source witnesses.  They are not delivered by the active master.

## Exact active source

- `tex/SGA3_Expose_XVI_English.tex`: 1,399 B,
  SHA-256
  `6EE37231DE0FD831133AEBF814E3E344A4DA599153353D76C7AD7F3495C9C817`.
- `tex/sga3_expose_xvi_macros.tex`: 641 B,
  SHA-256
  `9666FDDEB23D2F66C138BB7D24725930EED97C562234F0926F802205BEAA24C8`.
- Component 01: 33,139 B,
  SHA-256
  `62DD71F1D78A213CF8EE210F5494809DA46E900A3154BF0BC497A5506A3C766E`.
- Component 02: 11,100 B,
  SHA-256
  `09CBE1C9775072CD0B561FF21E0DDED09B0667DCAD2718DC07280DAFB6BE67BB`.
- Component 03: 17,355 B,
  SHA-256
  `2F9C0730E897EED37770BC3415BC0C5A8EA69A8845380B09C5D2D023A2D898B5`.
- Component 04: 7,512 B,
  SHA-256
  `D8E58A6EF63705415B0C2314515E3053191D462FCC18331B81B6C0267F651C94`.
- Component 05: 4,674 B,
  SHA-256
  `242D3A42F6C7344F6B1FBA702E56B546112FA9DEFDE509406F6BBDF9C9CF504E`.
- Component 06: 8,465 B,
  SHA-256
  `FCBF13186C7DB0FC38D62043CE6C8C6F8B064CA4241597C64C6429890DCB2A69`.
- Native DIAG-001: 135 B,
  SHA-256
  `0A85F7CDE6A73D579C8A224FC6DBAA4B97E0A3304E9ED219E5F09F047B17F782`.
- Native DIAG-002: 155 B,
  SHA-256
  `18FE37CEA63CF31054C2D5842F5476FA05866623F3001F221885E7630FA5281D`.
- Native DIAG-003: 197 B,
  SHA-256
  `DF6A54531CBD1F0C00CF4AF8C15271458BF85DB34E7340B9D162E3C24E94A646`.
- `NATIVE_SOURCE_SHA256.csv`: 11 rows / 1,405 B,
  SHA-256
  `3EDCC466276D3590C220945BE24818951888C10E9E00673ECE46E76C30B1743C`;
  exact replay 11/11, errors 0.

## Final standalone build

- PDF:
  `build_loop2_native_r1/SGA3_Expose_XVI_English.pdf`
- 25 A4 pages / 184,223 B
- SHA-256:
  `C2126756DF0A22A26D37DC5097C6DC723F63C65C21636E1BE9A7886016CBC84A`
- Log: 39,370 B,
  SHA-256
  `BFE3F4C20C8BE96D11CE2A67AB374EAC7C3BBADEAF19D49F158446A470EE15D2`.
- Three XeLaTeX passes exit 0; pass-2 and pass-3 console output is
  byte-identical.
- Fatal errors, undefined controls, missing characters, duplicate
  destinations, overfull/underfull boxes, and rerun requests: all 0.

The page count changes from the raster Loop-1 reader's 26 pages to 25
because the native diagrams use their natural TeX dimensions.  The
translated authority scope and hard stop are unchanged.  Any cumulative
reader must therefore regenerate its own downstream page coordinates.

## Remaining boundary

Exposé XVI itself has no active raster or unchecked native-diagram debt.
Whole-volume cumulative refresh, reference-v2 regeneration, privacy/rights
projection, and final SGA3 release/readback remain outside this bounded
closure.  No archive or publication action is claimed here.
