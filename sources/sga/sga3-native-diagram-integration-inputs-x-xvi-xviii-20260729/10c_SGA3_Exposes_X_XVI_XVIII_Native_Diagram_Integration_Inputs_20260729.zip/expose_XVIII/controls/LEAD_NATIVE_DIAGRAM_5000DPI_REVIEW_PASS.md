# Lead native-diagram review — SGA 3 Exposé XVIII

Status: **PASS** for the complete two-diagram Exposé-XVIII inventory.

This review was performed personally by the Session-A lead. No agent made
the mathematical or visual fidelity judgment. The controlling witness was
the Polo--Gille `Expo18.pdf`, 324,470 B, SHA-256
`AAD2454EFF58C198BB7088CE602050673AD273F67EAAE7105EABCD6C8D9926D0`.

## Method

- Each authority diagram was rendered directly from the authority PDF at
  5,000 dpi.
- Each final English native diagram was rendered directly from the
  compiled English PDF at 5,000 dpi.
- The 600-dpi full-page renders were used only for page placement,
  surrounding prose, clipping, collision, and seam context.
- No 300-dpi evidence was used.
- Neither diagram retained an ambiguous glyph or edge after the 5,000-dpi
  comparison, so 9,000-dpi escalation was unnecessary.

## SGA3-XVIII-DIAG-001 — Proposition 2.3 compatibility square

Authority locator: local page 4. English locator: physical page 6.

The final native square has exactly the four source nodes
`V`, `H\times_S H`, `U`, and `H`. The four arrows and their directions
match the authority. The top label
`(\bar f\times\bar f)|_V` is above the arrow; `m_G` and `m_H` are on the
right of their respective downward arrows; `\bar f` is above the bottom
arrow. The authority has no terminal punctuation in this square, and none
was introduced. The diagram is centered, unclipped, and separated from the
surrounding proposition text.

Disposition: **PASS**. The Loop-1 raster is inactive and has been replaced
by `native_diagrams/exp18/001_proposition_2_3_compatibility_square.tex`.

## SGA3-XVIII-DIAG-002 — Cartesian relation square

Authority locator: local page 15. English locator: physical page 19.

The final native square has exactly the four source nodes
`R`, `X^2\times_S X^2`, `G`, and `G\times_S G.`. The source terminal
period after the lower-right node is preserved. The arrows and label sides
match the authority: `\alpha` is above the top arrow, `\gamma` is left of
the left downward arrow, `\beta` is right of the right downward arrow, and
`\Delta` is above the bottom arrow. This corrects the Loop-1 placement of
`\Delta` below that arrow. The page placement is unclipped and does not
collide with the adjacent proof or Lemma 3.10.

Disposition: **PASS**. The rebuilt source is
`native_diagrams/exp18/002_cartesian_relation_square.tex`.

## Closure

- Native diagram inventory: 2.
- Lead-reviewed at 5,000 dpi: 2/2 PASS.
- Active native inputs: 2.
- Active `\includegraphics` calls: 0.
- Open Exposé-XVIII diagram blockers: 0.

This is a bounded Exposé-XVIII Loop-2 integration input. It does not claim
whole-volume reference, privacy, rights, packaging, archive, publication,
or readback closure.
