# SGA 3 Exposé XVIII — English Loop 2 native-diagram successor

Status: **native Loop-2 PASS for Exposé XVIII**.

This no-overwrite successor preserves the complete Loop-1 English
translation and closes the entire two-diagram Exposé-XVIII inventory in
native `tikz-cd`. It is a bounded integration input, not a whole-SGA3
release or archive dispatch.

## Scope and authority

- Session-A ownership: all of Exposé XVIII only.
- Authority: Polo--Gille `Expo18.pdf`, 324,470 B,
  SHA-256
  `AAD2454EFF58C198BB7088CE602050673AD273F67EAAE7105EABCD6C8D9926D0`.
- Authority envelope: local pages 1–18 / combined-reader pages 1013–1030.
- Local page 18 / combined page 1030 is the terminal blank.
- Hard stop: before Exposé XIX.

## Native-diagram closure

- Exact inventory: 2 diagrams.
- Active native TeX inputs: 2.
- Active `\includegraphics` calls: 0.
- Lead authority/native comparisons: 2/2 PASS at 5,000 dpi.
- No 300-dpi fidelity evidence was used.
- No ambiguity remained after the 5,000-dpi comparisons; 9,000-dpi
  escalation was unnecessary.
- The 600-dpi full-page renders are context evidence only and show no
  clipping, collision, or bad seam.

The page-4 Proposition-2.3 raster was replaced with native TeX. The
page-15 square was rebuilt so that `\Delta` is above the lower arrow, as
in the authority, while retaining the source terminal period after
`G\times_S G.`.

Exact controls:

- `NATIVE_DIAGRAM_INVENTORY.csv`: 2 rows / 1,349 B,
  SHA-256
  `FF4265525A11B1C8383829CB2236A0DE32B72A53496322DD4E0CAC4619EF3EB4`.
- `LEAD_NATIVE_DIAGRAM_5000DPI_REVIEW_PASS.md`: 2,789 B,
  SHA-256
  `0DFF3D85C745FDF966084C1AB2DE9BD4C82FA1086A8B6470CD00A07092B6C242`.
- `LOOP2_NATIVE_VALIDATION.json`: 2,223 B,
  SHA-256
  `67B09D51B5D21A45655054BB776EABBFA2B5E62DAC7030D85B89F0D9AD37394A`,
  status `PASS_NATIVE_LOOP2_EXPOSE_XVIII`, errors `[]`.

The predecessor PNG remains under `figures/` solely as an inactive
historical witness. It is not referenced by the active master.

## Exact active source

- `tex/SGA3_Expose_XVIII_English.tex`: 1,257 B,
  SHA-256
  `50B7E40785578530BED38456161109744C0DC848F30E749050512A1B89E6AB1B`.
- `tex/sga3_expose_xviii_macros.tex`: 499 B,
  SHA-256
  `3BC8C95C369B4BB0D475F7BB6CE7F091118C81E3774AE4657DD6EB50DBA848E0`.
- Component 01: 9,876 B,
  SHA-256
  `13DA91FD1FAEEB146DF7A9A9BA0B10CB3B46CA041D6CF1D48FE140DF349253A3`.
- Component 02: 9,485 B,
  SHA-256
  `9412064C3639CED72D2B1E5858BEBFB894830FB90236D51AE3DA025F7993ECFE`.
- Component 03: 37,338 B,
  SHA-256
  `9E9195DFBC8C87B11D6F437166C19E072032A454600231BAD1097EF7AB5088F2`.
- Native DIAG-001: 179 B,
  SHA-256
  `3135795BFCBA9B45DB1FA9CDFFF91B7D97F6DA57F4FAD22F29504EE84844DDA5`.
- Native DIAG-002: 181 B,
  SHA-256
  `0828C779F13051614875B196C0585628D5BEE4A67264D5ED0C7E1701C343617C`.
- `NATIVE_SOURCE_SHA256.csv`: 7 rows / 854 B,
  SHA-256
  `5EF553C81B715ACDAA4EB4C9D19E60617C573D87C2B409129356FB619FF6FC9F`;
  exact replay 7/7, errors 0.

## Final standalone build

- PDF:
  `build_loop2_native_r1/SGA3_Expose_XVIII_English.pdf`
- 22 A4 pages / 159,832 B
- SHA-256:
  `83E955BD25A92A65507A38F8E697DFC1DA6E46D8BF154C56BE33C9940B57EF6A`
- Log: 38,431 B,
  SHA-256
  `530163D0B471E7DF494EE2C87B6BF9107C449E673FA8D950915D43D1EF581122`.
- Three XeLaTeX passes exit 0.
- Fatal errors, undefined controls/references, missing characters,
  duplicate destinations/labels, overfull/underfull boxes, and rerun
  requests: all 0.

## Remaining boundary

Exposé XVIII itself has no active raster or unchecked native-diagram debt.
Whole-volume cumulative refresh, reference-v2 regeneration, privacy/rights
projection, and final SGA3 release/readback remain outside this bounded
closure. No archive or publication action is claimed here.
