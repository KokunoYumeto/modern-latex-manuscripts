# SGA 3 Expose X - English Native-Diagram Loop 2 Successor

Date: 2026-07-28

Status: **Expose-X native Loop 2 PASS.**

All four Expose-X raster placeholders have been replaced in the active TeX by
native TikZ/tikz-cd sources. The lead session compared every final diagram
directly against the controlling Polo-Gille PDF at 5,000 dpi. The reader
builds cleanly and contains 4 native diagram inputs and 0 active raster
diagram inputs.

This closes the Expose-X diagram debt only. It is not a whole-SGA3 Loop-2
closure, release authorization, archive handoff, or public-readback claim.

## No-overwrite lineage

- Loop-1 predecessor:
  `sga3_exposeX_english_loop1_reconstruction_20260728`
- This no-overwrite successor:
  `sga3_exposeX_english_loop2_native_diagram_successor_20260728_r1`
- The predecessor raster reader and its controls remain preserved as history.
- No other session's source tree or diagram range was touched.

## Authority and extent

- Authority: `Expo10-8nov09.pdf`
- Authority bytes: 464,776
- Authority SHA-256:
  `A335FF4972694DBE531B46F852D2C77F13E433B365D0D38289B25ADFEADF2C62`
- Authority local pages: 1-44
- Combined-reader pages: 679-722
- Opening cursor: local page 1, title and Section 1
- Terminal cursor: local page 44, bibliography/end
- Next excluded cursor: Expose XI, combined-reader page 723

The Polo-Gille PDF controls wording, formulas, structure, page order, and
diagram fidelity. Floris's existing GPU OCR is read-only locator/drafting
material. The Reinhold English lineage is a credited comparison witness, not
an independent source authority.

## Native diagram closure

| ID | Authority page | Reader page | Native source | Result |
|---|---:|---:|---|---|
| `SGA3-X-DIAG-001` | 3 | 5 | `native_diagrams/exp10/001_normalization_gluing_chain.tex` | PASS after one source-backed ray repair |
| `SGA3-X-DIAG-002` | 4 | 6 | `native_diagrams/exp10/002_descent_hom_exact_rows.tex` | PASS |
| `SGA3-X-DIAG-003` | 4 | 6 | `native_diagrams/exp10/003_diagonalizable_hom_square.tex` | PASS |
| `SGA3-X-DIAG-004` | 12 | 14 | `native_diagrams/exp10/004_etale_cover_equivalence_triangle.tex` | PASS |

The initial `SGA3-X-DIAG-001` reconstruction gave the fourth `b` crossing a
duplicate lower-left auxiliary ray. Direct authority comparison showed that
ray belongs on the upper-left. The final native source corrects it; the final
four-node/three-node chain, rays, labels, and dot counts now match.

Exact row-level locators, source hashes, evidence hashes, and dispositions:

- `NATIVE_DIAGRAM_INVENTORY.csv`
- 4 rows / 3,236 B
- SHA-256:
  `068AFAC5023A56CE858712406C6BFC33394E4EF0BE9DA5120A0CA0D7AFE46804`

## Lead high-zoom review

- Receipt: `LEAD_NATIVE_DIAGRAM_5000DPI_REVIEW_PASS.md`
- Bytes: 3,357
- SHA-256:
  `3D0C765CC9AFCAB45D8F8A9CA4BB44AD598312822A5095149B2BF414FF83F9E1`

Method:

- individual authority and final-native crops at 5,000 dpi;
- 600-dpi page context used only for placement/seams, never as the fidelity
  decision;
- manual lead inspection of all nodes, edges, arrowheads, directions,
  repeated arrows, labels, label sides, primes/subscripts, punctuation, and
  prose attachment;
- no unresolved ambiguity after 5,000 dpi, so no 9,000-dpi escalation;
- no delegated mathematical or visual judgment.

## Exact active source closure

- Manifest: `NATIVE_SOURCE_SHA256.csv`
- Rows: 9
- Bytes: 1,186
- SHA-256:
  `C686265A97646EDDB559262580B5CD3FFDF4A883ABBBF2CE9CEA2A743619B1B5`
- Exact replay: 9/9 size and SHA matches; errors 0.

Active source identities:

| File | Bytes | SHA-256 |
|---|---:|---|
| `tex/SGA3_Expose_X_English.tex` | 1,262 | `1639A07F89969EE835158F1C471FA9D91EB63B07EB9F7B1EA0F44248AC10C2F2` |
| `tex/sga3_expose_x_macros.tex` | 776 | `B2188178003886DEAACFE82C4F66AC131109AA20885CB1B62859CC3E0B2F17EE` |
| `tex/components/01_expose_X_sections1_3.tex` | 37,304 | `1458D8812BB12C82788CDCDD669DC82AC712233306A8D01A8622F8EC8D699F97` |
| `tex/components/02_expose_X_sections4_6.tex` | 64,327 | `DB3042AD3EB6B43369C3175129ABC49EB0B575F9151F7381364816F3796F133A` |
| `tex/components/03_expose_X_sections7_9_bibliography.tex` | 51,927 | `2DC5346B522DE831A39AE0848FF70A4B2BF66EEF339EC09F6871A03DD2AD8EF8` |
| `native_diagrams/exp10/001_normalization_gluing_chain.tex` | 1,262 | `55F77B6C0751FFA14C144471BB144338D5DC616E9D04409AFFDB75CC88FA2127` |
| `native_diagrams/exp10/002_descent_hom_exact_rows.tex` | 640 | `40FAB007DFFC9ECAF258476C3F10FA16888B6512AC1D77010981208CD85F4302` |
| `native_diagrams/exp10/003_diagonalizable_hom_square.tex` | 427 | `E9DAC284D98C2155DD055AD09A360F681B577DE31B2810D166DF776E2E5FF1AC` |
| `native_diagrams/exp10/004_etale_cover_equivalence_triangle.tex` | 236 | `8C6CCFDCBB9C0290A918BE42AB5F3AEF0E95CCDC2FF8703F3EC82B31EADD0965` |

## Final build

- Three final XeLaTeX passes: exit `0,0,0`.
- PDF:
  `build_loop2_native_r1/SGA3_Expose_X_English.pdf`
- Extent: 44 A4 pages.
- PDF bytes: 310,778.
- PDF SHA-256:
  `116065B39DC227EA72863ED7C71BC925CC15E0C62AAAE88601B46C648CAF64A7`
- Log:
  `build_loop2_native_r1/SGA3_Expose_X_English.log`
- Log bytes: 42,078.
- Log SHA-256:
  `A07E6E5B091CA251E5449489CEFA75589F59C15A1039984CFDD9BAC9CB345DDD`
- Fatal errors, undefined control sequences/references, duplicate
  destinations, missing characters, overfull vboxes, and underfull boxes: 0.
- Two inherited bounded overfull hboxes remain: 4.21538 pt and 0.78955 pt.
  Direct inspection shows no clipping or collision.
- Reader pages 5, 6, and 14 pass final placement/seam review.

Machine validation:

- `LOOP2_NATIVE_VALIDATION.json`
- 2,297 B
- SHA-256:
  `8924195210BD1E07FDF971A9E76365244E017C44C5F21D30B11C483631E3F4E9`
- Status: `PASS_NATIVE_LOOP2_EXPOSE_X`
- Errors: `[]`
- `release_authorized`: `false`

## Routing

The cumulative R14 reader is owned by Session C and is not duplicated here.
Session C may consume these exact Expose-X native bytes in a later
no-overwrite cumulative successor.

Session A continues only its frozen diagram debt. Session B/C-owned exposés
remain excluded. EGA IV Sections 11-21 remains a later queued allocation and
is not active while SGA3 work remains.
