# SGA 3 Expose X - Lead Native Diagram 5000-DPI Review PASS

Date: 2026-07-28

Status: **PASS for all four Expose-X native diagrams.**

This is a lead-session source-fidelity review, not an independent release
audit and not a whole-SGA3 completion claim.

## Controlling authority

- PDF: `Expo10-8nov09.pdf`
- Bytes: 464,776
- SHA-256:
  `A335FF4972694DBE531B46F852D2C77F13E433B365D0D38289B25ADFEADF2C62`
- Scope: authority local pages 1-44 / combined-reader pages 679-722.

The Polo-Gille PDF image decides. Existing GPU OCR and the Reinhold English
lineage were used only as locator/drafting/comparison witnesses.

## Method

- Each of the four authority diagrams was rendered and inspected individually
  at 5,000 dpi.
- Each compiled native diagram was rendered from the final English PDF and
  inspected individually at 5,000 dpi.
- Page context at 600 dpi was used only to confirm placement, seams, clipping,
  and surrounding prose. It did not carry the fidelity decision.
- Every node, edge, arrowhead, direction, repeated arrow, label, label side,
  prime/subscript, punctuation mark, and attachment to surrounding prose was
  compared manually by the lead session.
- No ambiguity remained after the 5,000-dpi comparison, so escalation to
  9,000 dpi was unnecessary.
- No mathematical or visual judgment was delegated.

## Row dispositions

1. `SGA3-X-DIAG-001`, authority local page 3 / reader page 5:
   PASS after one source-backed repair. The initial native reconstruction gave
   the fourth `b` crossing a duplicate lower-left auxiliary ray. The final
   source moves that ray to the upper-left, restoring the four-ray crossing
   visible in the authority. Four `b` nodes, three `c` nodes, six dots on each
   side, the alternating chain, and all auxiliary rays now match.
2. `SGA3-X-DIAG-002`, authority local page 4 / reader page 6:
   PASS. The three Hom objects in each row, vertical maps `u`, `u'`, `u''`,
   single first horizontal map, parallel second pair, arrow directions, and
   terminal comma match.
3. `SGA3-X-DIAG-003`, authority local page 4 / reader page 6:
   PASS. The two-by-two Hom square, corrected `M`/`N` ordering, two horizontal
   isomorphism labels, unlabeled vertical arrows, and terminal comma match.
4. `SGA3-X-DIAG-004`, authority local page 12 / reader page 14:
   PASS. The top horizontal arrow, two downward diagonal arrows, exterior
   isomorphism-label sides, and all three category nodes match. The neutral
   English abbreviation `EtCov` replaces the French `Rev. et.` without
   changing the mathematical diagram.

## Build and placement

- Final PDF:
  `build_loop2_native_r1/SGA3_Expose_X_English.pdf`
- Extent: 44 A4 pages.
- Bytes: 310,778.
- SHA-256:
  `116065B39DC227EA72863ED7C71BC925CC15E0C62AAAE88601B46C648CAF64A7`.
- Final log: 42,078 B; SHA-256:
  `A07E6E5B091CA251E5449489CEFA75589F59C15A1039984CFDD9BAC9CB345DDD`.
- Three final XeLaTeX passes exited 0.
- Active component closure: 4 native `\input` calls and 0 active
  `\includegraphics` calls.
- Page-context review passed reader pages 5, 6, and 14 with no clipping,
  collision, or seam regression.
- The two inherited bounded overfull hboxes remain 4.21538 pt and 0.78955 pt;
  neither clips or collides.

Exact row-level paths, bytes, hashes, source pages, reader pages, and evidence
identities are in `NATIVE_DIAGRAM_INVENTORY.csv`.
