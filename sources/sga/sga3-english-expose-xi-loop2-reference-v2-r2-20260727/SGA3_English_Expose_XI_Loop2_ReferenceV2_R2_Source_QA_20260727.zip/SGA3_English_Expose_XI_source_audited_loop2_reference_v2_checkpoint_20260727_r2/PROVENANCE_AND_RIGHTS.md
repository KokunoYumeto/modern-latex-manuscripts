# SGA 3 Exposé XI English checkpoint — provenance and rights

## Scope

This package contains the English reconstruction of **Exposé XI only**,
covering complete-reader pages 723–756 and stopping before page 757 /
Exposé XII. This is the hard stop. It is **not the whole of SGA 3**.

## Controlling source

The text, formulas, numbering, notes, page order, and diagrams were checked
against the Polo–Gille PDF `Expo11.pdf`:

- 34 A4 pages;
- 431,100 bytes;
- SHA-256
  `CDB58EA5518C29E998E12AEA8D958E488C466C3B12FE2ED178A009758A553EAD`;
- complete-reader pages 723–756.

The Polo–Gille PDF is the authority and page locator for this reconstruction.
It is **not recovered editor TeX**. No authority PDF or scan is included.
OCR is not authority and no OCR body is included.

## English comparison control

Jacob C. Reinhold's Exposé XI Markdown from commit
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` was used as credited comparison material
only and is not authority or independent corroboration:

- 113,921 bytes;
- SHA-256
  `763C7D413CC8772A00B50E42926CBC86F1E252D41AF86E5AA0A5245D87FE4FB5`.

That contributor declares CC BY 4.0 for the translation contribution while
excluding underlying French rights. This attribution does not make the
comparison source evidence.

## Rights statement

No license grant is asserted by this package for the underlying French text,
this English reconstruction, editorial additions, or third-party TeX
support. Rights remain with their respective holders. The comparison's
declared CC BY 4.0 terms are **no broader license** for the French source,
this independently revised reconstruction, or the package as a whole.

Redistribution rights are not asserted. Preservation metadata, attribution,
checksums, and technical validation do not themselves confer permission to
reproduce or redistribute copyrighted material. This is a provenance and
scope statement, not legal advice.

The package contains no authority PDF, scan, OCR body, comparison body,
private path, raw build cache, or internal task conversation.

## High-zoom diagram evidence

The frozen English reader was also checked under the Claude-style cold
reverify rule `SGA_DIAGRAM_CLAUDE_STYLE_COLD_REVERIFY_HIGH_ZOOM_CONTROL_20260727.md` (SHA-256
`8682D7E64EADF2E92F8015EF79BA337D3ADB062B232F296DEB6C4009360D10CB`). The package includes only target-side English
renders: five full pages at 300 dpi, eight whole native diagrams at 600 dpi,
and thirty targeted details at 1200 dpi.

Authority-derived source crops and the source/target forensic plates were used
locally for the audit but are deliberately omitted from this package. Their
omission avoids redistributing source-derived pixel evidence for which this
package asserts no license. Hashes and page locators are retained only as
audit metadata. The included target-side QA images do not imply any new
license grant for the English reconstruction or any underlying work. No new
license grant is made for those target-side images.
