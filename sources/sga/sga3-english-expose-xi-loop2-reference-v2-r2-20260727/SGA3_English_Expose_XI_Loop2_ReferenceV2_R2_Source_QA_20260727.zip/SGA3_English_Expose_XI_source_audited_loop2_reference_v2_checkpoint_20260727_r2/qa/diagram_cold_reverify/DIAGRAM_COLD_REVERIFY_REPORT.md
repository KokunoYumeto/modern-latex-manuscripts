# SGA3 Exposé XI target-only diagram cold reverify evidence

**Result: PASS.** A fresh nonauthor reviewed all eight native diagrams against
the exact Polo–Gille Exposé XI authority, including node/arrow/label
inventories, primes/subscripts, terminal punctuation, and surrounding
grammar. The frozen English reader is `SGA3_Expose_XI_English.pdf`, 38
pages, SHA-256 `E849010ADA0D36B3A06CA6DC5D082888E64A918C53A721526CFA2A52411FF553`.

The controlling high-zoom rule is
`SGA_DIAGRAM_CLAUDE_STYLE_COLD_REVERIFY_HIGH_ZOOM_CONTROL_20260727.md`, 4268 bytes, SHA-256
`8682D7E64EADF2E92F8015EF79BA337D3ADB062B232F296DEB6C4009360D10CB`. The audit used four authority-derived source crops
at 300 dpi, eight authority diagrams at 600 dpi, thirty authority detail crops at
1200 dpi, and eight source/target forensic plates. Those authority-derived
pixels are deliberately excluded from this public projection. Their exact
hashes and source-page locators remain in the portable ledger.

This package includes only target-side evidence: five full English pages at
300 dpi, eight whole English diagrams at 600 dpi, and thirty targeted English
detail crops at 1200 dpi. Diagram 03 was re-cropped before freeze so both
nodes `S'` and `F` are visible. Diagram 02 retains a deliberate English comma
after `G` because its surrounding English sentence continues after the
display. No TeX/PDF repair was required.

No authority PDF, source crop, or source/target forensic plate is included.
No license grant or redistribution right is asserted by this evidence set.
