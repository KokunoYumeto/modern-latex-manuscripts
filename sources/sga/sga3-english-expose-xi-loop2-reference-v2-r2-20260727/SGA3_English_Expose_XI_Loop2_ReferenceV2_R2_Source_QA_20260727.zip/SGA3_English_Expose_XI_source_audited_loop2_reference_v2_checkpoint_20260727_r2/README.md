# SGA 3 Exposé XI — English Loop2/reference-v2 checkpoint

This bounded checkpoint contains the complete English Exposé XI body,
editable LaTeX, a 38-page A4 reader, eight native TeX diagrams, an exhaustive
reference-v2 graph, source-correction and translation-QA ledgers, all-page
renders, a target-only high-zoom diagram evidence projection, and independent
validation.

## Exact scope

- Authority component: `Expo11.pdf`, standalone pages 1–34,
  complete-reader pages 723–756.
- English body: Introduction and Sections 1–6 through terminal Remark 6.12
  and its terminal note.
- Hard stop: before complete-reader page 757 and the first nonblank page of
  Exposé XII.
- Exposé XII and later are outside this checkpoint.
- This is a bounded Exposé XI checkpoint, not a complete SGA 3 reader.
- It is not the whole of SGA 3.

## Principal files

- `source/tex/SGA3_Expose_XI_English.tex` — cumulative Exposé XI master.
- `reader/SGA3_Expose_XI_English.pdf` — audited 38-page reader.
- `reference/REFERENCE_TARGETS.csv`
- `reference/REFERENCE_CANDIDATES.csv`
- `reference/REFERENCE_EDGES.csv`
- `reference/REFERENCE_RESIDUALS.csv`
- `reference/REFERENCE_REVISION_MAP.csv`
- `qa/SOURCE_CORRECTIONS_AND_ADVERSE_CHOICES.csv`
- `qa/FULL_EXPOSE_TRANSLATION_QA.csv`
- `qa/diagram_cold_reverify/DIAGRAM_COLD_REVERIFY_RECEIPT.json`
- `qa/INDEPENDENT_AUDIT.json`
- `SHA256SUMS.csv`

## Local build

From the extracted package, change into `source`, create a separate output
directory, and run XeLaTeX three times:

```text
cd source
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XI_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XI_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_XI_English.tex
```

Generated build files are not part of the checkpoint.

The high-zoom diagram evidence includes only target-side English renders.
Authority-derived source crops and source/target forensic plates are excluded.
A fresh independent extracted-package replay must re-review the widened
Diagram 03 target evidence before any custody dispatch; the packaged
prepackage audit is not that final extracted-package certification.

See `PROVENANCE_AND_RIGHTS.md` before any redistribution.
