# SGA 3 Exposé IX — Session-B native/high-zoom successor

Status: **LOCAL PASS — ready as one exact cumulative input; no archive/publication claim**

This copy-on-write successor preserves the source-audited Exposé IX English text and convention-v2 reference layer while replacing the older diagram-fidelity disposition with a complete top-level 5,000-dpi review of every native diagram.

## Exact scope

- Exposé IX only.
- Authority local pages 1–32 / combined pages 647–678.
- Hard stop before Exposé X / combined page 679.
- Authority SHA-256: `7C1E3D5B9D01AD01D0DD7B8B62045D012052E7890FB37ADC3E7934EBB5FD6FC3`.

## Native-diagram closure

- 8/8 native environments reviewed personally against direct 5,000-dpi authority crops.
- 4 passed unchanged.
- 4 required five exact source-backed repairs: one terminal-punctuation removal, two horizontal-label side corrections, and two vertical-label side corrections.
- Final result: 8/8 PASS, unresolved 0.
- Active raster calls: 0.
- PDF image XObjects: 0.

## Active source and build

- Active editable closure: 7 files, exactly listed in `controls/ACTIVE_SOURCE_SHA256.csv`.
- Native environments: 7 `tikzcd` + 1 `tikzpicture`.
- Final build: 3 XeLaTeX passes, exit 0/0/0; pass 2 and pass 3 console logs byte-identical; blocking diagnostics 0.
- PDF: `build/SGA3_Expose_IX_English.pdf`.
- PDF identity: 36 pages / 267,680 bytes / SHA-256 `AD6EC9FA9F6D25EBBD0E914D104F1B765FCD45878FE302DAF853B4AA6331DDBC`.
- Reference objects: 276 named destinations; 288/288 internal GoTo actions resolve; 0 URI/other actions.

## Contamination exclusion

The literal `$build` directory is a preserved first-build accident containing 5 generated files / 332,810 bytes. It is excluded from active source, evidence claims, manifests, and cumulative input. See `controls/CONTAMINATION_EXCLUSION.md`. Only `tex` and the intended sibling `build` directory are adjudicative.

## Integration rule

Future cumulative integration must consume the seven files in `controls/ACTIVE_SOURCE_SHA256.csv` exactly once and regenerate cumulative page/destination coordinates. The predecessor convention-v2 controls remain history/reference material, not a substitute for freshly regenerated cumulative graph data.

No standalone archive dispatch is authorized from this root.
