# Literal `$build` contamination exclusion

The literal directory named `$build` at this root is non-adjudicative build contamination from an incorrectly quoted first build command.

- It contains 5 generated files totaling 332,810 bytes.
- It is excluded from `ACTIVE_SOURCE_SHA256.csv`, every evidence or delivery claim, and every future cumulative input.
- The intended converged build is the sibling directory `build`.
- No source file imports or depends on the literal `$build` directory.
- Cumulative integration must copy only the seven active files listed in `controls/ACTIVE_SOURCE_SHA256.csv` and must not copy `$build`.

This exclusion is append-only provenance; it does not delete or conceal the contaminated first build.
