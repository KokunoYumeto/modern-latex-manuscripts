# Lead native-diagram 5,000-dpi review — PASS

## Scope and authority

- Scope: SGA 3, Exposé IX only, all 8 native diagram environments.
- Controlling authority: `Expo9.pdf`, local pages 1–32 / combined pages 647–678.
- Authority SHA-256: `7C1E3D5B9D01AD01D0DD7B8B62045D012052E7890FB37ADC3E7934EBB5FD6FC3`.
- Active English source: the seven files in `controls/ACTIVE_SOURCE_SHA256.csv`.
- Review was performed personally by the top-level Session-B lead; no agent made mathematical or visual judgments.

## Method

Every authority diagram was rendered directly from the controlling PDF at 5,000 dpi and compared against a 5,000-dpi crop of the rebuilt native English output. The review checked every object, superscript, subscript, prime, hat, arrow, arrowhead, direction, double-arrow multiplicity, vertical/horizontal attachment, label side, label placement, and terminal punctuation. No 300-dpi evidence carried any fidelity decision. Existing lower-resolution material was used only for navigation.

## Result

- 8/8 native diagrams reviewed.
- 4/8 passed unchanged: DIAG-001, DIAG-002, DIAG-004, DIAG-005.
- 4/8 required source-backed repair: DIAG-003, DIAG-006, DIAG-007, DIAG-008.
- Five exact strict-fidelity repairs were made:
  1. DIAG-003: removed an authority-absent terminal period after the lower exact row.
  2. DIAG-006: moved `\widehat\varphi` above the lower horizontal arrow.
  3. DIAG-007: moved `\Psi` above the lower horizontal arrow.
  4. DIAG-008: moved vertical label `u` to the right of its arrow.
  5. DIAG-008: moved vertical label `u'` to the right of its arrow.
- All repaired diagrams were rebuilt and re-compared at 5,000 dpi.
- Final disposition: 8/8 PASS.

The row-level evidence and source/output crop paths are recorded in `controls/NATIVE_DIAGRAM_INVENTORY.csv`.

## Build and PDF checks

- Three XeLaTeX passes completed with exit code 0.
- Pass 2 and pass 3 console logs are byte-identical.
- Blocking diagnostics: 0.
- Final PDF: 36 A4 pages, 267,680 bytes.
- PDF SHA-256: `AD6EC9FA9F6D25EBBD0E914D104F1B765FCD45878FE302DAF853B4AA6331DDBC`.
- Active source: 7 `tikzcd` environments + 1 `tikzpicture`, 0 `\includegraphics`.
- PDF image XObjects: 0.
- Named destinations: 276.
- Internal GoTo actions: 288/288 resolved; broken: 0.

## Exclusion

The literal `$build` directory is excluded as documented in `controls/CONTAMINATION_EXCLUSION.md`. It is not an active build, source dependency, manifest member, or cumulative input.
