# Lead native-diagram 5,000-dpi review — PASS

## Scope and authority

- Scope: SGA 3, Exposé XI only, all 8 native diagram environments.
- Controlling authority: `Expo11.pdf`, local pages 1–34 / combined pages 723–756.
- Authority SHA-256: `CDB58EA5518C29E998E12AEA8D958E488C466C3B12FE2ED178A009758A553EAD`.
- Active English source: the 13 files in `controls/ACTIVE_SOURCE_SHA256.csv`.
- The top-level Session-B lead performed every mathematical and visual judgment personally; no agent audited the diagrams.

## Method

Every authority diagram was rendered directly from the controlling PDF at 5,000 dpi and compared with a 5,000-dpi crop of the native English output. The comparison covered every node, prime, subscript, arrow, arrowhead, direction, attachment, label, label side, label placement, and terminal punctuation. Existing 600/1200-dpi evidence remains legitimate history, but no 300-dpi evidence carried any fidelity decision in this closure.

## Result

- 8/8 native diagrams reviewed.
- 6/8 passed unchanged: DIAG-001, DIAG-003, DIAG-005, DIAG-006, DIAG-007, DIAG-008.
- 2/8 required four exact source-backed repairs:
  1. DIAG-002: moved `u_0` from the left to the right of the left vertical arrow.
  2. DIAG-002: moved `v` from the right to the left of the right vertical arrow.
  3. DIAG-002: moved `f` from below to above the lower horizontal arrow.
  4. DIAG-004: moved `u_0` from below to above the lower horizontal arrow.
- Both repaired diagrams were rebuilt and re-compared at 5,000 dpi.
- Final disposition: 8/8 PASS, unresolved 0.

The row-level source/output evidence is recorded in `controls/NATIVE_DIAGRAM_INVENTORY.csv`.

## Build and PDF checks

- Three XeLaTeX passes completed with exit code 0.
- Blocking diagnostics: 0; the final log contains only XeTeX's benign `inputenc` notice.
- Final PDF: 38 A4 pages, 268,273 bytes.
- PDF SHA-256: `C5E0A127C7B61C3DCDFB3560D201F6E7FF35A5E1A0D0145370C21B0FD20F6963`.
- Active source: 8 `tikzcd` environments, 0 `tikzpicture`, 0 `\includegraphics`.
- PDF image XObjects: 0.
- Named destinations: 297.
- Internal GoTo actions: 328/328 resolved; broken: 0.
- Fonts: 32/32 embedded; Type 3 fonts: 0.
