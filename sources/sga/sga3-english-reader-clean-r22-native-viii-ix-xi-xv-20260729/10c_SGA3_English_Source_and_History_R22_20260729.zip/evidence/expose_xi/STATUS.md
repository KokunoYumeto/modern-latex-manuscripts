# SGA 3 Exposé XI — Session-B native/high-zoom successor

Status: **LOCAL PASS — ready as one exact cumulative input; no archive/publication claim**

This copy-on-write successor preserves the source-aligned Exposé XI English text and reference-v2 layer while replacing the older diagram-fidelity disposition with a complete top-level 5,000-dpi review of every native diagram.

## Exact scope

- Exposé XI only.
- Authority local pages 1–34 / combined pages 723–756.
- Hard stop before Exposé XII / combined page 757.
- Authority SHA-256: `CDB58EA5518C29E998E12AEA8D958E488C466C3B12FE2ED178A009758A553EAD`.

## Native-diagram closure

- 8/8 native environments reviewed personally against direct 5,000-dpi authority crops.
- 6 passed unchanged.
- 2 required four exact source-backed label-side repairs.
- Final result: 8/8 PASS, unresolved 0.
- Active raster calls: 0.
- PDF image XObjects: 0.

## Active source and build

- Active editable closure: 13 files / 147,746 bytes, exactly listed in `controls/ACTIVE_SOURCE_SHA256.csv`.
- Native environments: 8 `tikzcd`.
- Final build: 3 XeLaTeX passes, exit 0/0/0; blocking diagnostics 0.
- PDF: `build/SGA3_Expose_XI_English.pdf`.
- PDF identity: 38 pages / 268,273 bytes / SHA-256 `C5E0A127C7B61C3DCDFB3560D201F6E7FF35A5E1A0D0145370C21B0FD20F6963`.
- Reference objects: 297 named destinations; 328/328 internal GoTo actions resolve; broken 0.
- Fonts: 32/32 embedded; Type 3 fonts 0.

## Integration rule

Future cumulative integration must consume the 13 files in `controls/ACTIVE_SOURCE_SHA256.csv` exactly once and regenerate cumulative page/destination coordinates. The predecessor reference-v2 controls remain history/reference material, not a substitute for freshly regenerated cumulative graph data.

No standalone archive dispatch is authorized from this root.
