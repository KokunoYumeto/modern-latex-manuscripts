# Lead native-diagram review — Exposé VIII

Date: 2026-07-29

Result: **PASS after three source-backed label-side repairs.**

## Authority

- Polo–Gille Exposé VIII PDF, 30 pages, 440,912 bytes.
- SHA-256: `06E43E0571D411CC5579975778FCC03C8ECAA67189248D1A053E61DC653AF510`.
- The PDF image is the deciding witness. No OCR output was used to adjudicate a diagram.

## Method

The session lead inspected every Exposé-VIII diagram directly against the
authority at approximately 5,000 dpi. Thirteen overlapping authority details
cover the four diagrams. Each review checked nodes, arrows, direction,
arrowheads, curvature, label text, label side/placement, primes and indices,
punctuation, and attachment to the surrounding formula or sentence. The
private authority details live under `qa/lead_authority_5000dpi`; they are
review evidence, not delivery images.

## Diagram dispositions

1. `SGA3-VIII-D01`, authority local p6 / combined p622: six nodes and six
   arrows in the cocycle diagram. The native source placed
   \(c_{ki}\times\operatorname{id}_{S_j}\) below the bottom arrow, while the
   authority places it above. The label side was corrected. All remaining
   nodes, labels, equality arrows, directions, and the terminal period match.
2. `SGA3-VIII-D02`, authority local p6 / combined p622: the three-node descent
   triangle and labels \(p_{21}^{*}(c)\), \(p_{31}^{*}(c)\), and
   \(p_{32}^{*}(c)\) match unchanged, including the terminal period.
3. `SGA3-VIII-D03`, authority local p14 / combined p630: the \(u,v,w\)
   three-node chain matches unchanged, including the curved composite arrow
   and terminal comma.
4. `SGA3-VIII-D04`, authority local p27 / combined p643: the four-node,
   five-arrow group-scheme diagram had two label-side deviations. The diagonal
   \(v_n\) and bottom \(p^\nu\operatorname{id}_{G_n}\) labels were moved above
   their arrows. Both \(u_n\) labels, the top label, all directions and
   arrowheads, and the terminal period match.

## Rebuild and rendered verification

- Three XeLaTeX passes exited zero.
- Passes 2 and 3 have byte-identical console output, SHA-256
  `28968CDDE3DBD327BE46D7EDC52D11A4C254CB412CCC36E6B7D1D42C73623B6E`.
- Final PDF: 31 A4 pages, 248,282 bytes, SHA-256
  `73C33187701407CD15BD081E04E67D7925FBF180D57DBDFDFD28B4600BB1F6EF`.
- English pages 7, 8, 16, and 28 were rendered at 600 dpi after the edits and
  manually checked for placement, clipping, collision, and surrounding
  punctuation.
- `pdfimages -list` reports zero image objects.
- Active content contains four native `tikzcd` environments and no
  `\includegraphics` call. The shared macro file retains one dormant locator
  macro definition containing `\includegraphics`; it has no call site in this
  reader and produces no image object.

The prior lower-resolution evidence is retained as history. This receipt is the
controlling lead-level 5,000-dpi closure for Exposé VIII.
