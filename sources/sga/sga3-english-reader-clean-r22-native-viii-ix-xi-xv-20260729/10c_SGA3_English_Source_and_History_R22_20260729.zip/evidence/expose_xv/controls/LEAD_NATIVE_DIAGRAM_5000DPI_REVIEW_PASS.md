# Exposé XV lead native-diagram review — PASS

Date: 2026-07-29

## Scope and authority

- Scope: all 14 native diagram environments in SGA3 Exposé XV.
- Authority: `Expo15.pdf`, 625,595 bytes, 68 pages, SHA-256
  `03647E0232067A7508BB1350E7AACE3E88D58872956F068CED808A4F9CC3273F`.
- Authority range: local pages 1–68 / combined-reader pages 871–938.
- English hard stop: before Exposé XVI / combined-reader page 939.

The top-level Session-B lead compared every diagram directly against a
tight authority crop rendered at 5,000 dpi. No OCR or contact sheet carried
the mathematical or visual judgment. The review checked nodes, arrows,
arrowheads, direction, curvature, attachment, label text, primes and
indices, label side and placement, punctuation, and attachment to the
surrounding formula or sentence.

## Disposition

- Reviewed: 14/14.
- Final PASS: 14/14.
- Source-backed repaired diagrams: 12/14 (`001`–`011` and `013`).
- Unchanged after direct comparison: 2/14 (`012` and `014`).
- Native TeX environments: 14.
- Active `\includegraphics` calls: 0.
- Raster objects in the final PDF: 0.

The highest-impact repair was diagram `005`: its tensor source is now one
column left, its two diagonal arrows and separate vertical map reproduce the
authority, and the final native diagram is tight enough to remain wholly
inside the text block. The exact final 5,000-dpi English crop is
`qa\lead_english_5000dpi_final\D05_english_final_5000dpi.png`.

The complete per-diagram disposition, locators, repair text, and paired
evidence hashes are in `NATIVE_DIAGRAM_INVENTORY.csv`. Earlier lower-resolution
evidence remains history; it was not used as a substitute for this lead
5,000-dpi closure.

## Build and page-layout check

After the repairs, the active master was rebuilt through three successful
XeLaTeX passes. The result is:

- `build_loop2_5000dpi_r1\SGA3_Expose_XV_English.pdf`
- 383,246 bytes
- 66 A4 pages
- SHA-256
  `461E35451A88CABD959D2A1BE185B462E5E5E1AFF10822D5D0A19145BB6615C4`

Affected and adjacent pages 5, 6, 10, 12, 13, 15, 18, 23, 32, and 44 were
rendered at 600 dpi for page-layout review only. They show no clipping,
collision, diagram overflow, or broken attachment to surrounding prose.

The final log has no TeX error, undefined control sequence, fatal stop,
undefined-reference warning, duplicate-destination warning, or missing-glyph
diagnostic. Three pre-existing prose overfull boxes remain (4.13391 pt,
21.75345 pt, and 1.35687 pt); none intersects a diagram. The PDF has 37
internal named links, all resolving to in-document pages, and no raster image
objects. All 36 font resources reported by `pdffonts` are embedded and
non-Type3.

## Exclusions

The literal `$out` subtree is accidental non-adjudicative scratch and is
excluded from the active-source manifest and every cumulative-input claim.
Private authority crops and QA renders are evidence only; the cumulative
integration surface is exactly the 12 files in `ACTIVE_SOURCE_SHA256.csv`.
