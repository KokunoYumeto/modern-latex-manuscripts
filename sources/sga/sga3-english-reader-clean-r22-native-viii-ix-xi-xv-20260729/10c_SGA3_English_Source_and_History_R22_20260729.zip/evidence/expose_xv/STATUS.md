# SGA3 Exposé XV — native Loop-2 / lead 5,000-dpi successor

Status: **LOCALLY CLOSED FOR CUMULATIVE INTEGRATION**

This no-overwrite successor closes the Session-B-owned Exposé XV native
diagram set. It preserves the completed English prose and equations and
changes only source-backed native-diagram details.

## Authority and boundary

- Authority: Polo–Gille `Expo15.pdf`, 625,595 bytes, 68 pages,
  SHA-256
  `03647E0232067A7508BB1350E7AACE3E88D58872956F068CED808A4F9CC3273F`.
- Coverage: authority local pages 1–68 / combined pages 871–938.
- Hard stop: before Exposé XVI / combined page 939.

## Exact active result

- Active editable closure: 12 files in `controls\ACTIVE_SOURCE_SHA256.csv`.
- Native diagrams: 14/14.
- Lead direct-authority 5,000-dpi review: 14/14 PASS.
- Repaired after direct comparison: 12.
- Unchanged after direct comparison: 2.
- Active raster calls: 0.
- Final PDF raster image objects: 0.

Final reader:

- `build_loop2_5000dpi_r1\SGA3_Expose_XV_English.pdf`
- 383,246 bytes / 66 A4 pages
- SHA-256
  `461E35451A88CABD959D2A1BE185B462E5E5E1AFF10822D5D0A19145BB6615C4`

The full per-diagram ledger is
`controls\NATIVE_DIAGRAM_INVENTORY.csv`; the lead review receipt is
`controls\LEAD_NATIVE_DIAGRAM_5000DPI_REVIEW_PASS.md`. Final machine checks
are recorded in `controls\FINAL_LOCAL_VALIDATION.json`.

## Build and PDF checks

- Three successful XeLaTeX passes after the final edits.
- TeX/fatal/undefined/destination/missing-glyph diagnostics: 0.
- Native `tikzcd` environments: 14.
- `\includegraphics`: 0.
- PDF image objects: 0.
- Internal named links: 37/37 resolve to in-document pages.
- Fonts: 36/36 embedded, no Type3.
- Affected/adjacent page layouts reviewed at 600 dpi after the 5,000-dpi
  mathematical diagram review.

The remaining three overfull diagnostics are prose-only and do not touch a
diagram.

## Exclusions and claims

The literal `$out` subtree is accidental scratch and is excluded. QA crops
are private evidence, not deliverable raster content. This root is an exact
cumulative integration input only. It makes no standalone archive,
publication, or public-readback claim.
