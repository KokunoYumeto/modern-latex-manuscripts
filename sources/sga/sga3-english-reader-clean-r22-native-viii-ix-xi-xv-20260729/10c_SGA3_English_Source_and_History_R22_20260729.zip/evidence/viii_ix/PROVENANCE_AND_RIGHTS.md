# Provenance and rights

The controlling authority identities are:

- Expose VIII: Polo-Gille authority PDF SHA-256
  `06E43E0571D411CC5579975778FCC03C8ECAA67189248D1A053E61DC653AF510`.
- Expose IX: Polo-Gille authority PDF SHA-256
  `7C1E3D5B9D01AD01D0DD7B8B62045D012052E7890FB37ADC3E7934EBB5FD6FC3`.

Those PDFs and their high-zoom crops are excluded. Their hashes, pages, linked
source locations, crop dimensions, and QA dispositions are retained in the
visual-evidence ledger. Bounding boxes were not recorded in the local controls
and are therefore reported as unavailable rather than reconstructed.

OCR and comparison translations are locator and drafting witnesses only.
Jacob Reinhold's SGA Markdown at revision
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` is credited comparison lineage
under his stated CC BY 4.0 terms for his contribution. It is not authority or
independent corroboration. No redistribution right or blanket license for the
underlying French material is asserted here.
