# SGA 3 Exposes VIII-IX high-zoom native integration inputs

This compact archive preserves the completed Expose VIII and Expose IX inputs
for the next cumulative SGA 3 reader. It contains the exact active editable
sources, final PDFs, validation controls, diagram inventories, and lead-review
receipts.

## Scope

- Expose VIII: 31 A4 pages, 10 active TeX files, 4/4 native diagrams reviewed
  directly at 5,000 dpi, with three source-backed layout repairs.
- Expose IX: 36 A4 pages, 7 active TeX files, 8/8 native diagrams reviewed
  directly at 5,000 dpi, with five source-backed repairs.
- Raster diagram delivery: none.
- PDF image objects: zero in both readers.

Authority PDFs and authority crops are not redistributed. The
`VISUAL_EVIDENCE_DISPOSITION.csv` ledger records every local high-zoom crop by
hash, dimensions, source page, linked TeX location, and disposition. Authority
pixels are rights-blocked; target render crops are excluded because they merely
re-rasterize the supplied PDFs. Raw logs, temporary builds, the accidental
`$build` tree, and superseded reference material are also excluded.

This is a bounded GitHub custody package and cumulative-reader input. It is not
a separate current Zenodo reader, not complete SGA 3, and not a critical
edition. The direct cumulative reader remains the reader-facing object on the
existing SGA Zenodo concept.

Jacob Reinhold's SGA Markdown at revision
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` is comparison and drafting lineage,
not source authority. No blanket license over the underlying French works or
the reconstructed package is asserted.
