# SGA 3 Exposé VIII — English Loop2/reference-v2 checkpoint

This immutable checkpoint contains the complete English Exposé VIII body,
editable LaTeX, a 31-page A4 reader, native TeX diagrams, the exhaustive
reference-v2 graph, source-correction and translation-QA ledgers, all-page
renders, and independent validation.

## Exact scope

- Authority component: `Exp8-8nov09.pdf`, standalone pages 1–30,
  complete-reader pages 617–646.
- English body: Sections 1–7, 58 numbered units, 22 equation tags,
  notes 0–42 plus five symbolic notes, four native diagrams, and the
  terminal `[RG71]`, `[TO70]` bibliography.
- Hard stop: before the first nonblank page of Exposé IX.
- Exposé VII belongs to a different production lane; Exposé IX and later are
  outside this checkpoint.
- This is a bounded Exposé VIII checkpoint, not a complete SGA 3 reader.

## Principal files

- `source/tex/SGA3_Expose_VIII_English.tex` — cumulative Exposé VIII master.
- `reader/SGA3_Expose_VIII_English.pdf` — audited 31-page reader.
- `reference/REFERENCE_TARGETS.csv`
- `reference/REFERENCE_CANDIDATES.csv`
- `reference/REFERENCE_EDGES.csv`
- `reference/REFERENCE_RESIDUALS.csv`
- `qa/SOURCE_CORRECTIONS_AND_ADVERSE_CHOICES.csv`
- `qa/FULL_EXPOSE_TRANSLATION_QA.csv`
- `qa/INDEPENDENT_AUDIT.json`
- `SHA256SUMS.csv`

## Validation result

- Ten-file TeX closure: one master, one macro support file, eight components.
- Source size: 118,060 bytes.
- Reference graph: 155 targets; 525 candidates =
  188 internal edges + 337 residuals.
- Remaining reference application actions: zero.
- Frozen reference application history: 95 reversible actions.
- Reader: 31 A4 pages, 697,649 bytes, SHA-256
  `255A62C74E5A9900AC92DFCD5379A730C12B86DF7727336AF2E04282BF14D230`.
- PDF objects: 248 local GoTo links, 270 named destinations, 28 embedded
  fonts, zero unresolved destinations.
- Three-pass build diagnostics: zero.
- Independent clean rebuild: extracted text and all 31 page rasters identical
  to the audited reader; `errors: []`.

All 31 page renders are included under `qa/renders/`.

## Local build

From the extracted package:

```text
cd source
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_VIII_English.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_VIII_English.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_VIII_English.tex
```

Create `source/local-build` first. Generated local build files are not part of
the frozen 65-file checkpoint.

## Cumulative integration status

This checkpoint is ready to be inserted after Exposé VII once that disjoint
range is complete. No I–VIII cumulative reader is claimed here because
Exposé VII is still owned and produced elsewhere. The packaged Exposé VIII
source must remain byte-preserved during that later no-overwrite integration.

See `PROVENANCE_AND_RIGHTS.md` before any redistribution.
