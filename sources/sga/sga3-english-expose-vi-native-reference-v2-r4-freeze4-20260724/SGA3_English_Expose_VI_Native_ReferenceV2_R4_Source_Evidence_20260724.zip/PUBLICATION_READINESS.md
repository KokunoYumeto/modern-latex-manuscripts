# Publication readiness - SGA 3 Exposé VI

State: **READY FOR EXACT EXTERNAL REPLAY; ARCHIVE HANDOFF HELD**.

Proposed reader files are the exact TeX master, its 90 active component files,
and the 185-page PDF identified in `STATUS.md`. Active machine evidence is:

- `controls/SOURCE_GENERATION_VALIDATION.json`;
- `controls/SOURCE_COMPONENT_IDENTITY.csv`;
- `controls/REFERENCE_ADJUDICATIONS_BASELINE.csv`;
- `controls/REFERENCE_MUTATIONS.csv`;
- `controls/REFERENCE_MUTATION_STATE.jsonl`;
- `controls/SUBAGENT_LOCATOR_ADJUDICATION.json`;
- `controls/POSTGENERATION_REFERENCE_ADJUDICATIONS.json`;
- the PASS outputs in `final_reference_v2_gate/`;
- `qa_reference_v2_r1/PAGE_RASTER_COMPARISON.csv`;
- `qa_reference_v2_r1/PDF_RENDER_METADATA_PRIVACY_VALIDATION.json`;
- the eight rendered contact sheets in `qa_reference_v2_r1/contact_sheets/`.

The public projection excludes inactive component parents, reproduction
scratch trees, raw page renders, raw compiler logs, and the archived FAIL
receipt. It includes a privacy-clean build summary instead of the raw log.

Authority and rights caveat: the corrected Polo-Gille PDFs control this
reconstruction. Jacob Reinhold's declared CC BY 4.0 Markdown is a credited
comparison lineage only. No blanket license is asserted here for the
underlying French edition or for third-party editorial material. This bounded
reader must not be described as the completed SGA3 translation.

Two fresh disjoint audits PASS against the producer tree:

1. complete tree/hash/privacy/machine-control replay: PASS;
2. PDF/reference/action/render/formula and mathematical-layout replay: PASS.

The earlier exact held-projection audit applies only to the superseded r1
projection. Freeze2 was fail-closed after an exact replay found internally
contradictory release-state prose, an overbroad audit claim, and a malformed
Exposé-VI-B authority hash in the README. Freeze3 corrected the release-state
metadata but retained that malformed hash and is also fail-closed. This
freeze4 candidate records the verified full 64-character authority hash
without changing the reader TeX or PDF. Its own exact external replay is
still required. Exact prerequisite and predecessor receipt identities are
recorded in `INDEPENDENT_RELEASE_AUDITS.md`.

No archive handoff is authorized by these internal files. If a fresh
external replay returns PASS, its append-only receipt may supersede this
hold and authorize the lead and English/Germanic manager to send one exact
additive handoff to archive maintenance. This producer must not publish
or duplicate that handoff. GitHub publication, Zenodo deposition, DOI
mutation, archive acknowledgment, and public readback remain unclaimed.
