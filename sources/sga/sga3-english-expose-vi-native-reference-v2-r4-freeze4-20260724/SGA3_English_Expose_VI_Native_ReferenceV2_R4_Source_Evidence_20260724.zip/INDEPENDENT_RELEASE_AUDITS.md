# Independent release audits and predecessor disposition - SGA 3 Exposé VI freeze4 candidate

This candidate binds two independent producer PASS surfaces. The
raw audit trees are not copied into the public payload because they include
replay scratch and environment-specific diagnostics. Their exact logical
workspace paths, byte counts, and SHA-256 identities are retained below.

## 1. Producer tree, privacy, and machine audit

Workspace-relative root:
`sga3_exposeVI_english_reconstruction_20260723/independent_review/final_reference_v2_tree_privacy_machine_20260724_r1`

- `INDEPENDENT_TREE_PRIVACY_MACHINE_AUDIT_PASS.md`:
  2,195 bytes, SHA-256
  `FCF8D5D3DDCCC71CA0BAA71EA8F0B3DE4A97371C3D2F75DD5D385A813432E368`;
- `INDEPENDENT_AUDIT_VALIDATION.json`:
  4,959 bytes, SHA-256
  `1B60EB61C9B49543266CAF73C682CDEAA31803AA4F9571CC33C28ABD245F85B0`.

Result: PASS.

## 2. PDF, reference, action, render, and layout audit

Working-translations-relative root:
`independent_review/sga3_exposevi_reference_v2_final_pdf_reference_render_audit_20260724`

- `INDEPENDENT_FINAL_AUDIT_PASS.md`:
  6,047 bytes, SHA-256
  `ABC9CE9CC0E1982E048F4E8E4D045A776BA349FB7AC205D99718EB1AE9FBAF68`;
- `INDEPENDENT_VALIDATION.json`:
  3,046 bytes, SHA-256
  `B2C8BFFE98BBCB47DF246C6EA1D430A4954AA9CCFDDC09F425EA05191B5C92B7`.

Result: PASS.

## 3. Superseded r1 exact held-projection replay

Working-translations-relative root:
`independent_review/sga3_exposeVI_public_projection_tree_replay_20260724_r1`

- `INDEPENDENT_PUBLIC_PROJECTION_AUDIT_PASS.md`:
  3,653 bytes, SHA-256
  `D476361D7982CB3D4D1C66C72CEEA0EF38C2F5F74750FBAE691C3B1E68BE00DF`;
- `INDEPENDENT_PUBLIC_PROJECTION_VALIDATION.json`:
  2,562 bytes, SHA-256
  `9A8CB7C2A0604F2F2A63DEB50149E6A190A628BD1D30B72723D563E6CE835B50`;
- `SHA256SUMS.csv`:
  224 rows, 25,505 bytes, SHA-256
  `C0E286754C452ED1E1212B98D0E82E2FBA4EE311490D5559F5EE293C8A44B0C3`.

Result: PASS for the 132-file/130-manifest-row r1 projection only. This
receipt did not audit freeze2, freeze3, or freeze4 and does not by itself
authorize handoff of this candidate.

## 4. Freeze2 and freeze3 adverse parents

Freeze2 is preserved outside this payload as a failed predecessor. Its
fresh exact replay confirmed the reader, PDF, reference, build, render,
privacy, rights, and manifest surfaces, but failed release-state coherence:
`README.md` and `PUBLICATION_CAVEATS.md` still described an audit hold while
other controls claimed manager-handoff readiness, and the cited exact
projection PASS belonged to r1. The same replay also found that the README
printed a malformed 59-character Exposé-VI-B authority hash.

Workspace-relative audit root:
`sga3_exposeVI_english_reconstruction_20260723/independent_review/public_projection_freeze2_exact_release_audit_20260724_r1`

- `INDEPENDENT_EXACT_RELEASE_AUDIT_FAIL.md`: 4,885 bytes, SHA-256
  `A5EB87CB463851E010467E84E833CCA4A7C718352786B7A16BC894B212F24E2D`;
- `INDEPENDENT_EXACT_RELEASE_AUDIT_VALIDATION.json`: 11,287 bytes,
  SHA-256
  `0B5171D8A5ABDC16C72A7EBF9C90D7C78BE17DD7BDA4C052F8754094E6B948AB`;
- `SHA256SUMS.csv`: 246 rows, 46,359 bytes, SHA-256
  `276FE7ADAD4A3CB38A7FFA919C6D330447DD0AF16921D97F2C00238E8C4558FC`.

Freeze3 corrected the release-state coherence and audit-scope language, but
was fail-closed before handoff because it retained the same malformed
authority hash. Freeze4 changes that provenance reading to the full
64-character SHA-256 verified independently against both local
1,051,354-byte, 112-page Polo-Gille witnesses:
`88D8CCB045FC959535155EB4B0FC72E3E4845730FB73355F2043E8023B7DB3D2`.

## Release consequence

The two producer audits close the substantive producer gates, but they do
not close the exact freeze4 tree gate. Freeze4 is ready for a fresh exact
external replay and remains held from archive handoff until that replay
returns PASS. A later external PASS receipt may supersede this hold without
changing the candidate bytes. No GitHub publication, Zenodo deposition,
DOI mutation, archive acknowledgment, or public readback is claimed by
this file.

The rights and scope caveats remain unchanged: Polo-Gille PDFs are the
French authority and are not redistributed; Jacob Reinhold's declared
CC BY 4.0 applies to the credited comparison lineage; underlying French
rights are retained; this is Exposé VI only, not complete SGA 3.
