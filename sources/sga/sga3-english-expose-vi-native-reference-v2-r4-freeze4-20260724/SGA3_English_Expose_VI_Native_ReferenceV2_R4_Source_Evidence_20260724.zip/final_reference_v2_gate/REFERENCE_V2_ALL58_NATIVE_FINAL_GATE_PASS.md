# SGA3 Exposé VI all-native convention-v2 final gate — PASS

This is a read-only gate against the delivered Exposé-VI successor master and PDF. No target TeX, master, or PDF byte was changed.

## Frozen identities

- Master: `tex_reference_v2/SGA3_Expose_VI_English_ReferenceV2.tex` — 8,926 B — SHA-256 `F5388E9978FD1D33CEA905EE892ED859089F8D0329005031033B414593E299B4`.
- PDF: `build_reference_v2_r1/SGA3_Expose_VI_English_ReferenceV2.pdf` — 965,557 B — 185 pages — SHA-256 `4891908E423F933B36E61295BDC0CC77948B60B64B727F6B3592AB73332CC5CF`.
- Delivered component closure: 90 TeX files.

## Exact gate result

- Status: **PASS**.
- Targets: 987 labels / 987 target destinations.
- Candidates: 7,629; edges: 672; residuals: 6,957.
- PDF replay: 1,224 named destinations; 948 internal GoTo annotations; 0 action deficits.
- External IV/V standalone residuals: 8 occurrences / 7 exact labels.

## Release blockers


The dominant target defect is recorded row-by-row in `DESTINATION_COLLISIONS.csv`; separately addressable subitems need distinct `\phantomsection`/semantic anchors. Every unwrapped or unadjudicated locator is recorded at delivered-file byte/line coordinates in `REFERENCE_RESIDUALS.csv` with status `FAIL`.

## Machine evidence

- `DESTINATION_COLLISIONS.csv` — 121 B — SHA-256 `3DA8B3423C57BC68FFE5DE0717E6E836D75813387AB9191715EE379E2DFC2759`.
- `EXTERNAL_REFERENCE_OCCURRENCES.csv` — 1,473 B — SHA-256 `1E5D3C90C9382F59FF78966DA6289756906E77E514776315A8CB7083FB8BE4E0`.
- `PDF_LINK_ACTION_REPLAY.csv` — 86,226 B — SHA-256 `569DA9CFE9E4E18A9A162AC0B6D1EE456C310BA6A9F72014653C558425C2B77E`.
- `REFERENCE_CANDIDATES.csv` — 4,752,980 B — SHA-256 `0C8D73ED420DC2571245FEF4BD2518684693A0F1001ACD923517AE830E845CD3`.
- `REFERENCE_EDGES.csv` — 433,535 B — SHA-256 `35F89FA208E0CAB89CC6388FD1FDDCE0B7254FDD4752187F08DC54E38063A1FD`.
- `REFERENCE_RESIDUALS.csv` — 4,190,223 B — SHA-256 `70096E1980730EBCC67F38627D7BB9E24C00A05C4EC1D565FF8F8FD10A5F750B`.
- `REFERENCE_REVISION_STATE.jsonl` — 9,088,300 B — SHA-256 `6C2012F7AE246C32016D4477C968FB6249D160F4034CB28896D7E032D0EDEFA7`.
- `REFERENCE_TARGETS.csv` — 403,205 B — SHA-256 `13745765EA3EA87FB4D0E07BC1179B1B52CDF5C52CABCE238E31868C44F2696D`.
- `REFERENCE_V2_GATE_VALIDATION.json` — 5,310 B — SHA-256 `45E32DA54BECF8728F3E0654CD7DFDB9855320AC076CB8316DFB2AFDDEBE374C`.
- `STRUCTURAL_TARGET_COVERAGE.csv` — 52,889 B — SHA-256 `D5E28ACB5F18325D92DF7B0AC52160539BF6093AB0C4453A37D015BF18564152`.
- `build_reference_v2_final_gate.py` — 80,468 B — SHA-256 `93A48669790260DE6528857738993ADE25277BA3C3E71C7EE97717B2A2D84F2C`.

The exact self-excluding manifest is `SHA256SUMS.csv`; it covers this receipt after the receipt is written and intentionally does not list itself.
