# Publication caveats - SGA 3 Exposé VI

This is a bounded English Exposé VI reader, not a completed SGA 3 volume
and not a critical edition.

- The corrected Polo-Gille PDFs are the controlling sources but are not
  redistributed in this payload. Publication of the English reconstruction
  does not grant rights in the underlying French sources.
- Jacob Reinhold's CC BY 4.0 Markdown translation is credited as a
  comparison and drafting lineage. It is not source authority or
  independent corroboration.
- No public editor LaTeX source was available when this reconstruction was
  made. The editable reader, formulas, and 58 source-bound diagrams were
  reconstructed from the PDFs. OCR served only as locator and drafting
  material.
- The active source contains native diagrams only: 60 `tikzcd`
  environments and zero `includegraphics` calls. Authority-derived crop
  witnesses are deliberately excluded from this public projection.
- Seven destinations in Exposés IV and V are outside this standalone
  reader. Their eight textual occurrences are explicitly classified as
  unavailable-source-target residuals and can be linked in a later
  cumulative reader.
- The PDF has descriptive metadata but is not represented as tagged or
  fully accessibility-remediated.
- Raw compiler logs are excluded because local TeX installation paths are
  not publication data. `build_reference_v2_r1/BUILD_SUMMARY_PUBLIC.txt`
  records the relevant build result and the exact hash of the final raw
  producer log.
- The producer PASS controls are included for external replay. This
  freeze4 candidate is internally validated and ready for a fresh exact
  external replay, but remains held from archive handoff until that replay
  returns PASS. An external PASS may supersede this hold without changing
  the frozen payload bytes.
- No GitHub publication, Zenodo deposition, DOI mutation, archive
  acknowledgment, or public readback is claimed by this projection.
  Archive maintenance owns publication.
