# SGA 3 Exposé VI - English native-diagram reference-v2 reader

This bounded checkpoint contains a standalone English reader for the whole
of SGA 3 Exposé VI in its assigned order:

1. Exposé VI A, source-local pages 1-38; then
2. Exposé VI B, source-local pages 1-111.

Exposé VI B local page 112 is a terminal blank source envelope and contains
no translated body. Exposé VII and later are outside this payload. This is
not the complete SGA 3 volume and is not a critical edition.

## Source and translation lineage

The controlling French sources are the corrected Polo-Gille PDFs:

- `Exp6A-13oct24.pdf`: 38 pages, 427,698 bytes, SHA-256
  `6C8795572D1FC3B21BD02D24B1BFB20A8FB447475702C2674C96939B1EB69582`;
- `Exp6B-13oct24.pdf`: 112 pages, 1,051,354 bytes, SHA-256
  `88D8CCB045FC959535155EB4B0FC72E3E4845730FB73355F2043E8023B7DB3D2`.

The authority PDFs are identified but not redistributed here. No editable
Polo-Gille source was publicly available when this reconstruction was made,
so the formulas and diagrams were reconstructed in LaTeX from the PDFs.
OCR was used only as locator and drafting material and is neither authority
nor part of this public projection.

Jacob Reinhold's English Markdown was used as a credited comparison and
drafting lineage:

- author: Jacob Reinhold;
- repository: <https://github.com/jcreinhold/sga>;
- revision: `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- Exposé VI A file: `iii/06A-generalities-on-algebraic-groups.md`,
  134,386 bytes, SHA-256
  `CBA8277A3187AFB989FB5B7AA741AE14ED96B08C911A21190CBFFE60E2748DC3`;
- Exposé VI B file: `iii/06B-generalities-on-group-schemes.md`,
  386,188 bytes, SHA-256
  `A3FEADE781D8155E2774740D0D01884B2D4DE613001CDC1285D51BD4CF3341C7`;
- declared license for that translation lineage: CC BY 4.0.

Reinhold's Markdown is not the French source authority and is not
independent corroboration.

## Reader identities

- TeX master:
  `tex_reference_v2/SGA3_Expose_VI_English_ReferenceV2.tex`,
  8,926 bytes, SHA-256
  `F5388E9978FD1D33CEA905EE892ED859089F8D0329005031033B414593E299B4`;
- active editable components: 90;
- PDF:
  `build_reference_v2_r1/SGA3_Expose_VI_English_ReferenceV2.pdf`,
  185 A4 pages, 965,557 bytes, SHA-256
  `4891908E423F933B36E61295BDC0CC77948B60B64B727F6B3592AB73332CC5CF`.

Run XeLaTeX from this projection root so that the
`tex_reference_v2/components` paths resolve exactly as packaged.

## Completed producer gates

- all 58 source-bound diagrams are native LaTeX reconstructions;
- the active source has 60 `tikzcd` environments and zero
  `includegraphics` calls;
- 987 unique structural targets and 672 linked internal edges;
- 7,629 exhaustive candidates partition into 672 edges and 6,957
  positively classified residuals;
- zero collapsed PDF destinations, unwrapped internal locators, structural
  target gaps, or PDF action deficits;
- 948 internal GoTo annotations and no URI actions;
- all 185 pages rendered and reviewed through eight contact sheets;
- canonical extracted body text is unchanged from the all-native baseline;
- metadata and active-source privacy checks pass.

The producer tree has passed independent machine/privacy and
PDF/reference/render audits. This no-overwrite freeze4 candidate is ready
for an exact external replay of its own frozen tree. It is not yet
authorized for archive handoff: a fresh external PASS must supersede that
hold without changing these bytes. Archive maintenance alone owns any
subsequent public upload.
