param(
    [string]$ProjectionRoot = $PSScriptRoot
)

$ErrorActionPreference = 'Stop'
$root = [System.IO.Path]::GetFullPath($ProjectionRoot)
$manifestName = 'ZENODO_PAYLOAD_MANIFEST.csv'
$validationName = 'PUBLIC_PROJECTION_VALIDATION.json'
$manifestPath = Join-Path $root $manifestName
$validationPath = Join-Path $root $validationName
$excludedFromManifest = @($manifestName, $validationName)

function Get-RelativePath([string]$path) {
    return [System.IO.Path]::GetRelativePath($root, $path).Replace('\', '/')
}

function Get-Sha256([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
}

function Get-Role([string]$path) {
    if ($path -eq 'tex_reference_v2/SGA3_Expose_VI_English_ReferenceV2.tex') {
        return 'reader_tex_master'
    }
    if ($path -like 'tex_reference_v2/components/*.tex') {
        return 'reader_tex_component'
    }
    if ($path -like 'build_reference_v2_r1/*.pdf') {
        return 'reader_pdf'
    }
    if ($path -like 'qa_reference_v2_r1/contact_sheets/*.png') {
        return 'rendered_visual_qa'
    }
    if ($path -eq 'build_reference_v2_r1/BUILD_SUMMARY_PUBLIC.txt') {
        return 'privacy_clean_build_evidence'
    }
    if ($path -eq 'LICENSE_AND_ATTRIBUTION.md') {
        return 'license_and_attribution'
    }
    if ($path -in @('README.md', 'STATUS.md', 'PUBLICATION_CAVEATS.md',
            'PUBLICATION_READINESS.md')) {
        return 'publication_control'
    }
    if ($path -eq 'validate_public_projection.ps1') {
        return 'projection_validation_script'
    }
    if ($path -eq 'PRODUCER_FREEZE_SHA256SUMS.csv') {
        return 'producer_freeze_provenance_manifest'
    }
    return 'machine_or_visual_evidence'
}

function Get-SourceBasis([string]$role) {
    if ($role -like 'reader_*') {
        return 'Polo-Gille PDFs authority; Reinhold e7a259f comparison lineage'
    }
    if ($role -in @('rendered_visual_qa', 'privacy_clean_build_evidence')) {
        return 'final projected reader'
    }
    return 'projection control or producer evidence'
}

function Get-Caveat([string]$role) {
    if ($role -like 'reader_*') {
        return 'bounded Expose VI reader; not complete SGA3; underlying French rights retained'
    }
    if ($role -eq 'producer_freeze_provenance_manifest') {
        return 'lists producer candidates including two intentionally excluded non-standalone scripts and two projection-overridden controls'
    }
    return 'producer audits PASS; exact freeze4 external replay pending; publication and readback remain unclaimed'
}

$payloadFiles = Get-ChildItem -LiteralPath $root -Recurse -File |
    Where-Object { (Get-RelativePath $_.FullName) -notin $excludedFromManifest } |
    Sort-Object FullName

$manifestRows = foreach ($file in $payloadFiles) {
    $rel = Get-RelativePath $file.FullName
    $role = Get-Role $rel
    [pscustomobject][ordered]@{
        path = $rel
        bytes = [int64]$file.Length
        sha256 = Get-Sha256 $file.FullName
        role = $role
        public_status = 'READY_FOR_EXACT_EXTERNAL_REPLAY'
        source_basis = Get-SourceBasis $role
        caveat = Get-Caveat $role
    }
}

$manifestRows | Export-Csv -LiteralPath $manifestPath -NoTypeInformation -Encoding utf8

$errors = [System.Collections.Generic.List[string]]::new()
$privacyHits = [System.Collections.Generic.List[object]]::new()
$csvReplay = [System.Collections.Generic.List[object]]::new()
$jsonErrors = [System.Collections.Generic.List[object]]::new()
$jsonlReplay = [System.Collections.Generic.List[object]]::new()

# Construct the private-path patterns without embedding a literal private path
# in this public validation script.
$slash = '[\\/]'
$privacyPatterns = [ordered]@{
    windows_absolute_path = '(?i)\b[A-Z]:' + $slash +
        '(?:Users|Program Files|Windows|tmp)(?:' + $slash + '|$)'
    user_profile_path = '(?i)' + $slash + 'Users' + $slash
    posix_user_path = '(?i)/(?:home|Users)/'
    internal_named_root = '(?i)' + ('CLA' + 'UDE') +
        '\s+PLEASE|' + ('_cl' + 'aude_aid')
    local_application_data = '(?i)AppData' + $slash
}

$textExtensions = @('.md', '.txt', '.csv', '.json', '.jsonl', '.tex', '.ps1')
foreach ($file in (Get-ChildItem -LiteralPath $root -Recurse -File)) {
    if ($file.Extension -notin $textExtensions) {
        continue
    }
    $text = [System.IO.File]::ReadAllText($file.FullName)
    foreach ($entry in $privacyPatterns.GetEnumerator()) {
        $matches = [regex]::Matches($text, $entry.Value)
        foreach ($match in $matches) {
            $privacyHits.Add([pscustomobject][ordered]@{
                path = Get-RelativePath $file.FullName
                pattern_id = $entry.Key
                offset = $match.Index
                excerpt_sha256 = [Convert]::ToHexString(
                    [Security.Cryptography.SHA256]::HashData(
                        [Text.Encoding]::UTF8.GetBytes($match.Value)
                    )
                )
            })
        }
    }
}

$formulaPrefixes = @('=', '+', '-', '@')
foreach ($file in (Get-ChildItem -LiteralPath $root -Recurse -File -Filter '*.csv')) {
    try {
        $rows = @(Import-Csv -LiteralPath $file.FullName)
        $headerLine = Get-Content -LiteralPath $file.FullName -TotalCount 1
        $headers = if ($headerLine) {
            @($headerLine -split ',' | ForEach-Object { $_.Trim().Trim('"') })
        }
        else {
            @()
        }
        $unsafe = 0
        foreach ($row in $rows) {
            foreach ($property in $row.PSObject.Properties) {
                $value = [string]$property.Value
                if ($value.Length -gt 0 -and $value.Substring(0, 1) -in $formulaPrefixes) {
                    $unsafe++
                }
            }
        }
        $csvReplay.Add([pscustomobject][ordered]@{
            path = Get-RelativePath $file.FullName
            rows = $rows.Count
            columns = $headers.Count
            rectangular = $true
            unsafe_formula_cells = $unsafe
        })
        if ($unsafe -ne 0) {
            $errors.Add("unsafe spreadsheet-formula cell in $(Get-RelativePath $file.FullName)")
        }
    }
    catch {
        $errors.Add("CSV parse failure in $(Get-RelativePath $file.FullName): $($_.Exception.Message)")
    }
}

foreach ($file in (Get-ChildItem -LiteralPath $root -Recurse -File -Filter '*.json')) {
    try {
        [void]([System.IO.File]::ReadAllText($file.FullName) | ConvertFrom-Json)
    }
    catch {
        $jsonErrors.Add([pscustomobject][ordered]@{
            path = Get-RelativePath $file.FullName
            error = $_.Exception.Message
        })
        $errors.Add("JSON parse failure in $(Get-RelativePath $file.FullName)")
    }
}

foreach ($file in (Get-ChildItem -LiteralPath $root -Recurse -File -Filter '*.jsonl')) {
    $records = 0
    $lineErrors = 0
    $ids = [System.Collections.Generic.List[string]]::new()
    foreach ($line in [System.IO.File]::ReadLines($file.FullName)) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }
        $records++
        try {
            $obj = $line | ConvertFrom-Json
            foreach ($candidate in @('record_id', 'revision_id', 'candidate_id', 'id')) {
                if ($null -ne $obj.$candidate -and [string]$obj.$candidate -ne '') {
                    $ids.Add([string]$obj.$candidate)
                    break
                }
            }
        }
        catch {
            $lineErrors++
        }
    }
    $duplicateIds = @($ids | Group-Object | Where-Object Count -gt 1).Count
    $jsonlReplay.Add([pscustomobject][ordered]@{
        path = Get-RelativePath $file.FullName
        records = $records
        parse_errors = $lineErrors
        duplicate_primary_ids = $duplicateIds
    })
    if ($lineErrors -ne 0 -or $duplicateIds -ne 0) {
        $errors.Add("JSONL parse/identifier failure in $(Get-RelativePath $file.FullName)")
    }
}

if ($privacyHits.Count -ne 0) {
    $errors.Add("$($privacyHits.Count) private-path pattern hits")
}

$manifest = @(Import-Csv -LiteralPath $manifestPath)
$manifestReplayErrors = [System.Collections.Generic.List[string]]::new()
foreach ($row in $manifest) {
    $path = Join-Path $root ($row.path.Replace('/', '\'))
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        $manifestReplayErrors.Add("missing $($row.path)")
        continue
    }
    $file = Get-Item -LiteralPath $path
    if ([int64]$row.bytes -ne $file.Length) {
        $manifestReplayErrors.Add("byte mismatch $($row.path)")
    }
    if ($row.sha256 -ne (Get-Sha256 $path)) {
        $manifestReplayErrors.Add("hash mismatch $($row.path)")
    }
}
if ($manifestReplayErrors.Count -ne 0) {
    $errors.Add("$($manifestReplayErrors.Count) manifest replay errors")
}

$masterRel = 'tex_reference_v2/SGA3_Expose_VI_English_ReferenceV2.tex'
$masterPath = Join-Path $root ($masterRel.Replace('/', '\'))
$masterText = [System.IO.File]::ReadAllText($masterPath)
$inputMatches = [regex]::Matches($masterText, '\\input\{([^}]+)\}')
$inputErrors = [System.Collections.Generic.List[string]]::new()
foreach ($match in $inputMatches) {
    $componentRel = $match.Groups[1].Value + '.tex'
    $componentPath = Join-Path $root ($componentRel.Replace('/', '\'))
    if (-not (Test-Path -LiteralPath $componentPath -PathType Leaf)) {
        $inputErrors.Add("missing active component $componentRel")
    }
}
if ($inputMatches.Count -ne 90) {
    $inputErrors.Add("active input count is $($inputMatches.Count), expected 90")
}
if ($inputErrors.Count -ne 0) {
    $errors.Add("$($inputErrors.Count) active-source closure errors")
}

$expectedMasterHash = 'F5388E9978FD1D33CEA905EE892ED859089F8D0329005031033B414593E299B4'
$pdfRel = 'build_reference_v2_r1/SGA3_Expose_VI_English_ReferenceV2.pdf'
$pdfPath = Join-Path $root ($pdfRel.Replace('/', '\'))
$expectedPdfHash = '4891908E423F933B36E61295BDC0CC77948B60B64B727F6B3592AB73332CC5CF'
if ((Get-Sha256 $masterPath) -ne $expectedMasterHash) {
    $errors.Add('master identity mismatch')
}
if ((Get-Sha256 $pdfPath) -ne $expectedPdfHash) {
    $errors.Add('PDF identity mismatch')
}

$gatePath = Join-Path $root 'final_reference_v2_gate\REFERENCE_V2_GATE_VALIDATION.json'
$gate = [System.IO.File]::ReadAllText($gatePath) | ConvertFrom-Json
if ($gate.status -ne 'PASS' -or @($gate.errors).Count -ne 0) {
    $errors.Add('final reference-v2 gate is not PASS/errors[]')
}

$producerValidationPath = Join-Path $root 'FINAL_PRODUCER_VALIDATION.json'
$expectedProducerValidationHash = 'D285113B45165D472D2F7E3A6C6DCE79A88C82B81944F076C052F33C7A8E6779'
if ((Get-Sha256 $producerValidationPath) -ne $expectedProducerValidationHash) {
    $errors.Add('producer validation identity mismatch')
}

$producerManifestPath = Join-Path $root 'PRODUCER_FREEZE_SHA256SUMS.csv'
$producerRows = @(Import-Csv -LiteralPath $producerManifestPath)
$producerExact = 0
$producerOverrides = [System.Collections.Generic.List[string]]::new()
$producerExcluded = [System.Collections.Generic.List[string]]::new()
$expectedOverrides = @('PUBLICATION_READINESS.md', 'STATUS.md')
$expectedExclusions = @(
    'build_reference_v2_successor.py',
    'final_reference_v2_gate/build_reference_v2_final_gate.py'
)
foreach ($row in $producerRows) {
    $path = Join-Path $root ($row.path.Replace('/', '\'))
    if ($row.path -in $expectedExclusions) {
        if (Test-Path -LiteralPath $path) {
            $errors.Add("non-standalone producer script unexpectedly projected: $($row.path)")
        }
        $producerExcluded.Add($row.path)
        continue
    }
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        $errors.Add("producer-manifest file missing from projection: $($row.path)")
        continue
    }
    $matches = ((Get-Item -LiteralPath $path).Length -eq [int64]$row.bytes) -and
        ((Get-Sha256 $path) -eq $row.sha256)
    if ($matches) {
        $producerExact++
    }
    elseif ($row.path -in $expectedOverrides) {
        $producerOverrides.Add($row.path)
    }
    else {
        $errors.Add("unexpected producer identity drift: $($row.path)")
    }
}
if ($producerOverrides.Count -ne 2 -or $producerExcluded.Count -ne 2) {
    $errors.Add('producer projection override/exclusion closure mismatch')
}

$auditReceiptRel = 'INDEPENDENT_RELEASE_AUDITS.md'
$auditReceiptPath = Join-Path $root $auditReceiptRel
$expectedAuditHashes = @(
    'FCF8D5D3DDCCC71CA0BAA71EA8F0B3DE4A97371C3D2F75DD5D385A813432E368',
    '1B60EB61C9B49543266CAF73C682CDEAA31803AA4F9571CC33C28ABD245F85B0',
    'ABC9CE9CC0E1982E048F4E8E4D045A776BA349FB7AC205D99718EB1AE9FBAF68',
    'B2C8BFFE98BBCB47DF246C6EA1D430A4954AA9CCFDDC09F425EA05191B5C92B7',
    'A5EB87CB463851E010467E84E833CCA4A7C718352786B7A16BC894B212F24E2D',
    '0B5171D8A5ABDC16C72A7EBF9C90D7C78BE17DD7BDA4C052F8754094E6B948AB',
    '276FE7ADAD4A3CB38A7FFA919C6D330447DD0AF16921D97F2C00238E8C4558FC'
)
$auditReceiptMissingHashes = [System.Collections.Generic.List[string]]::new()
if (-not (Test-Path -LiteralPath $auditReceiptPath -PathType Leaf)) {
    $errors.Add('independent release-audit receipt is missing')
}
else {
    $auditReceiptText = [System.IO.File]::ReadAllText($auditReceiptPath)
    foreach ($hash in $expectedAuditHashes) {
        if (-not $auditReceiptText.Contains($hash)) {
            $auditReceiptMissingHashes.Add($hash)
        }
    }
if ($auditReceiptMissingHashes.Count -ne 0) {
    $errors.Add("$($auditReceiptMissingHashes.Count) independent audit identities missing from receipt")
}
}

$releaseControlChecks = [ordered]@{
    'README.md' = @(
        'ready for an exact external replay',
        'not yet authorized for archive handoff',
        '88D8CCB045FC959535155EB4B0FC72E3E4845730FB73355F2043E8023B7DB3D2'
    )
    'PUBLICATION_CAVEATS.md' = @(
        'ready for a fresh exact external replay',
        'remains held from archive handoff'
    )
    'PUBLICATION_READINESS.md' = @(
        'READY FOR EXACT EXTERNAL REPLAY; ARCHIVE HANDOFF HELD',
        'No archive handoff is authorized by these internal files'
    )
    'STATUS.md' = @(
        'READY FOR EXACT EXTERNAL REPLAY; ARCHIVE HANDOFF HELD',
        'No archive handoff'
    )
    'INDEPENDENT_RELEASE_AUDITS.md' = @(
        'Superseded r1 exact held-projection replay',
        'Freeze4 is ready for a fresh exact external replay'
    )
}
foreach ($entry in $releaseControlChecks.GetEnumerator()) {
    $controlPath = Join-Path $root $entry.Key
    if (-not (Test-Path -LiteralPath $controlPath -PathType Leaf)) {
        $errors.Add("release control missing: $($entry.Key)")
        continue
    }
    $controlText = [System.IO.File]::ReadAllText($controlPath)
    $normalizedControlText = [regex]::Replace($controlText, '\s+', ' ')
    foreach ($requiredText in $entry.Value) {
        if ($normalizedControlText.IndexOf(
                $requiredText,
                [StringComparison]::OrdinalIgnoreCase
            ) -lt 0) {
            $errors.Add("release-state marker missing from $($entry.Key): $requiredText")
        }
    }
}

$unexpectedReadyClaims = [System.Collections.Generic.List[string]]::new()
foreach ($controlName in @(
        'README.md',
        'PUBLICATION_CAVEATS.md',
        'PUBLICATION_READINESS.md',
        'STATUS.md',
        'INDEPENDENT_RELEASE_AUDITS.md'
    )) {
    $controlPath = Join-Path $root $controlName
    $controlText = [System.IO.File]::ReadAllText($controlPath)
    if ($controlText.IndexOf(
            'READY FOR MANAGER ARCHIVE HANDOFF',
            [StringComparison]::OrdinalIgnoreCase
        ) -ge 0 -or
        $controlText.IndexOf(
            'ready for one exact manager-to-archive-maintenance handoff',
            [StringComparison]::OrdinalIgnoreCase
        ) -ge 0) {
        $unexpectedReadyClaims.Add($controlName)
    }
}
if ($unexpectedReadyClaims.Count -ne 0) {
    $errors.Add("premature manager-handoff claim in $($unexpectedReadyClaims -join ', ')")
}

$manifestStatusValues = @($manifest | Select-Object -ExpandProperty public_status -Unique)
if ($manifestStatusValues.Count -ne 1 -or
    $manifestStatusValues[0] -ne 'READY_FOR_EXACT_EXTERNAL_REPLAY') {
    $errors.Add('manifest public_status is not uniformly READY_FOR_EXACT_EXTERNAL_REPLAY')
}

$validation = [ordered]@{
    schema = 'sga3_expose_vi_public_projection_validation_v4_freeze4_candidate'
    status = if ($errors.Count -eq 0) { 'PASS_READY_FOR_EXACT_EXTERNAL_REPLAY' } else { 'FAIL' }
    promotion_authorized = $false
    publication_authorized = $false
    manager_archive_handoff_authorized = $false
    scope = 'SGA3 Expose VI A local 1-38 plus VI B local 1-111; VI B local 112 terminal blank envelope; Expose VII+ excluded'
    reader = [ordered]@{
        master = [ordered]@{
            path = $masterRel
            bytes = (Get-Item -LiteralPath $masterPath).Length
            sha256 = Get-Sha256 $masterPath
            active_components = $inputMatches.Count
        }
        pdf = [ordered]@{
            path = $pdfRel
            bytes = (Get-Item -LiteralPath $pdfPath).Length
            sha256 = Get-Sha256 $pdfPath
            pages = 185
            tagged_accessibility_claimed = $false
        }
    }
    reference_v2 = [ordered]@{
        status = $gate.status
        validation_path = 'final_reference_v2_gate/REFERENCE_V2_GATE_VALIDATION.json'
        validation_sha256 = Get-Sha256 $gatePath
        targets = $gate.target_count
        edges = $gate.edge_count
        candidates = $gate.candidate_count
        residuals = $gate.residual_count
        collapsed_destination_groups = $gate.collapsed_destination_group_count
        unwrapped_internal_locators = $gate.unadjudicated_or_internally_resolvable_unwrapped_count
        goto_annotations = $gate.pdf_goto_annotation_count
    }
    projection = [ordered]@{
        files_including_manifest_and_validation = $manifest.Count + 2
        payload_files_in_manifest = $manifest.Count
        payload_bytes = [int64](($manifest | ForEach-Object { [int64]$_.bytes } | Measure-Object -Sum).Sum)
        manifest_path = $manifestName
        manifest_bytes = (Get-Item -LiteralPath $manifestPath).Length
        manifest_sha256 = Get-Sha256 $manifestPath
        manifest_columns = 7
        manifest_replay_errors = @($manifestReplayErrors)
        producer_manifest_rows = $producerRows.Count
        producer_exact_files = $producerExact
        producer_projection_overrides = @($producerOverrides)
        producer_nonstandalone_script_exclusions = @($producerExcluded)
    }
    active_source = [ordered]@{
        input_count = $inputMatches.Count
        closure_errors = @($inputErrors)
        tikzcd_environment_count = ([regex]::Matches(
                ($masterText + "`n" + (($inputMatches | ForEach-Object {
                            $componentRel = $_.Groups[1].Value + '.tex'
                            [System.IO.File]::ReadAllText((Join-Path $root ($componentRel.Replace('/', '\'))))
                        }) -join "`n")),
                '\\begin\{tikzcd\}'
            )).Count
        includegraphics_count = ([regex]::Matches(
                ($masterText + "`n" + (($inputMatches | ForEach-Object {
                            $componentRel = $_.Groups[1].Value + '.tex'
                            [System.IO.File]::ReadAllText((Join-Path $root ($componentRel.Replace('/', '\'))))
                        }) -join "`n")),
                '\\includegraphics'
            )).Count
    }
    privacy = [ordered]@{
        pattern_ids = @($privacyPatterns.Keys)
        hits = @($privacyHits)
    }
    machine_readable = [ordered]@{
        csv_replay = @($csvReplay)
        json_errors = @($jsonErrors)
        jsonl_replay = @($jsonlReplay)
    }
    rights = [ordered]@{
        authority_pdfs_redistributed = $false
        ocr_redistributed = $false
        polo_gille_authority = $true
        reinhold_comparison_revision = 'e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e'
        reinhold_declared_translation_license = 'CC BY 4.0'
        underlying_french_rights_granted = $false
    }
    release = [ordered]@{
        state = 'READY_FOR_EXACT_EXTERNAL_REPLAY'
        independent_release_audits = 'PRODUCER_PASS_CURRENT_PROJECTION_PENDING_EXACT_EXTERNAL_REPLAY'
        audit_receipt_path = $auditReceiptRel
        audit_receipt_sha256 = if (Test-Path -LiteralPath $auditReceiptPath) {
            Get-Sha256 $auditReceiptPath
        }
        else {
            $null
        }
        expected_audit_identities = $expectedAuditHashes.Count
        missing_audit_identities = @($auditReceiptMissingHashes)
        archive_handoff_claimed = $false
        github_publication_claimed = $false
        zenodo_deposition_claimed = $false
        whole_sga3_completion_claimed = $false
    }
    errors = @($errors)
}

$validation | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $validationPath -Encoding utf8

if ($errors.Count -ne 0) {
    Write-Error "Projection validation failed with $($errors.Count) error(s)."
    exit 1
}

Write-Output "PASS_READY_FOR_EXACT_EXTERNAL_REPLAY"
Write-Output "manifest_rows=$($manifest.Count)"
Write-Output "manifest_sha256=$(Get-Sha256 $manifestPath)"
Write-Output "validation_sha256=$(Get-Sha256 $validationPath)"
