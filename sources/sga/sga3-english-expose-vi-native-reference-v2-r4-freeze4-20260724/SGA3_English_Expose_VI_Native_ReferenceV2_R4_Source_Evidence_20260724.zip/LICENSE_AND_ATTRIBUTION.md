# License and attribution - SGA 3 Exposé VI English reader

## Required attribution

The controlling French sources are the corrected Polo-Gille re-edition
PDFs for Exposés VI A and VI B. Their exact filenames, sizes, page counts,
and SHA-256 identities are recorded in `README.md`; they are not
redistributed in this checkpoint.

Jacob Reinhold's English Markdown translation was used as a credited
comparison and drafting lineage:

- author: Jacob Reinhold;
- repository: <https://github.com/jcreinhold/sga>;
- revision: `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- Exposé VI A SHA-256:
  `CBA8277A3187AFB989FB5B7AA741AE14ED96B08C911A21190CBFFE60E2748DC3`;
- Exposé VI B SHA-256:
  `A3FEADE781D8155E2774740D0D01884B2D4DE613001CDC1285D51BD4CF3341C7`;
- declared license for that translation lineage: CC BY 4.0.

Reinhold's material is comparison and drafting input, not the controlling
French source and not independent corroboration. Any reuse derived from
that lineage must retain its attribution and comply with the upstream
license.

## Rights caveats

This file is an attribution and rights notice, not a blanket license grant.
The underlying French-source and editorial rights are not granted by this
English checkpoint. The native reconstruction does not purport to broaden
rights in the underlying edition.

Archive maintenance must preserve the Polo-Gille source identification,
Reinhold attribution, CC BY 4.0 comparison-lineage notice, and these rights
caveats in any GitHub or Zenodo description. It must not describe this
bounded Exposé VI checkpoint as the complete SGA 3 volume or as a critical
edition.
