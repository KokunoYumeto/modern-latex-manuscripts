# SGA 3 Exposé VI public projection status

Projection: `native_reference_v2_r4_freeze4_20260724`

Status: **READY FOR EXACT EXTERNAL REPLAY; ARCHIVE HANDOFF HELD**.

This no-overwrite successor covers Exposé VI in its assigned order: VIA local
pages 1–38, then VIB local pages 1–111. VIB local page 112 remains only the
terminal blank envelope. Exposé VII and later are outside this scope.

## Controlling reader

- Master: `tex_reference_v2/SGA3_Expose_VI_English_ReferenceV2.tex` —
  8,926 B — SHA-256
  `F5388E9978FD1D33CEA905EE892ED859089F8D0329005031033B414593E299B4`.
- PDF: `build_reference_v2_r1/SGA3_Expose_VI_English_ReferenceV2.pdf` —
  965,557 B — 185 A4 pages — SHA-256
  `4891908E423F933B36E61295BDC0CC77948B60B64B727F6B3592AB73332CC5CF`.
- Active source closure: one master plus 90 component TeX files.
- Diagram closure: 58/58 source-bound diagrams are native LaTeX
  reconstructions; the active source has 60 `tikzcd` environments and zero
  `includegraphics` calls.

The corrected Polo–Gille Exposé-VI PDFs remain the French text, formula,
numbering, note, and diagram authority. Jacob Reinhold's CC BY 4.0 English
Markdown is credited as a comparison and drafting lineage, not as source
authority.

## Exact convention-v2 result

`final_reference_v2_gate/REFERENCE_V2_GATE_VALIDATION.json` is PASS with
errors `[]`:

- 987 labels, 987 target IDs, and 987 unique target PDF destinations;
- 7,629 candidates partitioned into 672 edges and 6,957 positively classified
  residuals;
- zero collapsed destinations, unwrapped internal locators, semantic target
  mismatches, action deficits, structural target gaps, duplicate labels, or
  machine-reference closure errors;
- the expected standalone boundary remains explicit: eight occurrences of
  seven Exposé-IV/V labels are unresolved only because those exposés are not
  part of this standalone Exposé-VI reader.

The source generator records 382 exact inverse-replayable mutations:
254 reference wrappers, 102 distinct-destination anchors, 14 new subitem
targets, and 12 active explanatory-comment refreshes. A clean independent
source-generation replay matched 125/125 files byte-for-byte.

## Build, render, metadata, and privacy

- Eight sequential XeLaTeX passes completed with exit 0. The final log has no
  fatal error, duplicate destination, multiply defined label, missing
  character, or overfull box. Its remaining undefined references are exactly
  the seven disclosed Exposé-IV/V boundary labels.
- The final PDF retains 185 pages and has non-private Title, Author, Subject,
  and Keywords metadata.
- All 185 final pages were rendered. The eight contact sheets were visually
  inspected with no clipping, overlap, blank-body page, broken formula, or
  broken diagram found.
- Canonical extracted body text is unchanged from the fully native baseline.
  Hyperlink object boundaries alter at most 0.000915 of body-page pixels,
  below the recorded one-per-mille material-change threshold.
- The active TeX/PDF/metadata privacy scan reports zero private-path hits.

## Release boundary

This is an Exposé-VI successor, not a claim that SGA3 as a whole is complete.
It does not assert a blanket license over the underlying French edition. The
CC BY 4.0 statement belongs to Reinhold's declared comparison lineage only.
Raw compiler logs contain local tool paths and are internal evidence; they
must not be copied unchanged into a public projection.

The historical final-gate FAIL receipt and inactive source parents are not
part of this projection. The active PASS receipt and final machine controls
are included for exact external replay.

## Projection state

This privacy-clean no-overwrite successor contains the exact frozen
producer reader, active components, active machine controls, compact render
evidence, attribution, caveats, and a public hash manifest. It contains no
authority PDF, OCR substrate, raw page renders, raw compiler log, inactive
component parent, scratch/replay tree, or historical FAIL receipt.

Fresh disjoint producer audits completed:

1. complete tree/hash/privacy/machine-control replay: PASS;
2. PDF/reference/action/render/formula and mathematical-layout replay: PASS.

The exact held-projection PASS listed in the predecessor controls applies
to superseded r1, not to freeze2, freeze3, or freeze4. Freeze2 is preserved
as FAIL after a fresh exact replay found contradictory release-state prose,
an overbroad exact-projection audit claim, and a malformed Exposé-VI-B
authority hash. Freeze3 corrected the release-state controls but retained
that malformed hash and is also preserved as FAIL. Freeze4 records the
verified full 64-character authority hash; the reader TeX and PDF remain
byte-identical. A fresh exact external replay of this frozen tree is the
remaining gate. Exact prerequisite and predecessor identities are in
`INDEPENDENT_RELEASE_AUDITS.md`.

No archive handoff, GitHub publication, Zenodo deposition, DOI mutation,
archive acknowledgment, or public readback is claimed or authorized by
this candidate. A fresh exact external PASS may supersede this hold and
authorize the lead and English/Germanic manager to send the single exact
handoff.
