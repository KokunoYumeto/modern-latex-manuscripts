# SGA 1-6

## English readers

- `00a_SGA1_English_Reader.pdf`
- `00b_SGA2_English_Reader.pdf`
- `00c_SGA3_English_Reader.pdf`
- `00d_SGA4_English_Reader.pdf`
- `00e_SGA5_English_Reader.pdf`
- `00f_SGA6_English_Reader.pdf`

The SGA3 reader has 1,459 A4 pages and includes the Editorial Notice,
Introduction, Exposes I-XXVI, the Tome-I index, the Tome-III mathematical
guide, and the terminal index. Its direct reading flow contains mathematical
and legitimate historical editorial content; project production and
source-adjudication apparatus is kept in the grouped source/history archive.

## French texts

Direct French reader and TeX files are present for SGA5 and SGA6.

## Editable sources and archives

The `02*` files are the direct English master TeX files. The `03*` files are
the available direct French master TeX files. Supporting source, provenance,
quality-control, and historical material is grouped in the `10*`, `11*`, and
`12*` ZIP archives.

Rights in the underlying works remain with their respective holders.
Historical versions remain available through Zenodo. The corresponding source
package is mirrored in the project's GitHub repository.
