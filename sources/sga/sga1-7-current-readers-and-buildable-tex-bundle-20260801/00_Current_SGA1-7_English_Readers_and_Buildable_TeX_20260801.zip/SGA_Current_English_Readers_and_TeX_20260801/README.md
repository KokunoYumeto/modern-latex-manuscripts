# Current SGA 1-7 English readers and buildable TeX

This one-click archive contains one cumulative English reader PDF and its
complete buildable TeX closure for SGA 1 through SGA 6, plus the complete
working English reader and source closure for SGA 7 I. It omits provenance
archives, QA images, raw logs, historical releases, source scans, and internal
project notes.

SGA 7 I covers all written exposes I, II, VI, VII, VIII, and IX through the
end of the available Tome-I source. It is readable and translation-complete,
but has not received an exhaustive clickable-reference audit.

Each subtree carries a cumulative PDF under `reader/` and a buildable master
plus recursive inputs under `source/`. `SHA256SUMS.csv` covers every other
archive member exactly.