# Provenance and rights

The reader is an English TeX edition of SGA 3, edited by M. Demazure and
A. Grothendieck. Source-edition PDFs maintained by Polo and Gille controlled
page, formula, and diagram comparison during production; they are not
redistributed in this archive.

Some English wording was compared with Jacob C. Reinhold's public
`jcreinhold/sga` repository at commit
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`. That comparison lineage is not
the textual authority. Reinhold states CC BY 4.0 for his translation
contribution; that statement does not grant rights over the underlying
French work or unrelated project contributions.

R28 combines the clean reader presentation of R27 with the later
reference-linked source advances. It preserves genuine source-era editorial
notes while excluding project narration from the reader.

No new license over the underlying French work is asserted here. This
archive does not claim a critical edition, independent peer review, or
tagged-PDF accessibility.
