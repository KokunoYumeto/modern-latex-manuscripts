# Reference completion R28

The converged clean reader contained 10,607 named destinations and 12,344
syntactically valid named GoTo actions. A 3,744-row stable-target plan was
mapped to physical PDF pages and coordinates through the final SyncTeX file.

The replay found two target classes:

- 1,219 stable target names already existed but incorrectly resolved to
  physical page 1; and
- 2,525 stable target names were absent.

The R28 names-tree overlay replaced the 1,219 malformed entries and added the
2,525 missing entries. It preserved 9,388 unrelated destination signatures
exactly.

Final results:

- 13,132 named destinations;
- 3,744/3,744 mapped targets present at the expected page and coordinates;
- 12,344 internal named GoTo actions;
- zero broken named actions;
- zero URI or other external actions; and
- exact page-content streams, page boxes, and annotations.

The controlling machine receipts are in `controls`.
