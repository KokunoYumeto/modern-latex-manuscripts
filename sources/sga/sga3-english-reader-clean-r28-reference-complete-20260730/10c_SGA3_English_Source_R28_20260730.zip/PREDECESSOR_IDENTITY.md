# Predecessor identity

R28 supersedes R27 only as the preferred current reading and editable-source
surface after exact remote readback. R27 remains immutable archive history.

R27 identities:

- reader PDF: 6,363,273 bytes, SHA-256
  `7352749F0F2CAEC0C4759A417CF7D4C5E332F5C89E81E3D43F812F788519DE59`;
- master TeX: 8,142 bytes, SHA-256
  `51F43E91B3DFECC077B5808262B5639B9153D5FE3CA93F41142E0C2A1CFFDFFF`;
- source ZIP: 1,974,833 bytes, SHA-256
  `2F1CFD9D413D56299A91E6B7FA97494E83236858B22AD877F88EB720FE8CA6EF`.

The previously observed public SGA version was
`10.5281/zenodo.21698501`, under concept DOI
`10.5281/zenodo.20410947`.
