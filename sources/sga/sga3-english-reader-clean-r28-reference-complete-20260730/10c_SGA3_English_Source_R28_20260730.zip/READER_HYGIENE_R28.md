# Reader hygiene R28

The public reader should read like a book, not a project dashboard.

R28 therefore:

- uses a neutral title page and bibliographic PDF metadata;
- suppresses 143 project, workflow, source-status, and production-note
  wrappers across 96 component files;
- retains genuine historical editorial apparatus that belongs to the
  mathematical edition;
- keeps provenance and production evidence in this source archive; and
- scans the extracted final PDF text for blocked project and
  machine-assistant narration.

The final rendered-text scan found zero blocked phrase hits. The names-tree
overlay changes no page-content stream, page box, or annotation.
