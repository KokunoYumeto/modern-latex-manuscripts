# SGA 3 English source R28

This archive contains the editable recursive source for the clean 1,470-page
SGA 3 English reader R28.

Build from `02c_SGA3_English_Master.tex`. The `inputs` directory contains the
913 recursive TeX dependencies. The `controls` directory records convergence,
the 3,744-row target plan, SyncTeX page-coordinate mapping, final PDF
destination replay, and validation receipts.

Reader-facing project, source-status, and production notes are suppressed by
the master-level `SGAArchiveOnly` wrapper. They remain available in source
history where appropriate but are not typeset into the book.

`SOURCE_SHA256SUMS.csv` gives the byte count and SHA-256 of every other member
of this ZIP.
