# Publication readiness

Status: ready for exact archive-owner GitHub and same-concept Zenodo
replacement after checksum replay.

The direct public shelf should expose the reader PDF and master TeX. This ZIP
groups the recursive source and controls. Authority PDFs, source crops,
private paths, raw logs, SyncTeX working data, and temporary build files are
excluded.

The predecessor remains immutable history. No duplicate Zenodo concept or
parallel draft is authorized.
