# SGA 1 English complete-volume source package

This archive contains the exact recursive TeX build closure for the
262-page complete-volume working reader dated 2026-07-22.

- TeX files: 139
- Root: `SGA1_English_source_sync_workpass.tex`
- Text authority: corrected French arXiv `math/0206203v2` TeX.
- External comparisons, build logs, scans, rejected states, and
  operational/private evidence are excluded.
- Exhaustive convention-v2 link certification remains in progress.
- Underlying French rights are not conveyed by this package.

`SHA256SUMS.csv` enumerates every TeX member and this note. The
checksum manifest excludes itself.
