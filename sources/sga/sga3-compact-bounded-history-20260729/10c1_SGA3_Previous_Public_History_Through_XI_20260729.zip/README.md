# SGA3 previous public history through Expose XI

This archive preserves the two exact predecessor-history archives removed from the direct Zenodo file list when the clean cumulative reader became the public reading surface. These bytes are historical provenance, not a competing current reader.
