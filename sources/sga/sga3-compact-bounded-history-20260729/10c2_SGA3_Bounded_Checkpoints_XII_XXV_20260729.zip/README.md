# SGA3 bounded checkpoint history, Exposes XII-XXV

This archive preserves eight exact bounded checkpoint trios: reader PDF, master TeX, and source/QA ZIP for Exposes XII, XIII, XIV, XIX, XX, XXI, XXIII, and XXV. The current cumulative reader contains the mathematical reading surface. These checkpoint bytes remain available for provenance and audit history rather than as loose front-list readers.
