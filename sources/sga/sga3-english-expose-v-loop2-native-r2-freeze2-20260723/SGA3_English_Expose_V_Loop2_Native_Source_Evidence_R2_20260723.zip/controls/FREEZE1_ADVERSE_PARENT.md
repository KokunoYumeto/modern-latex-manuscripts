# Loop-2 freeze1 adverse parent

The immutable Loop-2 `r1_freeze1_20260723` projection is retained outside
this payload as FAIL/history only. It must not be published or described
as a 66/66 native-diagram reader.

Its comprehensive failures were:

1. twelve diagram calls still used raster PNGs, so the PDF contained image
   objects despite the native-completion claim;
2. component, path-closure, and coordinate-basis controls were stale or
   misdeclared;
3. the public build evidence leaked host-specific paths;
4. CSV formula-safety checks did not trim leading whitespace.

Exact independent adverse receipts:

- PDF/reference/render report:  SHA-256
  `925E675C6245E2919381A8F70AD7C2B13F5DE1C8E9E6BB4A975E09799DDB0E8E`;
- PDF/reference/render validation: SHA-256
  `48348C91AF036377017C89D7C65B9B0EF417CE4CE7BFC307ED700D66847EDE95`;
- tree/privacy/machine report: SHA-256
  `F5750C54F9C4F1609BB8BDBBEE73834F1EFBBA98A6193F76B663250F10EF6570`;
- tree/privacy/machine validation: SHA-256
  `ACA7AE6B11FE63888BFCD4AD748BCD1315C93CE18E49F8D4D14B9C3E457892DE`.

This no-overwrite successor replaces all twelve raster invocations with
native TeX, rebuilds to a 51-page PDF with zero image-paint operators,
regenerates active controls from the final tree, and preserves the
predecessor evidence only under explicit historical/supporting scope.
