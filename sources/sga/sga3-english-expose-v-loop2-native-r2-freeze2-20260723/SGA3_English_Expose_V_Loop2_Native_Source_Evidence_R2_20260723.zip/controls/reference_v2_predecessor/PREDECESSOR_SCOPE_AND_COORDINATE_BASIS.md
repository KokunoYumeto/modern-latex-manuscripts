# Predecessor reference scope and coordinate bases

This directory is a supporting predecessor layer, not a second co-current
Loop-2 build claim.

## What is retained here

- the exhaustive Loop-1 Freeze-3 candidate and residual detector output;
- the corresponding detector/signature and source-preservation controls;
- the reference revision, mutation, and visible-correction event streams;
- the 24-file reference-free baseline used by occurrence coordinates;
- the 24 delivered Loop-1 Freeze-3 reference-wrapped components and master.

`REFERENCE_V2_EXHAUSTIVE_VALIDATION_R3_PUBLIC.json` validates that
predecessor detector/reconstruction surface only. It is superseded for
active PDF action, page, diagram, and Loop-2 target/edge claims by the R4
files under `../loop2`.

## Coordinate bases

- predecessor candidates, residuals, detector hits, and edge source
  coordinates refer to the packaged files under
  `reference_free_baseline`;
- active Loop-2 target declaration coordinates refer to the packaged
  delivered Loop-1 Freeze-3 files under `delivered_reference_v2_tex`;
- active PDF page and destination fields refer to the delivered 51-page
  Loop-2 PDF.

The packaged mutation and correction event streams connect the
reference-free baseline to the delivered predecessor TeX. This makes the
coordinate transformations replayable without relying on a private
workspace path.

Projected CSVs are formula-safe: a cell whose first non-whitespace
character was `=`, `+`, `-`, or `@` receives one leading apostrophe.
Removing exactly that one prefix recovers the predecessor evidence cell.
