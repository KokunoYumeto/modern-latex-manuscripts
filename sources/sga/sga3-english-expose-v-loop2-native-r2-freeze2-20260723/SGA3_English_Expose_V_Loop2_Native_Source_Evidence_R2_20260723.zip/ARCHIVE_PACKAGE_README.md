# SGA 3 Expose V Loop 2 native source and evidence

This archive contains the self-contained editable Expose V Loop 2 reader,
66 native TikZ/TikZ-cd diagram sources, convention-v2 controls, public build
evidence, and project-generated render QA.

The 66 source-PDF-derived PNG witnesses are deliberately absent because
their redistribution rights are not affirmatively established. Their parent
PDF identity, source locators, dimensions, crop hashes, linked TeX units,
native replacements, and review dispositions are preserved in
RIGHTS_BLOCKED_SOURCE_WITNESSES.csv and .jsonl.

The reader is a bounded working English Expose V checkpoint, not complete
SGA 3, a critical edition, mathematical certification, independent human
peer review, blanket rights clearance, or accessibility certification.

Jacob Reinhold's jcreinhold/sga English Markdown at revision
e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e was credited comparison and
drafting material under his stated CC BY 4.0 license. It is not source
authority or independent corroboration.