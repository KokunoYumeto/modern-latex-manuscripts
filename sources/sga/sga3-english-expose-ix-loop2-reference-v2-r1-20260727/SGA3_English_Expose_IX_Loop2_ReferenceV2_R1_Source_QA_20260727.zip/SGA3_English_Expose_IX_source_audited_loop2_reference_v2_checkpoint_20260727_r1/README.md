# SGA 3 Exposé IX — English Loop2/reference-v2 checkpoint

This bounded checkpoint contains the complete English Exposé IX body,
editable LaTeX, a 36-page A4 reader, native TeX diagrams, an exhaustive
reference-v2 graph, source-correction and translation-QA ledgers, all-page
renders, and independent validation.

## Exact scope

- Authority component: `Exp9-8nov09.pdf`, standalone pages 1–32,
  complete-reader pages 647–678.
- English body: Sections 1–8 and the terminal bibliography and notes.
- Hard stop: before complete-reader page 679 and the first nonblank page of
  Exposé X.
- Exposé X and later are outside this checkpoint.
- This is a bounded Exposé IX checkpoint, not a complete SGA 3 reader.
- It is not the whole of SGA 3.

## Principal files

- `source/tex/SGA3_Expose_IX_English.tex` — cumulative Exposé IX master.
- `reader/SGA3_Expose_IX_English.pdf` — audited 36-page reader.
- `reference/REFERENCE_TARGETS.csv`
- `reference/REFERENCE_CANDIDATES.csv`
- `reference/REFERENCE_EDGES.csv`
- `reference/REFERENCE_RESIDUALS.csv`
- `qa/SOURCE_CORRECTIONS_AND_ADVERSE_CHOICES.csv`
- `qa/FULL_EXPOSE_TRANSLATION_QA.csv`
- `qa/INDEPENDENT_AUDIT.json`
- `SHA256SUMS.csv`

## Local build

From the extracted package, change into `source`, create a separate output
directory, and run XeLaTeX three times:

```text
cd source
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_IX_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_IX_English.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=local-build tex/SGA3_Expose_IX_English.tex
```

Generated build files are not part of the checkpoint.

See `PROVENANCE_AND_RIGHTS.md` before any redistribution.
