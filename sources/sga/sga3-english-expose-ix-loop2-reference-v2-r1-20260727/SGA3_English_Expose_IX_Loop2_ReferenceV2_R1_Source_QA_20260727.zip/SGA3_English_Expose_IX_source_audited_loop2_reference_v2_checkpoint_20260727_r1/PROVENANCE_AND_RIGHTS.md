# SGA 3 Exposé IX English checkpoint — provenance and rights

## Scope

This package contains the English reconstruction of **Exposé IX only**,
covering complete-reader pages 647–678 and stopping before page 679 /
Exposé X. The hard stop is before complete-reader page 679 / Exposé X. It is
**not the whole of SGA 3**.

## Controlling source

The text, formulas, numbering, notes, page order, and diagrams were checked
against the Polo–Gille PDF `Exp9-8nov09.pdf`:

- 32 A4 pages;
- 448,941 bytes;
- SHA-256
  `7C1E3D5B9D01AD01D0DD7B8B62045D012052E7890FB37ADC3E7934EBB5FD6FC3`;
- complete-reader pages 647–678.

The Polo–Gille PDF is the authority and page locator for this reconstruction.
It is **not recovered editor TeX**. No authority PDF or scan is included.
OCR is not authority and no OCR body is included.

## English comparison control

Jacob C. Reinhold's Exposé IX Markdown from commit
`e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e` was used as credited
comparison material only and is not authority or independent corroboration:

- 108,258 bytes;
- SHA-256
  `8D2FCC9B85CDE23E4740F88BC984A41AAFC12D4E6B15EAF59199ED63EFCA6D9F`.

That contributor declares CC BY 4.0 for the translation contribution while
excluding underlying French rights. This attribution does not make the
comparison source evidence.

## Rights statement

No license grant is asserted by this package for the underlying French text,
this English reconstruction, editorial additions, or third-party TeX
support. Rights remain with their respective holders. The comparison's
declared CC BY 4.0 terms are **no broader license** for the French source,
this independently revised reconstruction, or the package as a whole.

Redistribution rights are not asserted. Preservation metadata, attribution,
checksums, and technical validation do not themselves confer permission to
reproduce or redistribute copyrighted material. This is a provenance and
scope statement, not legal advice.

The package contains no authority PDF, scan, OCR body, comparison body,
private path, raw build cache, or internal task conversation.
