# Attribution and provenance

Source authority: the Polo--Gille corrected Exposé VI A and VI B PDFs.

Comparison/drafting lineage: Jacob Reinhold's English Markdown translation,
credited under its declared CC BY 4.0 terms. It was not treated as source
authority.

Reconstruction note: no editable Polo--Gille source was publicly available
when this work was undertaken. The mathematical formulas and diagrams were
therefore reconstructed in LaTeX against the PDF authority.
