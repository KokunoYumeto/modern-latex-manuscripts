# SGA 3 Exposé VI — English native-diagram successor

This no-overwrite checkpoint contains the complete English Exposé VI A and
VI B source, a 185-page reader, and 60 native TeX diagrams. The Polo--Gille
PDFs are the source authority. Jacob Reinhold's CC BY 4.0 English Markdown
was used and credited as comparison/drafting lineage, not as source
authority.

No editable Polo--Gille source was publicly available when this
reconstruction was made, so the formulas and diagrams were reconstructed
from the authoritative PDF. Source-derived images are not delivered.

Build from this package root with:

`xelatex -output-directory=build tex_reference_v2/SGA3_Expose_VI_English_ReferenceV2.tex`

The standalone source intentionally retains seven cross-exposé labels owned
by Exposés IV and V; they resolve in the cumulative reader.
