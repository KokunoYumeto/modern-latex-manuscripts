# SGA 3 Exposé VI direct-authority native-diagram review

Status: **PASS**

The Session-A lead compared all 60 atomic Exposé-VI diagrams directly with
the controlling Polo--Gille authority at 5,000 dpi. Raster images were used
only as private witnesses; the delivered reader contains native TeX diagrams
and no raster diagram payload.

- reviewed: 60/60;
- initially source-faithful: 46;
- repaired and rechecked: 14;
- unresolved: 0;
- native `tikzcd` environments: 60;
- delivered raster references: 0.

The 14 repairs are recorded row by row in
`LEAD_DIRECT_AUTHORITY_NATIVE_5000DPI_REVIEW_60.csv`. They correct terminal
punctuation and, in diagrams 14, 58, and 60, exact arrow-label placement.
The apparent tilde on diagram 53 was checked against the surrounding source
and retained correctly as the source's calligraphic F rather than silently
introducing a tilde.

The final 185-page reader was rebuilt after the repairs. The 11 affected
physical pages passed lead page-envelope review for clipping, overlap,
spacing, and seams. That 600-dpi page review is not the fidelity authority;
the fidelity judgments come from the separate 5,000-dpi comparisons.

The standalone build has eight expected hyper-reference warnings to seven
labels owned by Exposés IV and V. The PDF itself has 948 link
actions, all resolved, and no external action. Those cross-exposé labels are
expected to resolve in the cumulative reader.
