# Publication and rights caveats

- The controlling Polo--Gille PDFs are excluded.
- No copyright or license grant for the underlying French edition is
  inferred.
- Jacob Reinhold's comparison lineage is credited under its declared
  CC BY 4.0 terms; that declaration does not license the underlying edition.
- This checkpoint is ready for cumulative integration and manager replay.
  It does not itself claim archive dispatch, publication, DOI mutation, or
  public readback.
