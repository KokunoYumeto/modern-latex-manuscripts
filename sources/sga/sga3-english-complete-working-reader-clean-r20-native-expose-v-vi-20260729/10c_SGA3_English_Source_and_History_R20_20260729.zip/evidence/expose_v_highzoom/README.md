# SGA 3 Exposé V — high-zoom native-diagram successor

This bounded checkpoint contains the English Exposé-V reader with all 66
temporary diagram rasters replaced by native TikZ/TikZ-cd sources. It is a
corrected successor to the earlier low-zoom diagram checkpoint; it is not
the complete SGA 3 volume and is not represented as a critical edition.

## Source and translation lineage

The controlling source is the corrected Polo–Gille `Exp5-13oct24.pdf`
(439,522 bytes; SHA-256
`9198200633F929FE1822520371A9200DA4F8CF2513EFAB3D6A0C7E9330DB84CF`).
The authority PDF is identified but not redistributed here. No editable
Polo–Gille LaTeX source was publicly available when this reconstruction was
made, so formulas and diagrams were reconstructed from the PDF.

Jacob Reinhold's English Markdown was used as a credited comparison and
drafting lineage:

- author: Jacob Reinhold;
- repository: <https://github.com/jcreinhold/sga>;
- revision: `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- matched Exposé-V file SHA-256:
  `4FE1ED8361FDF66DCEED6D6E534E4A37B4E2DB7AF9BF9FFA29A023579FC9FE30`;
- declared translation license: CC BY 4.0.

Reinhold's Markdown is comparison/drafting lineage, not the source authority
or independent source corroboration.

## Reader identities

- master: `tex/SGA3_Expose_V_English_Loop2_Native_ReferenceV2_00_23.tex`, 7,202 bytes,
  SHA-256 `92AB24AB2E104618AB4E97AC4A2F23554BECB741258F7E9739EC463E6B99C37E`;
- PDF: `build/SGA3_Expose_V_English_Loop2_Native_ReferenceV2_00_23.pdf`, 51 pages, 361,456 bytes,
  SHA-256 `DCB6195D3FE8CA379CCFDB8F9B8B054165DCCF45EB8451C5C678AF4DE7775730`;
- editable source manifest: 91 rows, SHA-256 `EA47F537AD9D330BBF9214EF96CCD1FFAC456F6F0BA3B0903DE7AC9BD2FB1F14`;
- canonical editable-source tree digest: `975F29AE30BB55CB93335D056BDB304418F6AF5ED8270AE8EECBBF20E79A4DF0`.

## Diagram and layout gates

- 66/66 native diagram sources and 66/66 native invocations:
  54 figure wrappers plus 12 direct native equation embeddings;
- zero `includegraphics` calls and zero PDF image objects;
- all 66 diagrams reviewed against direct authority crops at 5,000 dpi;
- figures 007–011 corrected so the lower arrow label occupies the authority
  side, then rechecked at 5,000 dpi;
- 32/32 diagram-bearing reader pages checked for integration layout at
  600 dpi after fidelity had already been decided at 5,000 dpi;
- 51/51 PDF pages contain extractable text;
- 411 internal named actions, zero broken internal actions.

The 600-dpi page ledger is layout-only evidence. It does not substitute for
the separate 5,000-dpi diagram-fidelity ledger. Earlier 600/1,200-dpi
evidence remains valid history/context; only 300-dpi-only fidelity approval
is superseded.

## Build

Run XeLaTeX from this projection root so `tex/components` and
`native_diagrams/exp5` resolve as packaged. The privacy-clean public build
summary is `build/SGA3_Expose_V_English_Loop2_Native_ReferenceV2_00_23_BUILD_PUBLIC.log`.

Authority crops, OCR, source-derived raster witnesses, private paths, raw
build logs, and temporary renders are intentionally excluded.
