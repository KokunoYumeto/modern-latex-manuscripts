# Publication caveats

- This is a bounded Exposé-V successor, not the complete SGA 3 volume.
- The corrected Polo–Gille PDF controls the source and is not redistributed.
- No public editor LaTeX source was available when the reconstruction was
  made; the editable reader, formulas, and diagrams were reconstructed.
- Reinhold's CC BY 4.0 Markdown is credited comparison/drafting lineage.
- Delivered diagrams are native TeX only. Source crops, OCR, PNG witnesses,
  private paths, temporary renders, and raw build logs are excluded.
- Cross-exposé destinations require later cumulative-reader integration.
- The PDF is not claimed to be tagged or fully accessibility-remediated.
- Publication, DOI mutation, and archive readback are not claimed here.
