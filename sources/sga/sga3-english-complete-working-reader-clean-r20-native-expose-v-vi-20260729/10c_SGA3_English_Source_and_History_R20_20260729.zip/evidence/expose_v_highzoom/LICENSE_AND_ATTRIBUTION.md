# License and attribution — SGA 3 Exposé V

The controlling French source is the corrected Polo–Gille re-edition of
SGA 3, Exposé V. Its PDF is identified in `README.md` but is not
redistributed in this checkpoint.

Jacob Reinhold's English Markdown translation was used as a credited
comparison and drafting lineage:

- author: Jacob Reinhold;
- repository: <https://github.com/jcreinhold/sga>;
- revision: `e7a259f3f8608ad3edf9bf6eead3fd504dd2d23e`;
- matched Exposé-V file SHA-256:
  `4FE1ED8361FDF66DCEED6D6E534E4A37B4E2DB7AF9BF9FFA29A023579FC9FE30`;
- declared license for that translation lineage: CC BY 4.0.

Reinhold's material is not the controlling source and is not independent
source corroboration.

The underlying French-source rights are not granted by this checkpoint.
The native diagram reconstructions do not purport to broaden rights in the
underlying edition. Any later publication must preserve this attribution
and caveat and must not describe this bounded Exposé-V checkpoint as the
complete SGA 3 volume or as a critical edition.
