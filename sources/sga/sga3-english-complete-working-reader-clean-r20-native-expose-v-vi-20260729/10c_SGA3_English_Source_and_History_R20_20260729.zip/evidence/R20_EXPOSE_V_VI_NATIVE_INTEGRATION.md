# SGA 3 Exposé-V/VI native integration

This source archive retains the continuous English reader through all
twenty-six exposés and both index/guide surfaces. It overlays the exact
high-zoom native successors for Exposé V and Exposé VI A/B on the preceding
cumulative source closure.

Exposé V contains 66 native diagrams. Its lead checked all 66 directly against
the controlling authority at 5,000 dpi, repaired the five lower-arrow-label
placement defects in figures 007--011, and checked all 32 affected reader pages
at 600 dpi for integration layout.

Exposé VI contains 60 native diagrams. Its lead checked all 60 directly at
5,000 dpi, applied 14 source-backed repairs, and checked all 11 affected reader
pages at 600 dpi for integration layout. Both delivered successors contain
zero raster diagram files and the cumulative build packages no authority
pixels.

Reader metrics: 1459 A4 pages, 9351
named destinations, 4467 valid internal GoTo
actions, and 41 remaining raster objects outside the
newly overlaid Exposé-V/VI scope.

This is a scholarly working translation and TeX edition, not a critical
edition, blanket rights clearance, mathematical certification, peer review,
final whole-volume diagram certification, or tagged-PDF accessibility work.
