# R21 reader-facing apparatus removal

The reading edition removes eight project-authored production and
source-adjudication annotations that remained visible in R20: one diagram
reconstruction/source-locator caption, one inline source-adjudication aside,
and six project-added source-reading footnotes.

The mathematical reading text, source ordering, links, and legitimate
historical source-edition apparatus remain. Detailed provenance and the R20
predecessor are preserved in this archive rather than printed in the reader.

R21 reader metrics: 1459 A4 pages,
9345 named destinations, and
4461 valid internal links.
