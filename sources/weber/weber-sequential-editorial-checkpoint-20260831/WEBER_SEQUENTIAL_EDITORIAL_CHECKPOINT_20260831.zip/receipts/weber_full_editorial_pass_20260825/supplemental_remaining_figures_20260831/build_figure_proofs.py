from pathlib import Path
import hashlib
import json
import subprocess
import fitz

BASE=Path(__file__).resolve().parent
WORK=BASE.parents[2]
def ident(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}
builds=[]
for tag,idx in [('b1',275),('b3',78)]:
 for lang,lane in [('de','swarm_tex'),('en','swarm_en')]:
  stem=f'figure_proof_{tag}_i{idx:04d}_{lang}'
  master=BASE/f'{stem}.tex'
  leaf=WORK/lane/tag/f'{tag}_i{idx:04d}.tex'
  lines=[rf'\input{{{(WORK / "swarm_preamble.tex").as_posix()}}}',rf'\graphicspath{{{{{(WORK / "swarm_assets" / tag).as_posix()}/}}}}',r'\begin{document}',rf'\input{{{leaf.as_posix()}}}',r'\end{document}']
  master.write_text('\n'.join(lines)+'\n',encoding='utf-8')
  run=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',master.name],cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert run.returncode==0,run.stdout.decode(errors='replace')[-2000:]
  doc=fitz.open(BASE/f'{stem}.pdf')
  assert len(doc)==1, (stem,len(doc))
  render=subprocess.run(['pdftoppm','-r','300','-singlefile','-png',f'{stem}.pdf',f'{stem}_render'],cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  assert render.returncode==0,render.stdout.decode(errors='replace')
  builds.append({'tag':tag,'idx':idx,'language':lang,'canonical_input':ident(leaf),'master':ident(master),'pdf':ident(BASE/f'{stem}.pdf'),'log':ident(BASE/f'{stem}.log'),'render':ident(BASE/f'{stem}_render.png'),'build_exit_code':0,'render_exit_code':0,'pages':len(doc),'render_dpi':300})
(BASE/'FIGURE_BUILD_RESULTS.json').write_text(json.dumps({'builds':builds},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'build_result':ident(BASE/'FIGURE_BUILD_RESULTS.json'),'pages':len(builds)},indent=2))
