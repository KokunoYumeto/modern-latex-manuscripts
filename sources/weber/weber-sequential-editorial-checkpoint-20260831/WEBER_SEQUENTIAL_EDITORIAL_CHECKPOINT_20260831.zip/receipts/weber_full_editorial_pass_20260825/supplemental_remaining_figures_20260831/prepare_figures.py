from pathlib import Path
from datetime import datetime, timezone
import base64
import hashlib
import json
import subprocess
from PIL import Image

BASE=Path(__file__).resolve().parent
WORK=BASE.parents[2]
SPECS=[
 {'volume':'b1','idx':275,'printed':250,'figure':5,'source':r'registered-source/Weber_Algebra_Bd1_IA.pdf','crop_at_600dpi':[910,974,2420,2486],'relative_width':0.56,'asset':'b1_i0275_fig5_source_20260831.png'},
 {'volume':'b3','idx':78,'printed':57,'figure':1,'source':r'registered-source/Weber_Algebra_Bd3.pdf','crop_at_600dpi':[470,1678,2280,2920],'relative_width':0.66,'asset':'b3_i0078_fig1_source_20260831.png'},
]
def ident(path):
 p=Path(path); data=p.read_bytes(); return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest().upper()}
manifest_path=BASE/'FIGURE_PRE_MANIFEST.json'
assert not manifest_path.exists()
manifest={'schema':'weber-remaining-figure-pre-manifest/v1','created_utc':datetime.now(timezone.utc).isoformat(),'specs':SPECS,'canonical_before':[],'sources':[],'queries':[],'shared_preamble':ident(WORK/'swarm_preamble.tex')}
for s in SPECS:
 tag,idx=s['volume'],s['idx']
 manifest['sources'].append(ident(s['source']))
 manifest['queries'].append(ident(WORK/'translation_queries'/f'{tag}_i{idx:04d}.json'))
 for lane in ('swarm_tex','swarm_en'):
  p=WORK/lane/tag/f'{tag}_i{idx:04d}.tex'
  manifest['canonical_before'].append(dict(ident(p),bytes_base64=base64.b64encode(p.read_bytes()).decode('ascii')))
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assets=[]
for s in SPECS:
 tag,idx=s['volume'],s['idx']
 asset=WORK/'swarm_assets'/tag/s['asset']
 assert not asset.exists(), f'Existing asset: {asset}'
 assert asset.parent.is_dir()
 x0,y0,x1,y1=s['crop_at_600dpi']
 prefix=BASE/f'{tag}_i{idx:04d}_exact_source_crop_600dpi'
 command=['pdftoppm','-f',str(idx+1),'-l',str(idx+1),'-singlefile','-r','600','-x',str(x0),'-y',str(y0),'-W',str(x1-x0),'-H',str(y1-y0),'-png',s['source'],str(prefix)]
 run=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert run.returncode==0,run.stdout.decode(errors='replace')
 # Byte-for-byte copy of the uncensored, unretouched Poppler crop into the canonical asset tree.
 asset.write_bytes(prefix.with_suffix('.png').read_bytes())
 im=Image.open(asset); im.verify()
 assets.append(dict(ident(asset),crop_box_at_600dpi=[x0,y0,x1,y1],dimensions=[x1-x0,y1-y0],source_pdf_page_one_based=idx+1,render_command=command,processing='Exact rectangular Poppler source render; no resampling, recoloring, denoising, thresholding, drawing or label replacement.'))
(BASE/'FIGURE_ASSET_PROVENANCE.json').write_text(json.dumps({'schema':'weber-figure-assets/v1','assets':assets},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'pre_manifest':ident(manifest_path),'assets':assets},indent=2))
