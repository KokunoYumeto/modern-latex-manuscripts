from pathlib import Path
from datetime import datetime, timezone
import base64
import hashlib
import json
import re
import sys
import fitz
from PIL import Image

BASE=Path(__file__).resolve().parent
WORK=BASE.parents[2]
sys.path.insert(0,str(WORK))
import check_en

def ident(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest().upper()}

def unfigure(text,old):
 # Placeholder calls are single complete lines in these exact four files.
 pattern=r'^\\weberfigure\{[^\n]*\}\r?$' if old else r'^\\weberfigureimage\{[^\n]*\}\r?$'
 s=re.sub(pattern,'',text,flags=re.M)
 return '\n'.join(line.rstrip() for line in s.splitlines() if line.strip() and not line.lstrip().startswith('%'))

pre_path=BASE/'FIGURE_PRE_MANIFEST.json'
pre=json.loads(pre_path.read_text(encoding='utf-8'))
assets_path=BASE/'FIGURE_ASSET_PROVENANCE.json'
assets=json.loads(assets_path.read_text(encoding='utf-8'))['assets']
builds_path=BASE/'FIGURE_BUILD_RESULTS.json'
builds=json.loads(builds_path.read_text(encoding='utf-8'))['builds']
receipt_path=BASE/'FIGURE_COMPLETION_RECEIPT.json'
assert not receipt_path.exists()
assert ident(pre['shared_preamble']['path'])==pre['shared_preamble']
for source in pre['sources']:
 assert ident(source['path'])==source
for q in pre['queries']:
 assert ident(q['path'])==q

canonical=[]
for row in pre['canonical_before']:
 p=Path(row['path'])
 before=base64.b64decode(row['bytes_base64'])
 assert len(before)==row['bytes']
 assert hashlib.sha256(before).hexdigest().upper()==row['sha256']
 after=p.read_bytes()
 assert before!=after
 bt,at=before.decode('utf-8'),after.decode('utf-8')
 assert len(re.findall(r'^\\weberfigure\{',bt,re.M))==1
 assert not re.search(r'^\\weberfigure\{',at,re.M)
 assert len(re.findall(r'^\\weberfigureimage\{',at,re.M))==1
 assert unfigure(bt,True)==unfigure(at,False),f'Nonfigure content changed: {p}'
 assert 'Former placeholder description retained:' in at
 canonical.append({'pre':{k:v for k,v in row.items() if k!='bytes_base64'},'post':ident(p),'pre_bytes_recoverable_from':str(pre_path),'nonfigure_content_unchanged':True,'placeholder_calls_before':1,'placeholder_calls_after':0,'source_image_calls_after':1,'status':'SOURCE_FIGURE_RESTORED'})

for asset in assets:
 assert ident(asset['path'])=={k:asset[k] for k in ('path','bytes','sha256')}
 im=Image.open(asset['path'])
 assert list(im.size)==asset['dimensions']
 im.verify()
for b in builds:
 assert ident(b['canonical_input']['path'])==b['canonical_input']
 for k in ('master','pdf','log','render'):
  assert ident(b[k]['path'])==b[k]
 log=Path(b['log']['path']).read_text(encoding='utf-8',errors='replace')
 bad=re.findall(r'(?m)^.*(?:Overfull|Underfull|LaTeX Error|Undefined control sequence).*$',log)
 assert not bad,bad
 doc=fitz.open(b['pdf']['path'])
 assert len(doc)==1
 assert '[Figur,' not in doc[0].get_text()
 image_records=doc[0].get_images(full=True)
 assert image_records, 'No image embedded in proof'
 expected=assets[0] if b['tag']=='b1' else assets[1]
 assert any([im[2],im[3]]==expected['dimensions'] for im in image_records)
 b.update({'visual_status':'PASS_ALL_AFFECTED_PAGE_CONTENT_INSPECTED','visual_checks':['Full figure and original caption visible','All figure lines, shading and labels preserved','No crop truncation or adjoining source prose','No clipping, overlap or broken glyphs','Original figure position relative to prose preserved','Footnotes and text remain readable'],'bad_log_findings':[],'embedded_image_dimensions_verified':expected['dimensions']})

query_notes=[
 ('ALREADY_RESOLVED','The first Flächeninhalt des Periodenparallelogramms span and English area of the period parallelogram retain the source emphasis; adjoining source prose remains plain.'),
 ('ALREADY_RESOLVED','The full nach dem Modul ... kongruent span and its English equivalent are already letterspaced, including the period pair.'),
 ('ALREADY_RESOLVED','The second isolated kongruent / congruent is already emphasized separately, while the following prose is plain.'),
 ('ALREADY_RESOLVED','The opening doubly-periodic-function statement is already emphasized through denselben Wert / same value, without spreading into the next clause.'),
 ('ALREADY_RESOLVED','in einem Periodenparallelogramm / within a single period parallelogram already bears the intended emphasis; the period-parallelogram noun in the preceding ordinary sentence remains plain.'),
 ('ALREADY_RESOLVED','die eine / the one is already separately emphasized; surrounding words remain plain.'),
 ('ALREADY_RESOLVED','All three reported orphaned punctuation joins are already closed tightly; the figure replacement leaves them unchanged.'),
 ('TERMINOLOGY_ACCEPTED','Periodenparallelogramm is period parallelogram, matching the geometry and the repeated usage.'),
 ('TERMINOLOGY_ACCEPTED','Wertvorrat is range of values, preserving its distinction from a sequence or system of values.'),
 ('TERMINOLOGY_ACCEPTED','Unstetigkeitspunkte is points of discontinuity, faithful to the historical analytic statement.'),
]
leaf_checks=[]
for tag,idx in [('b1',275),('b3',78)]:
 problems=check_en.check(tag,idx)
 assert not problems,(tag,idx,problems)
 qp=WORK/'translation_queries'/f'{tag}_i{idx:04d}.json'
 queries=json.loads(qp.read_text(encoding='utf-8'))['queries']
 notes=query_notes if tag=='b3' else []
 assert len(notes)==len(queries)
 leaf_checks.append({'leaf':f'{tag}_i{idx:04d}','source_pdf_page_one_based':idx+1,'german_english_formula_parity':{'status':'PASS','problems':[]},'historical_query_file':ident(qp),'historical_query_dispositions':[{'number_one_based':n,'query':q,'status':d[0],'rationale':d[1],'terminal':True} for n,(q,d) in enumerate(zip(queries,notes),1)],'figure_finding':{'status':'FIXED','kind':'genuine_missing_source_figure','languages':['german','english'],'counted_as_one_shared_source_defect':True,'description':'Prose-only placeholder replaced by complete source-image crop including original Fig.5 caption and all model lines.' if tag=='b1' else 'Prose-only placeholder replaced by complete source-image crop including original Fig.1 caption, all nine lattice-vertex labels, and four interior-point labels.'},'unresolved':0})

receipt={
 'schema':'weber-supplemental-remaining-figures/v1',
 'status':'PASS_SOURCE_BACKED_FIGURES_COMPLETE',
 'completed_utc':datetime.now(timezone.utc).isoformat(),
 'scope':{'canonical_files':[r['post']['path'] for r in canonical],'new_asset_files':[a['path'] for a in assets],'supplemental_evidence_directory':str(BASE),'write_boundaries_observed':'Only the four assigned canonical leaves, two new figure assets and this new supplemental evidence directory. No existing receipts, cursor, master, shared preamble, validator or release artifact modified.'},
 'counts':{'distinct_missing_source_figures_fixed':2,'canonical_placeholder_instances_replaced':4,'german_pages':2,'english_pages':2,'source_figures_visually_reviewed':2,'rendered_output_pages_visually_reviewed':4,'historical_queries_terminally_disposed':10,'new_mathematical_prose_or_formula_changes':0,'unresolved':0},
 'pre_manifest':ident(pre_path),
 'sources':pre['sources'],
 'assets_provenance_manifest':ident(assets_path),
 'assets':assets,
 'render_resolution_note':'The crop operation renders the registered mixed-resolution PDF page at600dpi; this is not a claim that every embedded source image has native600dpi detail. No additional post-render resampling, recoloring, denoising, thresholding or redrawing was applied. Source paper tint and original print/scan artifacts remain.',
 'full_source_page_previews':[ident(BASE/'source_b1_i0275_scan276.png'),ident(BASE/'source_b3_i0078_scan079.png')],
 'canonical_changes':canonical,
 'per_leaf_checks':leaf_checks,
 'build_results_manifest':ident(builds_path),
 'build_and_visual_qa':builds,
 'shared_preamble_unchanged':pre['shared_preamble'],
 'validator':ident(WORK/'check_en.py'),
 'independent_source_crop_review':{'status':'PASS','method':'Separate read-only source-and-crop inspection; verified asset SHA256 identities.','b1':'Full Fig.5 caption; both pointed tips; complete hatched left face; all solid and dotted model lines; complete bottom curved edge; no neighboring prose.','b3':'Full Fig.1 caption; all nine lattice labels, including top-right u0+2omega1+2omega2, middle-right u0+2omega1+omega2, bottom-right u0+2omega1 and bottom-left u0; all four interior labels and all subscript extents; no clipped line.'},
 'provenance_preservation':'Exact pre-edit bytes of all four canonical leaves are base64 encoded in FIGURE_PRE_MANIFEST.json and hash-verified. Former descriptive placeholders remain as canonical comments. Registered source PDFs and historical query JSONs retain their pinned hashes.',
 'script_identities':[ident(BASE/'prepare_figures.py'),ident(BASE/'build_figure_proofs.py'),ident(__file__)],
 'publication_handoff':'Root must include both new PNGs in the existing buildable source packages; canonical references use portable asset basenames and the existing weberfigureimage macro.',
 'unresolved_findings':[],
}
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':ident(receipt_path),'counts':receipt['counts'],'canonical_post':[r['post'] for r in canonical]},indent=2))
