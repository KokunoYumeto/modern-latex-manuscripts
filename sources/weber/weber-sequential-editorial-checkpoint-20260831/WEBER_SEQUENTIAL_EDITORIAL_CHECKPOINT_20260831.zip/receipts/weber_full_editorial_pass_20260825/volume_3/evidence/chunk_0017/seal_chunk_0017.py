"""Seal Weber III chunk17 from pinned source/QA receipts; no build or canonical writes.
Default is a read-only check. --seal writes the terminal chunk/seal evidence.
--advance additionally advances the exact known cursor once, after readback verification.
"""
import argparse, copy, hashlib, json, re, sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
sys.dont_write_bytecode = True
import fitz
from PIL import Image

BASE = Path(__file__).resolve().parent
VOL = BASE.parents[1]
WORK = BASE.parents[4]
sys.path.insert(0, str(WORK))
import check_en
IDS = [f"i{n:04d}" for n in range(544, 576)]
SELECTED = ["i0543", *IDS, "i0576"]
FULL = [f"i{n:04d}" for n in range(22, 415)] + [f"i{n:04d}" for n in range(425, 772)]
CHUNK = VOL / "chunks" / "CHUNK_0017_i0544_i0575.json"
SEAL = BASE / "CHUNK_0017_INDEPENDENT_SEAL.json"
CURSOR = VOL / "CURSOR.json"
CURSOR_PRE_HASH = "FB83C93A470B1F372442BC8BCF4F8C6761ED6E32DC09C1E038ADAC0963F5D157"
PINS = {
    "pre": ("canonical_pre_manifest.json", "5539FF5034F4AEF831C5FDD45B6F1A517FF44CDF3F4F23D11FB6F1E1F29BF925"),
    "root": ("ROOT_PARTIAL_AUDIT_20260831.json", "FD9BC69BD29791639B850FD61CF560DED592F6CFE8E72332274FB7E3FE149B4A"),
    "source24": ("READ_ONLY_SOURCE_AUDIT_I0544_I0567.json", "2EE8F51F9E990C7C44F7A4F30FBE5E79C514293BC188F40739888BD267E4F82B"),
    "final8": ("PARTIAL_I0568_I0575_AUDIT.json", "4A4903BB6832700EBBD2B4A6C70BB646C45D80EC039DE01A189C4EB795401966"),
    "qa24": ("ROOT_FIRST24_FINAL_QA.json", "8A25663493745D7FF88DEBC50C7F6274023468BA724C496C474E5BE89768221E"),
    "qa546": ("ROOT_I0546_FINAL_LAYOUT_ADDENDUM.json", "85919E40298B2E8C6B2841A1E762794264F6CDEDC995A196743C1D2AE4555522"),
    "late": ("LATE_SOURCE_LAYOUT_CORRECTIONS_20260831.json", "3E1609687453A0EF6C3E4F5C9EB34F59D9038B480A1F56CE2991BE2B692427E8"),
    "queries24": ("FIRST24_QUERY_DISPOSITIONS_20260831.json", "6B938AB75E66ABC3AC04553D16180D10DD06FE407ABAB99E75B0DBE10A3115E3"),
    "qa_late": ("ROOT_LATE_TYPOGRAPHY_FINAL_QA.json", "D2C1ABC8E0C617B75C57A133CA038F58E99DB16EC7AEF916F6ED25A055734F8F"),
    "figure": ("FIG2_SOURCE_CROP_PROVENANCE.json", "A10F73EF09CAB1B333C01196CDCD9385496BE28FB70654F9311413A9FD803F71"),
}
SOURCE_HASH = "25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387"
CHECK_HASH = "78407FACC9D04C98FC890F394AA4A1656778372695B5562831EBB16434D03030"
PREAMBLE_HASH = "7973169E1E91480CA8CE61CB1C22556557332938EBB5168FDDD6BC07436C93F4"

def digest(data):
    return hashlib.sha256(data).hexdigest().upper()

def ident(path):
    p = Path(path)
    if not p.is_absolute():
        p = WORK / p
    return {"path": str(p), "bytes": p.stat().st_size, "sha256": digest(p.read_bytes())}

def same(a, b):
    return a["bytes"] == b["bytes"] and a["sha256"].upper() == b["sha256"].upper()

def verify_id(item):
    now = ident(item["path"])
    assert same(item, now), ("Identity mismatch", item, now)
    return now

def is_canonical(path):
    p = str(path).replace("\\", "/")
    return "/swarm_tex/b3/" in "/" + p or "/swarm_en/b3/" in "/" + p

def verify_evidence_tree(obj, seen):
    if isinstance(obj, dict):
        if {"path", "bytes", "sha256"} <= obj.keys() and not is_canonical(obj["path"]):
            key = str(obj["path"]), obj["sha256"]
            if key not in seen:
                verify_id(obj)
                seen.add(key)
        for v in obj.values():
            verify_evidence_tree(v, seen)
    elif isinstance(obj, list):
        for v in obj:
            verify_evidence_tree(v, seen)

def cpath(leaf, lang):
    return WORK / ("swarm_tex" if lang == "DE" else "swarm_en") / "b3" / f"b3_{leaf}.tex"

def ckey(item):
    path = item["path"].replace("\\", "/")
    return re.search(r"b3_(i\d{4})\.tex$", path).group(1), ("DE" if "/swarm_tex/" in "/" + path else "EN")

def root_hash(leaves):
    h = hashlib.sha256()
    for leaf in leaves:
        for lang in ("DE", "EN"):
            h.update(f"{lang.lower()}:{leaf}:".encode())
            h.update(cpath(leaf, lang).read_bytes())
            h.update(b"\n")
    return h.hexdigest().upper()

def tex_check(text):
    stripped = re.sub(r"(?m)(?<!\\)%.*$", "", text)
    depth = 0
    for m in re.finditer(r"(?<!\\)[{}]", stripped):
        depth += 1 if m.group() == "{" else -1
        assert depth >= 0, "Early closing brace"
    assert depth == 0, "Unbalanced braces"
    stack = []
    for m in re.finditer(r"\\(begin|end)\{([^}]+)\}", stripped):
        if m.group(1) == "begin":
            stack.append(m.group(2))
        else:
            assert stack and stack.pop() == m.group(2), "Mismatched environment"
    assert not stack
    # A row break followed by spacing, e.g. \\\\[2pt], is not a math opener.
    assert len(re.findall(r"(?<!\\)\\\[", stripped)) == len(re.findall(r"(?<!\\)\\\]", stripped))
    assert len(re.findall(r"(?<!\\)\\\(", stripped)) == len(re.findall(r"(?<!\\)\\\)", stripped))
    assert len(re.findall(r"(?<!\\)\$", stripped)) % 2 == 0
    assert not re.search(r"\\weberfigure\{", stripped), "Unreplaced figure placeholder"
    return "PASS"

def normalize_proof(p, leaf, lang, page, raster, canonical, origin, status):
    assert status == "PASS", (origin, leaf, status)
    return {"leaf": leaf, "language": lang, "proof_page": int(page), "pdf": p["pdf"],
            "master": p["master"], "log": p["log"], "raster": raster,
            "canonical_input": canonical, "origin": origin, "visual_status": "PASS"}

def inspect_pdf_proof(p, expected_leaves):
    for name in ("pdf", "master", "log"):
        verify_id(p[name])
    n = p.get("page_count", 1)
    with fitz.open(p["pdf"]["path"]) as doc:
        assert len(doc) == n, (p["pdf"], len(doc), n)
        assert all(len(page.get_text().strip()) > 250 for page in doc), "Empty or damaged proof page"
    log = Path(p["log"]["path"]).read_text(encoding="utf-8", errors="replace")
    failures = re.findall(r"(?m)^.*(?:Overfull|Underfull|LaTeX Error|Undefined control sequence|Missing character:).*$", log)
    assert not failures, (p["log"], failures)
    master = Path(p["master"]["path"]).read_text(encoding="utf-8")
    actual = re.findall(r"b3_(i\d{4})\.tex", master)
    assert actual == expected_leaves, ("Proof master order", actual, expected_leaves)

def build():
    inputs, documents = {}, {}
    for key, (name, sha) in PINS.items():
        inputs[key] = ident(BASE / name)
        assert inputs[key]["sha256"] == sha, (key, inputs[key])
        documents[key] = json.loads((BASE / name).read_text(encoding="utf-8"))
    d = documents
    seen = set()
    for value in d.values():
        verify_evidence_tree(value, seen)
    assert ident(WORK / "check_en.py")["sha256"] == CHECK_HASH
    assert ident(WORK / "swarm_preamble.tex")["sha256"] == PREAMBLE_HASH
    source = verify_id(d["root"]["source"])
    assert source["sha256"] == SOURCE_HASH
    assert d["qa24"]["status"] == d["qa546"]["status"] == d["qa_late"]["status"] == "PASS"
    assert d["source24"]["scope"]["leaf_count"] == 24
    assert d["final8"]["scope"]["canonical_leaves"] == IDS[24:]
    assert d["pre"]["scope"]["assigned"] == IDS
    assert [x["id"] for x in d["pre"]["records"]] == SELECTED
    pre = {x["id"]: x for x in d["pre"]["records"]}

    # Establish the initial32 source-audited identities, then an exact before/after chain.
    expected = {ckey(x): x for x in d["qa24"]["canonical_inputs"]}
    assert len(expected) == 48
    for row in d["source24"]["leaves"]:
        for field, lang in (("de", "DE"), ("en", "EN")):
            assert same(row[field], expected[(row["leaf_id"], lang)])
    for x in d["root"]["canonical_current"]:
        assert same(x, expected[ckey(x)])
    for row in d["final8"]["leaf_reviews"]:
        for field, lang in (("german", "DE"), ("english", "EN")):
            expected[(row["leaf"], lang)] = row["post"][field]
    assert len(expected) == 64
    for changes in (d["qa546"]["canonical_changes"], d["late"]["canonical_changes"]):
        for change in changes:
            key = ckey(change["before"])
            assert same(expected[key], change["before"]), ("Broken supersession chain", key)
            expected[key] = change["after"]
    for item in expected.values():
        verify_id(item)
    current = {(leaf, lang): ident(cpath(leaf, lang)) for leaf in SELECTED for lang in ("DE", "EN")}
    for leaf in ("i0543", "i0576"):
        for lang, field in (("DE", "german"), ("EN", "english")):
            assert same(current[(leaf, lang)], pre[leaf][field]), ("Boundary changed", leaf, lang)

    # Verify all retained proof files; then select exactly one final proof for each language leaf.
    pages = {}
    for p in d["qa24"]["proofs"]:
        lang = p["language"]
        inspect_pdf_proof(p, IDS[:24])
        for v in [x for x in d["qa24"]["visual_pages"] if x["language"] == lang]:
            old = next(x for x in d["qa24"]["canonical_inputs"] if ckey(x) == (v["leaf"], lang))
            pages[(v["leaf"], lang)] = normalize_proof(p, v["leaf"], lang, v["proof_page"], v["raster"], old, "ROOT_FIRST24_FINAL_QA", v["review_status"])
    for p in d["final8"]["build_and_visual_qa"]:
        lang = p["language"].upper()
        inspect_pdf_proof(p, IDS[24:])
        for v in p["rendered_pages"]:
            leaf = v["canonical_leaf"]
            row = next(x for x in d["final8"]["leaf_reviews"] if x["leaf"] == leaf)
            old = row["post"]["german" if lang == "DE" else "english"]
            raster = {k: v[k] for k in ("path", "bytes", "sha256")}
            pages[(leaf, lang)] = normalize_proof(p, leaf, lang, v["output_page"], raster, old, "PARTIAL_I0568_I0575_AUDIT", v["visual_status"])
    for p in d["qa546"]["proofs"]:
        inspect_pdf_proof(p, ["i0546"])
        lang = p["language"]
        post = next(x["after"] for x in d["qa546"]["canonical_changes"] if ckey(x["after"]) == ("i0546", lang))
        assert p["visual_review"].startswith("PASS:")
        pages[("i0546", lang)] = normalize_proof(p, "i0546", lang, 1, p["raster"], post, "ROOT_I0546_FINAL_LAYOUT_ADDENDUM", "PASS")
    for p in d["qa_late"]["proofs"]:
        lang = p["language"]
        pp = [x for x in d["qa_late"]["pages"] if x["language"] == lang]
        inspect_pdf_proof(p, [x["leaf"] for x in pp])
        for v in pp:
            pages[(v["leaf"], lang)] = normalize_proof(p, v["leaf"], lang, v["proof_page"], v["raster"], v["canonical_input"], "ROOT_LATE_TYPOGRAPHY_FINAL_QA", v["visual_review_status"])
    assert set(pages) == {(leaf, lang) for leaf in IDS for lang in ("DE", "EN")}
    for key, page in pages.items():
        assert same(page["canonical_input"], current[key]), ("Stale final proof", key)
        verify_id(page["raster"])
        with Image.open(page["raster"]["path"]) as im:
            assert im.size == (2481, 3508), ("Proof raster size", key, im.size)

    # Concrete correction inventory: source typography is not classified as algebra.
    corrections = []
    for n, c in enumerate(d["root"]["applied_correction_inventory"], 1):
        c = copy.deepcopy(c)
        c.update(id=f"ROOT_INITIAL_{n:02d}", category="mixed_source_editorial_correction", status="FIXED_SOURCE_BACKED", evidence=inputs["root"])
        corrections.append(c)
    for n, c in enumerate(d["qa546"]["corrections"], 1):
        c = copy.deepcopy(c)
        c.update(id=f"ROOT_I0546_{n}", status="FIXED_SOURCE_BACKED", evidence=inputs["qa546"])
        corrections.append(c)
    for c in d["late"]["corrections"]:
        corrections.append(dict(c, evidence=inputs["late"]))
    for row in d["final8"]["leaf_reviews"]:
        corrections.extend(dict(c, leaf=row["leaf"], groups=1, evidence=inputs["final8"]) for c in row["corrections"])
    assert sum(x["groups"] for x in corrections) == 47
    assert len({x["id"] for x in corrections}) == len(corrections)

    anomalies = []
    for x in d["source24"]["findings"]:
        if x["kind"] == "source_original":
            anomalies.append(dict(x, category="source_original_mathematical_or_cross_reference_anomaly",
                                  groups=1, source_occurrences=(4 if x["id"] == "SRC_0546_N_ARGUMENTS" else 1),
                                  evidence=inputs["source24"]))
    for row in d["final8"]["leaf_reviews"]:
        anomalies.extend(dict(a, leaf=row["leaf"], groups=1, evidence=inputs["final8"]) for a in row["source_anomalies"])
    assert len(anomalies) == 21

    q24 = {r["leaf"]: r for r in d["queries24"]["leaves"]}
    source24 = {r["leaf_id"]: r for r in d["source24"]["leaves"]}
    final8 = {r["leaf"]: r for r in d["final8"]["leaf_reviews"]}
    records, source_images, query_ids = [], [], []
    doc = fitz.open(source["path"])
    for leaf in IDS:
        n = int(leaf[1:])
        problems = check_en.check("b3", n)
        assert not problems, (leaf, problems)
        for lang in ("DE", "EN"):
            tex_check(cpath(leaf, lang).read_text(encoding="utf-8"))
        printed = check_en.printed_of(cpath(leaf, "DE").read_text(encoding="utf-8"))
        assert printed == ("none" if n == 556 else str(n - 31)), (leaf, printed)
        source_image = ident(BASE / f"source_scan_page-{n+1}.png")
        witness = source24[leaf]["source"] if n < 568 else final8[leaf]["source_image"]
        assert same(source_image, witness)
        with Image.open(source_image["path"]) as im:
            dpi = [im.width * 72 / doc[n].rect.width, im.height * 72 / doc[n].rect.height]
            assert im.size == (1048, 1656) and all(abs(x - 200) < 1 for x in dpi)
        source_images.append(dict(source_image, leaf=leaf, source_pdf_page_one_based=n+1, actual_dpi=200))
        qid = ident(WORK / "translation_queries" / f"b3_{leaf}.json")
        qdata = json.loads(Path(qid["path"]).read_text(encoding="utf-8"))["queries"]
        qrow = q24[leaf] if n < 568 else final8[leaf]
        assert same(qid, qrow["query_file" if n < 568 else "historical_queries_file"])
        qdisp = copy.deepcopy(qrow["query_dispositions"])
        assert len(qdisp) == len(qdata)
        for i, (qd, original) in enumerate(zip(qdisp, qdata), 1):
            assert qd["terminal"] is True and qd["query_number_one_based"] == i
            assert qd["historical_query"] == original and qd["rationale"]
        if leaf == "i0574":
            qdisp[1]["superseded_prior_disposition"] = {k: qdisp[1][k] for k in ("status", "rationale")}
            qdisp[1].update(status="FIXED_SOURCE_BACKED", rationale=d["late"]["superseded_final8_query"]["rationale"], evidence=inputs["late"])
        query_ids.append(qid)
        cs = [c for c in corrections if c["leaf"] == leaf]
        aa = [a for a in anomalies if a["leaf"] == leaf]
        changed = any(not same(current[(leaf, lang)], pre[leaf][field]) for lang, field in (("DE", "german"), ("EN", "english")))
        records.append({"id": leaf, "source_pdf_page": n+1, "printed_page": printed,
                        "source_inspection": "COMPLETE_SYMBOL_FORMULA_TRANSLATION_SEMANTIC",
                        "source_image": source_image, "german": current[(leaf, "DE")], "english": current[(leaf, "EN")],
                        "pre": pre[leaf], "canonical_leaf_changed": changed,
                        "status": "FIXED" if cs else ("SOURCE_ORIGINAL_SIC" if aa else "PASS"),
                        "corrections": cs, "source_original_anomalies": aa,
                        "source_review": source24[leaf]["review"] if n < 568 else {"source": final8[leaf]["source_visual_review"], "checks": final8[leaf]["checks"]},
                        "historical_query_count": len(qdata), "historical_query_file": qid,
                        "historical_query_disposition": "TERMINALLY_ADJUDICATED", "query_dispositions": qdisp,
                        "checks": {"formula_parity": "PASS", "tex_structure": "PASS", "printed_page": "PASS", "final_source_and_proof_identity": "PASS"},
                        "proofs": [pages[(leaf, "DE")], pages[(leaf, "EN")]], "unresolved": 0})
    doc.close()
    assert sum(x["historical_query_count"] for x in records) == 120

    jmap = {(x["left"], x["right"]): copy.deepcopy(x) for x in d["source24"]["boundaries"]}
    jmap.update({(x["left"], x["right"]): copy.deepcopy(x) for x in d["final8"]["joins"]})
    joins = []
    for n in range(543, 576):
        pair = (f"i{n:04d}", f"i{n+1:04d}")
        j = jmap[pair]
        assert j["status"] == "PASS"
        for stale in ("context_identities", "outside_assignment_context_only"):
            j.pop(stale, None)
        j["context_identities"] = {f"{side}_{lang.lower()}": current[(leaf, lang)] for side, leaf in zip(("left", "right"), pair) for lang in ("DE", "EN")}
        j["source_images"] = [ident(BASE / f"source_scan_page-{n+1}.png"), ident(BASE / f"source_scan_page-{n+2}.png")]
        j["late_change_disposition"] = "Final typography changes do not remove, duplicate, or alter join prose/math; postchange context identities revalidated."
        joins.append(j)
    assert len(joins) == 33

    # Exact source-backed invariants for the late and high-risk fixes.
    for lang in ("DE", "EN"):
        for n, count in ((556, 1), (561, 2), (562, 2), (563, 1)):
            t = cpath(f"i{n:04d}", lang).read_text(encoding="utf-8")
            assert t.count(r"\mathop{\mathrm{Lim}}\limits_{s=1}") == count
            assert r"\mathrm{Lim}_{s=1}" not in t
        t = cpath("i0563", lang).read_text(encoding="utf-8")
        assert t.count(r"\text{\textquotedblbase}") == 3 and r"\text{\textquotedbl}" not in t
        assert r"\rule{0.25\linewidth}{0.2pt}" in cpath("i0555", lang).read_text(encoding="utf-8")
        t546 = cpath("i0546", lang).read_text(encoding="utf-8")
        assert r"\begin{cases}" not in t546
        t544 = cpath("i0544", lang).read_text(encoding="utf-8")
        assert t544.count(r"\footnotetext[1]") == 1 and r"\footnote{" not in t544
        t558 = cpath("i0558", lang).read_text(encoding="utf-8")
        assert "weber_b3_i0558_fig2_source_crop.png" in t558 and r"\weberfigure{" not in t558
    assert r"\gesperrt{Gauss}schen" in cpath("i0555", "DE").read_text(encoding="utf-8")
    assert r"\gesperrt{Pell}schen" in cpath("i0574", "DE").read_text(encoding="utf-8")
    from fractions import Fraction
    for lam in range(1, 9):
        assert Fraction(1,4)/2**lam + Fraction(1,2) - Fraction(1,2**(lam+1)) == Fraction(1,2)-Fraction(1,2**(lam+2))
        assert Fraction(1,3)/2**lam + Fraction(1,2) - Fraction(1,2**(lam+1)) == Fraction(1,2)-Fraction(1,3*2**(lam+1))

    changed = [r["id"] for r in records if r["canonical_leaf_changed"]]
    file_changes = [{"leaf": leaf, "language": lang, "before": pre[leaf][field], "after": current[(leaf, lang)]}
                    for leaf in IDS for lang, field in (("DE", "german"), ("EN", "english"))
                    if not same(pre[leaf][field], current[(leaf, lang)])]
    counts = {"assigned_leaves": 32, "terminal_leaves": 32,
              "fixed_leaves": sum(r["status"] == "FIXED" for r in records),
              "source_original_sic_only_leaves": sum(r["status"] == "SOURCE_ORIGINAL_SIC" for r in records),
              "pass_leaves": sum(r["status"] == "PASS" for r in records),
              "changed_canonical_files": len(file_changes), "changed_unique_leaves": len(changed),
              "confirmed_defects_fixed": sum(c["groups"] for c in corrections),
              "algebra_changing_reconstruction_groups": sum(c["groups"] for c in corrections if c["category"] == "mathematical_semantics"),
              "algebra_changing_source_occurrences": sum(c.get("source_occurrences", 1) for c in corrections if c["category"] == "mathematical_semantics"),
              "technical_translation_semantics_groups": 1,
              "source_original_anomalies": len(anomalies),
              "mathematical_or_cross_reference_source_anomalies": sum(a["id"] != "A573-1" for a in anomalies),
              "source_original_anomaly_occurrences": sum(a["source_occurrences"] for a in anomalies),
              "historical_query_files_adjudicated": 32, "historical_queries_adjudicated": 120,
              "joins_checked": 33, "final_proof_pages_visually_reviewed": 64, "unresolved": 0}
    assert counts["algebra_changing_reconstruction_groups"] == 1 and counts["algebra_changing_source_occurrences"] == 2
    # This is a deterministic named-file root, not directory enumeration or a Git scan.
    roots = {"pre_selected_root_sha256": d["pre"]["selected_root_sha256"], "post_selected_root_sha256": root_hash(SELECTED),
             "pre_full_root_sha256": d["pre"]["full_root_sha256"], "post_full_root_sha256": root_hash(FULL)}
    for key, item in current.items():
        assert same(item, ident(cpath(*key))), ("Canonical moved during seal", key)
    return {"schema": "weber-editorial-chunk-source-backed/v2", "status": "PASS", "volume": "III", "chunk": CHUNK.stem,
            "scope": {"inbound_read_only": "i0543", "assigned_canonical_sequence": IDS, "assigned_first": IDS[0], "assigned_last": IDS[-1], "outbound_read_only": "i0576", "assigned_leaf_count": 32},
            "source": source, "pre_manifest": inputs["pre"], "live_root_hashes": roots,
            "canonical_leaf_changed": changed, "canonical_file_changed": file_changes,
            "source_evidence": source_images, "historical_query_evidence": query_ids, "records": records, "joins": joins,
            "correction_inventory": corrections, "source_original_anomalies": anomalies, "counts": counts,
            "boundary_post": [dict(id=leaf, german=current[(leaf,"DE")], english=current[(leaf,"EN")]) for leaf in ("i0543","i0576")],
            "qa_attestations": [inputs[k] for k in ("qa24","qa546","final8","qa_late")],
            "final_visual_coverage": dict(Counter(x["origin"] for x in pages.values())),
            "source_audit_receipts": [inputs[k] for k in ("source24","final8","late","queries24")],
            "pinned_inputs": inputs, "figure_asset": verify_id(d["qa24"]["figure_asset"]), "figure_provenance": inputs["figure"],
            "figure_extraction_script": ident(BASE / "extract_fig2_source_crop.py"),
            "checker": {"status": "PASS", "scope": IDS, "validator": ident(WORK/"check_en.py"), "problems": []},
            "structural_validator": {"status": "PASS", "scope": "64 current language leaves; balanced braces/environments/math delimiters; no placeholders; high-risk exact invariant checks", "script": ident(__file__)},
            "counting_policy": "Correction groups are concrete inventory groups, not mirrored-language duplicates. Layout, emphasis and punctuation are not algebra-changing errors. One i0572 group corrects two exponent scopes. Source-original anomalies are preserved and annotated; redundant denominator1 is typography, excluded from mathematical-anomaly count. Earlier partial completion claims are superseded only by the exact listed late changes.",
            "evidence_preservation": "All historical query files, audit receipts, pre snapshots, source rasters and previous proofs remain unchanged. Final32 canonical/proof identities follow the explicit before/after supersession chain.",
            "unresolved": 0, "outbound_candidates": []}

def write_new(path, obj):
    assert not path.exists(), ("Refuse overwrite", str(path))
    raw = (json.dumps(obj, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    with path.open("xb") as f:
        f.write(raw)
    assert json.loads(path.read_text(encoding="utf-8")) == obj

def verify_saved(obj):
    saved = json.loads(CHUNK.read_text(encoding="utf-8"))
    clone = copy.deepcopy(saved)
    clone.pop("completed_at_utc", None)
    assert clone == obj, "Saved chunk differs from current deterministic evidence"
    return saved

def advance_cursor(saved):
    cursor = json.loads(CURSOR.read_text(encoding="utf-8"))
    if cursor["last_terminal_leaf"] == "i0575":
        matches = [x for x in cursor["terminal_receipts"] if Path(x["path"]) == CHUNK]
        assert len(matches) == 1 and same(matches[0], ident(CHUNK))
        return "ALREADY_ADVANCED_NO_WRITE"
    assert ident(CURSOR)["sha256"] == CURSOR_PRE_HASH, "Unexpected cursor identity"
    assert cursor["terminal_leaves"] == cursor["terminal_leaf_count"] == 512
    assert cursor["last_terminal_leaf"] == "i0543" and cursor["next_leaf"] == "i0544"
    old = copy.deepcopy(cursor)
    counts = saved["counts"]
    for key in ("terminal_leaves", "terminal_leaf_count"):
        cursor[key] += 32
    for key in ("confirmed_defects", "fixed_defects", "cumulative_confirmed_defects_fixed"):
        cursor[key] += counts["confirmed_defects_fixed"]
    for key in ("source_original_anomalies", "cumulative_source_original_anomalies"):
        cursor[key] += counts["source_original_anomalies"]
    for key in ("source_original_mathematical_or_cross_reference_anomalies", "cumulative_mathematical_or_cross_reference_source_anomalies"):
        cursor[key] += counts["mathematical_or_cross_reference_source_anomalies"]
    for key in ("changed_leaves", "cumulative_changed_leaves"):
        cursor[key] += counts["changed_unique_leaves"]
    cursor.update(last_terminal_leaf="i0575", next_leaf="i0576", active_chunk="CHUNK_0018_i0576_i0607", updated_at_utc=datetime.now(timezone.utc).isoformat())
    cursor["terminal_receipts"].append(ident(CHUNK))
    receipt = {"schema": "weber-chunk17-cursor-advance/v1", "cursor_pre_identity": ident(CURSOR), "before": old,
               "after": cursor, "terminal_chunk": ident(CHUNK), "independent_seal": ident(SEAL), "advance_count": 1}
    write_new(BASE/"CURSOR_ADVANCE_CHUNK_0017.json", receipt)
    # Generated cursor update is narrow and occurs only after terminal chunk+seal readback.
    CURSOR.write_text(json.dumps(cursor, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    assert json.loads(CURSOR.read_text(encoding="utf-8")) == cursor
    return "ADVANCED_ONCE"

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--seal", action="store_true")
    parser.add_argument("--advance", action="store_true")
    args = parser.parse_args()
    assert not args.advance or args.seal
    result = build()
    state = "READ_ONLY_CHECK_PASS"
    if CHUNK.exists():
        verify_saved(result)
    if args.seal:
        if not CHUNK.exists():
            assert not SEAL.exists()
            saved = dict(result, completed_at_utc=datetime.now(timezone.utc).isoformat())
            write_new(CHUNK, saved)
            verify_saved(result)
            seal = {"schema":"weber-chunk17-independent-seal/v1", "status":"PASS", "completed_at_utc":datetime.now(timezone.utc).isoformat(),
                    "chunk":ident(CHUNK), "script":ident(__file__), "pinned_inputs":result["pinned_inputs"],
                    "counts":result["counts"], "live_root_hashes":result["live_root_hashes"], "gates":{
                    "all32_source_leaves":True,"all64_final_language_inputs":True,"all64_final_visual_proofs":True,
                    "all33_boundary_joins":True,"all120_historical_queries_terminal":True,"source_and_evidence_hashes":True,
                    "exact_before_after_supersession_chain":True,"formula_parity":True,"tex_structure":True,
                    "source_original_anomalies_preserved":True,"counting_derived_from_concrete_inventory":True,
                    "no_shared_or_publication_writes":True}, "unresolved":0}
            write_new(SEAL, seal)
        saved = verify_saved(result)
        seal = json.loads(SEAL.read_text(encoding="utf-8"))
        assert seal["status"] == "PASS" and same(seal["chunk"], ident(CHUNK)) and same(seal["script"], ident(__file__))
        state = advance_cursor(saved) if args.advance else "SEALED_READBACK_PASS"
    print(json.dumps({"status":"PASS","operation":state,"counts":result["counts"],"live_root_hashes":result["live_root_hashes"],
                      "chunk":ident(CHUNK) if CHUNK.exists() else None,"seal":ident(SEAL) if SEAL.exists() else None}, indent=2))

if __name__ == "__main__":
    main()
