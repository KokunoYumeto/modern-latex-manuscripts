"""Seal two source-layout restorations without rewriting earlier proof evidence."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
import fitz

E = Path(__file__).resolve().parent
W = E.parents[4]


def identity(p):
    p = Path(p)
    data = p.read_bytes()
    return {"path": str(p), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest().upper()}


prior = E / "ROOT_FIRST24_FINAL_QA.json"
assert identity(prior)["sha256"] == "8A25663493745D7FF88DEBC50C7F6274023468BA724C496C474E5BE89768221E"
qa = json.loads(prior.read_text(encoding="utf-8"))
changed = []
for expected in qa["canonical_inputs"]:
    if Path(expected["path"]).name != "b3_i0546.tex":
        assert identity(expected["path"]) == expected
    else:
        changed.append({"before": expected, "after": identity(expected["path"])})
assert len(changed) == 2
for row in qa["visual_pages"]:
    assert identity(row["raster"]["path"]) == row["raster"]
proofs = []
for lane in ("de", "en"):
    base = E / f"root_i0546_final_{lane}"
    log = base.with_suffix(".log")
    logtext = log.read_text(encoding="utf-8", errors="replace")
    assert not re.search(r"Overfull|Underfull|Undefined control sequence|LaTeX Error", logtext)
    assert f"AUDIT_START_{lane.upper()}_i0546_PAGE:1" in logtext
    with fitz.open(base.with_suffix(".pdf")) as pdf:
        assert len(pdf) == 1
    proofs.append({"language": lane.upper(), "leaf": "i0546", "proof_page": 1, "pdf": identity(base.with_suffix(".pdf")), "log": identity(log), "master": identity(base.with_suffix(".tex")), "raster": identity(base.with_suffix(".png")), "raster_dpi": 300, "visual_review": "PASS: Root inspected the entire final 300dpi page, confirmed equations12/13 are unbraced, equation12 repeats the equality on row2, both row alignments and shared mod4 clauses are legible, and no overlap/clipping/spill occurs."})
result = {
    "schema": "weber-root-proof-qa-addendum/v1",
    "status": "PASS",
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Final two source-layout corrections on Volume III i0546 in German and English.",
    "prior_first24_qa": identity(prior),
    "prior_evidence_preservation": "Prior48-page proof set remains byte-identical and historical. Its46 non-i0546 proof pages remain valid against unchanged canonical inputs; only its two i0546 proof pages are superseded by the two final proofs recorded here.",
    "source": qa["source"],
    "source_page": {"pdf_one_based": 547, "printed": 515, "raster": identity(E / "source_scan_page-547.png"), "visual_review": "Root inspected the complete registered source raster and confirmed both displays are unbraced and equation12 has equality signs before both Psi rows."},
    "corrections": [
        {"leaf": "i0546", "languages": ["DE", "EN"], "groups": 1, "category": "display_structure_source_fidelity", "detail": "Equation12: replace the added cases brace with source-unbraced aligned rows and restore the repeated equality on row2; all mathematical arguments and conditions unchanged."},
        {"leaf": "i0546", "languages": ["DE", "EN"], "groups": 1, "category": "display_structure_source_fidelity", "detail": "Equation13: remove the added cases brace while retaining the two aligned sign-change rows and shared mod4 condition."}
    ],
    "canonical_changes": changed,
    "proofs": proofs,
    "counts": {"additional_correction_groups": 2, "canonical_language_files_changed": 2, "new_proof_pages_built_and_visually_reviewed": 2, "unchanged_previously_reviewed_proof_pages_retained": 46, "final_first24_visual_coverage": 48, "algebra_changing_corrections": 0, "unresolved": 0},
    "terminal_assertion": "Together with the prior46 unaffected pages, this addendum completes visual/build QA of all48 final first24 DE/EN canonical pages. The aggregate chunk receipt must use these postchange i0546 identities and count these two additional source-layout groups."
}
out = E / "ROOT_I0546_FINAL_LAYOUT_ADDENDUM.json"
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "receipt": identity(out)}))
