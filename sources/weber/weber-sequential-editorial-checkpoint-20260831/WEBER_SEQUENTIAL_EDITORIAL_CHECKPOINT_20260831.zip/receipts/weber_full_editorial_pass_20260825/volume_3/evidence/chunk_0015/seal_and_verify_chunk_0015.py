import hashlib
import json
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import fitz

W = Path(r'local-environment/Documents\weber_restart_20260819\work')
D = W / 'swarm_tex' / 'b3'
E = W / 'swarm_en' / 'b3'
V = W / 'receipts' / 'weber_full_editorial_pass_20260825' / 'volume_3'
EV = V / 'evidence' / 'chunk_0015'
P = EV / 'canonical_pre_manifest.json'
C = V / 'CURSOR.json'
R = V / 'chunks' / 'CHUNK_0015_i0480_i0511.json'
A = EV / 'FINAL_QA_ATTESTATION.json'
O = EV / 'INDEPENDENT_FINAL_VERIFICATION.json'
S = Path(r'registered-source/Weber_Algebra_Bd3.pdf')

IDS = [f'i{n:04d}' for n in range(480, 512)]
SEL = ['i0479', *IDS, 'i0512']
FULL = [f'i{n:04d}' for n in range(22, 415)] + [f'i{n:04d}' for n in range(425, 772)]
EXPECTED_DE_CHANGED = ['i0485', 'i0501', 'i0502', 'i0503', 'i0504']
EXPECTED_EN_CHANGED = ['i0485', 'i0498', 'i0499', 'i0501', 'i0502', 'i0503', 'i0504', 'i0505', 'i0510']
RENDER_DE = ['i0504']
RENDER_EN = ['i0498', 'i0499', 'i0503', 'i0504', 'i0505', 'i0510']

COR = {
    'i0498': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Repaired the opening half of the English cross-page conditional so that the rational equation is correctly said to be satisfied among the four values.',
    },
    'i0499': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Repaired the continuation of the English cross-page conditional with the required by-phrases and removed the stray plural predicate.',
    },
    'i0503': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Corrected the defective literal English construction “the one ... passes over” to the precise statement that one congruence and one sign change into the other.',
    },
    'i0504': {
        'confirmed_defect_count': 3,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Restored the source-printed divisor symbol partial in equation (26) in both languages; also repaired two defective English renderings (“make known the methods” and “the task is frequently set of”).',
    },
    'i0505': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Completed the English cross-page sentence with idiomatic and source-faithful wording: the factorization is verifiable and its factors are easy to find.',
    },
    'i0510': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Repaired the ungrammatical English transition to equation (10): solving a quadratic equation readily yields the displayed result.',
    },
}

ANO = [
    {'id': 'i0482', 'detail': "The source prints A-prime squared times c in (8), while the derived quadratic expression requires A-prime times c squared. Retained and annotated.", 'mathematical_or_cross_reference': True},
    {'id': 'i0484', 'detail': 'The source prints g p in the third comparison relation, while elimination from (18) requires gamma p. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0485', 'detail': 'The source prints y=+1 and =-1, omitting y before the second equality. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0485', 'detail': 'The source cites values (3), although the displayed quantities under discussion are the values (15). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0488', 'detail': 'The source prints the nonstandard spelling “definirt.” Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0492', 'detail': 'The source prints singular “dieser Wert” with plural “kommen.” Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0501', 'detail': 'The source prints y=plus-or-minus 1 or =plus-or-minus 3, omitting y before the second equality. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0502', 'detail': 'The source phrase “woraus zu schließen, daß” omits the grammatically required “ist.” Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0503', 'detail': 'The source prints y=0 or =plus-or-minus 2, omitting y before the second equality. Retained and annotated.', 'mathematical_or_cross_reference': True},
]


def sh(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def ident(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sh(path)}


def wr(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def root(ids):
    h = hashlib.sha256()
    for leaf in ids:
        for lang, base in [('de', D), ('en', E)]:
            h.update(f'{lang}:{leaf}:'.encode())
            h.update((base / f'b3_{leaf}.tex').read_bytes())
            h.update(b'\n')
    return h.hexdigest().upper()


def run(args):
    proc = subprocess.run(args, cwd=W, text=True, encoding='utf-8', errors='replace', capture_output=True)
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def main():
    pre = json.loads(P.read_text(encoding='utf-8'))
    prior = {record['id']: record for record in pre['records']}
    assert list(prior) == SEL

    post = {}
    de_changed = []
    en_changed = []
    for leaf in SEL:
        post[leaf] = {
            'german': ident(D / f'b3_{leaf}.tex'),
            'english': ident(E / f'b3_{leaf}.tex'),
        }
        if post[leaf]['german']['sha256'] != prior[leaf]['german']['sha256']:
            de_changed.append(leaf)
        if post[leaf]['english']['sha256'] != prior[leaf]['english']['sha256']:
            en_changed.append(leaf)
    assert de_changed == EXPECTED_DE_CHANGED, de_changed
    assert en_changed == EXPECTED_EN_CHANGED, en_changed
    assert all(post[leaf][lang] == prior[leaf][lang] for leaf in ['i0479', 'i0512'] for lang in ['german', 'english'])

    pre_selected = pre['selected_root_sha256']
    pre_full = pre['full_root_sha256']
    post_selected = root(SEL)
    post_full = root(FULL)
    assert sh(S) == '25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387'

    scans = [EV / f'source_scan_page-{page}.png' for page in range(480, 514)]
    assert len(scans) == 34 and all(path.stat().st_size for path in scans)
    extracted = EV / 'source_scan_pages_480_513_extracted.txt'
    assert extracted.stat().st_size
    support = sorted(EV.glob('source_contact_*.jpg'))
    assert len(support) == 5 and all(path.stat().st_size for path in support)

    de_master = EV / 'changed_leaf_qa_de.tex'
    en_master = EV / 'changed_leaf_qa_en.tex'
    de_pdf = EV / 'changed_leaf_qa_de.pdf'
    en_pdf = EV / 'changed_leaf_qa_en.pdf'
    de_log = EV / 'changed_leaf_qa_de.log'
    en_log = EV / 'changed_leaf_qa_en.log'
    assert len(fitz.open(de_pdf)) == 1 and len(fitz.open(en_pdf)) == 6
    assert re.findall(r'b3_(i\d{4})\.tex', de_master.read_text(encoding='utf-8')) == RENDER_DE
    assert re.findall(r'b3_(i\d{4})\.tex', en_master.read_text(encoding='utf-8')) == RENDER_EN
    fatal_pattern = r'LaTeX Error|Undefined control sequence|Emergency stop|Fatal error|Overfull \\hbox|Overfull \\vbox|Underfull \\hbox|Underfull \\vbox'
    for log in [de_log, en_log]:
        assert not re.search(fatal_pattern, log.read_text(encoding='utf-8', errors='replace'), re.I)
    de_renders = sorted(EV.glob('final_qa_de_page-*.png'))
    en_renders = sorted(EV.glob('final_qa_en_page-*.png'))
    assert len(de_renders) == 1 and len(en_renders) == 6

    gate_formula, output_formula = run(['python', 'check_en.py', 'b3'])
    gate_structure, output_structure = run(['python', '_audit_printed_coverage.py', 'b3'])
    assert gate_formula == 0 and '740 pass, 0 fail, 3457 audit queries raised' in output_formula
    assert gate_structure == 0 and '750 fragments | printed range 1-733 | 43 unnumbered leaves' in output_structure
    for leaf in IDS:
        for path in [D / f'b3_{leaf}.tex', E / f'b3_{leaf}.tex']:
            text = path.read_text(encoding='utf-8')
            assert not re.search(r'\?\?|\b(?:TODO|TBD|PENDING|PLACEHOLDER|FIXME|UNCERTAIN|HOLD)\b', text)
    assert sum((D / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 9
    assert sum((E / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 9

    for base in [D, E]:
        eq26 = (base / 'b3_i0504.tex').read_text(encoding='utf-8')
        assert r'\frac{c+\partial\omega}{a}' in eq26 and r'\frac{c+d\omega}{a}' not in eq26
        assert 'omits y' in (base / 'b3_i0485.tex').read_text(encoding='utf-8')
        assert 'quantities under discussion are (15)' in (base / 'b3_i0485.tex').read_text(encoding='utf-8')
        assert 'second equality' in (base / 'b3_i0501.tex').read_text(encoding='utf-8')
        assert 'zu schließen' in (base / 'b3_i0502.tex').read_text(encoding='utf-8')
        assert 'second equality' in (base / 'b3_i0503.tex').read_text(encoding='utf-8')
    assert 'that, among the four values (3), is satisfied either only' in (E / 'b3_i0498.tex').read_text(encoding='utf-8')
    assert 'by the one corresponding to the value $r=0$, or by the two corresponding' in (E / 'b3_i0499.tex').read_text(encoding='utf-8')
    assert 'one of these congruences changes into the other' in (E / 'b3_i0503.tex').read_text(encoding='utf-8')
    assert 'teach the methods that can also be used for further calculations' in (E / 'b3_i0504.tex').read_text(encoding='utf-8')
    assert 'one is frequently faced with the task' in (E / 'b3_i0504.tex').read_text(encoding='utf-8')
    assert 'verifiable; but finding the factors is also easy' in (E / 'b3_i0505.tex').read_text(encoding='utf-8')
    assert 'by solving a quadratic equation, one readily obtains' in (E / 'b3_i0510.tex').read_text(encoding='utf-8')

    now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    attestation = {
        'schema': 'weber-changed-leaf-final-qa/v1',
        'status': 'PASS',
        'completed_at_utc': now,
        'volume': 'III',
        'chunk': 'CHUNK_0015_i0480_i0511',
        'visual_inspection': {
            'method': 'All seven rendering-changing proof pages were compiled, rendered with Poppler at 300 dpi after the final edits, and visually inspected page by page for clipping, overlap, glyph loss, malformed formulae, and unintended layout change.',
            'german_pages_reviewed': 1,
            'english_pages_reviewed': 6,
            'total_pages_reviewed': 7,
            'visual_defects': 0,
        },
        'source_symbol_review': {
            'status': 'PASS',
            'assigned_scan_pages_reviewed': 32,
            'boundary_scan_pages_reviewed': 2,
            'total_scan_pages_reviewed': 34,
            'source_scan_page_range_one_based': [480, 513],
        },
        'formula_gate': {'status': 'PASS', 'output': output_formula},
        'structural_gate': {'status': 'PASS_WITH_REGISTERED_TOPOLOGY', 'output': output_structure},
        'placeholder_gate': {'status': 'PASS', 'assigned_files_scanned': 64, 'marker_hits': 0},
        'german': {
            'rendering_changed_ids': RENDER_DE,
            'master': ident(de_master),
            'pdf': {**ident(de_pdf), 'pages': 1},
            'log': ident(de_log),
            'renders': [ident(path) for path in de_renders],
        },
        'english': {
            'rendering_changed_ids': RENDER_EN,
            'master': ident(en_master),
            'pdf': {**ident(en_pdf), 'pages': 6},
            'log': ident(en_log),
            'renders': [ident(path) for path in en_renders],
        },
        'unresolved': 0,
    }
    wr(A, attestation)

    corrections = {leaf: {'id': leaf, **value} for leaf, value in COR.items()}
    anomalies_by_leaf = {}
    for anomaly in ANO:
        anomalies_by_leaf.setdefault(anomaly['id'], []).append(anomaly)
    sic_only = set(anomalies_by_leaf) - set(COR)
    status = {leaf: ('FIXED' if leaf in COR else 'SOURCE_ORIGINAL_SIC' if leaf in sic_only else 'PASS') for leaf in IDS}
    assert Counter(status.values()) == Counter({'PASS': 19, 'SOURCE_ORIGINAL_SIC': 7, 'FIXED': 6})
    assert sum(item['confirmed_defect_count'] for item in COR.values()) == 8
    assert sum(item['mathematical_reconstruction_count'] for item in COR.values()) == 1
    assert sum(item['prose_grammar_or_number_count'] for item in COR.values()) == 7
    assert len(ANO) == 9
    assert sum(item['mathematical_or_cross_reference'] for item in ANO) == 6

    records = [
        {
            'id': leaf,
            'source_pdf_page': int(leaf[1:]) + 1,
            'source_inspection': 'COMPLETE_SYMBOL_FORMULA_TRANSLATION_SEMANTIC',
            'german': post[leaf]['german'],
            'english': post[leaf]['english'],
            'status': status[leaf],
            'correction': corrections.get(leaf),
            'source_original_anomalies': anomalies_by_leaf.get(leaf, []),
            'disposition': 'Terminally adjudicated against the registered scan; all source-original anomalies are annotated and no unresolved reconstruction or translation defect remains.',
            'unresolved': 0,
        }
        for leaf in IDS
    ]
    order = ['i0479', *IDS, 'i0512']
    joins = [
        {
            'from': left,
            'to': right,
            'status': 'PASS',
            'detail': f'The registered scan and both canonical languages were checked across the {left} to {right} join for sentence continuation, display topology, headings, page order, and omitted or duplicated symbols; the boundary is terminally complete.',
        }
        for left, right in zip(order, order[1:])
    ]
    assert len(joins) == 33

    counts = {
        'assigned_leaves': 32,
        'terminal_leaves': 32,
        'fixed_leaves': 6,
        'source_original_sic_only_leaves': 7,
        'pass_leaves': 19,
        'changed_canonical_files': 14,
        'changed_unique_leaves': 13,
        'rendering_changed_files': 7,
        'rendering_changed_unique_leaves': 6,
        'confirmed_defects_fixed': 8,
        'mathematical_reconstruction_defects_fixed': 1,
        'mathematical_or_technical_semantic_defects_fixed': 0,
        'prose_grammar_or_number_defects_fixed': 7,
        'source_original_anomalies': 9,
        'mathematical_or_cross_reference_source_anomalies': 6,
        'joins_checked': 33,
        'unresolved': 0,
    }
    outbound_candidates = [
        {
            'id': 'i0512',
            'language': 'german',
            'scope': 'OUTBOUND_READ_ONLY_NEXT_CHUNK',
            'detail': 'The canonical source places the full stop after “Klassengleichung” on a separate source line, which may render an unwanted space before the punctuation; adjudicate when i0512 enters the assigned scope.',
            'assigned_scope_unresolved': False,
        }
    ]
    receipt = {
        'schema': 'weber-full-editorial-chunk/v1',
        'status': 'TERMINAL_PASS',
        'completed_at_utc': now,
        'volume': 'III',
        'chunk': 'CHUNK_0015_i0480_i0511',
        'scope': {
            'inbound_read_only': 'i0479',
            'assigned_canonical_sequence': IDS,
            'assigned_first': 'i0480',
            'assigned_last': 'i0511',
            'outbound_read_only': 'i0512',
            'assigned_leaf_count': 32,
        },
        'source': ident(S),
        'pre_manifest': ident(P),
        'live_root_hashes': {
            'pre_selected_root_sha256': pre_selected,
            'post_selected_root_sha256': post_selected,
            'pre_full_root_sha256': pre_full,
            'post_full_root_sha256': post_full,
            'pre': {'selected': pre_selected, 'full': pre_full},
            'post': {'selected': post_selected, 'full': post_full},
        },
        'canonical_leaf_changed': sorted(set(de_changed + en_changed)),
        'canonical_file_changed': {'german': de_changed, 'english': en_changed, 'total': 14},
        'rendering_changed': {'german': RENDER_DE, 'english': RENDER_EN, 'total_files': 7, 'unique_leaves': 6},
        'source_evidence': {
            'pdf_pages_inspected': list(range(480, 514)),
            'assigned_pdf_pages': list(range(481, 513)),
            'mapping': 'canonical iNNNN maps to registered PDF page NNNN+1; inbound i0479 and outbound i0512 were read for join continuity',
            'render_inventory': [ident(path) for path in scans],
            'extracted_text': ident(extracted),
            'supporting_contact_sheets': [ident(path) for path in support],
        },
        'records': records,
        'joins': joins,
        'correction_inventory': list(corrections.values()),
        'source_original_anomalies': ANO,
        'counts': counts,
        'boundary_post': {'i0479': post['i0479'], 'i0512': post['i0512']},
        'qa_attestation': ident(A),
        'checker': {'status': 'PASS', 'output': output_formula},
        'structural_validator': {'status': 'PASS_WITH_REGISTERED_TOPOLOGY', 'output': output_structure},
        'outbound_candidates': outbound_candidates,
        'unresolved': 0,
    }
    wr(R, receipt)

    cursor = json.loads(C.read_text(encoding='utf-8'))
    assert cursor['last_terminal_leaf'] == 'i0479' and cursor['next_leaf'] == 'i0480'
    assert cursor['terminal_leaf_count'] == 448 and cursor['unresolved'] == 0
    cursor.update({
        'last_terminal_leaf': 'i0511',
        'next_leaf': 'i0512',
        'active_chunk': 'CHUNK_0016_i0512_i0543',
        'terminal_leaves': 480,
        'confirmed_defects': 251,
        'fixed_defects': 251,
        'source_original_anomalies': 172,
        'source_original_mathematical_or_cross_reference_anomalies': 142,
        'changed_leaves': 197,
        'terminal_leaf_count': 480,
        'cumulative_confirmed_defects_fixed': 251,
        'cumulative_source_original_anomalies': 172,
        'cumulative_mathematical_or_cross_reference_source_anomalies': 142,
        'cumulative_changed_leaves': 197,
        'unresolved': 0,
        'updated_at_utc': now,
    })
    cursor.setdefault('terminal_receipts', []).append(ident(R))
    wr(C, cursor)

    reread_receipt = json.loads(R.read_text(encoding='utf-8'))
    reread_cursor = json.loads(C.read_text(encoding='utf-8'))
    assert reread_receipt['status'] == 'TERMINAL_PASS' and len(reread_receipt['records']) == 32 and len(reread_receipt['joins']) == 33
    assert reread_receipt['counts'] == counts and reread_receipt['unresolved'] == 0
    assert reread_cursor['last_terminal_leaf'] == 'i0511' and reread_cursor['next_leaf'] == 'i0512'
    assert reread_cursor['terminal_leaf_count'] == 480 and reread_cursor['unresolved'] == 0
    assert root(SEL) == post_selected and root(FULL) == post_full
    verification = {
        'schema': 'weber-independent-chunk-verification/v1',
        'status': 'PASS',
        'verified_at_utc': now,
        'chunk': reread_receipt['chunk'],
        'receipt': ident(R),
        'attestation': ident(A),
        'cursor': ident(C),
        'pre_manifest': ident(P),
        'source': ident(S),
        'formula_gate': output_formula,
        'structural_gate': output_structure,
        'verified_changed_german': de_changed,
        'verified_changed_english': en_changed,
        'verified_rendering_changed_german': RENDER_DE,
        'verified_rendering_changed_english': RENDER_EN,
        'verified_canonical_leaf_changed': reread_receipt['canonical_leaf_changed'],
        'verified_boundaries_unchanged': ['i0479', 'i0512'],
        'verified_joins': 33,
        'verified_terminal_records': 32,
        'verified_correction_count': 8,
        'verified_source_anomaly_count': 9,
        'verified_mathematical_or_cross_reference_source_anomaly_count': 6,
        'verified_visual_pages': 7,
        'verified_unresolved': 0,
        'post_selected_root_sha256': post_selected,
        'post_full_root_sha256': post_full,
    }
    wr(O, verification)
    print(json.dumps({
        'status': 'PASS',
        'receipt': ident(R),
        'attestation': ident(A),
        'verification': ident(O),
        'cursor': ident(C),
        'counts': counts,
        'roots': {
            'pre_selected': pre_selected,
            'post_selected': post_selected,
            'pre_full': pre_full,
            'post_full': post_full,
        },
    }, indent=2))


if __name__ == '__main__':
    main()
