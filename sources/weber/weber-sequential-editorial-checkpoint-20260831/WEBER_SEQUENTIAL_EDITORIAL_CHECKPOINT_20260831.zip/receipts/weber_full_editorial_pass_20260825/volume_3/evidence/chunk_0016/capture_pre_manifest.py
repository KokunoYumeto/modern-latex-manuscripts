import hashlib
import json
from pathlib import Path

W = Path(r'local-environment/Documents\weber_restart_20260819\work')
D = W / 'swarm_tex' / 'b3'
E = W / 'swarm_en' / 'b3'
EV = W / 'receipts' / 'weber_full_editorial_pass_20260825' / 'volume_3' / 'evidence' / 'chunk_0016'
IDS = [f'i{n:04d}' for n in range(512, 544)]
SEL = ['i0511', *IDS, 'i0544']
FULL = [f'i{n:04d}' for n in range(22, 415)] + [f'i{n:04d}' for n in range(425, 772)]


def sh(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def ident(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sh(path)}


def root(ids):
    h = hashlib.sha256()
    for leaf in ids:
        for lang, base in [('de', D), ('en', E)]:
            h.update(f'{lang}:{leaf}:'.encode())
            h.update((base / f'b3_{leaf}.tex').read_bytes())
            h.update(b'\n')
    return h.hexdigest().upper()


value = {
    'schema': 'weber-canonical-pre-manifest/v1',
    'scope': {'inbound': 'i0511', 'assigned': IDS, 'outbound': 'i0544'},
    'records': [
        {
            'id': leaf,
            'german': ident(D / f'b3_{leaf}.tex'),
            'english': ident(E / f'b3_{leaf}.tex'),
        }
        for leaf in SEL
    ],
    'selected_root_sha256': root(SEL),
    'full_root_sha256': root(FULL),
}
path = EV / 'canonical_pre_manifest.json'
path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({**ident(path), 'selected': value['selected_root_sha256'], 'full': value['full_root_sha256']}, indent=2))
