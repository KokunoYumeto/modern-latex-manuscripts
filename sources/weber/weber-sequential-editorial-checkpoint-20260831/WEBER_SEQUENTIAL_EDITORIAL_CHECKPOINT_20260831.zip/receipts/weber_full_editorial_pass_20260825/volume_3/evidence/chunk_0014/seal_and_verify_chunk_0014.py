import hashlib
import json
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import fitz

W = Path(r'local-environment/Documents\weber_restart_20260819\work')
D = W / 'swarm_tex' / 'b3'
E = W / 'swarm_en' / 'b3'
V = W / 'receipts' / 'weber_full_editorial_pass_20260825' / 'volume_3'
EV = V / 'evidence' / 'chunk_0014'
P = EV / 'canonical_pre_manifest.json'
C = V / 'CURSOR.json'
R = V / 'chunks' / 'CHUNK_0014_i0448_i0479.json'
A = EV / 'FINAL_QA_ATTESTATION.json'
O = EV / 'INDEPENDENT_FINAL_VERIFICATION.json'
S = Path(r'registered-source/Weber_Algebra_Bd3.pdf')

IDS = [f'i{n:04d}' for n in range(448, 480)]
SEL = ['i0447', *IDS, 'i0480']
FULL = [f'i{n:04d}' for n in range(22, 415)] + [f'i{n:04d}' for n in range(425, 772)]
EXPECTED_DE_CHANGED = ['i0449', 'i0453', 'i0454', 'i0455', 'i0458', 'i0463', 'i0469', 'i0471', 'i0472', 'i0474', 'i0475', 'i0478']
EXPECTED_EN_CHANGED = [*EXPECTED_DE_CHANGED, 'i0479']
RENDER_DE = ['i0453', 'i0454', 'i0455', 'i0458', 'i0474', 'i0475']
RENDER_EN = ['i0453', 'i0454', 'i0455', 'i0458', 'i0469', 'i0474', 'i0475', 'i0479']

COR = {
    'i0453': {
        'confirmed_defect_count': 4,
        'mathematical_reconstruction_count': 4,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Restored four source-printed upper summation labels omitted from both canonical languages: partial/a in the two sums defining N and partial in each of equations (13) and (14).',
    },
    'i0454': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Restored the source-printed upper partial label on the second summation in equation (2) in both canonical languages.',
    },
    'i0455': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 2,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Reconstructed the source summation topology in both languages: moved the lower condition partial-prime>a-prime from the outer delta sum to the inner partial-prime sum in (3), and restored the upper partial label on the outer sum in (4).',
    },
    'i0458': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Corrected the class-equation function subscript from F_k(u,u) to the source-printed F_n(u,u) in both canonical languages.',
    },
    'i0469': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Corrected the English phrase “each two consecutive terms” to “each pair of consecutive terms.”',
    },
    'i0474': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 2,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Corrected two propagated Fraktur field-symbol misreadings from R to the source-defined K in both canonical languages.',
    },
    'i0475': {
        'confirmed_defect_count': 3,
        'mathematical_reconstruction_count': 3,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Corrected three further propagated Fraktur field-symbol misreadings from R to the source-defined K in both canonical languages.',
    },
    'i0479': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Repaired the English double-at construction without changing meaning: the passage “must occur at least once in the chain.”',
    },
}

ANO = [
    {'id': 'i0449', 'detail': 'The source says the sign of eta determines x-prime even though eta=0 and x-prime=plus-or-minus y/2; the sign of xi is mathematically operative. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0452', 'detail': 'The source prints the singular verb “bedeutete” with the plural subject a, partial. Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0453', 'detail': 'The source cites the right-hand side of (1), although the preceding sentence and displayed factor show that equation (12) is intended. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0454', 'detail': 'The source prints “Klassenvarianten” where the established mathematical term is “Klasseninvarianten.” The German body remains source-faithful and both languages are annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0456', 'detail': 'The source prints y=delta y-prime, n=delta x-prime, where x is mathematically expected in the second relation. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0459', 'detail': 'The source inconsistently prints one-quarter(b1 squared+m) and one-half(b2 squared+m) in the paired divisibility statement. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0460', 'detail': 'The source omits the expected subscript 1 on the final a in the displayed composition result. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0463', 'detail': 'The source prints y=+1 and =-1, omitting y before the second equality. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0469', 'detail': 'The source cites sequence (7), while the sequence used is numbered (10) on the preceding page. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0470', 'detail': 'The source prints the grammatically anomalous dative phrase “der Kongruenz” where “die Kongruenz” is expected. Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0470', 'detail': 'The source cites equation (16), but no antecedent equation (16) occurs in the section at this point. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0471', 'detail': 'The source cites equation (18), but no antecedent equation (18) occurs in the section at this point. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0472', 'detail': 'The source writes k=j(omega), although the introduced class-invariant notation is (k)=j(omega). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0472', 'detail': 'The source cites (21) as a forward reference in a passage whose displayed equations are currently numbered (16)-(17). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0473', 'detail': 'The source again prints “Klassenvarianten,” while the mathematical context requires class invariants. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0476', 'detail': 'The source mixes parenthesized class invariants with bare k in the following displays. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0477', 'detail': 'The source cites (17) for a left-hand side with two factors; only equation (16) has that topology. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0477', 'detail': 'The source says the substitution follows from (14), while the described substitution applies to equation (17). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0477', 'detail': 'The source cites congruences (19) and (20) with their logical roles apparently interchanged. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0478', 'detail': 'The source says “by (7),” although the inference rests on the immediately preceding congruences (19)-(20). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0479', 'detail': 'The source prints “und Körper Omega” rather than the grammatically and mathematically expected “im Körper Omega.” Retained and annotated.', 'mathematical_or_cross_reference': False},
]


def sh(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def ident(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sh(path)}


def wr(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def root(ids):
    h = hashlib.sha256()
    for leaf in ids:
        for lang, base in [('de', D), ('en', E)]:
            h.update(f'{lang}:{leaf}:'.encode())
            h.update((base / f'b3_{leaf}.tex').read_bytes())
            h.update(b'\n')
    return h.hexdigest().upper()


def run(args):
    proc = subprocess.run(args, cwd=W, text=True, encoding='utf-8', errors='replace', capture_output=True)
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def main():
    pre = json.loads(P.read_text(encoding='utf-8'))
    prior = {record['id']: record for record in pre['records']}
    assert list(prior) == SEL

    post = {}
    de_changed = []
    en_changed = []
    for leaf in SEL:
        post[leaf] = {
            'german': ident(D / f'b3_{leaf}.tex'),
            'english': ident(E / f'b3_{leaf}.tex'),
        }
        if post[leaf]['german']['sha256'] != prior[leaf]['german']['sha256']:
            de_changed.append(leaf)
        if post[leaf]['english']['sha256'] != prior[leaf]['english']['sha256']:
            en_changed.append(leaf)
    assert de_changed == EXPECTED_DE_CHANGED, de_changed
    assert en_changed == EXPECTED_EN_CHANGED, en_changed
    assert all(post[leaf][lang] == prior[leaf][lang] for leaf in ['i0447', 'i0480'] for lang in ['german', 'english'])

    pre_selected = pre['selected_root_sha256']
    pre_full = pre['full_root_sha256']
    post_selected = root(SEL)
    post_full = root(FULL)
    assert sh(S) == '25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387'

    scans = [EV / f'source_scan_page-{page}.png' for page in range(448, 482)]
    assert len(scans) == 34 and all(path.stat().st_size for path in scans)
    extracted = EV / 'source_scan_pages_448_481_extracted.txt'
    assert extracted.stat().st_size
    support = sorted([*EV.glob('crop*.png'), *EV.glob('source_contact_*.jpg')])
    assert len(support) >= 10 and all(path.stat().st_size for path in support)

    de_master = EV / 'changed_leaf_qa_de.tex'
    en_master = EV / 'changed_leaf_qa_en.tex'
    de_pdf = EV / 'changed_leaf_qa_de.pdf'
    en_pdf = EV / 'changed_leaf_qa_en.pdf'
    de_log = EV / 'changed_leaf_qa_de.log'
    en_log = EV / 'changed_leaf_qa_en.log'
    assert len(fitz.open(de_pdf)) == 6 and len(fitz.open(en_pdf)) == 8
    assert re.findall(r'b3_(i\d{4})\.tex', de_master.read_text(encoding='utf-8')) == RENDER_DE
    assert re.findall(r'b3_(i\d{4})\.tex', en_master.read_text(encoding='utf-8')) == RENDER_EN
    fatal_pattern = r'LaTeX Error|Undefined control sequence|Emergency stop|Fatal error|Overfull \\hbox|Overfull \\vbox|Underfull \\hbox|Underfull \\vbox'
    for log in [de_log, en_log]:
        assert not re.search(fatal_pattern, log.read_text(encoding='utf-8', errors='replace'), re.I)
    de_renders = sorted(EV.glob('final_qa_de_page-*.png'))
    en_renders = sorted(EV.glob('final_qa_en_page-*.png'))
    assert len(de_renders) == 6 and len(en_renders) == 8

    gate_formula, output_formula = run(['python', 'check_en.py', 'b3'])
    gate_structure, output_structure = run(['python', '_audit_printed_coverage.py', 'b3'])
    assert gate_formula == 0 and '740 pass, 0 fail, 3457 audit queries raised' in output_formula
    assert gate_structure == 0 and '750 fragments | printed range 1-733 | 43 unnumbered leaves' in output_structure
    for leaf in IDS:
        for path in [D / f'b3_{leaf}.tex', E / f'b3_{leaf}.tex']:
            text = path.read_text(encoding='utf-8')
            assert not re.search(r'\?\?|\b(?:TODO|TBD|PENDING|PLACEHOLDER|FIXME|UNCERTAIN|HOLD)\b', text)
    assert sum((D / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 21
    assert sum((E / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 21

    for base in [D, E]:
        assert r'\sum_{\partial > a}^{\partial}' in (base / 'b3_i0453.tex').read_text(encoding='utf-8')
        assert r'\sum_{\partial < a}^{a}' in (base / 'b3_i0453.tex').read_text(encoding='utf-8')
        assert r'2\sum^{\partial} \frac{\partial}{e}' in (base / 'b3_i0454.tex').read_text(encoding='utf-8')
        assert r"\sum^{\delta}\sum_{\partial' > a'}^{\partial'}" in (base / 'b3_i0455.tex').read_text(encoding='utf-8')
        assert r'\sum_{\partial>a}^{\partial}' in (base / 'b3_i0455.tex').read_text(encoding='utf-8')
        assert '$F_n(u,u)$ contains' in (E / 'b3_i0458.tex').read_text(encoding='utf-8') if base == E else '$F_n(u,u)$ die beiden' in (D / 'b3_i0458.tex').read_text(encoding='utf-8')
        assert (base / 'b3_i0474.tex').read_text(encoding='utf-8').count(r'\mathfrak{K}') == 2
        assert (base / 'b3_i0475.tex').read_text(encoding='utf-8').count(r'\mathfrak{K}') == 3
    assert 'each pair of consecutive' in (E / 'b3_i0469.tex').read_text(encoding='utf-8')
    assert 'must occur at least once in the chain (22)' in (E / 'b3_i0479.tex').read_text(encoding='utf-8')

    now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    attestation = {
        'schema': 'weber-changed-leaf-final-qa/v1',
        'status': 'PASS',
        'completed_at_utc': now,
        'volume': 'III',
        'chunk': 'CHUNK_0014_i0448_i0479',
        'visual_inspection': {
            'method': 'All fourteen rendering-changing proof pages were compiled, rendered with Poppler at 300 dpi after the final edits, and visually inspected page by page for clipping, overlap, glyph loss, malformed formulae, and unintended layout change.',
            'german_pages_reviewed': 6,
            'english_pages_reviewed': 8,
            'total_pages_reviewed': 14,
            'visual_defects': 0,
        },
        'source_symbol_review': {
            'status': 'PASS',
            'assigned_scan_pages_reviewed': 32,
            'boundary_scan_pages_reviewed': 2,
            'total_scan_pages_reviewed': 34,
            'source_scan_page_range_one_based': [448, 481],
        },
        'formula_gate': {'status': 'PASS', 'output': output_formula},
        'structural_gate': {'status': 'PASS_WITH_REGISTERED_TOPOLOGY', 'output': output_structure},
        'placeholder_gate': {'status': 'PASS', 'assigned_files_scanned': 64, 'marker_hits': 0},
        'german': {
            'rendering_changed_ids': RENDER_DE,
            'master': ident(de_master),
            'pdf': {**ident(de_pdf), 'pages': 6},
            'log': ident(de_log),
            'renders': [ident(path) for path in de_renders],
        },
        'english': {
            'rendering_changed_ids': RENDER_EN,
            'master': ident(en_master),
            'pdf': {**ident(en_pdf), 'pages': 8},
            'log': ident(en_log),
            'renders': [ident(path) for path in en_renders],
        },
        'unresolved': 0,
    }
    wr(A, attestation)

    corrections = {leaf: {'id': leaf, **value} for leaf, value in COR.items()}
    anomalies_by_leaf = {}
    for anomaly in ANO:
        anomalies_by_leaf.setdefault(anomaly['id'], []).append(anomaly)
    sic_only = set(anomalies_by_leaf) - set(COR)
    status = {leaf: ('FIXED' if leaf in COR else 'SOURCE_ORIGINAL_SIC' if leaf in sic_only else 'PASS') for leaf in IDS}
    assert Counter(status.values()) == Counter({'SOURCE_ORIGINAL_SIC': 13, 'PASS': 11, 'FIXED': 8})
    assert sum(item['confirmed_defect_count'] for item in COR.values()) == 15
    assert sum(item['mathematical_reconstruction_count'] for item in COR.values()) == 13
    assert len(ANO) == 21
    assert sum(item['mathematical_or_cross_reference'] for item in ANO) == 18

    records = [
        {
            'id': leaf,
            'source_pdf_page': int(leaf[1:]) + 1,
            'source_inspection': 'COMPLETE_SYMBOL_FORMULA_TRANSLATION_SEMANTIC',
            'german': post[leaf]['german'],
            'english': post[leaf]['english'],
            'status': status[leaf],
            'correction': corrections.get(leaf),
            'source_original_anomalies': anomalies_by_leaf.get(leaf, []),
            'disposition': 'Terminally adjudicated against the registered scan; all source-original anomalies are annotated and no unresolved reconstruction or translation defect remains.',
            'unresolved': 0,
        }
        for leaf in IDS
    ]
    order = ['i0447', *IDS, 'i0480']
    joins = [
        {
            'from': left,
            'to': right,
            'status': 'PASS',
            'detail': f'The registered scan and both canonical languages were checked across the {left} to {right} join for sentence continuation, display topology, headings, page order, and omitted or duplicated symbols; the boundary is terminally complete.',
        }
        for left, right in zip(order, order[1:])
    ]
    assert len(joins) == 33

    counts = {
        'assigned_leaves': 32,
        'terminal_leaves': 32,
        'fixed_leaves': 8,
        'source_original_sic_only_leaves': 13,
        'pass_leaves': 11,
        'changed_canonical_files': 25,
        'changed_unique_leaves': 13,
        'rendering_changed_files': 14,
        'rendering_changed_unique_leaves': 8,
        'confirmed_defects_fixed': 15,
        'mathematical_reconstruction_defects_fixed': 13,
        'mathematical_or_technical_semantic_defects_fixed': 0,
        'prose_grammar_or_number_defects_fixed': 2,
        'source_original_anomalies': 21,
        'mathematical_or_cross_reference_source_anomalies': 18,
        'joins_checked': 33,
        'unresolved': 0,
    }
    receipt = {
        'schema': 'weber-full-editorial-chunk/v1',
        'status': 'TERMINAL_PASS',
        'completed_at_utc': now,
        'volume': 'III',
        'chunk': 'CHUNK_0014_i0448_i0479',
        'scope': {
            'inbound_read_only': 'i0447',
            'assigned_canonical_sequence': IDS,
            'assigned_first': 'i0448',
            'assigned_last': 'i0479',
            'outbound_read_only': 'i0480',
            'assigned_leaf_count': 32,
        },
        'source': ident(S),
        'pre_manifest': ident(P),
        'live_root_hashes': {
            'pre_selected_root_sha256': pre_selected,
            'post_selected_root_sha256': post_selected,
            'pre_full_root_sha256': pre_full,
            'post_full_root_sha256': post_full,
            'pre': {'selected': pre_selected, 'full': pre_full},
            'post': {'selected': post_selected, 'full': post_full},
        },
        'canonical_leaf_changed': sorted(set(de_changed + en_changed)),
        'canonical_file_changed': {'german': de_changed, 'english': en_changed, 'total': 25},
        'rendering_changed': {'german': RENDER_DE, 'english': RENDER_EN, 'total_files': 14, 'unique_leaves': 8},
        'source_evidence': {
            'pdf_pages_inspected': list(range(448, 482)),
            'assigned_pdf_pages': list(range(449, 481)),
            'mapping': 'canonical iNNNN maps to registered PDF page NNNN+1; inbound i0447 and outbound i0480 were read for join continuity',
            'render_inventory': [ident(path) for path in scans],
            'extracted_text': ident(extracted),
            'supporting_crops_and_contact_sheets': [ident(path) for path in support],
        },
        'records': records,
        'joins': joins,
        'correction_inventory': list(corrections.values()),
        'source_original_anomalies': ANO,
        'counts': counts,
        'boundary_post': {'i0447': post['i0447'], 'i0480': post['i0480']},
        'qa_attestation': ident(A),
        'checker': {'status': 'PASS', 'output': output_formula},
        'structural_validator': {'status': 'PASS_WITH_REGISTERED_TOPOLOGY', 'output': output_structure},
        'outbound_candidates': [],
        'unresolved': 0,
    }
    wr(R, receipt)

    cursor = json.loads(C.read_text(encoding='utf-8'))
    assert cursor['last_terminal_leaf'] == 'i0447' and cursor['next_leaf'] == 'i0448'
    assert cursor['terminal_leaf_count'] == 416 and cursor['unresolved'] == 0
    cursor.update({
        'last_terminal_leaf': 'i0479',
        'next_leaf': 'i0480',
        'active_chunk': 'CHUNK_0015_i0480_i0511',
        'terminal_leaves': 448,
        'confirmed_defects': 243,
        'fixed_defects': 243,
        'source_original_anomalies': 163,
        'source_original_mathematical_or_cross_reference_anomalies': 136,
        'changed_leaves': 184,
        'terminal_leaf_count': 448,
        'cumulative_confirmed_defects_fixed': 243,
        'cumulative_source_original_anomalies': 163,
        'cumulative_mathematical_or_cross_reference_source_anomalies': 136,
        'cumulative_changed_leaves': 184,
        'unresolved': 0,
        'updated_at_utc': now,
    })
    cursor.setdefault('terminal_receipts', []).append(ident(R))
    wr(C, cursor)

    # Independent re-read after the cursor write.
    reread_receipt = json.loads(R.read_text(encoding='utf-8'))
    reread_cursor = json.loads(C.read_text(encoding='utf-8'))
    assert reread_receipt['status'] == 'TERMINAL_PASS' and len(reread_receipt['records']) == 32 and len(reread_receipt['joins']) == 33
    assert reread_receipt['counts'] == counts and reread_receipt['unresolved'] == 0
    assert reread_cursor['last_terminal_leaf'] == 'i0479' and reread_cursor['next_leaf'] == 'i0480'
    assert reread_cursor['terminal_leaf_count'] == 448 and reread_cursor['unresolved'] == 0
    assert root(SEL) == post_selected and root(FULL) == post_full
    verification = {
        'schema': 'weber-independent-chunk-verification/v1',
        'status': 'PASS',
        'verified_at_utc': now,
        'chunk': reread_receipt['chunk'],
        'receipt': ident(R),
        'attestation': ident(A),
        'cursor': ident(C),
        'pre_manifest': ident(P),
        'source': ident(S),
        'formula_gate': output_formula,
        'structural_gate': output_structure,
        'verified_changed_german': de_changed,
        'verified_changed_english': en_changed,
        'verified_rendering_changed_german': RENDER_DE,
        'verified_rendering_changed_english': RENDER_EN,
        'verified_canonical_leaf_changed': reread_receipt['canonical_leaf_changed'],
        'verified_boundaries_unchanged': ['i0447', 'i0480'],
        'verified_joins': 33,
        'verified_terminal_records': 32,
        'verified_correction_count': 15,
        'verified_source_anomaly_count': 21,
        'verified_mathematical_or_cross_reference_source_anomaly_count': 18,
        'verified_visual_pages': 14,
        'verified_unresolved': 0,
        'post_selected_root_sha256': post_selected,
        'post_full_root_sha256': post_full,
    }
    wr(O, verification)
    print(json.dumps({
        'status': 'PASS',
        'receipt': ident(R),
        'attestation': ident(A),
        'verification': ident(O),
        'cursor': ident(C),
        'counts': counts,
        'roots': {
            'pre_selected': pre_selected,
            'post_selected': post_selected,
            'pre_full': pre_full,
            'post_full': post_full,
        },
    }, indent=2))


if __name__ == '__main__':
    main()
