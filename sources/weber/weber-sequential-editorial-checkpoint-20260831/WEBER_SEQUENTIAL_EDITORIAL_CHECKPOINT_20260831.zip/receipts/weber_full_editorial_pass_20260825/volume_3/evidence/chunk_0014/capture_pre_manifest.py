import hashlib,json
from pathlib import Path
W=Path(r'local-environment/Documents\weber_restart_20260819\work');D=W/'swarm_tex'/'b3';E=W/'swarm_en'/'b3';EV=W/'receipts'/'weber_full_editorial_pass_20260825'/'volume_3'/'evidence'/'chunk_0014';IDS=[f'i{n:04d}' for n in range(448,480)];SEL=['i0447',*IDS,'i0480'];FULL=[f'i{n:04d}' for n in range(22,415)]+[f'i{n:04d}' for n in range(425,772)]
def sh(p):return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def ident(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sh(p)}
def root(ids):
 h=hashlib.sha256()
 for x in ids:
  for l,b in [('de',D),('en',E)]:h.update(f'{l}:{x}:'.encode());h.update((b/f'b3_{x}.tex').read_bytes());h.update(b'\n')
 return h.hexdigest().upper()
o={'schema':'weber-canonical-pre-manifest/v1','scope':{'inbound':'i0447','assigned':IDS,'outbound':'i0480'},'records':[{'id':x,'german':ident(D/f'b3_{x}.tex'),'english':ident(E/f'b3_{x}.tex')} for x in SEL],'selected_root_sha256':root(SEL),'full_root_sha256':root(FULL)};EV.mkdir(parents=True,exist_ok=True);p=EV/'canonical_pre_manifest.json';p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps({**ident(p),'selected':o['selected_root_sha256'],'full':o['full_root_sha256']},indent=2))
