from pathlib import Path
import json
import fitz
from PIL import Image

base = Path(__file__).resolve().parent
for lang in ('de', 'en'):
    pdf = fitz.open(base / f'partial_i0568_i0575_{lang}.pdf')
    print(lang, len(pdf), [len(p.get_text()) for p in pdf])
    p = pdf[-1]
    print(json.dumps([(b[:4], b[4][:100]) for b in p.get_text('blocks') if b[1] > 650]))
    im = Image.open(base / f'partial_i0568_i0575_{lang}_page-8.png')
    im.crop((0, im.height-900, im.width, im.height)).save(base / f'partial_i0568_i0575_{lang}_page8_footer.png')
im = Image.open(base / 'source_scan_page-573.png')
im.crop((100, 100, 800, 390)).resize((1400, 580)).save(base / 'partial_source573_exponent_detail.png')
