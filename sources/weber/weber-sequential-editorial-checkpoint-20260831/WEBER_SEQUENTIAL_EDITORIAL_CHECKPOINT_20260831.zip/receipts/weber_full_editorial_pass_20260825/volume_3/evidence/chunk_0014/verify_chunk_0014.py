import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import fitz

W = Path(r'local-environment/Documents\weber_restart_20260819\work')
D = W / 'swarm_tex' / 'b3'
E = W / 'swarm_en' / 'b3'
V = W / 'receipts' / 'weber_full_editorial_pass_20260825' / 'volume_3'
EV = V / 'evidence' / 'chunk_0014'
R = V / 'chunks' / 'CHUNK_0014_i0448_i0479.json'
A = EV / 'FINAL_QA_ATTESTATION.json'
C = V / 'CURSOR.json'
P = EV / 'canonical_pre_manifest.json'
O = EV / 'INDEPENDENT_FINAL_VERIFICATION.json'
S = Path(r'registered-source/Weber_Algebra_Bd3.pdf')

IDS = [f'i{n:04d}' for n in range(448, 480)]
SEL = ['i0447', *IDS, 'i0480']
FULL = [f'i{n:04d}' for n in range(22, 415)] + [f'i{n:04d}' for n in range(425, 772)]
DE_CHANGED = ['i0449', 'i0453', 'i0454', 'i0455', 'i0458', 'i0463', 'i0469', 'i0471', 'i0472', 'i0474', 'i0475', 'i0478']
EN_CHANGED = [*DE_CHANGED, 'i0479']
RENDER_DE = ['i0453', 'i0454', 'i0455', 'i0458', 'i0474', 'i0475']
RENDER_EN = ['i0453', 'i0454', 'i0455', 'i0458', 'i0469', 'i0474', 'i0475', 'i0479']


def sh(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def ident(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sh(path)}


def root(ids):
    h = hashlib.sha256()
    for leaf in ids:
        for lang, base in [('de', D), ('en', E)]:
            h.update(f'{lang}:{leaf}:'.encode())
            h.update((base / f'b3_{leaf}.tex').read_bytes())
            h.update(b'\n')
    return h.hexdigest().upper()


def run(args):
    proc = subprocess.run(args, cwd=W, text=True, encoding='utf-8', errors='replace', capture_output=True)
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def main():
    receipt = json.loads(R.read_text(encoding='utf-8'))
    attestation = json.loads(A.read_text(encoding='utf-8'))
    cursor = json.loads(C.read_text(encoding='utf-8'))
    pre = json.loads(P.read_text(encoding='utf-8'))
    prior = {record['id']: record for record in pre['records']}

    assert receipt['status'] == 'TERMINAL_PASS' and receipt['unresolved'] == 0
    assert receipt['chunk'] == 'CHUNK_0014_i0448_i0479'
    assert len(receipt['records']) == 32 and len(receipt['joins']) == 33
    assert all(record['unresolved'] == 0 for record in receipt['records'])
    assert receipt['counts'] == {
        'assigned_leaves': 32,
        'terminal_leaves': 32,
        'fixed_leaves': 8,
        'source_original_sic_only_leaves': 13,
        'pass_leaves': 11,
        'changed_canonical_files': 25,
        'changed_unique_leaves': 13,
        'rendering_changed_files': 14,
        'rendering_changed_unique_leaves': 8,
        'confirmed_defects_fixed': 15,
        'mathematical_reconstruction_defects_fixed': 13,
        'mathematical_or_technical_semantic_defects_fixed': 0,
        'prose_grammar_or_number_defects_fixed': 2,
        'source_original_anomalies': 21,
        'mathematical_or_cross_reference_source_anomalies': 18,
        'joins_checked': 33,
        'unresolved': 0,
    }
    assert len(receipt['source_original_anomalies']) == 21
    assert sum(item['mathematical_or_cross_reference'] for item in receipt['source_original_anomalies']) == 18
    assert sum(item['confirmed_defect_count'] for item in receipt['correction_inventory']) == 15

    de_changed = []
    en_changed = []
    for leaf in SEL:
        if sh(D / f'b3_{leaf}.tex') != prior[leaf]['german']['sha256']:
            de_changed.append(leaf)
        if sh(E / f'b3_{leaf}.tex') != prior[leaf]['english']['sha256']:
            en_changed.append(leaf)
    assert de_changed == DE_CHANGED
    assert en_changed == EN_CHANGED
    assert receipt['canonical_file_changed'] == {'german': DE_CHANGED, 'english': EN_CHANGED, 'total': 25}
    assert receipt['canonical_leaf_changed'] == sorted(set(DE_CHANGED + EN_CHANGED))
    assert all(sh((D if lang == 'german' else E) / f'b3_{leaf}.tex') == prior[leaf][lang]['sha256'] for leaf in ['i0447', 'i0480'] for lang in ['german', 'english'])
    assert root(SEL) == receipt['live_root_hashes']['post_selected_root_sha256']
    assert root(FULL) == receipt['live_root_hashes']['post_full_root_sha256']
    assert sh(S) == receipt['source']['sha256'] == '25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387'

    assert attestation['status'] == 'PASS' and attestation['unresolved'] == 0
    assert attestation['visual_inspection']['total_pages_reviewed'] == 14
    assert attestation['visual_inspection']['visual_defects'] == 0
    assert ident(A) == receipt['qa_attestation']
    assert len(fitz.open(EV / 'changed_leaf_qa_de.pdf')) == 6
    assert len(fitz.open(EV / 'changed_leaf_qa_en.pdf')) == 8
    assert re.findall(r'b3_(i\d{4})\.tex', (EV / 'changed_leaf_qa_de.tex').read_text(encoding='utf-8')) == RENDER_DE
    assert re.findall(r'b3_(i\d{4})\.tex', (EV / 'changed_leaf_qa_en.tex').read_text(encoding='utf-8')) == RENDER_EN
    assert len(list(EV.glob('final_qa_de_page-*.png'))) == 6
    assert len(list(EV.glob('final_qa_en_page-*.png'))) == 8
    for language in ['german', 'english']:
        section = attestation[language]
        for item in [section['master'], section['pdf'], section['log'], *section['renders']]:
            path = Path(item['path'])
            assert ident(path)['bytes'] == item['bytes'] and ident(path)['sha256'] == item['sha256']

    gate_formula, output_formula = run(['python', 'check_en.py', 'b3'])
    gate_structure, output_structure = run(['python', '_audit_printed_coverage.py', 'b3'])
    assert gate_formula == 0 and '740 pass, 0 fail, 3457 audit queries raised' in output_formula
    assert gate_structure == 0 and '750 fragments | printed range 1-733 | 43 unnumbered leaves' in output_structure
    assert sum((D / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 21
    assert sum((E / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 21
    for base in [D, E]:
        assert r'\sum_{\partial > a}^{\partial}' in (base / 'b3_i0453.tex').read_text(encoding='utf-8')
        assert r'\sum_{\partial < a}^{a}' in (base / 'b3_i0453.tex').read_text(encoding='utf-8')
        assert r'2\sum^{\partial} \frac{\partial}{e}' in (base / 'b3_i0454.tex').read_text(encoding='utf-8')
        assert r"\sum^{\delta}\sum_{\partial' > a'}^{\partial'}" in (base / 'b3_i0455.tex').read_text(encoding='utf-8')
        assert r'\sum_{\partial>a}^{\partial}' in (base / 'b3_i0455.tex').read_text(encoding='utf-8')
        assert (base / 'b3_i0474.tex').read_text(encoding='utf-8').count(r'\mathfrak{K}') == 2
        assert (base / 'b3_i0475.tex').read_text(encoding='utf-8').count(r'\mathfrak{K}') == 3
    assert 'each pair of consecutive' in (E / 'b3_i0469.tex').read_text(encoding='utf-8')
    assert 'must occur at least once in the chain (22)' in (E / 'b3_i0479.tex').read_text(encoding='utf-8')

    assert cursor['last_terminal_leaf'] == 'i0479' and cursor['next_leaf'] == 'i0480'
    assert cursor['active_chunk'] == 'CHUNK_0015_i0480_i0511'
    assert cursor['terminal_leaf_count'] == cursor['terminal_leaves'] == 448
    assert cursor['confirmed_defects'] == cursor['fixed_defects'] == 243
    assert cursor['source_original_anomalies'] == 163
    assert cursor['source_original_mathematical_or_cross_reference_anomalies'] == 136
    assert cursor['changed_leaves'] == 184 and cursor['unresolved'] == 0
    assert cursor['terminal_receipts'][-1] == ident(R)

    now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    verification = {
        'schema': 'weber-independent-chunk-verification/v1',
        'status': 'PASS',
        'verified_at_utc': now,
        'chunk': receipt['chunk'],
        'receipt': ident(R),
        'attestation': ident(A),
        'cursor': ident(C),
        'pre_manifest': ident(P),
        'source': ident(S),
        'formula_gate': output_formula,
        'structural_gate': output_structure,
        'verified_changed_german': de_changed,
        'verified_changed_english': en_changed,
        'verified_rendering_changed_german': RENDER_DE,
        'verified_rendering_changed_english': RENDER_EN,
        'verified_canonical_leaf_changed': receipt['canonical_leaf_changed'],
        'verified_boundaries_unchanged': ['i0447', 'i0480'],
        'verified_joins': 33,
        'verified_terminal_records': 32,
        'verified_correction_count': 15,
        'verified_source_anomaly_count': 21,
        'verified_mathematical_or_cross_reference_source_anomaly_count': 18,
        'verified_visual_pages': 14,
        'verified_unresolved': 0,
        'post_selected_root_sha256': root(SEL),
        'post_full_root_sha256': root(FULL),
    }
    O.write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'verification': ident(O), 'receipt': ident(R), 'attestation': ident(A), 'cursor': ident(C)}, indent=2))


if __name__ == '__main__':
    main()
