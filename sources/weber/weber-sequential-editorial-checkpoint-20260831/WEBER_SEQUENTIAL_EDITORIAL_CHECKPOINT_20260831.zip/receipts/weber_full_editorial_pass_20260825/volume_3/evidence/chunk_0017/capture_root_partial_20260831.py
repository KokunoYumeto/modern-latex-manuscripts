from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
EVIDENCE = WORK / "receipts/weber_full_editorial_pass_20260825/volume_3/evidence/chunk_0017"
SOURCE = Path(r"registered-source/Weber_Algebra_Bd3.pdf")


def identity(path: Path) -> dict:
    return {
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest().upper(),
    }


fixes = [
    {"leaf": "i0544", "groups": 1, "languages": ["DE", "EN"], "detail": "Replaced the later standalone footnote call with detached footnote text, retaining the sole manual source anchor near the top of the leaf."},
    {"leaf": "i0547", "groups": 1, "languages": ["DE", "EN"], "detail": "Restored the source paragraph before Zerlegt man / If one decomposes."},
    {"leaf": "i0549", "groups": 1, "languages": ["EN"], "detail": "Restored the final sentence period after the square-root display."},
    {"leaf": "i0550", "groups": 1, "languages": ["DE", "EN"], "detail": "Restored the source paragraph after equation (19)."},
    {"leaf": "i0553", "groups": 1, "languages": ["DE", "EN"], "detail": "Restored the source's one aligned four-row factor/value block from four independent displays."},
    {"leaf": "i0554", "groups": 2, "languages": ["DE", "EN"], "detail": "Restored the aligned two-line chi identity and source thin-space grouping in two long integers."},
    {"leaf": "i0555", "groups": 1, "languages": ["DE", "EN"], "detail": "Removed the literal unmatched main-prose parenthesis after the footnote call; source 1) is footnote-marker styling."},
    {"leaf": "i0557", "groups": 1, "languages": ["DE"], "detail": "Reattached the orphaned full stop to zusammenfassen."},
    {"leaf": "i0558", "groups": 1, "languages": ["DE", "EN"], "detail": "Replaced the Fig.2 textual placeholder with the exact registered-source figure crop; corrected the retained source-description comment so fixed-u strips extend from v=u toward v=infinity."},
    {"leaf": "i0559", "groups": 2, "languages": ["DE", "EN"], "detail": "Restored the source comma after the first integral display in both languages; reattached the German comma after ausfuehren."},
    {"leaf": "i0560", "groups": 3, "languages": ["DE", "EN"], "detail": "Restored two source paragraph starts and moved the equation-(17) comma out of the Q subscript."},
    {"leaf": "i0562", "groups": 2, "languages": ["DE", "EN"], "detail": "Restored the source paragraph starts before the substitution into (19) and before the limit formula."},
    {"leaf": "i0564", "groups": 1, "languages": ["DE", "EN"], "detail": "Restored the narrower indented definition block around the letterspaced complete-system-of-roots definition."},
    {"leaf": "i0565", "groups": 2, "languages": ["DE", "EN"], "detail": "Restored paragraph before Wenn wir / If therefore and the aligned B/A definition pair."},
    {"leaf": "i0566", "groups": 4, "languages": ["DE", "EN"], "detail": "Restored two source theorem paragraphs; corrected English classes-by-which-primes-are-representable meaning; removed duplicated English set at the inbound join."},
    {"leaf": "i0567", "groups": 1, "languages": ["DE", "EN"], "detail": "Restored the displayed pair of f-values that had been flattened into running prose."},
]

new_source_anomalies = [
    {"leaf": "i0544", "detail": "Equation (5) prints coefficient 2i although the following square expands with 4i."},
    {"leaf": "i0546", "detail": "Four Psi arguments print n although equation (12) and H(u) require u."},
    {"leaf": "i0546", "detail": "Final exception prints m'' congruent to 1 although the preceding argument indicates 3."},
    {"leaf": "i0547", "detail": "The case display repeats sqrt(m'') in both rows; preserve printed radicands."},
    {"leaf": "i0549", "detail": "Opening cross-reference prints (16) for the remaining cases while the preceding table is (17)."},
    {"leaf": "i0557", "detail": "Equation (6) prints bare M instead of M_s."},
    {"leaf": "i0558", "detail": "Equation (8) prints denominator A_s instead of A^s."},
]

source_identity = identity(SOURCE)
assert source_identity["sha256"] == "25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387"

data = {
    "schema": "weber-editorial-partial-checkpoint/v1",
    "status": "IN_PROGRESS_NOT_TERMINAL",
    "captured_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "scope": "Volume III chunk0017; root owns i0544-i0567, separate bounded worker owns i0568-i0575.",
    "source": source_identity,
    "preaudit_manifest": identity(EVIDENCE / "canonical_pre_manifest.json"),
    "applied_correction_inventory": fixes,
    "applied_correction_groups": sum(row["groups"] for row in fixes),
    "new_source_original_annotations": new_source_anomalies,
    "retracted_candidate": "The alleged ungrammatical i0566 parenthesis was independently disproved: die is governed by durch. False source-SIC comments were removed; the English reversed relation was corrected instead.",
    "source_review_state": "Root inspected source contacts544-559 and individual source546/547/548/556; independent read-only audit is checking all source545-568 and every current DE/EN leaf. Do not treat this partial checkpoint as terminal source coverage.",
    "historical_queries_considered": [f"i{n:04d}" for n in range(544, 568)],
    "canonical_current": [identity(WORK / lane / "b3" / f"b3_i{n:04d}.tex") for lane in ("swarm_tex", "swarm_en") for n in range(544, 568)],
    "pending": [
        "Complete independent source audit of i0544-i0567 and resolve every remaining candidate.",
        "Receive and verify the independent i0568-i0575 subaudit and its inbound/outbound joins.",
        "Build and render all changed DE/EN leaves; inspect every changed proof page and all structural transitions.",
        "Run formula/topology/placeholder checks, write full32-leaf receipt and independent seal, then advance volume3 cursor exactly once.",
        "Reconcile terminal chunk into the root master ledger and include it in the next verified additive public checkpoint.",
    ],
}

output = EVIDENCE / "ROOT_PARTIAL_AUDIT_20260831.json"
output.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({"status": data["status"], "checkpoint": identity(output), "applied_groups": data["applied_correction_groups"]}, indent=2))
