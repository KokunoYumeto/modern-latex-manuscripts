"""Seal only the assigned final eight leaves; never advances shared cursors."""
from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import re
import subprocess
import sys
import fitz
from PIL import Image

BASE = Path(__file__).resolve().parent
WORK = BASE.parents[4]
SOURCE = Path(r'registered-source/Weber_Algebra_Bd3.pdf')
EXPECTED_SOURCE = '25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387'
sys.path.insert(0, str(WORK))
import check_en

def ident(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda: f.read(1024 * 1024), b''):
            h.update(part)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': h.hexdigest().upper()}

def cpath(n, lang):
    return WORK / ('swarm_tex' if lang == 'german' else 'swarm_en') / 'b3' / f'b3_i{n:04d}.tex'

def correction(code, kind, detail, languages=('german','english'), instances=1):
    return {'id': code, 'category': kind, 'detail': detail, 'languages': list(languages), 'source_occurrences': instances, 'status': 'FIXED_SOURCE_BACKED'}

def anomaly(code, detail, rationale, instances=1, category='source_original_mathematical_or_notational_anomaly'):
    return {'id': code, 'category': category, 'printed_reading_and_annotation': detail, 'primary_reason': rationale, 'source_occurrences': instances, 'status': 'PRESERVED_AND_ANNOTATED'}

corrections = {
568: [
    correction('C568-1','table_layout','Restored all five substitution-table columns and German low double-quote ditto marks; every row now aligns its sum, x,y, replacement verb and replacement.'),
    correction('C568-2','math_layout','Placed the x,y indices directly above each Sigma in the three final rows of (12); they were present but incorrectly typeset as right superscripts.',instances=3),
    correction('C568-3','translation_join','Restored the missing English predicate across i0567/i0568: the 24th powers ... are class invariants. The old continuation read only a class invariant.',languages=('english',)),
],
569: [correction('C569-1','math_layout','Placed s=1 beneath the Lim operator in (15), as printed.')],
570: [
    correction('C570-1','math_layout','Placed s=1 beneath both Lim operators in (16).',instances=2),
    correction('C570-2','math_spacing','Restored visible spacing after the multiplication point in the three occurrences of 3. 2^s.',instances=3),
],
571: [
    correction('C571-1','paragraph_boundary','Restored the source paragraph break before Sind also / If therefore.'),
    correction('C571-2','paragraph_boundary','Restored the source paragraph break before Fassen wir / If we summarise.'),
],
572: [
    correction('C572-1','mathematical_semantics','Restored each entire denominator exponent: 2^{1/2-1/2^{lambda+2}} and 2^{1/2-1/(3.2^{lambda+1})}; the prior reconstruction misread each as 1/2^{1/2} minus a separate fraction. The whole subtraction is raised on the scan, not only the leading half.',instances=2),
    correction('C572-2','heading_structure','Restored the single-line bold section143 heading, retaining the source letterspacing of the title.'),
    correction('C572-3','numbered_equation_scope','Put psi0, psi and psi-prime together in the single three-row equation(4), with the number covering the whole definition.'),
],
573: [],
574: [],
575: [correction('C575-1','math_spacing','Restored spacing in the product 3. 5. 7 so its factors are visibly distinct.')],
}
anomalies = {
568: [
    anomaly('A568-1','Printed discriminant -4D retained with a source note.','The inbound construction on source p536 uses -4m; p537 visibly changes its variable to D.'),
    anomaly('A568-2','Printed unprimed S in Die Summe S retained with a source note.','Equations(9),(10) define and decompose S-prime, and all four partial sums are primed.'),
],
569: [],
570: [anomaly('A570-1','Printed sqrt(m) in equation(20) retained; note identifies required sqrt(m-prime).','m=4m-prime and m-prime=AC-B^2 imply the root of (A,2B,C) is (-B+i sqrt(m-prime))/A, not the printed expression.')],
571: [
    anomaly('A571-1','Printed h-prime attached to discriminant -m-prime retained.','Immediately below(23), the same page defines h-prime for discriminant -m.'),
    anomaly('A571-2','Printed numerator 2^h in middle of(23) retained; annotation identifies 2^{h-prime}.','There are h-prime pairs f1(omega1)f2(omega2), each contributing factor2. With f1 f2 f=sqrt2, the last equality requires numerator2^{h-prime}; the page states h=2h-prime.'),
],
572: [
    anomaly('A572-1','Printed residue m-prime congruent4 modulo8 in the second continuation row retained; note gives3.','The immediately preceding cube-root case has base tau-prime=1/3 for residue3; the recurrence on p540 gives exponent1/2-1/(3.2^{lambda+1}).'),
    anomaly('A572-2','Printed second lowercase delta in complementary divisor sentence retained.','The preceding definition is a divisor of Delta, and the immediately following relation is delta delta-prime=Delta.'),
],
573: [anomaly('A573-1','Printed chi(delta,k)/1 retained and identified as a redundant denominator.','The scan visibly has numerator chi, a rule and1. Division by1 changes no algebra; this is a source typographic peculiarity, not a mathematical error.',category='source_original_typographic_peculiarity')],
574: [
    anomaly('A574-1','Printed delta>0 congruent1 and delta<0 congruent5 conditions in(11) retained and annotated as inconsistent.','The unit is selected by the sign of delta, while the nonzero case in(10) is residue5. Positive delta5 and21 in the next example require the first unit branch despite not being residue1.',instances=2),
    anomaly('A574-2','Printed Hauptklasse retained, with note that the exception is the full principal genus.','The same paragraph states characters are constant on a genus; their sum equals g for every class in the principal genus, not solely the principal class.'),
],
575: [anomaly('A575-1','Printed radicands84 and20 in rows2,3 retained; note identifies required5 and21.','The positive discriminants in the displayed pairs are5 and21; source p545 explicitly computes the corresponding logarithms with sqrt5 and sqrt21.',instances=2)],
}

# Query order is exactly the immutable historical JSON order, one-based here.
query_dispositions = {
568: [
    ('ALREADY_RESOLVED','The paragraph3 opening is plain in source and current DE/EN; no invented letterspacing remains.'),
    ('RESOLVED_WITH_FURTHER_CORRECTION','The three x,y summation indices had already been restored, but as right superscripts; C568-2 now restores their printed above-Sigma placement.'),
    ('SOURCE_ORIGINAL_ANNOTATED','Unprimed S is the printed reading; A568-2 records the inconsistent prime.'),
    ('FIXED','C568-1 restores low ditto marks and the five-column alignment.'),
    ('TERMINOLOGY_ACCEPTED','Grenzformel is rendered limit formula, consistently with its use for an s-to1 limiting identity; no missing content.'),
],
569: [
    ('FIXED','C569-1 reproduces the printed below-operator limit condition.'),
    ('DISMISSED_LAYOUT_CONVENTION','Running heads are scan furniture, not body transcription. The source folio is retained in !PRINTED538; the shared reader preamble intentionally makes weberpage a no-op and uses its own footer. No claim that the old running head is reproduced.'),
],
570: [
    ('ALREADY_RESOLVED','The single source word ungerade and English odd are already letterspaced, and adjacent words remain plain.'),
    ('SOURCE_ORIGINAL_ANNOTATED','A570-1 preserves the printed radicand m and states the source-based m-prime correction.'),
    ('TERMINOLOGY_ACCEPTED','Wurzelsystem is system of roots and Klasseninvariante is class invariant; both correctly convey the local class-form meaning without a Lie-theory root-system implication.'),
],
571: [
    ('ALREADY_RESOLVED','algebraische Einheiten / algebraic units already carry exactly the printed emphasis span.'),
    ('FIXED','C571-1 restores the source paragraph before Sind also.'),
    ('FIXED','C571-2 restores the source paragraph before Fassen wir.'),
],
572: [
    ('FIXED_QUERY_DIAGNOSIS_REFINED','C572-1 restores both complete exponent expressions. The historical query correctly detected the fraction misread, but its suggestion 2^{1/2} minus a baseline fraction is incomplete; the scan raises the entire subtraction.'),
    ('FIXED_PARTLY_PREVIOUSLY_RESOLVED','Title letterspacing was already present; C572-2 additionally restores source bold and one-line structure.'),
    ('FIXED','C572-2 rejoins section number and title on the single printed heading line.'),
    ('ALREADY_RESOLVED','ungeraden Stammteiler / odd fundamental divisors are already letterspaced over the correct two-word span.'),
    ('FIXED','C572-3 includes psi0 in the numbered equation(4) group.'),
    ('SOURCE_ORIGINAL_ANNOTATED','A572-2 preserves the printed lowercase delta and explains its Delta complement.'),
    ('RESOLVED_PRINT_OR_SCAN_ARTIFACT','The isolated upright mark after the second f(omega) is an unmatched print/scan mark, not a semantic delimiter: no opening mate occurs and the three parallel numerators are f(omega). The registered scan preserves the mark; no invented mathematical character is added.'),
    ('TERMINOLOGY_ACCEPTED','Partialnormen is partial norms: products over classes of one genus, precisely as the first paragraph defines.'),
    ('TERMINOLOGY_ACCEPTED','Stammdiskriminante / Stammteiler are fundamental discriminant / fundamental divisor; the paired terminology is semantically correct here and no lost distinction follows from other German prefixes sometimes sharing fundamental.'),
    ('TERMINOLOGY_ACCEPTED','Grenzformel remains limit formula, consistent with i0568 and its analytic meaning.'),
],
573: [
    ('SOURCE_PECULIARITY_ANNOTATED_NOT_MATH_ERROR','A573-1 records the faithfully printed denominator1 without asserting it changes the value.'),
    ('ALREADY_RESOLVED_SCAN_ARTIFACT','The faint mark before delta is isolated damage/speck; the existing resolved comment correctly excludes it from the mathematical text. All other delta occurrences and local syntax support this reading.'),
],
574: [
    ('ALREADY_RESOLVED','The first Hauptgeschlechts / principal genus occurrence is letterspaced; later occurrences correctly remain plain.'),
    ('ALREADY_RESOLVED','Pellschen / Pell is already letterspaced over the source name span.'),
    ('TERMINOLOGY_ACCEPTED','Stammteiler remains fundamental divisors, consistent with the p541 definition.'),
],
575: [
    ('ALREADY_RESOLVED','The first Klasseninvarianten / class invariants occurrence has the source emphasis, while the next occurrence remains plain.'),
    ('ALREADY_RESOLVED','The DE footnote already restricts letterspacing to Gauss and leaves schen outside; the second Gauss-prime name remains emphasized.'),
    ('DISMISSED_LAYOUT_CONVENTION','Running head is source furniture; !PRINTED544 records the source folio and the reader uses its own page furniture.'),
    ('FIXED','C575-1 adds explicit thin spacing after the two multiplication points.'),
    ('TERMINOLOGY_ACCEPTED','Klasseninvarianten remains class invariants, correctly describing the objects computed.'),
    ('TERMINOLOGY_ACCEPTED','ohne quadratischen Teiler is without square divisor, correctly conveying the integer-divisor rather than polynomial-degree meaning.'),
],
}
join_descriptions = {
567: 'The incoming list of three quantities completes with whose product=2, are class invariants; C568-3 restores the missing English finite verb. German printed singular Klasseninvariante is source-faithfully retained.',
568: 'Equation(12) completes; the next page opens a new paragraph assuming a odd. No dropped or duplicate material.',
569: 'The final colon And from this there results by(14) leads directly to equation(16); continuation markers and formula ordering agree.',
570: 'The final and we obtain comma continues with when omega runs through ... and the product relation; subject and quantifiers remain intact.',
571: 'The three listed algebraic units continue with the three further cases on p541. C572-1 restores the exponent semantics of this cross-page list.',
572: 'The completed three definitions in(4) lead into classes k,k0,k-prime belonging to those forms. No missing psi0 definition remains.',
573: 'not the / class number itself, but the third part or half completes the exception rule for delta=-3,-4 exactly.',
574: 'The bibliography paragraph closes with a table; p544 begins a new paragraph about63 discriminants. No continuation or repetition is needed.',
575: 'The four-term example is followed on p545 by its class numbers and logarithmic evaluations. Printed radicands84/20 are preserved and annotated against the next page explicit5/21.',
}

receipt_path = BASE / 'PARTIAL_I0568_I0575_AUDIT.json'
assert not receipt_path.exists(), 'Refuse to overwrite a sealed partial receipt'
source_identity = ident(SOURCE)
assert source_identity['sha256'] == EXPECTED_SOURCE
pre_path = BASE / 'canonical_pre_manifest.json'
pre = json.loads(pre_path.read_text(encoding='utf-8'))
pre_records = {r['id']: r for r in pre['records']}
pre_id = ident(pre_path)
post_start = {f'{n}:{lang}': ident(cpath(n,lang)) for n in range(568,576) for lang in ('german','english')}

# The last canonical changes after the completed visual inspection are comments only.
# Rebuild exact live inputs and prove every new raster equals the already inspected raster.
builds = []
for lang in ('de','en'):
    stem = f'partial_i0568_i0575_{lang}'
    raster_before = [ident(BASE / f'{stem}_page-{n}.png') for n in range(1,9)]
    build_run = subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',f'{stem}.tex'],cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert build_run.returncode == 0, build_run.stdout.decode(errors='replace')[-2000:]
    log = (BASE / f'{stem}.log').read_text(encoding='utf-8',errors='replace')
    bad_log = re.findall(r'(?m)^.*(?:Overfull|Underfull|LaTeX Error|Undefined control sequence).*$' ,log)
    assert not bad_log, bad_log
    doc = fitz.open(BASE / f'{stem}.pdf')
    assert len(doc)==8
    assert all(len(p.get_text())>500 for p in doc)
    render_run = subprocess.run(['pdftoppm','-r','300','-png',f'{stem}.pdf',f'{stem}_page'],cwd=BASE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert render_run.returncode == 0, render_run.stdout.decode(errors='replace')
    raster_after = [ident(BASE / f'{stem}_page-{n}.png') for n in range(1,9)]
    assert [r['sha256'] for r in raster_before] == [r['sha256'] for r in raster_after], 'Rendered pixels changed after visual review'
    builds.append({'language':lang,'master':ident(BASE/f'{stem}.tex'),'pdf':ident(BASE/f'{stem}.pdf'),'log':ident(BASE/f'{stem}.log'),'page_count':8,'build_exit_code':0,'render_exit_code':0,'render_dpi':300,'bad_log_findings':[],'all_rasters_byte_identical_to_visually_inspected':True,'rendered_pages':[dict(r,output_page=n,canonical_leaf=f'i{567+n:04d}',visual_status='PASS',checks='No clipping, overlap, broken glyphs, missing mathematics, misplaced limits, table misalignment, paragraph/heading defect or footnote collision.') for n,r in enumerate(raster_after,1)]})

source_doc = fitz.open(SOURCE)
rows = []
for n in range(568,576):
    queries_path = WORK/'translation_queries'/f'b3_i{n:04d}.json'
    queries = json.loads(queries_path.read_text(encoding='utf-8'))['queries']
    assert len(queries)==len(query_dispositions[n])
    problems = check_en.check('b3',n)
    assert not problems, (n,problems)
    source_image = BASE/f'source_scan_page-{n+1}.png'
    im = Image.open(source_image)
    rect = source_doc[n].rect
    dpi = [round(im.width*72/rect.width,2),round(im.height*72/rect.height,2)]
    assert all(abs(v-200)<1 for v in dpi)
    de_text = cpath(n,'german').read_text(encoding='utf-8')
    en_text = cpath(n,'english').read_text(encoding='utf-8')
    assert check_en.printed_of(de_text)==check_en.printed_of(en_text)==str(n-31)
    posts = {lang:ident(cpath(n,lang)) for lang in ('german','english')}
    for lang in posts:
        assert posts[lang]==post_start[f'{n}:{lang}']
    rows.append({'leaf':f'i{n:04d}','printed_page':n-31,'source_pdf_page_one_based':n+1,'source_pdf_index_zero_based':n,'source_image':dict(ident(source_image),width=im.width,height=im.height,measured_dpi=dpi),'source_visual_review':'COMPLETE_SYMBOL_LEVEL','german_status':'PASS_SOURCE_FAITHFUL_AFTER_CORRECTIONS_AND_NOTES','english_status':'PASS_COMPLETE_SOURCE_FAITHFUL_TRANSLATION','pre':pre_records[f'i{n:04d}'],'post':posts,'canonical_leaf_changed':True,'corrections':corrections[n],'source_anomalies':anomalies[n],'historical_queries_file':ident(queries_path),'query_dispositions':[{'query_number_one_based':i,'historical_query':q,'status':d[0],'rationale':d[1],'terminal':True} for i,(q,d) in enumerate(zip(queries,query_dispositions[n]),1)],'checks':{'formula_parity':{'status':'PASS','problems':problems},'printed_page_identity':'PASS','body_prose_and_diacritics':'PASS','displayed_and_inline_symbols':'PASS','equation_labels_and_order':'PASS','emphasis_bounds':'PASS','citations_and_footnotes':'PASS','translation_completeness_and_terms':'PASS'},'unresolved_findings':0})

joins = []
for n,detail in join_descriptions.items():
    joins.append({'left':f'i{n:04d}','right':f'i{n+1:04d}','left_source_page':n+1,'right_source_page':n+2,'status':'PASS','disposition':detail,'context_identities':{f'{side}_{lang}':ident(cpath(idx,lang)) for side,idx in (('left',n),('right',n+1)) for lang in ('german','english')},'outside_assignment_context_only':n in(567,575)})

recurrence = []
for lam in range(1,9):
    general = lambda base: base/Fraction(2**lam)+Fraction(1,2)-Fraction(1,2**(lam+1))
    first = Fraction(1,2)-Fraction(1,2**(lam+2))
    second = Fraction(1,2)-Fraction(1,3*2**(lam+1))
    assert general(Fraction(1,4))==first
    assert general(Fraction(1,3))==second
    assert general(Fraction(1,2))==Fraction(1,2)
    recurrence.append({'lambda':lam,'quarter_base_result':str(first),'third_base_result':str(second),'half_base_result':'1/2'})

receipt = {
    'schema':'weber-b3-chunk17-partial-source-audit/v1',
    'status':'PASS_COMPLETE_WITHIN_ASSIGNED_SCOPE',
    'completed_utc':datetime.now(timezone.utc).isoformat(),
    'scope':{'volume':3,'canonical_leaves':[f'i{n:04d}' for n in range(568,576)],'leaf_count':8,'language_leaf_count':16,'printed_pages':[537,544],'boundary_count':9,'root_retains_full_chunk_seal_and_cursor_ownership':True,'write_scope':'Only b3_i0568.tex through b3_i0575.tex in swarm_tex/b3 and swarm_en/b3 plus this partial evidence prefix. No cursor, master logbook, shared validator, historical queries, publication artifact or premanifest edited.'},
    'source':source_identity,
    'canonical_pre_manifest':pre_id,
    'shared_preamble':ident(WORK/'swarm_preamble.tex'),
    'validator':ident(WORK/'check_en.py'),
    'sealing_script':ident(__file__),
    'source_resolution_correction':'Existing source_scan_page PNGs measure200dpi, not300dpi. Actual200dpi scans were inspected; all new proof rasters are300dpi. Cropped source detail is only enlarged for inspection, not falsely claimed as higher source resolution.',
    'counts':{'new_reconstruction_correction_groups':sum(map(len,corrections.values())),'new_reconstruction_source_occurrences':sum(c['source_occurrences'] for cs in corrections.values() for c in cs),'changed_leaf_pairs':8,'leaf_pairs_with_noncomment_corrections':sum(bool(cs) for cs in corrections.values()),'mathematical_semantics_correction_groups':1,'mathematical_semantics_source_occurrences':2,'translation_join_correction_groups':1,'source_original_anomaly_groups':sum(map(len,anomalies.values())),'source_original_anomaly_occurrences':sum(a['source_occurrences'] for aa in anomalies.values() for a in aa),'historical_queries_terminally_disposed':sum(len(q) for q in query_dispositions.values()),'visual_proof_pages':16,'source_pages_fully_inspected':8,'boundary_context_source_pages_inspected':2,'unresolved_findings':0},
    'leaf_reviews':rows,
    'joins':joins,
    'build_and_visual_qa':builds,
    'additional_visual_details':[ident(BASE/'partial_i0568_i0575_de_page8_footer.png'),ident(BASE/'partial_i0568_i0575_en_page8_footer.png'),ident(BASE/'partial_source573_exponent_detail.png')],
    'mathematical_crosschecks':{'recurrence_symbolic_reason':'tau(lambda)=tau0/2^lambda+1/2-1/2^{lambda+1}; substitution of1/4,1/3,1/2 yields the three printed cases with exponent scope restored.','recurrence_exact_rational_spot_checks':recurrence,'radicands_source_context':'Source p545 explicitly uses5 and21, closing the p544 source misprint diagnosis.'},
    'independent_read_only_subreview':{'scope':['i0572','i0574','i0575'],'context':['i0571','i0573','i0576'],'result':'Confirmed exponent scopes, residue4 as source-original error, complementary-delta error, sign-selection inconsistency, principal-genus exception, and radicands84/20 source errors. No overlooked transcription-symbol defect found in these inspected leaves.','important_rejected_candidate':'Reference(8) on p543 is not proven wrong: weighting(8), then using(7),(9), also gives the genus-product identity. Canonical note is explanatory only, excluded from anomaly counts.','contextual_notation_candidate':'p544 discriminant-convention wording is faithfully translated and not counted as a proven error; no modern normalization inferred.'},
    'root_coordination':'Root independently rejected an i0567 product-sign candidate after original-size review; this worker made no i0567 edits. Root must recompute current boundary identities if its owned adjoining leaf changes before the full32-leaf seal.',
    'historical_query_preservation':'All original query JSON files remain read-only; full historical queries and exact dispositions are retained in this additive receipt.',
    'unresolved_findings':[],
}
assert ident(pre_path)==pre_id
receipt_path.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':ident(receipt_path),'counts':receipt['counts'],'status':receipt['status']},indent=2))
