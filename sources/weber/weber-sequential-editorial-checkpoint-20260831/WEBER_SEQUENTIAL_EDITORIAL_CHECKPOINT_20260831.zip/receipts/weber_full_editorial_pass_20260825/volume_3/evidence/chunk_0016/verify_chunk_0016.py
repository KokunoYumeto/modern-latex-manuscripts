import hashlib
import json
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import fitz

W = Path(r'local-environment/Documents\weber_restart_20260819\work')
D = W / 'swarm_tex' / 'b3'
E = W / 'swarm_en' / 'b3'
Q = W / 'translation_queries'
V = W / 'receipts' / 'weber_full_editorial_pass_20260825' / 'volume_3'
EV = V / 'evidence' / 'chunk_0016'
R = V / 'chunks' / 'CHUNK_0016_i0512_i0543.json'
A = EV / 'FINAL_QA_ATTESTATION.json'
C = V / 'CURSOR.json'
P = EV / 'canonical_pre_manifest.json'
O = EV / 'INDEPENDENT_FINAL_VERIFICATION.json'
S = Path(r'registered-source/Weber_Algebra_Bd3.pdf')

IDS = [f'i{n:04d}' for n in range(512, 544)]
SEL = ['i0511', *IDS, 'i0544']
FULL = [f'i{n:04d}' for n in range(22, 415)] + [f'i{n:04d}' for n in range(425, 772)]
CHANGED = [
    'i0512', 'i0514', 'i0515', 'i0516', 'i0518', 'i0521', 'i0523', 'i0524',
    'i0528', 'i0531', 'i0532', 'i0533', 'i0534', 'i0537', 'i0538', 'i0539',
    'i0541', 'i0542', 'i0543',
]
RENDER_DE = [
    'i0512', 'i0514', 'i0516', 'i0518', 'i0523', 'i0524', 'i0531',
    'i0532', 'i0537', 'i0538', 'i0541', 'i0542', 'i0543',
]
RENDER_EN = [
    'i0512', 'i0514', 'i0516', 'i0518', 'i0523', 'i0524', 'i0531',
    'i0532', 'i0537', 'i0538', 'i0539', 'i0541', 'i0542', 'i0543',
]
EXPECTED_COUNTS = {
    'assigned_leaves': 32,
    'terminal_leaves': 32,
    'fixed_leaves': 16,
    'source_original_sic_only_leaves': 6,
    'pass_leaves': 10,
    'changed_canonical_files': 38,
    'changed_unique_leaves': 19,
    'rendering_changed_files': 27,
    'rendering_changed_unique_leaves': 14,
    'confirmed_defects_fixed': 25,
    'mathematical_reconstruction_defects_fixed': 7,
    'mathematical_or_technical_semantic_defects_fixed': 1,
    'prose_grammar_or_number_defects_fixed': 17,
    'source_original_anomalies': 20,
    'mathematical_or_cross_reference_source_anomalies': 17,
    'historical_query_files_adjudicated': 32,
    'historical_queries_adjudicated': 125,
    'joins_checked': 33,
    'unresolved': 0,
}


def sh(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def ident(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sh(path)}


def root(ids):
    h = hashlib.sha256()
    for leaf in ids:
        for lang, base in [('de', D), ('en', E)]:
            h.update(f'{lang}:{leaf}:'.encode())
            h.update((base / f'b3_{leaf}.tex').read_bytes())
            h.update(b'\n')
    return h.hexdigest().upper()


def run(args):
    proc = subprocess.run(args, cwd=W, text=True, encoding='utf-8', errors='replace', capture_output=True)
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def main():
    receipt = json.loads(R.read_text(encoding='utf-8'))
    attestation = json.loads(A.read_text(encoding='utf-8'))
    cursor = json.loads(C.read_text(encoding='utf-8'))
    pre = json.loads(P.read_text(encoding='utf-8'))
    prior = {record['id']: record for record in pre['records']}

    assert receipt['status'] == 'TERMINAL_PASS' and receipt['unresolved'] == 0
    assert receipt['chunk'] == 'CHUNK_0016_i0512_i0543'
    assert receipt['scope']['assigned_canonical_sequence'] == IDS
    assert len(receipt['records']) == 32 and len(receipt['joins']) == 33
    assert all(record['unresolved'] == 0 for record in receipt['records'])
    assert all(record['historical_query_disposition'] == 'TERMINALLY_ADJUDICATED' for record in receipt['records'])
    assert receipt['counts'] == EXPECTED_COUNTS
    assert len(receipt['source_original_anomalies']) == 20
    assert sum(item['mathematical_or_cross_reference'] for item in receipt['source_original_anomalies']) == 17
    assert sum(item['confirmed_defect_count'] for item in receipt['correction_inventory']) == 25
    assert sum(item['mathematical_reconstruction_count'] for item in receipt['correction_inventory']) == 7
    assert sum(item['mathematical_or_technical_semantic_count'] for item in receipt['correction_inventory']) == 1
    assert sum(item['prose_grammar_or_number_count'] for item in receipt['correction_inventory']) == 17
    assert Counter(record['status'] for record in receipt['records']) == Counter({'FIXED': 16, 'PASS': 10, 'SOURCE_ORIGINAL_SIC': 6})

    de_changed = []
    en_changed = []
    for leaf in SEL:
        if sh(D / f'b3_{leaf}.tex') != prior[leaf]['german']['sha256']:
            de_changed.append(leaf)
        if sh(E / f'b3_{leaf}.tex') != prior[leaf]['english']['sha256']:
            en_changed.append(leaf)
    assert de_changed == CHANGED
    assert en_changed == CHANGED
    assert receipt['canonical_file_changed'] == {'german': CHANGED, 'english': CHANGED, 'total': 38}
    assert receipt['canonical_leaf_changed'] == CHANGED
    assert all(sh((D if lang == 'german' else E) / f'b3_{leaf}.tex') == prior[leaf][lang]['sha256'] for leaf in ['i0511', 'i0544'] for lang in ['german', 'english'])
    assert root(SEL) == receipt['live_root_hashes']['post_selected_root_sha256'] == '2CD484D6E91F344BA23E277787D8312A8C2AB05D16C3961471002FF41EC67AE2'
    assert root(FULL) == receipt['live_root_hashes']['post_full_root_sha256'] == '68D392D3E7731E840559855EEEB141C2C91F4D3CB4B61C2CC65B4A1E08E5A8AF'
    assert receipt['live_root_hashes']['pre_selected_root_sha256'] == '7DAF67BB32127C74FD44FAF7AEE65AA3A6924F0A86A07C0D5894E8F24B501CA0'
    assert receipt['live_root_hashes']['pre_full_root_sha256'] == '69ED8FE8BCD9ECD9EDDC52FD8CD28898CD049E2542C7780920147D6C918A7B61'
    assert sh(S) == receipt['source']['sha256'] == '25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387'

    query_files = [Q / f'b3_i{n:04d}.json' for n in range(512, 544)]
    payloads = [json.loads(path.read_text(encoding='utf-8')) for path in query_files]
    queries = [query for payload in payloads for query in payload['queries']]
    by_confidence = Counter(query['confidence'] for query in queries)
    by_kind = Counter(query['kind'] for query in queries)
    assert len(queries) == 125
    assert by_confidence == Counter({'low': 53, 'high': 38, 'medium': 34})
    assert by_kind == Counter({'transcription': 71, 'term': 19, 'author_error': 12, 'omission': 12, 'unreadable': 9, 'addition': 2})
    query_evidence = receipt['historical_query_evidence']
    assert query_evidence['status'] == 'TERMINALLY_ADJUDICATED' and query_evidence['query_count'] == 125 and query_evidence['unresolved'] == 0
    assert len(query_evidence['files']) == 32
    for recorded, path in zip(query_evidence['files'], query_files):
        assert recorded == ident(path)

    assert attestation['status'] == 'PASS' and attestation['unresolved'] == 0
    assert attestation['visual_inspection']['total_pages_reviewed'] == 27
    assert attestation['visual_inspection']['visual_defects'] == 0
    assert attestation['source_symbol_review']['total_scan_pages_reviewed'] == 34
    assert attestation['historical_query_review']['queries_reviewed'] == 125
    assert ident(A) == receipt['qa_attestation']
    assert len(fitz.open(EV / 'changed_leaf_qa_de.pdf')) == 13
    assert len(fitz.open(EV / 'changed_leaf_qa_en.pdf')) == 14
    assert re.findall(r'b3_(i\d{4})\.tex', (EV / 'changed_leaf_qa_de.tex').read_text(encoding='utf-8')) == RENDER_DE
    assert re.findall(r'b3_(i\d{4})\.tex', (EV / 'changed_leaf_qa_en.tex').read_text(encoding='utf-8')) == RENDER_EN
    assert len(list(EV.glob('final_qa_de_page-*.png'))) == 13
    assert len(list(EV.glob('final_qa_en_page-*.png'))) == 14
    fatal_pattern = r'LaTeX Error|Undefined control sequence|Emergency stop|Fatal error|Overfull \\hbox|Overfull \\vbox|Underfull \\hbox|Underfull \\vbox'
    for log in [EV / 'changed_leaf_qa_de.log', EV / 'changed_leaf_qa_en.log']:
        assert not re.search(fatal_pattern, log.read_text(encoding='utf-8', errors='replace'), re.I)
    for language in ['german', 'english']:
        section = attestation[language]
        for item in [section['master'], section['pdf'], section['log'], *section['renders']]:
            path = Path(item['path'])
            assert ident(path)['bytes'] == item['bytes'] and ident(path)['sha256'] == item['sha256']

    gate_formula, output_formula = run(['python', 'check_en.py', 'b3'])
    gate_structure, output_structure = run(['python', '_audit_printed_coverage.py', 'b3'])
    assert gate_formula == 0 and '740 pass, 0 fail, 3457 audit queries raised' in output_formula
    assert gate_structure == 0 and '750 fragments | printed range 1-733 | 43 unnumbered leaves' in output_structure
    for leaf in IDS:
        for path in [D / f'b3_{leaf}.tex', E / f'b3_{leaf}.tex']:
            text = path.read_text(encoding='utf-8')
            assert not re.search(r'\?\?|\b(?:TODO|TBD|PENDING|PLACEHOLDER|FIXME|UNCERTAIN|HOLD)\b', text)
    assert sum((D / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 20
    assert sum((E / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 20
    assert '(and hence $m$) is even or odd' in (E / 'b3_i0512.tex').read_text(encoding='utf-8')
    assert '\\text{and in}' not in (E / 'b3_i0539.tex').read_text(encoding='utf-8')
    assert 'For $\\beta$ this follows from the assumptions already made.' in (E / 'b3_i0541.tex').read_text(encoding='utf-8')
    assert '\\gesperrt{odd divisor' in (E / 'b3_i0543.tex').read_text(encoding='utf-8')

    assert cursor['last_terminal_leaf'] == 'i0543' and cursor['next_leaf'] == 'i0544'
    assert cursor['active_chunk'] == 'CHUNK_0017_i0544_i0575'
    assert cursor['terminal_leaf_count'] == cursor['terminal_leaves'] == 512
    assert cursor['confirmed_defects'] == cursor['fixed_defects'] == 276
    assert cursor['source_original_anomalies'] == 192
    assert cursor['source_original_mathematical_or_cross_reference_anomalies'] == 159
    assert cursor['changed_leaves'] == 216 and cursor['unresolved'] == 0
    assert cursor['terminal_receipts'][-1] == ident(R)

    now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    verification = {
        'schema': 'weber-independent-chunk-verification/v1',
        'status': 'PASS',
        'verified_at_utc': now,
        'chunk': receipt['chunk'],
        'receipt': ident(R),
        'attestation': ident(A),
        'cursor': ident(C),
        'pre_manifest': ident(P),
        'source': ident(S),
        'formula_gate': output_formula,
        'structural_gate': output_structure,
        'verified_changed_german': de_changed,
        'verified_changed_english': en_changed,
        'verified_rendering_changed_german': RENDER_DE,
        'verified_rendering_changed_english': RENDER_EN,
        'verified_canonical_leaf_changed': receipt['canonical_leaf_changed'],
        'verified_boundaries_unchanged': ['i0511', 'i0544'],
        'verified_joins': 33,
        'verified_terminal_records': 32,
        'verified_historical_queries': 125,
        'verified_correction_count': 25,
        'verified_source_anomaly_count': 20,
        'verified_mathematical_or_cross_reference_source_anomaly_count': 17,
        'verified_visual_pages': 27,
        'verified_unresolved': 0,
        'post_selected_root_sha256': root(SEL),
        'post_full_root_sha256': root(FULL),
    }
    O.write_text(json.dumps(verification, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'verification': ident(O), 'receipt': ident(R), 'attestation': ident(A), 'cursor': ident(C)}, indent=2))


if __name__ == '__main__':
    main()
