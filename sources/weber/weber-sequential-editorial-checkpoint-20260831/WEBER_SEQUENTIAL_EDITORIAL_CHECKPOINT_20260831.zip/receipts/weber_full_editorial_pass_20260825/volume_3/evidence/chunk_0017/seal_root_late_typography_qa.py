"""Pin root's final eleven-page late-typography proof inspection."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
import fitz
from PIL import Image

E = Path(__file__).resolve().parent
W = E.parents[4]


def identity(p):
    p = Path(p)
    data = p.read_bytes()
    return {"path": str(p), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest().upper()}


pages = []
proofs = []
for lane, leaves in (("de", [555, 556, 561, 562, 563, 574]), ("en", [555, 556, 561, 562, 563])):
    base = E / f"root_late_typography_{lane}"
    pdf, master, log = [base.with_suffix(ext) for ext in (".pdf", ".tex", ".log")]
    text = log.read_text(encoding="utf-8", errors="replace")
    assert not re.search(r"Overfull|Underfull|Undefined control sequence|LaTeX Error", text)
    expected = [(f"i{leaf:04d}", str(n)) for n, leaf in enumerate(leaves, 1)]
    assert re.findall(r"AUDIT_START_" + lane.upper() + r"_(i\d{4})_PAGE:(\d+)", text) == expected
    with fitz.open(pdf) as doc:
        assert len(doc) == len(leaves)
    proofs.append({"language": lane.upper(), "master": identity(master), "pdf": identity(pdf), "log": identity(log), "page_count": len(leaves), "build_warning_count": 0})
    canonical_dir = W / ("swarm_tex" if lane == "de" else "swarm_en") / "b3"
    for n, leaf in enumerate(leaves, 1):
        png = E / f"root_late_typography_{lane}-{n}.png"
        with Image.open(png) as im:
            pixels = list(im.size)
            assert pixels == [2481, 3508], pixels
        pages.append({"language": lane.upper(), "leaf": f"i{leaf:04d}", "proof_page": n, "canonical_input": identity(canonical_dir / f"b3_i{leaf:04d}.tex"), "raster": identity(png), "pixels": pixels, "dpi": 300, "visual_review_status": "PASS"})

out = E / "ROOT_LATE_TYPOGRAPHY_FINAL_QA.json"
receipt = {
    "schema": "weber-root-late-typography-proof-qa/v1", "status": "PASS", "completed_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Final eleven changed proof pages: German and English i0555,i0556,i0561,i0562,i0563 plus German i0574.",
    "preamble": identity(W / "swarm_preamble.tex"), "proofs": proofs, "pages": pages,
    "prior_first24_qa": identity(E / "ROOT_FIRST24_FINAL_QA.json"),
    "i0546_addendum": identity(E / "ROOT_I0546_FINAL_LAYOUT_ADDENDUM.json"),
    "prior_final8_source_and_visual_audit": identity(E / "PARTIAL_I0568_I0575_AUDIT.json"),
    "inspection": [
        "Root inspected every one of the eleven full 300dpi proof pages after the final typography edits, not merely their extracted text or build logs.",
        "i0555 closing rule is below the last footnote line in both language proofs and clear of the audit page number; Gauss suffix emphasis is narrow and legible.",
        "All six restored under-Lim s=1 placements render below the operator with no collision; the source's bare Lim instances remain bare.",
        "The three low ditto marks on i0563 render as low double commas, and the Pell derivative suffix on German i0574 is unspaced.",
        "No clipped or missing glyphs, overflowing equations, broken rows, overlaps, black boxes, unwanted page spills, or unreadable footnotes were observed."
    ],
    "supersession": "Keep every old receipt/proof byte. This QA supersedes only the ten first24 proofs and one final8 German proof identified above. Final aggregate64page coverage is36 unchanged first24 +2 i0546 addendum +15 unchanged final8 +11 late proofs.",
    "counts": {"proof_pages": 11, "visually_reviewed": 11, "canonical_language_files": 11, "build_warnings": 0, "unresolved": 0},
    "terminal_assertion": "PASS for these exact eleven canonical inputs and final proof pages. Full chunk source/query adjudication and independent sealing are recorded separately."
}
out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "receipt": identity(out)}))
