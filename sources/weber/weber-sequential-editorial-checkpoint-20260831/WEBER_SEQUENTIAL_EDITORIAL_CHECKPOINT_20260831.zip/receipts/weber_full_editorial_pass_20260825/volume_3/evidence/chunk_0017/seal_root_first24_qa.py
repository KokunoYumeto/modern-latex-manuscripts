"""Record root's completed 48-page visual inspection and pin its inputs."""
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import fitz
from PIL import Image

E = Path(__file__).resolve().parent
W = E.parents[4]


def identity(path):
    path = Path(path)
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest().upper()}


partial_path = E / "ROOT_PARTIAL_AUDIT_20260831.json"
partial = json.loads(partial_path.read_text(encoding="utf-8-sig"))
assert identity(partial_path)["sha256"] == "FD9BC69BD29791639B850FD61CF560DED592F6CFE8E72332274FB7E3FE149B4A"
canonical = []
for expected in partial["canonical_current"]:
    actual = identity(expected["path"])
    assert actual == expected, actual
    canonical.append(actual)
assert len(canonical) == 48
assert identity(partial["source"]["path"]) == partial["source"]
source_audit = E / "READ_ONLY_SOURCE_AUDIT_I0544_I0567.json"
assert identity(source_audit)["sha256"] == "2EE8F51F9E990C7C44F7A4F30FBE5E79C514293BC188F40739888BD267E4F82B"

expected_pdfs = {
    "de": "7F936B730E3FB50D0409828CF3989639A54EB70049549BA3610D14C6A46EBB81",
    "en": "0E7B87FBAC2E1518478931831A1EEBE72176D0B563610C6226BC7B393DF6AA02",
}
proofs = []
visual_pages = []
contact_sheets = []
for language in ("de", "en"):
    base = E / ("root_first24_proof_" + language)
    pdf = base.with_suffix(".pdf")
    log = base.with_suffix(".log")
    master = base.with_suffix(".tex")
    assert identity(pdf)["sha256"] == expected_pdfs[language]
    log_text = log.read_text(encoding="utf-8", errors="replace")
    errors = re.findall(r"(?:Overfull|Underfull|Undefined control sequence|LaTeX Error)[^\n]*", log_text)
    assert not errors, errors
    starts = re.findall(r"AUDIT_START_" + language.upper() + r"_(i\d{4})_PAGE:(\d+)", log_text)
    assert starts == [(f"i{leaf:04d}", str(leaf - 543)) for leaf in range(544, 568)]
    master_text = master.read_text(encoding="utf-8")
    selected_lane = "swarm_tex" if language == "de" else "swarm_en"
    for leaf in range(544, 568):
        assert f"{selected_lane}/b3/b3_i{leaf:04d}.tex" in master_text
    with fitz.open(pdf) as document:
        assert len(document) == 24
        assert all(page.get_text().strip() for page in document)
    proofs.append({"language": language.upper(), "pdf": identity(pdf), "master": identity(master), "log": identity(log), "page_count": 24, "page_map": starts, "build_warning_count": 0})
    for page in range(1, 25):
        png = E / f"root_proof_{language}-{page:02d}.png"
        with Image.open(png) as im:
            im.verify()
        with Image.open(png) as im:
            size = list(im.size)
            assert min(size) > 2000, size
        visual_pages.append({"language": language.upper(), "leaf": f"i{page + 543:04d}", "proof_page": page, "raster": identity(png), "pixels": size, "raster_dpi": 300, "review_status": "PASS", "inspection": "Root visually inspected the full page in a four-page contact sheet; no clipping, overlapping text/equations, missing glyphs, black boxes, broken figure or table, or unexpected page spill observed."})
    for first in (1, 5, 9, 13, 17, 21):
        contact_sheets.append(identity(E / f"root_contact_{language}_{first:02d}_{first + 3:02d}.png"))

asset = W / "swarm_assets/b3/weber_b3_i0558_fig2_source_crop.png"
assert identity(asset)["sha256"] == "B37497F3ACE24A5DD9A3EA70B2D421FA8E7E723A08A7589D34628F3CBB542E79"
receipt = {
    "schema": "weber-root-proof-visual-qa/v1",
    "status": "PASS",
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Volume III i0544-i0567, all 24 German and 24 English final proof pages; this is proof-render QA, not a substitute for source or boundary adjudication.",
    "author": "root editorial agent",
    "source": partial["source"],
    "partial_correction_inventory": identity(partial_path),
    "independent_source_audit": identity(source_audit),
    "canonical_inputs": canonical,
    "preamble": identity(W / "swarm_preamble.tex"),
    "proofs": proofs,
    "visual_pages": visual_pages,
    "contact_sheets": contact_sheets,
    "figure_asset": identity(asset),
    "figure_provenance": identity(E / "FIG2_SOURCE_CROP_PROVENANCE.json"),
    "visual_review_details": [
        "All 48 proof pages inspected after final canonical changes; the checked PDF identities and 48 leaf inputs match the final correction checkpoint.",
        "i0544 has one manual footnote anchor and detached footnote text with no duplicate main-text anchor.",
        "i0553/i0554 aligned systems, integer digit grouping, and i0555 footnote punctuation render correctly.",
        "i0556 chapter/section transition is intact; i0558 shows the exact Fig.2 crop with caption, axes, labelled strips, and no clipping.",
        "i0560 Q_s punctuation, i0564 definition indentation, i0565 aligned B/A definitions, i0566 theorem paragraphs, and i0567 displayed f-value pair are clear.",
        "The proof page numbers 1-24 are audit-local; source leaf identity is carried by the exact master/log page mapping."
    ],
    "counts": {"canonical_leaves": 24, "canonical_language_files": 48, "proof_pages_built": 48, "proof_pages_visually_reviewed": 48, "build_warnings": 0, "unresolved_visual_defects": 0},
    "terminal_assertion": "PASS for these exact first24 canonical/proof identities. Full32 chunk sealing, deterministic formula/topology checks, and cursor advancement are separate operations."
}
out = E / "ROOT_FIRST24_FINAL_QA.json"
out.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "receipt": identity(out), "reviewed_pages": 48}))
