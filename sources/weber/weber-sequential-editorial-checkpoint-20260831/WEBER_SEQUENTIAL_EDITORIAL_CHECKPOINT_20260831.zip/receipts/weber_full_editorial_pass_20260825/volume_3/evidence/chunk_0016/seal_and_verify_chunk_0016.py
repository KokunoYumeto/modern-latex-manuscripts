import hashlib
import json
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import fitz

W = Path(r'local-environment/Documents\weber_restart_20260819\work')
D = W / 'swarm_tex' / 'b3'
E = W / 'swarm_en' / 'b3'
Q = W / 'translation_queries'
V = W / 'receipts' / 'weber_full_editorial_pass_20260825' / 'volume_3'
EV = V / 'evidence' / 'chunk_0016'
P = EV / 'canonical_pre_manifest.json'
C = V / 'CURSOR.json'
R = V / 'chunks' / 'CHUNK_0016_i0512_i0543.json'
A = EV / 'FINAL_QA_ATTESTATION.json'
S = Path(r'registered-source/Weber_Algebra_Bd3.pdf')

IDS = [f'i{n:04d}' for n in range(512, 544)]
SEL = ['i0511', *IDS, 'i0544']
FULL = [f'i{n:04d}' for n in range(22, 415)] + [f'i{n:04d}' for n in range(425, 772)]
EXPECTED_CHANGED = [
    'i0512', 'i0514', 'i0515', 'i0516', 'i0518', 'i0521', 'i0523', 'i0524',
    'i0528', 'i0531', 'i0532', 'i0533', 'i0534', 'i0537', 'i0538', 'i0539',
    'i0541', 'i0542', 'i0543',
]
# i0512 is also changed; keep strict canonical order.
EXPECTED_CHANGED.insert(0, EXPECTED_CHANGED.pop(EXPECTED_CHANGED.index('i0512')))
RENDER_DE = [
    'i0512', 'i0514', 'i0516', 'i0518', 'i0523', 'i0524', 'i0531',
    'i0532', 'i0537', 'i0538', 'i0541', 'i0542', 'i0543',
]
RENDER_EN = [
    'i0512', 'i0514', 'i0516', 'i0518', 'i0523', 'i0524', 'i0531',
    'i0532', 'i0537', 'i0538', 'i0539', 'i0541', 'i0542', 'i0543',
]

COR = {
    'i0512': {
        'confirmed_defect_count': 3,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Reattached the orphaned full stop to “Klassengleichung”; restored the three source-aligned unnumbered equations as one aligned display in both languages; repaired the English number agreement in the r/m parity sentence.',
    },
    'i0514': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Restored the short centered source rule after equation (29) in both languages and repaired the English monotonicity sentence.',
    },
    'i0516': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Restored the two source paragraph starts after the displays ending at (34) and z=2+sqrt(7), mirrored in English.',
    },
    'i0518': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 2,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Restored equation (10) as a two-row aligned display and removed the invented comma after its first row in both languages.',
    },
    'i0523': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Rejoined the two source lines after equation (10) into one two-row gathered display in both languages.',
    },
    'i0524': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Corrected the equation (13) alignment so c, c-prime, c-double-prime, and c-triple-prime share the source column independently of n.',
    },
    'i0528': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Restored the missing terminal continuation marker in both canonical languages, sealing the i0528-i0529 join.',
    },
    'i0531': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Restored the short centered chapter separator rule before section 134 in both languages.',
    },
    'i0532': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Restored the source comma at the end of the first row of equation (8) in both languages.',
    },
    'i0533': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Removed a false evidentiary annotation that had conflated the distinct printed variables partial and delta.',
    },
    'i0537': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 1,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 0,
        'detail': 'Restored the source-sized parentheses and outer square brackets around the omega/2 terms in equation (7), in both languages.',
    },
    'i0538': {
        'confirmed_defect_count': 1,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 1,
        'detail': 'Restored section 136 number and title to the single centered source line in both languages.',
    },
    'i0539': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Repaired the English divisibility passage as a complete sentence and removed the residual German preposition from its displayed conjunction.',
    },
    'i0541': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Corrected the German transcription ergiebt to the source-printed ergibt and repaired the English statement that positivity of beta follows from the existing assumptions.',
    },
    'i0542': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 0,
        'prose_grammar_or_number_count': 2,
        'detail': 'Restored the two source paragraph starts after equations (19) and (20), mirrored in English.',
    },
    'i0543': {
        'confirmed_defect_count': 2,
        'mathematical_reconstruction_count': 0,
        'mathematical_or_technical_semantic_count': 1,
        'prose_grammar_or_number_count': 1,
        'detail': 'Corrected the English cross-page theorem continuation from even divisor to odd divisor and restored section 137 number and title to one centered line.',
    },
}

ANO = [
    {'id': 'i0515', 'detail': 'Equation (33) omits x before its alternative equality. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0518', 'detail': 'Equation (8) omits sqrt(2)x before its alternative equality. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0521', 'detail': 'Equation (5) prints F-prime, inconsistent with F(u,v) in (4) and F(u,u) in (6). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0522', 'detail': 'The polynomial for m=19 begins B-squared minus 6B-squared although the sequel and equation (7) require a cubic first term. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0524', 'detail': 'The last factor in equation (15) prints v subscript 1+7 where the index pattern requires nu+7. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0526', 'detail': 'The source prints a stray full stop between a plus sign and rho-squared inside the displayed polynomial. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0528', 'detail': 'The coefficient of v3 is printed square-root 2 rather than fourth-root 2. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0528', 'detail': 'The coefficient of v5 is printed square-root 2 rather than fourth-root 2. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0528', 'detail': 'The page prints u=sqrt(2), conflicting with u=f(i)=fourth-root 2 on the preceding page. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0531', 'detail': 'The source prints singular “die nu Größe” where the context enumerates nu quantities. Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0534', 'detail': 'The source repeats v2 in the displayed list where an index run is expected. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0534', 'detail': 'The source separates the factors of the displayed expression with commas rather than a product sign. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0534', 'detail': 'The final denominator Phi-prime(u) conflicts with the immediately preceding specialization x=sigma and requires Phi-prime(sigma). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0535', 'detail': 'The source prints factor 9 in the gamma3 evaluation where the arithmetic requires 27. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0539', 'detail': 'Equation (2) prints denominator 2, conflicting with denominator a in (5) and the ensuing system (7). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0539', 'detail': 'The full stop after equation (4) interrupts the sentence whose governing verb follows the display. Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0542', 'detail': 'The claim that x and x-prime are both even conflicts with n=m-squared(x-squared+x-prime-squared) for odd n and m. Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0543', 'detail': 'Equation (23) prints Phi(-i,Mu), misplacing the comma; the sign orbit requires Phi(-iM,u). Retained and annotated.', 'mathematical_or_cross_reference': True},
    {'id': 'i0543', 'detail': 'The source prints the ungrammatical phrase “aus den ... Satz.” Retained and annotated.', 'mathematical_or_cross_reference': False},
    {'id': 'i0543', 'detail': 'The source cites the three quantities as (2), although they occur in equation (1). Retained and annotated.', 'mathematical_or_cross_reference': True},
]


def sh(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def ident(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sh(path)}


def wr(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def root(ids):
    h = hashlib.sha256()
    for leaf in ids:
        for lang, base in [('de', D), ('en', E)]:
            h.update(f'{lang}:{leaf}:'.encode())
            h.update((base / f'b3_{leaf}.tex').read_bytes())
            h.update(b'\n')
    return h.hexdigest().upper()


def run(args):
    proc = subprocess.run(args, cwd=W, text=True, encoding='utf-8', errors='replace', capture_output=True)
    return proc.returncode, (proc.stdout + proc.stderr).strip()


def main():
    pre = json.loads(P.read_text(encoding='utf-8'))
    prior = {record['id']: record for record in pre['records']}
    assert list(prior) == SEL

    post = {}
    de_changed = []
    en_changed = []
    for leaf in SEL:
        post[leaf] = {
            'german': ident(D / f'b3_{leaf}.tex'),
            'english': ident(E / f'b3_{leaf}.tex'),
        }
        if post[leaf]['german']['sha256'] != prior[leaf]['german']['sha256']:
            de_changed.append(leaf)
        if post[leaf]['english']['sha256'] != prior[leaf]['english']['sha256']:
            en_changed.append(leaf)
    assert de_changed == EXPECTED_CHANGED, de_changed
    assert en_changed == EXPECTED_CHANGED, en_changed
    assert all(post[leaf][lang] == prior[leaf][lang] for leaf in ['i0511', 'i0544'] for lang in ['german', 'english'])

    pre_selected = pre['selected_root_sha256']
    pre_full = pre['full_root_sha256']
    post_selected = root(SEL)
    post_full = root(FULL)
    assert sh(S) == '25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387'

    scans = [EV / f'source_scan_page-{page}.png' for page in range(512, 546)]
    assert len(scans) == 34 and all(path.stat().st_size for path in scans)
    extracted = EV / 'source_scan_pages_512_545_extracted.txt'
    assert extracted.stat().st_size
    support = sorted(EV.glob('source_contact_*.jpg'))
    assert len(support) == 5 and all(path.stat().st_size for path in support)

    query_files = [Q / f'b3_i{n:04d}.json' for n in range(512, 544)]
    query_payloads = [json.loads(path.read_text(encoding='utf-8')) for path in query_files]
    query_counts = {f'i{n:04d}': len(payload['queries']) for n, payload in zip(range(512, 544), query_payloads)}
    all_queries = [query for payload in query_payloads for query in payload['queries']]
    by_confidence = Counter(query['confidence'] for query in all_queries)
    by_kind = Counter(query['kind'] for query in all_queries)
    assert len(query_files) == 32 and len(all_queries) == 125
    assert by_confidence == Counter({'low': 53, 'high': 38, 'medium': 34})
    assert by_kind == Counter({'transcription': 71, 'term': 19, 'author_error': 12, 'omission': 12, 'unreadable': 9, 'addition': 2})

    de_master = EV / 'changed_leaf_qa_de.tex'
    en_master = EV / 'changed_leaf_qa_en.tex'
    de_pdf = EV / 'changed_leaf_qa_de.pdf'
    en_pdf = EV / 'changed_leaf_qa_en.pdf'
    de_log = EV / 'changed_leaf_qa_de.log'
    en_log = EV / 'changed_leaf_qa_en.log'
    assert len(fitz.open(de_pdf)) == 13 and len(fitz.open(en_pdf)) == 14
    assert re.findall(r'b3_(i\d{4})\.tex', de_master.read_text(encoding='utf-8')) == RENDER_DE
    assert re.findall(r'b3_(i\d{4})\.tex', en_master.read_text(encoding='utf-8')) == RENDER_EN
    fatal_pattern = r'LaTeX Error|Undefined control sequence|Emergency stop|Fatal error|Overfull \\hbox|Overfull \\vbox|Underfull \\hbox|Underfull \\vbox'
    for log in [de_log, en_log]:
        assert not re.search(fatal_pattern, log.read_text(encoding='utf-8', errors='replace'), re.I)
    de_renders = sorted(EV.glob('final_qa_de_page-*.png'))
    en_renders = sorted(EV.glob('final_qa_en_page-*.png'))
    assert len(de_renders) == 13 and len(en_renders) == 14

    gate_formula, output_formula = run(['python', 'check_en.py', 'b3'])
    gate_structure, output_structure = run(['python', '_audit_printed_coverage.py', 'b3'])
    assert gate_formula == 0 and '740 pass, 0 fail, 3457 audit queries raised' in output_formula
    assert gate_structure == 0 and '750 fragments | printed range 1-733 | 43 unnumbered leaves' in output_structure
    for leaf in IDS:
        for path in [D / f'b3_{leaf}.tex', E / f'b3_{leaf}.tex']:
            text = path.read_text(encoding='utf-8')
            assert not re.search(r'\?\?|\b(?:TODO|TBD|PENDING|PLACEHOLDER|FIXME|UNCERTAIN|HOLD)\b', text)
    assert sum((D / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 20
    assert sum((E / f'b3_{leaf}.tex').read_text(encoding='utf-8').count('[sic]') for leaf in IDS) == 20

    for base in [D, E]:
        assert 'Klassengleichung.\nLöst' in (D / 'b3_i0512.tex').read_text(encoding='utf-8')
        assert '\\begin{aligned}\nu^8' in (base / 'b3_i0512.tex').read_text(encoding='utf-8')
        assert '\\begin{center}\\rule{3cm}{0.4pt}\\end{center}' in (base / 'b3_i0514.tex').read_text(encoding='utf-8')
        assert '\\weq{10}{\\begin{aligned}' in (base / 'b3_i0518.tex').read_text(encoding='utf-8')
        assert '\\begin{gathered}' in (base / 'b3_i0523.tex').read_text(encoding='utf-8')
        assert "&& c' &=" in (base / 'b3_i0524.tex').read_text(encoding='utf-8')
        assert (base / 'b3_i0528.tex').read_text(encoding='utf-8').rstrip().endswith('%CONT>>')
        assert '\\begin{center}\\rule{3cm}{0.4pt}\\end{center}' in (base / 'b3_i0531.tex').read_text(encoding='utf-8')
        assert 'c\\beta-a\\delta &= \\frac{Bx+y}{2},' in (base / 'b3_i0532.tex').read_text(encoding='utf-8')
        assert '\\left[f_2\\!\\left(\\dfrac{\\omega}{2}\\right)^{24}+16\\right]' in (base / 'b3_i0537.tex').read_text(encoding='utf-8')
        assert '\\S\\,136.\\quad \\gesperrt{' in (base / 'b3_i0538.tex').read_text(encoding='utf-8')
        assert '\n\nEs haben also' in (D / 'b3_i0542.tex').read_text(encoding='utf-8')
        assert '\n\nThus $M$ and $M\'$' in (E / 'b3_i0542.tex').read_text(encoding='utf-8')
        assert '§ 137.\\quad \\gesperrt{' in (base / 'b3_i0543.tex').read_text(encoding='utf-8')
    assert '(and hence $m$) is even or odd' in (E / 'b3_i0512.tex').read_text(encoding='utf-8')
    assert 'increases monotonically' in (E / 'b3_i0514.tex').read_text(encoding='utf-8')
    assert '\n\nBut by (34):' in (E / 'b3_i0516.tex').read_text(encoding='utf-8')
    assert '\n\nThe left side of (36)' in (E / 'b3_i0516.tex').read_text(encoding='utf-8')
    assert 'It would then also divide' in (E / 'b3_i0539.tex').read_text(encoding='utf-8')
    assert '\\quad\\text{and}\\quad' in (E / 'b3_i0539.tex').read_text(encoding='utf-8')
    assert '\\text{and in}' not in (E / 'b3_i0539.tex').read_text(encoding='utf-8')
    assert 'so ergibt sich' in (D / 'b3_i0541.tex').read_text(encoding='utf-8')
    assert 'so ergiebt sich' not in (D / 'b3_i0541.tex').read_text(encoding='utf-8')
    assert 'For $\\beta$ this follows from the assumptions already made.' in (E / 'b3_i0541.tex').read_text(encoding='utf-8')
    assert '\\gesperrt{odd divisor' in (E / 'b3_i0543.tex').read_text(encoding='utf-8')

    now = datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z')
    attestation = {
        'schema': 'weber-changed-leaf-final-qa/v1',
        'status': 'PASS',
        'completed_at_utc': now,
        'volume': 'III',
        'chunk': 'CHUNK_0016_i0512_i0543',
        'visual_inspection': {
            'method': 'All 27 rendering-changing proof pages were compiled after the final edits, rendered with Poppler at 300 dpi, and visually inspected page by page for clipping, overlap, glyph loss, malformed formulae, and unintended layout change.',
            'german_pages_reviewed': 13,
            'english_pages_reviewed': 14,
            'total_pages_reviewed': 27,
            'visual_defects': 0,
        },
        'source_symbol_review': {
            'status': 'PASS',
            'assigned_scan_pages_reviewed': 32,
            'boundary_scan_pages_reviewed': 2,
            'total_scan_pages_reviewed': 34,
            'source_scan_page_range_one_based': [512, 545],
        },
        'historical_query_review': {
            'status': 'TERMINALLY_ADJUDICATED',
            'files_reviewed': 32,
            'queries_reviewed': 125,
            'by_confidence': dict(sorted(by_confidence.items())),
            'by_kind': dict(sorted(by_kind.items())),
            'unresolved': 0,
        },
        'formula_gate': {'status': 'PASS', 'output': output_formula},
        'structural_gate': {'status': 'PASS_WITH_REGISTERED_TOPOLOGY', 'output': output_structure},
        'placeholder_gate': {'status': 'PASS', 'assigned_files_scanned': 64, 'marker_hits': 0},
        'german': {
            'rendering_changed_ids': RENDER_DE,
            'master': ident(de_master),
            'pdf': {**ident(de_pdf), 'pages': 13},
            'log': ident(de_log),
            'renders': [ident(path) for path in de_renders],
        },
        'english': {
            'rendering_changed_ids': RENDER_EN,
            'master': ident(en_master),
            'pdf': {**ident(en_pdf), 'pages': 14},
            'log': ident(en_log),
            'renders': [ident(path) for path in en_renders],
        },
        'unresolved': 0,
    }
    wr(A, attestation)

    corrections = {leaf: {'id': leaf, **value} for leaf, value in COR.items()}
    anomalies_by_leaf = {}
    for anomaly in ANO:
        anomalies_by_leaf.setdefault(anomaly['id'], []).append(anomaly)
    sic_only = set(anomalies_by_leaf) - set(COR)
    status = {leaf: ('FIXED' if leaf in COR else 'SOURCE_ORIGINAL_SIC' if leaf in sic_only else 'PASS') for leaf in IDS}
    assert Counter(status.values()) == Counter({'FIXED': 16, 'PASS': 10, 'SOURCE_ORIGINAL_SIC': 6})
    assert sum(item['confirmed_defect_count'] for item in COR.values()) == 25
    assert sum(item['mathematical_reconstruction_count'] for item in COR.values()) == 7
    assert sum(item['mathematical_or_technical_semantic_count'] for item in COR.values()) == 1
    assert sum(item['prose_grammar_or_number_count'] for item in COR.values()) == 17
    assert len(ANO) == 20
    assert sum(item['mathematical_or_cross_reference'] for item in ANO) == 17

    records = [
        {
            'id': leaf,
            'source_pdf_page': int(leaf[1:]) + 1,
            'source_inspection': 'COMPLETE_SYMBOL_FORMULA_TRANSLATION_SEMANTIC',
            'historical_query_count': query_counts[leaf],
            'historical_query_disposition': 'TERMINALLY_ADJUDICATED',
            'german': post[leaf]['german'],
            'english': post[leaf]['english'],
            'status': status[leaf],
            'correction': corrections.get(leaf),
            'source_original_anomalies': anomalies_by_leaf.get(leaf, []),
            'disposition': 'Terminally adjudicated against the registered scan; every historical flag was resolved, all source-original anomalies are annotated, and no reconstruction or translation defect remains unresolved.',
            'unresolved': 0,
        }
        for leaf in IDS
    ]
    order = ['i0511', *IDS, 'i0544']
    joins = [
        {
            'from': left,
            'to': right,
            'status': 'PASS',
            'detail': f'The registered scan and both canonical languages were checked across the {left} to {right} join for sentence continuation, display topology, headings, page order, and omitted or duplicated symbols; the boundary is terminally complete.',
        }
        for left, right in zip(order, order[1:])
    ]
    assert len(joins) == 33

    counts = {
        'assigned_leaves': 32,
        'terminal_leaves': 32,
        'fixed_leaves': 16,
        'source_original_sic_only_leaves': 6,
        'pass_leaves': 10,
        'changed_canonical_files': 38,
        'changed_unique_leaves': 19,
        'rendering_changed_files': 27,
        'rendering_changed_unique_leaves': 14,
        'confirmed_defects_fixed': 25,
        'mathematical_reconstruction_defects_fixed': 7,
        'mathematical_or_technical_semantic_defects_fixed': 1,
        'prose_grammar_or_number_defects_fixed': 17,
        'source_original_anomalies': 20,
        'mathematical_or_cross_reference_source_anomalies': 17,
        'historical_query_files_adjudicated': 32,
        'historical_queries_adjudicated': 125,
        'joins_checked': 33,
        'unresolved': 0,
    }
    receipt = {
        'schema': 'weber-full-editorial-chunk/v1',
        'status': 'TERMINAL_PASS',
        'completed_at_utc': now,
        'volume': 'III',
        'chunk': 'CHUNK_0016_i0512_i0543',
        'scope': {
            'inbound_read_only': 'i0511',
            'assigned_canonical_sequence': IDS,
            'assigned_first': 'i0512',
            'assigned_last': 'i0543',
            'outbound_read_only': 'i0544',
            'assigned_leaf_count': 32,
        },
        'source': ident(S),
        'pre_manifest': ident(P),
        'live_root_hashes': {
            'pre_selected_root_sha256': pre_selected,
            'post_selected_root_sha256': post_selected,
            'pre_full_root_sha256': pre_full,
            'post_full_root_sha256': post_full,
            'pre': {'selected': pre_selected, 'full': pre_full},
            'post': {'selected': post_selected, 'full': post_full},
        },
        'canonical_leaf_changed': sorted(set(de_changed + en_changed)),
        'canonical_file_changed': {'german': de_changed, 'english': en_changed, 'total': 38},
        'rendering_changed': {'german': RENDER_DE, 'english': RENDER_EN, 'total_files': 27, 'unique_leaves': 14},
        'source_evidence': {
            'pdf_pages_inspected': list(range(512, 546)),
            'assigned_pdf_pages': list(range(513, 545)),
            'mapping': 'canonical iNNNN maps to registered PDF page NNNN+1; inbound i0511 and outbound i0544 were read for join continuity',
            'render_inventory': [ident(path) for path in scans],
            'extracted_text': ident(extracted),
            'supporting_contact_sheets': [ident(path) for path in support],
        },
        'historical_query_evidence': {
            'status': 'TERMINALLY_ADJUDICATED',
            'query_count': 125,
            'by_confidence': dict(sorted(by_confidence.items())),
            'by_kind': dict(sorted(by_kind.items())),
            'per_leaf_counts': query_counts,
            'files': [ident(path) for path in query_files],
            'disposition': 'Every query was checked against the registered scan and live German/English leaves. Proven live defects are represented in the correction inventory; genuine source-original defects are represented in the anomaly inventory; already-correct, corpus-convention, and source-context false positives were terminally dismissed.',
            'unresolved': 0,
        },
        'records': records,
        'joins': joins,
        'correction_inventory': list(corrections.values()),
        'source_original_anomalies': ANO,
        'counts': counts,
        'boundary_post': {'i0511': post['i0511'], 'i0544': post['i0544']},
        'qa_attestation': ident(A),
        'checker': {'status': 'PASS', 'output': output_formula},
        'structural_validator': {'status': 'PASS_WITH_REGISTERED_TOPOLOGY', 'output': output_structure},
        'outbound_candidates': [],
        'unresolved': 0,
    }
    wr(R, receipt)

    cursor = json.loads(C.read_text(encoding='utf-8'))
    assert cursor['last_terminal_leaf'] == 'i0511' and cursor['next_leaf'] == 'i0512'
    assert cursor['terminal_leaf_count'] == 480 and cursor['unresolved'] == 0
    assert cursor['terminal_receipts'][-1]['sha256'] == 'D756914D3517F98B9169E6A22D0ACC0E17EF19413BA2D2EBE19576416B264D61'
    cursor.update({
        'last_terminal_leaf': 'i0543',
        'next_leaf': 'i0544',
        'active_chunk': 'CHUNK_0017_i0544_i0575',
        'terminal_leaves': 512,
        'confirmed_defects': 276,
        'fixed_defects': 276,
        'source_original_anomalies': 192,
        'source_original_mathematical_or_cross_reference_anomalies': 159,
        'changed_leaves': 216,
        'terminal_leaf_count': 512,
        'cumulative_confirmed_defects_fixed': 276,
        'cumulative_source_original_anomalies': 192,
        'cumulative_mathematical_or_cross_reference_source_anomalies': 159,
        'cumulative_changed_leaves': 216,
        'unresolved': 0,
        'updated_at_utc': now,
    })
    cursor.setdefault('terminal_receipts', []).append(ident(R))
    wr(C, cursor)

    reread_receipt = json.loads(R.read_text(encoding='utf-8'))
    reread_cursor = json.loads(C.read_text(encoding='utf-8'))
    assert reread_receipt['status'] == 'TERMINAL_PASS' and len(reread_receipt['records']) == 32 and len(reread_receipt['joins']) == 33
    assert reread_receipt['counts'] == counts and reread_receipt['unresolved'] == 0
    assert reread_cursor['last_terminal_leaf'] == 'i0543' and reread_cursor['next_leaf'] == 'i0544'
    assert reread_cursor['terminal_leaf_count'] == 512 and reread_cursor['unresolved'] == 0
    assert root(SEL) == post_selected and root(FULL) == post_full
    print(json.dumps({
        'status': 'PASS',
        'receipt': ident(R),
        'attestation': ident(A),
        'cursor': ident(C),
        'counts': counts,
        'roots': {
            'pre_selected': pre_selected,
            'post_selected': post_selected,
            'pre_full': pre_full,
            'post_full': post_full,
        },
    }, indent=2))


if __name__ == '__main__':
    main()
