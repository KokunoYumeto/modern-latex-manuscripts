from pathlib import Path
from PIL import Image, ImageDraw, ImageOps

ROOT = Path(__file__).resolve().parent
CELL_W, CELL_H, LABEL_H = 720, 1018, 30
for lang in ("de", "en"):
    for first in range(1, 25, 4):
        sheet = Image.new("RGB", (CELL_W * 2, (CELL_H + LABEL_H) * 2), "white")
        draw = ImageDraw.Draw(sheet)
        for offset in range(4):
            page = first + offset
            source = ROOT / f"root_proof_{lang}-{page:02d}.png"
            with Image.open(source) as im:
                tile = ImageOps.contain(im.convert("RGB"), (CELL_W, CELL_H))
            x = (offset % 2) * CELL_W
            y = (offset // 2) * (CELL_H + LABEL_H)
            draw.text((x + 8, y + 8), f"{lang.upper()} i{543 + page:04d} / proof page {page}", fill="black")
            sheet.paste(tile, (x + (CELL_W - tile.width) // 2, y + LABEL_H))
        output = ROOT / f"root_contact_{lang}_{first:02d}_{first+3:02d}.png"
        sheet.save(output)
        print(output.name)
