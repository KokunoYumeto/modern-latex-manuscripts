from __future__ import annotations

import hashlib
import json
from pathlib import Path

import fitz


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
SOURCE = Path(r"registered-source/Weber_Algebra_Bd3.pdf")
EVIDENCE = WORK / "receipts/weber_full_editorial_pass_20260825/volume_3/evidence/chunk_0017"
OUTPUT = WORK / "swarm_assets/b3/weber_b3_i0558_fig2_source_crop.png"


def identity(path: Path) -> dict:
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest().upper()}


source_id = identity(SOURCE)
assert source_id["sha256"] == "25C31D0E2D8E17989C3FBB2B773142508BB405BA211C230D130E63D73A945387"
clip = fitz.Rect(185.0, 398.0, 323.5, 541.0)
with fitz.open(SOURCE) as doc:
    page = doc[558]
    page_rect = list(page.rect)
    assert page.rect.contains(clip)
    pixmap = page.get_pixmap(matrix=fitz.Matrix(400 / 72, 400 / 72), clip=clip, alpha=False)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    pixmap.save(OUTPUT)
    dimensions = [pixmap.width, pixmap.height]

receipt = {
    "schema": "weber-registered-source-figure-crop/v1",
    "source": source_id,
    "canonical_leaf": "i0558",
    "printed_page": 527,
    "figure": "2",
    "source_pdf_page_one_based": 559,
    "page_rect_points": page_rect,
    "clip_rect_points": list(clip),
    "render_dpi": 400,
    "pixel_dimensions": dimensions,
    "transform": "Direct PDF raster rendering of the registered figure rectangle; no retouching, regeneration, or content alteration.",
    "output": identity(OUTPUT),
    "visual_review": "PENDING_ROOT_CROP_INSPECTION",
}
receipt_path = EVIDENCE / "FIG2_SOURCE_CROP_PROVENANCE.json"
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"crop": identity(OUTPUT), "receipt": identity(receipt_path)}, indent=2))
