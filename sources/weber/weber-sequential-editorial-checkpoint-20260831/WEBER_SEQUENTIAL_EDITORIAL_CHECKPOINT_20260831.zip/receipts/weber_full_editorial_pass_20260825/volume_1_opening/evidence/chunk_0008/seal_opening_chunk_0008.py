from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
OPENING = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening"
EVIDENCE = OPENING / "evidence" / "chunk_0008"
RECEIPT = OPENING / "chunks" / "OPENING_CHUNK_0008_p0113_p0128.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def identity(path: Path) -> dict:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}


def verify(item: dict) -> Path:
    path = Path(item["path"])
    assert path.is_file() and path.stat().st_size == item["bytes"] and sha256(path) == item["sha256"], path
    return path


assert not RECEIPT.exists(), f"refusing to overwrite terminal receipt: {RECEIPT}"

preaudit_path = EVIDENCE / "PREAUDIT_IDENTITIES.json"
draft_path = EVIDENCE / "DRAFT_EXTRACTION_MANIFEST.json"
post_path = EVIDENCE / "POST_ADJUDICATION_IDENTITIES.json"
figure_path = EVIDENCE / "FIGURE_CROP_MANIFEST.json"
source_original_path = EVIDENCE / "SOURCE_ORIGINAL_FINDINGS.json"
scoped_path = EVIDENCE / "SCOPED_VALIDATION.json"
math_path = EVIDENCE / "MATHEMATICAL_VERIFICATION.json"
independent_path = EVIDENCE / "INDEPENDENT_CONTENT_REVIEW.json"

preaudit = json.loads(preaudit_path.read_text(encoding="utf-8"))
draft = json.loads(draft_path.read_text(encoding="utf-8"))
post = json.loads(post_path.read_text(encoding="utf-8"))
figures = json.loads(figure_path.read_text(encoding="utf-8"))
source_original = json.loads(source_original_path.read_text(encoding="utf-8"))
scoped = json.loads(scoped_path.read_text(encoding="utf-8"))
math = json.loads(math_path.read_text(encoding="utf-8"))
independent = json.loads(independent_path.read_text(encoding="utf-8"))

assert preaudit["scope"]["printed_pages"] == "113-128" and preaudit["scope"]["stable_leaves"] == "i0138-i0153"
assert draft["coverage"] == "printed pp.113-128 / stable leaves i0138-i0153"
assert post["status"] == figures["status"] == source_original["status"] == scoped["status"] == math["status"] == independent["status"] == "PASS"
assert scoped["problems"] == [] and scoped["unresolved"] == 0
assert math["failed"] == [] and math["unresolved_mathematical_defects"] == 0
assert independent["unresolved_content_defects"] == 0
assert post["counts"] == {"printed_pages": 16, "canonical_language_leaves": 32, "exact_source_assets": 3, "unresolved": 0}
for record in post["canonical_leaves"]:
    verify(record["de"])
    verify(record["en"])
for item in post["canonical_assets"]:
    verify(item)

defect_details = [
    # Sixteen previously absent bilingual page pairs.
    *[(f"i{page + 25:04d}", "RECONSTRUCTED_AND_FIXED", f"Created and source-adjudicated the previously absent German and English canonical leaves for printed p.{page}.") for page in range(113, 129)],
    ("i0138", "FIXED", "Restored the registered comma in German equation (8): x^n=a,."),
    ("i0138", "FIXED", "Restored equation (9)'s outer square brackets and inner trigonometric parentheses in both languages."),
    ("i0138", "FIXED", "Corrected the English radius comparison: the nth-root radius is greater/smaller as r is smaller/greater than 1."),
    ("i0138", "FIXED", "Replaced reconstructed Figure 1 with an exact pinned 300-dpi source crop in both languages."),
    ("i0139", "FIXED", "Corrected English xi_k drift to source epsilon_k throughout."),
    ("i0139", "FIXED", "Restored English equation (12) as the source equation x^n=1 rather than epsilon_k^n=1."),
    ("i0140", "FIXED", "Restored the English source comma in equation (2)."),
    ("i0143", "SOURCE_ORIGINAL_SIC", "Preserved and annotated the printed cross-reference to cubic equation (6), although that cubic is numbered (1)."),
    ("i0143", "FIXED", "Restored source emphasis for Cardano's formula and the nine-value statement."),
    ("i0144", "SOURCE_ORIGINAL_SIC", "Preserved and annotated the printed bibliographic spelling Collectet."),
    ("i0144", "FIXED", "Attached the English footnote callout to the translated three-values phrase and retained its text at the source footnote position, eliminating a stranded marker."),
    ("i0144", "FIXED", "Restored source emphasis for Cardano, Cayley, and the three-value statement."),
    ("i0145", "FIXED", "Restored source emphasis for the cubic resolvent."),
    ("i0146", "FIXED", "Corrected all three English Latin-d substitutions to the source Greek delta."),
    ("i0146", "FIXED", "Restored the lower-bound definition and theorem emphasis required by the printed source."),
    ("i0147", "FIXED", "Restored continuity, lower-bound, and theorem-3 emphasis in the English translation."),
    ("i0148", "FIXED", "Restored the source punctuation of English equation (6), removing the spurious comma."),
    ("i0148", "FIXED", "Restored lower-bound and theorem-4 emphasis in the English translation."),
    ("i0149", "FIXED", "Corrected the English region coordinate from gamma to y in (P,y), y<eta, and y>eta."),
    ("i0149", "FIXED", "Replaced reconstructed Figure 2 with an exact pinned 300-dpi source crop in both languages."),
    ("i0149", "FIXED", "Restored theorem-4 closing and lower-bound emphasis."),
    ("i0150", "FIXED", "Restored theorem-5 emphasis in both languages and the English lower-bound emphasis."),
    ("i0151", "FIXED", "Restored the English proof marker q.e.d."),
    ("i0151", "FIXED", "Removed the spurious German comma after the unnumbered substituted f(alpha+h) display."),
    ("i0151", "FIXED", "Corrected German equation (17)'s terminal punctuation from period to the registered comma."),
    ("i0151", "FIXED", "Removed the spurious German period from equation (18) before w. z. b. w.; English punctuation was retained as translation-grammatical."),
    ("i0152", "FIXED", "Removed the false English display row break inside equation (3)'s absolute-value list."),
    ("i0152", "FIXED", "Removed the spurious English comma from equation (4) and restored Lipschitz/Dedekind emphasis in both languages."),
    ("i0153", "FIXED", "Restored the full English equation (5) ordering chain a<b1<=b2<=...<=b(n-1)."),
    ("i0153", "FIXED", "Corrected every English excluded-circle radius from rho to the source varrho."),
    ("i0153", "FIXED", "Restored the completely omitted English Figure 3 and replaced both language figures with the exact pinned source crop."),
    ("i0153", "FIXED", "Restored outside/greater source emphasis in both languages."),
    ("i0139-i0152", "FIXED", "Normalized all section headings in the span to the established opening-leaf convention while preserving exact numbering and titles."),
]
assert len(defect_details) == 49
defect_groups = [
    {"id": f"O8-{index:03d}", "leaf": leaf, "disposition": disposition, "detail": detail}
    for index, (leaf, disposition, detail) in enumerate(defect_details, 1)
]
assert sum(item["disposition"] != "SOURCE_ORIGINAL_SIC" for item in defect_groups) == 47
assert sum(item["disposition"] == "SOURCE_ORIGINAL_SIC" for item in defect_groups) == 2

records = []
scoped_by_id = {item["stable_id"]: item for item in scoped["records"]}
for item in post["canonical_leaves"]:
    structural = scoped_by_id[item["stable_id"]]
    records.append({
        "printed_marker": str(item["printed_page"]),
        "stable_id": item["stable_id"],
        "terminal_status": "FIXED",
        "de": item["de"],
        "en": item["en"],
        "equation_tags": structural["de"]["tags"],
        "start_cont": structural["de"]["start_cont"],
        "end_cont": structural["de"]["end_cont"],
        "normalized_equation_fingerprints": structural["normalized_equation_fingerprints"],
        "visual_review": "PASS in both languages at original render detail",
        "unresolved": 0,
    })

receipt = {
    "schema": "weber-full-editorial-opening-chunk/v1",
    "volume": "I",
    "lane": "previously omitted opening",
    "chunk": "OPENING_CHUNK_0008",
    "coverage": {
        "printed_pages": "113-128",
        "stable_leaves": "i0138-i0153",
        "mapping": "printed page p maps to stable leaf i(p+25), zero-based source PDF index p+25, one-based source PDF page p+26",
    },
    "status": "PASS",
    "completed_utc": datetime.now(timezone.utc).isoformat(),
    "authority": "The registered Volume-I scan is the sole primary authority. The complete German and English monoliths are text reservoirs only.",
    "source": preaudit["registered_source"],
    "baselines": preaudit["baselines"],
    "canonical_roots": {"de": (WORK / "swarm_tex" / "b1").as_posix(), "en": (WORK / "swarm_en" / "b1").as_posix(), "assets": (WORK / "swarm_assets" / "b1").as_posix()},
    "evidence_root": EVIDENCE.as_posix(),
    "evidence": {
        "preaudit": identity(preaudit_path),
        "draft_extraction_manifest": identity(draft_path),
        "post_adjudication_identities": identity(post_path),
        "figure_crop_manifest": identity(figure_path),
        "source_original_findings": identity(source_original_path),
        "independent_p126_source_crops": scoped["independent_source_crops"],
    },
    "method": {
        "reconstruction": "Created all 32 absent canonical language leaves from the exact complete monolith spans, then treated every extracted byte as a draft requiring primary-source adjudication.",
        "source": "Viewed all sixteen assigned registered scan pages plus p112/p129 boundary pages at original detail and compared German symbol by symbol, including prose, orthography, punctuation, formulas, indices, equation numbers, emphasis, headings, references, figures, and page identity.",
        "translation": "Checked every English leaf against the source-verified German and scan for completeness, semantic fidelity, exact formula/symbol identity, punctuation affecting meaning, and translation-grammatical punctuation where English syntax differs.",
        "mathematics": "Ran 22 explicit symbolic and logical checks covering depressed polynomials, quadratic and Cardano formulas, Cayley reparameterization, biquadratic resolvent, lower-bound/minimum proof, local descent, and the root algorithm.",
        "joins": "Verified inbound p112->p113, all fifteen internal joins, and outbound p128->p129 against pinned source and both language topologies; p129 remains outside this scope and no i0154 leaf was created.",
        "figures": "Installed exact unretouched 300-dpi crops for Figures 1-3; each canonical asset is byte-identical to its pinned crop evidence.",
        "rendering": "Compiled both 16-page previews twice after final edits with pdfLaTeX, rendered every final page at 200 dpi, and inspected all 32 language pages at original detail. The final p119 EN and p126 DE repairs were rebuilt, rerendered, and rechecked.",
    },
    "counts": {
        "terminal_pages": 16,
        "canonical_language_leaves": 32,
        "terminal_status_FIXED": 16,
        "confirmed_adjudication_groups": 49,
        "corrective_or_reconstruction_groups": 47,
        "source_original_findings": 2,
        "source_original_mathematical_or_logical_findings": 1,
        "source_rasters_reviewed": 18,
        "final_render_pages_reviewed": 32,
        "mathematical_checks": 22,
        "unresolved": 0,
    },
    "defect_groups": defect_groups,
    "source_original_findings": source_original["findings"],
    "outside_boundaries": scoped["outside_boundaries"],
    "records": records,
    "validation": {
        "scoped_structure_formula_continuity": {**identity(scoped_path), "status": scoped["status"], "checks": len(scoped["checks"]), "problems": scoped["problems"], "unresolved": scoped["unresolved"]},
        "mathematical_verification": {**identity(math_path), "status": math["status"], "checks": len(math["checks"]), "failed": math["failed"], "unresolved_mathematical_defects": math["unresolved_mathematical_defects"]},
        "independent_content_review": {**identity(independent_path), "status": independent["status"], "pages_reviewed": independent["counts"]["pages_reviewed"], "candidate_dispositions": independent["counts"]["candidate_dispositions"], "unresolved_content_defects": independent["unresolved_content_defects"]},
        "de_preview": scoped["builds"]["de"],
        "en_preview": scoped["builds"]["en"],
        "visual_total": scoped["visual_review"],
    },
    "write_boundaries": {
        "canonical_leaves_written": "swarm_tex/b1/b1_i0138.tex..b1_i0153.tex and swarm_en/b1/b1_i0138.tex..b1_i0153.tex only",
        "canonical_assets_written": "swarm_assets/b1/weber-b1-fig01.png..weber-b1-fig03.png",
        "not_touched": ["volume_1_opening/CURSOR.json", "master logbook", "Git", "release artifacts", "publication artifacts", "leaves outside i0138-i0153"],
    },
    "terminal_assertion": "All sixteen assigned page pairs are terminal FIXED. Every source raster, canonical leaf, formula, boundary, source-original finding, mathematical candidate, exact figure, build, and final rendered page has a concrete disposition; unresolved=0.",
}

RECEIPT.parent.mkdir(parents=True, exist_ok=True)
RECEIPT.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "receipt": identity(RECEIPT), "counts": receipt["counts"]}, indent=2))
