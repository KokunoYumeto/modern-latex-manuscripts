from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
EVIDENCE = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening" / "evidence" / "chunk_0008"
OUTPUT = EVIDENCE / "INDEPENDENT_CONTENT_REVIEW.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def identity(path: Path) -> dict:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}


def verify(item: dict) -> Path:
    path = Path(item["path"])
    assert path.is_file() and path.stat().st_size == item["bytes"] and sha256(path) == item["sha256"], path
    return path


scoped_path = EVIDENCE / "SCOPED_VALIDATION.json"
math_path = EVIDENCE / "MATHEMATICAL_VERIFICATION.json"
post_path = EVIDENCE / "POST_ADJUDICATION_IDENTITIES.json"
figures_path = EVIDENCE / "FIGURE_CROP_MANIFEST.json"
source_original_path = EVIDENCE / "SOURCE_ORIGINAL_FINDINGS.json"
scoped = json.loads(scoped_path.read_text(encoding="utf-8"))
math = json.loads(math_path.read_text(encoding="utf-8"))
post = json.loads(post_path.read_text(encoding="utf-8"))
figures = json.loads(figures_path.read_text(encoding="utf-8"))
source_original = json.loads(source_original_path.read_text(encoding="utf-8"))

assert scoped["status"] == "PASS" and scoped["problems"] == [] and scoped["unresolved"] == 0
assert len(scoped["records"]) == 16 and len(scoped["render_records"]) == 32 and len(scoped["source_rasters"]) == 18
assert all(item["status"] == "PASS" for item in scoped["checks"])
assert math["status"] == "PASS" and math["unresolved_mathematical_defects"] == 0 and all(item["status"] == "PASS" for item in math["checks"])
assert post["status"] == "PASS" and post["counts"] == {"printed_pages": 16, "canonical_language_leaves": 32, "exact_source_assets": 3, "unresolved": 0}
assert figures["status"] == "PASS" and len(figures["figures"]) == 3 and all(item["byte_identical_crop_and_asset"] for item in figures["figures"])
assert source_original["status"] == "PASS" and source_original["source_original_findings"] == 2 and source_original["unresolved_reconstruction_defects"] == 0
for record in post["canonical_leaves"]:
    verify(record["de"])
    verify(record["en"])
for item in post["canonical_assets"]:
    verify(item)

page_findings = {
    113: ["DE equation (8) source comma restored", "DE/EN equation (9) source grouping restored", "EN radius comparison corrected", "exact scan Figure 1 installed"],
    114: ["EN epsilon_k notation and source equation x^n=1 restored", "cyclotomy and Moivre source emphasis restored"],
    115: ["EN equation (2) source comma restored", "depressed-polynomial coefficients symbolically verified"],
    116: ["quadratic and Cardano formulas source-matched and symbolically verified"],
    117: ["Cardano continuation, cube-root choice, and quotient formulas source-matched"],
    118: ["source-original cross-reference (6) preserved with explicit sic", "Cardano/nine-values emphasis restored"],
    119: ["source-original Collectet preserved with explicit sic", "EN footnote callout reattached so it cannot strand after the display", "Cayley formulas verified"],
    120: ["biquadratic symmetric data and cubic resolvent symbolically verified", "source emphasis restored"],
    121: ["EN Greek delta restored in all three occurrences", "lower-bound definition and emphasis source-matched"],
    122: ["continuity/minimum theorem translation and formula identity source-matched"],
    123: ["EN equation (6) source punctuation restored", "region-bound proof formulas source-matched"],
    124: ["EN region variable corrected from gamma to y in both inequalities", "exact scan Figure 2 installed"],
    125: ["theorem 5 emphasis restored", "minimum-to-root argument source-matched"],
    126: ["DE substituted display, (17), and (18) punctuation restored from independent scan crops", "EN punctuation retained as translation-grammatical without mathematical change", "EN q.e.d. restored", "local-descent implication verified"],
    127: ["EN false display row break removed", "EN equation (4) source punctuation restored", "Lipschitz/Dedekind emphasis restored"],
    128: ["EN equation (5) full ordering relations restored", "EN rho corrected to source varrho", "exact scan Figure 3 restored in both lanes"],
}

candidates = [
    {"id": "O8-R01", "scope": "p113 DE equation (8)", "candidate": "missing comma", "disposition": "FIXED", "evidence": "scan-139.png and canonical i0138"},
    {"id": "O8-R02", "scope": "p113 DE/EN equation (9)", "candidate": "wrong grouping delimiters", "disposition": "FIXED", "evidence": "scan-139.png; normalized formula identity PASS"},
    {"id": "O8-R03", "scope": "p113 EN prose", "candidate": "reversed radius comparison", "disposition": "FIXED", "evidence": "verified German and scan"},
    {"id": "O8-R04", "scope": "p114 EN equations (11)-(12)", "candidate": "xi notation and wrong equation epsilon_k^n=1", "disposition": "FIXED", "evidence": "scan-140.png; now epsilon_k and x^n=1"},
    {"id": "O8-R05", "scope": "p118 cross-reference", "candidate": "printed (6) apparently points to cubic equation (1)", "disposition": "SOURCE_ORIGINAL_SIC", "evidence": "scan-144.png; both lanes preserve and annotate"},
    {"id": "O8-R06", "scope": "p119 citation", "candidate": "Collectet appears misspelled", "disposition": "SOURCE_ORIGINAL_SIC", "evidence": "scan-145.png; both lanes preserve and annotate"},
    {"id": "O8-R07", "scope": "p119 EN footnote", "candidate": "callout stranded after displayed array", "disposition": "FIXED", "evidence": "final render page-07.png"},
    {"id": "O8-R08", "scope": "p121 EN", "candidate": "Greek delta translated as Latin d", "disposition": "FIXED", "evidence": "scan-147.png; all three delta occurrences"},
    {"id": "O8-R09", "scope": "p124 EN", "candidate": "region coordinate gamma conflicts with source y", "disposition": "FIXED", "evidence": "scan-150.png and Figure 2"},
    {"id": "O8-R10", "scope": "p126 DE substituted display", "candidate": "spurious comma", "disposition": "FIXED", "evidence": "independent_crop_p126_formula16_18.png"},
    {"id": "O8-R11", "scope": "p126 DE equation (17)", "candidate": "period instead of comma", "disposition": "FIXED", "evidence": "independent_crop_p126_formula17_18.png"},
    {"id": "O8-R12", "scope": "p126 DE equation (18)", "candidate": "spurious terminal period", "disposition": "FIXED", "evidence": "independent_crop_p126_formula18.png"},
    {"id": "O8-R13", "scope": "p126 EN display punctuation", "candidate": "differs from German source punctuation", "disposition": "PASS_TRANSLATION_GRAMMATICAL", "evidence": "commas/periods continue or close English syntax; formulas normalize identically"},
    {"id": "O8-R14", "scope": "p127 EN equation (3)", "candidate": "false row break after first absolute value", "disposition": "FIXED", "evidence": "scan-153.png and final render"},
    {"id": "O8-R15", "scope": "p128 EN equation (5)", "candidate": "lost ordering relations", "disposition": "FIXED", "evidence": "scan-154.png; full chain restored"},
    {"id": "O8-R16", "scope": "p128 EN prose/figure", "candidate": "rho/varrho drift and omitted Figure 3", "disposition": "FIXED", "evidence": "scan-154.png; exact source asset"},
]

page_reviews = []
for record in post["canonical_leaves"]:
    page = record["printed_page"]
    page_reviews.append({
        "printed_page": page,
        "stable_id": record["stable_id"],
        "terminal_status": "FIXED",
        "de": record["de"],
        "en": record["en"],
        "findings": page_findings[page],
        "source_review": "PASS: registered 300-dpi raster inspected at original detail.",
        "formula_translation_review": "PASS: exact tags and normalized DE/EN displayed-formula inventory verified; prose checked against source meaning.",
        "render_review": "PASS: final DE and EN page inspected at original detail with no clipping, collision, omission, or stranded material.",
        "unresolved": 0,
    })

payload = {
    "schema": "weber-opening-independent-content-review/v1",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "coverage": "Volume I printed pp.113-128 / i0138-i0153 / DE+EN",
    "status": "PASS",
    "basis": "Separate post-edit readback of all live leaves, pinned source rasters, exact figures, formula validation, symbolic mathematics, and final renders. Independent scan spot checks on p126 are pinned as three tight crops.",
    "page_reviews": page_reviews,
    "candidate_dispositions": candidates,
    "counts": {"pages_reviewed": 16, "canonical_language_leaves_rehashed": 32, "candidate_dispositions": len(candidates), "source_original_findings": 2, "unresolved_content_defects": 0},
    "post_review_closure": {
        "scoped_validation": identity(scoped_path),
        "mathematical_verification": identity(math_path),
        "post_adjudication_identities": identity(post_path),
        "figure_crop_manifest": identity(figures_path),
        "source_original_findings": identity(source_original_path),
    },
    "unresolved_content_defects": 0,
    "terminal_assertion": "Every assigned page has a terminal disposition. Every independent candidate is fixed, source-original with explicit annotation, or proved translation-grammatical; none remains pending.",
}
OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": "PASS", "output": identity(OUTPUT), "pages": len(page_reviews), "candidates": len(candidates), "unresolved": 0}, indent=2))
