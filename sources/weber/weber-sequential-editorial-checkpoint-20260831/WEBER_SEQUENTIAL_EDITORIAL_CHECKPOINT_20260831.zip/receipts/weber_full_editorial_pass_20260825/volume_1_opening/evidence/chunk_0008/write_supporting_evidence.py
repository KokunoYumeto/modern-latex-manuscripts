from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
EVIDENCE = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening" / "evidence" / "chunk_0008"
DE_ROOT = WORK / "swarm_tex" / "b1"
EN_ROOT = WORK / "swarm_en" / "b1"
ASSETS = WORK / "swarm_assets" / "b1"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def identity(path: Path) -> dict:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}


created = datetime.now(timezone.utc).isoformat()
figure_specs = [
    (1, 113, "scan-139.png", "figure_01_source_crop_tight.png", "weber-b1-fig01.png", {"x": 35, "y": 1260, "width": 610, "height": 605}),
    (2, 124, "scan-150.png", "figure_02_source_crop_tight.png", "weber-b1-fig02.png", {"x": 125, "y": 635, "width": 800, "height": 790}),
    (3, 128, "scan-154.png", "figure_03_source_crop_tight.png", "weber-b1-fig03.png", {"x": 140, "y": 1100, "width": 790, "height": 800}),
]
figures = []
for number, page, scan_name, crop_name, asset_name, rectangle in figure_specs:
    scan = EVIDENCE / scan_name
    crop = EVIDENCE / crop_name
    asset = ASSETS / asset_name
    assert scan.is_file() and crop.is_file() and asset.is_file()
    assert crop.read_bytes() == asset.read_bytes()
    figures.append({
        "figure": number,
        "printed_page": page,
        "stable_leaf": f"i{page + 25:04d}",
        "registered_scan_raster": identity(scan),
        "crop_rectangle_px_at_300_dpi": rectangle,
        "evidence_crop": identity(crop),
        "canonical_asset": identity(asset),
        "byte_identical_crop_and_asset": True,
        "visual_review": "PASS: tight crop inspected at original detail; labels, strokes, axes, and source defects are preserved without prose intrusion.",
    })

figure_payload = {
    "schema": "weber-opening-exact-figure-crops/v1",
    "created_utc": created,
    "coverage": "Volume I printed pp.113, 124, 128 / figures 1-3",
    "authority": "Each asset is an exact, unretouched 300-dpi crop of the pinned registered scan raster. No redrawing, OCR, denoising, or semantic alteration was applied.",
    "status": "PASS",
    "figures": figures,
    "unresolved": 0,
}
figure_output = EVIDENCE / "FIGURE_CROP_MANIFEST.json"
figure_output.write_text(json.dumps(figure_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

leaves = []
for page in range(113, 129):
    leaf = page + 25
    leaves.append({
        "printed_page": page,
        "stable_id": f"i{leaf:04d}",
        "de": identity(DE_ROOT / f"b1_i{leaf:04d}.tex"),
        "en": identity(EN_ROOT / f"b1_i{leaf:04d}.tex"),
    })
identity_payload = {
    "schema": "weber-opening-post-adjudication-identities/v1",
    "created_utc": created,
    "coverage": "Volume I printed pp.113-128 / i0138-i0153",
    "status": "PASS",
    "canonical_leaves": leaves,
    "canonical_assets": [identity(ASSETS / f"weber-b1-fig{number:02d}.png") for number in (1, 2, 3)],
    "counts": {"printed_pages": 16, "canonical_language_leaves": 32, "exact_source_assets": 3, "unresolved": 0},
}
identity_output = EVIDENCE / "POST_ADJUDICATION_IDENTITIES.json"
identity_output.write_text(json.dumps(identity_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

anomaly_payload = {
    "schema": "weber-opening-source-original-findings/v1",
    "created_utc": created,
    "coverage": "Volume I printed pp.113-128 / i0138-i0153",
    "status": "PASS",
    "policy": "Source-original anomalies are preserved in both canonical language lanes and explicitly annotated in LaTeX comments and this evidence record; they are not silently emended or counted as unresolved reconstruction defects.",
    "findings": [
        {
            "id": "O8-SIC-001",
            "printed_page": 118,
            "stable_leaf": "i0143",
            "class": "source-original mathematical cross-reference",
            "registered_reading": "the three roots of the cubic equation (6)",
            "adjudication": "PRESERVED_WITH_SIC",
            "explanation": "The cubic equation on p.116 is numbered (1); (6) on p.118 is nevertheless the exact registered reading. Both DE and EN preserve (6) and carry an explicit source-original annotation.",
            "de": identity(DE_ROOT / "b1_i0143.tex"),
            "en": identity(EN_ROOT / "b1_i0143.tex"),
            "source": identity(EVIDENCE / "scan-144.png"),
        },
        {
            "id": "O8-SIC-002",
            "printed_page": 119,
            "stable_leaf": "i0144",
            "class": "source-original bibliographic spelling",
            "registered_reading": "Collectet mathematical papers",
            "adjudication": "PRESERVED_WITH_SIC",
            "explanation": "The apparent spelling error is printed in the registered scan. Both DE and EN preserve Collectet and explicitly annotate it rather than silently modernizing to Collected.",
            "de": identity(DE_ROOT / "b1_i0144.tex"),
            "en": identity(EN_ROOT / "b1_i0144.tex"),
            "source": identity(EVIDENCE / "scan-145.png"),
        },
    ],
    "source_original_findings": 2,
    "source_original_mathematical_or_logical_findings": 1,
    "unresolved_reconstruction_defects": 0,
}
anomaly_output = EVIDENCE / "SOURCE_ORIGINAL_FINDINGS.json"
anomaly_output.write_text(json.dumps(anomaly_payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(json.dumps({
    "status": "PASS",
    "figure_manifest": identity(figure_output),
    "post_adjudication_identities": identity(identity_output),
    "source_original_findings": identity(anomaly_output),
}, indent=2))
