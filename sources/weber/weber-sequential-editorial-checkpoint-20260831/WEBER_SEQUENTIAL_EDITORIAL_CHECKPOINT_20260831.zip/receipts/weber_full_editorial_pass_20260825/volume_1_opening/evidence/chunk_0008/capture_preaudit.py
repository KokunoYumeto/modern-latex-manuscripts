from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
EVIDENCE = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening" / "evidence" / "chunk_0008"
SOURCE = Path(r"registered-source/Weber_Algebra_Bd1_IA.pdf")
DE_BASELINE = WORK / "github_publish_20260823_resealed" / "sources" / "weber" / "weber-volume1-german-complete-working-source-repair-20260731" / "source" / "Weber_VolumeI_German_Complete_Working_SourceRepair_20260731.tex"
EN_BASELINE = WORK / "github_publish_20260823_resealed" / "sources" / "weber" / "Weber_Cumulative_ThreeVolumes_Batch84_Vol1_RecursiveAudit_p7_p14_20260604" / "02_cumulative_work" / "volume_1_complete_repaired_through_batch84" / "english" / "tex" / "weber_volume1_cumulative_complete_batch84_english_translation.tex"
DE_ROOT = WORK / "swarm_tex" / "b1"
EN_ROOT = WORK / "swarm_en" / "b1"
ASSET_ROOT = WORK / "swarm_assets" / "b1"


def identity(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "path": path.as_posix(),
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest().upper(),
    }


assigned = []
for stable in range(138, 154):
    de = DE_ROOT / f"b1_i{stable:04d}.tex"
    en = EN_ROOT / f"b1_i{stable:04d}.tex"
    assigned.append(
        {
            "stable_leaf": f"i{stable:04d}",
            "printed_page": stable - 25,
            "de": identity(de) if de.exists() else {"path": de.as_posix(), "state": "ABSENT"},
            "en": identity(en) if en.exists() else {"path": en.as_posix(), "state": "ABSENT"},
        }
    )

manifest = {
    "schema": "weber-opening-preaudit/v1",
    "captured_utc": datetime.now(timezone.utc).isoformat(),
    "scope": {
        "volume": 1,
        "printed_pages": "113-128",
        "stable_leaves": "i0138-i0153",
        "mapping": "printed p maps to stable i(p+25); PDF one-based page p+26",
    },
    "authority": "The registered scan is the sole primary authority. Baselines are complete text reservoirs, never substitutes for source comparison.",
    "registered_source": identity(SOURCE),
    "baselines": {"de": identity(DE_BASELINE), "en": identity(EN_BASELINE)},
    "source_rasters": [identity(EVIDENCE / f"scan-{page}.png") for page in range(138, 156)],
    "source_text_locator": identity(EVIDENCE / "source_scan_pages_138_155.txt"),
    "assigned_canonical_state": assigned,
    "inbound_existing": {
        "stable_leaf": "i0137",
        "printed_page": 112,
        "de": identity(DE_ROOT / "b1_i0137.tex"),
        "en": identity(EN_ROOT / "b1_i0137.tex"),
    },
    "outbound_state": {
        "stable_leaf": "i0154",
        "printed_page": 129,
        "de": identity(DE_ROOT / "b1_i0154.tex") if (DE_ROOT / "b1_i0154.tex").exists() else {"path": (DE_ROOT / "b1_i0154.tex").as_posix(), "state": "ABSENT"},
        "en": identity(EN_ROOT / "b1_i0154.tex") if (EN_ROOT / "b1_i0154.tex").exists() else {"path": (EN_ROOT / "b1_i0154.tex").as_posix(), "state": "ABSENT"},
        "adjudication_basis": "registered p.129 raster plus exact p.129 baseline anchor; no outbound canonical leaf existed at capture time",
    },
    "figure_asset_state": [
        {"path": (ASSET_ROOT / f"weber-b1-fig{number:02d}.png").as_posix(), "state": "ABSENT"}
        for number in range(1, 4)
    ],
}

target = EVIDENCE / "PREAUDIT_IDENTITIES.json"
if target.exists():
    raise RuntimeError(f"refusing to overwrite pre-audit evidence: {target}")
target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps(identity(target), indent=2))
