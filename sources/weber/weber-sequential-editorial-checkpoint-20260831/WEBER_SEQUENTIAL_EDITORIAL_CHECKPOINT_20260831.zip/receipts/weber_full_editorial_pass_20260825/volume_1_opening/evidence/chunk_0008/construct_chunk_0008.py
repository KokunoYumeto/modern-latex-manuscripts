from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
EVIDENCE = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening" / "evidence" / "chunk_0008"
DE_BASELINE = WORK / "github_publish_20260823_resealed" / "sources" / "weber" / "weber-volume1-german-complete-working-source-repair-20260731" / "source" / "Weber_VolumeI_German_Complete_Working_SourceRepair_20260731.tex"
EN_BASELINE = WORK / "github_publish_20260823_resealed" / "sources" / "weber" / "Weber_Cumulative_ThreeVolumes_Batch84_Vol1_RecursiveAudit_p7_p14_20260604" / "02_cumulative_work" / "volume_1_complete_repaired_through_batch84" / "english" / "tex" / "weber_volume1_cumulative_complete_batch84_english_translation.tex"
DE_ROOT = WORK / "swarm_tex" / "b1"
EN_ROOT = WORK / "swarm_en" / "b1"
ASSET_ROOT = WORK / "swarm_assets" / "b1"


# Each seventeenth anchor is the first source token on printed p.129 and is
# used exclusively as the outbound boundary of this p.113--128 assignment.
DE_ANCHORS = [
    "\\begin{equation}\n x=\\sqrt[n]{r}\\left(\\cos\\frac{\\varphi}{n}+i\\sin\\frac{\\varphi}{n}\\right)\n\\tag{7}",
    "\\begin{equation}\n \\varepsilon_k=\\cos\\frac{2k\\pi}{n}+i\\sin\\frac{2k\\pi}{n}\n\\tag{11}",
    "\\begin{equation}\nf(x)=x^n+a_1x^{n-1}+a_2x^{n-2}+\\cdots+a_n\n\\tag{1}",
    "\\[\n y=\\pm\\sqrt{-a},",
    "Wir geben der $\\sqrt R$ eines der beiden Zeichen",
    "\\[\n y=\\frac{-(u+v)\\pm\\sqrt{-3(u+v)^2+12uv}}{2}",
    "Dies ist ein Mangel der \\gesperrt{Cardanischen Formel}",
    "\\[\n 2y=u+v+w",
    "\\section*{\\S.\\,38. Beweis des Fundamentalsatzes.}",
    "nur endliche Werthe hat, und die ausserdem in diesem Intervall",
    "Ist also $f(b)>g$, so definirt der Schnitt",
    "\\gesperrt{wird, dass also die untere Grenze auch hier ein Minimum ist.}",
    "Es ist nun ferner leicht einzusehen, dass $\\gamma=g$",
    "von Null verschieden; es mögen also $f'(\\alpha),f''(\\alpha),\\ldots,f^{(m-1)}(\\alpha)$",
    "\\section*{\\S.\\,39. Algorithmus zur Berechnung der Wurzeln.}",
    "sei, oder wenigstens keinen der anderen an Grösse übertrifft.",
    "\\begin{equation}\n f(\\alpha+h)=f(\\alpha)+h f'(\\alpha)+\\frac{h^2}{1\\cdot2}f''(\\alpha)+\\cdots\n\\tag{6}",
]

EN_ANCHORS = [
    "\\begin{equation}\n x=\\sqrt[n]{r}\\left(\\cos\\frac{\\varphi}{n}+i\\sin\\frac{\\varphi}{n}\\right)\n\\tag{7}",
    "\\begin{equation}\n \\xi_k=\\cos\\frac{2k\\pi}{n}+i\\sin\\frac{2k\\pi}{n}.\n\\tag{11}",
    "\\begin{equation}\nf(x)=x^n+a_1x^{n-1}+a_2x^{n-2}+\\cdots+a_n\n\\tag{1}",
    "\\[\n y=\\pm\\sqrt{-a},",
    "We give $\\sqrt R$ one of the two signs",
    "\\[\n y=\\frac{-(u+v)\\pm\\sqrt{-3(u+v)^2+12uv}}{2}",
    "This is a defect of Cardano's formula",
    "\\[\n 2y=u+v+w",
    "\\section*{\\S\\,38. Proof of the fundamental theorem.}",
    "and which is also continuous in this interval.",
    "If therefore $f(b)>g$, the cut",
    "so that here also the lower bound is a minimum.",
    "It is now further easy to see that $\\gamma=g$",
    "different from zero. Thus suppose that $f'(\\alpha),f''(\\alpha),\\ldots,f^{(m-1)}(\\alpha)$",
    "\\section*{\\S\\,39. Algorithm for the calculation of the roots.}",
    "or at least exceeds none of the others.",
    "\\begin{equation}\n f(\\alpha+h)=f(\\alpha)+h f'(\\alpha)+\\frac{h^2}{1\\cdot2}f''(\\alpha)+\\cdots\n\\tag{6}",
]


DE_SECTIONS = {
    r"\section*{\S.\,34. Befreiung einer Gleichung vom zweiten Gliede.}": (34, "Befreiung einer Gleichung vom zweiten Gliede."),
    r"\section*{\S.\,35. Cubische Gleichungen. Cardanische Formel.}": (35, "Cubische Gleichungen. Cardanische Formel."),
    r"\section*{\S.\,36. Der Cayley'sche Ausdruck der Cardanischen Formel.}": (36, "Der Cayley'sche Ausdruck der Cardanischen Formel."),
    r"\section*{\S.\,37. Die biquadratische Gleichung.}": (37, "Die biquadratische Gleichung."),
    r"\section*{\S.\,38. Beweis des Fundamentalsatzes.}": (38, "Beweis des Fundamentalsatzes."),
    r"\section*{\S.\,39. Algorithmus zur Berechnung der Wurzeln.}": (39, "Algorithmus zur Berechnung der Wurzeln."),
}

EN_SECTIONS = {
    r"\section*{\S\,34. Removal of the second term of an equation.}": (34, "Removal of the Second Term of an Equation."),
    r"\section*{\S\,35. Cubic equations. Cardano's formula.}": (35, "Cubic Equations. Cardano's Formula."),
    r"\section*{\S\,36. Cayley's expression for Cardano's formula.}": (36, "Cayley's Expression for Cardano's Formula."),
    r"\section*{\S\,37. The biquadratic equation.}": (37, "The Biquadratic Equation."),
    r"\section*{\S\,38. Proof of the fundamental theorem.}": (38, "Proof of the Fundamental Theorem."),
    r"\section*{\S\,39. Algorithm for the calculation of the roots.}": (39, "Algorithm for the Calculation of the Roots."),
}

CONTINUITY = {
    113: (True, True),
    114: (True, True),
    115: (True, True),
    116: (True, False),
    117: (False, True),
    118: (True, False),
    119: (False, True),
    120: (True, False),
    121: (False, True),
    122: (True, False),
    123: (False, True),
    124: (True, False),
    125: (False, True),
    126: (True, False),
    127: (False, True),
    128: (True, True),
}


def identity(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"path": path.as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest().upper()}


def locate(text: str, anchors: list[str]) -> list[int]:
    positions: list[int] = []
    cursor = 0
    for anchor in anchors:
        found = text.find(anchor, cursor)
        if found < 0:
            raise RuntimeError(f"anchor not found after offset {cursor}: {anchor!r}")
        positions.append(found)
        cursor = found + len(anchor)
    return positions


def section_block(number: int, title: str) -> str:
    return (
        "\\begin{center}\n"
        f"{{\\large \\S.\\ {number}.}}\n\n"
        "\\vspace{0.5em}\n"
        f"{{\\large\\gesperrt{{{title}}}}}\n"
        "\\end{center}"
    )


def normalize_sections(text: str, language: str) -> str:
    mappings = DE_SECTIONS if language == "de" else EN_SECTIONS
    for source, (number, title) in mappings.items():
        text = text.replace(source, section_block(number, title))
    return text.replace("\\clearpage\n", "")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one occurrence, found {count}")
    return text.replace(old, new, 1)


def replace_regex_once(text: str, pattern: str, replacement: str, label: str) -> str:
    result, count = re.subn(pattern, lambda _match: replacement, text, count=1, flags=re.DOTALL)
    if count != 1:
        raise RuntimeError(f"{label}: expected exactly one regex occurrence, found {count}")
    return result


def replace_figure(text: str, figure: int) -> str:
    if figure == 1:
        pattern = r"\\begin\{center\}\s*\\begin\{tikzpicture\}\[scale=0\.88.*?\\end\{tikzpicture\}\\\\\[-0\.2em\]\s*\{\\small Fig\. 1\.\}\s*\\end\{center\}"
        width = "0.50"
    elif figure == 2:
        pattern = r"\\begin\{center\}\{\\small Fig\. 2\.\}\\end\{center\}\s*\\begin\{center\}\s*\\begin\{tikzpicture\}\[scale=1\.0\].*?\\end\{tikzpicture\}\s*\\end\{center\}"
        width = "0.62"
    elif figure == 3:
        pattern = r"\\begin\{center\}\s*\{\\small Fig\. 3\.\}\\\\\[-0\.2em\]\s*\\begin\{tikzpicture\}\[scale=0\.95.*?\\end\{tikzpicture\}\s*\\end\{center\}"
        width = "0.58"
    else:
        raise ValueError(figure)
    replacement = (
        f"% Exact 300-dpi crop from the registered Volume-I scan, printed Fig. {figure}.\n"
        f"\\weberfigureimage{{weber-b1-fig{figure:02d}.png}}{{{width}}}"
    )
    return replace_regex_once(text, pattern, replacement, f"figure {figure} replacement")


def correct_de(page: int, text: str) -> str:
    if page == 113:
        text = replace_once(
            text,
            r"x_k=\sqrt[n]{r}\left(\cos\frac{\varphi+2k\pi}{n}+i\sin\frac{\varphi+2k\pi}{n}\right),",
            r"x_k=\sqrt[n]{r}\left[\cos\left(\frac{\varphi+2k\pi}{n}\right)+i\sin\left(\frac{\varphi+2k\pi}{n}\right)\right],",
            "DE p113 formula (9) grouping",
        )
        text = replace_figure(text, 1)
    elif page == 118:
        text = replace_once(
            text,
            "so erhält man die drei Wurzeln der cubischen Gleichung (6)\n",
            "so erhält man die drei Wurzeln der cubischen Gleichung (6)\n% [sic] Source-original mathematical cross-reference: the printed text says (6), although the cubic equation itself is (1).\n",
            "DE p118 source-original cross-reference annotation",
        )
    elif page == 124:
        text = replace_figure(text, 2)
    elif page == 125:
        text = replace_once(
            text,
            "5. Wenn $\\alpha$ irgend ein Werth von $x$ ist, für den $f(\\alpha)$ von Null verschieden ist, so lässt sich $h$ so annehmen, dass",
            "5. \\gesperrt{Wenn $\\alpha$ irgend ein Werth von $x$ ist, für den $f(\\alpha)$ von Null verschieden ist, so lässt sich $h$ so annehmen, dass}",
            "DE p125 theorem-5 first emphasis span",
        )
        text = replace_once(text, "\\end{equation}\nausfällt.", "\\end{equation}\n\\gesperrt{ausfällt.}", "DE p125 theorem-5 final emphasis span")
    elif page == 126:
        text = replace_once(
            text,
            "+\\cdots\\right),\n\\]",
            "+\\cdots\\right)\n\\]",
            "DE p126 unnumbered substituted display source punctuation",
        )
        text = replace_once(
            text,
            "+\\cdots\\right|.\n\\tag{17}",
            "+\\cdots\\right|,\n\\tag{17}",
            "DE p126 equation (17) source comma",
        )
        text = replace_once(
            text,
            "|f(\\alpha+h)|<|f(\\alpha)|.\\tag{18}",
            "|f(\\alpha+h)|<|f(\\alpha)|\\tag{18}",
            "DE p126 equation (18) no source punctuation",
        )
    elif page == 127:
        text = replace_once(text, "von Lipschitz herrührt", "von \\gesperrt{Lipschitz} herrührt", "DE p127 Lipschitz emphasis")
        text = replace_once(text, "von Dedekind)", "von \\gesperrt{Dedekind})", "DE p127 Dedekind emphasis")
    elif page == 128:
        text = replace_once(text, "dass ausserhalb dieses Gebietes der absolute Werth", "dass \\gesperrt{ausserhalb} dieses Gebietes der absolute Werth", "DE p128 outside emphasis")
        text = replace_once(text, "immer grösser als $a$ ist", "immer \\gesperrt{grösser} als $a$ ist", "DE p128 greater emphasis")
        text = replace_figure(text, 3)
    return text


def correct_en(page: int, text: str) -> str:
    if page == 113:
        text = replace_once(
            text,
            r"x_k=\sqrt[n]{r}\left(\cos\frac{\varphi+2k\pi}{n}+i\sin\frac{\varphi+2k\pi}{n}\right)",
            r"x_k=\sqrt[n]{r}\left[\cos\left(\frac{\varphi+2k\pi}{n}\right)+i\sin\left(\frac{\varphi+2k\pi}{n}\right)\right],",
            "EN p113 formula (9) grouping and punctuation",
        )
        text = replace_once(
            text,
            "The radius $\\sqrt[n]{r}$ is smaller or larger than $r$ according as $r$ is smaller or larger than $1$.",
            "The radius $\\sqrt[n]{r}$ is greater or smaller than $r$ according as $r$ is smaller or greater than $1$.",
            "EN p113 reversed radius comparison",
        )
        text = replace_figure(text, 1)
    elif page == 114:
        text = replace_once(
            text,
            "\\begin{equation}\n \\xi_k=\\cos\\frac{2k\\pi}{n}+i\\sin\\frac{2k\\pi}{n}.\n\\tag{11}\n\\end{equation}\nThe magnitudes $\\xi_k$,\n\\begin{equation}\n \\xi_k^n=1,\n\\tag{12}\n\\end{equation}\nare roots of the equation $x^n=1$ and are called the $n$th roots of unity.",
            "\\begin{equation}\n \\varepsilon_k=\\cos\\frac{2k\\pi}{n}+i\\sin\\frac{2k\\pi}{n}.\n\\tag{11}\n\\end{equation}\nThe quantities $\\varepsilon_k$ are roots of the equation\n\\begin{equation}\n x^n=1,\n\\tag{12}\n\\end{equation}\nand are called the $n$th \\gesperrt{roots of unity}.",
            "EN p114 equations (11)-(12) source reconstruction",
        )
        text = text.replace("$\\xi_k$", "$\\varepsilon_k$")
        text = replace_once(text, "subject of the theory of cyclotomy", "subject of the \\gesperrt{theory of cyclotomy}", "EN p114 cyclotomy emphasis")
        text = replace_once(text, "by Moivre's theorem", "by \\gesperrt{Moivre's} theorem", "EN p114 Moivre emphasis")
        text = text.replace(" \\xi_k=\\varepsilon^k,", " \\varepsilon_k=\\varepsilon^k,")
    elif page == 115:
        text = replace_once(text, "x=y-\\frac{a_1}{n}\n\\tag{2}", "x=y-\\frac{a_1}{n},\n\\tag{2}", "EN p115 equation (2) punctuation")
    elif page == 118:
        text = replace_once(text, "three roots of the cubic equation (1)\n", "three roots of the cubic equation (6)\n% [sic] Source-original mathematical cross-reference: the printed text says (6), although the cubic equation itself is (1).\n", "EN p118 source-original cross-reference")
        text = replace_once(text, "is called Cardano's formula.", "is called \\gesperrt{Cardano's formula}.", "EN p118 Cardano emphasis")
        text = replace_once(text, "has nine different values.", "has \\gesperrt{nine different} values.", "EN p118 nine-values emphasis")
    elif page == 119:
        text = replace_once(text, "a defect of Cardano's formula", "a defect of \\gesperrt{Cardano's formula}", "EN p119 Cardano emphasis")
        text = replace_once(text, "Cayley remedied this defect", "\\gesperrt{Cayley} remedied this defect", "EN p119 Cayley emphasis")
        text = replace_once(text, "not nine but only the three values", "not nine but \\gesperrt{only the three values}", "EN p119 three-values emphasis")
        text = replace_once(
            text,
            "\\footnote{Cayley, Phil. Mag. vol. XXI, 1861. Collected mathematical papers, vol. V, No. 310.}",
            "\\footnote{\\gesperrt{Cayley}, Phil. Mag. vol. XXI, 1861. Collectet mathematical papers vol. V, No. 310.}% [sic] The registered source prints ‘Collectet’; preserved as a source-original bibliographic anomaly.",
            "EN p119 source-original citation spelling",
        )
        text = replace_once(
            text,
            "\\gesperrt{only the three values}",
            "\\gesperrt{only the three values}\\footnotemark",
            "EN p119 source-backed footnote callout placement",
        )
        text = replace_once(
            text,
            "\\footnote{\\gesperrt{Cayley}, Phil. Mag. vol. XXI, 1861. Collectet mathematical papers vol. V, No. 310.}% [sic] The registered source prints ‘Collectet’; preserved as a source-original bibliographic anomaly.",
            "\\footnotetext{\\gesperrt{Cayley}, Phil. Mag. vol. XXI, 1861. Collectet mathematical papers vol. V, No. 310.}% [sic] The registered source prints ‘Collectet’; preserved as a source-original bibliographic anomaly. The callout is attached to the translated phrase introducing the three displayed values so it cannot strand after the display.",
            "EN p119 footnote text without a stranded post-display callout",
        )
        text = replace_once(text, "used in solving the cubic equation by Cardano's formula", "used in solving the cubic equation by \\gesperrt{Cardano's formula}", "EN p119 Cardano emphasis in section 37")
    elif page == 120:
        text = replace_once(text, "called a cubic resolvent", "called a \\gesperrt{cubic resolvent}", "EN p120 resolvent emphasis")
    elif page == 121:
        text = replace_once(text, "proof of the fundamental theorem of algebra", "proof of the \\gesperrt{fundamental theorem of algebra}", "EN p121 fundamental-theorem emphasis")
        text = replace_once(
            text,
            "1. If $S$ denotes an arbitrary system of real numbers all greater than a certain positive or negative number $C$ (that is, a system which contains no infinitely negative numbers), then there exists a lower bound for the numbers $S$.",
            "1. \\gesperrt{If $S$ denotes an arbitrary system of real numbers all greater than a certain positive or negative number $C$ (that is, a system which contains no infinitely negative numbers), then there exists a lower bound for the numbers $S$.}",
            "EN p121 theorem 1 emphasis",
        )
        text = replace_once(text, "By a lower bound $g$", "By a \\gesperrt{lower bound} $g$", "EN p121 lower-bound definition emphasis")
        text = text.replace("if $d$ is an arbitrarily given positive quantity", "if $\\delta$ is an arbitrarily given positive quantity")
        text = text.replace("between $g$ and $g+d$", "between $g$ and $g+\\delta$")
        text = text.replace("however small $d$ may be", "however small $\\delta$ may be")
        text = replace_once(text, "marks of the lower bound.", "marks of the \\gesperrt{lower bound}.", "EN p121 lower-bound characteristic emphasis")
        text = replace_once(
            text,
            "2. If $S'$ is a part of $S$, then the numbers $S'$ also have a lower bound $g'$, and this is either equal to $g$ or greater than $g$.",
            "2. \\gesperrt{If $S'$ is a part of $S$, then the numbers $S'$ also have a lower bound $g'$, and this is either equal to $g$ or greater than $g$.}",
            "EN p121 theorem 2 emphasis",
        )
    elif page == 122:
        text = replace_once(text, "which is also continuous", "which is also \\gesperrt{continuous}", "EN p122 continuity emphasis")
        text = replace_once(text, "there is, by 1., a lower bound $g$", "there is, by 1., a \\gesperrt{lower bound} $g$", "EN p122 lower-bound existence emphasis")
        text = replace_once(
            text,
            "3. The function $f(x)$ assumes the value $g$ for some value $\\xi$ of the interval, so that the lower bound becomes a minimum of the function $f(x)$ in the interval.",
            "3. \\gesperrt{The function $f(x)$ assumes the value $g$ for some value $\\xi$ of the interval, so that the lower bound becomes a minimum of the function $f(x)$ in the interval.}",
            "EN p122 theorem 3 emphasis",
        )
        text = replace_once(text, "The proof is as follows. By 2., the lower bound", "The proof is as follows. By 2., the \\gesperrt{lower bound}", "EN p122 proof lower-bound emphasis")
        text = replace_once(text, "and hence the lower bound of $f(x)$", "and hence the \\gesperrt{lower bound} of $f(x)$", "EN p122 local lower-bound emphasis")
        text = text.replace("if the lower bound of $f(x)$", "if the \\gesperrt{lower bound} of $f(x)$")
        text = text.replace("if the lower bound in the interval", "if the \\gesperrt{lower bound} in the interval")
        text = text.replace("so that their lower bound is equal", "so that their \\gesperrt{lower bound} is equal")
        text = text.replace("the lower bound is also greater", "the \\gesperrt{lower bound} is also greater")
        text = text.replace("the lower bound is greater than $g$, contrary", "the \\gesperrt{lower bound} is greater than $g$, contrary")
    elif page == 123:
        text = text.replace("hence their lower bound is greater", "hence their \\gesperrt{lower bound} is greater")
        text = text.replace("the lower bound of $f(x)$ in the whole interval", "the \\gesperrt{lower bound} of $f(x)$ in the whole interval")
        text = replace_once(text, "there is a lower bound $g$ for the values of $X$", "there is a \\gesperrt{lower bound} $g$ for the values of $X$", "EN p123 lower-bound existence emphasis")
        text = replace_once(
            text,
            "4. There exists a value $\\xi$ of $x$ in the interior of the region $(R)$ such that",
            "4. \\gesperrt{There exists a value $\\xi$ of $x$ in the interior of the region $(R)$ such that}",
            "EN p123 theorem 4 opening emphasis",
        )
        text = replace_once(text, " |f(\\xi)|=g,", " |f(\\xi)|=g", "EN p123 equation (6) source punctuation")
    elif page == 124:
        text = replace_once(text, "so that here also the lower bound is a minimum.", "\\gesperrt{so that here also the lower bound is a minimum.}", "EN p124 theorem 4 closing emphasis")
        text = text.replace("The lower bound of $X$", "The \\gesperrt{lower bound} of $X$")
        text = text.replace("if the lower bound of $X$", "if the \\gesperrt{lower bound} of $X$")
        text = text.replace("that the lower bound of $X$", "that the \\gesperrt{lower bound} of $X$")
        text = replace_once(text, "in the region $(P,\\gamma)$ is greater than $g$ if $\\gamma<\\eta$", "in the region $(P,y)$ is greater than $g$ if $y<\\eta$", "EN p124 wrong region variable")
        text = replace_once(text, "if $\\gamma>\\eta$", "if $y>\\eta$", "EN p124 second wrong region variable")
        text = replace_figure(text, 2)
    elif page == 125:
        text = text.replace("is the lower bound of all values", "is the \\gesperrt{lower bound} of all values")
        text = text.replace("Consequently the lower bound of $X$", "Consequently the \\gesperrt{lower bound} of $X$")
        text = text.replace("Since now the lower bound of $X$", "Since now the \\gesperrt{lower bound} of $X$")
        text = replace_once(
            text,
            "5. If $\\alpha$ is any value of $x$ for which $f(\\alpha)$ is different from zero, then $h$ can be chosen so that",
            "5. \\gesperrt{If $\\alpha$ is any value of $x$ for which $f(\\alpha)$ is different from zero, then $h$ can be chosen so that}",
            "EN p125 theorem 5 opening emphasis",
        )
        text = replace_once(text, "\\end{equation}\nresults.", "\\end{equation}\n\\gesperrt{results.}", "EN p125 theorem 5 closing emphasis")
    elif page == 126:
        text = replace_once(text, "\\end{equation}\nThus the proof", "\\end{equation}\n\\noindent\\hfill q.e.d.\n\nThus the proof", "EN p126 omitted source proof marker")
    elif page == 127:
        text = replace_once(text, "due in its essentials to Lipschitz", "due in its essentials to \\gesperrt{Lipschitz}", "EN p127 Lipschitz emphasis")
        text = replace_once(text, "communication of Dedekind)", "communication of \\gesperrt{Dedekind})", "EN p127 Dedekind emphasis")
        text = replace_once(text, " |f(\\beta_1)|,\\\\ |f(\\beta_2)|,\\ldots, |f(\\beta_{n-1})|,", " |f(\\beta_1)|,\\ |f(\\beta_2)|,\\ldots, |f(\\beta_{n-1})|,", "EN p127 equation (3) stray row break")
        text = replace_once(text, " b_1,b_2,\\ldots,b_{n-1},\n\\tag{4}", " b_1,b_2,\\ldots,b_{n-1}\n\\tag{4}", "EN p127 equation (4) source punctuation")
    elif page == 128:
        text = replace_once(text, " a<b_1,b_2,\\ldots,b_{n-1}.", " a<b_1\\le b_2\\le b_3\\le\\cdots\\le b_{n-1}.", "EN p128 equation (5) ordered chain")
        text = replace_once(text, "outside this domain the absolute value", "\\gesperrt{outside} this domain the absolute value", "EN p128 outside emphasis")
        text = replace_once(text, "is always greater than $a$", "is always \\gesperrt{greater} than $a$", "EN p128 greater emphasis")
        text = text.replace("\\rho_", "\\varrho_")
        insertion = "% Exact 300-dpi crop from the registered Volume-I scan, printed Fig. 3.\n\\weberfigureimage{weber-b1-fig03.png}{0.58}\n\n"
        text = replace_once(text, "We now determine a sequence of numbers\n", insertion + "We now determine a sequence of numbers\n", "EN p128 omitted source figure 3")
    return text


def write_language(baseline: Path, root: Path, anchors: list[str], language: str) -> list[dict[str, object]]:
    source = baseline.read_text(encoding="utf-8").replace("\r\n", "\n")
    positions = locate(source, anchors)
    outputs: list[dict[str, object]] = []
    for offset, printed_page in enumerate(range(113, 129)):
        body = source[positions[offset] : positions[offset + 1]].strip()
        body = normalize_sections(body, language)
        body = correct_de(printed_page, body) if language == "de" else correct_en(printed_page, body)
        inbound, outbound = CONTINUITY[printed_page]
        header = f"% !PRINTED {printed_page}\n\\weberpage{{{printed_page}}}\n"
        if inbound:
            header += "%<<CONT\n"
        if outbound:
            body += "\n%CONT>>"
        target = root / f"b1_i{printed_page + 25:04d}.tex"
        if target.exists():
            raise RuntimeError(f"refusing to overwrite existing canonical leaf: {target}")
        target.write_text(header + "\n" + body + "\n", encoding="utf-8", newline="\n")
        outputs.append(identity(target))
    return outputs


for number in range(1, 4):
    asset = ASSET_ROOT / f"weber-b1-fig{number:02d}.png"
    if not asset.exists():
        raise RuntimeError(f"required exact source crop missing: {asset}")

de_text = DE_BASELINE.read_text(encoding="utf-8").replace("\r\n", "\n")
en_text = EN_BASELINE.read_text(encoding="utf-8").replace("\r\n", "\n")
locate(de_text, DE_ANCHORS)
locate(en_text, EN_ANCHORS)

manifest = {
    "schema": "weber-opening-draft-extraction/v1",
    "coverage": "printed pp.113-128 / stable leaves i0138-i0153",
    "authority": "Registered scan is authoritative; the complete monoliths are draft text reservoirs only.",
    "de_baseline": identity(DE_BASELINE),
    "en_baseline": identity(EN_BASELINE),
    "figure_assets": [identity(ASSET_ROOT / f"weber-b1-fig{number:02d}.png") for number in range(1, 4)],
    "de_outputs": write_language(DE_BASELINE, DE_ROOT, DE_ANCHORS, "de"),
    "en_outputs": write_language(EN_BASELINE, EN_ROOT, EN_ANCHORS, "en"),
}

target = EVIDENCE / "DRAFT_EXTRACTION_MANIFEST.json"
if target.exists():
    raise RuntimeError(f"refusing to overwrite extraction evidence: {target}")
target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
print(json.dumps({"de": len(manifest["de_outputs"]), "en": len(manifest["en_outputs"]), "manifest": identity(target)}, indent=2))
