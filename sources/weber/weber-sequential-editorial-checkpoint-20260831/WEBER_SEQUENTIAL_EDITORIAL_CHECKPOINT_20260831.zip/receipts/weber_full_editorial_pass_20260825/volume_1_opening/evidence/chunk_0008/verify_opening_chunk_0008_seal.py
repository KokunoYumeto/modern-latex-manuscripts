from __future__ import annotations

import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
OPENING = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening"
EVIDENCE = OPENING / "evidence" / "chunk_0008"
RECEIPT = OPENING / "chunks" / "OPENING_CHUNK_0008_p0113_p0128.json"
OUTPUT = EVIDENCE / "FINAL_SEAL_VERIFICATION.json"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def identity(path: Path) -> dict:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}


def verify(item: dict) -> Path:
    path = Path(item["path"])
    assert path.is_file(), path
    assert path.stat().st_size == item["bytes"], path
    assert sha256(path) == item["sha256"], path
    return path


def load_verified(item: dict) -> tuple[Path, dict]:
    path = verify(item)
    return path, json.loads(path.read_text(encoding="utf-8"))


receipt = json.loads(RECEIPT.read_text(encoding="utf-8"))
assert receipt["schema"] == "weber-full-editorial-opening-chunk/v1"
assert receipt["status"] == "PASS"
assert receipt["chunk"] == "OPENING_CHUNK_0008"
assert receipt["coverage"]["printed_pages"] == "113-128"
assert receipt["coverage"]["stable_leaves"] == "i0138-i0153"
assert receipt["counts"] == {
    "terminal_pages": 16,
    "canonical_language_leaves": 32,
    "terminal_status_FIXED": 16,
    "confirmed_adjudication_groups": 49,
    "corrective_or_reconstruction_groups": 47,
    "source_original_findings": 2,
    "source_original_mathematical_or_logical_findings": 1,
    "source_rasters_reviewed": 18,
    "final_render_pages_reviewed": 32,
    "mathematical_checks": 22,
    "unresolved": 0,
}
verify(receipt["source"])
verify(receipt["baselines"]["de"])
verify(receipt["baselines"]["en"])

assert len(receipt["defect_groups"]) == 49
assert [item["id"] for item in receipt["defect_groups"]] == [f"O8-{index:03d}" for index in range(1, 50)]
assert sum(item["disposition"] == "SOURCE_ORIGINAL_SIC" for item in receipt["defect_groups"]) == 2
assert sum(item["disposition"] != "SOURCE_ORIGINAL_SIC" for item in receipt["defect_groups"]) == 47
assert len(receipt["source_original_findings"]) == 2
assert {item["id"] for item in receipt["source_original_findings"]} == {"O8-SIC-001", "O8-SIC-002"}

assert len(receipt["records"]) == 16
assert [item["stable_id"] for item in receipt["records"]] == [f"i{number:04d}" for number in range(138, 154)]
assert [item["printed_marker"] for item in receipt["records"]] == [str(page) for page in range(113, 129)]
canonical_identities = []
for record in receipt["records"]:
    assert record["terminal_status"] == "FIXED" and record["unresolved"] == 0
    assert record["de"]["path"].endswith(f"b1_{record['stable_id']}.tex")
    assert record["en"]["path"].endswith(f"b1_{record['stable_id']}.tex")
    verify(record["de"])
    verify(record["en"])
    canonical_identities.extend([record["de"], record["en"]])
    assert record["equation_tags"]
    assert 0 < len(record["normalized_equation_fingerprints"]) <= len(record["equation_tags"])

preaudit_path, preaudit = load_verified(receipt["evidence"]["preaudit"])
draft_path, draft = load_verified(receipt["evidence"]["draft_extraction_manifest"])
post_path, post = load_verified(receipt["evidence"]["post_adjudication_identities"])
figure_path, figures = load_verified(receipt["evidence"]["figure_crop_manifest"])
source_original_path, source_original = load_verified(receipt["evidence"]["source_original_findings"])
assert preaudit["scope"]["printed_pages"] == "113-128" and len(preaudit["source_rasters"]) == 18
for item in preaudit["source_rasters"]:
    verify(item)
assert draft["coverage"] == "printed pp.113-128 / stable leaves i0138-i0153"
assert post["status"] == "PASS" and post["counts"] == {"printed_pages": 16, "canonical_language_leaves": 32, "exact_source_assets": 3, "unresolved": 0}
assert figures["status"] == "PASS" and len(figures["figures"]) == 3
for item in figures["figures"]:
    verify(item["registered_scan_raster"])
    crop = verify(item["evidence_crop"])
    asset = verify(item["canonical_asset"])
    assert crop.read_bytes() == asset.read_bytes() and item["byte_identical_crop_and_asset"] is True
    canonical_identities.append(item["canonical_asset"])
assert source_original["status"] == "PASS" and source_original["source_original_findings"] == 2 and source_original["unresolved_reconstruction_defects"] == 0
for crop in receipt["evidence"]["independent_p126_source_crops"]:
    verify(crop)

scoped_path, scoped = load_verified(receipt["validation"]["scoped_structure_formula_continuity"])
math_path, math = load_verified(receipt["validation"]["mathematical_verification"])
independent_path, independent = load_verified(receipt["validation"]["independent_content_review"])
assert scoped["status"] == "PASS" and scoped["problems"] == [] and scoped["unresolved"] == 0
assert len(scoped["checks"]) == 382 and all(item["status"] == "PASS" for item in scoped["checks"])
assert len(scoped["records"]) == 16 and len(scoped["source_rasters"]) == 18 and len(scoped["render_records"]) == 32
for item in scoped["source_rasters"]:
    verify(item)
for item in scoped["render_records"]:
    verify(item)
    assert item["dimensions_px"] == [1654, 2339] and item["visual_review"] == "PASS"
assert scoped["visual_review"] == {"source_rasters_reviewed": 18, "final_language_pages_reviewed": 32, "unresolved_visual_flags": 0, "status": "PASS"}
assert math["status"] == "PASS" and math["failed"] == [] and len(math["checks"]) == 22 and math["unresolved_mathematical_defects"] == 0
assert all(item["status"] == "PASS" for item in math["checks"])
assert independent["status"] == "PASS" and len(independent["page_reviews"]) == 16 and len(independent["candidate_dispositions"]) == 16 and independent["unresolved_content_defects"] == 0
assert all(item["unresolved"] == 0 and item["terminal_status"] == "FIXED" for item in independent["page_reviews"])

for language in ("de", "en"):
    preview = receipt["validation"][f"{language}_preview"]
    verify(preview["master"])
    verify(preview["pdf"])
    verify(preview["log"])
    assert preview["pdf"]["pages"] == 16
    assert preview["compile"] == {"status": "PASS", "terminal_errors": 0, "overfull_hboxes": 0, "underfull_hboxes": 0, "overfull_vboxes": 0, "underfull_vboxes": 0}
    assert preview["visual_review"].startswith("PASS") and len(preview["renders"]) == 16
    for render in preview["renders"]:
        verify(render)
        assert render["visual_review"] == "PASS"

assert receipt["outside_boundaries"]["inbound"]["status"] == "PASS"
assert receipt["outside_boundaries"]["outbound"]["status"] == "PASS"
assert receipt["outside_boundaries"]["outbound"]["successor_canonical_state"] == "ABSENT"
assert not (WORK / "swarm_tex" / "b1" / "b1_i0154.tex").exists()
assert not (WORK / "swarm_en" / "b1" / "b1_i0154.tex").exists()
assert receipt["write_boundaries"]["not_touched"] == ["volume_1_opening/CURSOR.json", "master logbook", "Git", "release artifacts", "publication artifacts", "leaves outside i0138-i0153"]

aggregate = hashlib.sha256()
for item in canonical_identities:
    aggregate.update(item["path"].encode("utf-8"))
    aggregate.update(item["sha256"].encode("ascii"))
aggregate_sha256 = aggregate.hexdigest().upper()

expected_payload = {
    "schema": "weber-opening-chunk-final-seal-verification/v1",
    "status": "PASS",
    "receipt": identity(RECEIPT),
    "terminal_pages": 16,
    "canonical_language_leaves_verified": 32,
    "canonical_exact_source_assets_verified": 3,
    "source_rasters_verified": 18,
    "final_render_pages_verified": 32,
    "structural_formula_join_checks": 382,
    "mathematical_checks": 22,
    "independent_candidate_dispositions": 16,
    "source_original_findings": 2,
    "canonical_aggregate_sha256": aggregate_sha256,
    "cursor_modified": False,
    "unresolved": 0,
    "next_outside_scope": {"printed_page": 129, "stable_leaf": "i0154", "state": "deferred; canonical leaf absent"},
}

verify_existing = len(sys.argv) > 1 and sys.argv[1] == "--verify-existing"
if verify_existing:
    assert OUTPUT.is_file(), OUTPUT
    existing = json.loads(OUTPUT.read_text(encoding="utf-8"))
    for key, value in expected_payload.items():
        assert existing[key] == value, key
    assert existing["verified_utc"]
else:
    payload = {**expected_payload, "verified_utc": datetime.now(timezone.utc).isoformat()}
    OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

print(json.dumps({**expected_payload, "verification_evidence": identity(OUTPUT), "mode": "read-only verify-existing" if verify_existing else "write final seal"}, indent=2))
