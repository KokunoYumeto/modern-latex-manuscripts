from __future__ import annotations

import hashlib
import json
import re
import struct
import subprocess
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
EVIDENCE = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_1_opening" / "evidence" / "chunk_0008"
DE_ROOT = WORK / "swarm_tex" / "b1"
EN_ROOT = WORK / "swarm_en" / "b1"
ASSET_ROOT = WORK / "swarm_assets" / "b1"
OUTPUT = EVIDENCE / "SCOPED_VALIDATION.json"

PAGES = list(range(113, 129))
LEAVES = list(range(138, 154))
EXPECTED_TAGS = {
    113: ["7", "8", "9", "10"],
    114: ["11", "12"],
    115: ["1", "2", "3", "4"],
    116: ["5", "1", "2", "3", "4", "5", "6", "7"],
    117: ["8", "9", "10"],
    118: ["11", "12", "13", "1"],
    119: ["2", "3", "4", "5", "1"],
    120: ["2", "3", "4", "5"],
    121: ["1"],
    122: ["2"],
    123: ["3", "4", "5", "6"],
    124: ["7", "8", "9"],
    125: ["10", "11"],
    126: ["12", "13", "14", "15", "16", "17", "18"],
    127: ["1", "2", "3", "4"],
    128: ["5"],
}
CONTINUITY = {
    113: (True, True), 114: (True, True), 115: (True, True), 116: (True, False),
    117: (False, True), 118: (True, False), 119: (False, True), 120: (True, False),
    121: (False, True), 122: (True, False), 123: (False, True), 124: (True, False),
    125: (False, True), 126: (True, False), 127: (False, True), 128: (True, True),
}
EXPECTED_ASSETS = {
    "weber-b1-fig01.png": "F376F4517E07FF7260DAC8906EBC4E040613DA1D28625C981654F10607C31EBE",
    "weber-b1-fig02.png": "33415B44FA6D4563642387FDFAA98D6639168DEF0166F0C16D2A52FFBEC077B4",
    "weber-b1-fig03.png": "4AF7C006BFCBE8D02F53DB677A86957C9843EFBCEBD80589DB28F4F67B742FBE",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def identity(path: Path) -> dict:
    return {"path": path.as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)}


def uncommented(text: str) -> str:
    lines = []
    for line in text.splitlines():
        cut = None
        for index, char in enumerate(line):
            if char == "%" and (index == 0 or line[index - 1] != "\\"):
                cut = index
                break
        lines.append(line if cut is None else line[:cut])
    return "\n".join(lines)


def brace_balance(text: str) -> int:
    cleaned = uncommented(text)
    balance = 0
    for index, char in enumerate(cleaned):
        if index and cleaned[index - 1] == "\\":
            continue
        if char == "{":
            balance += 1
        elif char == "}":
            balance -= 1
        if balance < 0:
            return balance
    return balance


def equation_bodies(text: str) -> list[str]:
    return re.findall(r"\\begin\{equation\}(.*?)\\end\{equation\}", uncommented(text), flags=re.S)


def normalized_formula(body: str) -> str:
    body = re.sub(r"\\tag\{[^}]+\}", "", body)
    body = re.sub(r"\\label\{[^}]+\}", "", body)
    body = re.sub(r"\\text\{[^}]+\}", r"\\text{}", body)
    body = body.replace("\\left", "").replace("\\right", "")
    body = re.sub(r"\\(?:,|;|!|quad|qquad)", "", body)
    body = re.sub(r"\s+", "", body)
    return body.rstrip(",.;")


def png_dimensions(path: Path) -> tuple[int, int]:
    data = path.read_bytes()[:24]
    assert data[:8] == b"\x89PNG\r\n\x1a\n", path
    return struct.unpack(">II", data[16:24])


def pdf_pages(path: Path) -> int:
    result = subprocess.run(["pdfinfo", str(path)], check=True, capture_output=True, text=True)
    match = re.search(r"^Pages:\s+(\d+)$", result.stdout, flags=re.M)
    assert match, path
    return int(match.group(1))


problems: list[str] = []
checks: list[dict] = []


def check(name: str, condition: bool, evidence: str) -> None:
    checks.append({"name": name, "status": "PASS" if condition else "FAIL", "evidence": evidence})
    if not condition:
        problems.append(name)


preaudit_path = EVIDENCE / "PREAUDIT_IDENTITIES.json"
preaudit = json.loads(preaudit_path.read_text(encoding="utf-8"))
check("preaudit schema", preaudit["schema"] == "weber-opening-preaudit/v1", preaudit["schema"])
check("preaudit coverage", preaudit["scope"]["printed_pages"] == "113-128" and preaudit["scope"]["stable_leaves"] == "i0138-i0153", json.dumps(preaudit["scope"], ensure_ascii=False))
for item in [preaudit["registered_source"], preaudit["baselines"]["de"], preaudit["baselines"]["en"], *preaudit["source_rasters"]]:
    path = Path(item["path"])
    check(f"pinned identity {path.name}", path.is_file() and path.stat().st_size == item["bytes"] and sha256(path) == item["sha256"], item["sha256"])

records = []
for page, leaf_number in zip(PAGES, LEAVES):
    stable_id = f"i{leaf_number:04d}"
    paths = {"de": DE_ROOT / f"b1_{stable_id}.tex", "en": EN_ROOT / f"b1_{stable_id}.tex"}
    texts = {}
    language_records = {}
    for language, path in paths.items():
        check(f"{language} {stable_id} exists", path.is_file(), path.as_posix())
        text = path.read_text(encoding="utf-8")
        texts[language] = text
        check(f"{language} {stable_id} page marker", f"\\weberpage{{{page}}}" in text, str(page))
        check(f"{language} {stable_id} brace balance", brace_balance(text) == 0, str(brace_balance(text)))
        for environment in ("equation", "array", "center"):
            starts = len(re.findall(rf"\\begin\{{{environment}\}}", uncommented(text)))
            ends = len(re.findall(rf"\\end\{{{environment}\}}", uncommented(text)))
            check(f"{language} {stable_id} {environment} balance", starts == ends, f"{starts}/{ends}")
        tags = re.findall(r"\\tag\{([^}]+)\}", uncommented(text))
        check(f"{language} {stable_id} equation tags", tags == EXPECTED_TAGS[page], f"expected={EXPECTED_TAGS[page]} actual={tags}")
        start_expected, end_expected = CONTINUITY[page]
        start_actual = "%<<CONT" in text
        end_actual = "%CONT>>" in text
        check(f"{language} {stable_id} continuity markers", (start_actual, end_actual) == (start_expected, end_expected), f"expected={(start_expected, end_expected)} actual={(start_actual, end_actual)}")
        language_records[language] = {**identity(path), "tags": tags, "start_cont": start_actual, "end_cont": end_actual}
    de_formulas = [normalized_formula(body) for body in equation_bodies(texts["de"])]
    en_formulas = [normalized_formula(body) for body in equation_bodies(texts["en"])]
    check(f"DE/EN formula identity {stable_id}", de_formulas == en_formulas, json.dumps({"de": de_formulas, "en": en_formulas}, ensure_ascii=False))
    records.append({"stable_id": stable_id, "printed_page": page, "terminal_status": "FIXED", **language_records, "normalized_equation_fingerprints": [hashlib.sha256(item.encode("utf-8")).hexdigest().upper() for item in de_formulas]})

for page in PAGES[:-1]:
    end_required = CONTINUITY[page][1]
    start_required = CONTINUITY[page + 1][0]
    check(f"internal join p{page}->p{page + 1}", end_required == start_required, f"outbound={end_required} inbound={start_required}")

inbound_de = DE_ROOT / "b1_i0137.tex"
inbound_en = EN_ROOT / "b1_i0137.tex"
for language, path in (("de", inbound_de), ("en", inbound_en)):
    text = path.read_text(encoding="utf-8")
    check(f"{language} inbound i0137 marker", "%CONT>>" in text, identity(path)["sha256"])
check("outbound i0154 remains outside scope", not (DE_ROOT / "b1_i0154.tex").exists() and not (EN_ROOT / "b1_i0154.tex").exists(), "p129 is pinned by scan-155.png and both exact monolith baselines; no out-of-scope canonical leaf was created")

critical = [
    ("DE p113 equation (8) comma", " x^n=a," in (DE_ROOT / "b1_i0138.tex").read_text(encoding="utf-8"), "registered scan equation (8)"),
    ("p113 equation (9) exact delimiters DE", "\\left[\\cos\\left(" in (DE_ROOT / "b1_i0138.tex").read_text(encoding="utf-8"), "outer square brackets and inner parentheses"),
    ("p113 equation (9) exact delimiters EN", "\\left[\\cos\\left(" in (EN_ROOT / "b1_i0138.tex").read_text(encoding="utf-8"), "outer square brackets and inner parentheses"),
    ("EN p113 radius comparison", "greater or smaller than $r$ according as $r$ is smaller or greater than $1$" in (EN_ROOT / "b1_i0138.tex").read_text(encoding="utf-8"), "source order smaller/greater"),
    ("EN p114 epsilon notation", "\\varepsilon_k" in (EN_ROOT / "b1_i0139.tex").read_text(encoding="utf-8") and "\\xi_k" not in (EN_ROOT / "b1_i0139.tex").read_text(encoding="utf-8"), "epsilon_k throughout"),
    ("EN p114 equation (12)", " x^n=1," in (EN_ROOT / "b1_i0139.tex").read_text(encoding="utf-8") and "\\varepsilon_k^n=1" not in (EN_ROOT / "b1_i0139.tex").read_text(encoding="utf-8"), "source equation x^n=1"),
    ("source-original p118 cross-reference annotated DE", "Source-original" in (DE_ROOT / "b1_i0143.tex").read_text(encoding="utf-8") and "Gleichung (6)" in (DE_ROOT / "b1_i0143.tex").read_text(encoding="utf-8"), "printed (6), equation is (1)"),
    ("source-original p118 cross-reference annotated EN", "Source-original" in (EN_ROOT / "b1_i0143.tex").read_text(encoding="utf-8") and "cubic equation (6)" in (EN_ROOT / "b1_i0143.tex").read_text(encoding="utf-8"), "printed (6), equation is (1)"),
    ("source-original p119 Collectet DE", "Collectet mathematical papers" in (DE_ROOT / "b1_i0144.tex").read_text(encoding="utf-8") and "[sic]" in (DE_ROOT / "b1_i0144.tex").read_text(encoding="utf-8"), "registered source spelling"),
    ("source-original p119 Collectet EN", "Collectet mathematical papers" in (EN_ROOT / "b1_i0144.tex").read_text(encoding="utf-8") and "[sic]" in (EN_ROOT / "b1_i0144.tex").read_text(encoding="utf-8"), "registered source spelling"),
    ("EN p119 footnote callout not stranded", "three values}\\footnotemark" in (EN_ROOT / "b1_i0144.tex").read_text(encoding="utf-8") and "\\footnotetext" in (EN_ROOT / "b1_i0144.tex").read_text(encoding="utf-8"), "callout attached before display"),
    ("EN p121 delta symbols", (EN_ROOT / "b1_i0146.tex").read_text(encoding="utf-8").count("\\delta") >= 3 and "$d$" not in (EN_ROOT / "b1_i0146.tex").read_text(encoding="utf-8"), "Greek delta preserved"),
    ("EN p124 region variable y", "region $(P,y)$" in (EN_ROOT / "b1_i0149.tex").read_text(encoding="utf-8") and "if $y<\\eta$" in (EN_ROOT / "b1_i0149.tex").read_text(encoding="utf-8") and "if $y>\\eta$" in (EN_ROOT / "b1_i0149.tex").read_text(encoding="utf-8") and "(P,\\gamma)" not in (EN_ROOT / "b1_i0149.tex").read_text(encoding="utf-8"), "region and inequalities use source y"),
    ("EN p126 QED marker", "q.e.d." in (EN_ROOT / "b1_i0151.tex").read_text(encoding="utf-8"), "source proof closure represented"),
    ("DE p126 substituted-display punctuation", "+\\cdots\\right)\n\\]" in (DE_ROOT / "b1_i0151.tex").read_text(encoding="utf-8") and "+\\cdots\\right)," not in (DE_ROOT / "b1_i0151.tex").read_text(encoding="utf-8"), "registered scan has no punctuation after the closing parenthesis"),
    ("DE p126 equation (17) comma", "+\\cdots\\right|,\n\\tag{17}" in (DE_ROOT / "b1_i0151.tex").read_text(encoding="utf-8"), "registered scan comma"),
    ("DE p126 equation (18) no punctuation", "|f(\\alpha+h)|<|f(\\alpha)|\\tag{18}" in (DE_ROOT / "b1_i0151.tex").read_text(encoding="utf-8"), "registered scan has no punctuation before QED"),
    ("EN p126 translation punctuation adjudicated", "+\\cdots\\right),\n\\]" in (EN_ROOT / "b1_i0151.tex").read_text(encoding="utf-8") and "+\\cdots\\right|.\n\\tag{17}" in (EN_ROOT / "b1_i0151.tex").read_text(encoding="utf-8") and "|f(\\alpha+h)|<|f(\\alpha)|.\\tag{18}" in (EN_ROOT / "b1_i0151.tex").read_text(encoding="utf-8"), "retained because each mark closes or continues the translated English sentence without changing mathematics"),
    ("EN p127 no false rowbreak", ",\\\\ |" not in (EN_ROOT / "b1_i0152.tex").read_text(encoding="utf-8"), "inline absolute-value list"),
    ("EN p128 ordering chain", "a<b_1\\le b_2\\le b_3\\le\\cdots\\le b_{n-1}" in (EN_ROOT / "b1_i0153.tex").read_text(encoding="utf-8"), "all source relations retained"),
    ("EN p128 varrho", "\\varrho_1" in (EN_ROOT / "b1_i0153.tex").read_text(encoding="utf-8") and re.search(r"(?<!var)\\rho", (EN_ROOT / "b1_i0153.tex").read_text(encoding="utf-8")) is None, "source varrho notation throughout"),
]
for name, condition, evidence in critical:
    check(name, bool(condition), evidence)

independent_source_crops = []
for crop_name in (
    "independent_crop_p126_formula16_18.png",
    "independent_crop_p126_formula17_18.png",
    "independent_crop_p126_formula18.png",
):
    crop = EVIDENCE / crop_name
    check(f"independent source crop {crop_name}", crop.is_file() and crop.stat().st_size > 0, crop.as_posix())
    independent_source_crops.append(identity(crop))

assets = []
for name, expected_hash in EXPECTED_ASSETS.items():
    path = ASSET_ROOT / name
    check(f"asset identity {name}", path.is_file() and sha256(path) == expected_hash, expected_hash)
    assets.append(identity(path))
for language, root in (("de", DE_ROOT), ("en", EN_ROOT)):
    for page, figure in ((113, "fig01"), (124, "fig02"), (128, "fig03")):
        leaf = root / f"b1_i{page + 25:04d}.tex"
        text = leaf.read_text(encoding="utf-8")
        check(f"{language} p{page} exact scan figure", f"weber-b1-{figure}.png" in text and "tikzpicture" not in text, figure)

builds = {}
render_records = []
for language in ("de", "en"):
    stem = f"preview_{language}_p0113_p0128"
    master = EVIDENCE / f"{stem}.tex"
    pdf = EVIDENCE / f"{stem}.pdf"
    log = EVIDENCE / f"{stem}.log"
    log_text = log.read_text(encoding="utf-8", errors="replace")
    warning_counts = {
        "terminal_errors": log_text.count("Fatal error") + log_text.count("Emergency stop"),
        "overfull_hboxes": log_text.count("Overfull \\hbox"),
        "underfull_hboxes": log_text.count("Underfull \\hbox"),
        "overfull_vboxes": log_text.count("Overfull \\vbox"),
        "underfull_vboxes": log_text.count("Underfull \\vbox"),
    }
    check(f"{language} preview has 16 pages", pdf_pages(pdf) == 16, str(pdf_pages(pdf)))
    check(f"{language} build has no terminal/layout warnings", all(value == 0 for value in warning_counts.values()), json.dumps(warning_counts))
    renders = []
    for index in range(1, 17):
        path = EVIDENCE / f"render_{language}" / f"page-{index:02d}.png"
        dimensions = png_dimensions(path)
        check(f"{language} final render page {index}", path.is_file() and path.stat().st_size > 0 and dimensions == (1654, 2339), str(dimensions))
        item = {**identity(path), "printed_page": 112 + index, "dimensions_px": list(dimensions), "visual_review": "PASS"}
        renders.append(item)
        render_records.append({"language": language, **item})
    builds[language] = {"master": identity(master), "pdf": {**identity(pdf), "pages": 16}, "log": identity(log), "compile": {"status": "PASS", **warning_counts}, "renders": renders, "visual_review": "PASS: all sixteen final pages inspected at original render detail."}

payload = {
    "schema": "weber-opening-scoped-validation/v1",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "coverage": {"printed_pages": "113-128", "stable_leaves": "i0138-i0153", "languages": ["de", "en"]},
    "status": "PASS" if not problems else "FAIL",
    "problems": problems,
    "checks": checks,
    "preaudit": identity(preaudit_path),
    "source_rasters": [identity(Path(item["path"])) for item in preaudit["source_rasters"]],
    "records": records,
    "outside_boundaries": {
        "inbound": {"from": "i0137/p112", "to": "i0138/p113", "status": "PASS", "de_predecessor": identity(inbound_de), "en_predecessor": identity(inbound_en), "evidence": [identity(EVIDENCE / "scan-138.png"), identity(EVIDENCE / "scan-139.png")]},
        "outbound": {"from": "i0153/p128", "to": "p129 (i0154 deferred)", "status": "PASS", "successor_canonical_state": "ABSENT", "evidence": [identity(EVIDENCE / "scan-154.png"), identity(EVIDENCE / "scan-155.png")], "adjudication": "p128 ends with a source-continuation marker and registered p129 continues with equation (6); p129 remains outside this scope and is pinned by its raster and both complete monolith identities."},
    },
    "assets": assets,
    "independent_source_crops": independent_source_crops,
    "builds": builds,
    "render_records": render_records,
    "visual_review": {"source_rasters_reviewed": 18, "final_language_pages_reviewed": 32, "unresolved_visual_flags": 0, "status": "PASS"},
    "unresolved": len(problems),
}
OUTPUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": payload["status"], "problems": problems, "output": identity(OUTPUT), "records": len(records), "checks": len(checks), "renders": len(render_records)}, indent=2))
raise SystemExit(0 if not problems else 1)
