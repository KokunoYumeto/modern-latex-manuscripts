from pathlib import Path
import subprocess, json, hashlib, re
from datetime import datetime, timezone

W=Path(r'local-environment/Documents\weber_restart_20260819\work'); E=Path(__file__).parent
def ident(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()}
proof=[]
for lane,folder in [('de','swarm_tex'),('en','swarm_en')]:
 p=E/f'full_{lane}_compile.tex'
 lines=[r'\input{work/swarm_preamble.tex}',r'\begin{document}']
 for n in range(598,630):
  lines.extend([f'\\typeout{{CANONICAL-BEGIN-i{n:04d}-PAGE-\\thepage}}',f'\\input{{{(W/folder/"b2"/f"b2_i{n:04d}.tex").as_posix()}}}',r'\clearpage'])
 lines += [r'\end{document}']
 p.write_text('\n'.join(lines)+'\n',encoding='utf-8')
 for turn in range(2):
  subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',p.name],cwd=E,check=True,stdout=subprocess.DEVNULL)
 log=E/f'full_{lane}_compile.log'; lt=log.read_text(encoding='utf-8',errors='replace')
 issues=re.findall(r'^.*(?:Overfull|Underfull|LaTeX Warning|LaTeX Error|Missing character|Undefined control sequence|^!).*$',lt,re.M)
 pages=[{'stable_id':sid,'pdf_page_1_based':int(pno)} for sid,pno in re.findall(r'CANONICAL-BEGIN-(i\d+)-PAGE-(\d+)',lt)]
 assert len(pages)==32
 proof.append({'lane':lane,'tex':ident(p),'log':ident(log),'pdf':ident(E/f'full_{lane}_compile.pdf'),'page_map':pages,'issues':issues})
out={'created_utc':datetime.now(timezone.utc).isoformat(),'proofs':proof,'status':'PASS' if all(not p['issues'] for p in proof) else 'QA_REQUIRED'}
p=E/'BUILD_RECEIPT.json'; p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8'); print(json.dumps(out,indent=2))
