"""Read-only, bounded independent checks for Weber II chunk 0019.

Prints evidence as JSON. Never rebuilds, edits existing files, or advances cursor.
Run with python -B so imported validators do not write bytecode.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib
import json
import re
import struct
import sys

sys.dont_write_bytecode = True
W = Path(r'local-environment/Documents\weber_restart_20260819\work')
E = Path(__file__).parent
V = E.parent.parent
RP = V / 'chunks' / 'CHUNK_0019_i0598_i0629.json'
CP = V / 'CURSOR.json'
EXPECTED_RECEIPT = 'D5ABB16F8AF596C3AF29256005C5551F01C3370C82F6FEFF395749F00B1E5CDD'
EXPECTED_CURSOR = 'E34C09F0FCAF8E0D944B7EBBE22E13177427021A8E6C370B9D3356D80138431D'
errors = []

def require(condition, label):
    if not condition:
        errors.append(label)

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def identity(path):
    path = Path(path)
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': digest.hexdigest().upper()}

def body(text):
    return re.sub(r'(?<!\\)%[^\n]*', '', text)

receipt_identity = identity(RP)
cursor_identity = identity(CP)
require(receipt_identity['sha256'] == EXPECTED_RECEIPT, 'Unexpected chunk receipt hash')
require(receipt_identity['bytes'] == 109331, 'Unexpected chunk receipt byte count')
require(cursor_identity['sha256'] == EXPECTED_CURSOR, 'Pre-advance cursor changed')
receipt = load(RP)
cursor = load(CP)
require(cursor['terminal_leaves'] == 576 and cursor['next_leaf'] == 'i0598', 'Cursor state mismatch')
require(cursor['last_terminal_leaf'] == 'i0597', 'Last terminal cursor leaf mismatch')
documents = {RP.name: receipt}
for name, descriptor in receipt['evidence'].items():
    if name.endswith('.json'):
        documents[name] = load(descriptor['path'])
documents['PREAUDIT_IDENTITIES.json'] = load(receipt['preaudit_identity_snapshot']['path'])
pre = documents['PREAUDIT_IDENTITIES.json']
post = documents['POSTEDIT_IDENTITIES.json']
queries = documents['QUERY_ADJUDICATIONS.json']
joins = documents['JOIN_ADJUDICATIONS.json']
visual = documents['VISUAL_QA.json']
deqa = documents['DE_PROOF_VISUAL_QA.json']
enqa = documents['EN_PROOF_VISUAL_QA.json']
build = documents['BUILD_RECEIPT.json']
math = documents['MATH_VERIFICATION.json']
expected_ids = [f'i{n:04d}' for n in range(598, 630)]

# Treat only canonical pre/audit snapshots as historical. All source, query,
# rendering, builder and evidence-file identities remain live byte checks.
canonical_paths = {str(W / folder / 'b2' / f'b2_i{n:04d}.tex')
                   for folder in ('swarm_tex', 'swarm_en') for n in range(597, 631)}
allowed_files = canonical_paths | {str(CP), str(RP), str(W / 'check_en.py'),
    str(W / 'swarm_preamble.tex'), receipt['source']['path']}
allowed_files |= {str(W / 'translation_queries' / f'b2_i{n:04d}.json') for n in range(598, 630)}
current_expectations = {}
reference_count = 0
historical = []

def register(descriptor, document, location):
    global reference_count
    path = descriptor.get('path')
    expected_hash = descriptor.get('sha256')
    if not isinstance(path, str) or not isinstance(expected_hash, str):
        return
    expected_hash = expected_hash.upper()
    if not re.fullmatch(r'[0-9A-F]{64}', expected_hash):
        errors.append('Malformed hash at ' + document + ':' + location)
        return
    path = str(Path(path))
    is_canonical = path in canonical_paths
    is_history = is_canonical and (
        document.startswith('AUDIT_') or document == 'PREAUDIT_IDENTITIES.json'
        or '.pre.' in location or location.endswith('.pre'))
    if is_history:
        historical.append({'document': document, 'location': location,
                           'path': path, 'sha256': expected_hash,
                           'meaning': 'HISTORICAL_CANONICAL_SNAPSHOT_NOT_CURRENT'})
        return
    if path not in allowed_files and Path(path).parent != E:
        errors.append('Out-of-scope identity: ' + path)
        return
    reference_count += 1
    expected_bytes = descriptor.get('bytes')
    previous = current_expectations.get(path)
    if previous is not None:
        require(previous['sha256'] == expected_hash, 'Conflicting current hashes: ' + path)
        if expected_bytes is not None and previous['bytes'] is not None:
            require(previous['bytes'] == expected_bytes, 'Conflicting current sizes: ' + path)
        if previous['bytes'] is None:
            previous['bytes'] = expected_bytes
        previous['references'] += 1
    else:
        current_expectations[path] = {'path': path, 'bytes': expected_bytes,
                                      'sha256': expected_hash, 'references': 1}

def walk(value, document, location='$'):
    if isinstance(value, dict):
        register(value, document, location)
        # PREAUDIT uses flattened source_pdf_path/de_path/query_path/... triples.
        for key, path in value.items():
            if key.endswith('_path') and isinstance(path, str):
                prefix = key[:-5]
                if prefix + '_sha256' in value:
                    register({'path': path, 'sha256': value[prefix + '_sha256'],
                              'bytes': value.get(prefix + '_bytes')}, document, location + '.' + prefix)
        for key, child in value.items():
            walk(child, document, location + '.' + key)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            walk(child, document, location + '[' + str(index) + ']')

for name, document in documents.items():
    walk(document, name)
verified = []
for path, expected in sorted(current_expectations.items()):
    actual = identity(path)
    require(actual['sha256'] == expected['sha256'], 'Current hash mismatch: ' + path)
    if expected['bytes'] is not None:
        require(actual['bytes'] == expected['bytes'], 'Current size mismatch: ' + path)
    verified.append({**actual, 'reference_count': expected['references']})

# Exact terminal coverage and unchanged query contents.
require(receipt['status'] == 'COMPLETE', 'Receipt not COMPLETE')
require([r['stable_id'] for r in receipt['terminal_records']] == expected_ids, 'Terminal coverage/order')
require([r['stable_id'] for r in post['records']] == expected_ids, 'Postcanonical coverage/order')
require(all(r['status'] in ('PASS', 'FIXED', 'SOURCE_ORIGINAL_SIC') and r['unresolved'] == 0
            for r in receipt['terminal_records']), 'Nonterminal leaf')
require(receipt['terminal_records'][0]['source_pdf_page_1_based'] == 599, 'Source mapping start')
require(receipt['terminal_records'][-1]['source_pdf_page_1_based'] == 630, 'Source mapping end')
q_by_id = {q['identity']: q for q in queries['records']}
require(len(queries['records']) == 142 and len(q_by_id) == 142, 'Query count or uniqueness')
query_counts = {}
for n in range(598, 630):
    sid = f'i{n:04d}'
    raw = load(W / 'translation_queries' / f'b2_{sid}.json')['queries']
    query_counts[sid] = len(raw)
    for index, query in enumerate(raw, 1):
        key = sid + '#' + str(index)
        record = q_by_id.get(key)
        require(record is not None, 'Missing query ' + key)
        if record:
            require(record['query'] == query, 'Changed historical query ' + key)
            require(record['status'] == 'TERMINAL' and record['unresolved'] == 0,
                    'Nonterminal query ' + key)
            require(bool(record.get('disposition')) and bool(record.get('resolution')),
                    'Empty query adjudication ' + key)
    leaf = receipt['terminal_records'][n - 598]
    require(leaf['historical_queries'] == {'count': len(raw), 'terminal': len(raw), 'unresolved': 0},
            'Leaf query subtotal ' + sid)
require(sum(query_counts.values()) == 142, 'Raw query total')
expected_joins = [f'i{n:04d}->i{n+1:04d}' for n in range(597, 630)]
require([j['join'] for j in joins['joins']] == expected_joins, 'Exact join coverage/order')
require(all(j['status'] == 'TERMINAL' and j['unresolved'] == 0 and j['detail'] for j in joins['joins']),
        'Nonterminal join')

# Recount fixes independently of displayed summary; verify actual non-comment
# literals and source-original comment apparatus in both current lanes.
fixes = receipt['fixes']
require(len(fixes) == 15 and len({f['id'] for f in fixes}) == 15, 'Fix count/uniqueness')
rendered_pairs = {(f['stable_id'], lane) for f in fixes for lane in f['languages']}
require(sum(len(f['languages']) for f in fixes) == 24, 'Lane-instance count')
require(len(rendered_pairs) == 17, 'Rendered file count')
text_cache = {}
for n in range(598, 630):
    sid = f'i{n:04d}'
    for lane, folder in [('de', 'swarm_tex'), ('en', 'swarm_en')]:
        text_cache[sid, lane] = (W / folder / 'b2' / f'b2_{sid}.tex').read_text(encoding='utf-8')
for fix in fixes:
    require(fix['status'] == 'FIXED_VERIFIED', 'Nonterminal fix ' + fix['id'])
    for lane in fix['languages']:
        require(fix['verified_final_literal'] in body(text_cache[fix['stable_id'], lane]),
                'Missing live fix literal ' + fix['id'] + ':' + lane)
categories = Counter(f['kind'] for f in fixes)
require(categories['reconstruction_math'] == 4, 'True mathematical correction count')
require(categories['source_fidelity_formula_restoration'] == 4, 'Source-restoration count')
require(categories['mathematical_translation_precision'] == 1, 'Semantic precision count')
changed_counts = Counter()
for leaf in post['records']:
    sid = leaf['stable_id']
    for lane in ('de', 'en'):
        record = leaf[lane]
        changed = record['pre']['sha256'] != record['post']['sha256']
        rendered = (sid, lane) in rendered_pairs
        require(record['changed'] == changed, 'Changed flag mismatch ' + sid + ':' + lane)
        require(record['rendered_changed'] == rendered, 'Rendered flag mismatch ' + sid + ':' + lane)
        require(record['comment_only_changed'] == (changed and not rendered), 'Comment-only flag mismatch')
        changed_counts[lane] += changed
        changed_counts['comment_only'] += changed and not rendered
require(changed_counts == Counter(de=9, en=13, comment_only=5), 'Changed lane/comment totals')
for entry in receipt['source_original_sic']:
    for lane in ('de', 'en'):
        live = text_cache[entry['stable_id'], lane]
        require(bool(entry['notes'][lane]), 'Empty source-original apparatus')
        require(all(note in live and '[sic' in note and '%' in note for note in entry['notes'][lane]),
                'Missing source-original comments ' + entry['stable_id'] + ':' + lane)
require('Export annotations into the public editorial apparatus.' in math['warning'],
        'Missing public apparatus handoff')
require(len(receipt['independent_proposal_dispositions']) == 7
        and all(q['status'] == 'APPLIED_VERIFIED' for q in receipt['independent_proposal_dispositions']),
        'Original proposals not terminally applied')
require(enqa['status'] == 'PASS' and len(enqa['proposal_dispositions']) == 7
        and all(q['status'] == 'APPLIED_AND_VERIFIED' for q in enqa['proposal_dispositions']),
        'Independent EN proposal verification incomplete')

# Re-run only the exact32 check() calls; never call its whole-volume CLI main().
sys.path.insert(0, str(W))
import check_en
import fitz
english_checks = []
for n in range(598, 630):
    issues = check_en.check('b2', n)
    expected_marker = 'none' if n in (604, 622) else str(n - 21)
    marker_ok = all(check_en.printed_of(text_cache[f'i{n:04d}', lane]) == expected_marker
                    for lane in ('de', 'en'))
    english_checks.append({'stable_id': f'i{n:04d}', 'issues': issues,
                           'printed_marker': expected_marker, 'marker_verified': marker_ok,
                           'status': 'PASS' if not issues and marker_ok else 'FAIL'})
    require(not issues and marker_ok, 'check_en or marker failure i' + str(n))

# Verify PDF page inventories, current proof master input order, actual log
# markers/warnings and page bounds. This is read-only, not a rebuild/render.
pdf_checks = []
for proof in build['proofs']:
    lane = proof['lane']
    expected_pages = 33 if lane == 'de' else 32
    folder = 'swarm_tex' if lane == 'de' else 'swarm_en'
    tex = Path(proof['tex']['path']).read_text(encoding='utf-8')
    input_paths = re.findall(r'\\input\{([^}]+)\}', tex)
    expected_inputs = [(W / 'swarm_preamble.tex').as_posix()] + [
        (W / folder / 'b2' / f'b2_i{n:04d}.tex').as_posix() for n in range(598, 630)]
    require(input_paths == expected_inputs, 'Proof master input order ' + lane)
    log = Path(proof['log']['path']).read_text(encoding='utf-8', errors='replace')
    page_map = [{'stable_id': sid, 'pdf_page_1_based': int(page)} for sid, page in
                re.findall(r'CANONICAL-BEGIN-(i\d+)-PAGE-(\d+)', log)]
    require(page_map == proof['page_map'], 'Actual log page map ' + lane)
    log_issues = re.findall(r'^.*(?:Overfull|Underfull|LaTeX Warning|LaTeX Error|Missing character|Undefined control sequence|^!).*$', log, re.M)
    require(not log_issues and not proof['issues'], 'Build warnings/errors ' + lane)
    page_issues = []
    with fitz.open(proof['pdf']['path']) as pdf:
        require(len(pdf) == expected_pages, 'PDF page count ' + lane)
        for index, page in enumerate(pdf):
            if not page.get_text().strip():
                page_issues.append({'page': index + 1, 'issue': 'EMPTY'})
            for block in page.get_text('dict')['blocks']:
                for line in block.get('lines', []):
                    for span in line['spans']:
                        x0, y0, x1, y1 = span['bbox']
                        if x0 < -1 or y0 < -1 or x1 > page.rect.width + 1 or y1 > page.rect.height + 1:
                            page_issues.append({'page': index + 1, 'issue': 'OUTSIDE_BOUNDS', 'bbox': span['bbox']})
    require(not page_issues, 'PDF bounds/content failure ' + lane)
    pdf_checks.append({'lane': lane, 'pages': expected_pages, 'page_map': page_map,
                       'master_input_order': 'PASS', 'log_issues': log_issues,
                       'page_issues': page_issues, 'status': 'PASS' if not page_issues and not log_issues else 'FAIL'})
require(len(deqa['pages']) == 33 and all(p['status'] == 'PASS' and p['visually_inspected'] for p in deqa['pages']), 'DE visual coverage')
require(len(enqa['pages']) == 32 and all(p['status'] == 'PASS' and p['contact_reviewed'] for p in enqa['pages']), 'EN visual coverage')
require(len(visual['source_pages']) == 32 and len(visual['boundary_context']) == 2, 'Source visual count')
require(all(p['status'] == 'PASS' and p['full_source_visual_inspected'] for p in visual['source_pages'] + visual['boundary_context']), 'Source visual attestations')
require([p['pdf_page_1_based'] for p in visual['source_pages']] == list(range(599, 631)), 'Source image mapping')
require([p['source_pdf_page_1_based'] for p in visual['boundary_context']] == [598, 631], 'Boundary image mapping')
png_checks = []
for item in verified:
    if item['path'].lower().endswith('.png'):
        with Path(item['path']).open('rb') as stream:
            header = stream.read(24)
        require(header[:8] == b'\x89PNG\r\n\x1a\n', 'Not a PNG: ' + item['path'])
        width, height = struct.unpack('>II', header[16:24])
        require(width > 0 and height > 0, 'Invalid PNG dimensions')
        if re.search(r'proof_(de|en)_\d+\.png$', item['path']):
            require((width, height) == (2481, 3508), 'Proof300dpi dimensions: ' + item['path'])
        png_checks.append({'path': item['path'], 'width': width, 'height': height})

# Pre-advance identities are checked again after all diagnostics, so the seal
# cannot accidentally attest bytes that changed during the checks.
require(identity(RP) == receipt_identity, 'Receipt changed during verification')
require(identity(CP) == cursor_identity, 'Cursor changed during verification')
output = {
    'status': 'PASS' if not errors else 'FAIL',
    'checked_at_utc': datetime.now(timezone.utc).isoformat(),
    'chunk_receipt': receipt_identity,
    'pre_advance_cursor': cursor_identity,
    'cursor_state': {'terminal_leaves': cursor['terminal_leaves'], 'next_leaf': cursor['next_leaf'],
                     'last_terminal_leaf': cursor['last_terminal_leaf'], 'unchanged': True},
    'coverage': {'terminal_leaves': 32, 'current_canonical_lanes': 64, 'historical_queries': 142,
                 'joins': 33, 'source_images': 34, 'de_proof_pages': 33, 'en_proof_pages': 32,
                 'proof_pages': 65, 'proof_contacts': 17},
    'fix_counts': {'distinct_fixes': len(fixes), 'lane_instances': 24, 'rendered_files': len(rendered_pairs),
                  'changed_de': changed_counts['de'], 'changed_en': changed_counts['en'],
                  'comment_only_files': changed_counts['comment_only'],
                  'true_mathematical_fixes': categories['reconstruction_math'],
                  'source_formula_restorations': categories['source_fidelity_formula_restoration'],
                  'mathematical_semantic_precision': categories['mathematical_translation_precision']},
    'current_identity_reference_count': reference_count,
    'unique_current_identity_count': len(verified),
    'current_identity_checks': verified,
    'historical_canonical_identities_not_compared_to_current': historical,
    'historical_snapshot_policy': 'Canonical pre/audit hashes identify earlier bytes and are not mistaken for current postcanonical hashes. Their containing immutable JSON files are fully hash-verified. Source, query, proof, builder and evidence identities are always current byte checks.',
    'checker': identity(W / 'check_en.py'),
    'checker_dependencies': [identity(W / name) for name in ('collect.py', 'render.py')],
    'check_en_invocation': "python -B verify_independent_final_seal.py; check_en.check('b2',n) for n in range(598,630)",
    'english_checks': english_checks,
    'pdf_checks': pdf_checks,
    'png_checks': png_checks,
    'source_original_apparatus': {'status': 'VERIFIED_TEX_COMMENTS', 'public_export_required': True,
        'handoff': 'Root must export retained source-original anomaly explanations into the public editorial apparatus; these proof PDFs do not visibly print the TeX comments.'},
    'unresolved': len(errors),
    'errors': errors,
    'verifier': identity(__file__)
}
print(json.dumps(output, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 1)
