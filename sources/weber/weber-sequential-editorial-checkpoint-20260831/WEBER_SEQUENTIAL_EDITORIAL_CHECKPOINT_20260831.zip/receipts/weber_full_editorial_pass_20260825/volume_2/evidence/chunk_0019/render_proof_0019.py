from pathlib import Path
from PIL import Image, ImageDraw
import subprocess,json,hashlib,sys

E=Path(__file__).parent
for lane,count in [('de',33),('en',32)]:
 for page in range(1,count+1):
  out=E/f'proof_{lane}_{page:02d}.png'
  if not out.exists() or '--refresh-all' in sys.argv:
   subprocess.run(['pdftoppm','-f',str(page),'-l',str(page),'-r','300','-png','-singlefile',str(E/f'full_{lane}_compile.pdf'),str(out.with_suffix(''))],check=True,stdout=subprocess.DEVNULL)
 for first in range(1,count+1,4):
  nums=list(range(first,min(count+1,first+4)))
  canvas=Image.new('RGB',(1600,2320),'white'); d=ImageDraw.Draw(canvas)
  for offset,p in enumerate(nums):
   im=Image.open(E/f'proof_{lane}_{p:02d}.png').convert('RGB')
   im.thumbnail((790,1120))
   x=(offset%2)*800;y=(offset//2)*1160
   d.text((x+10,y+5),f'{lane.upper()} proof page {p}',fill='black')
   canvas.paste(im,(x,y+25))
  canvas.save(E/f'proof_contact_{lane}_{first:02d}.png')
print('Rendered65 proof pages at300dpi with17 contact sheets.')
