"""Advance only volume-II cursor after the independently sealed chunk0019."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os

E=Path(__file__).parent; V=E.parent.parent
EXPECTED_CURSOR='E34C09F0FCAF8E0D944B7EBBE22E13177427021A8E6C370B9D3356D80138431D'
EXPECTED_RECEIPT='D5ABB16F8AF596C3AF29256005C5551F01C3370C82F6FEFF395749F00B1E5CDD'
def ident(p):
    p=Path(p)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()}
def verify(i):
    x=ident(i['path']); assert x['bytes']==i['bytes'] and x['sha256']==i['sha256'],i['path']; return x

cp=V/'CURSOR.json'; rp=V/'chunks/CHUNK_0019_i0598_i0629.json'; sp=E/'INDEPENDENT_FINAL_SEAL.json'
before=ident(cp); receipt_id=ident(rp); seal_id=ident(sp)
assert before['sha256']==EXPECTED_CURSOR and receipt_id['sha256']==EXPECTED_RECEIPT
cursor=json.loads(cp.read_text(encoding='utf-8')); receipt=json.loads(rp.read_text(encoding='utf-8')); seal=json.loads(sp.read_text(encoding='utf-8'))
assert seal['status']=='PASS' and seal['unresolved']==0
assert verify(seal['chunk_receipt'])==receipt_id and verify(seal['pre_advance_cursor'])==before
assert cursor['terminal_leaves']==576 and cursor['next_leaf']=='i0598'
assert receipt['status']=='COMPLETE' and receipt['summary']['unresolved']==0 and len(receipt['terminal_records'])==32
assert receipt['summary']['terminal_leaves']==32
for e in receipt['evidence'].values(): verify(e)
verify(receipt['source']); verify(receipt['preaudit_identity_snapshot'])
for r in receipt['terminal_records']:
    for lane in ('de','en'): verify(r[lane]['post'])
    verify(r['queries']); assert r['unresolved']==0
summary=receipt['summary']
cursor.update({'terminal_leaves':608,'last_terminal_leaf':'i0629','next_leaf':'i0630','active_chunk':'CHUNK_0020_i0630_i0661'})
for k in ('confirmed_defects','fixed_defects','rendered_defect_instances_fixed','rendered_files_changed','nonrendering_comment_files_changed','mathematical_defects_fixed'):
    cursor[k]+=summary[k]
cursor['source_original_sic_leaves']+=len(summary['source_original_sic_leaves'])
cursor['chunk_receipts'].append({'chunk':'0019','range':'i0598-i0629','terminal_leaves':32,'path':str(rp),'sha256':receipt_id['sha256']})
assert cursor['confirmed_defects']==126 and cursor['fixed_defects']==126
assert cursor['rendered_defect_instances_fixed']==190 and cursor['rendered_files_changed']==132
assert cursor['nonrendering_comment_files_changed']==44 and cursor['mathematical_defects_fixed']==11 and cursor['source_original_sic_leaves']==102
# Preserve the exact pre-advance bytes and atomically install the gated successor.
backup=E/'CURSOR_BEFORE_ADVANCE.json'; assert not backup.exists()
backup.write_bytes(cp.read_bytes())
assert ident(backup)['sha256']==EXPECTED_CURSOR
temp=V/'CURSOR.chunk0019.next.json'; assert not temp.exists()
temp.write_text(json.dumps(cursor,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
assert ident(cp)['sha256']==EXPECTED_CURSOR
os.replace(temp,cp)
after=ident(cp); got=json.loads(cp.read_text(encoding='utf-8'))
assert got==cursor and got['next_leaf']=='i0630' and got['terminal_leaves']==608
report={'schema':'weber-editorial-post-advance/v1','status':'PASS','created_utc':datetime.now(timezone.utc).isoformat(),'chunk_receipt':receipt_id,'independent_seal':seal_id,'pre_cursor':before,'preserved_pre_cursor':ident(backup),'post_cursor':after,'advance_script':ident(__file__),'completed_leaves':608,'total_leaves':804,'next_leaf':'i0630','next_chunk':'CHUNK_0020_i0630_i0661','unresolved':0}
op=E/'POST_ADVANCE_VERIFICATION.json'; op.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'post_advance_verification':ident(op),**report},indent=2))
