from pathlib import Path
from PIL import Image

E = Path(__file__).parent
regions = {
    'i0600_primes': (601, (420, 1550, 950, 1740)),
    'i0602_final_comma': (603, (850, 2070, 1400, 2240)),
    'i0612_exponents': (613, (350, 730, 1050, 1440)),
    'i0613_exponents': (614, (400, 1780, 1140, 2160)),
}
for name, (page, box) in regions.items():
    im = Image.open(E / f'source-{page}.png')
    im.crop(box).resize(((box[2]-box[0])*2, (box[3]-box[1])*2)).save(E / f'crop_{name}.png')
