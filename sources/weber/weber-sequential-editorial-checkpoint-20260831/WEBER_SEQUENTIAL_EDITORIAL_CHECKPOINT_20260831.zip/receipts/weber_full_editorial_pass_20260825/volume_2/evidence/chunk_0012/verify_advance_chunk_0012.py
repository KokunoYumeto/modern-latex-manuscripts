from __future__ import annotations
import hashlib,json,re,sys
from datetime import datetime,timezone
from pathlib import Path
W=Path(r'local-environment/Documents\weber_restart_20260819\work'); V=W/'receipts/weber_full_editorial_pass_20260825/volume_2'; E=V/'evidence/chunk_0012'
D=W/'swarm_tex/b2'; N=W/'swarm_en/b2'; P=E/'PREAUDIT_IDENTITIES.json'; R=V/'chunks/CHUNK_0012_i0374_i0405.json'; C=V/'CURSOR.json'; O=E/'INDEPENDENT_FINAL_SEAL.json'
SIDS=[f'i{x:04d}' for x in range(374,406)]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def ident(p): return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def now(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
pre=load(P); rec=load(R); cur=load(C)
assert sha(C)==pre['pre_chunk_cursor']['sha256']
for k,v in {'terminal_leaves':352,'last_terminal_leaf':'i0373','next_leaf':'i0374','active_chunk':'CHUNK_0012_i0374_i0405','unresolved':0}.items(): assert cur[k]==v
assert rec['status']=='COMPLETE' and rec['range']=={'first':'i0374','last':'i0405','terminal_records':32}
assert rec['summary']=={'terminal_leaves':32,'confirmed_defects':0,'fixed_defects':0,'rendered_defect_instances_fixed':0,'rendered_files_changed':0,'changed_de_files':0,'changed_en_files':0,'changed_union_leaves':0,'nonrendering_comment_files_changed':0,'mathematical_defects_fixed':0,'source_original_sic_leaves':['i0397','i0405'],'source_original_sic_instances':2,'historical_translation_queries_checked':103,'boundary_joins_checked':33,'status_counts':{'PASS':30,'SOURCE_ORIGINAL_SIC':2},'canonical_leaf_changed':False,'unresolved':0}
assert [x['stable_id'] for x in rec['terminal_records']]==SIDS
for x in rec['terminal_records']:
    sid=x['stable_id']
    for lane,root in [('de',D),('en',N)]:
        live=ident(root/f'b2_{sid}.tex'); assert (live['sha256'],live['bytes'])==(x[lane]['post']['sha256'],x[lane]['post']['bytes'])
        assert not x[lane]['changed']
    assert x['historical_queries']['count']==x['historical_queries']['terminal'] and x['historical_queries']['unresolved']==0
for x in rec['evidence'].values(): assert ident(Path(x['path']))==x
q=load(E/'QUERY_ADJUDICATIONS.json'); j=load(E/'JOIN_ADJUDICATIONS.json'); n=load(E/'NARROW_VALIDATION.json'); m=load(E/'MATH_VERIFICATION.json'); v=load(E/'VISUAL_QA.json')
for x in [q,j,n,m,v]: assert x['status']=='PASS' and x['unresolved']==0
assert len(q['terminal_adjudications'])==103 and len(j['joins'])==33 and len(v['source_visuals'])==32 and len(v['boundary_visuals'])==2 and len(v['changed_proof_visuals'])==4
for x in v['source_visuals']+v['boundary_visuals']+v['changed_proof_visuals']:
    a=ident(Path(x['path'])); assert (a['sha256'],a['bytes'])==(x['sha256'],x['bytes'])
fatal=re.compile(r'(^!|LaTeX Error|Fatal error|Emergency stop|Overfull|Missing character|Undefined control sequence|Package .*Warning|LaTeX Warning)',re.I|re.M)
for lane in ['de','en']: assert not fatal.search((E/f'changed_{lane}_compile.log').read_text(encoding='utf-8',errors='replace'))
sys.path.insert(0,str(W)); import check_en
assert all(check_en.check('b2',int(s[1:]))==[] for s in SIDS)
seal={'schema':'weber-editorial-independent-final-seal/v1','created_utc':now(),'volume':'II','chunk':'0012','range':'i0374-i0405','status':'PASS','registered_source':rec['source'],'preaudit_snapshot':ident(P),'pre_advance_cursor':ident(C),'terminal_chunk_receipt':ident(R),'checks':{'terminal_records':'32/32','registered_source_visuals':'34/34 including boundaries','historical_queries':'103/103','joins':'33/33','canonical_changes':'0/64; byte-identical to preaudit','proof_pages':'4/4 compiled, rendered, and visually inspected at 300 dpi','check_en':'PASS 32/32','source_original_sic':'2/2 directly verified','unresolved':0}}
O.write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); oid=ident(O); rid=ident(R)
cur['terminal_leaves']=384; cur['last_terminal_leaf']='i0405'; cur['next_leaf']='i0406'; cur['active_chunk']='CHUNK_0013_i0406_i0437'; cur['source_original_sic_leaves']+=2
cur['chunk_receipts'].append({'chunk':'0012','range':'i0374-i0405','terminal_leaves':32,'path':str(R),'sha256':rid['sha256']})
C.write_text(json.dumps(cur,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); cid=ident(C)
post={'schema':'weber-editorial-post-advance-verification/v1','created_utc':now(),'status':'PASS','chunk_receipt':rid,'independent_final_seal':oid,'advanced_cursor':cid,'cursor_state':{'terminal_leaves':384,'last_terminal_leaf':'i0405','next_leaf':'i0406','active_chunk':'CHUNK_0013_i0406_i0437','unresolved':0},'canonical_recheck':'PASS 64/64 current identities match terminal receipt','unresolved':0}
(E/'POST_ADVANCE_VERIFICATION.json').write_text(json.dumps(post,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','receipt':rid,'seal':oid,'cursor':cid,'post_advance':ident(E/'POST_ADVANCE_VERIFICATION.json')},indent=2))
