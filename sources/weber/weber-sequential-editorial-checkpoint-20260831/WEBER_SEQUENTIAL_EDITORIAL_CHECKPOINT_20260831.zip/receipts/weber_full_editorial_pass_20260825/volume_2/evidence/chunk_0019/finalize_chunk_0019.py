"""Seal the finite i0598-i0629 audit; never edits canonical leaves or advances cursor."""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, re, sys
import fitz

W=Path(r'local-environment/Documents\weber_restart_20260819\work')
E=Path(__file__).parent
V=E.parent.parent
sys.path.insert(0,str(W))
import check_en

def ident(p):
    p=Path(p)
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()}
def read(name): return json.loads((E/name).read_text(encoding='utf-8'))
def write(name,data):
    p=E/name
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return ident(p)
def verify(i):
    got=ident(i['path'])
    assert got['sha256']==i['sha256'] and got['bytes']==i['bytes'],i['path']
    return got
def body(t): return re.sub(r'(?<!\\)%[^\n]*','',t)

stamp=datetime.now(timezone.utc).isoformat()
pre=read('PREAUDIT_IDENTITIES.json')
assert ident(E/'PREAUDIT_IDENTITIES.json')['sha256']=='FFC096BA479B200AE61A1189FD5C30E9C83765FF8346D7F31F9388DC6E978386'
assert ident(V/'CURSOR.json')['sha256']=='E34C09F0FCAF8E0D944B7EBBE22E13177427021A8E6C370B9D3356D80138431D'
source=verify({'path':pre['source_pdf_path'],'bytes':pre['source_pdf_bytes'],'sha256':pre['source_pdf_sha256']})
a=read('AUDIT_i0598_i0613.json'); b=read('AUDIT_i0614_i0629.json')
assert a['status']=='PASS' and len(a['records'])==16 and len(b['leaves'])==16
enqa=read('EN_PROOF_VISUAL_QA.json')
assert enqa['status']=='PASS'
build=read('BUILD_RECEIPT.json'); assert build['status']=='PASS'
for proof in build['proofs']:
    for name in ('tex','log','pdf'): verify(proof[name])
    assert not proof['issues']

# Each entry is one concrete source/translation discrepancy, not one lane copy.
fixes=[]
def fix(key,n,kind,lanes,detail,needle):
    for lane in lanes:
        folder='swarm_tex' if lane=='de' else 'swarm_en'
        text=(W/folder/'b2'/f'b2_i{n:04d}.tex').read_text(encoding='utf-8')
        assert needle in body(text),(key,lane,needle)
    fixes.append({'id':key,'stable_id':f'i{n:04d}','kind':kind,'languages':lanes,'status':'FIXED_VERIFIED','detail':detail,'verified_final_literal':needle,'rendered_instances':len(lanes)})
both=['de','en']
fix('R599',599,'heading_alignment',both,'Centered section158 number and title exactly as source; prior heading was left-aligned.',r'\begin{center}')
fix('R602',602,'source_fidelity_punctuation',['de'],'Restored real printed lowered comma after so; source-original odd punctuation separately annotated.','so, ergiebt')
fix('R605',605,'translation_emphasis',['en'],'Full relative-norm definitional emphasis now includes with-respect-to-R qualifier.',r'\gesperrt{the partial norm (relative norm) taken with respect to $R$}')
fix('R608',608,'translation_grammar',['en'],'Repaired incomplete English sentence around17 left by earlier deletion; no formula change.','we obtain the equation')
fix('R612a',612,'reconstruction_math',both,'Equation2 finite-field exponent is P^f, not Pf.',r'\omega^{P^f}')
fix('R612b',612,'reconstruction_math',both,'Equation3 primitive-root order is P^f-1, not Pf-1.',r'\gamma^{P^f-1}')
fix('R612c',612,'reconstruction_math',both,'Equation4 last nonzero-residue power is P^f-2, not Pf-2.',r'\gamma^{P^f-2}')
fix('S613a',613,'source_fidelity_formula_restoration',both,'Last listed root restores printed P^f-1 rather than silently normalized P^(f-1); annotation identifies intended orbit.',r'\gamma^{P^f-1}')
fix('S613b',613,'source_fidelity_formula_restoration',both,'Equation8 last factor independently repeats printed P^f-1; restored and separately annotated.',r'(t-\gamma^{P^f-1})')
fix('S615',615,'source_fidelity_formula_restoration',both,'Equation7 repeats same printed last-factor misprint; restored with explicit intended-form note.',r'(t-\gamma^{P^f-1})')
fix('R616',616,'reconstruction_math',both,'First congruence finite-field exponent is P^f, not Pf.',r'\omega^{P^f}')
fix('R621a',621,'translation_punctuation',['en'],'Restored sentence-final period at equation9.',r'(h_r = f_r\,g_r).')
fix('R621b',621,'translation_punctuation',['en'],'Restored sentence-final period after conjugate-field list.',r"\Omega_{m'}'.")
fix('R624',624,'mathematical_translation_precision',['en'],'Smallest absolute value explicitly denotes magnitude, not signed minimum.','with the smallest absolute value')
fix('S628',628,'source_fidelity_formula_restoration',both,'Restored printed incomplete a_{1,}; annotation gives intended a_{1,2} instead of silent completion.',r'$a_{1,}$')
assert len(fixes)==15

sic_details={
600:(1,'Primed argument in first derivative functional is inconsistent with the preceding definitions; original retained with new note.'),
601:(1,'Equation11 prints F1(tau) where surrounding factorization requires Phi(tau); existing note retained.'),
602:(1,'Unneeded lowered comma after so is real source punctuation; restored and newly annotated.'),
610:(2,'Source transposes comma: missing after first theilbar and stray after the action expression; existing note retained.'),
611:(1,'Capital fraktur P in prose conflicts with lower p in following norm formula; existing note retained.'),
613:(2,'Two occurrences of last-orbit exponent P^f-1 instead of intended P^(f-1) restored and annotated separately.'),
615:(1,'Repeated last-orbit exponent P^f-1 restored with intended P^(f-1) note.'),
618:(1,'Different-product exponent prints g2-2 instead of surrounding g2-1 pattern; retained with existing note.'),
619:(1,'Group-degree expression names Phi instead of Psi; retained with existing note.'),
620:(3,'Two missing primes retained with existing notes; newly annotated source calls subgroup Phi-prime a field.'),
628:(1,'Incomplete printed a_{1,} restored; intended a_{1,2} explicitly documented.')}
sic=[]
for n,(count,detail) in sic_details.items():
    notes={}
    for lane,folder in [('de','swarm_tex'),('en','swarm_en')]:
        text=(W/folder/'b2'/f'b2_i{n:04d}.tex').read_text(encoding='utf-8')
        notes[lane]=[x for x in text.splitlines() if '[sic' in x]
        assert notes[lane]
    sic.append({'stable_id':f'i{n:04d}','instances':count,'detail':detail,'notes':notes,'status':'SOURCE_ORIGINAL_RETAINED_ANNOTATED'})

rendered_pairs={(f['stable_id'],l) for f in fixes for l in f['languages']}
posts=[]; texts={}; validations=[]; sourcevisual=[]
for r in pre['records']:
    sid=r['stable_id']; n=int(sid[1:]); entry={'stable_id':sid,'source_pdf_page_1_based':n+1}
    for lane in both:
        post=ident(r[lane+'_path']); changed=post['sha256']!=r[lane+'_sha256']
        rendered=(sid,lane) in rendered_pairs
        assert changed or not rendered
        entry[lane]={'pre':{'path':r[lane+'_path'],'sha256':r[lane+'_sha256'],'bytes':r[lane+'_bytes']},'post':post,'changed':changed,'rendered_changed':rendered,'comment_only_changed':changed and not rendered}
        texts[(sid,lane)]=Path(post['path']).read_text(encoding='utf-8')
    entry['queries']=verify({'path':r['query_path'],'sha256':r['query_sha256'],'bytes':r['query_bytes']})
    vis=verify({'path':r['visual_path'],'sha256':r['visual_sha256'],'bytes':r['visual_bytes']})
    sourcevisual.append({'stable_id':sid,'pdf_page_1_based':n+1,'visual':vis,'status':'PASS','full_source_visual_inspected':True,'audit_report':ident(E/('AUDIT_i0598_i0613.json' if n<614 else 'AUDIT_i0614_i0629.json'))})
    result=check_en.check('b2',n); assert not result,(sid,result)
    expected='none' if n in (604,622) else str(n-21)
    for lane in both: assert check_en.printed_of(texts[sid,lane])==expected,(sid,lane)
    validations.append({'stable_id':sid,'formula_and_translation_check':'PASS','printed_marker':expected,'expected_marker_verified':True,'unresolved':0})
    posts.append(entry)
assert len(posts)==32

qrecords=[]
for leaf in a['records']:
    for q in leaf['query_adjudications']:
        assert q['status']=='TERMINAL' and q['unresolved']==0
        qrecords.append({**q,'source_pdf_page_1_based':leaf['source_pdf_page_1_based'],'queries_file':leaf['queries_file']})
for leaf in b['leaves']:
    sid=leaf['id'].removeprefix('b2_'); qpath=Path(leaf['historical_queries']['path']); queries=json.loads(qpath.read_text(encoding='utf-8'))['queries']
    assert len(queries)==len(leaf['historical_query_dispositions'])
    for q,d in zip(queries,leaf['historical_query_dispositions']):
        assert d['status']=='TERMINALLY_ADJUDICATED'
        qrecords.append({'identity':sid+'#'+str(d['query_index_1based']),'query':q,'status':'TERMINAL','disposition':d['disposition'],'resolution':'Source adjudication retained; all concrete new proposals are now applied and verified in fixes and English proof QA.','unresolved':0,'source_pdf_page_1_based':leaf['source_page_1based'],'queries_file':ident(qpath)})
assert len(qrecords)==142 and len({q['identity'] for q in qrecords})==142
assert sum(r['query_count'] for r in pre['records'])==142

joins=list(a['joins'])
joins += [{'join':j['left'].removeprefix('b2_')+'->'+j['right'].removeprefix('b2_'),'status':'TERMINAL','detail':j['disposition'],'unresolved':0} for j in b['boundary_dispositions']]
assert len(joins)==33 and {j['join'] for j in joins}=={f'i{n:04d}->i{n+1:04d}' for n in range(597,630)}
boundaries=[]
for r in pre['boundary_context']:
    vis=verify({'path':r['visual_path'],'sha256':r['visual_sha256'],'bytes':r['visual_bytes']})
    sid=r['role'].split('_')[-1]
    boundaries.append({'stable_id':sid,'role':r['role'],'visual':vis,'source_pdf_page_1_based':r['source_pdf_page_1_based'],'full_source_visual_inspected':True,'status':'PASS','de':ident(W/'swarm_tex/b2'/f'b2_{sid}.tex'),'en':ident(W/'swarm_en/b2'/f'b2_{sid}.tex')})

pdfvalidation=[]
for proof in build['proofs']:
    lane=proof['lane']; expected=33 if lane=='de' else 32
    doc=fitz.open(proof['pdf']['path']); assert len(doc)==expected
    issues=[]
    for index,page in enumerate(doc):
        assert page.get_text().strip()
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                for span in line['spans']:
                    x0,y0,x1,y1=span['bbox']
                    if x0 < -1 or y0 < -1 or x1 > page.rect.width+1 or y1 > page.rect.height+1: issues.append({'page':index+1,'text':span['text'],'bbox':span['bbox']})
    assert not issues
    pdfvalidation.append({'lane':lane,'pages':expected,'nonempty_pages':expected,'outside_page_bounds':issues,'status':'PASS'})
    doc.close()

# Observation record: all33 DE final proof pages personally inspected in9 contacts;
# changed formula/heading pages additionally opened individually at full resolution.
deproof=next(x for x in build['proofs'] if x['lane']=='de')
write('DE_PROOF_VISUAL_QA.json',{'schema':'weber-editorial-proof-visual/v1','created_utc':stamp,'status':'PASS','lane':'de','pdf':deproof['pdf'],'method':'All33 final proof pages personally inspected through9 contact sheets; fullpage detail inspected for pages2,15,16,18,19,32. No clipping, overlap, missing glyphs, malformed formulae, or heading alignment defects. Page24-25 is one canonical leaf i0621 across two proof pages, complete through13 and separator.','contacts':[ident(E/f'proof_contact_de_{n:02d}.png') for n in range(1,34,4)],'pages':[{'page_1_based':n,'image':ident(E/f'proof_de_{n:02d}.png'),'status':'PASS','visually_inspected':True,'fullpage_detail_inspected':n in (2,15,16,18,19,32)} for n in range(1,34)],'canonical':[{'stable_id':p['stable_id'],'de':p['de']['post']} for p in posts],'unresolved':0})

write('POSTEDIT_IDENTITIES.json',{'schema':'weber-editorial-postedit/v1','created_utc':stamp,'source':source,'preaudit':ident(E/'PREAUDIT_IDENTITIES.json'),'records':posts,'boundary_context':boundaries})
write('QUERY_ADJUDICATIONS.json',{'schema':'weber-editorial-queries/v1','status':'PASS','records':qrecords,'counts':{'total':142,'terminal':142,'unresolved':0},'original_query_files_changed':False})
write('JOIN_ADJUDICATIONS.json',{'schema':'weber-editorial-joins/v1','status':'PASS','joins':joins,'counts':{'total':33,'terminal':33,'unresolved':0},'boundary_context':boundaries})
write('NARROW_VALIDATION.json',{'schema':'weber-editorial-validation/v1','status':'PASS','checker':ident(W/'check_en.py'),'records':validations,'pdfs':pdfvalidation,'source_identity':'PASS','unresolved':0})
write('MATH_VERIFICATION.json',{'schema':'weber-editorial-math/v1','status':'PASS','reconstruction_math_defects_fixed':4,'mathematical_translation_precision_fixes':1,'source_fidelity_formula_restorations':4,'fixes':[f for f in fixes if 'math' in f['kind'] or 'formula' in f['kind']],'source_original_sic':sic,'warning':'Source-original errors are intentionally retained, identified as such in paired TeX comments and this receipt; they are not asserted mathematically correct. Export annotations into the public editorial apparatus.','all_source_and_translation_formulas_checked':32,'unresolved':0})
write('VISUAL_QA.json',{'schema':'weber-editorial-visual/v1','status':'PASS','source_pages':sourcevisual,'boundary_context':boundaries,'proof_reports':[ident(E/'DE_PROOF_VISUAL_QA.json'),ident(E/'EN_PROOF_VISUAL_QA.json')],'counts':{'assigned_source_pages':32,'boundary_source_pages':2,'de_proof_pages':33,'en_proof_pages':32,'total_proof_pages':65,'unresolved':0}})

summary={'terminal_leaves':32,'confirmed_defects':len(fixes),'fixed_defects':len(fixes),'rendered_defect_instances_fixed':sum(f['rendered_instances'] for f in fixes),'rendered_files_changed':len(rendered_pairs),'changed_de_files':sum(p['de']['changed'] for p in posts),'changed_en_files':sum(p['en']['changed'] for p in posts),'changed_union_leaves':sum(p['de']['changed'] or p['en']['changed'] for p in posts),'nonrendering_comment_files_changed':sum(p[l]['comment_only_changed'] for p in posts for l in both),'mathematical_defects_fixed':4,'mathematical_translation_precision_fixes':1,'source_fidelity_formula_restorations':4,'source_original_sic_leaves':[s['stable_id'] for s in sic],'source_original_sic_instances':sum(s['instances'] for s in sic),'historical_translation_queries_checked':142,'boundary_joins_checked':33,'canonical_leaf_changed':True,'unresolved':0}
assert summary['rendered_defect_instances_fixed']==24 and summary['rendered_files_changed']==17 and summary['nonrendering_comment_files_changed']==5
terminal=[]
for p in posts:
    sid=p['stable_id']; fs=[f for f in fixes if f['stable_id']==sid]; ss=[s for s in sic if s['stable_id']==sid]; count=len([q for q in qrecords if q['identity'].split('#')[0]==sid])
    status='FIXED' if fs else ('SOURCE_ORIGINAL_SIC' if ss else 'PASS')
    terminal.append({**p,'status':status,'printed_page_marker':check_en.printed_of(texts[sid,'de']),'findings':fs,'source_original_sic':ss,'historical_queries':{'count':count,'terminal':count,'unresolved':0},'boundary':{'inbound':next(j['detail'] for j in joins if j['join'].endswith('->'+sid)),'outbound':next(j['detail'] for j in joins if j['join'].startswith(sid+'->'))},'unresolved':0})
summary['status_counts']=dict(Counter(p['status'] for p in terminal))
evidence_names=['POSTEDIT_IDENTITIES.json','QUERY_ADJUDICATIONS.json','JOIN_ADJUDICATIONS.json','NARROW_VALIDATION.json','MATH_VERIFICATION.json','VISUAL_QA.json','DE_PROOF_VISUAL_QA.json','EN_PROOF_VISUAL_QA.json','AUDIT_i0598_i0613.json','AUDIT_i0614_i0629.json','BUILD_RECEIPT.json','build_proof_0019.py','render_proof_0019.py','record_audit_0598_0613.py','finalize_chunk_0019.py']
evidence_names += [f'full_{l}_compile.{ext}' for l in both for ext in ('tex','log','pdf')]
receipt={'schema':'weber-editorial-chunk-receipt/v1','volume':'II','chunk':'0019','range':{'first':'i0598','last':'i0629','terminal_records':32},'status':'COMPLETE','created_utc':stamp,'authority_and_scope':{'write_boundary':'Canonical i0598-i0629, chunk0019 evidence/receipt and volumeII cursor only. Boundaries read-only; no master/publication artifacts.','audit_method':'All32 registered source pages at300dpi, all64 canonical lanes,142 historical queries and33 joins. All65 final DE/EN proof pages visually checked; altered formula glyphs inspected individually.'},'source':source,'preaudit_identity_snapshot':ident(E/'PREAUDIT_IDENTITIES.json'),'evidence':{name:ident(E/name) for name in evidence_names},'source_original_sic':sic,'fixes':fixes,'independent_proposal_dispositions':[{'id':f['id'],'status':'APPLIED_VERIFIED','detail':'Exact canonical correction or source-original annotation applied; separately verified in English proof QA.'} for f in b['new_findings']],'validations':{'source_visual_inspection':'PASS34/34 including boundaries','historical_queries':'PASS142/142','joins':'PASS33/33','formula_and_translation':'PASS32/32','proof_build_and_render':'PASS65/65 at300dpi','unresolved':0},'summary':summary,'terminal_records':terminal}
rp=V/'chunks/CHUNK_0019_i0598_i0629.json'; rp.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'receipt':ident(rp),'summary':summary},indent=2))
