from __future__ import annotations
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
W=Path(r"local-environment/Documents\weber_restart_20260819\work"); V=W/"receipts"/"weber_full_editorial_pass_20260825"/"volume_2"; E=V/"evidence"/"chunk_0013"
S=Path(r"registered-source/Weber_Algebra_Bd2.pdf"); C=V/"CURSOR.json"; DE=W/"swarm_tex"/"b2"; EN=W/"swarm_en"/"b2"; Q=W/"translation_queries"
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def ident(p): return {"path":str(p),"sha256":h(p),"bytes":p.stat().st_size}
E.mkdir(parents=True,exist_ok=True)
assert h(C)=="2FBF31D30DAE9EC9CEEE261919F022EC7FB12F3EA24FD4BAE0B05C3C6E359490"
assert (h(S),S.stat().st_size)==("809C974845F6AFA7EA14AB99CD6259D9FABBAEA8F385F211BA131D624E10F4C7",61864818)
for page in range(406,440):
 out=E/f"source-{page}"
 if not (E/f"source-{page}.png").exists(): subprocess.run(["pdftoppm","-f",str(page),"-l",str(page),"-r","300","-png","-singlefile",str(S),str(out)],check=True)
rows=[]
for n in range(406,438):
 sid=f"i{n:04d}"; de=DE/f"b2_{sid}.tex"; en=EN/f"b2_{sid}.tex"; q=Q/f"b2_{sid}.json"; vis=E/f"source-{n+1}.png"; qd=json.loads(q.read_text(encoding="utf-8"))
 rows.append({"stable_id":sid,"source_pdf_page_1_based":n+1,"de_path":str(de),"de_sha256":h(de),"de_bytes":de.stat().st_size,"en_path":str(en),"en_sha256":h(en),"en_bytes":en.stat().st_size,"visual_path":str(vis),"visual_sha256":h(vis),"visual_bytes":vis.stat().st_size,"query_path":str(q),"query_sha256":h(q),"query_bytes":q.stat().st_size,"query_count":len(qd.get("queries",[]))})
b=[]
for page,role in [(406,"inbound_i0405"),(439,"outbound_i0438")]:
 vis=E/f"source-{page}.png"; b.append({"role":role,"source_pdf_page_1_based":page,"visual_path":str(vis),"visual_sha256":h(vis),"visual_bytes":vis.stat().st_size})
p={"schema":"weber-editorial-preaudit-identities/v1","created_utc":datetime.now(timezone.utc).isoformat().replace("+00:00","Z"),"volume":"II","chunk":"0013","range":"i0406-i0437","source_pdf_path":str(S),"source_pdf_sha256":h(S),"source_pdf_bytes":S.stat().st_size,"mapping":"stable iNNNN -> 1-based source PDF page NNNN+1","pre_chunk_cursor":ident(C),"records":rows,"boundary_context":b,"counts":{"assigned_leaves":32,"source_assigned_pages":32,"source_boundary_pages":2,"historical_queries":sum(x["query_count"] for x in rows)}}
(E/"PREAUDIT_IDENTITIES.json").write_text(json.dumps(p,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); print(json.dumps({"preaudit":ident(E/"PREAUDIT_IDENTITIES.json"),"counts":p["counts"]},indent=2))
