from pathlib import Path
import json, hashlib
from datetime import datetime, timezone

W=Path(r'local-environment/Documents\weber_restart_20260819\work')
E=Path(__file__).parent
def ident(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()}
Q = {
598:[('ALREADY_CORRECTED','The complete Das Product paragraph is letterspaced in the scan and both current lanes.'),('ALREADY_CORRECTED','Equations29,30,31,33 use baseline product dots; equation32 correctly uses centred sum dots.'),('RETAINED_CONVENTION','Printer signature and sheet37 are marginal production furniture, not body text; printed page577 is preserved.')],
599:[('CORRECTED','Full section158 title is letterspaced and section number plain; corrected both lanes to center the section number and heading as printed.'),('ALREADY_CORRECTED','Source clearly reads Variablen, matching current DE.'),('ALREADY_CORRECTED','The run die nicht alle durch p theilbar sind is preserved in DE/EN.')],
600:[('ALREADY_CORRECTED','The full discriminant/absolute-norm assertion is letterspaced in both lanes.'),('SOURCE_ORIGINAL_ANNOTATED','Source prints F prime of tau prime as first functional; surrounding definitions compare F prime of tau with F1 prime of tau prime. Added explicit source-original annotation, retaining printed argument.'),('RETAINED_VERIFIED','Native-size crop shows the F top serif plus one derivative prime, not F double prime; current single derivative is retained.'),('RETAINED_VERIFIED','Small mark after von is an isolated impression blemish, not a syntactic point; no stop is inserted.'),('TERMINOLOGY_CONFIRMED','Grundzahl/Grundfunctional/Grundideal remain fundamental number/fundamental functional/fundamental ideal consistently.')],
601:[('RETAINED_VERIFIED','Absolute-norm subscript is Latin a in both occurrences, matching the preceding definition and current text.'),('SOURCE_ORIGINAL_ANNOTATED','Equation11 prints F1(tau), while differentiation and adjacent prose require Phi(tau). Existing paired sic notes retained.'),('TERMINOLOGY_CONFIRMED','Grundzahl is consistently fundamental number.')],
602:[('ALREADY_CORRECTED','First ganze rationale Functionale run is letterspaced in both lanes.'),('ALREADY_CORRECTED','The coefficient-paragraph occurrence is independently letterspaced in both lanes.'),('SOURCE_ORIGINAL_RESTORED','Enlarged source crop shows a lowered comma after so, not a shapeless speck. Restored the printed comma in DE and documented the source punctuation in both lanes; EN retains natural punctuation.'),('RETAINED_VERIFIED','Polynomial family15 retains all rows, equals alignment, coefficients, powers and dotted continuation. Different intra-row compositor spacing changes no column semantics.'),('TERMINOLOGY_CONFIRMED','Band is retained in this historical self-reference; first volume elsewhere is equivalent English prose, not a mathematical discrepancy.')],
603:[('ALREADY_CORRECTED','Closing centred horizontal rule is present in DE and EN.'),('RETAINED_VERIFIED','The repeated index is Greek nu in the numerator and index range; full source image resolves the form.')],
604:[('ALREADY_CORRECTED','Neunzehnter Abschnitt and English chapter-number line are letterspaced.'),('ALREADY_CORRECTED','Relativnormen and translated section heading are letterspaced.'),('ALREADY_CORRECTED','absoluten Rationalitaetsbereiches run restored and plain second occurrence retained.'),('ALREADY_CORRECTED','Single definitional word ueber/over is letterspaced.'),('ALREADY_CORRECTED','Centred chapter separator rule is present.'),('ALREADY_CORRECTED','Quoted Galois name with possessive suffix is letterspaced inside footnote title.'),('TERMINOLOGY_CONFIRMED','Relativnormen means relative norms.'),('TERMINOLOGY_CONFIRMED','Ergaenzungen means supplements/additions to the theory in this context.'),('TERMINOLOGY_CONFIRMED','Primitivzahl is primitive number; no semantic ambiguity with primitive quantity.')],
605:[('ALREADY_CORRECTED','Full assertion after eq3 is letterspaced.'),('CORRECTED','DE full run already correct. Expanded and reordered EN letterspacing to include the complete definition and with-respect-to-R qualifier, leaving of the number omega plain.'),('ALREADY_CORRECTED','Totalnorm/total norm alone is letterspaced.'),('ALREADY_CORRECTED','Functionale/functionals emphasis and Ideale ihre Partialnormen emphasis retained.'),('ALREADY_CORRECTED','New paragraph after eq5 is present.'),('TERMINOLOGY_CONFIRMED','Partialnorm/Relativnorm/Totalnorm/gewoehnliche Norm consistently partial/relative/total/ordinary norm.')],
606:[('ALREADY_CORRECTED','Partialspur definition run retained through in Bezug auf; R remains mathematical.'),('ALREADY_CORRECTED','First Grundideal run emphasized, later ordinary occurrence plain.'),('ALREADY_CORRECTED','Partial-Grundideal definition run is retained in full.'),('TERMINOLOGY_CONFIRMED','Fundamental ideal and partial fundamental ideal remain source-faithful names.'),('TERMINOLOGY_CONFIRMED','Partial/relative/total trace and basis form preserve defined meanings.')],
607:[('ALREADY_CORRECTED','Integral functionals emphasis after13 retained in both lanes.'),('ALREADY_CORRECTED','Closing divisibility assertion letterspaced; preceding ergiebt/results plain.'),('RETAINED_VERIFIED','Eq14 trace S is italic Latin, distinct from fraktur partial trace in12.'),('RETAINED_VERIFIED','F derivative in lower display has one prime; printed serif accounts for apparent second stroke.'),('RETAINED_VERIFIED','The mark after nimmt is a semicolon with upper point visible in full source.'),('RETAINED_VERIFIED','Summation exponent index is nu; matches nu in following prose and indexed identity14.')],
608:[('CORRECTED','German has no extraneous ergiebt after17, as source requires. Its prior removal left EN syntactically incomplete; repaired to then ... we obtain the equation, without changing mathematical content.'),('RETAINED_VERIFIED','Raised-looking terminal dot of19 is sentence punctuation/impression placement, not a multiplication operator.'),('TERMINOLOGY_CONFIRMED','Fundamental ideal and relative fundamental ideal remain consistent with preceding definitions.')],
609:[('ALREADY_CORRECTED','Normal-field definition emphasized through with respect to.'),('ALREADY_CORRECTED','Group-of-field parenthetical definition fully emphasized.'),('ALREADY_CORRECTED','Abelian in equation assertion is separately emphasized.'),('ALREADY_CORRECTED','Second Abelian-field expression is emphasized, relativ/relatively plain.'),('ALREADY_CORRECTED','First Abelian-field emphasis includes in Bezug auf/with respect to.'),('ALREADY_CORRECTED','Complete substitution-action definition emphasized; following consequence plain.'),('TERMINOLOGY_CONFIRMED','Partial-Grundideal remains partial fundamental ideal.')],
610:[('ALREADY_CORRECTED','Opening complete group-belonging definition is letterspaced, initial carried ist/is plain.'),('SOURCE_ORIGINAL_ANNOTATED','Source transposes comma from after first theilbar to after action symbol; faithful DE and existing paired annotation retained.'),('TERMINOLOGY_CONFIRMED','Natural prime denotes rational positive prime here.'),('TERMINOLOGY_CONFIRMED','Partial norm consistent with its definition.')],
611:[('ALREADY_CORRECTED','Degree definition letterspaced from den to R.'),('ALREADY_CORRECTED','Mutually distinct phrase emphasized, following conjugacy qualification plain.'),('ALREADY_CORRECTED','Norm is a power of italic rational prime p, not the fraktur prime ideal.'),('SOURCE_ORIGINAL_ANNOTATED','Capital fraktur P in introductory prose contradicts lower p in5; existing paired annotation retains exact source.'),('TERMINOLOGY_CONFIRMED','Partial/total norm and associated-with-group constructions preserve definitions.')],
612:[('ALREADY_CORRECTED','Body Primitivwurzeln/primitive roots emphasis retained.'),('ALREADY_CORRECTED','Lowest possible degree run emphasized.'),('RETAINED_VERIFIED','Comma after Grade is faint but fits visible descending mark; no full stop substituted.'),('TERMINOLOGY_CONFIRMED','Unity means number1 in this congruence, not arbitrary algebraic unit.')],
613:[('SOURCE_ORIGINAL_RESTORED','Native-size enlarged crop disproves historical conjecture: f is nested but minus1 is level with P, so print is gamma^(P^f-1). Restored exact print and annotated intended gamma^(P^(f-1)).'),('SOURCE_ORIGINAL_RESTORED','Same source-original outer-minus1 misprint repeats in factor8. Restored and annotated separately.'),('ALREADY_CORRECTED','Eq8 product dots are baseline ldots in current DE/EN.')],
}
FINDINGS = {
599:'Restored source-centered section158 number and heading in both lanes after proof visual review.',
600:'Added paired annotation for source-original primed-argument inconsistency; formulas unchanged.',
601:'Source F1/Phi mismatch in11 retained with existing annotation.',
602:'Restored omitted printed lowered comma after so in DE, with explanatory annotations; family15 complete.',
604:'Unnumbered chapter opening retained as !PRINTED none; chapter19, section159, separator and footnote complete.',
605:'Repaired incomplete English emphasis scope in relative-norm definition.',
608:'Repaired English sentence grammar around17 after an earlier literal-word deletion.',
610:'Printed transposed comma anomaly retained and annotated.',
611:'Printed capital-P/lower-p norm anomaly retained and annotated.',
612:'Corrected3 flattened nested exponents in2,3,4 in both lanes: P^f, P^f-1, P^f-2, not Pf etc.',
613:'Restored2 silently normalized source-original final-orbit exponents; added source/interpretation distinction.',
}
JOINS={
597:'Equation28 is followed by and from this one concludes, with unchanged Phi1 factor.',
598:'Section157 ends at33; next leaf starts section158, resetting equation numbering to1.',
599:'Displayed dependence relation is immediately rejected by This contradicts theorem5.',
600:'From10 however / Aus10 aber continues to differentiation; Phi and modulus retained.',
601:'Omega basis display12 continues into coefficient qualification, then expression13.',
602:'Final trace polynomial takes value1 at all tau_i; next leaf completes proof of identically1.',
603:'Section158 closes with theorem4 and separator; following unnumbered chapter19 starts159.',
604:'Main text ends irreducibility of the; next leaf starts equation1, with source footnote separate from continuation.',
605:'If one / Wenn man continues to takes product of distinct conjugate ideals; no loss.',
606:'Three defining quotient displays9-11 complete; next page explains their coefficients F_nu,psi_nu,f_nu.',
607:'Divisibility in15 closes; next page proves reverse divisibility using16.',
608:'Source com-/plexen and EN com-/plex boundary correctly form complex multiplication.',
609:'Group Psi divisor of Phi continues with ist/is before new emphasized definition.',
610:'Folglich/Consequently continues directly to partial norm as power of P in3.',
611:'Section160 ends degree gf; next leaf starts section161 and cites4,5 correctly.',
612:'We can / Wir koennen continues with thus assume F polynomial; nested-power corrections do not change join.',
}
pre=json.loads((E/'PREAUDIT_IDENTITIES.json').read_text(encoding='utf-8'))
by={r['stable_id']:r for r in pre['records']}
records=[]
for n,res in Q.items():
 sid=f'i{n:04d}'; qpath=W/'translation_queries'/f'b2_{sid}.json'; queries=json.loads(qpath.read_text(encoding='utf-8'))['queries']
 assert len(queries)==len(res)
 r=by[sid]
 records.append({'stable_id':sid,'source_pdf_page_1_based':n+1,'source_visual':ident(Path(r['visual_path'])),'source_visual_inspected':True,'full_de_read':True,'full_en_read':True,'de':ident(W/'swarm_tex/b2'/f'b2_{sid}.tex'),'en':ident(W/'swarm_en/b2'/f'b2_{sid}.tex'),'queries_file':ident(qpath),'finding':FINDINGS.get(n,'Full source, formulas, symbols, prose, emphasis, translation and boundary order checked; no new reconstruction defect.'),'query_adjudications':[{'identity':f'{sid}#{k}','query':q,'status':'TERMINAL','disposition':d,'resolution':s,'unresolved':0} for k,(q,(d,s)) in enumerate(zip(queries,res),1)],'unresolved':0})
out={'schema':'weber-editorial-bounded-source-audit/v1','created_utc':datetime.now(timezone.utc).isoformat(),'range':'i0598-i0613','status':'PASS','preaudit':ident(E/'PREAUDIT_IDENTITIES.json'),'method':'Direct complete300dpi source PNG inspection, all DE/EN text, native-source crops for glyph/nesting ambiguities; no OCR-only adjudication.','records':records,'joins':[{'join':f'i{n:04d}->i{n+1:04d}','status':'TERMINAL','detail':s,'unresolved':0} for n,s in JOINS.items()],'counts':{'leaves':16,'source_visuals':16,'queries':sum(len(x['query_adjudications']) for x in records),'joins':16,'unresolved':0}}
p=E/'AUDIT_i0598_i0613.json'; p.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps(ident(p)))
