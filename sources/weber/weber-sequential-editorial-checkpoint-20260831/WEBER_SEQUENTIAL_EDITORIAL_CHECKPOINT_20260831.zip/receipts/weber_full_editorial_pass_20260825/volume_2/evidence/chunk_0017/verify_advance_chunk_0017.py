from __future__ import annotations
import hashlib,json,re,sys
from datetime import datetime,timezone
from pathlib import Path
W=Path(r'local-environment/Documents\weber_restart_20260819\work'); V=W/'receipts/weber_full_editorial_pass_20260825/volume_2'; E=V/'evidence/chunk_0017'
D=W/'swarm_tex/b2'; N=W/'swarm_en/b2'; P=E/'PREAUDIT_IDENTITIES.json'; R=V/'chunks/CHUNK_0017_i0534_i0565.json'; C=V/'CURSOR.json'; O=E/'INDEPENDENT_FINAL_SEAL.json'
SIDS=[f'i{x:04d}' for x in range(534,566)]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def ident(p): return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def now(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')
pre=load(P); rec=load(R); cur=load(C)
assert sha(C)==pre['pre_chunk_cursor']['sha256']
for k,v in {'terminal_leaves':512,'last_terminal_leaf':'i0533','next_leaf':'i0534','active_chunk':'CHUNK_0017_i0534_i0565','unresolved':0}.items(): assert cur[k]==v
assert rec['status']=='COMPLETE' and rec['range']=={'first':'i0534','last':'i0565','terminal_records':32}
assert rec['summary']['historical_translation_queries_checked']==104 and rec['summary']['source_original_sic_instances']==3 and rec['summary']['unresolved']==0
assert [x['stable_id'] for x in rec['terminal_records']]==SIDS
for x in rec['terminal_records']:
    sid=x['stable_id']
    for lane,root in [('de',D),('en',N)]:
        live=ident(root/f'b2_{sid}.tex'); assert (live['sha256'],live['bytes'])==(x[lane]['post']['sha256'],x[lane]['post']['bytes'])
        assert x[lane]['changed']==(sid=='i0541')
    assert x['historical_queries']['count']==x['historical_queries']['terminal'] and x['historical_queries']['unresolved']==0
for x in rec['evidence'].values(): assert ident(Path(x['path']))==x
q=load(E/'QUERY_ADJUDICATIONS.json'); j=load(E/'JOIN_ADJUDICATIONS.json'); n=load(E/'NARROW_VALIDATION.json'); m=load(E/'MATH_VERIFICATION.json'); v=load(E/'VISUAL_QA.json')
for x in [q,j,n,m,v]: assert x['status']=='PASS' and x['unresolved']==0
assert len(q['terminal_adjudications'])==104 and len(j['joins'])==33 and len(v['source_visuals'])==32 and len(v['boundary_visuals'])==2 and len(v['changed_proof_visuals'])==10
for x in v['source_visuals']+v['boundary_visuals']+v['changed_proof_visuals']:
    a=ident(Path(x['path'])); assert (a['sha256'],a['bytes'])==(x['sha256'],x['bytes'])
fatal=re.compile(r'(^!|LaTeX Error|Fatal error|Emergency stop|Overfull|Missing character|Undefined control sequence|Package .*Warning|LaTeX Warning)',re.I|re.M)
for lane in ['de','en']: assert not fatal.search((E/f'changed_{lane}_compile.log').read_text(encoding='utf-8',errors='replace'))
sys.path.insert(0,str(W)); import check_en
assert all(check_en.check('b2',int(s[1:]))==[] for s in SIDS)
seal={'schema':'weber-editorial-independent-final-seal/v1','created_utc':now(),'volume':'II','chunk':'0017','range':'i0534-i0565','status':'PASS','registered_source':rec['source'],'preaudit_snapshot':ident(P),'pre_advance_cursor':ident(C),'terminal_chunk_receipt':ident(R),'checks':{'terminal_records':'32/32','registered_source_visuals':'34/34 including boundaries','historical_queries':'104/104','joins':'33/33','canonical_changes':'2/64; i0541 DE/EN source-backed correction','proof_pages':'10/10 compiled and rendered at 300 dpi','check_en':'PASS 32/32','source_original_sic':'3 leaves/3 instances directly verified','unresolved':0}}
O.write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); oid=ident(O); rid=ident(R)
cur['terminal_leaves']=544; cur['last_terminal_leaf']='i0565'; cur['next_leaf']='i0566'; cur['active_chunk']='CHUNK_0018_i0566_i0597'; cur['source_original_sic_leaves']+=3
cur['chunk_receipts'].append({'chunk':'0017','range':'i0534-i0565','terminal_leaves':32,'path':str(R),'sha256':rid['sha256']})
C.write_text(json.dumps(cur,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); cid=ident(C)
post={'schema':'weber-editorial-post-advance-verification/v1','created_utc':now(),'status':'PASS','chunk_receipt':rid,'independent_final_seal':oid,'advanced_cursor':cid,'cursor_state':{'terminal_leaves':544,'last_terminal_leaf':'i0565','next_leaf':'i0566','active_chunk':'CHUNK_0018_i0566_i0597','unresolved':0},'canonical_recheck':'PASS 64/64 current identities match terminal receipt','unresolved':0}
(E/'POST_ADVANCE_VERIFICATION.json').write_text(json.dumps(post,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','receipt':rid,'seal':oid,'cursor':cid,'post_advance':ident(E/'POST_ADVANCE_VERIFICATION.json')},indent=2))
