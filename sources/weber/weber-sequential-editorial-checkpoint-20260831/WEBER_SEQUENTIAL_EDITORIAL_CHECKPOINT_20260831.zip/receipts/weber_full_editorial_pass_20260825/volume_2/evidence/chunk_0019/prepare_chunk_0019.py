from __future__ import annotations

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

WORK = Path(r"local-environment/Documents\weber_restart_20260819\work")
VOL = WORK / "receipts" / "weber_full_editorial_pass_20260825" / "volume_2"
EV = VOL / "evidence" / "chunk_0019"
SRC = Path(
    r"registered-source/Weber_Algebra_Bd2.pdf"
)
CURSOR = VOL / "CURSOR.json"
DE = WORK / "swarm_tex" / "b2"
EN = WORK / "swarm_en" / "b2"
QUERIES = WORK / "translation_queries"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def identity(path: Path) -> dict[str, object]:
    return {"path": str(path), "sha256": sha256(path), "bytes": path.stat().st_size}


assert sha256(CURSOR) == "E34C09F0FCAF8E0D944B7EBBE22E13177427021A8E6C370B9D3356D80138431D"
assert (sha256(SRC), SRC.stat().st_size) == (
    "809C974845F6AFA7EA14AB99CD6259D9FABBAEA8F385F211BA131D624E10F4C7",
    61_864_818,
)

EV.mkdir(parents=True, exist_ok=True)
for page in range(598, 632):
    rendered = EV / f"source-{page}.png"
    if rendered.exists():
        continue
    subprocess.run(
        [
            "pdftoppm",
            "-f",
            str(page),
            "-l",
            str(page),
            "-r",
            "300",
            "-png",
            "-singlefile",
            str(SRC),
            str(EV / f"source-{page}"),
        ],
        check=True,
    )

records = []
for n in range(598, 630):
    stable_id = f"i{n:04d}"
    de_path = DE / f"b2_{stable_id}.tex"
    en_path = EN / f"b2_{stable_id}.tex"
    query_path = QUERIES / f"b2_{stable_id}.json"
    visual_path = EV / f"source-{n + 1}.png"
    query_data = json.loads(query_path.read_text(encoding="utf-8"))
    records.append(
        {
            "stable_id": stable_id,
            "source_pdf_page_1_based": n + 1,
            "de_path": str(de_path),
            "de_sha256": sha256(de_path),
            "de_bytes": de_path.stat().st_size,
            "en_path": str(en_path),
            "en_sha256": sha256(en_path),
            "en_bytes": en_path.stat().st_size,
            "visual_path": str(visual_path),
            "visual_sha256": sha256(visual_path),
            "visual_bytes": visual_path.stat().st_size,
            "query_path": str(query_path),
            "query_sha256": sha256(query_path),
            "query_bytes": query_path.stat().st_size,
            "query_count": len(query_data.get("queries", [])),
        }
    )

boundary_context = []
for page, role in ((598, "inbound_i0597"), (631, "outbound_i0630")):
    visual_path = EV / f"source-{page}.png"
    boundary_context.append(
        {
            "role": role,
            "source_pdf_page_1_based": page,
            "visual_path": str(visual_path),
            "visual_sha256": sha256(visual_path),
            "visual_bytes": visual_path.stat().st_size,
        }
    )

snapshot = {
    "schema": "weber-editorial-preaudit-identities/v1",
    "created_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "volume": "II",
    "chunk": "0019",
    "range": "i0598-i0629",
    "source_pdf_path": str(SRC),
    "source_pdf_sha256": sha256(SRC),
    "source_pdf_bytes": SRC.stat().st_size,
    "mapping": "stable iNNNN -> 1-based source PDF page NNNN+1",
    "pre_chunk_cursor": identity(CURSOR),
    "records": records,
    "boundary_context": boundary_context,
    "counts": {
        "assigned_leaves": 32,
        "source_assigned_pages": 32,
        "source_boundary_pages": 2,
        "historical_queries": sum(row["query_count"] for row in records),
    },
}
out = EV / "PREAUDIT_IDENTITIES.json"
out.write_text(json.dumps(snapshot, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"preaudit": identity(out), "counts": snapshot["counts"]}, indent=2))
