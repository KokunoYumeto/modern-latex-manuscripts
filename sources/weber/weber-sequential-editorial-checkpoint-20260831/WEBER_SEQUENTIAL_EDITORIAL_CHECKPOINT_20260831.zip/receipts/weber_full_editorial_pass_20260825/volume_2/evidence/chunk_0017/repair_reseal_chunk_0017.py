from __future__ import annotations
import hashlib, json, re
from datetime import datetime, timezone
from pathlib import Path

W=Path(r'local-environment/Documents\weber_restart_20260819\work')
V=W/'receipts/weber_full_editorial_pass_20260825/volume_2'
E=V/'evidence/chunk_0017'; R=V/'chunks/CHUNK_0017_i0534_i0565.json'; C=V/'CURSOR.json'
O=E/'INDEPENDENT_FINAL_SEAL.json'; P=E/'POST_REPAIR_VERIFICATION.json'
DE=W/'swarm_tex/b2'; EN=W/'swarm_en/b2'
SIDS=[f'i{x:04d}' for x in range(534,566)]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest().upper()
def ident(p): return {'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size}
def load(p): return json.loads(p.read_text(encoding='utf-8'))
def now(): return datetime.now(timezone.utc).isoformat(timespec='milliseconds').replace('+00:00','Z')

assert sha(C)=='028CCF42343AFF5AE8DEA2853C7E23EC2D2845381A94EC78B943ABC2F7E6D0F2'
cur=load(C); before=json.loads(json.dumps(cur)); rec=load(R)
assert rec['status']=='COMPLETE' and rec['summary']['unresolved']==0
assert rec['validations']['proof_build_and_render']=='PASS 8/8 at 300 dpi'
assert [x['stable_id'] for x in rec['terminal_records']]==SIDS
for x in rec['terminal_records']:
    sid=x['stable_id']
    for lane,root in [('de',DE),('en',EN)]:
        a=ident(root/f'b2_{sid}.tex'); assert (a['sha256'],a['bytes'])==(x[lane]['post']['sha256'],x[lane]['post']['bytes'])
for x in rec['evidence'].values(): assert ident(Path(x['path']))==x
vis=load(E/'VISUAL_QA.json'); assert vis['status']=='PASS' and vis['unresolved']==0
assert len(vis['changed_proof_visuals'])==8
assert [(x['lane'],x['stable_id']) for x in vis['changed_proof_visuals']]==[(lane,sid) for lane in ['de','en'] for sid in ['i0538','i0541','i0542','i0555']]
for x in vis['changed_proof_visuals']:
    assert ident(Path(x['path']))=={k:x[k] for k in ['path','sha256','bytes']}
fatal=re.compile(r'(^!|LaTeX Error|Fatal error|Emergency stop|Overfull|Missing character|Undefined control sequence|Package .*Warning|LaTeX Warning)',re.I|re.M)
for lane in ['de','en']: assert not fatal.search((E/f'changed_{lane}_compile.log').read_text(encoding='utf-8',errors='replace'))

seal={'schema':'weber-editorial-independent-final-seal/v1','created_utc':now(),'volume':'II','chunk':'0017','range':'i0534-i0565','status':'PASS','repair':'Replaces the inherited incorrect proof-leaf set with exact affected/anomaly leaves i0538,i0541,i0542,i0555 in both lanes; all eight pages visually inspected.','registered_source':rec['source'],'preaudit_snapshot':ident(E/'PREAUDIT_IDENTITIES.json'),'pre_repair_cursor':ident(C),'terminal_chunk_receipt':ident(R),'checks':{'terminal_records':'32/32','registered_source_visuals':'34/34 including boundaries','historical_queries':'104/104','joins':'33/33','canonical_changes':'2/64; i0541 DE/EN source-backed correction','proof_pages':'8/8 correct affected/anomaly pages compiled, rendered at 300 dpi, and visually inspected','check_en':'PASS 32/32','source_original_sic':'3 leaves/3 instances directly verified','unresolved':0}}
O.write_text(json.dumps(seal,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
rid=ident(R); oid=ident(O)
hits=[x for x in cur['chunk_receipts'] if x['chunk']=='0017']; assert len(hits)==1
assert hits[0]['sha256']=='1C153117305209854D4DD6BFEC8A5BB3E97B95DB27FF5B298BB2F8AF18B4411B'
hits[0]['sha256']=rid['sha256']
for k in ['terminal_leaves','last_terminal_leaf','next_leaf','active_chunk','confirmed_defects','fixed_defects','rendered_defect_instances_fixed','rendered_files_changed','nonrendering_comment_files_changed','mathematical_defects_fixed','source_original_sic_leaves','unresolved']:
    assert cur[k]==before[k]
C.write_text(json.dumps(cur,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); cid=ident(C)
post={'schema':'weber-editorial-post-repair-verification/v1','created_utc':now(),'status':'PASS','repaired_chunk_receipt':rid,'independent_final_seal':oid,'advanced_cursor':cid,'proof_pages':8,'proof_leaf_set':['i0538','i0541','i0542','i0555'],'lanes':['de','en'],'cursor_topology_preserved':{'terminal_leaves':576,'last_terminal_leaf':'i0597','next_leaf':'i0598','active_chunk':'CHUNK_0019_i0598_i0629'},'cumulative_counters_preserved':{k:cur[k] for k in ['confirmed_defects','fixed_defects','rendered_defect_instances_fixed','rendered_files_changed','nonrendering_comment_files_changed','mathematical_defects_fixed','source_original_sic_leaves']},'unresolved':0}
P.write_text(json.dumps(post,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'PASS','receipt':rid,'seal':oid,'cursor':cid,'post_repair':ident(P)},indent=2))
