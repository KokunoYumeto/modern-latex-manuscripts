# -*- coding: utf-8 -*-
"""Validate an English facing-edition fragment against its German source.

The translation spec makes one promise that is worth more than all the others: the mathematics
in the English column is COPIED from the German column, not re-read off the scan. That promise
is mechanically checkable, and this is the check. Everything else here is cheaper.

What is compared:

  formulas   every display and every inline math span, in order, character for character after
             normalising whitespace. Language inside \text{...} is exempt -- that is prose that
             happens to sit in math mode, and translating it is required.
  header     % !PRINTED n must agree with the German fragment. A translation filed against the
             wrong page is worse than a missing one, because it looks complete.
  length     English prose against German prose. German is more compact than English in this
             register, so a translation SHORTER than its source usually means a dropped clause.
  queries    the audit report must exist. A page with no query file was not audited, whatever
             the agent said in its reply.
  german     no untranslated run of German left in the prose.

usage:
  python check_en.py b1
  python check_en.py b1 --rm      remove failures so they can be re-run
"""
import collections, json, os, re, sys

import collect

HERE = os.path.dirname(os.path.abspath(__file__))
EN = os.path.join(HERE, "swarm_en")
QUERIES = os.path.join(HERE, "translation_queries")

# Words that do not survive a translation: if these are still in the English fragment's prose,
# a sentence was left alone. Chosen to be frequent in Weber and absent from English.
GERMAN_TELLS = re.compile(
    r"\b(?:welche[rsnm]?|dass|daß|nicht|sind|werden|worden|durch|nach|"
    r"wenn|jede[rsnm]?|diese[rsnm]?|einer|eines|einem|"
    r"Gleichung|Gruppe|K\u00f6rper|Zahl|Satz|Beweis|Function|Funktion)\b")


def spans(text):
    """Every mathematical span in document order, normalised for comparison."""
    body = re.sub(r"(?<!\\)%.*", "", text)
    out = []
    # \weq{tag}{body} -- take both arguments; the tag is the printed equation number and must
    # match too, because a renumbered equation breaks every cross-reference in the volume.
    # \weq{tag}{body} is read by matching braces, NOT by anchoring to end of line. A numbered
    # equation can sit INLINE inside a paragraph (b2 i0781: a gesperrt theorem wrapped around
    # \weq{1}{...}); the old end-of-line anchor then swallowed everything up to the last brace
    # on the line, so German prose was compared against English prose and reported as an altered
    # display. Balanced reading captures exactly the two arguments.
    def _group(s, i):
        """s[i] == '{'; return (contents, index just past the matching '}') or (None, i)."""
        if i >= len(s) or s[i] != "{":
            return None, i
        depth, j = 1, i + 1
        while j < len(s) and depth:
            if s[j] == "{" and s[j - 1] != "\\":
                depth += 1
            elif s[j] == "}" and s[j - 1] != "\\":
                depth -= 1
            j += 1
        return (s[i + 1:j - 1], j) if depth == 0 else (None, i)

    pos = 0
    while True:
        k = body.find(r"\weq{", pos)
        if k < 0:
            break
        tag, after = _group(body, k + len(r"\weq"))
        if tag is None:
            pos = k + 5
            continue
        bodytext, after2 = _group(body, after)
        if bodytext is None:
            pos = k + 5
            continue
        out.append(("weq", tag, bodytext))
        pos = after2
    for m in re.finditer(r"(?<!\\)\\\[(.*?)(?<!\\)\\\]", body, re.S):
        out.append(("display", "", m.group(1)))
    for m in re.finditer(r"(?<!\\)\$(.+?)(?<!\\)\$", body, re.S):
        out.append(("inline", "", m.group(1)))
    # The reconstructed opening uses both TeX inline spellings.  Treat \(...\)
    # exactly like $...$; otherwise a lane-local delimiter choice makes real
    # formulae disappear from one side of the comparison (b1 i0074-i0118).
    for m in re.finditer(r"(?<!\\)\\\((.*?)(?<!\\)\\\)", body, re.S):
        out.append(("inline", "", m.group(1)))
    def blank_footnotes(s):
        # A \footnote inside a display is prose: translated on the English side (citation
        # titles excepted) and never mathematics. Blank its body like \text, brace-counted
        # because footnotes nest braces (b2 i0451).
        out2, i = [], 0
        while True:
            j = s.find(r"\footnote{", i)
            if j < 0:
                out2.append(s[i:])
                return "".join(out2)
            out2.append(s[i:j] + r"\footnote{}")
            k, depth = j + len(r"\footnote{"), 1
            while k < len(s) and depth:
                if s[k] == "{":
                    depth += 1
                elif s[k] == "}":
                    depth -= 1
                k += 1
            i = k
    norm = []
    for kind, tag, s in out:
        s = blank_footnotes(s)
        # German ordinal suffixes: $n^{\mathrm{ten}}$ Grades has no English form that keeps the
        # superscript, so the spec drops it and the empty exponent goes with it. The fragments
        # set these with \text as well as \mathrm, and the drop must run BEFORE \text blanking
        # or the ordinal survives as an empty ^{\text{}} on the German side only.
        s = re.sub(r"\^\{?\\(?:mathrm|text)\{(?:tem|ten|te|stem|sten|ster|ste|ter|tes|er)\}\}?", "", s)
        # ... including inside a compound superscript ($p^{\varkappa\,\mathrm{ten}}$, b2 i0147),
        # where the ordinal suffix rides along after the real exponent.
        s = re.sub(r"(?:\\,)?\\(?:mathrm|text)\{(?:tem|ten|te|stem|sten|ster|ste|ter|tes|er)\}", "", s)
        # An empty brace group is a script separator ($m_1{}^{\mathrm{ten}}$) or spacing
        # vestige and carries no content; the ordinal drop can orphan one. Inert either way.
        s = s.replace("{}", "")
        # \text{...}, \hbox{...}, and \mbox{...} hold prose and are expected to
        # differ across languages.  Blank them brace-countedly; their bodies can
        # contain nested groups, which a flat regular expression would truncate.
        for command in (r"\text", r"\hbox", r"\mbox"):
            outs, i = [], 0
            needle = command + "{"
            while True:
                k = s.find(needle, i)
                if k < 0:
                    outs.append(s[i:])
                    break
                inner, after = _group(s, k + len(command))
                if inner is None:
                    outs.append(s[i:k + len(needle)])
                    i = k + len(needle)
                    continue
                outs.append(s[i:k] + command + "{}")
                i = after
            s = "".join(outs)
        # Once \text{...} is exempt, HOW MANY prose groups a line is cut into, and the spacing
        # macros between them, are translation artifacts too: German "20 Substitutionen
        # 3^{ten} Grades:" becomes "20 substitutions of degree 3:", same mathematics, different
        # prose packaging (b2 i0246). Collapse blanked runs and drop pure spacing, so the
        # comparison tests the mathematics and not the compositor's word order.
        # A LaTeX row break is structure, not spacing: protect `\\` before collapsing
        # spacing macros, or the second backslash of the pair gets eaten as `\ ` when a
        # space follows it, silently merging two rows of a matrix.
        s = s.replace("\\\\", "\x00ROW\x00")
        # Discretionary math breaks carry no mathematical content.  They are
        # lane-local typography, just like \quad and thin-space commands.
        s = re.sub(r"\\(?:allowbreak|quad|qquad|[,;!:> ])", " ", s)
        s = s.replace("\x00ROW\x00", "\\\\")
        # Drop the blanked prose markers entirely rather than keeping them as position holders.
        # This check exists to prove the MATHEMATICS was copied and not retyped; where a display's
        # prose sits is a translation decision, and German grammar can leave a group with no
        # English slot at all. b3 i0275: the German display ends in the separable prefix of
        # "uebergehen" -- P ... in A und in B UEBER -- whose sense English carries in the verb
        # before the display ("passes over into"), so there is nothing left to put in a third
        # group. Keeping the markers made that correct translation read as altered mathematics.
        # Prose loss is still caught: the prose-length ratio below covers it.
        s = re.sub(r"(?:\\(?:text|hbox|mbox)\{\}\s*)+", "", s)
        s = re.sub(r"\s+", "", s)
        # A comma, full stop, colon, or semicolon placed at the outer end of a
        # math span is sentence punctuation, not mathematical content.  English
        # and German legitimately attach it on different sides of the delimiter.
        s = re.sub(r"[,.;:]+$", "", s)
        # INLINE ONLY: split a comma-separated list into its atoms. German packs ordinals into
        # one span -- $n^{\mathrm{te}}, a^{\mathrm{te}}, b^{\mathrm{te}}$ -- while the spec's own
        # ordinal ruling forces English to write "$n$th, $a$th, $b$th", i.e. three spans of the
        # same three symbols (b2 i0789). Inline math is already compared as an unordered multiset
        # across the page, so comparing atoms instead of packets tests which symbols are present
        # without pretending the two languages must punctuate them identically. A symbol dropped
        # from a list is still a missing atom, so nothing real is masked. Displays are NOT split:
        # they stay ordered and character-exact.
        if kind == "inline" and "," in s:
            depth, atom, atoms = 0, [], []
            for ch in s:
                if ch in "{([":
                    depth += 1
                elif ch in "})]":
                    depth -= 1
                if ch == "," and depth == 0:
                    atoms.append("".join(atom))
                    atom = []
                else:
                    atom.append(ch)
            atoms.append("".join(atom))
            atoms = [a for a in atoms if a]
            if len(atoms) > 1:
                for a in atoms:
                    norm.append((kind, "", a))
                continue
        norm.append((kind, re.sub(r"\s+", "", tag), s))
    # An inline that is empty after normalisation carries no comparable content. The one way
    # this arises is a bare ordinal superscript set as its own math span (47$^{\text{ten}}$
    # Grades, b1 i0430) -- the ordinal drop is sanctioned by the spec and leaves nothing, and
    # the English ("of degree 47") rightly has no math there at all.
    return [x for x in norm if not (x[0] == "inline" and x[2] == "")]


def prose(text):
    """Letters outside math and outside comments."""
    body = re.sub(r"(?<!\\)%.*", "", text)
    body = re.sub(r"\\weq\{.*?\}\{.*?\}(?=\s*$)", " ", body, flags=re.S | re.M)
    body = re.sub(r"(?<!\\)\\\[.*?(?<!\\)\\\]", " ", body, flags=re.S)
    body = re.sub(r"(?<!\\)\$.+?(?<!\\)\$", " ", body, flags=re.S)
    body = re.sub(r"(?<!\\)\\\(.*?(?<!\\)\\\)", " ", body, flags=re.S)
    # Count the visible ordinal suffix, not the implementation name of its TeX wrapper.
    # Source-faithful German-only typography such as ``12\textsuperscript{ten}`` otherwise
    # contributes the fifteen letters in ``textsuperscript`` eight times (b2 i0241) and creates
    # a false dropped-prose alarm.  This is intentionally narrow: later checks still need to see
    # markers such as \footnote, \glqq and \grqq in the returned text.
    body = re.sub(r"\\textsuperscript(?=\{)", "", body)
    return body


def printed_of(text):
    m = re.search(r"^%\s*!PRINTED\s+(\d+|none)\s*$", text, re.M)
    return m.group(1) if m else None


def check(tag, idx):
    problems = []
    de_p = os.path.join(collect.TEX, tag, "%s_i%04d.tex" % (tag, idx))
    en_p = os.path.join(EN, tag, "%s_i%04d.tex" % (tag, idx))
    q_p = os.path.join(QUERIES, "%s_i%04d.json" % (tag, idx))

    if not os.path.exists(en_p):
        return ["no English fragment"]
    # An English page with no German witness is not a translation of anything. It happens when
    # the lane is pointed at a pdf index the transcription lane deliberately skipped -- b2 has a
    # gap at 711-712, duplicate photographs of printed 688-689 already transcribed at 709-710.
    # Report it; do NOT crash the whole run on it, and never let one reach the edition.
    if not os.path.exists(de_p):
        return ["ORPHAN: English page with no German witness (%s missing) -- "
                "not part of the edition" % os.path.basename(de_p)]
    de = open(de_p, encoding="utf-8").read()
    en = open(en_p, encoding="utf-8").read()

    if printed_of(de) != printed_of(en):
        problems.append("printed header %s != German %s" % (printed_of(en), printed_of(de)))

    # Displays are compared IN ORDER: a display is a numbered step of an argument and nothing a
    # translator does may move one past another. Inline math is compared as a multiset, because
    # English word order legitimately moves it -- Weber's "durch Multiplication mit einer
    # niedrigeren Potenz von $a_0$ in eine ganze Function der $a$" comes out with $a$ before
    # $a_0$ in any English that is not a calque. Same symbols, same count, different order.
    ds, es = spans(de), spans(en)
    dd = [x for x in ds if x[0] != "inline"]
    ed = [x for x in es if x[0] != "inline"]
    if len(dd) != len(ed):
        problems.append("%d displays against %d in German" % (len(ed), len(dd)))
    else:
        for n, (d, e) in enumerate(zip(dd, ed)):
            if d != e:
                problems.append("display %d/%d altered: %s -> %s"
                                % (n + 1, len(dd), d[2][:60], e[2][:60]))
                break
    dseq = [x[2] for x in ds if x[0] == "inline"]
    eseq = [x[2] for x in es if x[0] == "inline"]
    di = collections.Counter(dseq)
    ei = collections.Counter(eseq)
    if di != ei:
        gone = list((di - ei).elements())
        new = list((ei - di).elements())

        def reconcile(seq, leftover_many, leftover_one):
            """Cancel a span on one side against CONSECUTIVE spans on the other.

            A source-line wrap can fall inside a formula, so the German may close one inline
            span at the end of a line and open its continuation at the start of the next
            (b3 i0280: the determinant ends line 45, its equals-one opens line 46), while the
            English -- wrapping elsewhere -- writes a single span. LaTeX sets both as one
            formula, so the two are the same page.

            Merging adjacent spans on both sides BEFORE comparing does not work: the two
            columns wrap at different points, so it cancels real pairs on one side and not the
            other. Tried that; it broke 13 Band II pages that had been passing. This runs only
            over spans already unmatched, so it can retire a false failure and never invent one.
            """
            for one in list(leftover_one):
                done = False
                for i in range(len(seq)):
                    if done:
                        break
                    acc = ""
                    for j in range(i, min(i + 4, len(seq))):
                        if seq[j] not in leftover_many:
                            break
                        acc += seq[j]
                        if acc == one and j > i:
                            for k in range(i, j + 1):
                                leftover_many.remove(seq[k])
                            leftover_one.remove(one)
                            done = True
                            break

        reconcile(dseq, gone, new)   # English wrote one span where German wrapped into several
        reconcile(eseq, new, gone)   # the reverse
        if gone or new:
            problems.append("inline math differs: German has %s, English has %s"
                            % (gone[:4] or "-", new[:4] or "-"))

    dp, ep = prose(de), prose(en)
    dl = sum(c.isalpha() for c in dp)
    el = sum(c.isalpha() for c in ep)
    # English runs longer than German in this register; well under parity means dropped text.
    if dl > 400 and el < 0.80 * dl:
        problems.append("prose %d letters against %d German -- material dropped" % (el, dl))

    # Footnotes carry bibliographic citations whose titles stay in German by the spec's
    # citation ruling, so they are exempt from the untranslated-German scan (the prose-length
    # check still covers a wholly untranslated footnote). Brace-counted strip, since footnote
    # bodies nest braces.
    def strip_footnotes(s):
        out, i = [], 0
        while True:
            j = s.find(r"\footnote{", i)
            if j < 0:
                out.append(s[i:])
                return "".join(out)
            out.append(s[i:j])
            k, depth = j + len(r"\footnote{"), 1
            while k < len(s) and depth:
                if s[k] == "{":
                    depth += 1
                elif s[k] == "}":
                    depth -= 1
                k += 1
            i = k
    # Quoted spans are citation titles, which stay in German by the same ruling (b2 i0516's
    # Kronecker titles sit in a body-set footnote block that the \footnote strip cannot see).
    def strip_quoted(s):
        s = re.sub(r"``.*?''", " ", s, flags=re.S)
        s = re.sub(r"\\glqq.*?\\grqq(?:\{\})?", " ", s, flags=re.S)
        return s
    left = GERMAN_TELLS.findall(strip_quoted(strip_footnotes(ep)))
    if len(left) >= 3:
        problems.append("untranslated German: %s" % " ".join(sorted(set(left))[:6]))

    if not os.path.exists(q_p):
        problems.append("no query file -- page was not audited")
    else:
        try:
            json.load(open(q_p, encoding="utf-8"))
        except Exception as exc:
            problems.append("query file unreadable: %s" % exc)
    return problems


def main():
    tag = sys.argv[1]
    rm = "--rm" in sys.argv
    d = os.path.join(EN, tag)
    idxs = sorted(int(m.group(1)) for m in
                  (re.match(r"%s_i(\d+)\.tex$" % tag, f) for f in os.listdir(d)) if m)
    ok = bad = 0
    nq = 0
    for i in idxs:
        probs = check(tag, i)
        if probs:
            bad += 1
            print("  i%04d  %s" % (i, "; ".join(probs)))
            if rm:
                os.remove(os.path.join(EN, tag, "%s_i%04d.tex" % (tag, i)))
        else:
            ok += 1
        q_p = os.path.join(QUERIES, "%s_i%04d.json" % (tag, i))
        if os.path.exists(q_p):
            try:
                nq += len(json.load(open(q_p, encoding="utf-8")).get("queries", []))
            except Exception:
                pass
    print("%s: %d pass, %d fail, %d audit queries raised" % (tag, ok, bad, nq))
    # This validator is also a build gate.  Printing failures while returning process success
    # lets callers such as build_en.py unknowingly compile a red lane, so make the command-line
    # contract match the report: any failed leaf yields a non-zero exit status.
    return 1 if bad else 0


if __name__ == "__main__":
    raise SystemExit(main())
