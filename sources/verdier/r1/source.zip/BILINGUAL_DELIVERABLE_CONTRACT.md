# Bilingual deliverable contract

Status: controlling  
Publication boundary: complete Astérisque 239; hard stop at physical p.270

## 1. Contracted scholarly layers

### 1.1 Canonical diplomatic French TeX

The diplomatic layer reproduces the publication as printed: wording, spelling,
accents, punctuation, capitalization, order, numbering, notation, formulae,
diagram content, source oddities, incomplete sentences, and unfinished
passages. TeX representation may modernize mechanics only when the visible and
mathematical result is reversible and source-faithful.

It does not silently correct the author, editor, printer, or inherited source.
It does not add proof headings or terminal symbols absent from print. It does
not import later Verdier material. Every page/unit is bound to direct NUMDAM
authority.

### 1.2 Separately corrected French TeX

Corrected French begins as an exact projection of diplomatic French. Every
difference is an explicit correction or declared reader normalization with a
stable ID, source form, corrected form, evidence, rationale, confidence,
visible-note disposition, inverse, affected scope, and supersession state.

No correction may conceal the thesis's unfinished state. A correction can
repair a demonstrable coquille; it cannot supply a missing proof, sentence, or
argument. Uncertain proposals remain candidates or notes, not silent text.

### 1.3 Source-aligned English TeX

English preserves mathematical objects, hypotheses, conclusions, logical
connectors, reference intent, formula and diagram structure, qualifications,
role boundaries, and incompleteness. Idiomatic English and declared reader
typography are permitted, but every functional departure from the French has a
reversible decision.

English does not use a later exposition as authority, silently strengthen a
claim, repair an authorial gap without notice, or attribute editor material to
Verdier. Every aligned unit is checked after the diplomatic source reading is
established.

### 1.4 Comparison and publication lineages

Comparison witnesses, source corrections, translation decisions, semantic
data, build artifacts, and public packages are not additional textual layers.
They are linked provenance lineages. No package projection may flatten their
roles into one undocumented “clean text.”

## 2. Unit identity and authorship contract

All three textual layers attach to one stable source-unit and semantic ID.
Every unit records:

- physical and printed/unnumbered pages;
- publication hierarchy;
- responsible agent: Verdier, Illusie, Maltsiniotis, publisher, or other
  explicitly identified contributor;
- role: thesis, preface, editors' note, front matter, index, bibliography,
  contents, or other apparatus;
- completion state, including incomplete or unfinished;
- three language-layer slice locators;
- formula, diagram, reference, terminology, notation, person, and bibliography
  bindings; and
- active decision and reversal IDs.

The same page PDF does not imply the same author. A TeX include boundary must
not cross an authorship or role boundary without an explicit composite unit.

## 3. Reader deliverables

Required local readers are:

1. complete diplomatic French reader;
2. complete corrected French reader with scholarly correction apparatus;
3. complete source-aligned English reader;
4. complete bilingual reader with stable cross-language navigation;
5. global table of contents and indexes useful across the complete issue; and
6. machine-readable graph and index data from which reader targets are derived.

Astérisque 239 is one bounded publication, so no cross-volume cumulative reader
is required beyond the complete-issue reader. “Cumulative” in this corpus means
the continuously updated complete-issue projection at meaningful checkpoints,
not a separate multi-work anthology. No other Verdier work is appended.

Reader PDFs contain scholarship only: the text, genuine historical/editorial
apparatus, correction notes, bibliography, contents, and mathematical indexes.
They exclude AI/model names, task IDs, private paths, build status, QA prose,
source hashes, workflow instructions, and release narration.

## 4. Diagram and formula contract

All delivered mathematical diagrams are native TeX. Private raster source
crops may support review but never serve as mathematical reader assets. Every
diagram has a stable ID, page and unit, node/edge inventory, native source
locus, direct evidence, lead review, and residual state.

Every displayed or mathematically consequential formula has a stable ID and
aligned layer forms. Formula source fidelity is independent of successful
compilation. Added or omitted factors, indices, primes, punctuation, brackets,
and labels require explicit decisions.

The source portrait is not a mathematical diagram. It remains a private,
rights-sensitive asset hold. Its printed caption can be transcribed. Embedding
the raster requires a separate lawful disposition.

## 5. Semantic and reference contract

One stable semantic graph is shared across languages. Reader links are a
projection. The graph includes all declared units, statements, proofs,
formulae, diagrams, objects, constructions, terminology, notation, people,
bibliography, decisions, and typed dependencies.

Reference candidates, admitted edges, and residuals remain separate. Final
reference completeness requires a complete source-derived candidate universe
partitioned exactly into active edges and typed residuals, with zero
unclassified rows and no false edges from TeX coordinates or number shape.

Stacks mappings are evidence-qualified candidates. No official tag is invented
or impersonated. General subject similarity is not an equivalence proof.

## 6. Rights and redistribution contract

Archival French TeX and local readers are required. Public redistribution is a
separate rights-aware gate and is not implied by local production authority.

Before any public candidate:

- inventory every source-derived asset;
- exclude authority PDFs and private crops;
- record the basis or hold for each included asset;
- avoid invented license language or permissions;
- scan source, PDF, metadata, package, and archive members for private/workflow
  content; and
- state precisely which textual layers and apparatus are being distributed.

An unresolved right produces a held public asset or local-only reader, not an
invented permission and not abandonment of the archival scholarly source.

## 7. Completion contract

No layer is complete until its complete source universe has been enumerated and
every unit passes on one exact generation. No bilingual completion exists until
all three textual layers, their shared graph, formulas, native diagrams,
reference partition, roles, unfinished-state parity, readers, privacy, rights,
package, and handoff gates are closed for pages 2--270.

A bounded build or opening checkpoint may be useful and reported. Its headline
must state the exact range and open holds. “Complete,” “canonical,” “sealed,”
“published,” and “read back” remain reserved for their typed gates.

## 8. Reversal contract

Every later correction identifies the earlier decision, why it was wrong,
which layer and copies were affected, exact inverse, repaired identities,
derived builds or graph rows superseded, bounded global search, and residual
result. The original decision remains. Frozen historical artifacts are not
silently edited; active successors are repaired copy-on-write.
