from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\verdier_derived_categories_bilingual_canonical_stacks_20260804_r1")
MANIFEST = ROOT / "RETROSPECTIVE_SOURCE_MANIFEST.csv"
VALIDATION = ROOT / "RETROSPECTIVE_VALIDATION.json"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def source_id(path: Path) -> str:
    normalized = str(path).replace("/", "\\").casefold().encode("utf-8")
    return "VDR-RET-SRC-" + hashlib.sha256(normalized).hexdigest()[:16].upper()


SOURCES: list[tuple[str, str, str, str, str, str]] = []


def add(
    category: str,
    role: str,
    path: str,
    read_completeness: str = "read_through_eof",
    read_by: str = "root",
    identity_kind: str = "immutable_or_snapshot_at_validation",
) -> None:
    SOURCES.append((category, role, path, read_completeness, read_by, identity_kind))


HANDOFF = r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\00_lane_control\CANONICAL_BILINGUAL_STACKS_FGA_TOHOKU_VERDIER_ILLUSIE_20260804_r1"
for rel, role in [
    ("00_START_HERE.md", "common_start"),
    ("01_COMMON_METHOD_AND_INVARIANTS.md", "common_method"),
    ("02_LOGBOOK_AND_REVERSAL_PROTOCOL.md", "logbook_reversal_protocol"),
    ("03_PRESTACKS_SEMANTIC_SCAFFOLD.md", "prestacks_protocol"),
    ("04_PRECEDENT_READING_LIST.csv", "precedent_manifest"),
    (r"FGA\README_START_HERE.md", "peer_corpus_brief"),
    (r"TOHOKU\README_START_HERE.md", "peer_corpus_brief"),
    (r"VERDIER\README_START_HERE.md", "verdier_corpus_brief"),
    (r"ILLUSIE_I_II\README_START_HERE.md", "peer_corpus_brief"),
    ("THREAD_ALLOCATIONS.csv", "ownership_allocation"),
    ("HANDOFF_SHA256SUMS.csv", "handoff_manifest"),
    ("HANDOFF_VALIDATION.json", "handoff_validation"),
    ("validate_handoff.ps1", "handoff_validator"),
]:
    add("common_handoff", role, str(Path(HANDOFF) / rel))

LANE = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\00_lane_control")
add("precedent", "user_verbatim_brief", r"C:\Users\Floris\Documents\interlanguage\00_governance\USER_VERBATIM_THREAD_BRIEF_20260717.md")
for name, role in [
    ("SUCCESSOR_SESSION_BOOTSTRAP_AND_LOGBOOK_PROTOCOL_20260803.md", "successor_bootstrap"),
    ("EGA_PRESTACKS_MACHINE_READABLE_INDEXING_SCAFFOLD_20260802.md", "ega_live_prestacks_scaffold"),
    ("PROJECT_LOGBOOK_METHODOLOGY_REPLICATION_DOI_REQUIREMENT_20260802.md", "dual_doi_logbook_rule"),
    ("CHAT_TRANSLATES_AND_CLEAN_PATH_RELOCATION_CONTROL_20260804.md", "resource_path_control"),
    ("SGA3_SESSION_A_EXPOSE_II_41_DIAGRAM_OMISSION_FAIL_CLOSE_20260729.md", "diagram_fail_close"),
]:
    add("precedent", role, str(LANE / name), read_by="root+forensic_subagent")
add("precedent", "diagram_cold_reverify", r"C:\Users\Floris\Documents\CHat translates and clean\SGA continuation 2\_claude_aid\_codex_confirmed_source_errors\CLAUDE_DIAGRAM_COLD_REVERIFY_METHOD_20260728.md", read_by="root+forensic_subagent")

for path, role in [
    (r"C:\Users\Floris\Documents\Papors\OS\AST_1996__239__R1_0.pdf", "verdier_controlling_authority"),
    (r"C:\Users\Floris\Documents\Papors\OS\Des categories derivees des categories abeliennes (Verdier J.-L.).djvu", "verdier_comparison_witness"),
    (r"C:\Users\Floris\Documents\Papors\OS\Des categories derivees des categories abeliennes (Verdier J.-L..pdf", "verdier_comparison_witness"),
]:
    add("verdier_authority", role, path, "binary_full_byte_replay", "root", "immutable")

EGA_HANDOFF = Path(r"C:\Users\Floris\Documents\interlanguage\04_handoffs\EGA_FRENCH_CANON_AND_ENGLISH_RECHECK_SESSION_HANDOFF_20260803_R1")
for name in [
    "README_START_HERE.md",
    "CURRENT_STATE_CURSOR_AND_OPEN_WORK.md",
    "DECISION_LOGGING_AND_QA_RULES.md",
    "FILE_TREE_MAP_AND_CUSTODY.md",
    "HANDOFF_BINDINGS.json",
    "HANDOFF_SHA256SUMS.csv",
    "HANDOFF_VALIDATION.json",
    "SUCCESSOR_BOOTSTRAP_PROMPT.md",
]:
    add("ega_handoff", "ega_successor_handoff", str(EGA_HANDOFF / name), read_by="root+ega_forensic_subagent", identity_kind="immutable")

EGA_BASE = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\EGA_English_Global_0_IV_complete_linked_reader_20260801_r1")
for name in ["STATUS.md", "README.md", "LOGBOOK.md"]:
    add("ega_english_first", "complete_english_baseline", str(EGA_BASE / name), read_by="root+ega_forensic_subagent", identity_kind="immutable")

EGA_FR = Path(r"C:\Users\Floris\Documents\interlanguage\Transcription\03_working_transcriptions\EGA_French_NUMDAM_canonical_TeX_20260801_r1")
for rel, role in [
    ("README.md", "french_root_policy"),
    ("CONTINUATION_HANDOFF.md", "french_continuation"),
    ("STATUS.md", "french_status"),
    ("LOGBOOK.md", "french_logbook"),
    (r"source\ega1\ega1-3-fr.tex", "french_source_witness"),
    (r"controls\AUTHORITY_SHA256.csv", "authority_manifest"),
    (r"controls\ENGLISH_NORMALIZATION_DECISION_AND_REVISION_POLICY_20260802.md", "normalization_reversal_policy"),
    (r"controls\EGA1_CHAPTER1_P112_VALIDATION_R35.json", "p112_validation"),
    (r"controls\FRENCH_DIPLOMATIC_TRANSCRIPTION_APPEND_P112_20260803.jsonl", "p112_french_decisions"),
    (r"controls\ENGLISH_CORRECTION_RECHECK_APPEND_P112_20260803.jsonl", "p112_english_decisions"),
    (r"controls\WORKFLOW_ERROR_APPEND_P112_20260803.jsonl", "p112_workflow_errors"),
    (r"controls\ENGLISH_CORRECTION_RECHECK_APPEND_20260802.jsonl", "p69_english_corrections"),
    (r"controls\WORKFLOW_ERROR_APPEND_P108_20260802.jsonl", "p108_workflow_errors"),
    (r"controls\ENGLISH_CORRECTION_RECHECK_APPEND_P108_20260802.jsonl", "p108_english_layer_decisions"),
    (r"controls\FRENCH_DIPLOMATIC_TRANSCRIPTION_APPEND_P108_20260802.jsonl", "p108_french_layer_decisions"),
    (r"controls\SEQUENTIAL_RAM_LIGHT_REUSE_FIRST_WORK_RULE_20260802.md", "resource_rule"),
]:
    add("ega_french_replay", role, str(EGA_FR / rel), read_by="root+ega_forensic_subagent", identity_kind="mutable_snapshot" if role in {"french_continuation", "french_status", "french_logbook", "french_source_witness"} else "immutable")

EGA_EN = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\EGA_English_Global_0_IV_french_recheck_source_successor_20260802_r1")
for rel, role in [
    ("STATUS.md", "english_repair_status"),
    ("LOGBOOK.md", "english_repair_logbook"),
    (r"source\ega1\ega1-3.tex", "english_repair_source"),
    (r"controls\SOURCE_INPUT_SHA256_R41.json", "english_r41_manifest"),
    (r"controls\SOURCE_DIFF_VALIDATION_R41.json", "english_r41_validation"),
]:
    add("ega_english_repair", role, str(EGA_EN / rel), read_by="root+ega_forensic_subagent", identity_kind="mutable_snapshot" if role in {"english_repair_status", "english_repair_logbook", "english_repair_source"} else "immutable")
add("ega_authority", "ega_i_controlling_pdf", r"C:\Users\Floris\Documents\Papors\OS\NUMDAM\EGA_I_PMIHES_1960_4.pdf", "binary_full_byte_replay", "root", "immutable")

for name, role in [
    ("SGA3_SESSION_A_NATIVE_DIAGRAM_COMPLETE_CLOSURE_20260729.md", "false_native_closure"),
    ("SGA3_SESSION_A_DIAGRAM_INVENTORY_COUNT_CORRECTION_AND_CLOSURE_20260729.md", "diagram_count_correction"),
    ("SGA3_EXPOSE_VII_NATIVE_DIAGRAM_REFERENCE_DETECTOR_FAIL_20260727.md", "false_semantic_edges"),
    ("SGA3_EXPOSE_VII_NATIVE_DIAGRAM_REFERENCE_DETECTOR_IDENTITY_CORRECTION_20260727.md", "detector_identity_correction"),
    ("SGA_FAC_GAGA_SEMANTIC_INDEXING_AND_FORMALIZATION_SCAFFOLD_20260802.md", "semantic_scaffold"),
    ("ARCHIVE_DECISION_RECORD_SGA3_R28_CLEAN_REFERENCE_COMPLETE_PUBLICATION_20260730.json", "reference_complete_claim"),
    ("ARCHIVE_DECISION_RECORD_SGA_SEMANTIC_PLANNING_QUEUE_RULE_R43_CORRECTION_20260730.json", "semantic_planning_correction"),
    ("ARCHIVE_DECISION_RECORD_MACHINE_READABLE_REFERENCE_CONVENTION_AND_EGA_ROUTING_20260723.json", "reference_convention_archive"),
    ("SGA3_SESSION_A_DIAGRAM_600_1200_EVIDENCE_APPEND_ONLY_CORRECTION_20260728.md", "resolution_evidence_correction"),
    ("SGA3_SESSION_A_NATIVE_DIAGRAM_REDO_NO_300DPI_CONTROL_20260728.md", "no_300dpi_control"),
    ("SGA3_EXPOSE_VII_HIGH_ZOOM_DIAGRAM_32_REPAIR_HOLD_20260727.md", "diagram_repair_hold"),
    ("SGA3_EXPOSE_V_HIGHZOOM_NATIVE_DIAGRAM_CLOSURE_20260729.md", "native_diagram_positive_precedent"),
    ("SGA_DIAGRAM_CLAUDE_STYLE_COLD_REVERIFY_HIGH_ZOOM_CONTROL_20260727.md", "high_zoom_control"),
    ("SGA2_IX_EXAMPLE15_PROPOSITION14_CROSS_REFERENCE_DEFECT_20260719.md", "kind_collision_reference_defect"),
    ("SGA2_IX_EXAMPLE15_PROPOSITION14_CROSS_REFERENCE_DEFECT_20260719_VALIDATION.json", "kind_collision_validation"),
    ("ARCHIVE_DECISION_RECORD_SGA3_COMPACT_BOUNDED_HISTORY_ZENODO_PUBLICATION_20260729.json", "raster_bearing_provisional_reader"),
]:
    add("sga_diagram_reference", role, str(LANE / name), read_by="semantic_diagram_forensic_subagent", identity_kind="immutable")

REF_ROOT = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\reference_machine_readable_20260722")
for name, role in [
    ("MACHINE_READABLE_INTERNAL_REFERENCES_CONVENTION_v2_EXHAUSTIVE.md", "exhaustive_reference_convention"),
    ("CLAUDE_WEBER_MACHINE_READABLE_REFERENCE_DELIVERY_20260723.md", "reference_delivery"),
    ("SGA_GLOBAL_CLICKABLE_REFERENCE_AGENDA_20260723.md", "reference_agenda"),
]:
    add("sga_reference", role, str(REF_ROOT / name), read_by="semantic_diagram_forensic_subagent", identity_kind="mutable_snapshot")
add("sga_reference", "r43_validation", r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\sga3_full_native_cumulative_reference_v2_semantic_closure_20260730_r43\VALIDATION_R43.json", read_by="semantic_diagram_forensic_subagent", identity_kind="immutable")
add("sga_reference", "r28_candidate_validation", r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\sga3_full_native_cumulative_reference_v2_lexical_context_20260730_r28_planning\REFERENCE_CANDIDATE_LEXICAL_CONTEXT_R28_VALIDATION.json", read_by="semantic_diagram_forensic_subagent", identity_kind="immutable")

COMP_ROOT = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\sga3_english_loop1_full_volume_integration_20260728_r3_tomeI_index_complete\tex\components")
for name in [
    "10_expose_II_s1_s2_hom_dual_numbers.tex",
    "11_expose_II_s3_tangent_bundle_condition_E.tex",
    "12_expose_II_s41_s44_lie_algebras.tex",
    "13_expose_II_s45_s411_lie_structure.tex",
    "14_expose_II_s5_s6_examples_misc.tex",
]:
    add("sga_direct_source", "omitted_png_backed_diagram_component", str(COMP_ROOT / name), read_by="semantic_diagram_forensic_subagent", identity_kind="immutable")

FAC_ROOT = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\06_publication_candidates\FAC_Accidental_Blind_Comparator_Methodology_Evidence_20260803_r1")
for name in [
    "ARTIFACT_TOOL_PACKAGE_CSV_VALIDATION.json",
    "BLIND_COMPARATOR_GENERATION_VALIDATION.json",
    "BLIND_COMPARATOR_INPUT_IDENTITIES.csv",
    "FAC_ACCIDENTAL_DUPLICATION_BLIND_COMPARATOR_METHODOLOGY_EVIDENCE.md",
    "FAC_BLIND_COMPARATOR_ALL_79_FINDINGS.csv",
    "FAC_BLIND_COMPARATOR_ALL_79_UNIT_REVIEWS.csv",
    "FAC_BLIND_COMPARATOR_ALL_79_VALIDATION.json",
    "FAC_BLIND_COMPARATOR_FINAL_METHODOLOGY_REPORT.md",
    "FAC_BLIND_COMPARATOR_INVENTORY.csv",
    "FAC_EDITORIAL_DECISION_LOGBOOK_SNAPSHOT.md",
    "FAC_EDITORIAL_SELF_CORRECTION_LEDGER_PRIVACY_CLEAN.csv",
    "FAC_PROJECT_LOGBOOK_SNAPSHOT.md",
    "FAC_SOURCE_AND_COMPARATOR_IDENTITIES.csv",
    "METHODOLOGY_EVIDENCE_READINESS.md",
    "PACKAGE_VALIDATION.json",
    "PROJECT_LOGBOOK_METHODOLOGY_REPLICATION_DOI_REQUIREMENT_20260802.md",
    "README.md",
    "RIGHTS_AND_PROVENANCE.md",
    "ZENODO_PAYLOAD_MANIFEST.csv",
]:
    add("fac_forensic_package", "fac_package_evidence", str(FAC_ROOT / name), read_by="sga_fac_forensic_subagent", identity_kind="immutable")

for name, role in [
    ("SHARED_DECISION_LOG_LOCKED_APPEND_PROTOCOL_20260720.md", "locked_append_protocol"),
    ("DECISION_LOGGING_DIRECTIVE_20260718.md", "decision_logging_directive"),
    ("append_english_germanic_decision_log.ps1", "locked_append_helper"),
    ("validate_english_germanic_decision_log.py", "decision_log_validator"),
    ("SGA5_SGA6_PUBLICATION_RECONCILIATION_20260718.md", "publication_reconciliation"),
    ("SGA5_SGA6_PUBLICATION_RECONCILIATION_20260718.json", "publication_reconciliation_machine"),
    ("ARCHIVE_DECISION_RECORD_ENGLISH_GERMANIC_LOG_PRIVACY_REMEDIATION_20260803.json", "privacy_remediation"),
    ("ARCHIVE_DECISION_RECORD_ENGLISH_GERMANIC_LOG_PRIVACY_COUNT_CORRECTION_20260803.json", "privacy_count_correction"),
    ("ARCHIVE_DECISION_RECORD_ENGLISH_GERMANIC_LOG_PRIVACY_RESIDUAL_TASK_ID_REMEDIATION_20260803.json", "privacy_residual_correction"),
    ("ARCHIVE_PROACTIVE_PRIVACY_AND_SUBSTANTIVE_UPDATE_REQUIREMENT_20260802.md", "privacy_archive_rule"),
    ("ARCHIVE_DECISION_RECORD_FAC_BLIND_COMPARATOR_TRANSPORT_ACCEPTED_20260803_0349.json", "fac_transport_replay"),
    ("ARCHIVE_DECISION_RECORD_FAC_BLIND_COMPARATOR_DUAL_DOI_PUBLISHED_20260803_0421.json", "fac_dual_doi_readback"),
    ("ARCHIVE_DECISION_RECORD_EGA_READER_SHELF_CONCEPT_DOI_CORRECTION_20260801.json", "ega_doi_correction"),
    ("ARCHIVE_DECISION_RECORD_STEINITZ_CONCEPT_DOI_CORRECTION_20260802.json", "steinitz_doi_correction"),
    ("ARCHIVE_DECISION_RECORD_SGA_READER_BODY_CLEAN_ZENODO_PUBLICATION_20260729.json", "reader_cleanup_v1"),
    ("ARCHIVE_DECISION_RECORD_SGA_READER_BODY_CLEAN_V2_ZENODO_PUBLICATION_20260729.json", "reader_cleanup_v2"),
    ("SGA1_REFERENCE_V2_SUCCESSOR_READER_PRESENTATION_HOLD_20260730.md", "reader_presentation_hold"),
    ("ARCHIVE_DECISION_RECORD_SGA_READER_AI_BADGE_AND_NOTES_REMOVAL_20260729.json", "reader_ai_badge_cleanup"),
    ("ENGLISH_GERMANIC_DECISION_LOG_20260718.md", "retrospective_decision_log"),
    ("SGA_TRANSLATION_RESOURCE_EFFICIENCY_INCIDENT_NOTE_20260728.md", "resource_incident"),
    ("PUBLICATION_HANDOFF_RULE_20260718.md", "publication_handoff_rule"),
    ("SGA_COMPACT_SUCCESSOR_SGA2_R8_SGA5_R9_SGA6_STAGING_READY_20260723.md", "compact_successor_control"),
    ("RESEARCH_HANDOFF_INTEGRATION_20260717.md", "research_handoff"),
    ("SGA5_ENGLISH_SOURCECHECKED_HANDOFF_20260717.md", "weak_handoff"),
    ("MACHINE_READABLE_LEDGER_REQUIREMENT_20260718.md", "machine_ledger_rule"),
    ("ARCHIVE_DECISION_RECORD_NOETHER_R823_FULL_COMPACT_PUBLIC_READBACK_20260723.json", "member_readback_precedent"),
    ("ARCHIVE_DECISION_RECORD_ACTIVE_FAC_EGA_PROVENANCE_V4_CLOSED_20260803_0047.json", "active_provenance_closeout"),
]:
    add("archive_log_privacy", role, str(LANE / name), read_by="root+archive_forensic_subagent", identity_kind="immutable_or_live_snapshot")

add("archive_log_privacy", "producer_log_regression_receipt", r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\sga1_english_source_sync_workpass\SHARED_DECISION_LOG_TRANSIENT_REGRESSION_AND_RECONCILIATION_I_9_12_NOTE_20260719.md", read_by="archive_forensic_subagent", identity_kind="immutable")

GAGA_SOURCE = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\serre_gaga_bilingual_source_aligned_successor_20260803_r1")
for rel, role in [
    ("STATUS.md", "source_aligned_status"),
    ("LOGBOOK.md", "source_aligned_logbook"),
    ("EDITORIAL_DECISION_LOGBOOK.md", "source_aligned_editorial_decisions"),
    (r"frozen_first_pass\README.md", "first_pass_reader_failure_receipt"),
    (r"frozen_first_pass\STATUS_PUBLIC.md", "first_pass_public_claim_boundary"),
    (r"frozen_first_pass\SOURCE_NOTES.md", "first_pass_source_readings"),
    (r"frozen_first_pass\CUSTODY_VALIDATION.json", "first_pass_custody_validation"),
    (r"frozen_first_pass\SHA256SUMS.csv", "first_pass_manifest"),
    (r"frozen_first_pass\gaga.tex", "first_pass_master_with_private_comments"),
    (r"comparison_waring_english_20260803\COMPARISON_CONTROL.md", "comparison_lineage_control"),
]:
    add("gaga_forensic", role, str(GAGA_SOURCE / rel), read_by="gaga_deligne_forensic_subagent", identity_kind="immutable_or_snapshot_at_validation")
add("gaga_forensic", "gaga_controlling_authority", str(GAGA_SOURCE / r"authority\AIF_1956__6__1_0.pdf"), "binary_full_byte_replay", "gaga_deligne_forensic_subagent", "immutable")

GAGA_REF = Path(r"C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\serre_gaga_bilingual_reference_v2_successor_20260803_r1")
for rel, role in [
    ("STATUS.md", "reference_v2_status"),
    ("LOGBOOK.md", "reference_v2_logbook"),
    ("EDITORIAL_DECISION_LOGBOOK.md", "reference_v2_editorial_decisions"),
    (r"controls\PROVENANCE.csv", "provenance"),
    (r"controls\TRANSLATION_LINEAGES.csv", "stale_translation_lineage"),
    (r"controls\SOURCE_CORRECTION_LEDGER.csv", "source_corrections"),
    (r"controls\SOURCE_CORRECTION_APPLICATIONS.csv", "source_correction_applications"),
    (r"controls\TRANSCRIPTION_REPAIR_LEDGER.csv", "transcription_repairs"),
    (r"controls\REVISION_HISTORY.csv", "revision_history"),
    (r"controls\UNCERTAIN_READING_LEDGER.csv", "stale_uncertainty_state"),
    (r"controls\REFERENCE_TARGETS.csv", "reference_targets"),
    (r"controls\REFERENCE_CANDIDATES.csv", "reference_candidates"),
    (r"controls\REFERENCE_EDGES.csv", "reference_edges"),
    (r"controls\REFERENCE_RESIDUALS.csv", "reference_residuals"),
    (r"controls\REFERENCE_GRAPH_VALIDATION.json", "reference_graph_validation"),
    (r"controls\REFERENCE_V2_PDF_VALIDATION.json", "reference_pdf_validation"),
    (r"controls\INTERNAL_REFERENCE_LINK_APPLICATION.json", "internal_link_application"),
    (r"controls\BIBLIOGRAPHY_LINK_APPLICATION.json", "bibliography_link_application"),
    (r"controls\FRENCH_LAYOUT_REPAIR_VALIDATION.json", "final_french_identity_receipt"),
    (r"controls\FRENCH_LADDER_LAYOUT_REVIEW_PASS.md", "french_layout_review"),
    (r"controls\LAYOUT_VISUAL_REVIEW_PASS.md", "reader_layout_review"),
    ("GAGA_ARCHIVE_HANDOFF_20260803_r1.md", "archive_handoff"),
    ("GAGA_ARCHIVE_DISPATCH_RECEIPT_20260803_r1.md", "dispatch_claim_boundary"),
]:
    add("gaga_forensic", role, str(GAGA_REF / rel), read_by="gaga_deligne_forensic_subagent", identity_kind="immutable_or_snapshot_at_validation")

for name, role in [
    ("ARCHIVE_DECISION_RECORD_DELIGNE_METHODOLOGY_CURRENT_HEAD_CATALOG_SYNC_20260802.json", "deligne_stale_catalog_correction"),
    ("ARCHIVE_DECISION_RECORD_DELIGNE_D001_SOURCE_ALIGNED_CLOSEOUT_20260801.json", "deligne_diplomatic_layer_gap"),
]:
    add("deligne_forensic", role, str(LANE / name), read_by="gaga_deligne_forensic_subagent", identity_kind="immutable")


ARTIFACT_NAMES = [
    "PREDECESSOR_FAILURE_FORENSIC_AUDIT.md",
    "PARENT_TASK_HISTORY_EVIDENCE.md",
    "FAILURE_MODE_REGISTER.csv",
    "BINDING_SAFEGUARDS.md",
    "DO_NOT_REPEAT_AND_BOUNDED_OPERATING_PROTOCOL.md",
    "AUTHORITY_AND_COMPARISON_LINEAGE.md",
    "BILINGUAL_DELIVERABLE_CONTRACT.md",
    "PRESTACKS_SEMANTIC_SCAFFOLD_DESIGN.md",
    "ASSUMPTION_NORMALIZATION_AND_REVERSAL_LEDGER.csv",
    "CONTINUATION_HANDOFF.md",
    "STATUS.md",
    "PROJECT_LOGBOOK.md",
    "SOURCE_AUTHORITY.csv",
]

FROZEN_DRAFTS = {
    "content/fr_diplomatic/0001_title_classification_portrait_preface.tex": (5149, "5AA82E486025105078FA54507A044508E65EA312825C49825E9B74519B9EC61B"),
    "content/fr_corrected/0001_title_classification_portrait_preface.tex": (5149, "5AA82E486025105078FA54507A044508E65EA312825C49825E9B74519B9EC61B"),
    "content/en/0001_title_classification_portrait_preface.tex": (4899, "59E46844F8FFA82479F744D3C089FFCF58FD69141B92B09A7C01FC5F565CC4C2"),
    "content/parallel/0001_title_classification_portrait_preface.tex": (9561, "EAFD244A28E42B891A1D744784F82E8BA969C62D06E1D1967C1FA97BDD20B30B"),
}


def build_manifest(observed: str) -> tuple[list[dict[str, object]], list[str]]:
    errors: list[str] = []
    dedup: dict[str, tuple[str, str, str, str, str, str]] = {}
    for item in SOURCES:
        key = str(Path(item[2])).replace("/", "\\").casefold()
        if key in dedup:
            prior = dedup[key]
            merged_role = ";".join(sorted(set((prior[1] + ";" + item[1]).split(";"))))
            merged_read_by = ";".join(sorted(set((prior[4] + ";" + item[4]).split(";"))))
            dedup[key] = (prior[0], merged_role, prior[2], prior[3], merged_read_by, prior[5])
        else:
            dedup[key] = item

    rows: list[dict[str, object]] = []
    for category, role, raw_path, read_completeness, read_by, identity_kind in sorted(dedup.values(), key=lambda x: str(Path(x[2])).replace("/", "\\").casefold()):
        path = Path(raw_path)
        if not path.is_file():
            errors.append(f"missing_source:{path}")
            continue
        rows.append(
            {
                "source_id": source_id(path),
                "category": category,
                "role": role,
                "path": str(path),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                "read_completeness": read_completeness,
                "read_by": read_by,
                "identity_kind": identity_kind,
                "observed_at_utc": observed,
                "notes": "Exact bounded forensic source; no predecessor mutation.",
            }
        )
    ids = [str(row["source_id"]) for row in rows]
    if len(ids) != len(set(ids)):
        errors.append("duplicate_source_id")
    paths = [str(row["path"]).casefold() for row in rows]
    if len(paths) != len(set(paths)):
        errors.append("duplicate_source_path")
    return rows, errors


def write_manifest(rows: list[dict[str, object]]) -> None:
    fields = [
        "source_id",
        "category",
        "role",
        "path",
        "bytes",
        "sha256",
        "read_completeness",
        "read_by",
        "identity_kind",
        "observed_at_utc",
        "notes",
    ]
    with MANIFEST.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def validate(observed: str, source_rows: list[dict[str, object]], initial_errors: list[str]) -> dict[str, object]:
    errors = list(initial_errors)
    checks: dict[str, object] = {}

    retrospective_interval_delta = 1221786 - 882796
    if retrospective_interval_delta < 100000:
        errors.append(f"retrospective_minimum_not_met:{retrospective_interval_delta}<100000")

    replay_errors: list[str] = []
    for row in source_rows:
        path = Path(str(row["path"]))
        if not path.is_file():
            replay_errors.append(f"missing:{path}")
            continue
        if path.stat().st_size != int(row["bytes"]):
            replay_errors.append(f"bytes:{path}")
        if sha256(path) != str(row["sha256"]):
            replay_errors.append(f"sha256:{path}")
        if row["read_completeness"] not in {"read_through_eof", "semantic_parse_through_eof", "binary_full_byte_replay"}:
            replay_errors.append(f"read_incomplete:{path}")
    errors.extend(replay_errors)
    binary_suffixes = {".pdf", ".djvu", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".zip"}
    binary_source_bytes = sum(int(row["bytes"]) for row in source_rows if Path(str(row["path"])).suffix.casefold() in binary_suffixes)
    textual_or_code_source_bytes = sum(int(row["bytes"]) for row in source_rows if Path(str(row["path"])).suffix.casefold() not in binary_suffixes)
    checks["source_manifest"] = {
        "rows": len(source_rows),
        "bytes": sum(int(row["bytes"]) for row in source_rows),
        "binary_source_bytes": binary_source_bytes,
        "textual_or_code_source_bytes": textual_or_code_source_bytes,
        "categories": sorted({str(row["category"]) for row in source_rows}),
        "read_complete_rows": sum(1 for row in source_rows if row["read_completeness"] in {"read_through_eof", "semantic_parse_through_eof", "binary_full_byte_replay"}),
        "replay_errors": replay_errors,
        "manifest_bytes": MANIFEST.stat().st_size if MANIFEST.exists() else None,
        "manifest_sha256": sha256(MANIFEST) if MANIFEST.exists() else None,
    }

    artifacts: list[dict[str, object]] = []
    for name in ARTIFACT_NAMES + ["RETROSPECTIVE_SOURCE_MANIFEST.csv"]:
        path = ROOT / name
        if not path.is_file():
            errors.append(f"missing_artifact:{name}")
            continue
        artifacts.append({"path": name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    checks["retrospective_artifacts"] = artifacts
    artifact_minimum_bytes = {
        "PREDECESSOR_FAILURE_FORENSIC_AUDIT.md": 50000,
        "PARENT_TASK_HISTORY_EVIDENCE.md": 10000,
        "FAILURE_MODE_REGISTER.csv": 40000,
        "BINDING_SAFEGUARDS.md": 40000,
        "DO_NOT_REPEAT_AND_BOUNDED_OPERATING_PROTOCOL.md": 8000,
        "BILINGUAL_DELIVERABLE_CONTRACT.md": 6000,
        "PRESTACKS_SEMANTIC_SCAFFOLD_DESIGN.md": 9000,
        "CONTINUATION_HANDOFF.md": 9000,
    }
    for name, minimum in artifact_minimum_bytes.items():
        path = ROOT / name
        if not path.exists() or path.stat().st_size < minimum:
            errors.append(f"artifact_below_substantive_minimum:{name}:{path.stat().st_size if path.exists() else 'missing'}<{minimum}")
    if len(source_rows) < 160:
        errors.append(f"source_manifest_too_narrow:{len(source_rows)}<160")
    if textual_or_code_source_bytes < 1_000_000:
        errors.append(f"textual_forensic_surface_too_small:{textual_or_code_source_bytes}<1000000")
    checks["substantive_minimums"] = {
        "artifact_minimum_bytes": artifact_minimum_bytes,
        "source_row_minimum": 160,
        "textual_or_code_source_byte_minimum": 1_000_000,
        "source_rows_actual": len(source_rows),
        "textual_or_code_source_bytes_actual": textual_or_code_source_bytes,
    }

    try:
        with (ROOT / "FAILURE_MODE_REGISTER.csv").open(encoding="utf-8-sig", newline="") as handle:
            modes = list(csv.DictReader(handle))
        mode_ids = [row["failure_mode_id"] for row in modes]
        required_ids = {f"VDR-FM-{n:04d}" for n in range(1, 62)}
        if len(mode_ids) != len(set(mode_ids)):
            errors.append("failure_register_duplicate_ids")
        missing_modes = sorted(required_ids - set(mode_ids))
        if missing_modes:
            errors.append("failure_register_missing:" + ",".join(missing_modes))
        required_fields = {"incident_and_evidence", "root_cause", "affected_artifacts", "detection", "corrective_control", "recurrence_test", "evidence_sources", "verdier_disposition"}
        for row in modes:
            if any(not row.get(field, "").strip() for field in required_fields):
                errors.append(f"failure_register_empty_required:{row.get('failure_mode_id')}")
        checks["failure_register"] = {"rows": len(modes), "unique_ids": len(mode_ids) == len(set(mode_ids)), "required_ids_present": not missing_modes}
    except Exception as exc:
        errors.append(f"failure_register_parse:{exc}")

    safeguards_text = (ROOT / "BINDING_SAFEGUARDS.md").read_text(encoding="utf-8")
    safeguard_ids = re.findall(r"VDR-SG-\d{4}", safeguards_text)
    required_safeguards = {f"VDR-SG-{n:04d}" for n in range(1, 55)}
    if required_safeguards - set(safeguard_ids):
        errors.append("missing_safeguards:" + ",".join(sorted(required_safeguards - set(safeguard_ids))))
    if len(set(safeguard_ids)) != 54:
        errors.append(f"safeguard_unique_count:{len(set(safeguard_ids))}")
    checks["binding_safeguards"] = {"unique_ids": len(set(safeguard_ids)), "required_1_through_54": required_safeguards <= set(safeguard_ids)}

    try:
        with (ROOT / "ASSUMPTION_NORMALIZATION_AND_REVERSAL_LEDGER.csv").open(encoding="utf-8-sig", newline="") as handle:
            assumptions = list(csv.DictReader(handle))
        assumption_ids = [row["ledger_id"] for row in assumptions]
        if len(assumption_ids) != len(set(assumption_ids)):
            errors.append("assumption_ledger_duplicate_ids")
        if not {f"VDR-RETRO-ANR-{n:04d}" for n in range(1, 14)} <= set(assumption_ids):
            errors.append("assumption_ledger_missing_bootstrap_rows")
        assumption_lookup = {row["ledger_id"]: row for row in assumptions}
        timestamp_supersessions = {
            "VDR-RETRO-ANR-0010": "VDR-RETRO-ANR-0007",
            "VDR-RETRO-ANR-0011": "VDR-RETRO-ANR-0008",
            "VDR-RETRO-ANR-0012": "VDR-RETRO-ANR-0009",
        }
        bad_timestamp_supersessions = [
            newer for newer, older in timestamp_supersessions.items()
            if assumption_lookup.get(newer, {}).get("supersedes_id") != older
        ]
        if bad_timestamp_supersessions:
            errors.append("assumption_ledger_timestamp_supersession:" + ",".join(bad_timestamp_supersessions))
        checks["assumption_ledger"] = {
            "rows": len(assumptions),
            "unique_ids": len(assumption_ids) == len(set(assumption_ids)),
            "timestamp_corrections_append_only": not bad_timestamp_supersessions,
            "retrospective_interval_delta_row_present": "VDR-RETRO-ANR-0013" in assumption_lookup,
        }
    except Exception as exc:
        errors.append(f"assumption_ledger_parse:{exc}")

    audit_text = (ROOT / "PREDECESSOR_FAILURE_FORENSIC_AUDIT.md").read_text(encoding="utf-8")
    mandatory_audit_terms = [
        "English-first",
        "Layer collapse",
        "OCR",
        "Raster delivery",
        "Reference-complete",
        "pre-Stacks",
        "Stacks mappings",
        "Shared append log",
        "workflow prose",
        "Privacy counts",
        "duplicate concept",
        "raw member readback",
        "False completion",
        "Resource safety",
        "Successor-continuation section",
        "global correction",
        "unfinished",
        "100,000",
        "GAGA",
        "Deligne",
        "parent-task history",
    ]
    missing_terms = [term for term in mandatory_audit_terms if term.casefold() not in audit_text.casefold()]
    if missing_terms:
        errors.append("audit_missing_topics:" + ",".join(missing_terms))
    checks["audit_topics"] = {"required": len(mandatory_audit_terms), "missing": missing_terms}

    history_text = (ROOT / "PARENT_TASK_HISTORY_EVIDENCE.md").read_text(encoding="utf-8")
    history_requirements = [
        "twelve consecutive",
        "113 turn summaries",
        "hasMore: false",
        "019f711e-e016-7d73-9d56-8eab55a75633",
        "c8bcbaf5-72be-4960-8dd2-6c0a0df23479",
        "f1fb7af4-0a3b-4a9c-8e06-0ff8b3e0c4d6",
        "PARENT_TASK_HISTORY_EVIDENCE",
    ]
    missing_history = [term for term in history_requirements if term.casefold() not in history_text.casefold()]
    if missing_history:
        errors.append("parent_history_missing:" + ",".join(missing_history))
    checks["parent_task_history"] = {
        "thread_id": "019f711e-cac3-7a10-a0e6-dc0131799c3a",
        "page_count": 12,
        "turn_summary_count": 113,
        "terminal_has_more": False,
        "stable_whole_thread_hash_available": False,
        "missing_requirements": missing_history,
    }

    try:
        gaga_uncertain = GAGA_REF / r"controls\UNCERTAIN_READING_LEDGER.csv"
        with gaga_uncertain.open(encoding="utf-8-sig", newline="") as handle:
            uncertain_rows = list(csv.DictReader(handle))
        statuses = [row.get("status", "") for row in uncertain_rows]
        supersedes = [row.get("supersedes", "") for row in uncertain_rows]
        if len(uncertain_rows) != 82 or set(statuses) != {"carried_forward_for_adjudication"} or any(value.strip() for value in supersedes):
            errors.append("gaga_uncertainty_evidence_drift")

        graph_files = {
            "targets": GAGA_REF / r"controls\REFERENCE_TARGETS.csv",
            "candidates": GAGA_REF / r"controls\REFERENCE_CANDIDATES.csv",
            "edges": GAGA_REF / r"controls\REFERENCE_EDGES.csv",
            "residuals": GAGA_REF / r"controls\REFERENCE_RESIDUALS.csv",
        }
        graph_counts: dict[str, int] = {}
        graph_headers: dict[str, list[str]] = {}
        for label, path in graph_files.items():
            with path.open(encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.DictReader(handle))
                graph_counts[label] = len(rows)
                graph_headers[label] = list(rows[0].keys()) if rows else []
        expected_graph_counts = {"targets": 126, "candidates": 325, "edges": 245, "residuals": 80}
        if graph_counts != expected_graph_counts:
            errors.append(f"gaga_graph_count_drift:{graph_counts}")
        forbidden_as_missing_design_fields = {"printed_page", "diagram_id", "relation_type", "evidence", "confidence", "stacks_tag", "french_locator"}
        present_design_fields = sorted(forbidden_as_missing_design_fields & {field.casefold() for headers in graph_headers.values() for field in headers})
        if present_design_fields:
            errors.append("gaga_graph_expected_historical_schema_changed:" + ",".join(present_design_fields))
        checks["gaga_forensic_replay"] = {
            "uncertainty_rows": len(uncertain_rows),
            "uncertainty_statuses": sorted(set(statuses)),
            "nonempty_supersedes": sum(1 for value in supersedes if value.strip()),
            "graph_counts": graph_counts,
            "graph_headers": graph_headers,
            "historically_missing_design_fields": sorted(forbidden_as_missing_design_fields),
        }
    except Exception as exc:
        errors.append(f"gaga_forensic_replay:{exc}")

    required_source_identities = {
        str(GAGA_SOURCE / r"authority\AIF_1956__6__1_0.pdf").casefold(): (4134102, "9898F985DD6932496E26450BFE0BECA8655A937032F545B97CEBD88D1BC8EB98"),
        str(GAGA_REF / r"controls\UNCERTAIN_READING_LEDGER.csv").casefold(): (31379, "64255FBCD06D16380E987BCB7E6C7F6F7E1A56DD3E9403D8EF6CA8F2F218AED8"),
        str(LANE / "ARCHIVE_DECISION_RECORD_DELIGNE_METHODOLOGY_CURRENT_HEAD_CATALOG_SYNC_20260802.json").casefold(): (15953, "3AB2C4D4BEA03819BFE1C85BF5B4AC16842B92A5E44F4AF020BC93C736E13F7F"),
        str(LANE / "ARCHIVE_DECISION_RECORD_DELIGNE_D001_SOURCE_ALIGNED_CLOSEOUT_20260801.json").casefold(): (6405, "A8A1ED53294AFCAEB64D41CB15CD63BC4CEA0F5E8121504919A8EF1E96F1FA53"),
    }
    source_lookup = {str(row["path"]).casefold(): row for row in source_rows}
    exact_identity_results: list[dict[str, object]] = []
    for path_key, (expected_bytes, expected_sha) in required_source_identities.items():
        row = source_lookup.get(path_key)
        match = row is not None and int(row["bytes"]) == expected_bytes and str(row["sha256"]) == expected_sha
        if not match:
            errors.append(f"required_source_identity_mismatch:{path_key}")
        exact_identity_results.append({"path": path_key, "expected_bytes": expected_bytes, "expected_sha256": expected_sha, "match": match})
    checks["supplement_exact_identities"] = exact_identity_results

    frozen: list[dict[str, object]] = []
    for rel, (expected_bytes, expected_sha) in FROZEN_DRAFTS.items():
        path = ROOT / rel
        actual_bytes = path.stat().st_size if path.exists() else None
        actual_sha = sha256(path) if path.exists() else None
        match = actual_bytes == expected_bytes and actual_sha == expected_sha
        if not match:
            errors.append(f"frozen_draft_mismatch:{rel}")
        frozen.append({"path": rel, "expected_bytes": expected_bytes, "actual_bytes": actual_bytes, "expected_sha256": expected_sha, "actual_sha256": actual_sha, "match": match})
    checks["frozen_drafts"] = frozen

    try:
        with (ROOT / "SOURCE_AUTHORITY.csv").open(encoding="utf-8-sig", newline="") as handle:
            authority_rows = list(csv.DictReader(handle))
        controlling = [row for row in authority_rows if row["role"] == "controlling_authority"]
        authority_ok = len(authority_rows) == 3 and len(controlling) == 1 and controlling[0]["sha256"] == "6214C252BACEBA5584E3C4AEB564C129851941C1A9250BABAB45B79A3939B0AE" and controlling[0]["pages"] == "270"
        if not authority_ok:
            errors.append("authority_lineage_mismatch")
        checks["authority_lineage"] = {"rows": len(authority_rows), "controlling_rows": len(controlling), "exact": authority_ok}
    except Exception as exc:
        errors.append(f"authority_parse:{exc}")

    reader_paths = [
        ROOT / "reader_fr_diplomatic.tex",
        ROOT / "reader_fr_corrected.tex",
        ROOT / "reader_english.tex",
        ROOT / "reader_bilingual.tex",
    ] + sorted((ROOT / "content").rglob("*.tex")) + sorted((ROOT / "tex").rglob("*.tex")) + sorted((ROOT / "tex").rglob("*.sty"))
    reader_patterns = {
        "absolute_user_path": re.compile(r"C:\\Users\\", re.I),
        "task_uuid": re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I),
        "ai_or_workflow": re.compile(r"\b(?:OpenAI|Anthropic|ChatGPT|Claude|Codex|workflow status|build status|source and status note)\b", re.I),
    }
    reader_hits: list[dict[str, object]] = []
    for path in reader_paths:
        text = path.read_text(encoding="utf-8", errors="replace")
        for label, pattern in reader_patterns.items():
            matches = pattern.findall(text)
            if matches:
                reader_hits.append({"path": str(path.relative_to(ROOT)), "class": label, "count": len(matches)})
    if reader_hits:
        errors.append("reader_privacy_or_workflow_hits")

    control_locator_files = [ROOT / name for name in ARTIFACT_NAMES] + [MANIFEST]
    private_locator_hits = 0
    other_user_hits: list[str] = []
    email_hits: list[str] = []
    for path in control_locator_files:
        if not path.exists():
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        private_locator_hits += len(re.findall(r"C:\\Users\\Floris(?:\\|\b)", text, flags=re.I))
        other_user_hits.extend(f"{path.name}:{name}" for name in re.findall(r"C:\\Users\\([^\\\s,;\"']+)", text, flags=re.I) if name.casefold() != "floris")
        email_hits.extend(f"{path.name}:{email}" for email in re.findall(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", text, flags=re.I))
    if other_user_hits:
        errors.append("unexpected_other_user_paths")
    if email_hits:
        errors.append("unexpected_email_addresses")
    checks["privacy"] = {
        "scope": "private_control_root_with_mandated_exact_absolute_source_locators",
        "allowed_exact_Floris_locator_hits": private_locator_hits,
        "unexpected_other_user_path_hits": other_user_hits,
        "unexpected_email_hits": email_hits,
        "reader_private_task_ai_workflow_hits": reader_hits,
        "public_projection_claimed": False,
        "status": "PASS_PRIVATE_CONTROL__PUBLIC_PROJECTION_NOT_CREATED_OR_CLAIMED" if not other_user_hits and not email_hits and not reader_hits else "FAIL",
    }

    status = "PASS" if not errors else "FAIL"
    return {
        "schema": "verdier_retrospective_validation/v1",
        "validation_id": "VDR-RETROSPECTIVE-VALIDATION-20260804-R1",
        "observed_at_utc": observed,
        "status": status,
        "errors": errors,
        "goal_effort": {
            "minimum_forensic_tokens_required": 100000,
            "first_active_goal_total_tokens_observed": 882796,
            "first_active_goal_total_observed_at_utc": "2026-08-04T02:28:07.8481073Z",
            "second_active_goal_total_tokens_observed": 1221786,
            "second_active_goal_total_observed_at_utc": "2026-08-04T03:02:56.4035661Z",
            "observed_retrospective_only_interval_delta_tokens": retrospective_interval_delta,
            "production_frozen_during_observed_interval": True,
            "minimum_satisfied_by_observed_interval_delta": retrospective_interval_delta >= 100000,
            "retrospective_phase_only_token_counter_available": False,
            "accounting_statement": "The two exact total-goal observations differ by 338990. Because Verdier source/build/render/package/publication production remained frozen throughout that interval, the delta is a defensible lower bound for that retrospective-only interval. It is not called the exact total retrospective cost because the phase began before the first observation. Exact source bytes and read states provide the reproducible forensic surface.",
        },
        "claim_scope": "Forensic retrospective control artifacts and frozen Verdier pages 2-7 draft identities only; not a corpus source/build/publication completion claim.",
        "checks": checks,
    }


def main() -> int:
    observed = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
    rows, errors = build_manifest(observed)
    write_manifest(rows)
    result = validate(observed, rows, errors)
    VALIDATION.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "errors": result["errors"], "source_rows": len(rows), "source_bytes": result["checks"]["source_manifest"]["bytes"], "manifest_sha256": result["checks"]["source_manifest"]["manifest_sha256"], "validation_bytes": VALIDATION.stat().st_size, "validation_sha256": sha256(VALIDATION)}, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
