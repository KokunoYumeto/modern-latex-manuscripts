# Predecessor failure forensic audit

Corpus governed by this audit: Jean-Louis Verdier, *Des catégories dérivées
des catégories abéliennes*, complete Astérisque 239 publication  
Audit date: 2026-08-04  
Status: first-stage controlling retrospective; Verdier source production is
frozen until the companion validation reports PASS

## Executive finding

The predecessor record does not show one isolated bad translation, one broken
build, or one careless archive action. It shows a recurring systems failure:
a narrow, internally coherent surface was repeatedly allowed to stand for a
larger scholarly claim whose universe had not been positively enumerated.

That pattern appears in different forms:

- a complete 1,356-page English EGA reader existed before the canonical French
  authority corpus and later French replay forced inherited English repairs;
- a 378-of-378 native-diagram closure was locally true for its selected list
  but false for Session A, because 41 active PNG-backed diagrams in Exposé II
  had never entered the list;
- 3,744 mapped SGA references could all work while a 23,880-candidate discovery
  universe still contained thousands of unwrapped or unresolved occurrences;
- a graph could be mechanically closed while six TikZ coordinate literals had
  been promoted into invented semantic edges;
- a manifest could replay all of its rows while an accompanying PASS record
  still carried a byte total wrong by 238 bytes;
- a checkpoint validator could be self-consistent while binding PDFs and
  French layers from an older checkpoint;
- a privacy projection could report zero residuals while a second detector
  found nine UUIDs;
- an upload or container could succeed while raw public files were missing,
  line endings had changed, or archive members still contained private paths
  and workflow prose; and
- a durable goal could preserve the translation grind while silently dropping
  the requested pre-Stacks semantic deliverable;
- a GAGA reader could be repaired while all 82 uncertainty rows still said
  `carried_forward_for_adjudication` and the translation-lineage table retained
  obsolete byte counts, blank hashes, and the wrong correction total;
- a clickable GAGA graph could pass count/uniqueness checks while omitting
  bilingual locators, printed pages, diagrams, typed semantic evidence, and
  pre-Stacks migration fields and while carrying corrupt visible anchors;
- a Deligne D001 closeout could say bilingual without evidencing a separately
  preserved diplomatic French layer; and
- one parent task could be routed repeatedly across SGA, EGA, FAC, and GAGA,
  with retractions and PC-kill reports, because current scope and resource
  bounds were not a single validated disk state.

The central corrective principle for Verdier is therefore stronger than
“validate more.” Every terminal claim must first define its complete authority
or source universe, prove that the inventory equals that universe, and only
then validate the properties of every member on one coherent generation.
Compilation, link replay, zero reported errors, clean rendered samples, exact
manifest rows, or upload success remain valuable bounded evidence. None of
them can supply a missing universe.

The audit also distinguishes what the record does and does not prove. It proves
the 41-diagram omission, six false coordinate edges, English defects exposed by
French replay, stale checkpoint bindings, manifest-algorithm errors, shared-log
regression, reader workflow leakage, private-path contamination, wrong privacy
counts, missed UUIDs, line-ending drift, incomplete mirrors, and incorrect
DOIs. It does **not** prove that an official Stacks tag was actually invented,
that a duplicate Zenodo concept was actually minted in the FAC settlement, or
that duplicate stable IDs entered the examined logs. Those three items are
high-severity hazards with binding fail-close controls, not incidents invented
to make the register symmetrical.

## 1. Mandate and non-substitution rule

This retrospective is the required first-stage deliverable of the existing
Verdier corpus goal. The user clarified that 100,000 tokens is the **minimum**
investigation budget, not a ceiling. The work therefore did not stop when a
round number of source text, tool output, or analysis had been consumed. It
continued through the complete common handoff, every exact listed precedent,
the Verdier authority identities, the full EGA successor handoff, live EGA
status and continuation histories, relevant source and decision ledgers, the
SGA diagram and reference failures, the FAC correction and stale-validation
record, and the archive/log/privacy/readback controls.

The companion `RETROSPECTIVE_SOURCE_MANIFEST.csv` records the exact read
surface. Its validation distinguishes human or team read-through-EOF,
semantic parse, binary full-byte identity replay, historical snapshot, and
mutable live snapshot. No exact token count is fabricated because the runtime
does not expose a reliable tokenizer accounting for all tool-returned content.
The byte- and line-level receipt is the reproducible claim.

At 2026-08-04T02:28:07.8481073Z, the durable-goal telemetry reported exactly
882,796 total tokens used. The goal predates the retrospective mandate and the
API does not expose a phase-only baseline or permit an in-place budget edit, so
882,796 is recorded as total-goal usage—not falsely relabelled as retrospective-
only usage. The active plan explicitly binds the 100,000-token minimum, and the
manifest/validation records the exact forensic read surface that supports the
substantive result.

A second durable-goal observation at 2026-08-04T03:02:56.4035661Z reported
1,221,786 total tokens, an exact increase of 338,990 since the first receipt.
No Verdier source production, TeX build, render, package, or publication action
occurred in that interval; the frozen four drafts retained their exact bytes.
The intervening activity was the retrospective itself: complete parent-task
pagination, GAGA/Deligne source integration, audit/register/safeguard expansion,
and current validation. Therefore 338,990 is a defensible lower bound for just
that observed retrospective-only interval, already more than three times the
100,000-token minimum. It is still not misrepresented as the exact total for
the entire retrospective, which began before the first telemetry observation.

This investigation is not permission to create endless control bureaucracy.
Once the first durable retrospective generation passes, the required next
scholarly action is the exact source unit at physical PDF page 8: Georges
Maltsiniotis's `Note des éditeurs`, logical page iii. The frozen pages 2--7
draft remains unbuilt and unchanged while this audit is completed. After the
retrospective gate, Verdier production resumes sequentially and stops only at
the end of Astérisque 239.

## 2. Evidentiary method

### 2.1 Authority hierarchy for the retrospective

The audit uses five evidence classes:

1. **Direct incident record.** An append-only failure, correction, hold, or
   reconciliation record names the false claim, exact artifacts, detection,
   and successor state.
2. **Contemporaneous operational log.** A status or logbook records what was
   claimed or done at the time, with exact identities and cursor.
3. **Machine ledger or replay.** CSV, JSON, JSONL, source enumeration, hash,
   build, link, or privacy result supplies reproducible counts and sets.
4. **Later forensic inference.** Chronology and artifacts jointly support a
   causal conclusion even though no contemporary file used the later failure
   label. Such conclusions are explicitly called inferences.
5. **Prospective hazard.** A risk required by the user's mandate but not shown
   as an actual incident in the bounded evidence. Hazards receive controls but
   are not rewritten as history.

This hierarchy prevents two opposite mistakes. It prevents minimizing a
confirmed failure merely because a preceding PASS was internally consistent,
and it prevents exaggerating a safeguard into proof that the prohibited event
actually occurred.

### 2.2 Identity discipline

Every source used by the controlling audit is bound by absolute path, exact
bytes, SHA-256, read state, and observation time in the retrospective manifest.
Historical handoff identity and current mutable identity are different facts.
For example, the EGA handoff bound its pre-Stacks scaffold at the p.112
generation, 12,419 bytes with SHA-256
`00782C23C1DE78EBCC58A4C75BF424BA926CB99A4CB25BE6083B2383FE8D40E4`.
The same append-only live file later reached the p.137 generation at 92,172
bytes and SHA-256
`248460C70D5B42F30E254761EC31C30F9F3AD6EFAFDFC41C768AEC50581D10C6`,
and the p.138 snapshot inspected for this audit is 98,950 bytes with SHA-256
`1B024552FFE71D56EB1BB2BA50304961073B55B0CEE76D5F514EDDFB65D49BB4`.
The later bytes do not corrupt the historical handoff; the historical PASS
also does not certify the later bytes.

### 2.3 Incident versus hazard discipline

The register column `classification` is controlling:

- `confirmed_incident` means the selected evidence demonstrates the adverse
  state;
- `confirmed_incident_strong_causal_inference` means the chronology is direct
  but the causal label is ours rather than contemporaneous wording;
- `confirmed_architectural_gap` means the earlier system was internally valid
  for its stated mechanics but insufficient for the later required scholarly
  object;
- `prevented_hazard_not_observed` means the controls prevented or searched for
  the event and no selected receipt proves occurrence; and
- `prevented_high_severity_hazard_Verdier_specific` means the risk follows from
  this corpus's declared integrity conditions even without a predecessor event.

The distinction is especially important for invented Stacks tags, duplicate
archive concepts, duplicate IDs, and silent completion of Verdier's unfinished
text. All four can seriously corrupt the corpus. None may be described as a
confirmed predecessor incident without evidence.

## 3. Chronology of the failure system

### 3.1 17--20 July: readiness rhetoric, weak handoffs, and missing decision custody

The early SGA5 handoff is a useful baseline for what later controls had to
repair. `SGA5_ENGLISH_SOURCECHECKED_HANDOFF_20260717.md` used a relative working
root and bound only two principal hashes. It called the package `CONTENT READY`
while simultaneously acknowledging an unresolved editorial-note gate, ongoing
rights remediation, and a support ZIP that contained the original scan and 15
derived PNGs. The handoff did disclose these problems; the failure was that its
headline and restart shape were weaker than the state required.

The contemporaneous `ENGLISH_GERMANIC_DECISION_LOG_20260718.md` records another
foundational deficiency: earlier decisions, exact times, reviews, and handoffs
had not always been logged separately when they occurred. Some had to be
reconstructed retrospectively. That made later correction possible, but it
reduced confidence in causal order, rejected alternatives, and the propagation
scope of earlier editorial choices. The later machine-ledger requirement and
validator introduced stable IDs, exact locators, evidence classes, alternatives,
adverse evidence, supersession, and continuation cursors because prose status
and compiled output alone could not reconstruct them.

The shared English/Germanic decision log then demonstrated why append-only
intent is not enough under concurrency. A valid append had brought the log to
250 records. A later reader observed a regression to 1,414,495 bytes with
decision `EG-SGA1-I912N-LOCAL-SEAL-20260719-0001` missing. The cause was not
proven; the record carefully calls stale-snapshot whole-file replacement the
leading explanation. Recovery restored 251 records, 1,429,579 bytes, unique
IDs, and `errors: []`. The successor protocol banned direct editor,
`apply_patch`, `Set-Content`, and cached full-log replacement for the shared
file. Its helper rereads under a live lock, rejects duplicate IDs, appends one
record, flushes, validates while locked, and truncates to the exact original
length on failure.

This is the first recurring causal chain:

1. state exists partly in conversation or a writer's cached memory;
2. the artifact looks append-only but the mutation mechanism is whole-file;
3. concurrent progress makes the cached state stale;
4. a later write restores old bytes and silently deletes a valid decision;
5. only exact identity and stable-ID replay reveals the regression.

For Verdier, local single-writer ledgers can remain ordinary append-only files
under exclusive task ownership. If a second writer is ever authorized, the
locked helper pattern becomes mandatory immediately.

### 3.2 23--30 July: diagram fidelity, inventory omission, and false semantic edges

The SGA diagram history shows a progression from local fidelity work to a
false global closure. Earlier count corrections had already established that a
detector could miss diagrams hidden behind another call class: Exposé I grew
from 10 to 25 and Exposé III from 32 to 62 when the inventory expanded beyond
one raster mechanism. That discovered global lesson was not propagated to
every Session-A unit.

`SGA3_SESSION_A_NATIVE_DIAGRAM_COMPLETE_CLOSURE_20260729.md` later declared an
exact inventory of 378, all native and lead-reviewed, with open, delivered
raster, and unchecked counts all zero. It explicitly said Exposé II had no
diagram debt. The record also gave real evidence: listed standalone sources
had zero direct `includegraphics`, and their PDFs had zero image objects. The
mistake was not fabricated numbers within the listed set. It was treating the
listed set as the full Session-A universe without proving that equality.

The append-only fail-close identified five controlling Exposé-II components
containing 41 active `SGAThreeDiagram` calls. Each call loaded a
`figures/exp2/*.png` asset. The independently replayed distribution was 7, 11,
12, 6, and 5 calls across components 10--14. The correct Session-A universe was
therefore 419: 378 closed and 41 open. A clean cumulative build did what the
standalone scans had not done: it exercised the active dependency universe and
made the omitted unit visible.

This incident matters beyond diagrams. It demonstrates that “all known items
pass” and “the corpus universe is complete” are separate propositions. The
former can be exactly true while the latter is false. A validator must derive
or independently enumerate the universe before it tests member properties.

The high-zoom diagram record also shows why resolution must follow represented
detail. Ordinary builds, contact sheets, and broad views had accepted diagrams
that retained i/j, star/shriek, prime, index, punctuation, label, and arrow
errors. A complete Exposé-VII cold review classified 32 of 135 diagrams as
correction-required. Later correction records rightly avoided the opposite
overstatement: 600- and 1,200-dpi evidence could remain legitimate contextual
evidence; only 300-dpi-only or other insufficient-detail approval was
categorically invalid. The durable lesson is not a ritual resolution number.
It is that broad views locate content, while small or ambiguous graphical
features require tight direct crops and element-by-element review.

The reference detector produced a parallel semantic failure. In Exposé VII it
found 7,460 candidates, including 574 from native-diagram source files, and
promoted six TikZ coordinate literals such as `2.1`, `3.3`, and `3.2` into
internal semantic edges. The graph remained mechanically coherent: IDs existed,
rows linked, and validation could replay. Yet the edges were false, and
wrapping the coordinates would corrupt the diagram source. The detector had
recognized number shape without TeX syntax class or mathematical reference
semantics.

These two failures share the same root:

- the diagram closure omitted content because its detector knew too few call
  classes;
- the reference graph invented content because its detector accepted too many
  number shapes;
- both controls were internally coherent over the universe their generator
  produced; and
- neither generator had been proven extensionally equal to the intended
  mathematical universe.

Verdier's formula, diagram, and reference inventories therefore require both
positive and negative classes. Every active occurrence must appear exactly
once, while coordinates, dimensions, style values, folios, and other
nonreferences remain explicit rejected candidates rather than silently
disappearing.

### 3.3 29--30 July: reader surface contamination and reference overclaim

The SGA reader cleanup record demonstrates that a mathematically useful PDF
can still be the wrong reader. The first cleanup removed 351 items of
project/source/translator/model apparatus. A second pass found 34 more,
bringing the cumulative cleanup to 385. Another SGA1 successor still displayed
a project-authored `Source and status note` on page i and in the table of
contents. Its content—source archive hash, retention status, and project claim
limits—was useful provenance, but not part of the mathematical reading surface.
AI badges and reader-facing internal Notes required separate removal.

The initial cleanup's large count did not make the second pass redundant. It
proved that a keyword set created from already-known leakage classes can return
zero while an independent vocabulary or structural scan finds more. Verdier
therefore scans reader source, extracted PDF text, bookmarks, annotations,
metadata, attachments, TOC, and rendered front matter using both known terms
and shape detectors. Scholarly notes about Verdier's unfinished thesis and
editorial interventions belong in the reader. Task IDs, hashes, model names,
build state, workflow narration, and private paths do not.

The SGA3 R28 record made a more subtle language error by calling a reader
`reference-complete`. It stated that all 3,744 mapped destinations were
repaired. The mapped set may indeed have replayed. But the exact lexical
planning validation contained 23,880 candidates. Among them were 2,125
internally resolvable but unwrapped occurrences, 241 multiple-target reviews,
and 1,028 target-gap-or-external reviews. Later R43 planning still carried 291
lead holds, 94 unregistered edge targets, and four unresolved source locators.

The denominator “all mapped targets” was tautological for mapped-target
integrity but insufficient for exhaustive reference closure. The correct
identity is:

`complete candidate universe = adjudicated active edges disjoint-union typed residuals`.

Every candidate must have exactly one current disposition. Zero broken PDF
actions is then a projection test over admitted edges, not a substitute for the
candidate universe.

### 3.4 1--3 August: English-first EGA, authority replay, and scope recovery

On 1 August, the EGA global reader status said `TECHNICAL PASS — complete global
reader`. It bound 127 active source files, a 1,356-page PDF, 15,383 named
destinations, 17,808 internal GoTo actions, zero broken actions, zero image
objects, embedded fonts, privacy scans, 31 context pages, and 17 direct
1,100-dpi detail crops. Those are meaningful achievements. The problem is the
headline's relationship to the later required bilingual corpus.

The French canonical logbook opened separately the same day. It bound eight
NUMDAM authorities totalling 1,800 PDF pages and reused the only discovered
French TeX seed merely as provisional witness material. That seed stopped
partway through EGA I printed p.7 and was explicitly “not yet admitted as
source-exact.” Direct page reading immediately reversed its two silent accent
normalizations and found an English Chapter XI/IX error.

At printed p.69, sequential French replay exposed three inherited English
defects:

1. omitted `M` after `mathfrak n^{hk}`, changing a submodule inclusion into a
   type-invalid expression;
2. wrong link and wording for 7.2.4 instead of the local Proposition 7.4.2; and
3. omitted “by virtue of what precedes” plus loss of the fact that exactly two
   jointly required conditions follow.

The repair did not overwrite the frozen global reader. It copied the complete
127-file tree into a successor and changed exactly one file for that batch.
The log explicitly says the successor was not yet a rebuilt/public replacement.

It is an inference—but a strongly evidenced one—that English-first closure
forced this rework. The files do not use that phrase. They show a complete
English surface, a later newly opened and mostly absent canonical French
surface, and defects discovered because the French authority was finally read
sequentially. The correct Verdier response is not to forbid useful English
drafting. It is to deny broad closure until each unit's diplomatic French,
corrected French, and English have been reconciled against the same authority.

EGA p.108 then supplied the clearest layer-conflation receipt. The audit removed
an English proof square solely because French did not print `c.q.f.d.`. It later
restored the exact earlier English identity after recognizing the declared
modern proof-structure normalization. The final decision correctly distinguishes
diplomatic evidence, proof-role markup, translation normalization, and external
errata augmentation. Verdier strengthens that two-layer distinction into three
separate textual artifacts.

Finally, the EGA thread reread exposed lost terminal intent. The original
attachment required bilingual source work plus a machine-readable semantic
index, but the durable goal had omitted the explicit pre-Stacks/Stacks
deliverable. The omission “materially narrowed” the task; production was held,
the goal was deleted, and the complete scope was reconstructed on disk. That is
direct evidence of scope loss. The record does not prove conversational
compactification as the sole mechanical cause, so this audit does not make that
claim. It does prove that long-chat intent had not been completely encoded in
the durable goal and restart surface.

### 3.5 2--4 August: stale validation, privacy reversals, and archive readback

FAC provides unusually rich correction evidence. Its self-correction ledger
records source errors, coverage gaps, stale semantics, page-range errors, and
control-plane mistakes without deleting earlier states. Examples include:

- `FAC-SELF-0065`, an authority-absent comma in `C'^{,n}` found after admission;
- `FAC-SELF-0140`, the underinclusive physical-page range for no.65;
- `FAC-SELF-0144`, a clean no.66 build lacking an exact no.52 link and two
  distinct semantic construction anchors;
- `FAC-SELF-0156`, `0169`, and `0175`, visually clean readers with two, two,
  and four missing semantic object destinations;
- `FAC-SELF-0190`, a citation that remained plain text because the exact
  historical proposition target did not yet exist;
- `FAC-SELF-0202`, a nominal p.74 PASS whose generator still bound p.73
  artifacts; and
- `FAC-SELF-0204`, a p.76 validation whose manifest still named an older p.73
  English PDF and C0039 French PDF.

The current immutable FAC methodology package adds an independent live example.
Its self-excluding manifest replays every one of 18 rows. The directory contains
19 files totalling 734,768 bytes. Excluding `PACKAGE_VALIDATION.json` and the
manifest leaves 17 files totalling 730,442 bytes. Yet the PASS validation says
730,204 bytes, a difference of 238. The manifest is good evidence for its own
rows; it does not repair the stale or wrong aggregate in a different record.

Privacy remediation shows why adverse results must remain append-only. The
first record described 421 path-root, three state, and 17 task-ID hits. Exact
recursive transformation later counted 2,416 events across 423 of 478 records,
including 2,272 project-root events and 31 task-ID events. The correction did
not rewrite the earlier statement. It named the difference between line/record
counts and recursive event counts.

A subsequent v1 projection reported zero residual private tokens. A separate
UUID-shape scan found nine identifiers across six records and fields. The old
regex required word boundaries, but the UUIDs were concatenated directly after
words such as `thread` or `task`; the leading boundary never matched. Again,
the correction preserved the v1 public records as adverse immutable history and
prepared same-concept successors.

Archive transport exposed two more layers of false assurance. An independent
FAC comparison found five task IDs, six machine roots, and one internal staging
segment despite the producer privacy PASS. The first Git commit also normalized
CRLF to LF in five payload files, so only 14 of 19 raw blobs were byte-identical.
A corrected commit and readback eventually established 19 of 19. Elsewhere,
SGA reconciliation found two stale current-surface CSVs referring to three
absent files and a GitHub mirror containing only 49 of 51 expected files.

Wrong archive routing was not hypothetical. An EGA shelf DOI was transposed,
and three Steinitz controls pointed to an unrelated preterm-birth medical
dataset. Live API/catalog comparison of title, creators, concept/version
relationship, and payload corrected the identifiers append-only.

The positive controls matter as much as the failures. Noether readback rejected
container-hash-only acceptance and opened all 55 ZIP members with safe paths.
The FAC dual-DOI settlement reused existing concepts, performed direct outer-
file readback on both, and replayed every archive member. No duplicate concept
was found in the bounded evidence. The correct historical statement is therefore
that duplicate concepts/transports were a recognized and successfully
controlled hazard, not a confirmed incident.

### 3.6 3--4 August: GAGA's stale closure state and Deligne's missing layer evidence

The GAGA record supplies a compact demonstration that a repaired final reader
can still carry stale machine-readable truth. The first-pass source put sixteen
page-join boundaries directly in content as `CONT>>` and `<<CONT`. Its held
24-page PDF visibly typeset all 32 sentinel tokens. The first-pass README and
custody validation preserved the failure, and the successor inspected all
sixteen joins before admitting a corrected layout. This was contained before
public promotion, but it was a real reader-surface failure: a compilable PDF
had operational delimiters in the mathematical text.

Direct-source adjudication then reversed three inherited readings. A p.11
reading recorded uppercase `X` where the source has the point `x`; three script
glyphs were recorded as `\mathcal I` where later direct evidence established
`\mathcal J`; and a p.14 glyph first called `\mathfrak J` was established as
`\mathcal J` from a tight 1,800-dpi crop. The later transcription-repair ledger
is explicit, including the subtle case where the earlier rationale was wrong
although its proposed replacement happened to be right. The lesson is not
“always zoom more.” It is that a source-reading claim must bind the exact crop,
effective detail, local comparison set, confidence, and layer disposition.
Mathematical plausibility can trigger inspection but cannot decide what the
print says.

GAGA also reproduced the denominator failure. After the original 21 correction
candidates were called closed, English alignment exposed the missing
`H_I/H_{II}` defect. Proposition 11's tensor base and an omitted printed
equation tag `(1)` appeared later as well. The truthful state had been
`candidate_batch_closed`, not `corpus_exhaustive_closed`. Closing a seed list
did not prove that the seed generator covered every page, formula, or diagram.

The final reference-v2 tree contains a useful hyperlink graph but not the
promised reusable semantic scaffold. Its four graph schemas have no French
locators, printed-source pages, diagram fields, semantic relation type,
evidence, confidence, or pre-Stacks migration fields. The target table has 126
rows: 20 bibliography entries, 24 numbered units, seven sections, 75 generic
`semantic_anchor` rows, nine equation IDs, zero diagram IDs, and zero French
source paths. Several machine anchors are lossy or corrupt: one embeds an item
suffix in a Lemma anchor, Proposition 2 is truncated, a homomorphism becomes
`$:O_xH_x$`, and a theorem anchor loses its inequality. The validator still
passes because it checks the 126/325/245/80 partition, uniqueness, and target
existence—not semantic label integrity or source-universe coverage. This is the
precise difference between clickable-reference closure and pre-Stacks closure.

Two current-state ledgers remained stale after the final repairs. The
31,379-byte `UNCERTAIN_READING_LEDGER.csv`, SHA-256
`64255FBCD06D16380E987BCB7E6C7F6F7E1A56DD3E9403D8EF6CA8F2F218AED8`,
has 82 rows, all still `carried_forward_for_adjudication`, and no supersession
fields. That includes the `\mathcal I` and `\mathfrak J` rows contradicted by
the admitted `\mathcal J` repairs. Append-only history existed; a current-state
join did not. `TRANSLATION_LINEAGES.csv` likewise reports diplomatic/corrected
bytes 125,147/125,130, blank hashes, and fourteen corrections, while the final
validation reports 125,157/125,141 and the status reports fifteen corrections.
A content repair had failed to invalidate and regenerate its downstream
lineage identity.

The same GAGA status contradicts itself. One line says the privacy-clean
package and external replay passed; four lines later it says that package and
replay are the next gate. Chronology had been appended into a file serving as a
current cursor without a validator capable of rejecting completed work as the
still-current next action. Historical chronology and current state need
different data projections.

Privacy and pagination carry similar denominator defects. The frozen GAGA
master contains `OS\...` historical source-path comments and an alternate
on-disk filename, yet its custody validation says `privacy_hits: 0`. Later
provenance explicitly acknowledges those private historical comments. The
detector's zero was true only for a narrower vocabulary than the later custody
policy. The archive handoff also calls the exact GAGA authority a 42-page PDF;
`pdfinfo` reports 43 physical pages, while 1--42 is the printed article span.
The hash was right and the coordinate system was wrong.

Operational history adds repeated command waste: literal `$out` or `$build`
directories, wrong working directory, wrong TeX engine, invalid validation
regex, wildcard use with `-LiteralPath`, wrong crop-coordinate order, and
duplicate `equation.1` destinations. Link insertion first emitted a literal
`\n`; ten wrappers later proved to change spacing or link only part of a
phrase, requiring seventeen repairs. The predecessor correctly retained an
8/26 exact versus 18/26 nonexact pixel comparison as a FAIL. Verdier therefore
requires one checked-in serial build runner and a mechanical wrapper-removal
round trip for navigation-only edits.

The bounded Deligne evidence is smaller but decisive. A current-head catalog
sync records that GitHub still fronted methodology record `21743417` and
Deligne record `21212608` after their public concept heads advanced to
`21744853` and `21745061`. Archive objects and generated catalogs had advanced
independently. More importantly for the bilingual contract, the D001 closeout
names corrected French, English, and a bilingual reader, but contains zero
mentions of a diplomatic layer. This proves a closeout-evidence gap, not that a
diplomatic witness existed nowhere else. The same record properly limits its
claim to D001 and says the wider Deligne corpus is uneven; that narrow claim is
a positive precedent. Under the Verdier contract, however, “bilingual” cannot
stand in for three separately identified and hashed textual layers.

### 3.7 17 July--4 August: parent-task history, coordination churn, and PC harm

The complete available turn-summary pagination for parent task
`019f711e-cac3-7a10-a0e6-dc0131799c3a` was replayed newest-to-oldest: twelve
pages, 113 turn summaries, ending with `hasMore: false`. The durable cursor
chain and incident locators are in `PARENT_TASK_HISTORY_EVIDENCE.md`. That app
surface has no stable whole-thread byte export and truncates long items, so it
is treated as task-history testimony and coordination evidence, not as a
hash-bound authority source.

The history shows an original SGA5 synchronization task repeatedly becoming
SGA1, SGA4, SGA3, EGA II, EGA III, EGA I, SGA7 I/II, FAC, GAGA, and the global
SGA reader. One manager message redirects to EGA I, immediately retracts its
authority to do so, and a later message returns the task to SGA3. Some changes
were legitimate new assignments. The failure was that the current objective,
owner, cursor, and supersession state lived in a stream of mutually
incompatible messages instead of one validated disk cursor. Repeated no-overlap
queries were a symptom of that missing control plane.

The history also gives a direct integration failure. Narrow SGA1 translation
ranges were assigned in parallel, and four fragment files named by the
cumulative master later disappeared. The build remained broken until those
translations were restored. Parallelism was not inherently wrong; admitting a
master before exact input presence and immutable handoff replay was.

Machine harm is explicit but must be worded at the evidence level. The user
reported a memory-spike crash in turn
`019f7229-ec34-74a0-8637-02557cfd52d4` and later reported two more PC-kill
events. Turn `f1fb7af4-0a3b-4a9c-8e06-0ff8b3e0c4d6` attributes the later event
to a global search over the multi-terabyte Documents tree and orders that it
never be repeated. The task history does not provide operating-system
telemetry, but durable resource controls independently establish the unsafe
scope. Exact-root-only discovery and serial heavy work are therefore scholarly
integrity requirements, not convenience preferences.

Finally, the history shows why chat cannot be the handoff. Individual turns
report 67, 57, and 37 compactifications while containing hundreds of file
changes and dozens of routing messages. A compaction count does not prove that
a particular error resulted. It proves that any successor dependent on chat to
recover the objective is accepting unnecessary epistemic risk. Verdier's
successor must reconstruct the next safe action entirely from validated disk
controls; task history remains adverse evidence and context, never the only
custodian of purpose.

## 4. Cross-cutting causal analysis

### 4.1 The denominator failure

The most common predecessor defect was not bad arithmetic. It was choosing a
denominator that could only confirm already-known work:

- 378 known diagrams divided by 378 known diagrams yielded 100%, while an
  active Exposé II had never entered the numerator or denominator;
- 3,744 mapped references divided by 3,744 mapped references yielded 100%,
  while 23,880 discovery candidates remained the real universe;
- 18 manifest rows divided by 18 manifest rows yielded 100%, while an
  accompanying aggregate field remained wrong;
- current ledger counts in a validator were correct, while source and build
  identities still pointed to an older page checkpoint; and
- a privacy detector returned zero over the token shapes it recognized, while
  a different valid UUID shape remained outside its language.

The root cause was a shift from an extensional question—“what exactly exists in
the controlling corpus?”—to an intensional one—“did everything my current
script knows how to find pass?” The latter is useful but cannot prove
completeness. A program cannot report the items its discovery language excludes.

Verdier therefore uses independent universe generators and explicit residuals.
For each domain, the audit asks two different questions:

1. Does the inventory equal the source universe?
2. Does every inventoried member pass its domain-specific review?

Both must pass. The source universe is derived from the complete active TeX
dependency graph, page topology, and direct source-unit boundaries. The
inventory is the corresponding semantic or review table. Any missing, extra,
duplicate, or unclassified item fails before a percentage or zero-residual
claim is computed.

### 4.2 Layer collapse

Predecessor artifacts repeatedly stored distinct epistemic roles too close
together:

- provisional reconstructed French was convenient enough to look canonical;
- diplomatic French typography was temporarily used to judge English editorial
  proof structure;
- comparison lineage, source correction, translation normalization, and
  reader typography could be described in one prose status rather than typed
  ledgers;
- useful project provenance was placed inside the mathematical reader; and
- historical pending inventory state sat beside final review state without a
  clear `state_as_of` or supersession link.

Once roles collapse, a correct observation in one layer can cause a wrong
mutation in another. “French prints no square” is a correct diplomatic fact.
It does not imply “English must contain no editorial proof terminator.” “This
archive record contains a source hash” is useful provenance. It does not imply
that the hash chapter belongs in a reader's table of contents.

Verdier's three textual layers are therefore physically separate and joined
only through stable unit IDs. Comparison readings and publication controls are
additional lineages, not hidden content layers. An operation must name its
source role and target role. If a correction belongs in corrected French, it
cannot be achieved by changing a shared file also included by diplomatic
French. If reader typography adds a proof environment, the decision must state
that the markup expresses role without supplying an absent proof or closing an
unfinished argument.

### 4.3 Authority collapse

No selected receipt shows an official policy saying “OCR is the authority.”
The evidence instead shows why such a policy would be dangerous:

- the inherited EGA French seed silently normalized visible print;
- extracted scan text garbled formulae, diagrams, punctuation, case, and
  accents;
- a source-visible unmatched bracket required a tight direct crop before it
  could be preserved diplomatically;
- a small formula factor and diagram label side were invisible to build and
  ordinary review; and
- same-number equation/proposition references required mathematical context,
  not visible number shape alone.

Authority collapse happens operationally when a witness is cheaper to query
than the authority and the record stops naming which one decided. Verdier
prevents this by making the authority SHA and physical page required fields of
every content decision. Existing extraction can locate the paragraph. It
cannot close it. Comparison PDFs can help resolve primary-image damage only
through an explicit page-level decision. Later Verdier works can supply
historical context but cannot complete the unfinished Astérisque body.

### 4.4 Generation collapse

The EGA and FAC histories show three generation mistakes:

1. treating a historical handoff PASS as certification of later mutable bytes;
2. advancing status prose or counts while hard-coded artifacts remained from a
   previous checkpoint; and
3. replaying one exact manifest while trusting an independent stale summary
   field.

The shared feature is failure to require all dependencies of a claim to carry
one generation identity. Verdier validation therefore does not ask whether
each individual file has *some* valid hash. It asks whether source, decisions,
semantic tables, builds, renders, page maps, and manifests all belong to the
same named generation and declared range.

An old PASS is retained. It may prove that p.7 was correct at one time. It
cannot prove p.8 after a source edit. A new validation may reuse immutable
authority and unchanged content hashes, but it must generate a new dependency
record and explicitly say which predecessors remain identical.

### 4.5 Status collapse

Words such as `complete`, `ready`, `sealed`, `source-certified`, and
`reference-complete` repeatedly compressed multiple state dimensions into one
headline. The evidence underneath was often candid. The EGA English baseline
separated public rights from its technical PASS. The SGA5 handoff disclosed its
rights and note holds. The R17 archive record called its raster-bearing reader
heterogeneous and provisional. Yet the broad headline remained easy to repeat
without the limiting paragraph.

Verdier uses a typed closure lattice. `drafted` means source text exists.
`authority_read` means the direct page was adjudicated. `layer_admitted` means
the unit passed that layer's decisions. `bounded_build_pass` and `visual_pass`
say nothing about unbuilt pages. `semantic_pass` names its object classes and
candidate universe. `privacy_pass`, `rights_disposition_recorded`,
`package_pass`, `handoff_accepted`, `published`, and `public_readback_pass` are
separate later states. A human headline must state the range and weakest open
gate.

### 4.6 Provenance written after the decision

Retrospective logging was better than losing history, but it could not always
recover exact decision time, rejected alternatives, or the active copy set that
should have received a correction. FAC's later append-only discipline shows the
stronger model: the original choice, discovery channel, correction, propagation
scope, obsolete artifact, and residual query all become one machine row before
the checkpoint closes.

Verdier therefore records decisions at admission time. The decision can be a
no-edit confirmation; it need not create textual churn. It must still say why
a suspicious source form was preserved, why corrected French differs, why an
English normalization is functional or merely typographic, and what would
reverse it. A later error appends rather than edits. The original decision is
not embarrassing waste; it is the evidence that makes the correction auditable.

### 4.7 Global lessons that were discovered but not propagated

Several failures were second-order failures: the workflow had already learned
the relevant lesson locally.

- Diagram detector undercounting had already occurred in Exposés I and III,
  but the new call-class lesson was not replayed over Exposé II before the
  zero-debt closure.
- FAC normalization generators had already shown that regex scope can be too
  narrow, yet later occurrence policies still needed append-only expansion.
- Privacy scans had already found private task identifiers, but the first
  residual detector still encoded a word-boundary assumption that excluded
  concatenated identifiers.
- A reference target could be mechanically valid, but same-number kind
  collisions and diagram coordinates required new semantic context classes.

Discovering a global failure class creates a corpus-wide obligation. A local
fix closes the immediate artifact; it does not close the recurrence. Verdier's
incident record must include the bounded earlier universe searched, the exact
predicate, results, and any residuals. This is deliberately different from a
broad filesystem search. The search universe is the named active corpus or
semantic field set, never all Documents or a drive.

### 4.8 Resource safety as scholarly integrity

The EGA log gives unusually concrete resource evidence: one command created
twenty 5,000-dpi grayscale bands, generally 33,057 by 3,056 pixels, and the
task loaded all twenty at original detail. The estimated decoded/context
footprint was roughly two gigabytes and the log says this destabilized the PC
during compactification. A separate p.112 record joins a whole-page
original-detail load with an unbounded recursive Documents search. The path
relocation control says traversals of the old Chatnotes area were destabilizing;
the common precedent list calls them PC-killing global searches.

This audit preserves the distinction between evidence and user
characterization. The local files document destabilization, memory allocation
failure, blank output, multi-gigabyte decoded/context load, and broad searches.
They do not contain a hardware telemetry trace proving a particular operating-
system crash. That uncertainty does not weaken the control. Repeating the
workflow would be unjustifiable.

Resource safety is not merely convenience. A crashed or compacted task loses
cursor, encourages cached-state writes, tempts broad recovery searches, and
can turn private scratch into accidental evidence. Verdier work therefore
reuses existing crops, reads ordinary pages at approximately 1,100--1,800
dpi-equivalent, creates one tight 5,000--9,000 crop only for a genuine small
ambiguity, runs no new OCR, serializes builds, and delegates only disjoint
low-intensity work. The lead retains mathematical and visual judgment.

## 5. Required topic-by-topic dispositions

### 5.1 English-first production that omitted diplomatic/corrected French

**Finding:** confirmed chronology and strong causal inference, register
`VDR-FM-0001`.

The completed English surface was real, but it was not a canonical bilingual
edition. French production began later from a provisional witness, and direct
French replay immediately found errors in the earlier English. Corrected
French was not a separate EGA layer at all; Verdier must not reproduce that
architectural omission. For Verdier, each unit is admitted in the sequence
authority reading, diplomatic French, corrected-French decision projection,
English alignment, semantic binding. Drafting can overlap in memory, but
closure cannot skip the sequence.

### 5.2 Conflating transcription, correction, translation, comparison, and publication

**Finding:** confirmed incident and recurrent architecture risk,
`VDR-FM-0002`, `0003`, `0019`, and `0038`.

The p.108 proof-square reversal is the smallest exact example. Reader workflow
leakage is the publication-surface example. Historical pending state beside
final review is the time-layer example. Verdier maintains separate source
files, ledgers, graph bindings, and package projections for each role. No
single `final_text` column or shared TeX include is allowed to erase how a form
entered the edition.

### 5.3 Silent normalization and missing reversal history

**Finding:** confirmed incident, `VDR-FM-0003`, with the broader decision
failure `0032`.

The EGA seed's accents were small changes but decisive evidence: editorially
reasonable text is not diplomatic text. The later stable IDs and reversal
policy are the positive precedent. Verdier's corrected French can carry a
reasonable emendation; diplomatic French cannot. Both the accepted and rejected
form remain machine-addressable.

### 5.4 OCR or reconstructed TeX as authority

**Finding:** confirmed witness divergence and high-severity authority hazard,
not a confirmed formal OCR-promotion policy, `VDR-FM-0004`.

The audit refuses to overstate this item. The controls already say image
decides. The failure evidence is that convenient reconstructed text differed
from print and that extraction is unreliable for math and diagrams. Verdier's
test is simple: no content-affecting row without the primary authority hash and
page can pass.

### 5.5 Weak page/formula/diagram mapping and low-resolution approval

**Finding:** multiple confirmed incidents, `VDR-FM-0005` through `0007`.

Page envelopes, formulas, and diagrams receive independent IDs and gates.
Physical page, printed page, running head, role, unit, reader projection, and
semantic coordinate are reconciled. Visual output proves layout only; direct
authority proves source. Resolution escalates for represented detail rather
than being applied as an expensive ritual.

### 5.6 Raster delivery where native TeX was required

**Finding:** confirmed, `VDR-FM-0008` and `0009`.

The 41 omitted PNG calls are decisive. Verdier cannot prove native delivery by
searching only `includegraphics`. It must enumerate wrapper macros and active
dependencies, bind every diagram to native source and review rows, and inspect
the PDF object inventory. The portrait is a distinct non-mathematical,
rights-sensitive asset hold and cannot be confused with mathematical diagram
policy.

### 5.7 Incomplete semantic/reference inventories described as complete

**Finding:** confirmed, `VDR-FM-0010` and `0011`.

Verdier's reference closure begins with the candidate universe, not the linked
subset. Numeric source shapes are candidates until syntax and mathematics
decide them. Coordinates and page numbers remain typed nonreferences; unresolved
mathematical citations remain residuals rather than vanishing.

### 5.8 References without reusable pre-Stacks scaffold

**Finding:** confirmed architectural gap, `VDR-FM-0012`.

Clickable references are a reader projection. The stable graph additionally
models objects, statements, proofs, hypotheses, conclusions, constructions,
formulas, diagrams, terms, notation, people, bibliography, source oddities,
corrections, and reversals. French and English bind to the same nodes.

### 5.9 Invented or unjustified Stacks mappings

**Finding:** no confirmed official-tag incident; controlled prospective hazard,
`VDR-FM-0013`.

No mapping is promoted from similar numbering, keywords, OCR text, page
proximity, or general subject resemblance. A row can remain `candidate`,
`rejected`, or `not_mapped`. The project never manufactures an official-looking
tag. Evidence class, relation type, exact local target, exact external target,
confidence, and mathematical reviewer are required before promotion.

### 5.10 Stale manifests, cached rewrites, duplicate IDs, and unlocked logs

**Finding:** manifest and regression incidents confirmed; duplicate IDs are a
prevented hazard, `VDR-FM-0014` through `0018`.

The EGA R2/R3 history proves row accuracy does not prove aggregate algorithm.
FAC proves manifest accuracy does not prove a sibling PASS summary. The shared
log proves append-only policy without append-safe mechanics can lose records.
Verdier uses ordinal manifests, independent replay, generation coherence,
locked append if ownership ever becomes shared, and cross-file ID uniqueness.

### 5.11 Status/AI/workflow prose in reader PDFs

**Finding:** confirmed, `VDR-FM-0019`.

Provenance remains complete in private controls and privacy-clean public
packages. Reader PDFs keep genuine scholarly apparatus, including properly
attributed editorial explanation of the unfinished thesis, but exclude project
status, source hashes, AI/model language, task IDs, QA notes, and build prose.

### 5.12 Private-path contamination and inaccurate privacy counts

**Finding:** confirmed chain, `VDR-FM-0020` through `0023`.

The chain matters: private members were published; initial counts confused
denominators; zero residuals depended on an incomplete regex; independent
custody found more private tokens; and a text transport changed bytes. Verdier
privacy closure therefore includes recursive member inspection, multiple
detectors, typed counts, raw-byte preservation, and post-transport readback.

### 5.13 Duplicate archive concepts/transports and weak raw readback

**Finding:** wrong routing and incomplete mirrors confirmed; duplicate concept
itself prevented, `VDR-FM-0024` through `0027` and `0039`.

Existing concepts are verified live and reused. A failed upload or verifier
exception resumes the tracked lineage. No new concept is minted as an escape
route. Publication means all expected outer bytes and container members have
been reread from the public endpoint, not merely that an API call returned
success.

### 5.14 False completion claims from narrower builds

**Finding:** confirmed, `VDR-FM-0028`.

The SGA and FAC cases demonstrate both missing-universe and mixed-generation
variants. Verdier final closure is a conjunction over the complete 270-page
topology, three textual layers, full graph, builds, visual review, privacy,
rights, package, and handoff. A bounded PASS stays bounded in its headline.

### 5.15 Unbounded searches and heavy concurrency

**Finding:** confirmed unsafe workflow with documented destabilization;
`VDR-FM-0029`.

The user's description “crashed Floris's PC” is honored as the controlling
reason for the prohibition. The audit's evidentiary prose remains precise about
what local receipts show: memory allocation failures, blank output, multi-
gigabyte decoded/context load, broad searches, and PC destabilization. The
Verdier rule is exact-path, reuse-first, serial, and one-crop-at-a-time.

### 5.16 Weak successor handoffs and compactification-related purpose loss

**Finding:** weak handoff and durable-goal scope loss confirmed; compactification
as sole cause not proven, `VDR-FM-0030` and `0031`.

A successor must be able to reconstruct the task from disk without chat. The
handoff includes exact objective, root, authority, ownership, historical/live
identities, closed and open pages, next cursor, layer and graph state, holds,
first safe action, prohibited actions, and terminal boundary.

### 5.17 Unlogged model/editorial choices and failure to propagate corrections

**Finding:** confirmed, `VDR-FM-0032` and `0033`.

Verdier records model preference only when it materially decides among forms;
routine drafting does not need performative narration. Every substantive
choice does need source form, alternatives, reason, confidence, inverse, and
scope. A later global correction searches every active occurrence and derived
reader and closes only after residual replay.

### 5.18 Retrospective displacement of corpus production

**Finding:** confirmed process risk, `VDR-FM-0040`.

The forensic requirement is large because earlier work lost control of scope,
not because controls are the final product. Once this generation is durable,
the audit becomes a stable input to page production. It is not regenerated
after every page. New incidents append to the existing ledger and safeguards;
global revalidation occurs at meaningful cumulative checkpoints.

## 6. The Verdier control architecture derived from the failures

### 6.1 Canonical unit loop

For each physical page and source unit, in order:

1. confirm physical, printed or unnumbered coordinate, running role, and unit
   seam from the direct NUMDAM page;
2. reuse an existing sufficient authority render or create one bounded broad
   view; escalate only a genuinely small ambiguity to one tight high-resolution
   crop;
3. transcribe diplomatic French exactly, preserving source oddities and
   incompleteness;
4. create or confirm the corrected-French projection and append every delta;
5. translate/recheck English against the same source unit, recording every
   functional departure and retained reader normalization;
6. reconstruct each mathematical diagram in native TeX and compare it
   element-by-element;
7. bind the three slices, formulas, diagrams, references, terminology, people,
   bibliography, role, and provenance to shared semantic IDs;
8. update candidate, edge, and residual tables without inventing targets;
9. append the exact page/unit cursor and any assumptions, reversals, or workflow
   errors; and
10. build only after substantive source change at a meaningful bounded
    checkpoint, then review every affected output page.

The loop separates source admission from compilation. A TeX file can be drafted
without being admitted; a bounded reader can build without making the unit
source-exact; a source-exact unit can remain semantically open; and all can be
closed locally while the whole issue remains incomplete.

### 6.2 Shared stable graph

The semantic graph is source-centred. It does not model “the French proposition”
and “the English proposition” as different mathematical propositions. One node
represents the source proposition. Diplomatic French, corrected French, and
English slices attach with their own text, coordinates, and decisions.

Minimum node classes are:

- publication, front-matter unit, chapter, section, subsection, numbered and
  unnumbered source unit;
- definition, convention, construction, remark, example, proposition, lemma,
  corollary, theorem, proof, incomplete proof, editor note, and source oddity;
- named category, functor, complex, localization, derived construction,
  morphism, natural transformation, and other mathematical objects as the text
  introduces them;
- formula, numbered equation, exact sequence, diagram, table, and note;
- terminology, notation, person, work, bibliography item, and external
  reference target; and
- transcription, correction, normalization, translation, reversal, repair,
  ambiguity, and review decisions.

Minimum edge classes include containment, statement/proof, definition-use,
proof-use, hypothesis, conclusion, construction input/output, comparison,
forward pointer, backward reference, range, same-work reference, external
citation, correction-of, normalization-of, translation-of, supersedes, and
possible Stacks alignment. Every edge has evidence, confidence, and review
state. Candidate alignments remain outside the admitted dependency graph until
mathematically justified.

### 6.3 Completion gates

The final Verdier conjunction is deliberately demanding:

- exact disposition for all 270 physical pages, with page 1 typed as provider
  wrapper and hard stop after page 270;
- all source-bearing and apparatus units assigned correct responsibility;
- complete diplomatic French;
- complete corrected French with an exhaustive delta ledger;
- complete source-aligned English with exhaustive functional-departure ledger;
- exact unfinished-state parity across all layers;
- full formula and native-diagram universes with review closure;
- complete reference candidate partition and internal-target closure;
- complete declared semantic node/edge/index classes with zero unclassified
  source-universe residuals;
- evidence-qualified pre-Stacks candidate mappings and no invented official
  tags;
- serial final builds on one source generation and affected/full visual QA;
- reader-surface purity, independent privacy scans, and asset/right
  dispositions;
- exact ordinal package manifest and independent replay;
- disk-sufficient successor handoff and acceptance; and
- if separately authorized, correct existing archive routes and complete raw
  public outer/member readback.

No single Boolean validator can make these facts true. The final validator
reports each component and computes their conjunction only after their exact
evidence exists.

## 7. What is frozen at the retrospective boundary

Before the later retrospective mandate arrived, physical PDF pages 2--7 had
been drafted into four source surfaces: title/classification/portrait caption
and Luc Illusie's complete preface. They were not compiled, validated, or
promoted. Their frozen identities are:

- diplomatic French: 5,149 bytes, SHA-256
  `5AA82E486025105078FA54507A044508E65EA312825C49825E9B74519B9EC61B`;
- corrected French: identical 5,149 bytes and hash at this no-correction
  checkpoint;
- English: 4,899 bytes, SHA-256
  `59E46844F8FFA82479F744D3C089FFCF58FD69141B92B09A7C01FC5F565CC4C2`;
- bilingual parallel source: 9,561 bytes, SHA-256
  `EAFD244A28E42B891A1D744784F82E8BA969C62D06E1D1967C1FA97BDD20B30B`.

The portrait raster remains private rights-sensitive witness material. Only
its printed caption is transcribed. No build has occurred. The source cursor is
physical PDF p.8, logical p.iii, first paragraph of the editors' note. The
retrospective must verify those four identities before releasing the production
hold.

## 8. Successor-continuation section

This section is intentionally redundant with `CONTINUATION_HANDOFF.md` so a
future task can recover purpose even if one control is damaged.

### 8.1 Objective

Produce the complete canonical bilingual scholarly edition of Jean-Louis
Verdier's *Des catégories dérivées des catégories abéliennes* exactly as
published in Astérisque 239 (1996), edited by Georges Maltsiniotis. Deliver
diplomatic French, separately corrected French, source-aligned English, local
single-language and bilingual readers, exhaustive semantic references and
indexes, and a machine-readable pre-Stacks graph. Preserve the fact that the
thesis body is unfinished. Do not enter any other Verdier work or SGA 4/4 1/2.

### 8.2 Authority and root

The controlling PDF is:

`C:\Users\Floris\Documents\Papors\OS\AST_1996__239__R1_0.pdf`

Identity: 19,188,423 bytes, 270 physical pages, SHA-256
`6214C252BACEBA5584E3C4AEB564C129851941C1A9250BABAB45B79A3939B0AE`.

The only write root is:

`C:\Users\Floris\Documents\interlanguage\03_projects\language_management\english_germanic\03_working_translations\verdier_derived_categories_bilingual_canonical_stacks_20260804_r1`

Alternate local DJVU and PDF witnesses are comparison-only and have their exact
identities in `SOURCE_AUTHORITY.csv`. Authority and predecessor trees are
immutable.

### 8.3 Ownership and non-overlap

This task exclusively owns the complete Astérisque 239 issue. FGA, Tôhoku,
Illusie I--II, EGA, Deligne, SGA, FAC, and GAGA remain outside the root. Recheck
live task ownership before a resumed edit and append the receipt. Do not infer
handback from silence.

### 8.4 Closed, drafted, and open state

- Handoff/bootstrap read, hash, validation, authority, and ownership checks:
  complete.
- Retrospective source investigation: complete when the companion validation
  reports PASS; never stop merely because a token threshold was reached.
- Pages 2--7 text: drafted in four layers, frozen, unbuilt, not promoted.
- Physical p.1: provider wrapper, not issue content.
- Portrait: private witness hold; no reader raster reference.
- Next source cursor: physical p.8 / logical iii / Georges Maltsiniotis,
  `Note des éditeurs`, first paragraph.
- Terminal cursor: physical p.270, end of Astérisque 239; hard stop.

### 8.5 First safe action after retrospective PASS

1. Replay the retrospective validation and four frozen draft hashes.
2. Read `BINDING_SAFEGUARDS.md`, the assumption ledger, status, logbook, and
   continuation through EOF.
3. Inspect live ownership and append no-overlap.
4. Directly read physical p.8 at ordinary bounded resolution, confirming the
   printed/logical coordinate and the editor-role boundary.
5. Transcribe the next coherent editors-note unit diplomatically; create the
   corrected-French projection; translate English; bind all three to one unit
   and role ID.
6. Record every decision before any build. No OCR. No portrait promotion.
7. Continue sequentially through front matter and thesis body, preserving the
   unfinished state and stopping at p.270.

### 8.6 Prohibited first actions

Do not compile the frozen draft merely to obtain a quick PASS. Do not scan all
Documents for comparison material. Do not generate OCR. Do not bulk-render the
270-page PDF. Do not load whole pages at 5,000--9,000 dpi. Do not copy an old
Verdier translation into authority position. Do not add an official-looking
Stacks tag. Do not embed the portrait or source crops in readers. Do not create
an archive concept, upload, public candidate, or external mutation. Do not
advance past Astérisque 239.

### 8.7 How later errors are recorded

Every later violation or changed premise is appended to the assumption/reversal
ledger and project logbook. Content decisions go to their layer-specific
JSONL; global repairs go to `REVERSALS_AND_GLOBAL_REPAIRS.jsonl`; diagram and
formula adjudications go to the review table and shared graph. A correction is
closed only after every active copy and derived gate is repaired. Historical
artifacts remain frozen and explicitly superseded.

## 9. Audit conclusion

Earlier failures were rarely caused by the absence of effort. They were caused
by effort applied to the wrong proof obligation: validating a selected set
without proving that it was the whole set; polishing one language before
authority alignment; relying on a successful build for source semantics;
trusting a validator's self-description; or treating upload, manifest, or zero
regex hits as terminal evidence.

The Verdier edition will be safer only if its controls remain subordinate to
the scholarly object. The correct production unit is one directly read source
unit with three distinct textual layers and one shared semantic identity. The
correct cumulative claim is the exact conjunction of every unit, formula,
diagram, reference, role, page, decision, build, privacy, rights, and handoff
gate on one generation. The correct response to error is append-only
correction and full active-scope propagation. The correct response to
uncertainty is an explicit residual, never an invented completion.

Two compact phrases summarize the transport and concurrency gates. A **shared
append log** requires live locking, inside-lock duplicate rejection, validation,
and rollback; an append-only intention implemented by cached whole-file rewrite
is not safe. A publication claim requires **raw member readback** as well as
outer-file readback; an upload response or container hash cannot prove member
presence, safe paths, byte identity, or privacy.

Shared append log integrity and raw member readback are independent mandatory
gates.
