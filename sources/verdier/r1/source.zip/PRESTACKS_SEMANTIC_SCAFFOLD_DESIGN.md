# Pre-Stacks semantic scaffold design

Status: controlling design; population remains sequential with source work  
Principle: one source-centred graph, three textual layer projections

## 1. Purpose and non-claim

This scaffold prepares Astérisque 239 for later Stacks-style reconstruction.
It is not a claim that Verdier's text has already been converted into the
Stacks Project, formally verified, completed, or assigned official Stacks tags.
It captures stable mathematical identity, provenance, dependencies, and
ambiguity so later work can deepen the graph without rereading the entire
publication merely to recover structure.

Clickable PDF references are one output of the scaffold. They are not the
scaffold itself.

## 2. Stable ID grammar

IDs use ASCII, publication identity, structural role, source numbering, and a
stable disambiguator when necessary. They never depend on mutable TeX line
numbers, byte offsets, output pages, or chronological insertion order.

Recommended forms:

- publication: `VDR-A239`;
- front matter: `VDR-A239-FM-PREFACE`, `VDR-A239-FM-EDITORS-NOTE`;
- chapter: `VDR-A239-CH-I`;
- section/subsection: `VDR-A239-CH-I-S-1`, `...-SS-1-2`;
- numbered statement: `VDR-A239-CH-I-PROP-1-2-3`;
- definition, lemma, theorem, corollary, remark, example, convention:
  corresponding kind token plus printed number;
- unnumbered unit: parent ID plus stable role and ordinal within the printed
  parent, for example `...-PROOF-OF-PROP-1-2-3` or `...-REMARK-UNN-02`;
- equation/formula: parent ID plus `EQ`, `FORM`, or `SEQ` and printed tag or
  stable within-parent ordinal;
- diagram: parent ID plus `DGM` and printed/within-parent ordinal;
- subitem: parent statement plus `ITEM-A`, `ITEM-I`, or exact source label;
- bibliography: `VDR-A239-BIB-<stable-key>`;
- person: `VDR-PERSON-<canonical-slug>`;
- term/notation: `VDR-TERM-...`, `VDR-NOT-...`;
- decision: existing `VDR-*` ledger namespaces; and
- candidate external alignment: `VDR-STX-CAND-####`.

If printed numbering collides across kinds, kind remains part of the ID. If two
unnumbered units of the same kind collide, a stable within-parent ordinal is
assigned from printed order and never renumbered; later discoveries use a
suffix and alias rather than shifting existing IDs.

## 3. Required node classes

### 3.1 Publication and structural nodes

- publication, wrapper, title, classification, portrait caption;
- preface, editors' note, publication list, internal title;
- introduction, chapter, section, subsection, paragraph;
- notation index, subject/term index, bibliography, contents;
- blank or intentionally empty page where topology requires it; and
- terminal unfinished/truncated boundary.

### 3.2 Mathematical discourse nodes

- definition, convention, notation declaration;
- proposition, lemma, theorem, corollary;
- remark, example, counterexample, warning;
- proof, incomplete proof, proof sketch, omitted proof, editor-supplied note;
- hypothesis set, conclusion, equivalence, construction, universal property;
- named category, class, object, complex, morphism, functor, transformation,
  localization, derived construction, filtration, truncation, or other object
  introduced by the text; and
- explicit ambiguity or source oddity.

### 3.3 Mathematical expression nodes

- displayed formula and numbered equation;
- consequential inline formula;
- exact sequence, triangle, complex, array, table;
- commutative or other diagram;
- diagram node and edge when element-level structure matters; and
- formula/diagram source error or corrected projection.

### 3.4 Scholarly apparatus nodes

- person and responsible role;
- cited work and bibliography entry;
- terminology and translation choice;
- notation and scope;
- transcription, correction, normalization, translation, reversal, global
  repair, visual review, and confidence decision; and
- authority page/crop and comparison-witness use.

## 4. Required node fields

Every semantic target row must support, as applicable:

- `semantic_id`;
- `kind` and optional subtype;
- `publication_id` and parent ID;
- source-visible number/title;
- physical page start/end and printed/unnumbered coordinates;
- responsible agent and unit role;
- completion state, including `unfinished`, `truncated`, or `editor_supplied`;
- diplomatic French slice locator;
- corrected-French slice locator;
- English slice locator;
- authority SHA and review evidence;
- formula/diagram IDs contained;
- active decision IDs;
- ambiguity state;
- review method, reviewer, confidence, and generation;
- reader anchor(s), which may change without changing the semantic ID; and
- supersession or alias fields.

## 5. Typed edges

Required edge classes include:

- `contains`, `part_of`, `precedes`, `continues_on`;
- `statement_has_proof`, `proof_proves`, `proof_incomplete_for`;
- `has_hypothesis`, `has_conclusion`, `equivalent_to`, `implies`;
- `defines`, `uses_definition`, `constructs`, `uses_construction`;
- `uses_result`, `cites`, `compares`, `specializes`, `generalizes`;
- `forward_pointer`, `back_reference`, `range_reference`, `cross_chapter`;
- `formula_in_unit`, `diagram_in_unit`, `diagram_edge_represents`;
- `term_denotes`, `notation_denotes`, `translation_of`;
- `diplomatic_slice_of`, `corrected_slice_of`, `english_slice_of`;
- `correction_of`, `normalization_of`, `reversal_of`, `supersedes`;
- `authored_by`, `edited_by`, `prefaced_by`;
- `bibliography_cites`, `external_reference`;
- `possible_stacks_alignment`; and
- `excluded_nonreference` for positive negative-class evidence when useful.

Every edge records source ID, target ID, relation class, source span, evidence,
confidence, reviewer, generation, and status. An uncertain edge is a candidate,
not an admitted edge.

## 6. Reference pipeline

The complete reference process is:

1. derive candidate occurrences from the full active source universe;
2. record exact source span, lexical context, syntax class, visible locator,
   and current source hash;
3. classify positive reference, negative nonreference, ambiguity, or duplicate;
4. resolve positive candidates to stable internal targets or typed external
   targets;
5. create admitted edges only after semantic-kind and local mathematical
   context agree;
6. retain unresolved or intentionally unlinked cases as typed residuals;
7. require `candidate universe = active edges disjoint-union active residuals`
   after accounting for explicit rejected/nonreference records;
8. generate reader links from admitted edges after source freeze; and
9. replay PDF destinations/actions and final coordinates.

Number shape never decides target kind. TikZ coordinates, dimensions, style
values, page folios, equation tags in declarations, and similar syntax are
explicit candidate classes that can be rejected without disappearing from the
audit trail.

## 7. Formula and diagram inventories

`FORMULA_INDEX.csv` and `DIAGRAM_INDEX.csv` must be derivable from the same
active source dependency closure as the readers. Wrapper macros and native
input files are expanded in the universe generator.

Formula rows bind all three layer forms, exact authority page, punctuation and
index decisions, dependencies, and reader anchors. Diagram rows bind node and
edge counts, element inventories, native TeX locus, private evidence identities,
review resolution, lead judgment, and residuals.

Final native-diagram closure requires equality among active diagram
invocations, diagram index, native source files, and lead review rows, plus
zero mathematical raster objects in the reader PDF.

## 8. Terminology, notation, people, and bibliography

Term and notation records are scoped. A symbol may mean different things in
different chapters or local contexts and must not be globally merged from
surface spelling alone. English choices bind to source terms and decision IDs.

Person records distinguish author, editor, preface writer, cited mathematician,
and subject of a bibliographic note. Bibliography records bind printed entries,
in-text citations, external identifiers where verified, and unresolved
abbreviations without fabricating metadata.

## 9. Stacks migration map

`STACKS_ALIGNMENT_CANDIDATES.csv` is a migration-planning table. Minimum fields:

- local candidate ID and semantic target ID;
- exact local unit/formula/diagram scope;
- Stacks topic or exact verified tag/URL, if any;
- mapping class: `equivalent`, `special_case`, `analogue`, `prerequisite`,
  `terminology_only`, `historical_precursor`, `candidate`, `rejected`, or
  `not_mapped`;
- primary evidence and mathematical comparison;
- important hypothesis or convention differences;
- confidence vocabulary with explicit meaning;
- reviewer and review state;
- generation and supersession; and
- downstream migration note.

An empty Stacks target with `candidate` is valid. A guessed tag is not. Local
IDs never adopt official-looking Stacks tag syntax. The later migration can
create a separate mapping layer without changing source semantic identity.

## 10. Provenance per semantic unit

Every unit must allow reconstruction of:

- which authority page was read;
- which language slices represent it;
- who is responsible for the printed text;
- what corrections or normalizations were considered, accepted, rejected, or
  reversed;
- which formulas, diagrams, and references it contains;
- what prior units it uses and later units use it;
- whether the text or proof is unfinished;
- what visual evidence resolved ambiguity;
- which build and reader generation projects it; and
- what remains open.

This provenance is stored in machine-readable tables and ledgers. Markdown
summaries explain it but do not replace it.

## 11. Validation and closure

The scaffold validator checks:

- CSV/JSONL parse and required columns;
- stable-ID uniqueness across the union;
- parent and edge referential integrity;
- no source node duplicated by language;
- page and unit set equality;
- formula and diagram universe equality;
- complete candidate/edge/residual disposition;
- no active edge from excluded syntax classes;
- every textual layer binding resolves;
- every correction/reversal ID resolves reciprocally;
- confidence and status vocabulary;
- no official Stacks claim without exact verified evidence;
- historical versus current generation typing; and
- zero dangling reader anchors only at final coordinate closure.

During sequential source work, source-certain nodes and explicit edges are
added without blocking transcription. At meaningful cumulative checkpoints,
the full universe generators and residual audits run. After the canonical
source freeze, exhaustive graph, index, coordinate, and migration-map closure
is required before any semantic-complete claim.
