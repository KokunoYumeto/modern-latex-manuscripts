# Parent task history evidence

Durable artifact name: `PARENT_TASK_HISTORY_EVIDENCE.md`.

## 1. Source and replay boundary

The controlling predecessor task is Codex thread
`019f711e-cac3-7a10-a0e6-dc0131799c3a`, titled in the application
`SGA 1–7.2 Global Reader + FAC/GAGA`. On 2026-08-04 this Verdier task used the
application's read-only thread-history surface to page from the live newest
turn to the originating delegation. The replay consumed twelve consecutive
newest-to-oldest pages, 113 turn summaries in all. The cursor chain was:

1. initial page -> `5268f722-baff-4f0d-a977-342c2246a690`;
2. `5268f722-baff-4f0d-a977-342c2246a690` ->
   `d3cd607a-f75b-472b-8ab3-475586f5dc7e`;
3. `d3cd607a-f75b-472b-8ab3-475586f5dc7e` ->
   `f1fb7af4-0a3b-4a9c-8e06-0ff8b3e0c4d6`;
4. `f1fb7af4-0a3b-4a9c-8e06-0ff8b3e0c4d6` ->
   `b959400d-335b-4a91-a53b-4e6c03539874`;
5. `b959400d-335b-4a91-a53b-4e6c03539874` ->
   `019fb4cd-81dd-75c0-ba8a-a749adc0ae8c`;
6. `019fb4cd-81dd-75c0-ba8a-a749adc0ae8c` ->
   `019fb160-68d5-7922-84bc-428b1cb1d7ba`;
7. `019fb160-68d5-7922-84bc-428b1cb1d7ba` ->
   `019fa8fc-15a2-7d31-9382-330d7f5c2f13`;
8. `019fa8fc-15a2-7d31-9382-330d7f5c2f13` ->
   `019f91de-4cfb-7e62-966d-fef7b2757785`;
9. `019f91de-4cfb-7e62-966d-fef7b2757785` ->
   `019f88b9-2012-76a1-ae48-012d659cf70a`;
10. `019f88b9-2012-76a1-ae48-012d659cf70a` ->
    `8a740291-bd22-478b-960e-f2d3187924e0`;
11. `8a740291-bd22-478b-960e-f2d3187924e0` ->
    `019f7229-ec34-74a0-8637-02557cfd52d4`;
12. `019f7229-ec34-74a0-8637-02557cfd52d4` -> end, with
    `hasMore: false`.

The oldest returned turn is `019f711e-e016-7d73-9d56-8eab55a75633`, the
original SGA5 synchronization delegation. The newest returned turn at replay
time is `c8bcbaf5-72be-4960-8dd2-6c0a0df23479`, then in progress on FAC
reference work. This is a complete replay of the application's available turn
summary pagination for the named task at that observation time.

The thread-history surface does not expose a stable export byte stream or a
SHA-256 identity for the whole task. It also truncates individual messages and
tool outputs. Therefore it is not represented falsely as an immutable local
file in `RETROSPECTIVE_SOURCE_MANIFEST.csv`. This file is the durable synthesis
of that replay. Exact local controls, status files, ledgers, manifests, and
validation receipts remain higher-grade evidence for content and identity
claims.

## 2. Evidence extracted from task history

### 2.1 Missing or narrowed goals

Turn `019f712c-85ed-7633-a77a-3bce4ecdf284` contains the user's direct report
that no pursuit goal was visible. Much later, turn
`c0c6ff22-0e0e-4ee3-a09b-5d4fe047114c` records the user finding that the goal
had narrowed to the wrong object and omitted the required SGA, FAC, GAGA,
French, and cumulative-reader scope. This independently supports the local
successor controls requiring a complete disk-resident objective and a restart
read-in.

### 2.2 Model/configuration rework

Turn `019f7125-1e22-7951-b5fa-c5a805d02e64` says the task had been run on the
wrong model and directs it to redo its work. Turn
`019f752f-cfe0-7e33-9bf9-b311ec375d8b` repeats that the last two hours needed
rechecking because of the model setting. The thread summaries do not prove
which exact bytes were wrong or how much work was invalidated; the incident is
therefore evidence of unrecorded execution-premise drift, not proof that every
artifact from that interval was defective.

### 2.3 OCR/source-authority confusion and wasted review

Turn `5359b4ec-f0d1-4f82-95e9-be069ce7d49c` records a controlling correction:
official SGA1 TeX was already fully transcribed, edition typos had been
misclassified as a transcription workstream, and scan checking had consumed a
very large amount of effort without finding transcription defects. Turn
`019f7601-5d25-7453-b03d-3cc39db2a972` separately records that Claude's SGA3
output was raw OCR substrate and must not be called source transcription or a
candidate edition. Together these messages establish both directions of the
authority error: treating a complete direct digital source as if it needed OCR
forensics, and treating OCR-shaped output as if it might be an edition.

### 2.4 Parallel fragments and broken cumulative state

The same turn `5359b4ec-f0d1-4f82-95e9-be069ce7d49c` records repeated
coordination messages assigning narrow translation ranges to parallel workers,
followed by an urgent failure: four translated fragment files referenced by the
cumulative SGA1 master had disappeared, and the build was broken until the
fragments were restored. This is direct task-history evidence that parallel
range allocation without immutable handoff identities and an atomic integration
gate can create a master that names unavailable inputs.

### 2.5 Low-resolution diagram approval reversed

Turn `019fa64b-4d61-7763-b848-0b92a1114e16` contains the high-detail recheck of
the first thirty Exposé-V diagrams: zero mathematical-content errors but five
strict layout-fidelity failures in figures 007–011 that the earlier roughly
300-dpi review missed. The later control switched to direct authority review at
about 5,000 dpi, escalating toward 9,000 only for genuine ambiguity. This task
history agrees with the durable diagram fail-close controls and is not used to
justify blanket high-resolution rendering.

### 2.6 Scope whiplash and retractions

Turns `019fa8fc-15a2-7d31-9382-330d7f5c2f13`,
`019fae1f-1d52-7243-9651-d2cb712e92ad`,
`019fb160-68d5-7922-84bc-428b1cb1d7ba`, and
`019fb4cd-81dd-75c0-ba8a-a749adc0ae8c` preserve repeated switches among SGA3,
EGA I, EGA II, EGA III, and EGA IV. One manager message explicitly retracts
its immediately preceding EGA-I routing; a later message reverses it again to
SGA3. Subsequent turns route the same task into SGA7 I/II, FAC, GAGA, and the
global SGA reader. Some reassignment was legitimate, but chat carried mutually
incompatible live instructions and forced repeated ownership checks. The root
cause is not simply “too many tasks”: current ownership and objective were not
materialized as a single validated state before work began.

### 2.7 Completion rhetoric challenged by scope

Turn `9dcbba66-976f-4fcb-b035-689b0d634eb7` shows a claimed complete SGA1
English reader being challenged because its apparent page count was about
eighty pages shorter than the French. The summary alone does not establish
whether layout, omitted material, or an incorrect page count explained the
delta, so this is classified as a completion claim requiring denominator
replay, not as proof of a specific omission. Turn
`019fb31f-0ebe-79c2-9d2c-c567b934e7fa` later records the same recurring user
question: if the task was idle, were EGA and SGA genuinely finished?

### 2.8 Machine failures and the causal boundary

Turn `019f7229-ec34-74a0-8637-02557cfd52d4` records a memory spike and PC
crash. Turns `b536ed30-cc40-4a04-a488-77ae9a037e2d` and
`3611eb23-fe34-4d15-97a6-def4c9b96453` record two later user-observed PC-kill
events. Turn `f1fb7af4-0a3b-4a9c-8e06-0ff8b3e0c4d6` supplies the user's causal
diagnosis for the latter incident: a global search over the multi-terabyte
Documents tree, with an explicit instruction never to repeat it. The task
history does not expose operating-system telemetry, so the crash mechanism is
reported as user-observed and user-attributed; the unsafe command scope itself
is independently corroborated by durable resource controls.

### 2.9 Compactification and loss of controlling state

The task history contains heavily compacted turns: turn
`b959400d-335b-4a91-a53b-4e6c03539874` reports 67 compactions, turn
`019fa64b-4d61-7763-b848-0b92a1114e16` reports 57, and turn
`019fae1f-1d52-7243-9651-d2cb712e92ad` reports 37. Compaction count does not by
itself prove an erroneous edit. It does prove that chat memory was a poor sole
custodian for a task with hundreds of file changes and frequent rerouting. The
proper control is a disk-sufficient current-state cursor plus append-only
history, not an attempt to preserve purpose by ever longer chat prompts.

### 2.10 Logbooks as evidence, not decoration

Turn `dde2cc61-7dcc-482f-b3a9-2c9d73c477fa` records the user's direct
instruction that logbooks and the comparative translation are primary trust
evidence for mathematicians, including every correction and rationale. The
same turn also records the demand for a useful global table of contents. This
supports the distinction between scholarly auditability and workflow prose:
decision evidence belongs in durable private/public-support controls, while
the reader itself must remain a readable mathematical edition.

### 2.11 Reader prose and duplicate archive structure

Turn `623548d2-34ec-43a7-a004-315fba57513d` records the user's explicit
instruction not to put source-status rambling in the PDF. The later FAC/Zenodo
sequence in the same thread includes user items `item-6074` and `item-6076`,
which require a redundant quality-assessment DOI to be tombstoned and folded
into the single FAC lineage. Agent item `item-6081` reports record `21779393`
gone as a duplicate. These task-history items corroborate the durable archive
records; the durable records, not the chat assertion, decide final archive
truth.

## 3. Controls bound into Verdier

The Verdier task therefore treats the following as fail-close conditions:

- no source mutation without one complete current goal, root, owner, cursor,
  authority, and hard stop on disk;
- no chat-only assignment or correction;
- no OCR when direct authority text is available, and no OCR-shaped witness in
  the authority role;
- no parallel range integration unless every input is immutable, hashed,
  present, and atomically replayed;
- no source-complete claim from a page count, build, seed candidate list, or
  selected inventory;
- no diagram approval from low-resolution navigation evidence;
- no Documents-wide or profile-wide search and no concurrent heavy work;
- no current status assembled from chronological prose alone;
- no workflow, task, AI, source-status, or private-path prose in readers; and
- no archive action unless separately authorized and bound to one verified
  existing concept plus raw public readback.

This replay is complete for the named task-history surface at the observed
checkpoint. It is an evidentiary supplement, not an authority source for
Verdier and not permission to mutate any predecessor corpus.
