[CmdletBinding()]
param(
    [ValidateSet('fr-diplomatic', 'fr-corrected', 'english', 'bilingual', 'all')]
    [string]$Reader = 'all'
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSCommandPath
$targets = [ordered]@{
    'fr-diplomatic' = 'reader_fr_diplomatic.tex'
    'fr-corrected'  = 'reader_fr_corrected.tex'
    'english'       = 'reader_english.tex'
    'bilingual'     = 'reader_bilingual.tex'
}

if ($Reader -eq 'all') {
    $selectedTargets = @($targets.Keys)
} else {
    $selectedTargets = @($Reader)
}

$latexmk = Get-Command -Name 'latexmk' -ErrorAction SilentlyContinue
$lualatex = Get-Command -Name 'lualatex' -ErrorAction SilentlyContinue
if ($null -eq $latexmk -and $null -eq $lualatex) {
    throw 'Neither latexmk nor lualatex is available on PATH.'
}

Push-Location -LiteralPath $projectRoot
try {
    foreach ($target in $selectedTargets) {
        $entryPath = Join-Path $projectRoot $targets[$target]
        $outputDirectory = Join-Path $projectRoot (Join-Path 'build' $target)
        [System.IO.Directory]::CreateDirectory($outputDirectory) | Out-Null

        if ($null -ne $latexmk) {
            & $latexmk.Source '-lualatex' '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' "-outdir=$outputDirectory" $entryPath
            if ($LASTEXITCODE -ne 0) {
                throw "Reader build failed: $target"
            }
            continue
        }

        for ($pass = 1; $pass -le 2; $pass++) {
            & $lualatex.Source '-interaction=nonstopmode' '-halt-on-error' '-file-line-error' "-output-directory=$outputDirectory" $entryPath
            if ($LASTEXITCODE -ne 0) {
                throw "Reader build failed: $target (pass $pass)"
            }
        }
    }
} finally {
    Pop-Location
}
