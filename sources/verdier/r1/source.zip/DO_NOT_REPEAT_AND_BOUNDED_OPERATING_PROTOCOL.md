# Do-not-repeat checklist and bounded operating protocol

Status: controlling quick-action companion to `BINDING_SAFEGUARDS.md`

## Before every production session

- [ ] Read status, project logbook, assumption/reversal ledger, binding
  safeguards, current validation, and continuation through EOF.
- [ ] Rehash the controlling authority and active source generation named by
  the handoff.
- [ ] Inspect live task ownership and append exact no-overlap.
- [ ] State the last closed unit, first open unit, physical/printed coordinate,
  responsible agent, and first safe action.
- [ ] Confirm no other heavy render, OCR, build, or audit process is active.
- [ ] Confirm the target write path resolves inside the Verdier root.
- [ ] Stop if any required identity, cursor, role, or ownership fact is missing.

## Do not repeat

- [ ] Do not call an English-only reader bilingual or canonical completion.
- [ ] Do not merge diplomatic French, corrected French, English, comparison,
  or publication state.
- [ ] Do not silently normalize spelling, accents, punctuation, notation,
  formulae, diagrams, references, or proof structure.
- [ ] Do not let OCR, extraction, reconstructed TeX, inherited translation, or
  later literature decide the source.
- [ ] Do not create new OCR.
- [ ] Do not approve small formula/diagram detail from a thumbnail, contact
  sheet, low-resolution whole page, or compiled appearance.
- [ ] Do not deliver mathematical diagrams as raster images.
- [ ] Do not prove completeness only over already-known or already-mapped
  items; derive the full active universe first.
- [ ] Do not confuse working PDF links with a reusable semantic graph.
- [ ] Do not invent official Stacks tags or equivalences.
- [ ] Do not trust a manifest or validator without independent scope and
  aggregate replay.
- [ ] Do not apply a historical PASS to later mutable bytes.
- [ ] Do not rewrite a shared log from a cached snapshot or reuse a stable ID.
- [ ] Do not put AI, model, task, build, QA, status, hash, private-path, or
  workflow prose in reader PDFs.
- [ ] Do not treat one regex or one kind of privacy count as closure.
- [ ] Do not create a new archive concept or duplicate transport for a retry.
- [ ] Do not call an upload published until public raw bytes and members match.
- [ ] Do not use a bounded build to claim a larger range.
- [ ] Do not scan all Documents, a profile, a drive, or the relocated Chatnotes
  tree.
- [ ] Do not batch-render authority pages, bulk-load high-resolution images,
  run parallel heavy builds, or delegate final mathematical/visual judgment.
- [ ] Do not leave a discovered global failure pattern repaired only locally.
- [ ] Do not depend on chat history for successor purpose.
- [ ] Do not complete Verdier's historically unfinished text.
- [ ] Do not cross physical p.270 or enter another Verdier work or SGA 4/4 1/2.

## Bounded source-unit protocol

1. Resolve one coherent unit and its page envelope.
2. Reuse an exact sufficient authority render if present.
3. Otherwise create one broad direct view at roughly 1,100--1,800
   dpi-equivalent.
4. If one genuinely small mark remains ambiguous, create one tight direct crop
   at roughly 5,000--9,000 dpi-equivalent; do not render a whole page there.
5. Confirm physical page, printed/unnumbered coordinate, running role, and seam.
6. Read direct authority; extraction is locator-only.
7. Admit diplomatic French without correction.
8. Project corrected French and log every delta or explicit no-delta state.
9. Produce/recheck English and log every functional departure.
10. Reconstruct diagrams natively and review every graph element.
11. Bind unit, formulas, diagrams, terms, references, roles, and decisions to
    stable semantic IDs.
12. Update candidates, edges, and residuals without suppressing ambiguity.
13. Append exact cursor, source identities, review method, and open holds.
14. Build serially only if substantive source/build-system bytes changed and a
    meaningful bounded checkpoint is intended.
15. Inspect every affected output page and keep source-fidelity evidence
    separate from layout evidence.

## Global-correction protocol

1. Append the discovering incident and original decision ID.
2. Define the exact authorized active search universe and reproducible
   predicate.
3. Enumerate every occurrence; do not search unrelated roots.
4. Classify true affected occurrences, false positives, historical frozen
   copies, and residual ambiguities.
5. Repair active sources copy-on-write.
6. Update corrected/English projections, semantic bindings, indexes, and
   decision links.
7. Build/review only affected readers and then the next required cumulative
   checkpoint.
8. Rerun independent fixed-string, syntax-aware, and semantic residual checks.
9. Record exact repaired identities and zero residual or typed held residuals.
10. Append reciprocal supersession; never rewrite the original judgment.

## Build protocol

- [ ] Triggering edit IDs recorded.
- [ ] Exact source manifest current.
- [ ] Engine, working directory, master, output directory, and job name
  resolved and printed.
- [ ] One heavy build at a time.
- [ ] Output is outside source and contains no literal variable-name directory.
- [ ] All passes and diagnostics retained.
- [ ] Expected page count/range stated before interpreting success.
- [ ] Changed-page mapping and visual review set complete.
- [ ] Build PASS reported only for the exact generation and range.

## Diagram protocol

- [ ] Active source dependency closure enumerated, including wrapper macros.
- [ ] Diagram occurrence has one stable ID and exact authority page.
- [ ] Node count and symbols checked.
- [ ] Every arrow presence and direction checked.
- [ ] Every label text, side, prime, index, attachment, and punctuation checked.
- [ ] Native TeX source bound.
- [ ] Private evidence crop identity bound.
- [ ] Lead review and confidence recorded.
- [ ] Diagram index, active calls, native sources, and review rows are equal.
- [ ] Final PDF contains zero mathematical raster image objects.

## Reference and semantic protocol

- [ ] Candidate universe derived from every active source component.
- [ ] Candidate source span, syntax class, visible locator, and source hash
  recorded.
- [ ] Coordinate/dimension/style and other nonreference classes preserved as
  rejected evidence.
- [ ] Mathematical kind and local context decide same-number collisions.
- [ ] Every candidate has exactly one edge/residual/rejected disposition.
- [ ] Every edge target resolves uniquely and has evidence/confidence.
- [ ] All required unit/formula/diagram/term/notation/person/bibliography nodes
  exist.
- [ ] French and English slices attach to one graph, not duplicate graphs.
- [ ] Stacks rows remain candidates absent direct verification.
- [ ] PDF action replay occurs only after final source/edge generation.

## Privacy and reader protocol

- [ ] Scan TeX sources and included assets.
- [ ] Extract and scan PDF text.
- [ ] Scan bookmarks, annotations, metadata, attachments, and TOC.
- [ ] Inspect rendered front matter and any changed apparatus.
- [ ] Run literal normalized-root detectors.
- [ ] Run boundary-aware and boundary-free UUID/task/state shape detectors.
- [ ] Record events, affected records, fields, files, and unique values
  separately.
- [ ] Recursively inspect every package/archive member and safe path.
- [ ] Preserve private raw logs; publish only a validated privacy-clean
  projection if authorized.
- [ ] Reader contains scholarship, not workflow.

## Package/archive/readback protocol

- [ ] New project-owned basenames are at most 32 characters and new paths are
  at most four components below the work root, except recorded imported or
  frozen compatibility paths.
- [ ] Descriptions live in existing manifests and stable IDs; no aliases,
  duplicate convenience copies, or one-file-per-workflow-event trees.
- [ ] Any live-path shortening updates all consumers atomically and leaves no
  stale reference; frozen checkpoint paths are not rewritten.
- [ ] Rights disposition per layer and asset; no invented permission.
- [ ] Exact final directory only; self-excluding ordinal manifest.
- [ ] Independent membership/order/byte/hash/aggregate replay.
- [ ] Validation summary recomputed from manifest and same generation.
- [ ] Existing concept/draft/package lineage verified live.
- [ ] No duplicate concept or duplicate logical transport.
- [ ] No automatic line-ending conversion or raw-byte drift.
- [ ] Public raw outer-file set exactly matches expected.
- [ ] Every container member opens, has safe path, and matches bytes/hash.
- [ ] Public bytes independently pass privacy and reader-surface scans.
- [ ] Only then use `published` and `public_readback_pass`.

## Handoff protocol

- [ ] Complete objective and explicit exclusions.
- [ ] Absolute root and sole owner.
- [ ] Authority and comparison identities/admissibility.
- [ ] Exact historical and live generations.
- [ ] Complete page topology; closed/open range and first cursor.
- [ ] Three layer states and unfinished-state holds.
- [ ] Semantic/index/reference/formula/diagram states and residuals.
- [ ] Decision/reversal/workflow incident cursor.
- [ ] Build/render/privacy/rights/package/archive states separately typed.
- [ ] First safe action and prohibited actions.
- [ ] Hard stop at p.270.
- [ ] Self-excluding manifest, validation, and successor acceptance receipt.

## Current first safe action

The retrospective gate must pass first. Then replay the four frozen opening
draft identities and resume at physical PDF p.8 / logical iii / Georges
Maltsiniotis's editors' note. Do not build before the next substantive and
admitted checkpoint.
