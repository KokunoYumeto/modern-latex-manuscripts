#!/usr/bin/env python3
"""Read-only validation for the Verdier bilingual machine scaffold.

Normal invocation writes nothing::

    python validate_machine_scaffold.py

A deterministic SHA-256 manifest is generated only when explicitly requested::

    python validate_machine_scaffold.py --write-manifest
    python validate_machine_scaffold.py --write-manifest controls/MANIFEST_SHA256.csv

The manifest excludes its own output path.  This validator checks current
structure; it cannot prove historical append-only behavior without a prior
snapshot, so it verifies each JSONL ledger's append-only schema marker instead.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import re
import sys
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any, Iterable


CSV_SCHEMAS: dict[str, tuple[str, ...]] = {
    "SOURCE_AUTHORITY.csv": (
        "authority_id",
        "role",
        "path",
        "bytes",
        "pages",
        "sha256",
        "admission",
        "status",
    ),
    "PAGE_AND_UNIT_MAP.csv": (
        "pdf_page",
        "printed_page",
        "source_unit",
        "authorship_role",
        "editorial_responsibility",
        "statement_status",
        "fr_diplomatic_tex",
        "fr_corrected_tex",
        "en_tex",
        "review_status",
    ),
    "DIAGRAM_AND_FORMULA_REVIEW.csv": (
        "review_id",
        "target_id",
        "kind",
        "pdf_page",
        "printed_page",
        "authority_sha256",
        "inspection_detail",
        "result",
        "decision_id",
        "reviewed_utc",
    ),
    "semantics/BIBLIOGRAPHY_GRAPH.csv": (
        "bibliography_id",
        "citation_key",
        "author",
        "title",
        "publication_data",
        "target_id",
        "external_identifier",
        "review_status",
    ),
    "semantics/DECISION_BINDINGS.csv": (
        "binding_id",
        "decision_id",
        "target_id",
        "layer",
        "active_state",
        "review_status",
    ),
    "semantics/DIAGRAM_INDEX.csv": (
        "diagram_id",
        "parent_id",
        "visible_number",
        "printed_page",
        "pdf_page",
        "fr_tex_path",
        "en_tex_path",
        "native_tex_path",
        "review_status",
    ),
    "semantics/FORMULA_INDEX.csv": (
        "formula_id",
        "parent_id",
        "visible_number",
        "printed_page",
        "pdf_page",
        "fr_tex_path",
        "en_tex_path",
        "review_status",
    ),
    "semantics/NOTATION_INDEX.csv": (
        "notation_id",
        "visible_notation",
        "meaning",
        "first_target_id",
        "printed_page",
        "pdf_page",
        "review_status",
    ),
    "semantics/PERSON_INDEX.csv": (
        "person_id",
        "display_name",
        "target_id",
        "role",
        "printed_page",
        "pdf_page",
        "review_status",
    ),
    "semantics/REFERENCE_CANDIDATES.csv": (
        "candidate_id",
        "source_target_id",
        "visible_text",
        "reference_kind",
        "printed_page",
        "pdf_page",
        "tex_path",
        "locator",
        "context_hash",
        "classification",
        "status",
    ),
    "semantics/REFERENCE_EDGES.csv": (
        "edge_id",
        "candidate_id",
        "source_target_id",
        "target_id",
        "relation_type",
        "scope",
        "admission",
        "rationale",
        "review_status",
    ),
    "semantics/REFERENCE_RESIDUALS.csv": (
        "residual_id",
        "candidate_id",
        "reason",
        "scope",
        "external_work",
        "visible_locator",
        "rationale",
        "review_status",
    ),
    "semantics/SEMANTIC_TARGETS.csv": (
        "target_id",
        "corpus",
        "work",
        "volume",
        "kind",
        "parent_id",
        "source_number",
        "visible_title",
        "printed_page",
        "pdf_page",
        "coordinate_basis",
        "fr_tex_path",
        "fr_locator",
        "en_tex_path",
        "en_locator",
        "authority_sha256",
        "statement_status",
        "provenance",
        "review_status",
    ),
    "semantics/SOURCE_PAGE_MAP.csv": (
        "pdf_page",
        "printed_page",
        "page_label",
        "unit_ids",
        "authorship_role",
        "authority_sha256",
        "review_status",
    ),
    "semantics/STACKS_ALIGNMENT_CANDIDATES.csv": (
        "local_target_id",
        "stacks_tag_or_topic",
        "mapping_class",
        "evidence",
        "rationale",
        "review_status",
    ),
    "semantics/SUBJECT_INDEX.csv": (
        "subject_id",
        "subject_label",
        "target_id",
        "relation",
        "review_status",
    ),
    "semantics/TERM_INDEX.csv": (
        "term_id",
        "canonical_concept",
        "fr_diplomatic",
        "fr_corrected",
        "en",
        "first_target_id",
        "modern_equivalent",
        "review_status",
    ),
    "semantics/TEXTUAL_LAYER_PROJECTIONS.csv": (
        "projection_id",
        "target_id",
        "layer",
        "tex_path",
        "locator",
        "containing_tex_sha256",
        "projection_status",
        "review_status",
    ),
}

JSONL_SCHEMAS: dict[str, str] = {
    "NORMALIZATION_DECISIONS.jsonl": "verdier_normalization_decisions_v1",
    "REVERSALS_AND_GLOBAL_REPAIRS.jsonl": (
        "verdier_reversals_and_global_repairs_v1"
    ),
    "SOURCE_CORRECTIONS.jsonl": "verdier_source_corrections_v1",
    "TRANSCRIPTION_DECISIONS.jsonl": "verdier_transcription_decisions_v1",
    "TRANSLATION_DECISIONS.jsonl": "verdier_translation_decisions_v1",
}

REQUIRED_TEXT_FILES: tuple[str, ...] = (
    "CONTINUATION_HANDOFF.md",
    "INTAKE_AND_OWNERSHIP.md",
    "PROJECT_LOGBOOK.md",
    "STATUS.md",
)

# Primary keys are unique within their own ledgers.  Different entity types are
# deliberately not forced into one namespace: an index ID may validly mirror a
# semantic target ID.
PRIMARY_IDS: dict[str, str] = {
    "SOURCE_AUTHORITY.csv": "authority_id",
    "DIAGRAM_AND_FORMULA_REVIEW.csv": "review_id",
    "semantics/BIBLIOGRAPHY_GRAPH.csv": "bibliography_id",
    "semantics/DECISION_BINDINGS.csv": "binding_id",
    "semantics/DIAGRAM_INDEX.csv": "diagram_id",
    "semantics/FORMULA_INDEX.csv": "formula_id",
    "semantics/NOTATION_INDEX.csv": "notation_id",
    "semantics/PERSON_INDEX.csv": "person_id",
    "semantics/REFERENCE_CANDIDATES.csv": "candidate_id",
    "semantics/REFERENCE_EDGES.csv": "edge_id",
    "semantics/REFERENCE_RESIDUALS.csv": "residual_id",
    "semantics/SEMANTIC_TARGETS.csv": "target_id",
    "semantics/SUBJECT_INDEX.csv": "subject_id",
    "semantics/TERM_INDEX.csv": "term_id",
    "semantics/TEXTUAL_LAYER_PROJECTIONS.csv": "projection_id",
}

# Append-only rows remain in the files.  Only clearly inactive dispositions are
# removed from the active edge/residual partition.
INACTIVE_STATUS_PREFIXES: tuple[str, ...] = (
    "inactive",
    "superseded",
    "reversed",
    "withdrawn",
    "rejected",
    "void",
    "deprecated",
    "retired",
    "cancelled",
    "canceled",
    "not_admitted",
    "unadmitted",
)

STRUCTURAL_STATUS_FIELDS: tuple[str, ...] = ("mapping_class", "review_status")


CsvRows = list[tuple[int, dict[str, str]]]


def normalize_status(value: str) -> str:
    """Normalize a structural status without interpreting prose fields."""

    return re.sub(r"[^a-z0-9]+", "_", value.casefold()).strip("_")


def is_inactive(row: dict[str, str], fields: Iterable[str]) -> bool:
    for field in fields:
        normalized = normalize_status(row.get(field, ""))
        if any(
            normalized == prefix or normalized.startswith(prefix + "_")
            for prefix in INACTIVE_STATUS_PREFIXES
        ):
            return True
    return False


def claims_official_stacks_status(value: str) -> bool:
    """Return true only for a positive *structural* official-status claim.

    Prose, evidence, rationale, and ``stacks_tag_or_topic`` are intentionally
    outside this check.  Verified is allowed; it records evidence review and
    does not impersonate an official Stacks designation.
    """

    normalized = normalize_status(value)
    if not normalized:
        return False

    tokens = normalized.split("_")
    for index, token in enumerate(tokens):
        if token not in {"official", "authoritative"}:
            continue
        if index > 0 and tokens[index - 1] in {"not", "non"}:
            continue
        return True

    return (
        "canonical_stacks" in normalized
        or "stacks_canonical" in normalized
        or "canonical_tag" in normalized
    )


def read_csv_file(
    root: Path,
    relative: str,
    expected_header: tuple[str, ...],
    errors: list[str],
) -> CsvRows:
    path = root / relative
    if not path.is_file():
        errors.append(f"missing required file: {relative}")
        return []

    rows: CsvRows = []
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.DictReader(handle)
            actual_header = tuple(reader.fieldnames or ())
            if actual_header != expected_header:
                errors.append(
                    f"{relative}: header mismatch: expected "
                    f"{list(expected_header)!r}, got {list(actual_header)!r}"
                )

            for line_number, row in enumerate(reader, start=2):
                if None in row:
                    errors.append(
                        f"{relative}:{line_number}: extra CSV fields: {row[None]!r}"
                    )
                missing_cells = [
                    field for field in expected_header if row.get(field) is None
                ]
                if missing_cells:
                    errors.append(
                        f"{relative}:{line_number}: missing CSV cells for "
                        f"{missing_cells!r}"
                    )
                clean_row = {
                    field: (row.get(field) or "").strip()
                    for field in expected_header
                }
                rows.append((line_number, clean_row))
    except (OSError, UnicodeError, csv.Error) as exc:
        errors.append(f"{relative}: cannot read valid UTF-8 CSV: {exc}")
    return rows


def read_jsonl_file(
    root: Path,
    relative: str,
    expected_schema: str,
    errors: list[str],
) -> list[tuple[int, dict[str, Any]]]:
    path = root / relative
    if not path.is_file():
        errors.append(f"missing required file: {relative}")
        return []

    records: list[tuple[int, dict[str, Any]]] = []
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeError) as exc:
        errors.append(f"{relative}: cannot read valid UTF-8 JSONL: {exc}")
        return records

    lines = text.splitlines()
    # The seed ledgers use one trailing whitespace-only padding line.  It is
    # harmless at EOF; an empty record between JSON values remains an error.
    while lines and not lines[-1].strip():
        lines.pop()

    for line_number, line in enumerate(lines, start=1):
        if not line.strip():
            errors.append(f"{relative}:{line_number}: blank JSONL record")
            continue
        try:
            value = json.loads(line)
        except json.JSONDecodeError as exc:
            errors.append(
                f"{relative}:{line_number}:{exc.colno}: invalid JSON: {exc.msg}"
            )
            continue
        if not isinstance(value, dict):
            errors.append(f"{relative}:{line_number}: JSONL record is not an object")
            continue
        records.append((line_number, value))

    if not records:
        errors.append(f"{relative}: missing schema record")
        return records

    schema_line, schema_record = records[0]
    expected_marker = {
        "record_type": "schema",
        "schema": expected_schema,
        "append_only": True,
    }
    for field, expected in expected_marker.items():
        if schema_record.get(field) != expected:
            errors.append(
                f"{relative}:{schema_line}: schema field {field!r} must be "
                f"{expected!r}, got {schema_record.get(field)!r}"
            )

    for line_number, record in records[1:]:
        if record.get("record_type") == "schema":
            errors.append(
                f"{relative}:{line_number}: duplicate schema record after line 1"
            )

    return records


def check_primary_ids(
    rows_by_file: dict[str, CsvRows], errors: list[str]
) -> None:
    for relative, id_field in PRIMARY_IDS.items():
        seen: dict[str, int] = {}
        for line_number, row in rows_by_file.get(relative, []):
            identifier = row.get(id_field, "")
            if not identifier:
                errors.append(
                    f"{relative}:{line_number}: blank required ID {id_field!r}"
                )
                continue
            if identifier in seen:
                errors.append(
                    f"{relative}:{line_number}: duplicate {id_field} "
                    f"{identifier!r}; first seen on line {seen[identifier]}"
                )
            else:
                seen[identifier] = line_number


def check_decision_bindings(
    rows_by_file: dict[str, CsvRows],
    jsonl_by_file: dict[str, list[tuple[int, dict[str, Any]]]],
    errors: list[str],
) -> dict[str, int]:
    decisions: dict[str, tuple[str, int]] = {}
    for relative, records in sorted(jsonl_by_file.items()):
        for line_number, record in records[1:]:
            decision_id = record.get("decision_id")
            if not isinstance(decision_id, str) or not decision_id.strip():
                errors.append(
                    f"{relative}:{line_number}: data record lacks a nonblank "
                    "decision_id"
                )
                continue
            decision_id = decision_id.strip()
            if decision_id in decisions:
                earlier_file, earlier_line = decisions[decision_id]
                errors.append(
                    f"{relative}:{line_number}: duplicate cross-ledger decision_id "
                    f"{decision_id!r}; first seen at {earlier_file}:{earlier_line}"
                )
            else:
                decisions[decision_id] = (relative, line_number)

    bindings = rows_by_file.get("semantics/DECISION_BINDINGS.csv", [])
    bound_ids: set[str] = set()
    for line_number, row in bindings:
        decision_id = row.get("decision_id", "")
        if not decision_id:
            errors.append(
                "semantics/DECISION_BINDINGS.csv:"
                f"{line_number}: blank required decision_id"
            )
            continue
        if decision_id not in decisions:
            errors.append(
                "semantics/DECISION_BINDINGS.csv:"
                f"{line_number}: decision_id {decision_id!r} does not resolve "
                "to an append-only JSONL decision"
            )
        bound_ids.add(decision_id)

    unbound = set(decisions) - bound_ids
    if unbound:
        errors.append(
            "decision bindings: active decision records without any semantic "
            "binding: "
            + ", ".join(repr(item) for item in sorted(unbound))
        )

    return {
        "decision_ids": len(decisions),
        "binding_rows": len(bindings),
        "unbound_decisions": len(unbound),
    }


def check_target_field(
    rows_by_file: dict[str, CsvRows],
    relative: str,
    field: str,
    target_ids: set[str],
    errors: list[str],
    *,
    required: bool = False,
    allowed_ids: set[str] | None = None,
) -> None:
    valid_ids = target_ids if allowed_ids is None else allowed_ids
    for line_number, row in rows_by_file.get(relative, []):
        identifier = row.get(field, "")
        if not identifier:
            if required:
                errors.append(
                    f"{relative}:{line_number}: blank required target reference "
                    f"{field!r}"
                )
            continue
        if identifier not in valid_ids:
            errors.append(
                f"{relative}:{line_number}: {field} {identifier!r} does not "
                "resolve to an existing semantic target"
            )


def split_unit_ids(value: str) -> list[str]:
    """Accept a JSON array or the scaffold's compact semicolon/pipe list."""

    stripped = value.strip()
    if not stripped:
        return []
    if stripped.startswith("["):
        try:
            parsed = json.loads(stripped)
        except json.JSONDecodeError:
            return [stripped]
        if isinstance(parsed, list) and all(isinstance(item, str) for item in parsed):
            return [item.strip() for item in parsed if item.strip()]
        return [stripped]
    return [item.strip() for item in re.split(r"[;|]", stripped) if item.strip()]


def check_target_references(
    rows_by_file: dict[str, CsvRows], errors: list[str]
) -> set[str]:
    target_rows = rows_by_file.get("semantics/SEMANTIC_TARGETS.csv", [])
    target_ids = {row["target_id"] for _, row in target_rows if row["target_id"]}

    reference_fields: tuple[tuple[str, str, bool], ...] = (
        ("PAGE_AND_UNIT_MAP.csv", "source_unit", False),
        ("semantics/BIBLIOGRAPHY_GRAPH.csv", "target_id", False),
        ("semantics/DECISION_BINDINGS.csv", "target_id", True),
        ("semantics/DIAGRAM_INDEX.csv", "parent_id", True),
        ("semantics/FORMULA_INDEX.csv", "parent_id", True),
        ("semantics/NOTATION_INDEX.csv", "first_target_id", True),
        ("semantics/PERSON_INDEX.csv", "target_id", False),
        ("semantics/REFERENCE_CANDIDATES.csv", "source_target_id", True),
        ("semantics/REFERENCE_EDGES.csv", "source_target_id", True),
        ("semantics/REFERENCE_EDGES.csv", "target_id", True),
        ("semantics/SEMANTIC_TARGETS.csv", "parent_id", False),
        ("semantics/STACKS_ALIGNMENT_CANDIDATES.csv", "local_target_id", True),
        ("semantics/SUBJECT_INDEX.csv", "target_id", True),
        ("semantics/TERM_INDEX.csv", "first_target_id", True),
        ("semantics/TEXTUAL_LAYER_PROJECTIONS.csv", "target_id", True),
    )
    for relative, field, required in reference_fields:
        check_target_field(
            rows_by_file,
            relative,
            field,
            target_ids,
            errors,
            required=required,
        )

    diagram_ids = {
        row["diagram_id"]
        for _, row in rows_by_file.get("semantics/DIAGRAM_INDEX.csv", [])
        if row["diagram_id"]
    }
    formula_ids = {
        row["formula_id"]
        for _, row in rows_by_file.get("semantics/FORMULA_INDEX.csv", [])
        if row["formula_id"]
    }
    check_target_field(
        rows_by_file,
        "DIAGRAM_AND_FORMULA_REVIEW.csv",
        "target_id",
        target_ids,
        errors,
        required=True,
        allowed_ids=target_ids | diagram_ids | formula_ids,
    )

    for line_number, row in rows_by_file.get("semantics/SOURCE_PAGE_MAP.csv", []):
        for unit_id in split_unit_ids(row.get("unit_ids", "")):
            if unit_id not in target_ids:
                errors.append(
                    "semantics/SOURCE_PAGE_MAP.csv:"
                    f"{line_number}: unit_id {unit_id!r} does not resolve to "
                    "an existing semantic target"
                )

    return target_ids


def check_textual_layer_projections(
    root: Path, rows_by_file: dict[str, CsvRows], errors: list[str]
) -> dict[str, Any]:
    relative = "semantics/TEXTUAL_LAYER_PROJECTIONS.csv"
    rows = rows_by_file.get(relative, [])
    required_layers = {"fr_diplomatic", "fr_corrected", "en"}
    by_target: dict[str, list[tuple[int, dict[str, str]]]] = {}

    for line_number, row in rows:
        target_id = row.get("target_id", "")
        if target_id:
            by_target.setdefault(target_id, []).append((line_number, row))

        layer = row.get("layer", "")
        if layer not in required_layers:
            errors.append(
                f"{relative}:{line_number}: layer {layer!r} is not one of "
                + ", ".join(repr(item) for item in sorted(required_layers))
            )

        tex_path = row.get("tex_path", "")
        locator = row.get("locator", "")
        expected_hash = row.get("containing_tex_sha256", "").upper()
        if not tex_path:
            errors.append(f"{relative}:{line_number}: blank required tex_path")
            continue
        if not locator:
            errors.append(f"{relative}:{line_number}: blank required locator")
        if not re.fullmatch(r"[0-9A-F]{64}", expected_hash):
            errors.append(
                f"{relative}:{line_number}: containing_tex_sha256 is not "
                "an uppercase 64-hex SHA-256"
            )

        candidate = (root / tex_path).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            errors.append(
                f"{relative}:{line_number}: tex_path escapes validated root: "
                f"{tex_path!r}"
            )
            continue
        if not candidate.is_file():
            errors.append(
                f"{relative}:{line_number}: tex_path is not a file: {tex_path!r}"
            )
            continue
        if re.fullmatch(r"[0-9A-F]{64}", expected_hash):
            actual_hash = sha256_file(candidate)
            if actual_hash != expected_hash:
                errors.append(
                    f"{relative}:{line_number}: hash mismatch for {tex_path!r}: "
                    f"expected {expected_hash}, got {actual_hash}"
                )

    for target_id, target_rows in sorted(by_target.items()):
        counts = Counter(row["layer"] for _, row in target_rows if row["layer"])
        duplicates = {layer: count for layer, count in counts.items() if count > 1}
        missing = required_layers - set(counts)
        extras = set(counts) - required_layers
        if duplicates:
            errors.append(
                f"{relative}: target {target_id!r} has duplicate layers: "
                + ", ".join(
                    f"{layer}={count}" for layer, count in sorted(duplicates.items())
                )
            )
        if missing:
            errors.append(
                f"{relative}: target {target_id!r} is missing layers: "
                + ", ".join(sorted(missing))
            )
        if extras:
            errors.append(
                f"{relative}: target {target_id!r} has unexpected layers: "
                + ", ".join(sorted(extras))
            )

    target_rows = rows_by_file.get("semantics/SEMANTIC_TARGETS.csv", [])
    projected_targets = {
        row["target_id"]
        for _, row in target_rows
        if row["target_id"] and (row.get("fr_tex_path") or row.get("en_tex_path"))
    }
    missing_targets = projected_targets - set(by_target)
    extra_targets = set(by_target) - {
        row["target_id"] for _, row in target_rows if row["target_id"]
    }
    if missing_targets:
        errors.append(
            f"{relative}: semantic targets with textual paths lack a complete "
            "projection set: "
            + ", ".join(repr(item) for item in sorted(missing_targets))
        )
    if extra_targets:
        errors.append(
            f"{relative}: projections reference absent targets: "
            + ", ".join(repr(item) for item in sorted(extra_targets))
        )

    return {
        "rows": len(rows),
        "projected_targets": len(by_target),
        "required_layers_per_target": sorted(required_layers),
        "semantic_targets_missing_projection_set": len(missing_targets),
    }


def check_candidate_partition(
    rows_by_file: dict[str, CsvRows], errors: list[str]
) -> dict[str, Any]:
    candidate_rows = rows_by_file.get("semantics/REFERENCE_CANDIDATES.csv", [])
    edge_rows = rows_by_file.get("semantics/REFERENCE_EDGES.csv", [])
    residual_rows = rows_by_file.get("semantics/REFERENCE_RESIDUALS.csv", [])

    candidate_ids = {
        row["candidate_id"] for _, row in candidate_rows if row["candidate_id"]
    }
    candidate_sources = {
        row["candidate_id"]: row["source_target_id"]
        for _, row in candidate_rows
        if row["candidate_id"]
    }

    active_edges = [
        (line, row)
        for line, row in edge_rows
        if not is_inactive(row, ("admission", "review_status"))
    ]
    active_residuals = [
        (line, row)
        for line, row in residual_rows
        if not is_inactive(row, ("review_status",))
    ]

    for relative, rows in (
        ("semantics/REFERENCE_EDGES.csv", edge_rows),
        ("semantics/REFERENCE_RESIDUALS.csv", residual_rows),
    ):
        for line_number, row in rows:
            candidate_id = row.get("candidate_id", "")
            if not candidate_id:
                errors.append(
                    f"{relative}:{line_number}: blank required candidate_id"
                )
            elif candidate_id not in candidate_ids:
                errors.append(
                    f"{relative}:{line_number}: candidate_id {candidate_id!r} "
                    "does not resolve to REFERENCE_CANDIDATES.csv"
                )

    for line_number, edge in edge_rows:
        candidate_id = edge.get("candidate_id", "")
        expected_source = candidate_sources.get(candidate_id, "")
        edge_source = edge.get("source_target_id", "")
        if expected_source and edge_source and edge_source != expected_source:
            errors.append(
                "semantics/REFERENCE_EDGES.csv:"
                f"{line_number}: source_target_id {edge_source!r} disagrees "
                f"with candidate {candidate_id!r} source {expected_source!r}"
            )

    edge_counts = Counter(
        row["candidate_id"] for _, row in active_edges if row["candidate_id"]
    )
    residual_counts = Counter(
        row["candidate_id"] for _, row in active_residuals if row["candidate_id"]
    )
    edge_ids = set(edge_counts)
    residual_ids = set(residual_counts)
    checked = bool(candidate_rows or edge_rows or residual_rows)

    if checked:
        for candidate_id, count in sorted(edge_counts.items()):
            if count > 1:
                errors.append(
                    f"candidate partition: {candidate_id!r} has {count} active edges"
                )
        for candidate_id, count in sorted(residual_counts.items()):
            if count > 1:
                errors.append(
                    f"candidate partition: {candidate_id!r} has {count} active residuals"
                )

        overlap = edge_ids & residual_ids
        missing = candidate_ids - (edge_ids | residual_ids)
        extra = (edge_ids | residual_ids) - candidate_ids
        if overlap:
            errors.append(
                "candidate partition: active edge/residual overlap: "
                + ", ".join(repr(item) for item in sorted(overlap))
            )
        if missing:
            errors.append(
                "candidate partition: candidates without one active edge or "
                "residual: "
                + ", ".join(repr(item) for item in sorted(missing))
            )
        if extra:
            errors.append(
                "candidate partition: active disposition IDs absent from "
                "candidate universe: "
                + ", ".join(repr(item) for item in sorted(extra))
            )

    return {
        "checked": checked,
        "candidates": len(candidate_ids),
        "active_edges": len(active_edges),
        "active_residuals": len(active_residuals),
        "edge_residual_overlap": len(edge_ids & residual_ids),
        "missing_dispositions": len(candidate_ids - (edge_ids | residual_ids)),
        "extra_dispositions": len((edge_ids | residual_ids) - candidate_ids),
    }


def check_stacks_structural_statuses(
    rows_by_file: dict[str, CsvRows], errors: list[str]
) -> int:
    relative = "semantics/STACKS_ALIGNMENT_CANDIDATES.csv"
    claims = 0
    for line_number, row in rows_by_file.get(relative, []):
        for field in STRUCTURAL_STATUS_FIELDS:
            value = row.get(field, "")
            if claims_official_stacks_status(value):
                claims += 1
                errors.append(
                    f"{relative}:{line_number}: structural field {field!r} "
                    f"claims an official/canonical Stacks status: {value!r}"
                )
    return claims


def validate(root: Path) -> dict[str, Any]:
    errors: list[str] = []

    for relative in REQUIRED_TEXT_FILES:
        if not (root / relative).is_file():
            errors.append(f"missing required file: {relative}")

    rows_by_file = {
        relative: read_csv_file(root, relative, header, errors)
        for relative, header in CSV_SCHEMAS.items()
    }
    jsonl_by_file = {
        relative: read_jsonl_file(root, relative, schema, errors)
        for relative, schema in JSONL_SCHEMAS.items()
    }

    check_primary_ids(rows_by_file, errors)
    decision_bindings = check_decision_bindings(
        rows_by_file, jsonl_by_file, errors
    )
    target_ids = check_target_references(rows_by_file, errors)
    textual_projections = check_textual_layer_projections(root, rows_by_file, errors)
    partition = check_candidate_partition(rows_by_file, errors)
    official_claims = check_stacks_structural_statuses(rows_by_file, errors)

    csv_row_counts = {
        relative: len(rows) for relative, rows in sorted(rows_by_file.items())
    }
    jsonl_record_counts = {
        relative: max(0, len(records) - 1)
        for relative, records in sorted(jsonl_by_file.items())
    }
    return {
        "schema": "verdier_machine_scaffold_validation_v1",
        "status": "PASS" if not errors else "FAIL",
        "errors": errors,
        "counts": {
            "required_files": (
                len(REQUIRED_TEXT_FILES) + len(CSV_SCHEMAS) + len(JSONL_SCHEMAS)
            ),
            "semantic_targets": len(target_ids),
            "decision_bindings": decision_bindings,
            "textual_layer_projections": textual_projections,
            "csv_rows": csv_row_counts,
            "jsonl_data_records": jsonl_record_counts,
            "candidate_partition": partition,
            "official_stacks_structural_claims": official_claims,
        },
    }


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest().upper()


def path_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
    except ValueError:
        return False
    return True


def write_manifest(root: Path, requested_path: str) -> tuple[Path, int]:
    output = Path(requested_path)
    if not output.is_absolute():
        output = root / output
    output = output.resolve()
    if not path_within(output, root):
        raise ValueError("manifest output must remain inside the validated root")
    if output.exists() and output.is_dir():
        raise ValueError("manifest output path is a directory")

    output_key = os.path.normcase(os.path.abspath(output))
    rows: list[tuple[str, int, str]] = []
    for path in sorted(root.rglob("*"), key=lambda item: item.as_posix().casefold()):
        if path.is_symlink() or not path.is_file():
            continue
        if os.path.normcase(os.path.abspath(path)) == output_key:
            continue
        rows.append(
            (
                path.relative_to(root).as_posix(),
                path.stat().st_size,
                sha256_file(path),
            )
        )

    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer, lineterminator="\n")
    writer.writerow(("relative_path", "bytes", "sha256"))
    writer.writerows(rows)

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            newline="",
            dir=output.parent,
            prefix=f".{output.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            handle.write(buffer.getvalue())
            temporary_name = handle.name
        os.replace(temporary_name, output)
        temporary_name = None
    finally:
        if temporary_name is not None:
            Path(temporary_name).unlink(missing_ok=True)

    return output, len(rows)


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent,
        help="scaffold root to validate (default: directory containing script)",
    )
    parser.add_argument(
        "--write-manifest",
        nargs="?",
        const="MANIFEST_SHA256.csv",
        metavar="RELATIVE_PATH",
        help=(
            "explicitly write a self-excluding SHA-256 manifest; default path "
            "when the flag has no value is MANIFEST_SHA256.csv"
        ),
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(sys.argv[1:] if argv is None else argv)
    root = args.root.resolve()
    if not root.is_dir():
        result = {
            "schema": "verdier_machine_scaffold_validation_v1",
            "status": "FAIL",
            "errors": [f"validation root is not a directory: {root}"],
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 1

    result = validate(root)
    if args.write_manifest is not None:
        try:
            manifest_path, entry_count = write_manifest(root, args.write_manifest)
        except (OSError, ValueError) as exc:
            result["errors"].append(f"manifest generation failed: {exc}")
            result["status"] = "FAIL"
        else:
            result["manifest"] = {
                "path": manifest_path.relative_to(root).as_posix(),
                "entries": entry_count,
                "self_excluded": True,
            }

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
