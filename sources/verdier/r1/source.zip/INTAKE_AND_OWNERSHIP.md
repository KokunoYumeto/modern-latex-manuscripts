# Intake and ownership record

Append-only private production control. Created 2026-08-04T01:24:00Z before
any substantive transcription, translation, build, rendering, or semantic
admission in this root.

## Durable objective

Produce a complete canonical bilingual scholarly edition of Jean-Louis
Verdier's *Des catégories dérivées des catégories abéliennes* as published in
Astérisque 239 (1996), edited by Georges Maltsiniotis. Deliver diplomatic
French, separately corrected French, source-aligned English, complete local
readers, semantic references/indexes, and a pre-Stacks graph.

The edition must preserve, rather than conceal, the bibliographic fact that
Verdier left the thesis body unfinished. Do not complete an unfinished proof,
normalize an incomplete passage into apparent completion, or merge the
author's text with later editor material. Identify author, editor, preface,
notes, and later apparatus accurately at the unit level.

## Handoff replay

- Complete lane-control packet read through EOF, beginning with
  `00_START_HERE.md` and the Verdier corpus README.
- `HANDOFF_SHA256SUMS.csv`: 1,184 bytes,
  SHA-256 `F50A8D9171E44448083A42E6F0A668E49DD60EFD7EDE8BA6C77BDD6A75191E45`.
- `HANDOFF_VALIDATION.json`: 465 bytes,
  SHA-256 `B57817D9CA29CD01011603889CFFC2089EFE0F387774B2DFA386290A7A2DBA0D`.
- Read-only replay at 2026-08-04T01:22:37.8199694Z: 11/11 payload rows
  match, 40,193 manifest payload bytes, stored status `PASS`, stored
  `errors=[]`, replay errors `[]`.
- All seven exact precedents were read through EOF and rehashed; every byte
  count and SHA-256 matched `04_PRECEDENT_READING_LIST.csv`.

## Authority replay

- Controlling NUMDAM PDF: 19,188,423 bytes, 270 physical pages,
  SHA-256 `6214C252BACEBA5584E3C4AEB564C129851941C1A9250BABAB45B79A3939B0AE`,
  exact match.
- Comparison DJVU: 1,330,094 bytes,
  SHA-256 `7D20F3E0F62E58E8CE27DB038BCAD6D8821CDEA7D0E49D27EEBB8EC1225F7F63`,
  exact match.
- Comparison PDF: 8,705,514 bytes,
  SHA-256 `9F93C0BB3131F720B9C736E7C2E7834E76500A62B3C68155FCFE62301C5DA4EB`,
  exact match.

NUMDAM/SMF decides. The comparison witnesses may be consulted only to clarify
page-image damage after an explicit page-level comparison.

## Exact no-overlap result

The live Codex task inventory was inspected before this root was created.

- This task, `019fca5a-c80e-7890-a46b-4948ff443e6d`, exclusively owns the
  complete Astérisque 239 Verdier publication.
- Peer task `019fca5a-bcf8-7813-93dd-1adff100c52d` owns FGA only.
- Peer task `019fca5a-c29e-7330-acdc-c93f4a3dc9fb` owns Tôhoku only.
- Peer task `019fca5a-ce42-7ad1-baed-0e0564fe5ff7` owns Illusie I-II only.
- Parent production task `019f711e-cac3-7a10-a0e6-dc0131799c3a` retains
  SGA 1-7.2 plus FAC/GAGA and explicitly does not overlap this allocation.
- Separate active EGA and Deligne tasks remain outside this corpus.
- No other inspected live task claimed Verdier or Astérisque 239.
- A bounded name check of the working-translations parent found no existing
  Verdier or derived-categories root. The prescribed target did not exist at
  2026-08-04T01:24:00.7317608Z.

Therefore the admitted range is exactly: first source-bearing page of the
complete issue through the end of Astérisque 239. It excludes every other
Verdier work and all of SGA 4 and SGA 4 1/2.

## Intake holds and fail-closed points

- The exact opening physical/printed-page cursor and issue topology await
  direct visual inspection of the controlling PDF.
- No source unit is yet admitted; extraction or OCR text alone cannot admit
  content.
- The unfinished/truncated state of the thesis body must be recorded, never
  repaired by later literature.
- Public redistribution of French remains rights-gated. Archival French TeX
  and local readers remain required.
- No OCR will be generated.

