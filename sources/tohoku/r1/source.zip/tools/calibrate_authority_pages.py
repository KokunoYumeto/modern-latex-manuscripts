#!/usr/bin/env python3
"""Calibrate page-image matches against an adjacent-page negative control."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import fitz

from compare_authority_pages import compare_images, largest_page_raster, sha256


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("local_pdf", type=Path)
    parser.add_argument("part_i_pdf", type=Path)
    parser.add_argument("part_ii_pdf", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()

    local = fitz.open(args.local_pdf)
    part_i = fitz.open(args.part_i_pdf)
    part_ii = fitz.open(args.part_ii_pdf)
    pairings = [
        (local_page, "part_I", local_page, part_i)
        for local_page in range(65)
    ] + [
        (local_page, "part_II", local_page - 66, part_ii)
        for local_page in range(66, 103)
    ]

    rows: list[dict[str, object]] = []
    for local_page, part, official_page, official_document in pairings:
        local_image = largest_page_raster(local, local_page)
        expected = compare_images(
            local_image, largest_page_raster(official_document, official_page)
        )
        control_page = official_page + 1 if official_page + 1 < len(official_document) else official_page - 1
        control = compare_images(
            local_image, largest_page_raster(official_document, control_page)
        )
        expected_inliers = int(expected.get("homography_inliers", 0))
        control_inliers = int(control.get("homography_inliers", 0))
        margin = expected_inliers / max(1, control_inliers)
        status = (
            "MATCH"
            if expected_inliers >= 100
            and float(expected.get("inlier_ratio", 0.0)) >= 0.30
            and margin >= 5.0
            else "HOLD"
        )
        rows.append(
            {
                "printed_page": local_page + 119,
                "local_pdf_page": local_page + 1,
                "official_part": part,
                "official_pdf_page": official_page + 1,
                "negative_control_official_pdf_page": control_page + 1,
                "status": status,
                "expected": expected,
                "negative_control": control,
                "homography_inlier_margin": round(margin, 6),
            }
        )

    output = {
        "schema": "tohoku_authority_image_comparison_v2",
        "method": (
            "expected largest-raster SIFT/RANSAC correspondence calibrated "
            "against an adjacent-page negative control; no OCR"
        ),
        "inputs": {
            "local": {
                "bytes": args.local_pdf.stat().st_size,
                "sha256": sha256(args.local_pdf),
                "pages": len(local),
            },
            "jstage_part_I": {
                "bytes": args.part_i_pdf.stat().st_size,
                "sha256": sha256(args.part_i_pdf),
                "pages": len(part_i),
            },
            "jstage_part_II": {
                "bytes": args.part_ii_pdf.stat().st_size,
                "sha256": sha256(args.part_ii_pdf),
                "pages": len(part_ii),
            },
        },
        "mapping": {
            "part_I": "local 1--65 / printed 119--183 / official I 1--65",
            "unpaired": "local 66 / blank interleaf between printed 183 and 185",
            "part_II": "local 67--103 / printed 185--221 / official II 1--37",
        },
        "summary": {
            "paired_pages": len(rows),
            "matches": sum(row["status"] == "MATCH" for row in rows),
            "holds": sum(row["status"] != "MATCH" for row in rows),
            "unpaired_local_pages": [66],
        },
        "pages": rows,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    if args.output_json.exists():
        raise FileExistsError(f"no-overwrite output already exists: {args.output_json}")
    args.output_json.write_text(
        json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(output["summary"], sort_keys=True))


if __name__ == "__main__":
    main()
