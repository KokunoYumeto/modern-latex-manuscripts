#!/usr/bin/env python3
"""Compare the local 103-page witness with the two frozen J-STAGE PDFs.

This is an image-identity aid, not OCR and not a textual certification.  It
matches local-feature geometry between the largest source raster on each
paired page and records a conservative per-page result for lead review.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path

import cv2
import fitz
import numpy as np
from PIL import Image


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def largest_page_raster(document: fitz.Document, page_index: int) -> np.ndarray:
    page = document[page_index]
    images = page.get_images(full=True)
    if images:
        xref = max(images, key=lambda item: item[2] * item[3])[0]
        payload = document.extract_image(xref)["image"]
        with Image.open(io.BytesIO(payload)) as image:
            grayscale = np.asarray(image.convert("L"))
    else:
        pixmap = page.get_pixmap(dpi=300, colorspace=fitz.csGRAY, alpha=False)
        grayscale = np.frombuffer(pixmap.samples, dtype=np.uint8).reshape(
            pixmap.height, pixmap.width
        )
    return grayscale


def downsample(image: np.ndarray, max_dimension: int = 1800) -> np.ndarray:
    height, width = image.shape
    scale = min(1.0, max_dimension / max(height, width))
    if scale == 1.0:
        return image
    return cv2.resize(
        image,
        (max(1, round(width * scale)), max(1, round(height * scale))),
        interpolation=cv2.INTER_AREA,
    )


def compare_images(local: np.ndarray, official: np.ndarray) -> dict[str, object]:
    local_small = downsample(local)
    official_small = downsample(official)
    detector = cv2.SIFT_create(nfeatures=2400, contrastThreshold=0.02)
    key_local, desc_local = detector.detectAndCompute(local_small, None)
    key_official, desc_official = detector.detectAndCompute(official_small, None)
    if desc_local is None or desc_official is None:
        return {
            "status": "HOLD",
            "reason": "insufficient descriptors",
            "local_keypoints": len(key_local),
            "official_keypoints": len(key_official),
        }
    matcher = cv2.BFMatcher(cv2.NORM_L2)
    pairs = matcher.knnMatch(desc_local, desc_official, k=2)
    good = [first for first, second in pairs if first.distance < 0.72 * second.distance]
    if len(good) < 12:
        return {
            "status": "HOLD",
            "reason": "too few ratio-test matches",
            "local_keypoints": len(key_local),
            "official_keypoints": len(key_official),
            "good_matches": len(good),
        }
    source_points = np.float32([key_local[m.queryIdx].pt for m in good]).reshape(-1, 1, 2)
    target_points = np.float32([key_official[m.trainIdx].pt for m in good]).reshape(-1, 1, 2)
    _, mask = cv2.findHomography(source_points, target_points, cv2.RANSAC, 4.0)
    inliers = int(mask.sum()) if mask is not None else 0
    inlier_ratio = inliers / len(good)
    status = "MATCH" if inliers >= 40 and inlier_ratio >= 0.55 else "HOLD"
    return {
        "status": status,
        "local_keypoints": len(key_local),
        "official_keypoints": len(key_official),
        "good_matches": len(good),
        "homography_inliers": inliers,
        "inlier_ratio": round(inlier_ratio, 6),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("local_pdf", type=Path)
    parser.add_argument("part_i_pdf", type=Path)
    parser.add_argument("part_ii_pdf", type=Path)
    parser.add_argument("output_json", type=Path)
    args = parser.parse_args()

    local = fitz.open(args.local_pdf)
    part_i = fitz.open(args.part_i_pdf)
    part_ii = fitz.open(args.part_ii_pdf)
    if (len(local), len(part_i), len(part_ii)) != (103, 65, 37):
        raise RuntimeError(
            f"unexpected page envelope: local={len(local)}, "
            f"part_i={len(part_i)}, part_ii={len(part_ii)}"
        )

    rows: list[dict[str, object]] = []
    pairings = [
        (local_page, "part_I", local_page, part_i)
        for local_page in range(65)
    ] + [
        (local_page, "part_II", local_page - 66, part_ii)
        for local_page in range(66, 103)
    ]
    for local_page, official_part, official_page, official_doc in pairings:
        comparison = compare_images(
            largest_page_raster(local, local_page),
            largest_page_raster(official_doc, official_page),
        )
        rows.append(
            {
                "printed_page": local_page + 119,
                "local_pdf_page": local_page + 1,
                "official_part": official_part,
                "official_pdf_page": official_page + 1,
                **comparison,
            }
        )

    result = {
        "schema": "tohoku_authority_image_comparison_v1",
        "method": (
            "largest embedded page raster; SIFT ratio-test feature matching; "
            "RANSAC homography; no OCR"
        ),
        "inputs": {
            "local": {
                "bytes": args.local_pdf.stat().st_size,
                "sha256": sha256(args.local_pdf),
                "pages": len(local),
            },
            "jstage_part_I": {
                "bytes": args.part_i_pdf.stat().st_size,
                "sha256": sha256(args.part_i_pdf),
                "pages": len(part_i),
            },
            "jstage_part_II": {
                "bytes": args.part_ii_pdf.stat().st_size,
                "sha256": sha256(args.part_ii_pdf),
                "pages": len(part_ii),
            },
        },
        "mapping": {
            "part_I": "local 1--65 / printed 119--183 / official I 1--65",
            "unpaired": "local 66 / printed 184",
            "part_II": "local 67--103 / printed 185--221 / official II 1--37",
        },
        "summary": {
            "paired_pages": len(rows),
            "matches": sum(row["status"] == "MATCH" for row in rows),
            "holds": sum(row["status"] != "MATCH" for row in rows),
            "unpaired_local_pages": [66],
        },
        "pages": rows,
    }
    args.output_json.parent.mkdir(parents=True, exist_ok=True)
    if args.output_json.exists():
        raise FileExistsError(f"no-overwrite output already exists: {args.output_json}")
    args.output_json.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result["summary"], sort_keys=True))


if __name__ == "__main__":
    main()
