param(
    [Parameter(Mandatory = $true)]
    [ValidatePattern('^[A-Za-z0-9_-]+$')]
    [string]$Gate
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$gateRoot = Join-Path $projectRoot "build\$Gate"
$outputRoot = Join-Path $projectRoot 'output\pdf'

if (Test-Path -LiteralPath $gateRoot) {
    throw "No-overwrite build gate already exists: $gateRoot"
}

$pdfLatex = 'C:\Users\Floris\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'
if (-not (Test-Path -LiteralPath $pdfLatex)) {
    throw "pdflatex not found at configured path: $pdfLatex"
}

$readers = @(
    'tohoku_part_I_diplomatic_fr',
    'tohoku_part_I_corrected_fr',
    'tohoku_part_I_english',
    'tohoku_part_I_bilingual'
)

New-Item -ItemType Directory -Path $gateRoot | Out-Null
New-Item -ItemType Directory -Path $outputRoot -Force | Out-Null

Push-Location $projectRoot
try {
    foreach ($reader in $readers) {
        $readerBuild = Join-Path $gateRoot $reader
        New-Item -ItemType Directory -Path $readerBuild | Out-Null
        $source = "tex/readers/$reader.tex"
        $stdoutLog = Join-Path $readerBuild 'command-output.log'
        $arguments = @(
            '-interaction=nonstopmode',
            '-halt-on-error',
            '-file-line-error',
            "-output-directory=$readerBuild",
            $source
        )
        for ($pass = 1; $pass -le 2; $pass++) {
            "PASS $pass" | Add-Content -LiteralPath $stdoutLog -Encoding utf8NoBOM
            & $pdfLatex @arguments 2>&1 |
                Add-Content -LiteralPath $stdoutLog -Encoding utf8NoBOM
            if ($LASTEXITCODE -ne 0) {
                throw "pdflatex failed for $reader on pass $pass"
            }
        }
        $builtPdf = Join-Path $readerBuild "$reader.pdf"
        $finalPdf = Join-Path $outputRoot "$reader.pdf"
        if (-not (Test-Path -LiteralPath $builtPdf)) {
            throw "Expected PDF missing: $builtPdf"
        }
        if (Test-Path -LiteralPath $finalPdf) {
            throw "No-overwrite output already exists: $finalPdf"
        }
        Copy-Item -LiteralPath $builtPdf -Destination $finalPdf
        $item = Get-Item -LiteralPath $finalPdf
        [pscustomobject]@{
            reader = $reader
            bytes = $item.Length
            sha256 = (Get-FileHash -LiteralPath $finalPdf -Algorithm SHA256).Hash
        } | ConvertTo-Json -Compress
    }
}
finally {
    Pop-Location
}
