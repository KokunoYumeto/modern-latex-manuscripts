#!/usr/bin/env python3
"""Render one authority page into high-detail horizontal reading bands."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import fitz
from PIL import Image, ImageEnhance, ImageOps

Image.MAX_IMAGE_PIXELS = None

BANDS = (
    ("top", 0.015, 0.155),
    ("a", 0.135, 0.355),
    ("b", 0.335, 0.555),
    ("c", 0.535, 0.755),
    ("d", 0.735, 0.985),
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf", type=Path)
    parser.add_argument("page", type=int, help="one-based PDF page")
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--dpi", type=int, default=1200)
    parser.add_argument("--prefix", default="source")
    args = parser.parse_args()

    if args.output_dir.exists():
        raise FileExistsError(f"no-overwrite output directory exists: {args.output_dir}")
    args.output_dir.mkdir(parents=True)
    document = fitz.open(args.pdf)
    page = document[args.page - 1]
    matrix = fitz.Matrix(args.dpi / 72.0, args.dpi / 72.0)
    manifest: list[str] = []
    for name, fy0, fy1 in BANDS:
        rectangle = page.rect
        clip = fitz.Rect(
            rectangle.x0 + 0.03 * rectangle.width,
            rectangle.y0 + fy0 * rectangle.height,
            rectangle.x0 + 0.98 * rectangle.width,
            rectangle.y0 + fy1 * rectangle.height,
        )
        pixmap = page.get_pixmap(
            matrix=matrix, clip=clip, colorspace=fitz.csGRAY, alpha=False
        )
        image = Image.frombytes("L", (pixmap.width, pixmap.height), pixmap.samples)
        image = ImageOps.autocontrast(image, cutoff=1)
        image = ImageEnhance.Contrast(image).enhance(1.9)
        image = ImageEnhance.Sharpness(image).enhance(1.6)
        path = args.output_dir / f"{args.prefix}_p{args.page:03d}_{name}_{args.dpi}dpi.png"
        image.save(path, optimize=True)
        manifest.append(f"{path.name},{path.stat().st_size},{sha256(path)}")
    print("file,bytes,sha256")
    print("\n".join(manifest))


if __name__ == "__main__":
    main()
