param()

$ErrorActionPreference = 'Stop'
$controlRoot = $PSScriptRoot

$interlanguageRoot = $controlRoot
for ($i = 0; $i -lt 7; $i++) {
    $interlanguageRoot = Split-Path -Parent $interlanguageRoot
}

$documentsRoot = [Environment]::GetFolderPath('MyDocuments')
$aliasRoots = @{
    IL = $interlanguageRoot
    LEGACY_SGA_CONTROL = Join-Path $documentsRoot 'CHat translates and clean\SGA continuation 2\_claude_aid\_codex_confirmed_source_errors'
    LOCAL_TOHOKU_WITNESS = Join-Path $documentsRoot 'Papors\OS\Sur quelques points dalgèbre homologique (the Tôhoku paper) (Alexandre Grothendieck).pdf'
}

$errors = [System.Collections.Generic.List[string]]::new()
$warnings = [System.Collections.Generic.List[string]]::new()

function Add-Error([string]$message) {
    $script:errors.Add($message)
}

function Get-Sha256([string]$path) {
    return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
}

$requiredArtifacts = @(
    'PREDECESSOR_FAILURE_FORENSIC_AUDIT.md',
    'FAILURE_MODE_REGISTER.csv',
    'BINDING_SAFEGUARDS.md',
    'ASSUMPTION_NORMALIZATION_AND_REVERSAL_LEDGER.csv',
    'RETROSPECTIVE_SOURCE_MANIFEST.csv',
    'RETROSPECTIVE_STATUS.md',
    'validate_retrospective.ps1'
)

$artifactRows = [System.Collections.Generic.List[object]]::new()
foreach ($name in $requiredArtifacts) {
    $path = Join-Path $controlRoot $name
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Add-Error "required artifact missing: $name"
        continue
    }
    $item = Get-Item -LiteralPath $path
    $artifactRows.Add([pscustomobject]@{
        path = $name
        bytes = $item.Length
        sha256 = Get-Sha256 $path
    })
}

$manifestPath = Join-Path $controlRoot 'RETROSPECTIVE_SOURCE_MANIFEST.csv'
$manifestRows = @()
if (Test-Path -LiteralPath $manifestPath) {
    try {
        $manifestRows = @(Import-Csv -LiteralPath $manifestPath -Encoding UTF8)
    }
    catch {
        Add-Error "source manifest parse failure: $($_.Exception.Message)"
    }
}

$sourceIds = @{}
$sourceKeys = @{}
$sourceBytes = [int64]0
$sourceStates = @{}
foreach ($row in $manifestRows) {
    if ([string]::IsNullOrWhiteSpace($row.source_id)) {
        Add-Error 'source manifest row with empty source_id'
        continue
    }
    if ($sourceIds.ContainsKey($row.source_id)) {
        Add-Error "duplicate source_id: $($row.source_id)"
    } else {
        $sourceIds[$row.source_id] = $true
    }

    $sourceKey = "$($row.root_alias)|$($row.relative_path)"
    if ($sourceKeys.ContainsKey($sourceKey)) {
        Add-Error "duplicate source path key: $sourceKey"
    } else {
        $sourceKeys[$sourceKey] = $true
    }

    if (-not $aliasRoots.ContainsKey($row.root_alias)) {
        Add-Error "unknown root alias for $($row.source_id): $($row.root_alias)"
        continue
    }
    if ([string]::IsNullOrWhiteSpace($row.read_status)) {
        Add-Error "empty read_status: $($row.source_id)"
    }
    if ([string]::IsNullOrWhiteSpace($row.reader)) {
        Add-Error "empty reader: $($row.source_id)"
    }
    if ([string]::IsNullOrWhiteSpace($row.identity_state)) {
        Add-Error "empty identity_state: $($row.source_id)"
    } else {
        if (-not $sourceStates.ContainsKey($row.identity_state)) {
            $sourceStates[$row.identity_state] = 0
        }
        $sourceStates[$row.identity_state]++
    }

    $expectedBytes = [int64]0
    if (-not [int64]::TryParse($row.bytes, [ref]$expectedBytes)) {
        Add-Error "invalid byte count: $($row.source_id)"
        continue
    }
    if ($row.sha256 -notmatch '^[A-Fa-f0-9]{64}$') {
        Add-Error "invalid SHA-256 syntax: $($row.source_id)"
        continue
    }

    $rootValue = $aliasRoots[$row.root_alias]
    if ($row.root_alias -eq 'LOCAL_TOHOKU_WITNESS') {
        $resolved = $rootValue
    } else {
        $normalizedRelative = $row.relative_path.Replace('/', [IO.Path]::DirectorySeparatorChar)
        $resolved = Join-Path $rootValue $normalizedRelative
    }

    if (-not (Test-Path -LiteralPath $resolved -PathType Leaf)) {
        Add-Error "source missing: $($row.source_id)"
        continue
    }
    $item = Get-Item -LiteralPath $resolved
    if ($item.Length -ne $expectedBytes) {
        Add-Error "byte mismatch: $($row.source_id) expected=$expectedBytes observed=$($item.Length)"
        continue
    }
    $observedHash = Get-Sha256 $resolved
    if ($observedHash -ne $row.sha256.ToUpperInvariant()) {
        Add-Error "hash mismatch: $($row.source_id) expected=$($row.sha256) observed=$observedHash"
        continue
    }
    $sourceBytes += $item.Length
}

$failurePath = Join-Path $controlRoot 'FAILURE_MODE_REGISTER.csv'
$failureRows = @()
if (Test-Path -LiteralPath $failurePath) {
    try {
        $failureRows = @(Import-Csv -LiteralPath $failurePath -Encoding UTF8)
    }
    catch {
        Add-Error "failure register parse failure: $($_.Exception.Message)"
    }
}
$failureIds = @{}
foreach ($row in $failureRows) {
    if ($row.failure_id -notmatch '^TOH-FM-[0-9]{3}$') {
        Add-Error "invalid failure_id: $($row.failure_id)"
    }
    if ($failureIds.ContainsKey($row.failure_id)) {
        Add-Error "duplicate failure_id: $($row.failure_id)"
    } else {
        $failureIds[$row.failure_id] = $true
    }
    foreach ($column in @('classification','incident_or_hazard','evidence','root_cause','affected_artifacts','detection','corrective_control','recurrence_test','tohoku_binding','claim_boundary')) {
        if ([string]::IsNullOrWhiteSpace($row.$column)) {
            Add-Error "failure row $($row.failure_id) has empty $column"
        }
    }
}
if ($failureRows.Count -lt 35) {
    Add-Error "failure register has fewer than 35 rows: $($failureRows.Count)"
}

$ledgerPath = Join-Path $controlRoot 'ASSUMPTION_NORMALIZATION_AND_REVERSAL_LEDGER.csv'
$ledgerRows = @()
if (Test-Path -LiteralPath $ledgerPath) {
    try {
        $ledgerRows = @(Import-Csv -LiteralPath $ledgerPath -Encoding UTF8)
    }
    catch {
        Add-Error "assumption ledger parse failure: $($_.Exception.Message)"
    }
}
$ledgerIds = @{}
foreach ($row in $ledgerRows) {
    if ($row.ledger_id -notmatch '^TOH-ARL-[0-9]{4}$') {
        Add-Error "invalid ledger_id: $($row.ledger_id)"
    }
    if ($ledgerIds.ContainsKey($row.ledger_id)) {
        Add-Error "duplicate ledger_id: $($row.ledger_id)"
    } else {
        $ledgerIds[$row.ledger_id] = $true
    }
    foreach ($column in @('kind','assumption_or_decision','origin','evidence_or_defeater','corrected_or_binding_state','affected_surfaces','inverse_or_replay','state','notes')) {
        if ([string]::IsNullOrWhiteSpace($row.$column)) {
            Add-Error "ledger row $($row.ledger_id) has empty $column"
        }
    }
}
if ($ledgerRows.Count -lt 40) {
    Add-Error "assumption ledger has fewer than 40 rows: $($ledgerRows.Count)"
}

$auditPath = Join-Path $controlRoot 'PREDECESSOR_FAILURE_FORENSIC_AUDIT.md'
$auditText = if (Test-Path -LiteralPath $auditPath) { Get-Content -LiteralPath $auditPath -Raw -Encoding UTF8 } else { '' }
$safeguardsPath = Join-Path $controlRoot 'BINDING_SAFEGUARDS.md'
$safeguardsText = if (Test-Path -LiteralPath $safeguardsPath) { Get-Content -LiteralPath $safeguardsPath -Raw -Encoding UTF8 } else { '' }

$requiredAuditPhrases = @(
    'Chronological failure history',
    'Exact Tôhoku authority and comparison lineage',
    'Bilingual deliverable contract',
    'Tôhoku semantic and pre-Stacks scaffold design',
    'Project-specific do-not-repeat checklist',
    'Bounded operating protocol',
    'Successor continuation record',
    'Effort accounting and closure rule',
    '100,000'
)
foreach ($phrase in $requiredAuditPhrases) {
    if ($auditText -notmatch [regex]::Escape($phrase)) {
        Add-Error "audit missing required phrase: $phrase"
    }
}

$requiredSafeguardPhrases = @(
    'Precedence-first bootstrap gate',
    'Three-layer textual invariant',
    'Native-TeX delivery gate',
    'Shared semantic graph and reference completeness',
    'Pre-Stacks mapping controls',
    'Reader-surface and privacy gate',
    'Resource-safety and concurrency gate',
    'Distinct release gates',
    'Current fail-close conditions',
    'Successor continuation contract'
)
foreach ($phrase in $requiredSafeguardPhrases) {
    if ($safeguardsText -notmatch [regex]::Escape($phrase)) {
        Add-Error "safeguards missing required phrase: $phrase"
    }
}

$requiredFailureIds = @(
    'TOH-FM-001','TOH-FM-002','TOH-FM-003','TOH-FM-005','TOH-FM-006',
    'TOH-FM-007','TOH-FM-008','TOH-FM-011','TOH-FM-012','TOH-FM-013',
    'TOH-FM-014','TOH-FM-015','TOH-FM-016','TOH-FM-017','TOH-FM-018',
    'TOH-FM-019','TOH-FM-021','TOH-FM-022','TOH-FM-023','TOH-FM-025',
    'TOH-FM-026','TOH-FM-027','TOH-FM-028','TOH-FM-029','TOH-FM-030',
    'TOH-FM-031','TOH-FM-032','TOH-FM-034'
)
foreach ($id in $requiredFailureIds) {
    if (-not $failureIds.ContainsKey($id)) {
        Add-Error "mandatory failure topic missing register ID: $id"
    }
}

$privacyFiles = @(
    'PREDECESSOR_FAILURE_FORENSIC_AUDIT.md',
    'FAILURE_MODE_REGISTER.csv',
    'BINDING_SAFEGUARDS.md',
    'ASSUMPTION_NORMALIZATION_AND_REVERSAL_LEDGER.csv',
    'RETROSPECTIVE_SOURCE_MANIFEST.csv',
    'RETROSPECTIVE_STATUS.md',
    'validate_retrospective.ps1'
)
$privacyPatterns = @(
    '(?i)C:\\Users\\',
    ('(?i)/' + 'Users/'),
    '(?i)AppData[\\/]',
    '(?i)\.codex[\\/]',
    '(?i)(?<![0-9a-f])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![0-9a-f])'
)
$privacyHits = [System.Collections.Generic.List[object]]::new()
foreach ($name in $privacyFiles) {
    $path = Join-Path $controlRoot $name
    if (-not (Test-Path -LiteralPath $path)) { continue }
    $text = Get-Content -LiteralPath $path -Raw -Encoding UTF8
    foreach ($pattern in $privacyPatterns) {
        $matches = [regex]::Matches($text, $pattern)
        if ($matches.Count -gt 0) {
            $privacyHits.Add([pscustomobject]@{
                file = $name
                pattern = $pattern
                count = $matches.Count
            })
            Add-Error "privacy pattern hit in ${name}: $pattern count=$($matches.Count)"
        }
    }
}

$result = [ordered]@{
    schema = 'tohoku_retrospective_validation_v1'
    generated_utc = (Get-Date).ToUniversalTime().ToString('o')
    status = if ($errors.Count -eq 0) { 'PASS' } else { 'FAIL' }
    errors = @($errors)
    warnings = @($warnings)
    scope = [ordered]@{
        corpus = 'tohoku_pp119_221'
        production_blocked_until_pass = $true
        minimum_retrospective_tokens = 100000
    }
    counts = [ordered]@{
        required_artifacts = $requiredArtifacts.Count
        artifact_hash_rows = $artifactRows.Count
        source_manifest_rows = $manifestRows.Count
        source_manifest_total_bytes = $sourceBytes
        source_ids_unique = $sourceIds.Count
        source_paths_unique = $sourceKeys.Count
        failure_modes = $failureRows.Count
        failure_ids_unique = $failureIds.Count
        assumption_ledger_rows = $ledgerRows.Count
        assumption_ledger_ids_unique = $ledgerIds.Count
        privacy_hits = $privacyHits.Count
    }
    source_identity_states = $sourceStates
    artifact_hashes = @($artifactRows)
    privacy = [ordered]@{
        status = if ($privacyHits.Count -eq 0) { 'PASS' } else { 'FAIL' }
        path_aliases_used = $true
        hits = @($privacyHits)
    }
    continuation = [ordered]@{
        durable_objective_present = ($auditText -match 'Produce a complete canonical bilingual scholarly edition')
        exact_authority_hashes_present = ($auditText -match '5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF' -and $auditText -match '8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53')
        next_cursor = 'printed_p119_repair'
        production_may_resume = ($errors.Count -eq 0)
    }
}

$result | ConvertTo-Json -Depth 8
