# Tôhoku predecessor forensic retrospective — status

## 2026-08-04 — controlling phase declaration

- Phase: `FORENSIC_RETROSPECTIVE_BLOCKING_PRODUCTION`.
- Minimum effort floor: 100,000 goal-tracked tokens; not a cap.
- Active corpus goal: complete canonical bilingual Tôhoku pp.119--221 with
  diplomatic French, separately corrected French, source-aligned English,
  readers, complete semantic references/indexes, and a pre-Stacks graph.
- Goal API limitation: an active goal's token budget cannot be edited in place;
  the controlling floor is therefore bound in the active plan, this status,
  the audit, and the final validation receipt.
- Pre-finalization goal counter snapshot: 759,671 tokens used.
- Production state: blocked. No transcription, translation, TeX repair,
  semantic indexing, build, package, publication, or archive work may resume
  until the retrospective manifest and final validation are frozen PASS.
- Evidence state: bounded predecessor reading complete; no broad recursive
  search, no new OCR, no parallel heavy render/build, and no predecessor
  mutation performed.
- Artifact state: audit, failure register, safeguards, assumption/reversal
  ledger, status, and source manifest drafted; final source replay, privacy
  scan, internal-consistency checks, artifact hashes, validation JSON, and
  frozen continuation receipt remain required.
- Current corpus cursor after retrospective: p.119 repair, not p.120.
- Blocking current defect: inherited diplomatic and corrected French p.119
  systematically strip printed diacritics while the old correction ledger says
  no correction.

This status is append-only. Later state changes are appended below; the
pre-correction project `STATUS.md` remains unchanged as adverse history.

## 2026-08-04T04:51:25.7135621+02:00 — retrospective closure checkpoint

- Full bounded source replay: PASS for 143 unique manifest rows and
  25,342,777 source bytes.
- Failure register: PASS, 35 stable unique failure IDs.
- Assumption/normalization/reversal ledger: PASS, 40 stable unique IDs.
- Mandatory audit sections and safeguard stop conditions: PASS.
- Privacy-clean retrospective projection: PASS, zero private-path or task-UUID
  detector hits; exact source locations use root aliases.
- Validator errors: empty; warnings: empty.
- Goal-tracker effort snapshot immediately before this append: 914,657 tokens
  used and 3,085 seconds, exceeding the 100,000-token minimum by 814,657
  tokens. This is an exact dated tracker snapshot, not a claim about the word
  count of the audit and not a terminal goal-completion count.
- Retrospective phase disposition: complete after the final validation JSON is
  frozen from the co-current artifact hashes.
- Corpus goal disposition: remains active; the next production action is the
  append-only direct-authority repair of printed p.119.
