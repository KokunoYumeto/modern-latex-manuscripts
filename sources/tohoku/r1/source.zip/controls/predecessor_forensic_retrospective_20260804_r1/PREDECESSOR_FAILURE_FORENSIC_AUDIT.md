# Predecessor failure forensic audit

## Tôhoku canonical bilingual corpus, retrospective generation r1

Audit date: 2026-08-04  
Corpus governed by this audit: Alexandre Grothendieck, *Sur quelques points
d'algèbre homologique*, Tôhoku Mathematical Journal (Second Series), volume 9
(1957), both published parts, printed pp.119--221  
Stage: mandatory forensic retrospective before renewed corpus production  
Effort floor: at least 100,000 tokens of goal-tracked investigation; this is a
minimum, not a cap  
Mutation boundary: this audit creates files only below the new no-overwrite
Tôhoku retrospective control root; no authority or predecessor tree was
mutated

## 1. Executive determination

The predecessor record does not show one isolated mistake. It shows a
repeating epistemic failure: a narrow technical success was promoted into a
broader scholarly claim that the test did not establish. A compiled PDF was
treated as evidence of source fidelity. Page-envelope coverage was treated as
textual completeness. A local link graph was called reference-complete. A
large cumulative reader was called corpus-complete despite a missing expected
scope segment. A repository merge was treated as exact public custody. A
privacy projection was called clean after a detector with a known blind spot.
A diagram inventory said zero because the detector never enumerated the active
dependency class that contained forty-one diagrams.

The common mechanism was not simply carelessness. The workflows repeatedly
collapsed distinct layers or gates:

- diplomatic transcription into correction;
- correction into translation;
- translation into comparison lineage;
- comparison lineage into authority;
- build validity into source validity;
- local links into semantic reference closure;
- package validity into privacy and rights validity;
- transport success into public byte identity;
- current working state into a stale status narrative;
- file existence into successor acknowledgment;
- plausible analogy into a potential official Stacks mapping.

The repair is therefore architectural. Tôhoku production will not rely on a
single notion of “PASS” or “complete.” It will maintain three textual layers
over one stable semantic graph, explicit decision/reversal provenance, an
expected-unit matrix, exhaustive candidate/edge/residual inventories, native
TeX diagram closure, generation-addressed builds, co-current manifests and
state, privacy and rights gates, and exact public readback if publication is
later authorized.

This audit also finds two current Tôhoku failures before renewed production:

1. The first durable goal was set in a sequence the controlling user rejected;
   the user deleted it and required the entire precedence to be reread before
   another goal could be created. The old intake's self-attestation cannot
   override that direct correction.
2. The inherited p.119 “diplomatic” and “corrected” French files systematically
   omit printed diacritics while the correction ledger declares the corrected
   layer identical to diplomatic French and admits no source correction. This
   is not diplomatic French. It must be superseded append-only before p.120.

The user further clarified that the 100,000-token figure is a minimum forensic
effort, not a limit. The goal tracker already records effort above that floor;
the retrospective nevertheless remains incomplete until every mandated file
passes final validation and receives a frozen hash.

## 2. Evidence method and claim discipline

### 2.1 Corrected precedence-first sequence

After the user deleted the premature goal, mutation stopped. The lead
personally reread the complete common handoff through EOF, beginning with
`00_START_HERE.md` and `TOHOKU/README_START_HERE.md`; reread all exact
precedents in `04_PRECEDENT_READING_LIST.csv`; rehashed them; replayed the
handoff manifest and validation; and only then created the current durable
goal.

The frozen handoff identities replayed exactly:

- `HANDOFF_SHA256SUMS.csv`: 1,184 bytes, SHA-256
  `F50A8D9171E44448083A42E6F0A668E49DD60EFD7EDE8BA6C77BDD6A75191E45`;
- `HANDOFF_VALIDATION.json`: 465 bytes, SHA-256
  `B57817D9CA29CD01011603889CFFC2089EFE0F387774B2DFA386290A7A2DBA0D`,
  state `PASS`, `errors=[]`.

Six of seven precedent files still matched the frozen reading-list identities
exactly. The EGA pre-Stacks scaffold was a live append-only successor:

- frozen reading-list identity: 92,172 bytes, SHA-256
  `248460C70D5B42F30E254761EC31C30F9F3AD6EFAFDFC41C768AEC50581D10C6`;
- live EOF identity at audit snapshot: 98,950 bytes, SHA-256
  `1B024552FFE71D56EB1BB2BA50304961073B55B0CEE76D5F514EDDFB65D49BB4`;
- the first 92,172 bytes of the live file hash exactly to the frozen identity;
  the suffix is a later p.138 append.

This is classified as an expected live successor with a proved frozen prefix,
not as unexplained corruption and not as an exact current match. That
distinction is essential: snapshot-time identity is evidence; a mutable file
name is not a timeless object.

### 2.2 Bounded evidence set

The investigation used exact named controls and exact predecessor roots only.
It did not search all of `Documents`, a profile, or a drive. It did not open a
forbidden authority corpus, regenerate OCR, or run parallel heavy renders.
Bounded agents read independent EGA, SGA/FAC/GAGA, and archive/publication
evidence through EOF; the lead personally reread the common precedence and the
critical failure receipts, current long-running EGA status/logbooks, and the
current Tôhoku artifacts used for adverse findings.

The source manifest identifies every file by a privacy-clean root alias,
exact relative path, byte count, SHA-256, EOF state, reader, and identity
classification. An agent read is labeled as such; it is not falsely described
as a lead read. Live files are labeled `live_snapshot` or
`frozen_prefix_plus_append`. No hash is silently substituted.

### 2.3 Claim boundaries

This audit distinguishes:

- **proved incident**: direct evidence records the failure;
- **proved near-miss**: evidence shows a dangerous condition, but not the
  strongest possible formal violation;
- **controlled hazard**: a recurrence risk is real, but no positive incident
  was found in the bounded evidence;
- **positive precedent**: a workflow that correctly constrained its claim;
- **current adverse history**: a failure in the pre-correction Tôhoku root that
  must be preserved and superseded.

Two negative findings matter:

- No bounded evidence proves that an official Stacks tag was actually
  invented. The risk is real and the null-until-verified rule is binding, but
  inventing a historical incident in a retrospective would repeat the same
  epistemic failure.
- No bounded evidence proves an admitted duplicate decision ID or that a
  duplicate archive concept was actually minted. The record proves transient
  log regression, wrong DOI routing, and duplicate-concept/draft risk. The
  prevention controls are justified without fabricating the stronger event.

## 3. Chronological failure history

### 3.1 2026-07-17 to 2026-07-19: source authority and raw-OCR boundary

The user authority and early controls already required exact source fidelity,
decision provenance, and privacy-aware publication. Yet the SGA OCR sequence
shows how quickly coverage metrics became seductive. The raw witness had all
1,368 page identifiers, but the mutable generated TeX still contained thirty-
five TeX errors, malformed formulas, symbol substitutions, accent failures,
stale logs, and no full-master PDF. Controls explicitly rejected “near-perfect”
and “finished.” A later force-OCR manifest kept 314 files classified as
`RAW_OCR_WITNESS` and held them for page/formula audit.

The exact lesson is not merely “OCR makes typos.” It is that the workflow had
at least four different meanings of completeness:

1. a page envelope existed;
2. an OCR artifact existed;
3. TeX could be generated or partially compiled;
4. the text and mathematics matched direct authority.

Only the fourth can admit source content. A count at level one cannot be
promoted through levels two and three by naming the file “complete.” The later
Claude SGA7 status adds a related reconstructed-TeX failure: a prior tree had
invented or substituted diagrams, systematically relabeled notation, and
condensed prose. It was correctly refused as authority.

This audit does not claim that a formal policy ever said OCR was authority.
The proved failure is de-facto reliance pressure: reconstructed artifacts
looked finished enough to invite stronger claims before direct replay.

### 3.2 2026-07-19 to 2026-07-20: shared-log regression

On 2026-07-19, a decision was admitted in the shared English-Germanic manager
log at 250 records, 1,424,151 bytes, SHA-256 beginning `89BE32`. A later
independent read saw the log regress to 1,414,495 bytes, SHA-256 beginning
`538A2E`, and the decision was absent. A subsequent read found it restored
exactly once at 251 records and 1,429,579 bytes.

The exact writer was not identified. The leading explanation in the receipt is
a cached-snapshot whole-file replacement by a concurrent writer. The root
cause is therefore structural, not personal: full-file rewrites were possible
without a writer lock held through validation. JSON validity could not detect
the lost record because both the older and newer snapshots were syntactically
valid.

The adopted append helper is the correct model. It acquires an exclusive lock,
rereads live bytes, rejects duplicate IDs, appends one record, flushes,
validates while still locked, and truncates to the original length on failure.
At the archive audit snapshot, the shared log validated at 491 records, 491
unique IDs, `errors=[]`, 3,288,199 bytes, SHA-256
`49A03734F4F73FB28E8E4C3188E1FECAEE5D2FA4143A4F0D7F575CF54EE39E39`.

No actual duplicate ID was found. Duplicate rejection is a prevention
requirement; the incident is record loss/regression.

### 3.3 2026-07-22: resource waste and correction of false work assumptions

The user correction of 2026-07-22 records enormous wasted effort rechecking
already complete SGA1/2 transcription. The later resource note attributes
waste to repeated OCR/transcription, rereading rendered pages without a new
question, overlapping agents, duplicate manifests/releases, and rebuilds
without substantive edits. This is a workflow failure because computational
cost displaced source-critical work while creating more mutable evidence
surfaces.

The stronger PC-crash evidence comes from the EGA p.112 workflow receipt: a
9,259-by-11,550 original-detail image load and a recursive `rg` over all of the
user's Documents tree were identified as co-causes. A separate EGA log records
twenty 5,000-dpi bands consuming roughly two gigabytes and destabilizing the
machine. The controls therefore forbid profile-, Documents-, or drive-wide
searches and restrict the task to one heavy build/render at a time.

The correct image policy is question-scaled. Broad page reading uses roughly
1,100--1,800 dpi-equivalent. Only a genuinely small or ambiguous mark justifies
5,000--9,000. Resolution does not substitute for a feature checklist, and
twenty maximum-resolution bands are not safer than one bounded crop.

### 3.4 2026-07-23: package, privacy, link-classification, and public-custody failures

The SGA2 R6 independent audit is a model of why distinct gates matter. The
reader core, graph, build, fonts, and rendered samples were healthy, yet the
delivery correctly failed:

- only 4 of 27 `DELIVERY_MANIFEST.csv` rows matched the active R6 bytes;
- only 7 of 23 root checksum rows matched;
- only 6 of 22 Zenodo payload manifest rows matched;
- fourteen CSV context cells still began with spreadsheet formula triggers;
- a proposed-public sanitized build log reconstructed five private path roots
  after whitespace dewrapping.

The root cause was generation inheritance: R5 controls were carried into R6,
visible-string sanitization missed normalized paths, and CSV quoting was
mistaken for formula neutralization. The proper response was a distinct
no-overwrite R7 successor, not editing R6 to make its failure disappear.

R7 then revealed another narrow-PASS problem. Its public payload validation
called all 1,384 PDF link annotations internal GoTo links. Direct action-
dictionary inspection found 1,382 GoTo actions and two URI actions. The links
were not necessarily broken; their semantics were falsely classified. R8
corrected the metadata without rebuilding an otherwise unchanged reader.

The initial R8 GitHub merge produced a third failure: repository clean filters
normalized nineteen CRLF files to LF. Merge success did not preserve sealed
bytes. Only commit-pinned anonymous raw readback exposed the difference. A
package-scoped `-text` rule and exact restaging later closed 48 of 48 files and
6,960,671 bytes. The lesson is exact: source/package hashes must be checked on
the public surface after transport. Git status, push, pull request, merge, and
raw-public custody are separate states.

### 3.5 2026-07-27 to 2026-07-29: diagram evidence and false zero-debt closure

Broad builds, contact sheets, and ordinary review had passed while SGA
diagrams still differed in `i/j`, star versus shriek, primes, indices, bullets,
arrow direction, label side, and terminal punctuation. The cold-reverify
method therefore bound three page coordinates—printed page, running header,
and folio—and used rendered authority images with targeted 6,500--9,000-dpi
crops where needed. Text extraction could help locate a page but could not
decide a mark.

The most important diagram failure is the Exposé-II omission chain:

1. the ownership CSV recorded Exposé I = 10, II = 0, III = 32;
2. a correction found I = 25 and III = 62 because earlier counts covered only
   selected call classes, but it retained II = 0;
3. a closure then claimed 378 of 378 diagrams native, zero open, zero raster,
   and zero unchecked;
4. a later cumulative-source replay found five active Exposé-II components
   containing exactly forty-one `\SGAThreeDiagram` calls, all PNG-backed;
5. the corrected total was 419, of which 378 were native/lead-reviewed and 41
   remained open.

The closure was not defeated by a subtle glyph. It was defeated by its
universe. The build covered ten enumerated nonzero units and excluded Exposé II
because the flawed inventory said it was empty. Thus the build passed exactly
the wrong expected set. Tôhoku must derive its diagram universe from every
active final-master dependency and every call class. Claimed-zero units need
negative evidence; an absent row is not zero.

Raster diagrams were acceptable only as visible interim debt. They became a
publication failure when the debt escaped the inventory. Final Tôhoku readers
must pass three independent zero tests: no active raster call, no raster asset
in the package, and no relevant PDF image object. Private authority crops may
remain as evidence outside delivery.

### 3.6 2026-07-27: semantic detector and identity invalidation failures

An Exposé-VII reference detector promoted six TikZ coordinate decimals such
as `2.1`, `3.3`, and `3.2` into semantic references. Its validation was
mechanically consistent and semantically false. A second correction proved a
diagram source changed from 1,246 to 1,290 bytes while only a 287-byte prefix
remained identical; derived candidates nevertheless retained old identities.

These incidents establish two controls:

- automated extraction produces candidates, never final semantic edges;
- any source-byte change invalidates all derived IDs, offsets, candidates,
  edges, and delivered-PDF coordinates until complete regeneration.

Tôhoku's semantic graph will retain rejected candidates and reasons so a later
detector cannot rediscover and silently readmit the same false positive.

### 3.7 2026-07-28 to 2026-08-01: English-first EGA production

The EGA intake and allocation controls organized a source-aligned English
production lane. French scans and source TeX were authority inputs and OCR was
a locator, but the planned deliverables did not include separately complete
diplomatic-French and corrected-French readers. On 2026-08-01, a closeout
fronted a “complete linked English EGA 0--IV reader.”

On 2026-08-02, the French-first successor copied the frozen 127-file tree and
began direct source replay. Printed p.69 immediately produced three inherited
English defects. The active log found seven copies of each obsolete wording
across publication candidates, historical trees, and comparison lineage. The
active source could be repaired, but the global integration debt remained.
Subsequent p.80--138 replay found many further corrections. The p.138 snapshot
alone recorded four source-fidelity repairs, including an omitted dependency
and a necessary/sufficient polarity error.

The issue was not that English translation preceded all useful French work in
time; it was that English build/link/package closure defined the product while
the two French editorial layers did not exist as deliverables. This made a
later source-first pass both corrective and architectural rework. Tôhoku must
advance all three layers together from p.119.

The later EGA logs supply precise examples of what a one-tree design cannot
express:

- diplomatic French preserves a printed omission in a pair of arrows while
  corrected/English text supplies the necessary second named arrow;
- a printed object name differs from the mathematically corrected one;
- a printed “monomorphisme” is corrected to a homomorphism;
- a theta-sharp source and target are reversed in print but repaired in the
  corrected layer;
- printed `1°/2°` had silently become `(a)/(b)`;
- printed `n≥0` had become `n>0`;
- a proof square was removed, then reinstated by explicit reversal;
- a p.107 14-byte unlogged drift invalidated frozen evidence;
- p.110 rendered inspection superseded a code-inferred diagram-label PASS.

Each case requires diplomatic, correction, translation, comparison, and
publication roles to be independently addressable over shared semantic IDs.

### 3.8 2026-07-30 to 2026-08-02: reference-v2 and pre-Stacks overclaim

EGA reference publications called local graphs exhaustive while some cross-
volume references remained visible nonlinks. The compact package also covered
an uneven source-certification state, and the global reader's EGA 0 component
ended at Section 13 even though a scope correction required Sections 0.1--0.23.
Named destinations and GoTo validation could show that links were not broken;
they could not establish that every semantic reference candidate had been
found, adjudicated, and resolved.

The EGA pre-Stacks scaffold is useful. It captures pagewise concepts and
explicitly refuses to claim a Stacks-form rewrite or Lean formalization. But at
the reviewed snapshot it remained a Markdown scaffold and explicitly deferred
final coordinates, exhaustive reference, subject, formula and terminology
indexes, and implication closure. It was not the complete reusable machine
graph its title might suggest.

Tôhoku therefore separates:

- candidate extraction coverage;
- candidate adjudication;
- local target resolution;
- cross-part and cross-work relationships;
- bibliography resolution;
- semantic edge closure;
- residual closure;
- implication/dependency closure;
- PDF-link validity;
- pre-Stacks candidate versus confirmed mapping.

An official Stacks tag remains null without a directly verified official
citation. No positive invented-tag incident was found, and this audit will not
invent one.

### 3.9 2026-08-01: false completion from narrower scope

At 17:17 on 2026-08-01, the EGA global scope correction required EGA 0 through
Section 0.23. The current coordination file says the same and warns against
using the older through-0.13 reader. At 19:41, a global closeout called a
1,356-page reader the complete linked English EGA 0--IV corpus while its bound
component scope still ended at EGA 0 Section 13.

This is a textbook stale-input completion claim. The reader could be complete
relative to its frozen component manifest while still incomplete relative to
the corrected intended scope. Tôhoku completion will be a set equality:
canonical expected units for pp.119--221 must equal built and validated units,
with zero missing rows. Page count and build success are not substitutes.

### 3.10 2026-08-01 to 2026-08-04: stale status and weak continuation

The active EGA successor's `STATUS.md` begins with a controlling p.77 snapshot,
while append-only blocks and later evidence reach p.137 and p.138. The log is
not strictly chronological, so following its first header or EOF alone can
produce the wrong cursor. At one audit moment, neither STATUS nor LOGBOOK
contained the R82/p.138 state even though R82 validation had advanced.

A stalled EGA app send required takeover with an exact p.150 cursor. A GAGA
handoff precisely bound source and PDF identities and recorded thirty-two
workflow sentinel tokens at sixteen joins, but its archive decision explicitly
did not claim recipient read acknowledgment. A file can exist without being
consumed.

The repair is a generated, co-current `CURRENT_STATE.json`, not more prose. It
must bind the exact objective, scope, authority, ownership, last admitted page,
next cursor, live hashes, open holds, and next bounded action. A successor
must issue a hash-bound acknowledgment after replay. Chat memory and file
existence do not satisfy the gate.

### 3.11 2026-08-02: manifest canonicalization and live identity drift

EGA source manifest R2 had null totals and an incomplete ordering contract.
R3 had 127 correct rows and correct total bytes, but its declared “sorted
ordinal” aggregate was actually generated in listed JSON order. The declared
hash began `A6BBB1`; true ordinal replay began `0E7BBF`. R4 repaired the
contract and reproduced in independent Python and PowerShell implementations.

During this retrospective, the EGA p.138 source-diff validation itself changed
from an initially observed 15,169-byte identity to 15,663 bytes, SHA-256
`2BA182D64F28C22E5BD4E732E29830C904FAA0747F42DBC36B0918D08E651D71`,
which was reread through EOF and immediately rehashed stable. The scaffold had
also advanced by an append. These are not attributed as misconduct; they prove
that a retrospective manifest must say when it observed a live snapshot and
must not imply that a path identifies immutable bytes.

### 3.12 2026-08-02 to 2026-08-03: archive DOI, draft, privacy, and reader failures

Three Steinitz control files used concept DOI `10.5281/zenodo.20547337`, which
resolved to an unrelated medical dataset; the correct concept was recorded as
`10.5281/zenodo.20616988`. An EGA decision transposed its concept DOI as
`10.5281/zenodo.20415424`; live state and repository mapping established
`10.5281/zenodo.20414353`. These are routing failures caused by conflating
concept DOI, version DOI, record, deposition/draft, package, branch, and corpus.

The SGA draft-recovery record shows why a failed transfer must retain one
tracked same-concept draft rather than starting parallel drafts. No reviewed
record proves a duplicate concept was actually minted, so the audit records
duplicate-concept risk rather than a false incident.

Privacy remediation then exposed two rounds of overclaim. Preliminary counts
described 421 private path-root hits, three Codex-state segments, and seventeen
task IDs. Recursive JSON traversal corrected the report to 2,416 replacement
events affecting 423 of 478 records: 2,272 project-root events, 88 private
Documents-root events, sixteen archive-worktree events, five operator-home
events, four Codex-state events, and 31 task-ID events. The v1 public projection
still retained nine UUIDs across six records because its regex required a
leading word boundary and missed IDs concatenated after words such as `thread`
or `task`.

This failure combines ontology and detector design: events, matching lines,
and affected records are different counts; known-token scanning and shape-
based scanning detect different residuals. Tôhoku privacy validation will
recursively ledger transformations by JSON/CSV field and run both classes of
detector over loose files and archive members.

Reader presentation required repeated cleanup. Hundreds of project/process
apparatus items, AI badges, Zenodo notes, and comparison/correction narrative
were removed from readers. Yet on 2026-08-03 a published 4,185-page provisional
cumulative SGA reader still contained a full “Source and status” note on page
2. Transport identity had advanced without an all-page content-surface gate.
Tôhoku readers will contain mathematics and genuine source-era editorial
matter only; workflow, AI, status, error, and custody prose stay in controls.

### 3.13 2026-08-04: current Tôhoku bootstrap and p.119 failures

The pre-correction Tôhoku root contains an intake file claiming it was created
only after complete control reading and that all seven precedents matched. It
also contains p.119 diplomatic, corrected, and English files, decisions, a
status, and a continuation cursor at p.120. The controlling user directly
rejected the goal sequence, deleted the goal, and required the precedence to
be reread before a new goal was created. This task complied: all mutation was
frozen, the lead reread the complete handoff and all seven precedents through
EOF, rehashed them, replayed the handoff, and only then created the current
exact goal.

The old root is not deleted. Its claims are evidence to be tested, not
authority over the user's correction. It is preserved as an adverse generation.

The p.119 TeX then reveals a substantive source failure. Both French files
contain ASCII forms such as `ALGEBRE`, `Recu`, `theorie`, `a`, `derives`,
`categories`, `expose`, and `Universite` throughout a French page whose direct
printed source contains diacritics. The diplomatic file is 3,422 bytes,
SHA-256 `B8FB69418F7C95EF402E55C3D87F53819321750D5148D053EB13AE263E1A4985`.
The corrected file is 3,450 bytes, SHA-256
`65833D06FA8A5C6892ABC965383E978BCAFAC4E5837E47643F589F6C436D1B76`.
The correction ledger's active disposition says the corrected French is
identical to diplomatic French and that no source error was established after
a complete 1,200-dpi-equivalent five-band review.

That review claim is defeated by its own output. The problem is not one
ambiguous speck; it is systematic feature-class omission. Resolution and the
number of bands do not prove that accents were inspected. The final repair
must not guess accents merely from modern French. It must reopen the official
p.119 image, enumerate each printed glyph from direct authority, append a
superseding transcription decision, determine separately whether any
authorial source correction exists, rebind the English decisions, and rebuild
in a no-overwrite generation.

The current log also records duplicate R2 comparator calibrations. Asynchronous
yield hid two background session identifiers, so retries were started before
completion became visible. No-overwrite protection retained only the first
complete R2 JSON and duplicate writes failed at the existing target; no
authority, TeX, or decision file changed. This was contained, but it proves
the need to capture and poll the returned session and to enforce one heavy
process at a time.

Finally, static review of `tools/build_readers.ps1` finds a generation-control
defect before it causes overwrite. Build directories are gate-addressed, but
the script copies into fixed final filenames and throws if one already exists.
After a successful early build, a corrected later generation cannot be
promoted alongside it. Final outputs must be generation-addressed with a
separate immutable current-projection receipt.

## 4. Root-cause synthesis

The chronology supports six interacting root causes. Treating them separately
is useful for prevention, but no single one explains the entire history.

### 4.1 Product ontology was underspecified

The projects used words such as source, text, translation, reader, corpus,
reference graph, complete, current, and public without always defining which
artifact role or validation scope they denoted. That permitted a reconstructed
English TeX tree to become the practical “source,” a linked PDF to become the
“complete corpus,” and a sanitized log to become “privacy clean” despite a
different detector universe.

Tôhoku therefore gives every artifact a role, not just a path:

- `authority_image`;
- `local_comparison_witness`;
- `locator_or_drafting_witness`;
- `fr_diplomatic`;
- `fr_corrected`;
- `en_source_aligned`;
- `comparison_lineage`;
- `semantic_canonical`;
- `reader_projection`;
- `private_control`;
- `privacy_clean_control`;
- `package_projection`;
- `public_transport_object`.

An artifact may have more than one relationship but only one primary role in a
generation. A path name cannot silently change that role.

### 4.2 Validation universes were defined by what tools already knew

The forty-one-diagram omission is the clearest example: the inventory covered
selected call classes and known nonzero components, so its expected set
excluded the very unit it was supposed to prove empty. Coordinate decimals
became references because the detector's universe was “number-like strings.”
Privacy detectors counted known tokens but missed UUID shapes concatenated to
words. A manifest aggregate used list order while its prose named ordinal
order.

Every Tôhoku validator must therefore declare both its positive universe and
its exclusions. Expected sets originate from the canonical corpus map and
final dependency graph, not from the detector's hits. Claimed-zero categories
need independent negative evidence. At least one recurrence test must be
adversarial: introduce or identify a syntactically different but semantically
equivalent call, path, or candidate class and prove the detector's contract
handles it.

### 4.3 Evidence scope and claim scope diverged

A build PASS answers “does this selected master compile?” A named-destination
PASS answers “do these emitted targets resolve?” A raw-readback PASS answers
“did these public bytes survive transport?” None answers “does every printed
page match authority?” or “is every semantic reference adjudicated?” The
predecessor record repeatedly used a true narrow fact in a false broad sentence.

The cure is not weaker language alone. Each PASS must carry a machine-readable
scope object: expected units, tested units, exclusions, detector version,
input hashes, and claim class. Human status prose is generated from that object
and cannot broaden it.

### 4.4 Mutable evidence lacked co-current state

Append-only logs are valuable because they preserve mistakes, but a long log
is not a current-state database. EGA's top status and later page blocks drifted;
an R82 validation and scaffold advanced without every status surface moving in
lockstep. An old hash could describe a valid prefix of a live file and still
be false as the current identity.

Tôhoku needs both:

- append-only history; and
- a generated, immutable, co-current `CURRENT_STATE.json` per checkpoint.

The state object points into history; it does not rewrite it. A successor can
then reproduce the exact goal, cursor, active generations, hashes, holds, and
next action without interpreting chronology.

### 4.5 Downstream dependency closure was informal

The p.69 seven-copy finding, missing public SGA6 footnote, and stale
coordination identity all show local repair without global closure. The same
pattern threatens bilingual work: correcting a French noun can affect English,
term index, semantic node label, cross-reference anchor, all readers, package,
and public record.

Every Tôhoku decision therefore records an explicit impact set. Closure is a
graph operation: traverse active downstream projections, regenerate those
whose inputs changed, prove others unaffected, then run an obsolete-reading or
stale-hash search over a bounded allowlist. A correction is not globally closed
because its canonical source file is correct.

### 4.6 Operational pressure distorted epistemic judgment

Heavy image loads, broad searches, overlapping agents, duplicate comparators,
and repeated builds created machine instability and made it tempting to accept
whatever artifact already existed. Resource safety is therefore part of
scholarly reliability. A crashed or thrashing session loses cursor, encourages
stale retries, fragments decision logs, and consumes the attention needed for
small mathematical marks.

The one-heavy-process mutex, exact path allowlists, question-scaled resolution,
and no-build-without-substantive-change rule are not merely performance tips.
They protect the evidence chain.

## 5. Exact Tôhoku authority and comparison lineage

### 5.1 Official authority

The controlling authority consists of two official J-STAGE PDFs frozen inside
the isolated Tôhoku work root:

| Authority ID | Published part | Printed scope | DOI | Bytes | SHA-256 | Admissibility |
|---|---|---:|---|---:|---|---|
| `TOH-AUTH-JSTAGE-I` | Part I | 119--183 | `10.2748/tmj/1178244839` | 7,305,283 | `5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF` | Direct authority after exact hash replay |
| `TOH-AUTH-JSTAGE-II` | Part II | 185--221 | `10.2748/tmj/1178244774` | 3,984,260 | `8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53` | Direct authority after exact hash replay |

The hard stop is printed p.221. No other Grothendieck paper, FGA, EGA, SGA,
Verdier, or Illusie source corpus may be opened to fill or modernize a Tôhoku
reading.

### 5.2 Local comparison witness

The starting local witness is a 103-page PDF:

- bytes: 12,897,534;
- SHA-256:
  `57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78`;
- role: local comparison witness, not independent authority;
- admission: pagewise only after official/local image comparison.

The admitted map is:

- local physical pages 1--65 = official Part I pages 1--65 = printed
  pp.119--183;
- local physical page 66 = completely blank unnumbered interleaf;
- local physical pages 67--103 = official Part II pages 1--37 = printed
  pp.185--221.

The first comparator generation is adverse evidence. It used strong
SIFT/RANSAC correspondences but an over-conservative fixed ratio and classified
only one pair MATCH while holding 101. It remains immutable at 34,063 bytes,
SHA-256 beginning `E9704C`; it was not rewritten to look successful.

The calibrated no-overwrite R2 successor is the admitted comparator:

- bytes: 74,608;
- SHA-256 beginning `B4E04B` and ending `DC34`, as bound in the current
  control record;
- result: 102/102 source-bearing page pairs MATCH, zero holds;
- minimum expected inliers: 149;
- maximum negative-control inliers: 48;
- minimum expected/control margin: 5.729167.

Before final corpus closure, the full comparator identity, schema, every page
row, and human boundary adjudication must be replayed. The summary above does
not license using feature matching to decide text or mathematics.

### 5.3 Textual derivatives

The pre-correction p.119 TeX and ledgers are derivatives, not authority. Their
identities are preserved because they form the first adverse Tôhoku
generation:

| Artifact | Bytes | SHA-256 | Disposition |
|---|---:|---|---|
| diplomatic French p.119 | 3,422 | `B8FB69418F7C95EF402E55C3D87F53819321750D5148D053EB13AE263E1A4985` | FAIL; systematic diacritic omission |
| corrected French p.119 | 3,450 | `65833D06FA8A5C6892ABC965383E978BCAFAC4E5837E47643F589F6C436D1B76` | FAIL; inherits omission and false no-correction state |
| source-aligned English p.119 | 3,245 | `844DCECD253BE8FA552DF95AF786E55BC321338AC3E074589E042BBA5414EB20` | HOLD; translation decisions must be rebound after French repair |
| transcription decisions | 2,902 | `ADA9100601CFA6B796608AC166C50A085B54EB0332D465ABEEE129AF85BE2998` | adverse history plus boundary decision |
| normalization decisions | 1,361 | `09AAC080120C9740C8FE239F8DFF671A1FA4F17891A2885F7987663D02EF90D2` | line-wrap policy provisionally retainable |
| source corrections | 1,204 | `6B17B608E2583363863EF715F6BEF03036625677F2BC287651B1F2A266284F64` | p.119 no-correction disposition requires supersession |
| translation decisions | 4,579 | `F17EEAAC1CC3EAC15B094D91AEEE89F1963DD984A61F06569885E848A456F0EE` | provisional; rebind to repaired French |
| reversals/global repairs | 453 | `47BFA0860A20B3FDDEDB990B08BCE117E253474DEB960054B59158AFE18CC23A` | insufficient; states no textual reversal yet |

No external translation has been admitted. If one is later discovered, it is
comparison lineage only. The FAC accidental-blind precedent supplies the
correct method: freeze which Tôhoku units predate discovery, compare only that
eligible set under an explicit methodology, let direct authority and corrected
French decide, and never extend a blind-comparison claim to later-produced
units.

### 5.4 Cross-work relationship lineage

The requested Tôhoku scaffold must support relationship mapping into SGA, EGA,
and FGA without opening or importing those corpora during this exclusive lane.
Therefore the initial relation table may contain:

- Tôhoku source node IDs and exact Tôhoku evidence;
- a target-work family name (`SGA`, `EGA`, `FGA`, `Stacks`);
- a descriptive target concept supplied by an authorized later integration
  pass;
- a null external target ID until that target's owning corpus validates it;
- relation type and direction;
- candidate status, confidence, and evidence boundary;
- ownership field identifying which future integration lane may confirm it.

This permits migration-ready structure without violating no-overlap or
inventing external coordinates. Cross-work confirmation is a later bounded
join between independently authoritative graphs, never an inference from
memory.

## 6. Bilingual deliverable contract

### 6.1 Canonical archival layers

For every source-bearing printed page from 119 through 221, the canonical
archive contains:

1. diplomatic French TeX;
2. separately corrected French TeX;
3. source-aligned English TeX;
4. stable shared semantic IDs and page/unit mappings;
5. formula and diagram objects where present;
6. page-specific transcription, normalization, correction, translation, and
   reversal records;
7. source-image review evidence sufficient for the smallest adjudicated mark.

The layers are never generated by destructive transformation of one another.
They may be rendered from shared structure, but the textual content and
decision lineage remain separately addressable.

### 6.2 Readers

The final private scholarly delivery includes at least:

- Part I diplomatic French reader;
- Part I corrected French reader;
- Part I source-aligned English reader;
- Part I bilingual reader;
- Part II diplomatic French reader;
- Part II corrected French reader;
- Part II source-aligned English reader;
- Part II bilingual reader;
- complete-paper diplomatic French reader;
- complete-paper corrected French reader;
- complete-paper source-aligned English reader;
- complete-paper bilingual reader.

“Sensible part-level readers” may add index or comparison projections, but no
reader may replace the complete-paper views. Every reader is generation-
addressed, rebuildable from canonical TeX, and free of workflow/AI/status prose.

### 6.3 Rights

Archival French TeX is required regardless of public projection. Public French
redistribution remains rights-aware. No inferred permission arises from
J-STAGE availability, successful build, existing archive practice, or the
scholarly value of the edition. A rights record separately states what may be
published, what remains private, what attribution is required, and whether
authority scans are excluded. In the absence of direct permission, the public
payload fails closed or is limited to authorized metadata/control surfaces.

### 6.4 Reader content boundary

Reader PDFs may contain:

- the mathematical paper;
- genuine printed footnotes and historical editorial notices;
- scholarly translation notes only when they are reader-facing mathematical
  content and clearly distinguished by layer policy;
- mathematical indexes and bibliography.

They may not contain task IDs, model names, AI badges, workflow directions,
progress claims, source-custody status, failure narration, build logs, private
paths, or archive transport notes. Those belong beside the readers in control
artifacts.

## 7. Tôhoku semantic and pre-Stacks scaffold design

### 7.1 Stable identifier grammar

IDs are language-independent and stable after admission. The proposed grammar
uses lower-case ASCII tokens while preserving printed labels as properties:

- paper: `tohoku:paper`;
- part: `tohoku:part:I`, `tohoku:part:II`;
- chapter: `tohoku:chapter:I` through the printed chapter structure;
- section/number: `tohoku:section:<printed-number>`;
- paragraph/subitem: `tohoku:<owner>:p<n>` and
  `tohoku:<owner>:subitem:<printed-label>`;
- theorem: `tohoku:theorem:<printed-number>`;
- lemma: `tohoku:lemma:<printed-number>`;
- proposition: `tohoku:proposition:<printed-number>`;
- corollary: `tohoku:corollary:<printed-number>`;
- definition: `tohoku:definition:<printed-number-or-contextual-id>`;
- remark: `tohoku:remark:<printed-number-or-contextual-id>`;
- equation: `tohoku:equation:<page>:<ordinal>` unless a stable printed label
  exists;
- diagram: `tohoku:diagram:<page>:<ordinal>` unless a source label controls;
- bibliography: `tohoku:bib:<printed-key>`;
- term: `tohoku:term:<slug>`;
- person/work: `tohoku:work:<slug>` and `tohoku:person:<slug>`.

IDs do not encode English or French wording. If an earlier ID proves wrong, a
superseding alias/migration row is appended; the old ID is never silently
reassigned to a different semantic object.

### 7.2 Core machine-readable tables

The initial scaffold must contain validated CSV or JSONL forms for:

1. `SOURCE_PAGE_MAP.csv` — official/local/printed coordinates and authority
   hashes;
2. `SEMANTIC_NODES.csv` — stable node ID, type, owner, printed label, page
   span, language labels, state;
3. `BILINGUAL_UNIT_ALIGNMENT.csv` — node ID to all three layer file/anchor
   coordinates and hashes;
4. `FORMULA_INDEX.csv` — formula ID, owner, page, source crop, TeX, rendered
   evidence, punctuation state;
5. `DIAGRAM_INDEX.csv` — diagram ID, nodes, edges, labels, native source,
   source/render evidence, review state;
6. `TERM_INDEX.csv` — French printed term, corrected term, English term,
   scope, decision IDs;
7. `REFERENCE_CANDIDATES.csv` — every detector/human candidate, source hash,
   context, candidate class, detector version;
8. `REFERENCE_EDGES.csv` — adjudicated typed edges with evidence and target
   state;
9. `REFERENCE_RESIDUALS.csv` — unresolved/rejected candidates and exact
   reasons;
10. `SUBJECT_INDEX.csv` — controlled subject labels and node memberships;
11. `BIBLIOGRAPHY_INDEX.csv` — printed keys, works, mentions, and resolution;
12. `PRESTACKS_CANDIDATES.csv` — conceptual mappings with confidence and null
    official tag by default;
13. `PRESTACKS_CONFIRMED.csv` — only directly verified target mappings;
14. `CROSS_WORK_RELATION_CANDIDATES.csv` — SGA/EGA/FGA relationship stubs
    without unauthorized external IDs;
15. `ID_MIGRATIONS.csv` — append-only supersession/alias history.

Every table declares primary keys, allowed enums, null policy, encoding,
ordering, and referential integrity. A Markdown overview may explain the
schema, but cannot substitute for the data.

### 7.3 Edge ontology

At minimum, the graph distinguishes:

- structural: `contains`, `continues_on_page`, `proof_of`, `defined_in`;
- textual: `translates`, `corrects`, `normalizes`, `supersedes`;
- logical: `uses`, `depends_on`, `implies`, `equivalent_to`, `specializes`;
- reference: `cites_internal`, `cites_bibliography`, `refers_to_diagram`,
  `refers_to_equation`;
- terminology: `names_concept`, `translation_term`, `historical_term_for`;
- cross-work: `precursor_of`, `reused_in`, `generalized_by`, `analogue_of`,
  `terminology_influences`;
- pre-Stacks: `candidate_alignment`, `confirmed_alignment`,
  `rejected_alignment`.

Logical and cross-work edges require evidence beyond co-occurrence. An
inference made by the editor is labeled as such. Source assertions and
editorial inference are different evidence types.

### 7.4 Candidate, edge, and residual closure

Every candidate receives a terminal state: admitted edge, rejected with
reason, or unresolved with an explicit hold. The following arithmetic must
reconcile per page, part, and paper:

`candidate_count = admitted_edge_count + rejected_count + unresolved_count`

This equation is necessary but not sufficient; candidate-universe coverage
must also pass. Detectors are versioned and rerun after any source hash change.
Human-found candidates are not excluded merely because no detector emitted
them. Residuals remain visible and prevent broad closure claims when in scope.

### 7.5 Pre-Stacks migration map

The scaffold is designed for later Stacks-style conversion without pretending
that Tôhoku is already written in Stacks form. Each semantic node records:

- prerequisites;
- defined terms;
- statement and proof boundaries;
- formula/diagram dependencies;
- internal and bibliography references;
- candidate modern concepts;
- source-era terminology;
- confidence and evidence;
- unresolved issues.

Later migration can map these nodes into a chapter/section/lemma graph or
another formal corpus without re-parsing page prose. Official Stacks tags are
only an optional verified target property. The primary deliverable is a stable,
source-grounded semantic graph.

## 8. Project-specific do-not-repeat checklist

Before touching a new printed page, answer every item `YES`:

- [ ] Was the corrected precedence-first bootstrap replayed for this session?
- [ ] Is the exact Tôhoku goal active and does it include all three layers,
      readers, indexes, and pre-Stacks graph?
- [ ] Is live ownership still non-overlapping?
- [ ] Are the official PDF and admitted local-witness hashes unchanged?
- [ ] Is the command bounded to exact named Tôhoku inputs?
- [ ] Is no other heavy process running?
- [ ] Is the source page mapped by official, printed, and local coordinates?
- [ ] Is the broad render in the 1,100--1,800 dpi-equivalent range unless a
      named ambiguity justifies higher zoom?
- [ ] Will the lead, not a subagent or detector, make every mathematical and
      visual decision?
- [ ] Are diplomatic French, corrected French, and English destinations
      distinct before transcription begins?
- [ ] Will every normalization/correction/translation receive a stable record
      and inverse?
- [ ] Are formulas, diagrams, references, and bibliography mentions being
      inventoried from the page rather than from known syntax classes?
- [ ] Will a source-byte change invalidate derived candidates?
- [ ] Is the next build/output path generation-addressed and no-overwrite?

Before closing a page, answer every item `YES`:

- [ ] Did direct authority decide every admitted mark?
- [ ] Does diplomatic French retain all printed accents, spelling, punctuation,
      numbering, formula symbols, footnotes, and page seam?
- [ ] Are corrected-French differences exhausted by the correction ledger?
- [ ] Are English differences exhausted by translation decisions?
- [ ] Did the lead inspect each formula/diagram at sufficient resolution?
- [ ] Does every diagram have native TeX or an explicit open debt that blocks
      release?
- [ ] Do candidate, edge, rejection, and residual totals reconcile?
- [ ] Are all new semantic IDs unique and referentially valid?
- [ ] Did every changed source trigger downstream invalidation?
- [ ] Is the next cursor exact and recorded in co-current state?

Before any reader/package/public claim, answer every item `YES`:

- [ ] Does expected-unit scope equal built scope?
- [ ] Are all three textual layers complete for the claimed range?
- [ ] Are formula and native-diagram inventories complete for the claimed
      range?
- [ ] Is the reference claim scoped exactly and are all in-scope residuals
      closed?
- [ ] Does the semantic/pre-Stacks data pass schemas and integrity checks?
- [ ] Was the reader scanned on every page and in metadata for workflow, AI,
      status, and private-path leakage?
- [ ] Were manifests generated from final bytes and independently replayed?
- [ ] Did recursive privacy validation distinguish events from affected
      records and run shape-based residual scans?
- [ ] Is rights disposition explicit and independent of technical success?
- [ ] Are concept, version, record, draft, branch, PR, merge, and public bytes
      separately identified?
- [ ] If externally published, did anonymous raw readback match every loose
      file and archive member byte-for-byte?

Any `NO` is a fail-close, not a promise to fix after publication.

## 9. Required failure topics: evidence-to-control matrix

This section makes explicit that every topic in the controlling mandate has an
evidence-backed disposition. The detailed recurrence tests live in
`FAILURE_MODE_REGISTER.csv` and the executable rules in
`BINDING_SAFEGUARDS.md`.

| Mandated topic | Evidence-backed finding | Stable register rows | Binding result |
|---|---|---|---|
| English-first production omitted French layers | EGA English corpus closed before diplomatic/corrected French deliverables; direct-French replay forced rework | `TOH-FM-001`, `TOH-FM-002` | Three layers advance together |
| English-only presented as broader completion | Complete linked English and global claims exceeded source/layer or unit scope | `TOH-FM-001`, `TOH-FM-022` | Claim names language layers and exact expected set |
| Layer conflation | Printed error, corrected source, English repair, comparison, and publication could not coexist truthfully in one tree | `TOH-FM-002`, `TOH-FM-003`, `TOH-FM-004` | Explicit role enum and interlayer diff closure |
| Silent normalization/correction | `1°/2°`, `n≥0`, proof square, and 14-byte drift examples | `TOH-FM-003`, `TOH-FM-004` | Stable IDs, inverse, and append-only reversals |
| OCR/scan/reconstructed TeX treated too strongly | 1,368-page coverage coexisted with 35 errors and source defects; reconstructed prose/diagrams were unreliable | `TOH-FM-005` | Direct official image is authority; no new OCR |
| Weak source/page/formula/diagram mapping | Small marks and label sides survived broad review | `TOH-FM-006` | Triple page coordinates, per-object inventory, lead review |
| Low-resolution approval | Contact sheets and ordinary builds did not resolve microglyphs | `TOH-FM-006` | 1,100--1,800 broad; 5,000--9,000 for ambiguity |
| False diagram closure | 41 active raster calls existed in a unit declared zero | `TOH-FM-007` | Inventory from final dependency graph; negative evidence for zero |
| Raster delivery | Temporary debt escaped into cumulative reader | `TOH-FM-008` | Native TeX; zero source/package/PDF raster tests |
| Superficial reference-v2 | Local link closure and GoTo checks were generalized | `TOH-FM-011`, `TOH-FM-020` | Separate link, candidate, edge, residual, and implication states |
| Missing reusable pre-Stacks scaffold | Markdown scaffold deferred machine schemas and closure | `TOH-FM-012` | Validated bilingual node/edge/candidate/residual tables |
| Invented Stacks mappings | No incident proved; risk explicitly controlled | `TOH-FM-013` | Official tag null unless exact verified citation |
| Stale manifests/canonicalization | R2/R3 defects; R4 needed independent replay | `TOH-FM-014`, `TOH-FM-033` | Frozen final bytes and declared canonicalization |
| Cached full-log rewrites | One admitted record disappeared during regression | `TOH-FM-015` | Lock-held one-record append and rollback |
| Duplicate IDs | No incident found; structural hazard remains | `TOH-FM-016` | Duplicate rejection under lock |
| Workflow/AI/status prose in readers | Repeated cleanup; full status note persisted on cumulative p.2 | `TOH-FM-017` | All-page reader-surface gate |
| Private-path leakage and false counts | 2,416 events corrected preliminary counts; nine UUIDs survived v1 | `TOH-FM-018`, `TOH-FM-019` | Recursive event ledger plus independent shape scans |
| Duplicate/incorrect archive concepts/transports | Wrong DOIs and draft duplication pressure; no proved duplicate concept | `TOH-FM-023`, `TOH-FM-024` | Exact transport tuple and one tracked draft |
| Weak raw public readback | Nineteen files normalized after merge | `TOH-FM-021` | Commit/record-pinned anonymous byte replay |
| False completion from narrow build | Corrected EGA0 scope was §0.23; closeout used §0.13 | `TOH-FM-022` | Expected-unit set equality |
| Unbounded scans/heavy concurrency | Broad Documents search, huge images, twenty high-res bands, duplicate R2 jobs | `TOH-FM-026`, `TOH-FM-030` | Exact allowlists, one heavy process, session polling |
| Weak handoff/compactification loss | Stale p.77 status, nonchronological log, unacknowledged GAGA relay | `TOH-FM-027`, `TOH-FM-028` | Generated current state and hash-bound acknowledgment |
| Unlogged editorial/model choices | Multiple precise EGA changes and reversals | `TOH-FM-003`, `TOH-FM-004`, `TOH-FM-025` | Every choice and inverse logged |
| Failure to propagate global repair | p.69 seven-copy debt, SGA6 missing public footnote, stale coordination hash | `TOH-FM-025` | Downstream impact set and obsolete-reading replay |
| Rights inferred from technical success | Rights holds remained independently unresolved | `TOH-FM-034` | Separate manifest-bound rights gate |
| Current Tôhoku precedence failure | User deleted pre-reread goal | `TOH-FM-028`, `TOH-FM-031` | Corrected reread then exact goal |
| Current Tôhoku p.119 source failure | Systematic diacritic loss under false high-confidence review | `TOH-FM-029` | Hard stop and append-only p.119 repair |
| Current build-generation weakness | Fixed final PDF names conflict with later no-overwrite correction | `TOH-FM-032` | Generation-addressed output and explicit promotion |

## 10. Bounded operating protocol

### 10.1 Session start

1. Read the latest immutable current-state receipt.
2. Replay the retrospective validation and artifact hashes.
3. Rehash the two official PDFs and local witness.
4. Confirm live ownership/no-overlap.
5. Inspect active process state.
6. Declare exactly one page or bounded unit as the session target.
7. Declare the exact files to be read and written.
8. Refuse any command whose resolved search root is a profile, all Documents,
   a drive root, or an unrelated corpus.

### 10.2 Page production loop

1. Map official PDF page, printed page, and local page.
2. Render a broad page image at approximately 1,100--1,800 dpi-equivalent.
3. Read the entire page directly; use extraction only to navigate.
4. Enumerate source units, footnotes, formulas, diagrams, references, terms,
   bibliography mentions, and page seams.
5. Create diplomatic French first, preserving every printed mark.
6. Compare diplomatic output against the source by feature class: letters,
   accents, punctuation, numbering, formulas, labels, and layout-significant
   boundaries.
7. Record every permitted normalization.
8. Adjudicate source errors separately; create corrected French.
9. Translate from corrected French while aligning to diplomatic coordinates.
10. Add or update shared semantic nodes and all candidate inventories.
11. Generate one high-resolution crop at a time only for named ambiguities.
12. Lead adjudicates formulas, diagrams, and mathematical wording.
13. Append decisions, corrections, translations, and reversals using unique
    IDs and downstream impact sets.
14. Invalidate derived candidates for every changed source hash.
15. Run bounded structural checks; do not run a full build unless a milestone
    or substantive integration change justifies it.
16. Freeze a generation-addressed page checkpoint and exact next cursor.

### 10.3 Milestone build loop

At a meaningful section, chapter, or part boundary:

1. derive the expected unit set from the canonical page/unit map;
2. derive active TeX dependencies from intended masters;
3. reconcile every page, layer, formula, diagram, and semantic node;
4. run native-diagram and raster-object tests;
5. build one generation in one heavy process;
6. render and visually inspect representative pages and every special-layout
   or ambiguity-bearing page;
7. scan every reader page and metadata for forbidden project prose;
8. generate manifests only after final bytes;
9. independently replay manifests;
10. generate co-current state and checkpoint receipts.

### 10.4 Package and publication loop

Only if separately authorized:

1. decide rights scope;
2. project a privacy-clean control set from preserved private controls;
3. recursively ledger transformations and run independent residual detectors;
4. validate CSV cells against formula-trigger semantics;
5. create a no-overwrite package from an explicit membership allowlist;
6. replay every loose file and every archive member;
7. validate the concept/record/version/draft tuple;
8. perform the authorized transport;
9. anonymously read back every public object;
10. compare exact bytes, hashes, paths, CRCs, membership, and aggregate;
11. append the public receipt without rewriting earlier failures.

## 11. Application to the current Tôhoku root

### 11.1 Artifacts retained as adverse history

The following pre-correction artifacts are not deleted, overwritten, or called
canonical:

- the original intake/ownership record and its bootstrap self-attestation;
- the deleted pre-reread goal as described by the controlling user;
- the first adverse authority comparator;
- the duplicate R2 execution note;
- the p.119 diplomatic French with stripped diacritics;
- the p.119 corrected French with the same stripping;
- the active p.119 no-correction disposition;
- the p.119 English and translation decisions pending rebinding;
- the status and continuation handoff that say p.119 is admitted and p.120 is
  next;
- the build script with fixed final output names.

Their preservation is essential. Deleting or silently editing them would erase
the evidence needed to test the new controls.

### 11.2 Required repair before p.120

The next substantive production action is not p.120. It is a no-overwrite
p.119 repair generation:

1. freeze and rehash the current adverse p.119 files and ledgers;
2. reopen official Part I page 1 at broad reading scale;
3. create targeted high-resolution crops only for genuinely ambiguous small
   marks;
4. enumerate every French diacritic and source mark from the image;
5. create a new diplomatic p.119 artifact without overwriting the adverse one;
6. append a superseding transcription record that names the old decision and
   every corrected glyph category;
7. separately adjudicate authorial/source corrections and supersede the old
   no-correction disposition as required;
8. create corrected French from the repaired diplomatic layer;
9. replay all English translation decisions against the repaired source;
10. update stable semantic nodes, terms, references, and page alignment;
11. create a global repair record covering status, handoff, readers, indexes,
    and future packages;
12. redesign build outputs to be generation-addressed;
13. build and render the p.119 checkpoint once;
14. validate the three-layer diff and reader surface;
15. only then set the next cursor to p.120.

The correction must not assume that every unaccented ASCII form has the modern
dictionary accent. Direct authority decides each printed glyph. The diplomatic
layer preserves historical French exactly even where modern style differs.

### 11.3 Sequential continuation after repair

After p.119 closes, production advances sequentially through printed p.221.
Pages are not skipped because text extraction is easy, because a page has no
formula, or because a later chapter seems more mathematically interesting.
Part I ends at p.183; the blank interleaf is recorded; Part II begins at p.185.
The paper's bibliography at p.221 is part of the corpus and the hard stop.

The first checkpoint after the retrospective must be materially bilingual,
not an intake-only status. The repaired p.119 checkpoint satisfies this only
when all three layers, decisions, shared semantic units, and validation are
durable.

## 12. Open risks after the retrospective

The retrospective can close as an evidence product while leaving corpus risks
open. Those risks are not retrospective validation errors if they are
truthfully registered and bound to a future gate.

1. **p.119 exact glyph repair** — open and blocking p.120.
2. **p.119 source-correction disposition** — suspended pending repaired direct
   replay.
3. **English p.119 rebinding** — translation wording may remain sound but its
   provenance chain is currently defective.
4. **Build output addressing** — fixed final names require no-overwrite
   successor design.
5. **Full semantic schema implementation** — design is bound here; tables and
   validators must be implemented during production.
6. **Cross-work relation confirmation** — Tôhoku-side candidates may be
   recorded, but SGA/EGA/FGA target IDs remain null until an authorized owner
   joins them.
7. **Official Stacks mappings** — none may be asserted from memory; later
   official verification is required.
8. **Rights disposition** — private archival production may continue; public
   French scope remains unresolved until direct rights evidence exists.
9. **Final comparator replay** — R2 summary is admitted for intake; final
   closure must replay every row and full identity.
10. **Complete-paper scope** — no claim beyond repaired p.119 is currently
    permitted.

## 13. Successor continuation record

### 13.1 Durable objective

Produce a complete canonical bilingual scholarly edition of both published
parts of Alexandre Grothendieck's *Sur quelques points d'algèbre homologique*,
Tôhoku Mathematical Journal (Second Series), volume 9 (1957), pp.119--221.
Deliver diplomatic French, separately corrected French, source-aligned
English, one complete paper reader plus sensible part-level readers, complete
semantic references/indexes, and a pre-Stacks graph.

### 13.2 Controlling scope and exclusions

- exclusive corpus: this Tôhoku paper, printed pp.119--221;
- opening source page: p.119;
- terminal hard stop: p.221;
- local blank interleaf: physical page 66 between printed pp.183 and 185;
- no FGA, other Grothendieck paper, EGA, SGA, Verdier, or Illusie source work;
- predecessor controls may be read only by exact path for provenance;
- no authority/predecessor mutation;
- no new OCR;
- no broad search;
- one heavy process at a time.

### 13.3 Current valid state

- corrected precedence-first handoff and precedent reread: complete;
- current exact durable goal: active;
- minimum 100,000-token retrospective floor: exceeded according to the goal
  tracker, but closure depends on artifact validation, not the number alone;
- source evidence inventory: complete through EOF for the bounded manifest;
- retrospective audit, failure register, safeguards, and assumption/reversal
  ledger: created in the no-overwrite control root;
- source manifest and validation JSON: must be frozen and PASS before the
  retrospective checkpoint is declared durable;
- corpus production cursor: **p.119 repair**, not p.120;
- current p.119 French state: FAIL/HOLD as described above;
- next authorized substantive action after retrospective PASS: create the
  append-only, direct-authority p.119 repair generation.

### 13.4 Exact authority identities

- official Part I: 7,305,283 bytes,
  `5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`;
- official Part II: 3,984,260 bytes,
  `8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53`;
- local witness: 12,897,534 bytes,
  `57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78`.

### 13.5 Required successor acknowledgment

Before mutation, a successor must write a hash-bound acknowledgment that:

1. reproduces the exact objective above;
2. reproduces all three authority identities;
3. replays every retrospective artifact hash and validation;
4. confirms current ownership/no-overlap;
5. states that the cursor is p.119 repair;
6. lists all p.119 adverse identities and the old no-correction record;
7. repeats the exact no-OCR, bounded-search, and one-heavy-process controls;
8. identifies one next bounded action.

If any item differs, the successor must stop and append a discrepancy record.
It may not infer the missing state from chat, a stale STATUS heading, or file
existence.

## 14. Effort accounting and closure rule

The controlling user defined 100,000 tokens as the minimum retrospective
effort, not the maximum and not a requested output length. The task's durable
goal tracker is the only available direct token counter. A pre-finalization
snapshot recorded 759,671 goal tokens used, already above the floor. That
number includes the corrected precedence reread, bounded predecessor EOF reads,
forensic analysis, agent evidence passes, and artifact drafting under the
current goal; it is not represented as the word count of this Markdown file.

The exact final snapshot is written into the validation JSON when the
retrospective artifacts have frozen. The retrospective is not complete merely
because the counter exceeds 100,000. Closure additionally requires:

- every mandated artifact exists;
- every file parses as its declared format;
- stable IDs are unique;
- all mandatory failure topics map to register rows;
- safeguards contain executable stop conditions;
- the assumption/reversal ledger covers inherited assumptions and current
  adverse reversals;
- the source manifest replays exact bytes/hashes or explicitly classified
  live-snapshot semantics;
- privacy-clean root aliases replace private absolute paths in public-facing
  retrospective artifacts;
- the continuation record is sufficient to recover purpose and cursor;
- final artifact hashes are generated from frozen bytes;
- validation reports `PASS` and `errors=[]`.

Only after that durable checkpoint may p.119 repair begin. The retrospective
is a first-stage deliverable, not an excuse to abandon the full bilingual
paper.
