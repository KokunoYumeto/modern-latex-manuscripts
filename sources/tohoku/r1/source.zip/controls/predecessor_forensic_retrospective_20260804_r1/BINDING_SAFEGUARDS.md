# Binding safeguards for the Tôhoku canonical bilingual corpus

Control generation: `predecessor_forensic_retrospective_20260804_r1`  
Bound corpus: Grothendieck, *Sur quelques points d'algèbre homologique*, both
published parts, printed pp.119--221  
Status: binding for every production action after the corrected
precedence-first bootstrap  
Authority boundary: official J-STAGE Part I DOI
`10.2748/tmj/1178244839`, official J-STAGE Part II DOI
`10.2748/tmj/1178244774`, and the admitted 103-page local comparison witness
only after pagewise binding

## 1. Purpose and priority

These safeguards convert the predecessor retrospective into executable
conditions. They are not recommendations. A later convenience, successful
build, plausible reconstruction, deadline, context loss, or compactification
cannot waive them. If a control conflicts with a direct authority image, the
direct authority wins. If a later user instruction changes the scope, that
instruction is logged append-only and the affected controls are replayed.

The corpus has one durable objective: produce a complete canonical bilingual
scholarly edition of both published parts of Grothendieck's Tôhoku paper,
printed pp.119--221, with diplomatic French, separately corrected French,
source-aligned English, one complete-paper reader and sensible part-level
readers, complete semantic references and indexes, and a pre-Stacks graph.

No completion claim is permitted until every gate in section 16 that applies
to the claim is independently PASS. A narrower PASS may never be promoted to
a broader claim.

## 2. Precedence-first bootstrap gate

Before any new production generation or successor session mutates the corpus,
the acting lead must:

1. read `00_START_HERE.md` and `TOHOKU/README_START_HERE.md` first;
2. read every file in the common handoff through EOF;
3. read every exact row of `04_PRECEDENT_READING_LIST.csv` through EOF;
4. rehash every precedent and classify it as exact, expected live successor,
   frozen-prefix match, or unexplained drift;
5. replay `HANDOFF_SHA256SUMS.csv` and `HANDOFF_VALIDATION.json`;
6. rehash the named authority inputs;
7. inspect live task ownership and record exact no-overlap;
8. only then create or replace a durable pursuit goal;
9. only then create a prescribed no-overwrite successor root.

Fail closed if the read order cannot be proved, any required file is unread,
an identity change is unexplained, ownership overlaps, or the goal omits any
required deliverable. A file that merely asserts that the bootstrap happened
is not proof when direct user evidence or task chronology defeats the claim.

The pre-correction Tôhoku intake, its original goal, and its p.119 artifacts
remain adverse history. They are never deleted or silently treated as a valid
precedence-first generation.

## 3. Scope and ownership gate

The exclusive textual scope is the two published parts of this paper,
printed pp.119--221. The blank physical interleaf between printed pp.183 and
185 is an authority-boundary record, not invented printed p.184 text.

Forbidden scope:

- FGA;
- any other Grothendieck paper;
- EGA source production;
- SGA source production;
- Verdier;
- Illusie;
- unrelated archival or publication mutation.

Predecessor controls and failure receipts may be read only when exactly named
for this retrospective. They may never be mutated. Every production session
records current task ownership and no-overlap. Any second live Tôhoku owner or
ambiguous boundary is a hard stop.

## 4. Authority and witness hierarchy

The authority hierarchy is:

1. direct rendered image of the official J-STAGE PDF for the relevant part;
2. the admitted local 103-page witness, only for pages whose official/local
   image equivalence has passed the frozen comparator and human boundary check;
3. reconstructed TeX, extraction, or OCR as locator/drafting evidence only;
4. external translations as comparison lineage only.

No OCR may be generated for this corpus. Existing OCR, extracted text, or TeX
cannot decide a word, symbol, formula, diagram, punctuation mark, page seam, or
correction. A successful TeX build proves only that TeX compiled.

Every admitted source unit must bind:

- authority ID and SHA-256;
- official PDF page;
- printed page;
- local-witness page where applicable;
- stable semantic unit ID;
- review scale and crop identity when a small mark is adjudicated;
- lead disposition and confidence;
- any unresolved ambiguity.

If the authority image and any derivative disagree, the derivative is wrong
until a separately logged source correction proves otherwise.

## 5. Three-layer textual invariant

Diplomatic French, corrected French, and source-aligned English are three
distinct layers even when their visible wording is identical.

### 5.1 Diplomatic French

The diplomatic layer preserves the printed lexical content, spelling,
diacritics, mathematical symbols, numbering, punctuation, source errors,
footnote attachment, paragraph structure, and printed-page seams. It may
normalize scan-imposed line wrapping and discretionary line-end word division
only when the normalization is explicitly logged and mechanically reversible.

It may not silently:

- remove or add accents;
- modernize spelling;
- alter `1°`, `2°`, or any enumeration;
- change inequalities, indices, primes, star/shriek marks, arrows, or labels;
- repair a source error;
- complete a sentence across a printed-page boundary without preserving that
  boundary;
- import wording needed only by the corrected or English layer.

### 5.2 Corrected French

The corrected layer starts from the diplomatic layer and differs only through
an admitted source-correction record. Each correction must state the printed
reading, corrected reading, error class, mathematical/editorial rationale,
evidence, affected IDs, downstream surfaces, confidence, and inverse. “No
correction” is a positive page disposition and must be reversed if later
evidence proves even one source-level correction.

### 5.3 Source-aligned English

The English layer translates the corrected French while remaining explicitly
aligned to the diplomatic source coordinate. It may explain but not erase a
source correction. Mathematical terminology is stable corpus-wide unless a
logged context-specific exception applies.

### 5.4 Layer tests

For every page:

- three source files or three unambiguous layer records exist;
- every unit ID exists in all applicable layers;
- differences between diplomatic and corrected French are exhausted by the
  correction ledger;
- differences between corrected French and English are exhausted by the
  translation ledger;
- comparison witnesses have `authority=false`;
- public projection is not confused with any source layer.

The current p.119 files fail this gate because both French layers strip
printed diacritics while the corrected layer declares no correction. They must
be superseded append-only before p.120 production.

## 6. Append-only decision, normalization, correction, and reversal controls

Every non-byte-identical editorial intervention requires a stable unique ID.
The minimum record schema is:

- record ID;
- UTC timestamp;
- corpus and layer;
- authority identity;
- source coordinate and semantic unit;
- exact observed reading;
- selected reading or operation;
- rejected alternatives;
- classification;
- rationale;
- evidence channel and inspection detail;
- confidence and unresolved ambiguity;
- affected IDs and downstream files;
- state;
- supersedes/reverses link;
- exact inverse or replay instruction.

No existing record is rewritten to conceal a mistake. A later finding appends
a superseding record and a global repair record. The adverse decision remains
readable. Formatting changes are not exempt: a 14-byte unlogged drift is still
an unlogged mutation.

A global correction must enumerate its impact set across:

- diplomatic French;
- corrected French;
- English;
- semantic nodes, edges, candidates, residuals, and indexes;
- standalone readers;
- part readers;
- complete reader;
- build manifests;
- privacy-clean package;
- archive/public records if any.

Promotion stops until every affected surface is either regenerated and
rehashed or explicitly proved unaffected.

## 7. Visual, formula, and diagram adjudication

The lead owns mathematical and visual judgment. Delegated or automated work
may prepare bounded crops, inventories, hashes, and candidate comparisons; it
may not issue the final visual PASS.

Use approximately 1,100--1,800 dpi-equivalent for broad reading. Use
approximately 5,000--9,000 dpi-equivalent only for genuinely small or
ambiguous marks. Never load many huge bands concurrently. A contact sheet,
thumbnail, nominal PDF DPI, file size, compilation, or code inspection is not
a microglyph PASS.

Every formula-bearing page requires:

- formula inventory and stable IDs;
- source/delivery coordinates;
- exact symbol, delimiter, index, prime, arrow, and punctuation review;
- native TeX source;
- rendered comparison at a scale fit for the smallest ambiguous mark;
- lead disposition.

Every diagram requires:

- stable diagram ID;
- source page and semantic owner;
- full node/edge/arrow/label inventory;
- label-side and direction adjudication from rendered output;
- authority image/crop hashes;
- native TeX source;
- zero raster fallback in delivered source;
- zero raster image object in delivered PDFs.

The inventory is generated from the final active dependency graph and every
diagram-call class, not from known folders or nonzero units. Every claimed-zero
unit receives an explicit row with negative-source evidence. A source hash
change invalidates every derived diagram/reference candidate until regenerated.

## 8. Native-TeX delivery gate

All delivered diagrams are native TeX. Raster witnesses may exist only in a
private, clearly marked review-evidence area and never as active reader
dependencies or package contents.

Release tests independently require:

1. zero active raster diagram calls in all final TeX dependencies;
2. zero raster diagram files in the delivery package;
3. zero relevant PDF image objects as independently inspected;
4. native-source count equal to the semantic diagram inventory;
5. direct-authority lead review complete for every diagram.

Any nonzero result fails the relevant reader and package. A cumulative build
that excludes a claimed-zero unit is not a test of that unit.

## 9. Shared semantic graph and reference completeness

The stable semantic graph is shared across languages. Language strings are
properties or projections of stable semantic nodes; they are not independent
graphs whose IDs can drift.

Required machine-readable surfaces include at least:

- source page map;
- semantic node inventory;
- bilingual text-unit alignment;
- theorem/definition/lemma/proposition/corollary/example/remark inventory;
- formula inventory;
- diagram inventory;
- terminology index;
- person/work bibliography index;
- internal reference candidates;
- adjudicated reference edges;
- unresolved residuals;
- subject index;
- pre-Stacks alignment candidates;
- confirmed pre-Stacks alignments, if any;
- rejected mappings and reasons.

Every table has a declared schema, stable unique key, referential-integrity
checks, source evidence, confidence, and state. Coordinates, dimensions,
version numbers, TeX geometry, and style arguments are excluded from reference
detection unless positively adjudicated as source references.

Reference claims are separately scoped:

- syntactic candidate coverage;
- local target resolution;
- cross-part resolution;
- bibliography resolution;
- semantic edge adjudication;
- residual closure;
- implication closure;
- PDF-link validity.

Zero broken PDF links does not imply semantic completeness. “Reference
complete” is forbidden while any declared candidate, edge, or residual class
is unenumerated or any in-scope residual is open.

## 10. Pre-Stacks mapping controls

The pre-Stacks scaffold is an evidence-bearing conceptual map, not a license
to retrofit modern terminology or invent official Stacks tags.

For each candidate mapping record:

- Tôhoku semantic node ID;
- source coordinate and exact proposition/definition context;
- target concept description;
- target citation or official tag only if directly verified;
- relation type (`precursor`, `analogue`, `special_case`, `used_by`,
  `terminology_overlap`, or other declared type);
- evidence;
- confidence;
- status (`candidate`, `confirmed`, `rejected`, `unresolved`);
- adjudicator and date.

The official Stacks tag field remains null unless an exact official citation
has been verified. A plausible memory match is not evidence. Candidate and
confirmed mappings are counted separately. Rejections remain append-only.

## 11. Manifest and generation integrity

Every generation is no-overwrite. Failed generations remain adverse history.
Manifests are generated only after the bytes they describe are frozen.

Each manifest contract declares:

- path normalization;
- encoding;
- row ordering;
- case normalization, if any;
- separators;
- line ending and final-newline rule;
- whether the manifest excludes itself;
- aggregate construction.

Validation requires:

- every row exists;
- exact byte count and SHA-256;
- unique normalized paths;
- exact expected membership;
- aggregate reproduced independently;
- first and last canonical paths recorded;
- no null totals;
- no mislabeled listed-order hash;
- co-current status and validation identities.

Live files that are permitted to advance must be snapshot-labeled. A frozen
prefix plus later append is not “same file”; it is an explicitly classified
live successor. Unexplained drift is a hard stop.

## 12. Shared-log mutation

No cached whole-file rewrite of a shared log is permitted. A shared ledger
append must:

1. acquire an exclusive writer lock;
2. reread the live file while locked;
3. reject a duplicate ID before mutation;
4. append one record only;
5. flush to storage;
6. validate JSON/JSONL structure, record count, unique IDs, latest ID, bytes,
   and SHA-256 while still locked;
7. truncate back to the original length on validation failure;
8. release only after a durable receipt.

Tôhoku-local ledgers use the same one-record append discipline even when no
other writer is expected. Direct editor replacement of prior records is
forbidden.

## 13. Reader-surface and privacy gate

Reader PDFs contain mathematical and genuine source-era editorial content.
They do not contain:

- AI/model references or badges;
- task/session/thread IDs;
- workflow instructions;
- status, progress, failure, or correction narration;
- source-custody or publication-process notes;
- private paths;
- build logs or internal decision ledgers.

Such material belongs in external controls. Before any reader is released,
run a bounded all-page text and metadata scan, then visually inspect relevant
rendered pages. Use an allowlist for genuine source-era notices; do not delete
historical editorial matter merely because a keyword resembles workflow
language.

Privacy validation recursively traverses every string in JSON, CSV, TeX,
Markdown, PDF metadata/text, loose files, and archive members. It records
replacement events by record and field path. It runs both known-token and
shape-based detectors, including UUIDs without a leading-word-boundary
assumption. Record counts, affected-record counts, and occurrence counts are
reported separately. A privacy-clean projection preserves decision IDs and
record order and never rewrites the private raw ledger.

## 14. Packaging, transport, public readback, and rights

The following identities remain distinct fields:

- logical corpus;
- source authority;
- working generation;
- reader generation;
- package generation;
- concept DOI;
- version DOI;
- record ID;
- deposition/draft ID;
- branch;
- pull request;
- merge commit;
- raw-public object identity.

A push is not a pull request; a merge is not a byte-exact public readback; a
concept DOI is not a version DOI. Existing archive concepts are reused, and a
logical payload has one tracked draft per intended concept. No publication or
external write is authorized merely by this document.

Public-readback tests download every commit-pinned or record-pinned loose
object anonymously and compare bytes and SHA-256. Archives also require path,
CRC, member count, and every member identity. Line-ending or clean-filter
normalization is a failure even if the repository merge succeeded.

Rights are a separate gate. Build success and textual scholarship do not
establish public redistribution authority. Archival French TeX is preserved;
any public French projection remains rights-aware and carries an exact rights
disposition. Authority scans are not placed in a public package unless direct
permission is established.

## 15. Resource-safety and concurrency gate

All searches are bounded to exact named files or exact project/control roots.
Never search all of `Documents`, a user profile, a drive root, or a broad
archive tree. Never regenerate OCR.

Before a heavy render, image comparison, or build:

1. inspect the relevant process/session state;
2. ensure no other heavy process for this task is active;
3. record the exact bounded input set and intended output path;
4. use one heavy process at a time;
5. capture and poll the returned session ID;
6. do not retry merely because asynchronous output is delayed;
7. use a no-overwrite target;
8. audit that no process remains after completion.

Broad reading uses 1,100--1,800 dpi-equivalent. High zoom is generated only
for a named ambiguous mark and released before the next. Rebuilding without a
substantive source or control change is forbidden.

## 16. Distinct release gates

The following gates are logically independent and must never be collapsed:

1. **Bootstrap PASS** — precedence-first order, exact goal, ownership.
2. **Authority PASS** — official/local binding and page boundary.
3. **Diplomatic PASS** — direct authority fidelity.
4. **Correction PASS** — every difference logged and reversible.
5. **Translation PASS** — source-aligned English and terminology review.
6. **Formula PASS** — exhaustive formula inventory and visual review.
7. **Diagram PASS** — exhaustive native-TeX inventory and zero raster debt.
8. **Semantic PASS** — schema, IDs, integrity, candidates, edges, residuals.
9. **Reference PASS** — claim-specific candidate/edge/residual closure.
10. **Build PASS** — intended full scope compiles reproducibly.
11. **Reader-surface PASS** — no workflow/AI/status leakage.
12. **Manifest PASS** — exact co-current bytes and independent replay.
13. **Privacy PASS** — recursive event ledger and residual scans.
14. **Rights PASS** — direct publication/redistribution disposition.
15. **Package PASS** — intended membership and archive-member replay.
16. **Transport PASS** — correct concept/record/draft/branch/merge identities.
17. **Public-readback PASS** — exact anonymous bytes after publication.

A claim names its gate set and exact scope. “Complete” is permitted only when
the expected unit set for pp.119--221 equals the built and validated unit set,
all required layers and semantic surfaces close, and all applicable gates pass.

## 17. Current fail-close conditions

Production must stop immediately if any of the following occurs:

- a required precedence file has not been read through EOF;
- the durable objective is missing or was created before required precedence;
- authority hash or page map is unexplained;
- another live task owns Tôhoku content;
- a diplomatic reading is made from OCR/extraction rather than direct image;
- a French diacritic, symbol, numbering mark, or formula differs without a
  ledger record;
- diplomatic and corrected French are conflated;
- an official Stacks tag lacks exact verified evidence;
- a diagram inventory omits a claimed-zero unit or active dependency;
- a delivered diagram is raster-backed;
- a source hash changes without invalidating derived candidates;
- a global repair leaves an active projection stale;
- a shared log cannot be locked and replayed;
- a manifest is generated before final bytes or cannot reproduce its contract;
- a reader contains project/workflow/AI/status prose;
- privacy counts conflate events, matches, and affected records;
- a package or public object cannot be anonymously read back byte-exact;
- rights are assumed from build or publication mechanics;
- a completion claim exceeds the expected-unit matrix;
- a search or render exceeds the bounded resource policy;
- an asynchronous heavy task is retried without first resolving its session.

## 18. Recurrence audit cadence

At each admitted printed page:

- rehash the page-source inputs;
- close the three-layer diff;
- append decisions and reversals;
- update formula, diagram, reference, and semantic inventories;
- run bounded structural validation;
- record next cursor.

At each chapter/part boundary:

- replay the expected-unit matrix;
- run a corpus-wide obsolete-reading search over a declared allowlist;
- rebuild all active projections once;
- inspect reader surfaces;
- seal co-current manifests and state.

At final pp.119--221 closure:

- replay all seventeen applicable gates;
- generate a privacy-clean package and exact handoff;
- preserve private archival French TeX and evidence;
- state public French rights disposition without inference;
- include a generated `CURRENT_STATE.json` so a successor never has to recover
  purpose, scope, cursor, or live identities from chat history.

## 19. Successor continuation contract

A successor must read this file, the forensic audit, failure register,
assumption/reversal ledger, source manifest, and validation JSON through EOF.
It must then replay their hashes, the current-state receipt, authority hashes,
and ownership before mutation. Its acknowledgment must restate:

- exact durable objective;
- printed-page scope and hard stop;
- authority hierarchy;
- current admitted page and next cursor;
- open failures and holds;
- active artifact identities;
- one next bounded action.

If any item cannot be reproduced, the successor fails closed and records the
discrepancy. File existence alone is not acknowledgment, and chat memory is not
continuation state.
