# Tohoku canonical bilingual edition

This private production root contains three non-collapsed textual layers for
Alexandre Grothendieck's *Sur quelques points d'algebre homologique*:

- `tex/fr_diplomatic`: source-faithful French;
- `tex/fr_corrected`: copy-on-write corrected French;
- `tex/en`: source-aligned English.

Reader sources are under `tex/readers`; generated PDFs are placed under
`output/pdf`. Machine-readable semantic files are under `semantics`. Authority,
decision, correction, normalization, reversal, build, and continuation records
remain outside reader bodies.

Build a new immutable gate from this root with:

```powershell
powershell -NoProfile -File .\tools\build_readers.ps1 -Gate gate_001
```

Choose a new gate name for every later cumulative build. The script fails
closed if either a build gate or final PDF target already exists.

