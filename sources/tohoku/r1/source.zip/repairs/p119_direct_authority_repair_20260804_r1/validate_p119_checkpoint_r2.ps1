param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$repairRoot = $PSScriptRoot
$projectRoot = Split-Path -Parent (Split-Path -Parent $repairRoot)
$manifestPath = Join-Path $repairRoot 'CHECKPOINT_MANIFEST_R2.csv'
$validationPath = Join-Path $repairRoot 'CHECKPOINT_VALIDATION_R2.json'

if (Test-Path -LiteralPath $manifestPath) {
    throw "No-overwrite manifest generation already exists"
}
if (Test-Path -LiteralPath $validationPath) {
    throw "No-overwrite validation generation already exists"
}

$errors = [System.Collections.Generic.List[string]]::new()
$warnings = [System.Collections.Generic.List[string]]::new()
$manifestRows = [System.Collections.Generic.List[object]]::new()
$artifactActualPaths = @{}

function Add-Error {
    param([string]$Message)
    $script:errors.Add($Message)
}

function Assert-Check {
    param(
        [bool]$Condition,
        [string]$Message
    )
    if (-not $Condition) {
        Add-Error $Message
    }
}

function Get-Identity {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return $null
    }
    $item = Get-Item -LiteralPath $Path
    [pscustomobject]@{
        bytes = [int64]$item.Length
        sha256 = (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToUpperInvariant()
    }
}

function Assert-Identity {
    param(
        [string]$Path,
        [int64]$ExpectedBytes,
        [string]$ExpectedSha256,
        [string]$Label
    )
    $identity = Get-Identity $Path
    if ($null -eq $identity) {
        Add-Error "$Label is missing"
        return
    }
    Assert-Check ($identity.bytes -eq $ExpectedBytes) "$Label byte count drifted"
    Assert-Check ($identity.sha256 -eq $ExpectedSha256.ToUpperInvariant()) "$Label SHA-256 drifted"
}

function Add-ManifestRow {
    param(
        [string]$ArtifactId,
        [string]$RootAlias,
        [string]$RelativePath,
        [string]$Role,
        [string]$ActualPath,
        [string]$ReadCompleteness,
        [string]$PublicProjection
    )
    $identity = Get-Identity $ActualPath
    if ($null -eq $identity) {
        Add-Error "Manifest input $ArtifactId is missing"
        return
    }
    $script:manifestRows.Add([pscustomobject]@{
        artifact_id = $ArtifactId
        root_alias = $RootAlias
        relative_path = $RelativePath.Replace('\', '/')
        role = $Role
        bytes = $identity.bytes
        sha256 = $identity.sha256
        read_completeness = $ReadCompleteness
        public_projection = $PublicProjection
    })
    $script:artifactActualPaths[$ArtifactId] = $ActualPath
}

function Read-CsvRows {
    param([string]$RelativePath)
    $path = Join-Path $repairRoot $RelativePath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Add-Error "$RelativePath is missing"
        return @()
    }
    return @(Import-Csv -LiteralPath $path)
}

function Assert-UniqueField {
    param(
        [object[]]$Rows,
        [string]$Field,
        [string]$Label
    )
    $values = @($Rows | ForEach-Object { [string]($_.$Field) })
    $nonEmpty = @($values | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    Assert-Check ($values.Count -eq $nonEmpty.Count) "$Label has an empty $Field"
    Assert-Check ($nonEmpty.Count -eq @($nonEmpty | Sort-Object -Unique).Count) "$Label has duplicate $Field values"
}

function Get-CanonicalLayerText {
    param([string]$Path)
    $raw = Get-Content -LiteralPath $Path -Raw
    $lines = @($raw -split "`r?`n" | Where-Object { $_ -notmatch '^%' })
    return ($lines -join "`n")
}

function Get-StringSha256 {
    param([string]$Value)
    $bytes = [Text.Encoding]::UTF8.GetBytes($Value)
    return [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($bytes))
}

function Test-TextPrivacy {
    param(
        [string]$Label,
        [string]$Text
    )
    $privateRootPattern = '[A-Za-z]:' + '[\\/]' + 'Users' + '[\\/]'
    $codexStatePattern = '\.' + 'codex' + '[\\/]'
    $taskUuidPattern = '(?i)(?<![0-9a-f])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![0-9a-f])'
    $userLeaf = Split-Path -Leaf ([Environment]::GetFolderPath('UserProfile'))
    if ($Text -match $privateRootPattern) {
        Add-Error "$Label contains a private user-root path"
    }
    if ($Text -match $codexStatePattern) {
        Add-Error "$Label contains a private Codex-state path"
    }
    if (-not [string]::IsNullOrWhiteSpace($userLeaf) -and $Text -match [regex]::Escape($userLeaf)) {
        Add-Error "$Label contains the operator account name"
    }
    if ($Text -match $taskUuidPattern) {
        Add-Error "$Label contains a task UUID"
    }
}

# Exact authority and comparison bindings.
$authorityPartI = Join-Path $projectRoot 'authority_snapshot\jstage_part_I_9_2_119.pdf'
$authorityPartII = Join-Path $projectRoot 'authority_snapshot\jstage_part_II_9_3_185.pdf'
$sourceAuthorityPath = Join-Path $projectRoot 'SOURCE_AUTHORITY.csv'
$authorityComparisonR2Path = Join-Path $projectRoot 'controls\AUTHORITY_IMAGE_COMPARISON_R2.json'

Assert-Identity $authorityPartI 7305283 '5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF' 'official J-STAGE Part I authority'
Assert-Identity $authorityPartII 3984260 '8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53' 'official J-STAGE Part II authority'
Assert-Identity $authorityComparisonR2Path 74608 'B4E04B2A31DB5CC60BE423F27813C5B168795252CF3C5194BE6FA6E46975DC34' 'authority comparison R2'

$sourceAuthorityRows = @(Import-Csv -LiteralPath $sourceAuthorityPath)
Assert-Check ($sourceAuthorityRows.Count -eq 3) 'SOURCE_AUTHORITY.csv must have exactly three rows'
$partIRow = @($sourceAuthorityRows | Where-Object witness_id -eq 'TOH-AUTH-JSTAGE-I')
$partIIRow = @($sourceAuthorityRows | Where-Object witness_id -eq 'TOH-AUTH-JSTAGE-II')
$localRow = @($sourceAuthorityRows | Where-Object witness_id -eq 'TOH-COMP-LOCAL-103P')
Assert-Check ($partIRow.Count -eq 1) 'Part I authority row is not unique'
Assert-Check ($partIIRow.Count -eq 1) 'Part II authority row is not unique'
Assert-Check ($localRow.Count -eq 1) 'local 103-page witness row is not unique'

$localWitnessPath = if ($localRow.Count -eq 1) { [string]$localRow[0].path_or_url } else { '' }
if (-not [string]::IsNullOrWhiteSpace($localWitnessPath)) {
    Assert-Identity $localWitnessPath 12897534 '57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78' 'local 103-page comparison witness'
}

if ($partIRow.Count -eq 1) {
    Assert-Check ($partIRow[0].doi -eq '10.2748/tmj/1178244839') 'Part I DOI drifted'
    Assert-Check ($partIRow[0].sha256 -eq '5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF') 'Part I CSV identity drifted'
}
if ($partIIRow.Count -eq 1) {
    Assert-Check ($partIIRow[0].doi -eq '10.2748/tmj/1178244774') 'Part II DOI drifted'
    Assert-Check ($partIIRow[0].sha256 -eq '8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53') 'Part II CSV identity drifted'
}

$r2 = Get-Content -LiteralPath $authorityComparisonR2Path -Raw | ConvertFrom-Json
Assert-Check ($r2.schema -eq 'tohoku_authority_image_comparison_v2') 'R2 authority comparison schema drifted'
Assert-Check ([int]$r2.summary.paired_pages -eq 102) 'R2 paired-page count is not 102'
Assert-Check ([int]$r2.summary.matches -eq 102) 'R2 match count is not 102'
Assert-Check ([int]$r2.summary.holds -eq 0) 'R2 has a hold'
Assert-Check (@($r2.summary.unpaired_local_pages).Count -eq 1 -and [int]$r2.summary.unpaired_local_pages[0] -eq 66) 'R2 blank-interleaf mapping drifted'
$r2p119 = @($r2.pages | Where-Object { [int]$_.printed_page -eq 119 })
Assert-Check ($r2p119.Count -eq 1) 'R2 printed-p.119 row is not unique'
if ($r2p119.Count -eq 1) {
    Assert-Check ([int]$r2p119[0].local_pdf_page -eq 1) 'R2 p.119 local page is not 1'
    Assert-Check ([int]$r2p119[0].official_pdf_page -eq 1) 'R2 p.119 official page is not 1'
    Assert-Check ($r2p119[0].official_part -eq 'part_I') 'R2 p.119 part is not Part I'
    Assert-Check ($r2p119[0].status -eq 'MATCH') 'R2 p.119 is not MATCH'
}

# Adverse predecessor immutability.
$oldDiplomatic = Join-Path $projectRoot 'tex\fr_diplomatic\part_I\p119.tex'
$oldCorrected = Join-Path $projectRoot 'tex\fr_corrected\part_I\p119.tex'
$oldEnglish = Join-Path $projectRoot 'tex\en\part_I\p119.tex'
$oldCorrectionLedger = Join-Path $projectRoot 'SOURCE_CORRECTIONS.jsonl'
$preamble = Join-Path $projectRoot 'tex\common\preamble.tex'
Assert-Identity $oldDiplomatic 3422 'B8FB69418F7C95EF402E55C3D87F53819321750D5148D053EB13AE263E1A4985' 'adverse predecessor diplomatic French'
Assert-Identity $oldCorrected 3450 '65833D06FA8A5C6892ABC965383E978BCAFAC4E5837E47643F589F6C436D1B76' 'adverse predecessor corrected French'
Assert-Identity $oldEnglish 3245 '844DCECD253BE8FA552DF95AF786E55BC321338AC3E074589E042BBA5414EB20' 'adverse predecessor English'
Assert-Identity $oldCorrectionLedger 1204 '6B17B608E2583363863EF715F6BEF03036625677F2BC287651B1F2A266284F64' 'adverse predecessor source-correction ledger'
Assert-Identity $preamble 1387 '2498C6D7FEAE365476C04446AFB1E85C2AE843DA673656B2AB3F6A0953F3696C' 'reader preamble dependency'

# Repaired layers and their contract.
$newDiplomatic = Join-Path $repairRoot 'tex\fr_diplomatic\p119.tex'
$newCorrected = Join-Path $repairRoot 'tex\fr_corrected\p119.tex'
$newEnglish = Join-Path $repairRoot 'tex\en\p119.tex'
Assert-Identity $newDiplomatic 3599 'C2449038BD2076F71694DD33B679367E2B21C4F492E9DC3D1C389EB11047FDF8' 'repaired diplomatic French'
Assert-Identity $newCorrected 3608 'E19F7916F5A90F469DD5ED78C4BEB74C60892FE66EBF3771C6F6E9B82C480DE4' 'repaired corrected French'
Assert-Identity $newEnglish 3306 '6CB72A5CC630BBF6A9CE4C92E353912254F3D12FF0712388708DD43F0ECB88C5' 'rebound source-aligned English'

$diplomaticText = Get-CanonicalLayerText $newDiplomatic
$correctedText = Get-CanonicalLayerText $newCorrected
$englishText = Get-Content -LiteralPath $newEnglish -Raw
$englishComparable = [regex]::Replace($englishText, '\s+', ' ')
Assert-Check ($diplomaticText -ceq $correctedText) 'corrected French is not textually identical to diplomatic French after layer comments'
$frenchCanonicalHash = Get-StringSha256 $diplomaticText
Assert-Check ($frenchCanonicalHash -eq 'E15F6E69E534EDFDFA6CF0DD165F81C06A0CBA41A34DDA38ACE7D1F8E107ED50') 'canonical repaired French textual hash drifted'

$requiredFrench = @(
    "D'ALGÈBRE",
    'Reçu mars',
    '\paragraph{I. Contenu du travail.}',
    'théorie',
    'coefficients',
    'dérivés',
    'catégories abéliennes',
    '\emph{L''introduction des catégories',
    '\emph{toutes}',
    '---Les numéros'
)
foreach ($marker in $requiredFrench) {
    Assert-Check ($diplomaticText.Contains($marker)) "diplomatic French lacks required marker: $marker"
}
Assert-Check (-not $diplomaticText.Contains('\paragraph{1. Contenu du travail.}')) 'diplomatic French regressed Roman I to Arabic 1'
$requiredEnglish = @(
    '\paragraph{I. Contents of the work.}',
    '\emph{The introduction of additive categories}',
    '\emph{all}',
    '---The numbers'
)
foreach ($marker in $requiredEnglish) {
    Assert-Check ($englishComparable.Contains($marker)) "English layer lacks required marker: $marker"
}

# Append-only decision records.
$jsonlSpecs = @(
    [pscustomobject]@{ path = 'TRANSCRIPTION_SUPERSESSION.jsonl'; count = 5 },
    [pscustomobject]@{ path = 'NORMALIZATION_REVALIDATION.jsonl'; count = 2 },
    [pscustomobject]@{ path = 'SOURCE_CORRECTION_DISPOSITION.jsonl'; count = 1 },
    [pscustomobject]@{ path = 'TRANSLATION_REBINDING.jsonl'; count = 6 },
    [pscustomobject]@{ path = 'GLOBAL_REPAIR_LEDGER.jsonl'; count = 2 }
)
$allDecisionIds = [System.Collections.Generic.List[string]]::new()
foreach ($spec in $jsonlSpecs) {
    $path = Join-Path $repairRoot $spec.path
    $lines = @(Get-Content -LiteralPath $path | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    Assert-Check ($lines.Count -eq $spec.count) "$($spec.path) record count drifted"
    foreach ($line in $lines) {
        try {
            $record = $line | ConvertFrom-Json
            $stableId = ''
            if ($record.PSObject.Properties.Name -contains 'decision_id') {
                $stableId = [string]$record.decision_id
            }
            elseif ($record.PSObject.Properties.Name -contains 'record_id') {
                $stableId = [string]$record.record_id
            }
            Assert-Check (-not [string]::IsNullOrWhiteSpace($stableId)) "$($spec.path) has a record without a stable ID"
            if (-not [string]::IsNullOrWhiteSpace($stableId)) {
                $allDecisionIds.Add($stableId)
            }
        }
        catch {
            Add-Error "$($spec.path) contains invalid JSON"
        }
    }
}
Assert-Check ($allDecisionIds.Count -eq 16) 'append-only repair record total is not 16'
Assert-Check ($allDecisionIds.Count -eq @($allDecisionIds | Sort-Object -Unique).Count) 'append-only repair decision IDs are not unique'

# Semantic scaffold structure and referential integrity.
$csvSpecs = @(
    [pscustomobject]@{ path = 'semantics\BIBLIOGRAPHY_INDEX.csv'; count = 5; id = 'bibliography_node_id' },
    [pscustomobject]@{ path = 'semantics\BILINGUAL_UNIT_ALIGNMENT.csv'; count = 8; id = 'alignment_id' },
    [pscustomobject]@{ path = 'semantics\CROSS_WORK_RELATION_CANDIDATES.csv'; count = 6; id = 'relation_candidate_id' },
    [pscustomobject]@{ path = 'semantics\DIAGRAM_INDEX.csv'; count = 0; id = 'diagram_id' },
    [pscustomobject]@{ path = 'semantics\FORMULA_INDEX.csv'; count = 0; id = 'formula_id' },
    [pscustomobject]@{ path = 'semantics\ID_MIGRATIONS.csv'; count = 5; id = 'migration_id' },
    [pscustomobject]@{ path = 'semantics\PAGE_OBJECT_COUNTS.csv'; count = 1; id = 'page_inventory_id' },
    [pscustomobject]@{ path = 'semantics\PRESTACKS_CANDIDATES.csv'; count = 10; id = 'mapping_id' },
    [pscustomobject]@{ path = 'semantics\PRESTACKS_CONFIRMED.csv'; count = 0; id = 'mapping_id' },
    [pscustomobject]@{ path = 'semantics\REFERENCE_CANDIDATES.csv'; count = 29; id = 'candidate_id' },
    [pscustomobject]@{ path = 'semantics\REFERENCE_EDGES.csv'; count = 27; id = 'edge_id' },
    [pscustomobject]@{ path = 'semantics\REFERENCE_RESIDUALS.csv'; count = 20; id = 'residual_id' },
    [pscustomobject]@{ path = 'semantics\SEMANTIC_NODES.csv'; count = 41; id = 'node_id' },
    [pscustomobject]@{ path = 'semantics\SOURCE_PAGE_MAP.csv'; count = 1; id = 'page_map_id' },
    [pscustomobject]@{ path = 'semantics\SUBJECT_INDEX.csv'; count = 10; id = 'subject_entry_id' },
    [pscustomobject]@{ path = 'semantics\TERM_INDEX.csv'; count = 14; id = 'term_id' }
)
$csvByPath = @{}
foreach ($spec in $csvSpecs) {
    $rows = @(Read-CsvRows $spec.path)
    $csvByPath[$spec.path] = $rows
    Assert-Check ($rows.Count -eq $spec.count) "$($spec.path) row count drifted"
    if ($rows.Count -gt 0) {
        Assert-UniqueField $rows $spec.id $spec.path
    }
    foreach ($row in $rows) {
        foreach ($property in $row.PSObject.Properties) {
            $cell = [string]$property.Value
            if ($cell -match '^\s*[=+@-]') {
                Add-Error "$($spec.path) has a spreadsheet-formula-triggering cell"
            }
        }
    }
}

$nodes = @($csvByPath['semantics\SEMANTIC_NODES.csv'])
$nodeIds = @($nodes | ForEach-Object { [string]$_.node_id })
$nodeSet = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($id in $nodeIds) { [void]$nodeSet.Add($id) }
foreach ($node in $nodes) {
    if (-not [string]::IsNullOrWhiteSpace($node.parent_id)) {
        Assert-Check ($nodeSet.Contains([string]$node.parent_id)) "semantic node $($node.node_id) has a missing parent"
    }
    Assert-Check ($allDecisionIds.Contains([string]$node.provenance_decision)) "semantic node $($node.node_id) has an unknown provenance decision"
}

$alignments = @($csvByPath['semantics\BILINGUAL_UNIT_ALIGNMENT.csv'])
foreach ($row in $alignments) {
    Assert-Check ($nodeSet.Contains([string]$row.node_id)) "alignment $($row.alignment_id) has a missing node"
    Assert-Check ($row.fr_diplomatic_sha256 -eq 'C2449038BD2076F71694DD33B679367E2B21C4F492E9DC3D1C389EB11047FDF8') "alignment $($row.alignment_id) has stale diplomatic hash"
    Assert-Check ($row.fr_corrected_sha256 -eq 'E19F7916F5A90F469DD5ED78C4BEB74C60892FE66EBF3771C6F6E9B82C480DE4') "alignment $($row.alignment_id) has stale corrected-French hash"
    Assert-Check ($row.en_sha256 -eq '6CB72A5CC630BBF6A9CE4C92E353912254F3D12FF0712388708DD43F0ECB88C5') "alignment $($row.alignment_id) has stale English hash"
}

foreach ($row in @($csvByPath['semantics\TERM_INDEX.csv'])) {
    Assert-Check ($nodeSet.Contains([string]$row.node_id)) "term $($row.term_id) has a missing node"
    Assert-Check ($allDecisionIds.Contains([string]$row.decision_id)) "term $($row.term_id) has an unknown decision"
}
foreach ($row in @($csvByPath['semantics\SUBJECT_INDEX.csv'])) {
    Assert-Check ($nodeSet.Contains([string]$row.node_id)) "subject $($row.subject_entry_id) has a missing node"
}
foreach ($row in @($csvByPath['semantics\BIBLIOGRAPHY_INDEX.csv'])) {
    Assert-Check ($nodeSet.Contains([string]$row.bibliography_node_id)) "bibliography row $($row.bibliography_node_id) has a missing node"
}
foreach ($row in @($csvByPath['semantics\ID_MIGRATIONS.csv'])) {
    Assert-Check ($nodeSet.Contains([string]$row.new_id)) "ID migration $($row.migration_id) has a missing new ID"
}

$pageMap = @($csvByPath['semantics\SOURCE_PAGE_MAP.csv'])
if ($pageMap.Count -eq 1) {
    Assert-Check ($pageMap[0].authority_id -eq 'TOH-AUTH-JSTAGE-I') 'source-page map authority ID drifted'
    Assert-Check ($pageMap[0].authority_sha256 -eq '5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF') 'source-page map authority hash drifted'
    Assert-Check ([int]$pageMap[0].official_pdf_page -eq 1 -and [int]$pageMap[0].printed_page -eq 119 -and [int]$pageMap[0].local_witness_page -eq 1) 'source-page coordinate binding drifted'
    Assert-Check ($pageMap[0].local_witness_sha256 -eq '57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78') 'source-page map local-witness hash drifted'
}

$pageCounts = @($csvByPath['semantics\PAGE_OBJECT_COUNTS.csv'])
if ($pageCounts.Count -eq 1) {
    Assert-Check ([int]$pageCounts[0].printed_page -eq 119) 'page-object inventory is not p.119'
    Assert-Check ([int]$pageCounts[0].formula_count -eq 0) 'p.119 formula count is not zero'
    Assert-Check ([int]$pageCounts[0].diagram_count -eq 0) 'p.119 diagram count is not zero'
    Assert-Check ([int]$pageCounts[0].reference_candidate_count -eq 29) 'p.119 reference candidate count is not 29'
    Assert-Check ([int]$pageCounts[0].term_rows -eq 14) 'p.119 term-row count is not 14'
    Assert-Check ($pageCounts[0].lead_review_state -eq 'PASS') 'p.119 page-object inventory lacks lead PASS'
}

$candidates = @($csvByPath['semantics\REFERENCE_CANDIDATES.csv'])
$edges = @($csvByPath['semantics\REFERENCE_EDGES.csv'])
$residuals = @($csvByPath['semantics\REFERENCE_RESIDUALS.csv'])
$candidateIds = @($candidates | ForEach-Object { [string]$_.candidate_id })
$candidateSet = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::Ordinal)
foreach ($id in $candidateIds) { [void]$candidateSet.Add($id) }
$admittedCandidateIds = @($candidates | Where-Object terminal_state -eq 'admitted_edge' | ForEach-Object { [string]$_.candidate_id })
$unresolvedCandidateIds = @($candidates | Where-Object terminal_state -eq 'unresolved' | ForEach-Object { [string]$_.candidate_id })
$edgeCandidateIds = @($edges | ForEach-Object { [string]$_.candidate_id })
Assert-Check ($candidates.Count -eq $edges.Count + $unresolvedCandidateIds.Count) 'reference candidate arithmetic does not close'
Assert-Check ($admittedCandidateIds.Count -eq 27 -and $unresolvedCandidateIds.Count -eq 2) 'reference terminal-state counts drifted'
Assert-Check (@(Compare-Object ($admittedCandidateIds | Sort-Object) ($edgeCandidateIds | Sort-Object)).Count -eq 0) 'reference edge candidate set does not equal admitted candidates'
foreach ($candidate in $candidates) {
    Assert-Check ($nodeSet.Contains([string]$candidate.source_node_id)) "reference candidate $($candidate.candidate_id) has a missing source node"
    Assert-Check ($candidate.source_hash -eq 'C2449038BD2076F71694DD33B679367E2B21C4F492E9DC3D1C389EB11047FDF8') "reference candidate $($candidate.candidate_id) has a stale source hash"
}
foreach ($edge in $edges) {
    Assert-Check ($candidateSet.Contains([string]$edge.candidate_id)) "reference edge $($edge.edge_id) has a missing candidate"
    Assert-Check ($nodeSet.Contains([string]$edge.source_node_id)) "reference edge $($edge.edge_id) has a missing source node"
    Assert-Check ($nodeSet.Contains([string]$edge.target_node_id)) "reference edge $($edge.edge_id) has a missing target node"
}
$unresolvedResidualIds = @($residuals | Where-Object residual_kind -eq 'unresolved_candidate' | ForEach-Object { [string]$_.candidate_or_target_id })
Assert-Check ($unresolvedResidualIds.Count -eq 2) 'unresolved-candidate residual count is not 2'
Assert-Check (@(Compare-Object ($unresolvedCandidateIds | Sort-Object) ($unresolvedResidualIds | Sort-Object)).Count -eq 0) 'unresolved candidates and residuals do not match'
Assert-Check (@($residuals | Where-Object state -ne 'open').Count -eq 0) 'a p.119 residual is not open'

$prestacksCandidates = @($csvByPath['semantics\PRESTACKS_CANDIDATES.csv'])
$prestacksConfirmed = @($csvByPath['semantics\PRESTACKS_CONFIRMED.csv'])
foreach ($row in $prestacksCandidates) {
    Assert-Check ($nodeSet.Contains([string]$row.source_node_id)) "pre-Stacks candidate $($row.mapping_id) has a missing source node"
    Assert-Check ([string]::IsNullOrWhiteSpace([string]$row.official_stacks_tag)) "pre-Stacks candidate $($row.mapping_id) invents or asserts an official tag"
    Assert-Check ($row.status -eq 'candidate') "pre-Stacks candidate $($row.mapping_id) has a non-candidate status"
}
Assert-Check ($prestacksConfirmed.Count -eq 0) 'official pre-Stacks confirmation table is not empty'

$crossWork = @($csvByPath['semantics\CROSS_WORK_RELATION_CANDIDATES.csv'])
foreach ($row in $crossWork) {
    Assert-Check ($nodeSet.Contains([string]$row.source_node_id)) "cross-work candidate $($row.relation_candidate_id) has a missing source node"
    Assert-Check ([string]::IsNullOrWhiteSpace([string]$row.target_external_id)) "cross-work candidate $($row.relation_candidate_id) asserts an external ID"
    Assert-Check ($row.status -eq 'unresolved_candidate') "cross-work candidate $($row.relation_candidate_id) is not unresolved"
}

# Build, PDF, fonts, images, metadata, and reader-surface checks.
$readerPdf = Join-Path $repairRoot 'o\tohoku_p119_bilingual_r1.pdf'
$builtPdf = Join-Path $repairRoot 'b\r1\p119_r1.pdf'
$buildLog = Join-Path $repairRoot 'b\r1\p119_r1.log'
$commandLog = Join-Path $repairRoot 'b\r1\command.log'
Assert-Identity $readerPdf 273464 '493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E' 'p.119 bilingual reader'
Assert-Identity $builtPdf 273464 '493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E' 'p.119 build-directory PDF'

$logText = Get-Content -LiteralPath $buildLog -Raw
$commandText = Get-Content -LiteralPath $commandLog -Raw
$hardLogPatterns = @(
    '(?m)^!',
    'LaTeX Error',
    'Undefined control sequence',
    'Emergency stop',
    'Fatal error',
    'Overfull \\[hv]box',
    'Underfull \\[hv]box',
    'There were undefined references',
    'Rerun to get cross-references right'
)
foreach ($pattern in $hardLogPatterns) {
    Assert-Check (-not [regex]::IsMatch($logText, $pattern, [Text.RegularExpressions.RegexOptions]::IgnoreCase)) "TeX transcript contains prohibited pattern: $pattern"
}
Assert-Check (@([regex]::Matches($commandText, '(?m)^PASS [12]\s*$')).Count -eq 2) 'build command log does not contain exactly two passes'
Assert-Check (@([regex]::Matches($commandText, '\(4 pages, 273464 bytes\)')).Count -eq 2) 'build command log does not record two identical four-page outputs'

$pdfTextCommand = Get-Command pdftotext -ErrorAction SilentlyContinue
$pdfFontsCommand = Get-Command pdffonts -ErrorAction SilentlyContinue
$pdfImagesCommand = Get-Command pdfimages -ErrorAction SilentlyContinue
$pdfInfoCommand = Get-Command pdfinfo -ErrorAction SilentlyContinue
Assert-Check ($null -ne $pdfTextCommand) 'pdftotext is unavailable'
Assert-Check ($null -ne $pdfFontsCommand) 'pdffonts is unavailable'
Assert-Check ($null -ne $pdfImagesCommand) 'pdfimages is unavailable'
Assert-Check ($null -ne $pdfInfoCommand) 'pdfinfo is unavailable'

$readerText = ''
$fontOutput = ''
$imageOutput = ''
$pdfInfoOutput = ''
if ($null -ne $pdfTextCommand) {
    $readerText = (& $pdfTextCommand.Path -layout $readerPdf - 2>&1 | Out-String)
    Assert-Check ($LASTEXITCODE -eq 0) 'pdftotext failed'
}
if ($null -ne $pdfFontsCommand) {
    $fontOutput = (& $pdfFontsCommand.Path $readerPdf 2>&1 | Out-String)
    Assert-Check ($LASTEXITCODE -eq 0) 'pdffonts failed'
}
if ($null -ne $pdfImagesCommand) {
    $imageOutput = (& $pdfImagesCommand.Path -list $readerPdf 2>&1 | Out-String)
    Assert-Check ($LASTEXITCODE -eq 0) 'pdfimages failed'
}
if ($null -ne $pdfInfoCommand) {
    $dependenciesRoot = Split-Path -Parent (Split-Path -Parent (Split-Path -Parent $pdfInfoCommand.Path))
    $pdfInfoExe = Join-Path $dependenciesRoot 'native\poppler\Library\bin\pdfinfo.exe'
    Assert-Check (Test-Path -LiteralPath $pdfInfoExe -PathType Leaf) 'direct Poppler pdfinfo executable is unavailable'
    if (Test-Path -LiteralPath $pdfInfoExe -PathType Leaf) {
        $pdfInfoOutput = (& $pdfInfoExe $readerPdf 2>&1 | Out-String)
        Assert-Check ($LASTEXITCODE -eq 0) 'pdfinfo failed'
    }
}

Assert-Check ($pdfInfoOutput -match '(?m)^Pages:\s+4\s*$') 'reader PDF page count is not 4'
Assert-Check ($pdfInfoOutput -match '(?m)^Author:\s+Alexandre Grothendieck\s*$') 'reader PDF author metadata drifted'
Assert-Check ($pdfInfoOutput -match '(?m)^Title:\s+Sur quelques points') 'reader PDF title metadata drifted'
$fontLines = @($fontOutput -split "`r?`n" | Where-Object { $_ -match '^[A-Z0-9]{6}\+\S+\s+(Type|CID)' })
Assert-Check ($fontLines.Count -eq 10) 'reader PDF font-resource count is not 10'
foreach ($line in $fontLines) {
    Assert-Check ($line -match '\s+yes\s+yes\s+yes\s+\d+\s+\d+\s*$') 'reader PDF has a font that is not embedded, subsetted, and Unicode mapped'
}
$imageRows = @($imageOutput -split "`r?`n" | Where-Object { $_ -match '^\s*\d+\s+\d+\s+\w+' })
Assert-Check ($imageRows.Count -eq 0) 'reader PDF contains an image object'

$requiredReaderText = @(
    'Diplomatic French',
    'Corrected French',
    'source-aligned',
    'SUR QUELQUES POINTS',
    'ON SOME POINTS',
    'I. Contenu du travail.',
    'I. Contents of the work.',
    '10.2748/tmj/1178244839'
)
foreach ($marker in $requiredReaderText) {
    Assert-Check ($readerText.Contains($marker)) "reader text lacks required marker: $marker"
}
$readerProseBan = '(?i)\b(Codex|ChatGPT|OpenAI|workflow|status|validation|retrospective|repair|supersession|adverse|checkpoint|handoff|AI)\b'
Assert-Check (-not [regex]::IsMatch($readerText, $readerProseBan)) 'reader PDF contains workflow, AI, status, or repair prose'
Test-TextPrivacy 'reader text' $readerText
Test-TextPrivacy 'reader metadata' $pdfInfoOutput

# Exact authority and reader render evidence.
$qaExpected = @(
    [pscustomobject]@{ path = 'qa\p119_1200g.png'; bytes = 4959134; sha = 'FDFA4EDB4443F5E585935C32AD6873F10F7C3D2FEAD5DC776253A34132A9DE61' },
    [pscustomobject]@{ path = 'qa\b1.png'; bytes = 387956; sha = '43E46F788415D265C235178B18F46176830666340A3AD6A7654777900F88C9C3' },
    [pscustomobject]@{ path = 'qa\b2.png'; bytes = 904864; sha = '5AF803A00F28C451D2AD81694FDC7C55329E78CAE191E707190ED3EA11BA9C3A' },
    [pscustomobject]@{ path = 'qa\b3.png'; bytes = 862290; sha = 'E2444246ED50137C3E64E0FB10C5695C46BB4C4BC97ACA5F807DB94F9278A912' },
    [pscustomobject]@{ path = 'qa\b4.png'; bytes = 666198; sha = 'B2992DC0185B9B95DAA6004BF028DF32FEFF79BB8CA5E009D9D1EA386EEA88AB' },
    [pscustomobject]@{ path = 'qa\label_I_7000.png'; bytes = 30707; sha = '2A1C7CE996CACFA4FD5C3E7C5DD0C20580203C025321F9050515F1C4B7A41756' },
    [pscustomobject]@{ path = 'qa\reader_r1_180dpi\page-1.png'; bytes = 96624; sha = '191BDE67B68C8D091C01981BD8A4CFCB46FB66995F4FAA91FBF9332CDF17CA03' },
    [pscustomobject]@{ path = 'qa\reader_r1_180dpi\page-2.png'; bytes = 364330; sha = '18B8920A432FDE99E70579E19E2C263DFA95D9F214B90DDBD36620996BCB560E' },
    [pscustomobject]@{ path = 'qa\reader_r1_180dpi\page-3.png'; bytes = 455008; sha = '8FA0369C85CEE6C8FE48BEF6A0AFD57C494AE6E920692D7DE05188A50620857D' },
    [pscustomobject]@{ path = 'qa\reader_r1_180dpi\page-4.png'; bytes = 357177; sha = '611B42518539B1783095FA9D0582C15731F10EEF3683C2443564CE8DC12AF248' }
)
foreach ($qa in $qaExpected) {
    Assert-Identity (Join-Path $repairRoot $qa.path) $qa.bytes $qa.sha "QA evidence $($qa.path)"
}

# Privacy-clean text surface for future package-eligible controls.
$eligibleTextRelativePaths = @(
    'README.md',
    'STATUS.md',
    'CONTINUATION_HANDOFF.md',
    'LEAD_VISUAL_QA_R1.md',
    'build_checkpoint.ps1',
    'validate_p119_checkpoint.ps1',
    'validate_p119_checkpoint_r2.ps1',
    'TRANSCRIPTION_SUPERSESSION.jsonl',
    'NORMALIZATION_REVALIDATION.jsonl',
    'SOURCE_CORRECTION_DISPOSITION.jsonl',
    'TRANSLATION_REBINDING.jsonl',
    'GLOBAL_REPAIR_LEDGER.jsonl',
    'tex\fr_diplomatic\p119.tex',
    'tex\fr_corrected\p119.tex',
    'tex\en\p119.tex',
    'tex\readers\p119_r1.tex'
)
$eligibleTextRelativePaths += @($csvSpecs | ForEach-Object { $_.path })
foreach ($relative in $eligibleTextRelativePaths) {
    Test-TextPrivacy $relative (Get-Content -LiteralPath (Join-Path $repairRoot $relative) -Raw)
}
Test-TextPrivacy 'reader preamble dependency' (Get-Content -LiteralPath $preamble -Raw)
Test-TextPrivacy 'authority comparison R2' (Get-Content -LiteralPath $authorityComparisonR2Path -Raw)

# Generation manifest. Paths are alias-relative; private absolute paths never enter it.
$repairEntries = @(
    [pscustomobject]@{ id='R1-README'; path='README.md'; role='repair generation scope'; read='lead_read_through_eof'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-STATUS'; path='STATUS.md'; role='bounded checkpoint status'; read='lead_read_through_eof'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-HANDOFF'; path='CONTINUATION_HANDOFF.md'; role='successor continuation contract'; read='lead_read_through_eof'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-VISUAL-QA'; path='LEAD_VISUAL_QA_R1.md'; role='lead visual inspection receipt'; read='lead_read_through_eof'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-BUILD-SCRIPT'; path='build_checkpoint.ps1'; role='generation-addressed build procedure'; read='validator_byte_complete'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-VALIDATOR-FAILED'; path='validate_p119_checkpoint.ps1'; role='failed validation-generation R1 procedure'; read='validator_byte_complete'; projection='excluded_adverse_validation' },
    [pscustomobject]@{ id='R1-MANIFEST-FAILED'; path='CHECKPOINT_MANIFEST_R1.csv'; role='failed validation-generation R1 manifest'; read='parsed_every_row'; projection='excluded_adverse_validation' },
    [pscustomobject]@{ id='R1-VALIDATION-FAILED'; path='CHECKPOINT_VALIDATION_R1.json'; role='failed validation-generation R1 receipt'; read='parsed_through_eof'; projection='excluded_adverse_validation' },
    [pscustomobject]@{ id='R2-VALIDATOR'; path='validate_p119_checkpoint_r2.ps1'; role='fail-closed validation-generation R2 procedure'; read='validator_byte_complete'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-LEDGER-TRANSCRIPTION'; path='TRANSCRIPTION_SUPERSESSION.jsonl'; role='append-only transcription supersession'; read='parsed_every_record'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-LEDGER-NORMALIZATION'; path='NORMALIZATION_REVALIDATION.jsonl'; role='append-only normalization revalidation'; read='parsed_every_record'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-LEDGER-SOURCE'; path='SOURCE_CORRECTION_DISPOSITION.jsonl'; role='append-only source correction disposition'; read='parsed_every_record'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-LEDGER-TRANSLATION'; path='TRANSLATION_REBINDING.jsonl'; role='append-only translation rebinding'; read='parsed_every_record'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-LEDGER-GLOBAL'; path='GLOBAL_REPAIR_LEDGER.jsonl'; role='append-only global repair propagation'; read='parsed_every_record'; projection='eligible_control' },
    [pscustomobject]@{ id='R1-TEX-DIP'; path='tex\fr_diplomatic\p119.tex'; role='diplomatic French'; read='lead_source_replay_complete'; projection='eligible_source' },
    [pscustomobject]@{ id='R1-TEX-COR'; path='tex\fr_corrected\p119.tex'; role='corrected French'; read='lead_source_replay_complete'; projection='eligible_source' },
    [pscustomobject]@{ id='R1-TEX-EN'; path='tex\en\p119.tex'; role='source-aligned English'; read='lead_alignment_complete'; projection='eligible_source' },
    [pscustomobject]@{ id='R1-TEX-READER'; path='tex\readers\p119_r1.tex'; role='reader master'; read='build_input_complete'; projection='eligible_source' },
    [pscustomobject]@{ id='R1-READER'; path='o\tohoku_p119_bilingual_r1.pdf'; role='four-page scholarly reader'; read='lead_visual_all_pages_and_machine_complete'; projection='eligible_reader' },
    [pscustomobject]@{ id='R1-BUILD-PDF'; path='b\r1\p119_r1.pdf'; role='build-directory duplicate'; read='hash_complete'; projection='excluded_build_intermediate' },
    [pscustomobject]@{ id='R1-BUILD-LOG'; path='b\r1\p119_r1.log'; role='private path-bearing TeX transcript'; read='machine_log_complete'; projection='excluded_private_build_log' },
    [pscustomobject]@{ id='R1-COMMAND-LOG'; path='b\r1\command.log'; role='private path-bearing command transcript'; read='machine_log_complete'; projection='excluded_private_build_log' }
)
foreach ($spec in $csvSpecs) {
    $leaf = [IO.Path]::GetFileNameWithoutExtension($spec.path)
    $repairEntries += [pscustomobject]@{ id="R1-SEM-$leaf"; path=$spec.path; role='machine-readable semantic scaffold'; read='parsed_every_row'; projection='eligible_control' }
}
foreach ($qa in $qaExpected) {
    $safeId = ($qa.path -replace '[^A-Za-z0-9]+','-').Trim('-').ToUpperInvariant()
    $repairEntries += [pscustomobject]@{ id="R1-$safeId"; path=$qa.path; role='lead QA raster evidence, not reader content'; read='lead_visual_or_source_evidence_complete'; projection='excluded_qa_evidence' }
}
foreach ($entry in $repairEntries) {
    Add-ManifestRow $entry.id 'TOHOKU_REPAIR_R1' $entry.path $entry.role (Join-Path $repairRoot $entry.path) $entry.read $entry.projection
}

Add-ManifestRow 'PROJECT-PREAMBLE' 'TOHOKU_PROJECT' 'tex/common/preamble.tex' 'reader preamble dependency' $preamble 'validator_byte_complete' 'eligible_source'
Add-ManifestRow 'PROJECT-SOURCE-AUTHORITY' 'TOHOKU_PROJECT' 'SOURCE_AUTHORITY.csv' 'private source authority registry' $sourceAuthorityPath 'parsed_every_row' 'excluded_private_path_control'
Add-ManifestRow 'PROJECT-AUTHORITY-COMP-R2' 'TOHOKU_PROJECT' 'controls/AUTHORITY_IMAGE_COMPARISON_R2.json' '102-page no-OCR authority binding' $authorityComparisonR2Path 'parsed_through_eof' 'eligible_control'
Add-ManifestRow 'AUTH-JSTAGE-I' 'TOHOKU_PROJECT' 'authority_snapshot/jstage_part_I_9_2_119.pdf' 'official Part I image authority' $authorityPartI 'rehash_complete' 'excluded_authority_pdf'
Add-ManifestRow 'AUTH-JSTAGE-II' 'TOHOKU_PROJECT' 'authority_snapshot/jstage_part_II_9_3_185.pdf' 'official Part II image authority' $authorityPartII 'rehash_complete' 'excluded_authority_pdf'
if (-not [string]::IsNullOrWhiteSpace($localWitnessPath)) {
    Add-ManifestRow 'COMP-LOCAL-103P' 'TOHOKU_LOCAL_WITNESS' 'witness.pdf' 'admitted local comparison witness' $localWitnessPath 'rehash_complete' 'excluded_comparison_pdf'
}
Add-ManifestRow 'ADVERSE-DIP' 'TOHOKU_PROJECT' 'tex/fr_diplomatic/part_I/p119.tex' 'immutable adverse predecessor diplomatic layer' $oldDiplomatic 'rehash_complete' 'excluded_adverse_history'
Add-ManifestRow 'ADVERSE-COR' 'TOHOKU_PROJECT' 'tex/fr_corrected/part_I/p119.tex' 'immutable adverse predecessor corrected layer' $oldCorrected 'rehash_complete' 'excluded_adverse_history'
Add-ManifestRow 'ADVERSE-EN' 'TOHOKU_PROJECT' 'tex/en/part_I/p119.tex' 'immutable adverse predecessor English layer' $oldEnglish 'rehash_complete' 'excluded_adverse_history'
Add-ManifestRow 'ADVERSE-SOURCE-LEDGER' 'TOHOKU_PROJECT' 'SOURCE_CORRECTIONS.jsonl' 'immutable adverse predecessor source-correction ledger' $oldCorrectionLedger 'rehash_complete' 'excluded_adverse_history'

$artifactIds = @($manifestRows | ForEach-Object { [string]$_.artifact_id })
Assert-Check ($artifactIds.Count -eq @($artifactIds | Sort-Object -Unique).Count) 'generation manifest artifact IDs are not unique'
$manifestRows | Sort-Object artifact_id | Export-Csv -LiteralPath $manifestPath -NoTypeInformation -Encoding utf8NoBOM

$writtenManifestRows = @(Import-Csv -LiteralPath $manifestPath)
Assert-Check ($writtenManifestRows.Count -eq $manifestRows.Count) 'written manifest row count does not replay'
foreach ($row in $writtenManifestRows) {
    Assert-Check ($artifactActualPaths.ContainsKey([string]$row.artifact_id)) "written manifest has unknown artifact $($row.artifact_id)"
    if ($artifactActualPaths.ContainsKey([string]$row.artifact_id)) {
        $identity = Get-Identity $artifactActualPaths[[string]$row.artifact_id]
        Assert-Check ([int64]$row.bytes -eq $identity.bytes) "manifest byte mismatch for $($row.artifact_id)"
        Assert-Check ($row.sha256 -eq $identity.sha256) "manifest SHA-256 mismatch for $($row.artifact_id)"
    }
}
Test-TextPrivacy 'checkpoint manifest' (Get-Content -LiteralPath $manifestPath -Raw)

$manifestIdentity = Get-Identity $manifestPath
$manifestTotalBytes = [int64](($writtenManifestRows | Measure-Object -Property bytes -Sum).Sum)
$aggregateLines = @($writtenManifestRows | Sort-Object artifact_id | ForEach-Object { "$($_.artifact_id)|$($_.bytes)|$($_.sha256)" })
$manifestAggregate = Get-StringSha256 (($aggregateLines -join "`n") + "`n")

$status = if ($errors.Count -eq 0) { 'PASS' } else { 'FAIL' }
$validation = [ordered]@{
    schema = 'tohoku_p119_checkpoint_validation_v2'
    generation = 'p119_direct_authority_repair_20260804_r1_validation_r2'
    created_utc = (Get-Date).ToUniversalTime().ToString('o')
    scope = [ordered]@{
        printed_pages = @(119)
        claim_boundary = 'bounded printed-p.119 checkpoint only; pp.120--221 remain open'
        production_cursor = 'printed p.120 / official Part I PDF p.2 / local witness p.2'
    }
    status = $status
    errors = [object[]]$errors.ToArray()
    warnings = [object[]]$warnings.ToArray()
    authority = [ordered]@{
        part_I_bytes = 7305283
        part_I_sha256 = '5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF'
        part_I_doi = '10.2748/tmj/1178244839'
        part_II_bytes = 3984260
        part_II_sha256 = '8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53'
        part_II_doi = '10.2748/tmj/1178244774'
        local_witness_bytes = 12897534
        local_witness_sha256 = '57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78'
        comparison_R2_sha256 = 'B4E04B2A31DB5CC60BE423F27813C5B168795252CF3C5194BE6FA6E46975DC34'
        paired_pages = 102
        matches = 102
        holds = 0
        p119_mapping = 'local p.1 = official Part I p.1 = printed p.119'
        ocr_used = $false
    }
    predecessor_immutability = [ordered]@{
        diplomatic_sha256 = 'B8FB69418F7C95EF402E55C3D87F53819321750D5148D053EB13AE263E1A4985'
        corrected_sha256 = '65833D06FA8A5C6892ABC965383E978BCAFAC4E5837E47643F589F6C436D1B76'
        english_sha256 = '844DCECD253BE8FA552DF95AF786E55BC321338AC3E074589E042BBA5414EB20'
        source_ledger_sha256 = '6B17B608E2583363863EF715F6BEF03036625677F2BC287651B1F2A266284F64'
    }
    repaired_layers = [ordered]@{
        diplomatic = [ordered]@{ bytes = 3599; sha256 = 'C2449038BD2076F71694DD33B679367E2B21C4F492E9DC3D1C389EB11047FDF8' }
        corrected = [ordered]@{ bytes = 3608; sha256 = 'E19F7916F5A90F469DD5ED78C4BEB74C60892FE66EBF3771C6F6E9B82C480DE4' }
        english = [ordered]@{ bytes = 3306; sha256 = '6CB72A5CC630BBF6A9CE4C92E353912254F3D12FF0712388708DD43F0ECB88C5' }
        french_textual_equality = ($diplomaticText -ceq $correctedText)
        canonical_french_text_sha256 = $frenchCanonicalHash
    }
    append_only_ledgers = [ordered]@{
        files = 5
        records = $allDecisionIds.Count
        unique_decision_ids = @($allDecisionIds | Sort-Object -Unique).Count
    }
    semantic_scaffold = [ordered]@{
        nodes = $nodes.Count
        bilingual_alignments = $alignments.Count
        terms = @($csvByPath['semantics\TERM_INDEX.csv']).Count
        subjects = @($csvByPath['semantics\SUBJECT_INDEX.csv']).Count
        bibliography_rows = @($csvByPath['semantics\BIBLIOGRAPHY_INDEX.csv']).Count
        reference_candidates = $candidates.Count
        reference_edges = $edges.Count
        unresolved_reference_candidates = $unresolvedCandidateIds.Count
        reference_residuals = $residuals.Count
        formula_rows = @($csvByPath['semantics\FORMULA_INDEX.csv']).Count
        diagram_rows = @($csvByPath['semantics\DIAGRAM_INDEX.csv']).Count
        prestacks_candidates = $prestacksCandidates.Count
        prestacks_confirmed = $prestacksConfirmed.Count
        official_stacks_tags_asserted = @($prestacksCandidates | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.official_stacks_tag) }).Count
        cross_work_candidates = $crossWork.Count
        cross_work_external_ids_asserted = @($crossWork | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_.target_external_id) }).Count
    }
    reader = [ordered]@{
        path = 'TOHOKU_REPAIR_R1/o/tohoku_p119_bilingual_r1.pdf'
        bytes = 273464
        sha256 = '493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E'
        pages = 4
        build_passes = 2
        embedded_subset_unicode_fonts = $fontLines.Count
        image_objects = $imageRows.Count
        workflow_or_ai_prose_hits = @([regex]::Matches($readerText, $readerProseBan)).Count
        lead_visual_pages_inspected = 4
        lead_visual_disposition = 'PASS'
    }
    privacy = [ordered]@{
        eligible_text_files_scanned = $eligibleTextRelativePaths.Count + 2
        reader_text_and_metadata_scanned = $true
        private_path_hits = 0
        operator_name_hits = 0
        task_uuid_hits = 0
    }
    manifest = [ordered]@{
        path = 'TOHOKU_REPAIR_R1/CHECKPOINT_MANIFEST_R2.csv'
        rows = $writtenManifestRows.Count
        represented_bytes = $manifestTotalBytes
        bytes = $manifestIdentity.bytes
        sha256 = $manifestIdentity.sha256
        canonical_aggregate = 'artifact_id|bytes|sha256 sorted ordinal, UTF-8, LF, final LF'
        canonical_aggregate_sha256 = $manifestAggregate
        replay_errors = @($errors | Where-Object { $_ -match '^manifest |^written manifest' }).Count
        self_exclusions = @('CHECKPOINT_MANIFEST_R2.csv', 'CHECKPOINT_VALIDATION_R2.json')
    }
}

$validationJson = $validation | ConvertTo-Json -Depth 8
Test-TextPrivacy 'validation JSON candidate' $validationJson
if ($errors.Count -ne 0 -and $status -eq 'PASS') {
    $status = 'FAIL'
    $validation.status = 'FAIL'
    $validation.errors = [object[]]$errors.ToArray()
    $validationJson = $validation | ConvertTo-Json -Depth 8
}
[IO.File]::WriteAllText($validationPath, $validationJson + "`n", [Text.UTF8Encoding]::new($false))

$validationIdentity = Get-Identity $validationPath
[pscustomobject]@{
    status = $validation.status
    errors = $errors.Count
    warnings = $warnings.Count
    manifest_rows = $writtenManifestRows.Count
    manifest_bytes = $manifestIdentity.bytes
    manifest_sha256 = $manifestIdentity.sha256
    validation_bytes = $validationIdentity.bytes
    validation_sha256 = $validationIdentity.sha256
    reader_sha256 = '493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E'
} | ConvertTo-Json

if ($errors.Count -ne 0) {
    exit 1
}

