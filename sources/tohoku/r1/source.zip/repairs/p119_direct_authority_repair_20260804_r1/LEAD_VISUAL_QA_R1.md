# Printed p.119 lead visual QA — generation r1

Inspection completed: 2026-08-04T03:15:46Z

This receipt records lead-owned visual judgment. It is not a delegated or
automated certification.

## Direct authority

Authority: `TOHOKU_PROJECT/authority_snapshot/jstage_part_I_9_2_119.pdf`,
one-based PDF page 1 / printed p.119, 7,305,283 bytes, SHA-256
`5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`.
The local 103-page witness is admitted only as a comparison witness and is
bound to this page by the 102/102-match, zero-hold R2 authority comparison.
No OCR was generated or used.

The complete page was rendered once at 1,200-dpi-equivalent grayscale and
reviewed sequentially in four bounded bands. A single genuinely ambiguous
small label was then cropped at 7,000-dpi-equivalent. Evidence identities:

| Evidence | Bytes | SHA-256 | Disposition |
|---|---:|---|---|
| `TOHOKU_REPAIR_R1/qa/p119_1200g.png` | 4,959,134 | `FDFA4EDB4443F5E585935C32AD6873F10F7C3D2FEAD5DC776253A34132A9DE61` | complete-page source-fidelity anchor |
| `TOHOKU_REPAIR_R1/qa/b1.png` | 387,956 | `43E46F788415D265C235178B18F46176830666340A3AD6A7654777900F88C9C3` | title, author, receipt date, Introduction heading, and opening label checked |
| `TOHOKU_REPAIR_R1/qa/b2.png` | 904,864 | `5AF803A00F28C451D2AD81694FDC7C55329E78CAE191E707190ED3EA11BA9C3A` | first and second body paragraphs checked |
| `TOHOKU_REPAIR_R1/qa/b3.png` | 862,290 | `E2444246ED50137C3E64E0FB10C5695C46BB4C4BC97ACA5F807DB94F9278A912` | Chapter II paragraph, printed emphasis, and references checked |
| `TOHOKU_REPAIR_R1/qa/b4.png` | 666,198 | `B2992DC0185B9B95DAA6004BF028DF32FEFF79BB8CA5E009D9D1EA386EEA88AB` | Chapter III continuation seam and complete footnote checked |
| `TOHOKU_REPAIR_R1/qa/label_I_7000.png` | 30,707 | `2A1C7CE996CACFA4FD5C3E7C5DD0C20580203C025321F9050515F1C4B7A41756` | resolves the printed label as Roman `I.`, not Arabic `1.` |

The direct replay established that the adverse predecessor had stripped
French diacritics systematically, changed Roman `I.` to `1.`, dropped the
printed emphases on *L'introduction des catégories additives* and *toutes*,
and altered the footnote dash spacing. The r1 diplomatic layer restores each
feature. No authorial error was established: the separately instantiated
corrected-French layer is therefore textually identical to the repaired
diplomatic layer after layer-specific comments are removed.

## Reader build and layout

Reader: `TOHOKU_REPAIR_R1/o/tohoku_p119_bilingual_r1.pdf`, 4 pages,
273,464 bytes, SHA-256
`493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E`.
It was built in two consecutive `pdflatex` passes. The transcript contains no
TeX error, undefined reference, overfull box, underfull box, fatal stop, or
rerun request. All ten font resources are embedded, subsetted, and Unicode
mapped. `pdfimages -list` reports zero image objects.

All four pages were rendered at 180 dpi and inspected at original render
resolution:

| Page | Render identity | Lead visual disposition |
|---:|---|---|
| 1 | 96,624 bytes; `191BDE67B68C8D091C01981BD8A4CFCB46FB66995F4FAA91FBF9332CDF17CA03` | title, author, layer contract, bibliographic line, and DOI are centered, legible, and unclipped |
| 2 | 364,330 bytes; `18B8920A432FDE99E70579E19E2C263DFA95D9F214B90DDBD36620996BCB560E` | full diplomatic layer is legible; headings, emphasis, footnote, continuation seam, margins, and footer are intact |
| 3 | 455,008 bytes; `8FA0369C85CEE6C8FE48BEF6A0AFD57C494AE6E920692D7DE05188A50620857D` | corrected French and English columns align without collision; gutter, headings, accents, emphases, and page footer are intact |
| 4 | 357,177 bytes; `611B42518539B1783095FA9D0582C15731F10EEF3683C2443564CE8DC12AF248` | bilingual continuation, both footnotes, both source-page seams, running head, and footer are intact and unclipped |

The page-3/page-4 break occurs at the same semantic continuation in both
language columns and is intentional. The reader contains mathematical and
historical/editorial content only; no workflow, AI, retrospective, validation,
status, repair, or handoff prose is present.

Lead visual disposition: **PASS for the bounded printed-p.119 checkpoint**.
This is not a claim about printed pp.120--221 or about a public package.
