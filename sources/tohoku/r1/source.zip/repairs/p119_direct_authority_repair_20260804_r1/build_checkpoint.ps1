param()

$ErrorActionPreference = 'Stop'
$repairRoot = $PSScriptRoot
$projectRoot = Split-Path -Parent (Split-Path -Parent $repairRoot)
$buildRoot = Join-Path $repairRoot 'b\r1'
$outputRoot = Join-Path $repairRoot 'o'
$outputPdf = Join-Path $outputRoot 'tohoku_p119_bilingual_r1.pdf'
$source = 'repairs/p119_direct_authority_repair_20260804_r1/tex/readers/p119_r1.tex'
$localAppData = [Environment]::GetFolderPath('LocalApplicationData')
$pdfLatex = Join-Path $localAppData 'Programs\MiKTeX\miktex\bin\x64\pdflatex.exe'

if (Test-Path -LiteralPath $buildRoot) {
    throw "No-overwrite build generation exists: $buildRoot"
}
if (Test-Path -LiteralPath $outputPdf) {
    throw "No-overwrite reader exists: $outputPdf"
}
if (-not (Test-Path -LiteralPath $pdfLatex)) {
    throw "pdflatex missing at configured path"
}

New-Item -ItemType Directory -Path $buildRoot | Out-Null
New-Item -ItemType Directory -Path $outputRoot | Out-Null
$commandLog = Join-Path $buildRoot 'command.log'

Push-Location $projectRoot
try {
    $arguments = @(
        '-interaction=nonstopmode',
        '-halt-on-error',
        '-file-line-error',
        "-output-directory=$buildRoot",
        $source
    )
    for ($pass = 1; $pass -le 2; $pass++) {
        "PASS $pass" | Add-Content -LiteralPath $commandLog -Encoding utf8NoBOM
        & $pdfLatex @arguments 2>&1 | Add-Content -LiteralPath $commandLog -Encoding utf8NoBOM
        if ($LASTEXITCODE -ne 0) {
            throw "pdflatex failed on pass $pass"
        }
    }
}
finally {
    Pop-Location
}

$builtPdf = Join-Path $buildRoot 'p119_r1.pdf'
if (-not (Test-Path -LiteralPath $builtPdf)) {
    throw "Expected PDF absent: $builtPdf"
}
Copy-Item -LiteralPath $builtPdf -Destination $outputPdf

$item = Get-Item -LiteralPath $outputPdf
[pscustomobject]@{
    path = 'o/tohoku_p119_bilingual_r1.pdf'
    bytes = $item.Length
    sha256 = (Get-FileHash -LiteralPath $outputPdf -Algorithm SHA256).Hash
} | ConvertTo-Json
