# Printed p.119 repair continuation handoff

Purpose: resume the Tôhoku canonical bilingual corpus without reconstructing
the p.119 repair from chat history.

## Resume order

1. Rehash and read this file, `STATUS.md`, `LEAD_VISUAL_QA_R1.md`,
   `CHECKPOINT_MANIFEST_R1.csv`, and `CHECKPOINT_VALIDATION_R1.json` through
   EOF.
2. Require validation status `PASS` with `errors: []` and `warnings: []`.
3. Rehash the authority-comparison R2 control and require 102 paired pages,
   102 matches, zero holds, and local page 66 as the sole blank interleaf.
4. Rehash the four adverse predecessor files and confirm that none was
   overwritten.
5. Resume at printed p.120 only. Do not reopen another corpus.

## Frozen p.119 contract

- repaired diplomatic French:
  `TOHOKU_REPAIR_R1/tex/fr_diplomatic/p119.tex`;
- separately instantiated corrected French:
  `TOHOKU_REPAIR_R1/tex/fr_corrected/p119.tex`;
- source-aligned English:
  `TOHOKU_REPAIR_R1/tex/en/p119.tex`;
- shared semantic scaffold: `TOHOKU_REPAIR_R1/semantics/`;
- append-only repair ledgers: the five root-level JSONL files;
- reader: `TOHOKU_REPAIR_R1/o/tohoku_p119_bilingual_r1.pdf`;
- lead-owned source and reader inspection: `LEAD_VISUAL_QA_R1.md`.

The exact p.119 source identity is official Part I page 1, 7,305,283 bytes,
SHA-256
`5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`.
The repaired layer identities and every QA evidence identity are carried in
the generation manifest and validation receipt.

## Open paper-wide work

- Transcribe and translate pp.120--221 sequentially, stopping after printed
  p.221.
- Close forward chapter, section, theorem, and bibliography placeholders when
  their controlling source coordinates are admitted.
- Regenerate reference candidates after every changed source hash; never
  retain offsets or identities from a superseded layer.
- Confirm pre-Stacks mappings only against official Stacks evidence; candidate
  descriptions are not official tags.
- Leave SGA/EGA/FGA external target IDs null in this exclusive lane. The six
  p.119 cross-work rows are schema-ready unresolved stubs, not asserted
  relations.
- Build complete paper and sensible part readers only from fully admitted
  units. Reader PDFs may contain mathematics and genuine historical/editorial
  matter, never workflow, AI, status, validation, or handoff prose.
- Preserve French TeX privately and treat any public French redistribution as
  a separate rights-aware decision.
- Run only one heavy build or render at a time; never scan a profile,
  Documents, or a drive root; never generate new OCR.

## Global repair propagation rule

Any later correction must append a new decision that names the superseded
decision and closes its impact across diplomatic French, corrected French,
English, semantic nodes, alignments, references, readers, manifests, package,
and any public record. A discovered global defect blocks promotion until every
affected artifact is rebuilt or explicitly proved unaffected.
