# Printed p.119 direct-authority repair generation r1

Status: open, no-overwrite successor; old p.119 artifacts remain immutable
adverse history.

## Authority

- Official J-STAGE Part I PDF, one-based page 1 / printed p.119.
- PDF bytes: 7,305,283.
- PDF SHA-256:
  `5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`.
- DOI: `10.2748/tmj/1178244839`.
- No OCR is authorized or used.

## Adverse predecessor identities

- diplomatic French: 3,422 bytes,
  `B8FB69418F7C95EF402E55C3D87F53819321750D5148D053EB13AE263E1A4985`;
- corrected French: 3,450 bytes,
  `65833D06FA8A5C6892ABC965383E978BCAFAC4E5837E47643F589F6C436D1B76`;
- source-aligned English: 3,245 bytes,
  `844DCECD253BE8FA552DF95AF786E55BC321338AC3E074589E042BBA5414EB20`;
- source-correction ledger: 1,204 bytes,
  `6B17B608E2583363863EF715F6BEF03036625677F2BC287651B1F2A266284F64`.

The old French layers systematically strip printed diacritics while the old
correction disposition says the corrected French is identical to diplomatic
French and admits no source correction. This generation replays the complete
page from direct authority, records every supersession append-only, and does
not overwrite any predecessor file.

## Operating bounds

- One 1,200-dpi-equivalent grayscale authority render, inspected only through
  sequential bounded bands.
- Additional 5,000--9,000-dpi-equivalent crops only for genuinely ambiguous
  small marks.
- Lead makes every textual, mathematical, and visual decision.
- Diplomatic French, corrected French, and English remain distinct.
- Build outputs, if any, are generation-addressed below this repair root.
- No publication, package, archive, or cross-corpus mutation.
