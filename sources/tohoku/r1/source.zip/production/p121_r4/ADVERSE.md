# R4 adverse build

R4 is preserved and rejected. Its local 1.5-em emergency stretch did not alter
the line solution: both passes still report the same 0.74916-pt overfull box in
the English section 4.2 contents entry.

- Reader source: `tex/readers/p121.tex`, 2,224 bytes, SHA-256
  `AC2A5010CCE1A8E85CA5911F4FD47B051E54F0FFDC5780BDB8A8F6EF10023CCF`.
- Command log: `b/command.log`, 17,269 bytes, SHA-256
  `D08F5C65F84B13F45E5E6F51CE1E31C9F6EAFE08ABAA5EB3E32EE0F0D9FA1931`.
- TeX log: `b/p121.log`, 27,169 bytes, SHA-256
  `FE0E17044DB60CD2B2BD1B1647D680299AE21B7DFC3D1570D663B46698051773`.
- Reader PDF: `o/p121.pdf`, 409,952 bytes, SHA-256
  `F29A3462CF196A1B57629F6580C69E890088A137BE2D876E06BBAB19A942EA80`.

No language or semantic file changed. R4 must not be promoted, rebuilt, or
overwritten. The next repair belongs to `p121_r5`.
