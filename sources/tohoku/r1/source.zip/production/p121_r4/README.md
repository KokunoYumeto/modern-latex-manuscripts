# p.121 R4

R4 inherits the byte-identical language layers and semantic scaffold from R3.
It adds only bounded emergency stretch inside the parallel reader, addressing
the preserved R3 overfull-box failure without changing scholarly text.

Direct authority evidence is in `../p121_direct_authority_20260804_r1`; failed
R2 and R3 generations remain preserved beside this root.
