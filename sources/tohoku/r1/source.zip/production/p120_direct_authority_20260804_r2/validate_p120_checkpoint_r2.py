from __future__ import annotations

import csv
import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

from pypdf import PdfReader


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent.parent
P120_R1 = ROOT.parent / "p120_direct_authority_20260804_r1"
P119 = PROJECT / "repairs" / "p119_direct_authority_repair_20260804_r1"
MANIFEST = ROOT / "CHECKPOINT_MANIFEST_R2.csv"
VALIDATION = ROOT / "CHECKPOINT_VALIDATION_R2.json"

if MANIFEST.exists() or VALIDATION.exists():
    raise SystemExit("No-overwrite validation generation already exists")

errors: list[str] = []
warnings: list[str] = []
manifest_rows: list[dict[str, object]] = []
actual_paths: dict[str, Path] = {}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def identity(path: Path) -> tuple[int, str] | None:
    if not path.is_file():
        return None
    return path.stat().st_size, sha256(path)


def check(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)


def assert_identity(path: Path, size: int, digest: str, label: str) -> None:
    got = identity(path)
    if got is None:
        errors.append(f"{label} is missing")
        return
    check(got[0] == size, f"{label} byte count drifted: {got[0]} != {size}")
    check(got[1] == digest.upper(), f"{label} SHA-256 drifted: {got[1]}")


def csv_rows(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        errors.append(f"CSV missing: {path.name}")
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def unique(rows: list[dict[str, str]], field: str, label: str) -> None:
    values = [row.get(field, "") for row in rows]
    check(all(values), f"{label} has a blank {field}")
    check(len(values) == len(set(values)), f"{label} has duplicate {field} values")


def add_manifest(
    artifact_id: str,
    root_alias: str,
    relative_path: str,
    role: str,
    path: Path,
    read_completeness: str,
    public_projection: str,
) -> None:
    got = identity(path)
    if got is None:
        errors.append(f"manifest artifact missing: {artifact_id}")
        return
    manifest_rows.append(
        {
            "artifact_id": artifact_id,
            "root_alias": root_alias,
            "relative_path": relative_path.replace("\\", "/"),
            "role": role,
            "bytes": got[0],
            "sha256": got[1],
            "read_completeness": read_completeness,
            "public_projection": public_projection,
        }
    )
    actual_paths[artifact_id] = path


def canonical_layer(path: Path) -> bytes:
    lines = path.read_text(encoding="utf-8-sig").splitlines()
    return "\n".join(line for line in lines if not line.startswith("%")).encode("utf-8")


def privacy_hits(text: str) -> dict[str, int]:
    patterns = {
        "private_user_root": r"(?i)[A-Z]:[\\/]Users[\\/]",
        "codex_state": r"(?i)\.codex[\\/]",
        "operator_name": r"(?i)Floris",
        "task_uuid": r"(?i)(?<![0-9a-f])[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}(?![0-9a-f])",
    }
    return {name: len(re.findall(pattern, text)) for name, pattern in patterns.items()}


# Exact authority and predecessor bindings.
authority_i = PROJECT / "authority_snapshot" / "jstage_part_I_9_2_119.pdf"
authority_ii = PROJECT / "authority_snapshot" / "jstage_part_II_9_3_185.pdf"
authority_map = PROJECT / "controls" / "AUTHORITY_IMAGE_COMPARISON_R2.json"
source_authority = PROJECT / "SOURCE_AUTHORITY.csv"
preamble = PROJECT / "tex" / "common" / "preamble.tex"

assert_identity(authority_i, 7_305_283, "5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF", "official Part I")
assert_identity(authority_ii, 3_984_260, "8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53", "official Part II")
assert_identity(authority_map, 74_608, "B4E04B2A31DB5CC60BE423F27813C5B168795252CF3C5194BE6FA6E46975DC34", "authority comparison R2")
assert_identity(preamble, 1_387, "2498C6D7FEAE365476C04446AFB1E85C2AE843DA673656B2AB3F6A0953F3696C", "reader preamble")
assert_identity(P119 / "CHECKPOINT_MANIFEST_R2.csv", 13_442, "3D9F0EC46AA721BE998B8B228A8B26587AA8813E0D75FB0774ADF28059FB363D", "p119 manifest R2")
assert_identity(P119 / "CHECKPOINT_VALIDATION_R2.json", 4_005, "062F64BD1507B8751AF8B712E4CDEB30F7AAB87E3E4241147C062BAE0A0117E9", "p119 validation R2")
assert_identity(P119 / "o" / "tohoku_p119_bilingual_r1.pdf", 273_464, "493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E", "p119 reader")

source_rows = csv_rows(source_authority)
check(len(source_rows) == 3, "SOURCE_AUTHORITY.csv must have three rows")
source_by_id = {row.get("witness_id", ""): row for row in source_rows}
check(source_by_id.get("TOH-AUTH-JSTAGE-I", {}).get("doi") == "10.2748/tmj/1178244839", "Part I DOI drifted")
check(source_by_id.get("TOH-AUTH-JSTAGE-II", {}).get("doi") == "10.2748/tmj/1178244774", "Part II DOI drifted")
local_value = source_by_id.get("TOH-COMP-LOCAL-103P", {}).get("path_or_url", "")
local_witness = Path(local_value) if local_value else Path("__missing_local_witness__")
assert_identity(local_witness, 12_897_534, "57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78", "local 103-page witness")

comparison = json.loads(authority_map.read_text(encoding="utf-8-sig"))
summary = comparison.get("summary", {})
check(summary.get("paired_pages") == 102, "authority comparison paired-page count drifted")
check(summary.get("matches") == 102, "authority comparison match count drifted")
check(summary.get("holds") == 0, "authority comparison has a hold")
p120_rows = [row for row in comparison.get("pages", []) if row.get("printed_page") == 120]
check(len(p120_rows) == 1, "authority comparison p120 row is not unique")
if len(p120_rows) == 1:
    row = p120_rows[0]
    check(row.get("local_pdf_page") == 2, "p120 local witness coordinate drifted")
    check(row.get("official_pdf_page") == 2, "p120 official coordinate drifted")
    check(row.get("official_part") == "part_I", "p120 authority part drifted")
    check(row.get("status") == "MATCH", "p120 authority comparison is not MATCH")

# Preserve and bind the adverse R1 generation.
assert_identity(P120_R1 / "o" / "tohoku_p120_bilingual_r1.pdf", 267_066, "0CD4896BE7FB8B1F97B8B9C3828477AC78D39A22308433A8A8974C93D4A25ED3", "adverse p120 R1 reader")
assert_identity(P120_R1 / "tex" / "fr_diplomatic" / "p120.tex", 4_048, "555446F5DA4CAFAF421A86CE4176420F1A2E5876A184391843CB27B78482F59A", "adverse p120 R1 diplomatic")
assert_identity(P120_R1 / "tex" / "fr_corrected" / "p120.tex", 4_069, "B842A750D9E6429183C8E88A5BD738795F1E3256DA5DFFDBE037240E228588D6", "adverse p120 R1 corrected")
assert_identity(P120_R1 / "tex" / "en" / "p120.tex", 3_775, "7B711A9F6B4EDAD1F5E18B167924C6F097D16A744C9B691D126410BCDFF30DAB", "adverse p120 R1 English")
assert_identity(P120_R1 / "semantics" / "BILINGUAL_UNIT_ALIGNMENT.csv", 4_098, "B01DE27B504BBD97D1A2F51B8B3184039AA6C0BB39E0B13ECD0B7D1D90D813EE", "adverse p120 R1 alignment")
assert_identity(P120_R1 / "semantics" / "REFERENCE_EDGES.csv", 3_656, "425B8C73DA05914A23F9E895AABADDF3F4C013945218C709478A641355DE21BA", "adverse p120 R1 edges")

# Active layer identities and separation contract.
layer_rel = ["tex/fr_diplomatic/p120.tex", "tex/fr_corrected/p120.tex", "tex/en/p120.tex"]
layer_paths = {rel: ROOT / rel for rel in layer_rel}
expected_layers = {
    "tex/fr_diplomatic/p120.tex": (4_163, "AA982B53C7F7FAE36CC90DB43B2E68FD19C37A297877F470C8630FFFB4F30B6B"),
    "tex/fr_corrected/p120.tex": (4_184, "51C383ECDB9BB328395A00867851DC0802EA0ABB1243E4E3F2B9AC73E560A570"),
    "tex/en/p120.tex": (3_890, "EA9B809AEDF7D36A5FB6F8C27F7B83CAA91C287267BEF74F808B3FF956EDFB67"),
}
for rel, (size, digest) in expected_layers.items():
    assert_identity(layer_paths[rel], size, digest, rel)

check(canonical_layer(layer_paths[layer_rel[0]]) == canonical_layer(layer_paths[layer_rel[1]]), "corrected and diplomatic French bodies differ")
check(layer_paths[layer_rel[0]].read_bytes() != layer_paths[layer_rel[1]].read_bytes(), "corrected and diplomatic French are not separately instantiated")
check(layer_paths[layer_rel[0]].read_bytes() != layer_paths[layer_rel[2]].read_bytes(), "English and diplomatic layers are conflated")

# Append-only decision ledgers.
decision_files = [
    "TRANSCRIPTION_DECISIONS.jsonl",
    "SOURCE_CORRECTION_DISPOSITION.jsonl",
    "NORMALIZATION_DECISIONS.jsonl",
    "TRANSLATION_DECISIONS.jsonl",
]
decision_ids: list[str] = []
for name in decision_files:
    for line_number, line in enumerate((ROOT / name).read_text(encoding="utf-8-sig").splitlines(), 1):
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError as exc:
            errors.append(f"{name}:{line_number} invalid JSON: {exc}")
            continue
        decision_id = obj.get("decision_id", "")
        check(bool(decision_id), f"{name}:{line_number} lacks decision_id")
        decision_ids.append(decision_id)
check(len(decision_ids) == 21, f"decision count is {len(decision_ids)}, expected 21")
check(len(decision_ids) == len(set(decision_ids)), "decision IDs are not unique")
for required in ["TOH-P120-R2-REV-001", "TOH-P120-R2-REV-002", "TOH-P120-R2-REV-003", "TOH-P120-R2-NORM-001"]:
    check(required in decision_ids, f"repair decision missing: {required}")

# Machine-readable scaffold.
expected_counts = {
    "SOURCE_PAGE_MAP.csv": 1,
    "SEMANTIC_NODES.csv": 54,
    "BILINGUAL_UNIT_ALIGNMENT.csv": 11,
    "TERM_INDEX.csv": 25,
    "PAGE_OBJECT_COUNTS.csv": 1,
    "FORMULA_INDEX.csv": 16,
    "DIAGRAM_INDEX.csv": 0,
    "ID_MIGRATIONS.csv": 0,
    "REFERENCE_CANDIDATES.csv": 21,
    "REFERENCE_EDGES.csv": 21,
    "REFERENCE_RESIDUALS.csv": 14,
    "BIBLIOGRAPHY_INDEX.csv": 6,
    "PRESTACKS_CANDIDATES.csv": 15,
    "PRESTACKS_CONFIRMED.csv": 0,
    "CROSS_WORK_RELATION_CANDIDATES.csv": 6,
    "SUBJECT_INDEX.csv": 12,
    "DECISION_ARTIFACT_BINDINGS.csv": 21,
}
id_fields = {
    "SOURCE_PAGE_MAP.csv": "page_map_id",
    "SEMANTIC_NODES.csv": "node_id",
    "BILINGUAL_UNIT_ALIGNMENT.csv": "alignment_id",
    "TERM_INDEX.csv": "term_id",
    "PAGE_OBJECT_COUNTS.csv": "page_inventory_id",
    "FORMULA_INDEX.csv": "formula_id",
    "DIAGRAM_INDEX.csv": "diagram_id",
    "ID_MIGRATIONS.csv": "migration_id",
    "REFERENCE_CANDIDATES.csv": "candidate_id",
    "REFERENCE_EDGES.csv": "edge_id",
    "REFERENCE_RESIDUALS.csv": "residual_id",
    "BIBLIOGRAPHY_INDEX.csv": "bibliography_node_id",
    "PRESTACKS_CANDIDATES.csv": "mapping_id",
    "PRESTACKS_CONFIRMED.csv": "mapping_id",
    "CROSS_WORK_RELATION_CANDIDATES.csv": "relation_candidate_id",
    "SUBJECT_INDEX.csv": "subject_entry_id",
    "DECISION_ARTIFACT_BINDINGS.csv": "binding_id",
}
tables = {name: csv_rows(ROOT / "semantics" / name) for name in expected_counts}
for name, count in expected_counts.items():
    check(len(tables[name]) == count, f"{name} has {len(tables[name])} rows, expected {count}")
    unique(tables[name], id_fields[name], name)

nodes = tables["SEMANTIC_NODES.csv"]
node_map = {row["node_id"]: row for row in nodes}
for node in nodes:
    if node["parent_id"]:
        check(node["parent_id"] in node_map, f"node parent missing: {node['node_id']} -> {node['parent_id']}")
    check(node["provenance_decision"] in decision_ids, f"node provenance decision missing: {node['node_id']}")

layer_hashes = {rel: sha256(path) for rel, path in layer_paths.items()}
alignment = tables["BILINGUAL_UNIT_ALIGNMENT.csv"]
alignment_nodes = {row["node_id"] for row in alignment}
target_sets: dict[str, set[str]] = {}
for rel, path in layer_paths.items():
    targets = re.findall(r"\\LayerTarget\{([^}]+)\}", path.read_text(encoding="utf-8-sig"))
    check(len(targets) == len(set(targets)), f"duplicate LayerTarget in {rel}")
    target_sets[rel] = set(targets)
    check(set(targets) == alignment_nodes, f"LayerTarget/alignment set mismatch in {rel}")

for row in alignment:
    check(row["node_id"] in node_map, f"alignment node missing: {row['alignment_id']}")
    path_fields = [
        ("fr_diplomatic_path", "fr_diplomatic_sha256"),
        ("fr_corrected_path", "fr_corrected_sha256"),
        ("en_path", "en_sha256"),
    ]
    for path_field, hash_field in path_fields:
        rel = row[path_field]
        check(rel in layer_hashes, f"alignment path unexpected: {row['alignment_id']} -> {rel}")
        if rel in layer_hashes:
            check(row[hash_field].upper() == layer_hashes[rel], f"alignment hash stale: {row['alignment_id']} -> {rel}")
    cited = set(filter(None, row["decision_ids"].split(";")))
    check(cited <= set(decision_ids), f"alignment cites unknown decision: {row['alignment_id']}")
    check("TOH-P120-R1-SRC-DISPOSITION-001" in cited, f"alignment lacks corrected-layer disposition: {row['alignment_id']}")

bindings = tables["DECISION_ARTIFACT_BINDINGS.csv"]
binding_decisions = [row["decision_id"] for row in bindings]
check(set(binding_decisions) == set(decision_ids), "decision/artifact binding set does not equal decision set")
check(len(binding_decisions) == len(set(binding_decisions)), "a decision has more than one canonical binding row")

for row in tables["TERM_INDEX.csv"]:
    check(row["node_id"] in node_map, f"term node missing: {row['term_id']}")
    check(row["decision_id"] in decision_ids, f"term decision missing: {row['term_id']}")
for row in tables["SUBJECT_INDEX.csv"]:
    check(row["node_id"] in node_map, f"subject node missing: {row['subject_entry_id']}")
for row in tables["FORMULA_INDEX.csv"]:
    check(row["owner_node_id"] in node_map, f"formula owner missing: {row['formula_id']}")
    check((ROOT / row["tex_path"]).is_file(), f"formula TeX path missing: {row['formula_id']}")
for row in tables["BIBLIOGRAPHY_INDEX.csv"]:
    check(row["bibliography_node_id"] in node_map, f"bibliography node missing: {row['bibliography_node_id']}")
    mentions = list(filter(None, row["mention_nodes"].split(";")))
    check(int(row["mention_count_on_p120"]) == len(mentions), f"bibliography mention count mismatch: {row['bibliography_node_id']}")
    check(all(mention in node_map for mention in mentions), f"bibliography mention node missing: {row['bibliography_node_id']}")

candidates = tables["REFERENCE_CANDIDATES.csv"]
edges = tables["REFERENCE_EDGES.csv"]
candidate_map = {row["candidate_id"]: row for row in candidates}
edge_map = {row["candidate_id"]: row for row in edges}
check(set(candidate_map) == set(edge_map), "reference candidate/edge sets differ")
for candidate_id, candidate in candidate_map.items():
    edge = edge_map.get(candidate_id)
    if edge is None:
        continue
    check(candidate["source_node_id"] in node_map, f"candidate source missing: {candidate_id}")
    check(candidate["source_hash"].upper() == layer_hashes[layer_rel[0]], f"candidate source hash stale: {candidate_id}")
    check(candidate["terminal_state"] == "admitted_edge", f"candidate terminal state is not admitted_edge: {candidate_id}")
    check(candidate["target_hint"] == edge["target_node_id"], f"candidate/edge target mismatch: {candidate_id}")
    check(candidate["source_node_id"] == edge["source_node_id"], f"candidate/edge source mismatch: {candidate_id}")
    check(edge["target_node_id"] in node_map, f"edge target missing: {candidate_id}")
    if edge["target_node_id"] in node_map:
        check(edge["target_state"] == node_map[edge["target_node_id"]]["state"], f"edge target-state mismatch: {candidate_id}")

residuals = tables["REFERENCE_RESIDUALS.csv"]
check({row["candidate_or_target_id"] for row in residuals} == {row["target_node_id"] for row in edges}, "reference residual target set is incomplete")
check(all(row["state"] == "open" for row in residuals), "a p120 target residual is not open")
check(all(not row["official_stacks_tag"] for row in tables["PRESTACKS_CANDIDATES.csv"]), "an official Stacks tag was invented")
check(not tables["PRESTACKS_CONFIRMED.csv"], "confirmed Stacks table is not empty")
check(all(not row["target_external_id"] for row in tables["CROSS_WORK_RELATION_CANDIDATES.csv"]), "an external cross-work ID was invented")
check(all(not row["exact_work_identity"] for row in tables["BIBLIOGRAPHY_INDEX.csv"]), "bibliography work identity was admitted before p221")

page_count = tables["PAGE_OBJECT_COUNTS.csv"][0] if tables["PAGE_OBJECT_COUNTS.csv"] else {}
for field, expected in {
    "semantic_text_units": 11,
    "formula_count": 16,
    "diagram_count": 0,
    "reference_candidate_count": 21,
    "term_rows": 25,
}.items():
    check(page_count.get(field) == str(expected), f"PAGE_OBJECT_COUNTS {field} drifted")

for name, rows in tables.items():
    for line_number, row in enumerate(rows, 2):
        for field, value in row.items():
            check(not re.match(r"^\s*[=+\-@]", value or ""), f"spreadsheet trigger: {name}:{line_number}:{field}")

# Reader, build, render, and privacy gates.
reader = ROOT / "o" / "tohoku_p120_bilingual_r2.pdf"
assert_identity(reader, 266_946, "61B350EC50101A40B543DB6F57EF8145AE9F0484788857F8F14AF845BD9C7DDB", "p120 R2 reader")
render_expected = {
    "qa/reader_r2_180dpi/page-1.png": (87_180, "1C76BAEE5D345479B8DDDA1CE165566D31DCAE6C7994AC4E5EA2592F056FCD7B"),
    "qa/reader_r2_180dpi/page-2.png": (424_423, "7858C150F5CD0D1B1F60CC3313CEBA47AC121CBD72395A96E1987AE248CCEC1C"),
    "qa/reader_r2_180dpi/page-3.png": (514_587, "788D48268A499B9F6B35E1E5533A9CF9AB250893AC46129194EA17DF657820B7"),
    "qa/reader_r2_180dpi/page-4.png": (410_585, "977C081102DAA50B2037FBC7935145A3CF414694E44D7E6B648EE090F103983B"),
}
for rel, (size, digest) in render_expected.items():
    assert_identity(ROOT / rel, size, digest, rel)
text_path = ROOT / "qa" / "reader_r2_text.txt"
assert_identity(text_path, 11_963, "825D9CFF2BD69FD674220C2420E62EEDD410200777694CF476EAF6D70FC38F6B", "reader text extraction")

build_log = (ROOT / "b" / "r2" / "command.log").read_text(encoding="utf-8-sig")
check(build_log.count("PASS 1") == 1 and build_log.count("PASS 2") == 1, "build log does not contain exactly two passes")
check(not re.search(r"(?i)warning|error|overfull|underfull|undefined|multiply defined|missing character|fatal", build_log), "build log contains an adverse diagnostic")

pdf = PdfReader(str(reader))
check(len(pdf.pages) == 4, f"reader has {len(pdf.pages)} pages, expected 4")
link_counts = {"total": 0, "goto": 0, "uri": 0, "other": 0}
uris: list[str] = []
image_xobjects = 0
for page in pdf.pages:
    for annotation_ref in page.get("/Annots", []) or []:
        annotation = annotation_ref.get_object()
        if annotation.get("/Subtype") != "/Link":
            continue
        link_counts["total"] += 1
        action = annotation.get("/A")
        if not action:
            link_counts["other"] += 1
            continue
        action = action.get_object()
        action_type = action.get("/S")
        if action_type == "/GoTo":
            link_counts["goto"] += 1
        elif action_type == "/URI":
            link_counts["uri"] += 1
            uris.append(str(action.get("/URI")))
        else:
            link_counts["other"] += 1
    resources = page.get("/Resources") or {}
    xobjects = resources.get("/XObject") if resources else None
    if xobjects:
        for reference in xobjects.get_object().values():
            if reference.get_object().get("/Subtype") == "/Image":
                image_xobjects += 1
check(link_counts == {"total": 1, "goto": 0, "uri": 1, "other": 0}, f"reader link actions drifted: {link_counts}")
check(uris == ["https://doi.org/10.2748/tmj/1178244839"], f"reader URI set drifted: {uris}")
check(image_xobjects == 0, "reader contains an image XObject")

font_command = subprocess.run(["pdffonts", str(reader)], capture_output=True, text=True, encoding="utf-8", errors="replace")
check(font_command.returncode == 0, "pdffonts failed")
font_lines = [line for line in font_command.stdout.splitlines() if re.search(r"\byes\s+yes\s+yes\s+\d+\s+\d+\s*$", line)]
check(len(font_lines) == 13, f"embedded/subset/Unicode font rows are {len(font_lines)}, expected 13")

reader_text = text_path.read_text(encoding="utf-8-sig", errors="replace")
for phrase in [
    "Čechiste",
    "Čechist",
    "Ext",
    "Steenrod",
    "III. Lacunes.",
    "III. Gaps.",
    "Pour la multiplication en cohomologie",
    "For multiplication in cohomology",
]:
    check(phrase in reader_text, f"reader text lacks expected phrase: {phrase}")
check(len(re.findall(r"Continued on source p\. 121\.", reader_text)) == 3, "reader does not have exactly three p121 continuation notices")
reader_privacy = privacy_hits(reader_text)
check(all(value == 0 for value in reader_privacy.values()), f"reader privacy hits: {reader_privacy}")
workflow_hits = len(re.findall(r"(?i)\b(?:workflow|checkpoint|status|chatgpt|codex|artificial intelligence|language model)\b", reader_text))
check(workflow_hits == 0, f"reader workflow/AI/status prose hits: {workflow_hits}")

# Construct a closed, privacy-safe checkpoint manifest. The manifest and its
# validation receipt are self-excluded to avoid recursive identities.
external_artifacts = [
    ("AUTH-I", "TOHOKU_PROJECT", "authority_snapshot/jstage_part_I_9_2_119.pdf", "official Part I image authority", authority_i, "rehash_complete", "excluded_authority_pdf"),
    ("AUTH-II", "TOHOKU_PROJECT", "authority_snapshot/jstage_part_II_9_3_185.pdf", "official Part II image authority", authority_ii, "rehash_complete", "excluded_authority_pdf"),
    ("AUTH-MAP-R2", "TOHOKU_PROJECT", "controls/AUTHORITY_IMAGE_COMPARISON_R2.json", "102-page no-OCR authority binding", authority_map, "read_complete", "internal_control"),
    ("SOURCE-AUTHORITY", "TOHOKU_PROJECT", "SOURCE_AUTHORITY.csv", "source authority registry", source_authority, "read_complete", "excluded_private_binding"),
    ("LOCAL-103P", "TOHOKU_LOCAL_WITNESS", "witness.pdf", "admitted local comparison witness", local_witness, "rehash_complete", "excluded_comparison_pdf"),
    ("PREAMBLE", "TOHOKU_PROJECT", "tex/common/preamble.tex", "reader preamble", preamble, "read_complete", "rights_review_required"),
    ("P119-MANIFEST-R2", "P119_REPAIR", "CHECKPOINT_MANIFEST_R2.csv", "prior page manifest", P119 / "CHECKPOINT_MANIFEST_R2.csv", "replay_complete", "internal_control"),
    ("P119-VALIDATION-R2", "P119_REPAIR", "CHECKPOINT_VALIDATION_R2.json", "prior page validation", P119 / "CHECKPOINT_VALIDATION_R2.json", "replay_complete", "internal_control"),
    ("P119-READER", "P119_REPAIR", "o/tohoku_p119_bilingual_r1.pdf", "prior page reader", P119 / "o" / "tohoku_p119_bilingual_r1.pdf", "replay_complete", "rights_review_required"),
    ("P120-R1-READER", "P120_R1", "o/tohoku_p120_bilingual_r1.pdf", "adverse five-page reader", P120_R1 / "o" / "tohoku_p120_bilingual_r1.pdf", "replay_complete", "excluded_adverse_history"),
    ("P120-R1-DIP", "P120_R1", "tex/fr_diplomatic/p120.tex", "adverse diplomatic layer", P120_R1 / "tex" / "fr_diplomatic" / "p120.tex", "replay_complete", "excluded_adverse_history"),
    ("P120-R1-COR", "P120_R1", "tex/fr_corrected/p120.tex", "adverse corrected layer", P120_R1 / "tex" / "fr_corrected" / "p120.tex", "replay_complete", "excluded_adverse_history"),
    ("P120-R1-EN", "P120_R1", "tex/en/p120.tex", "adverse English layer", P120_R1 / "tex" / "en" / "p120.tex", "replay_complete", "excluded_adverse_history"),
    ("P120-R1-ALIGN", "P120_R1", "semantics/BILINGUAL_UNIT_ALIGNMENT.csv", "adverse alignment table", P120_R1 / "semantics" / "BILINGUAL_UNIT_ALIGNMENT.csv", "replay_complete", "excluded_adverse_history"),
    ("P120-R1-EDGES", "P120_R1", "semantics/REFERENCE_EDGES.csv", "adverse edge table", P120_R1 / "semantics" / "REFERENCE_EDGES.csv", "replay_complete", "excluded_adverse_history"),
]
for args in external_artifacts:
    add_manifest(*args)

qa_external = [
    "p120_1200g.png",
    "b1.png",
    "b2.png",
    "b3.png",
    "b4.png",
    "cechiste_locator_1200.png",
    "cechiste_7000.png",
    "multiplicative_phrase_locator_1200.png",
    "multiplicative_phrase_locator2_1200.png",
]
for index, name in enumerate(qa_external, 1):
    add_manifest(
        f"P120-AUTH-QA-{index:02d}",
        "P120_R1",
        f"qa/{name}",
        "direct-authority visual evidence",
        P120_R1 / "qa" / name,
        "lead_inspected",
        "excluded_authority_render",
    )

active_relations: list[tuple[str, str, str]] = [
    ("README.md", "checkpoint README", "internal_control"),
    ("R1_ADVERSE_FINDINGS_AND_R2_CLOSURE.md", "adverse finding and repair closure", "internal_control"),
    ("LEAD_VISUAL_QA_R2.md", "lead visual QA", "internal_control"),
    ("STATUS.md", "bounded checkpoint status", "internal_control"),
    ("CONTINUATION_HANDOFF.md", "successor handoff", "internal_control"),
    ("TRANSCRIPTION_DECISIONS.jsonl", "transcription decisions", "rights_review_required"),
    ("SOURCE_CORRECTION_DISPOSITION.jsonl", "correction disposition", "rights_review_required"),
    ("NORMALIZATION_DECISIONS.jsonl", "normalization and repair ledger", "rights_review_required"),
    ("TRANSLATION_DECISIONS.jsonl", "translation decisions", "rights_review_required"),
    ("build_checkpoint.ps1", "no-overwrite build procedure", "internal_control"),
    ("validate_p120_checkpoint_r2.py", "validation procedure", "internal_control"),
    ("replay_p120_checkpoint_r2.py", "independent manifest replay procedure", "internal_control"),
    ("tex/fr_diplomatic/p120.tex", "diplomatic French", "rights_review_required"),
    ("tex/fr_corrected/p120.tex", "corrected French", "rights_review_required"),
    ("tex/en/p120.tex", "source-aligned English", "rights_review_required"),
    ("tex/readers/p120_r2.tex", "reader source", "rights_review_required"),
    ("o/tohoku_p120_bilingual_r2.pdf", "active bilingual reader", "rights_review_required"),
    ("qa/reader_r2_text.txt", "reader text QA", "internal_qa"),
    ("b/r2/command.log", "build command log", "internal_qa"),
    ("b/r2/p120_r2.log", "TeX build log", "internal_qa"),
]
for name in sorted(expected_counts):
    active_relations.append((f"semantics/{name}", "machine-readable semantic scaffold", "rights_review_required"))
for name in sorted(render_expected):
    active_relations.append((name, "reader-page render", "internal_qa"))

for index, (rel, role, projection) in enumerate(active_relations, 1):
    add_manifest(
        f"P120-R2-{index:03d}",
        "P120_R2",
        rel,
        role,
        ROOT / rel,
        "read_complete" if projection != "internal_qa" else "generated_and_checked",
        projection,
    )

artifact_ids = [str(row["artifact_id"]) for row in manifest_rows]
manifest_keys = [(str(row["root_alias"]), str(row["relative_path"])) for row in manifest_rows]
check(len(artifact_ids) == len(set(artifact_ids)), "manifest artifact IDs are not unique")
check(len(manifest_keys) == len(set(manifest_keys)), "manifest root/path keys are not unique")

public_text_hits: dict[str, dict[str, int]] = {}
for row in manifest_rows:
    if row["public_projection"] != "rights_review_required":
        continue
    path = actual_paths[str(row["artifact_id"])]
    if path.suffix.lower() == ".pdf":
        continue
    text = path.read_text(encoding="utf-8-sig", errors="replace")
    hits = privacy_hits(text)
    public_text_hits[str(row["artifact_id"])] = hits
    check(all(value == 0 for value in hits.values()), f"public-candidate privacy hit in {row['artifact_id']}: {hits}")

manifest_rows.sort(key=lambda row: (str(row["root_alias"]), str(row["relative_path"])))
canonical = "".join(
    f"{row['root_alias']}|{row['relative_path']}|{row['bytes']}|{row['sha256']}\n"
    for row in manifest_rows
).encode("utf-8")
aggregate = hashlib.sha256(canonical).hexdigest().upper()

with MANIFEST.open("w", encoding="utf-8", newline="") as stream:
    writer = csv.DictWriter(
        stream,
        fieldnames=["artifact_id", "root_alias", "relative_path", "role", "bytes", "sha256", "read_completeness", "public_projection"],
        lineterminator="\n",
        quoting=csv.QUOTE_ALL,
    )
    writer.writeheader()
    writer.writerows(manifest_rows)

manifest_identity = identity(MANIFEST)
status = "PASS" if not errors else "FAIL"
receipt = {
    "schema": "tohoku_p120_checkpoint_validation_v2",
    "generated_utc": "2026-08-04T04:02:05Z",
    "status": status,
    "errors": errors,
    "warnings": warnings,
    "scope": {
        "printed_page": 120,
        "official_part": "part_I",
        "official_pdf_page": 2,
        "local_witness_page": 2,
        "next_cursor": {"printed_page": 121, "official_pdf_page": 3, "local_witness_page": 3},
        "complete_paper_claim": False,
    },
    "authority": {
        "part_i_sha256": "5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF",
        "part_ii_sha256": "8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53",
        "local_witness_sha256": "57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78",
        "comparison_r2_sha256": "B4E04B2A31DB5CC60BE423F27813C5B168795252CF3C5194BE6FA6E46975DC34",
        "p120_match": True,
        "new_ocr": False,
    },
    "layers": {
        "diplomatic_sha256": layer_hashes[layer_rel[0]],
        "corrected_sha256": layer_hashes[layer_rel[1]],
        "english_sha256": layer_hashes[layer_rel[2]],
        "diplomatic_corrected_canonical_body_equal": canonical_layer(layer_paths[layer_rel[0]]) == canonical_layer(layer_paths[layer_rel[1]]),
        "separately_instantiated": True,
    },
    "semantic_counts": {
        "decisions": len(decision_ids),
        "decision_bindings": len(bindings),
        "nodes": len(nodes),
        "aligned_units": len(alignment),
        "layer_targets_each": {rel: len(values) for rel, values in target_sets.items()},
        "terms": len(tables["TERM_INDEX.csv"]),
        "formulas": len(tables["FORMULA_INDEX.csv"]),
        "diagrams": len(tables["DIAGRAM_INDEX.csv"]),
        "reference_candidates": len(candidates),
        "reference_edges": len(edges),
        "open_target_residuals": len(residuals),
        "pre_stacks_candidates": len(tables["PRESTACKS_CANDIDATES.csv"]),
        "official_stacks_tags": sum(bool(row["official_stacks_tag"]) for row in tables["PRESTACKS_CANDIDATES.csv"]),
        "cross_work_candidates": len(tables["CROSS_WORK_RELATION_CANDIDATES.csv"]),
        "external_cross_work_ids": sum(bool(row["target_external_id"]) for row in tables["CROSS_WORK_RELATION_CANDIDATES.csv"]),
    },
    "reader": {
        "bytes": reader.stat().st_size,
        "sha256": sha256(reader),
        "pages": len(pdf.pages),
        "font_rows_embedded_subset_unicode": len(font_lines),
        "image_xobjects": image_xobjects,
        "link_actions": link_counts,
        "uris": uris,
        "rendered_pages_lead_inspected": 4,
        "text_sha256": sha256(text_path),
        "privacy_hits": reader_privacy,
        "workflow_ai_status_hits": workflow_hits,
    },
    "adverse_predecessor": {
        "r1_reader_sha256": "0CD4896BE7FB8B1F97B8B9C3828477AC78D39A22308433A8A8974C93D4A25ED3",
        "r1_alignment_sha256": "B01DE27B504BBD97D1A2F51B8B3184039AA6C0BB39E0B13ECD0B7D1D90D813EE",
        "r1_edges_sha256": "425B8C73DA05914A23F9E895AABADDF3F4C013945218C709478A641355DE21BA",
        "preserved": True,
        "active": False,
    },
    "manifest": {
        "rows": len(manifest_rows),
        "total_bytes": sum(int(row["bytes"]) for row in manifest_rows),
        "canonicalization": "UTF-8 lines root_alias|relative_path|bytes|sha256\\n sorted ordinal by root_alias then relative_path",
        "aggregate_sha256": aggregate,
        "bytes": manifest_identity[0] if manifest_identity else None,
        "sha256": manifest_identity[1] if manifest_identity else None,
        "self_exclusions": ["CHECKPOINT_MANIFEST_R2.csv", "CHECKPOINT_VALIDATION_R2.json"],
    },
    "rights": {
        "public_redistribution_cleared": False,
        "authority_pdfs_in_public_projection": 0,
        "authority_renders_in_public_projection": 0,
        "rights_review_required": True,
    },
}

VALIDATION.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"status": status, "errors": errors, "warnings": warnings, "manifest": receipt["manifest"], "validation": {"bytes": VALIDATION.stat().st_size, "sha256": sha256(VALIDATION)}}, ensure_ascii=False, indent=2))
raise SystemExit(0 if status == "PASS" else 1)
