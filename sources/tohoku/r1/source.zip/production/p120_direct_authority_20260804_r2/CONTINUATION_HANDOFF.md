# Continuation handoff — after printed p.120 R2

## Objective and boundary

Continue the canonical bilingual Tôhoku paper sequentially through printed
p.221. The active next page is printed p.121. Do not open FGA, another
Grothendieck paper, EGA, SGA, Verdier, or Illusie. Do not run broad searches,
new OCR, parallel heavy builds, or renders.

## Required predecessor replay

Before p.121 mutation, rehash:

- p.119 validation R2: 4,005 bytes, SHA-256
  `062F64BD1507B8751AF8B712E4CDEB30F7AAB87E3E4241147C062BAE0A0117E9`;
- p.119 reader: 273,464 bytes, SHA-256
  `493E2A37A13E10CE486A19FF506A6C52D0EAE325D37D724A20180D6C6E28AA6E`;
- p.120 R2 diplomatic, corrected, English, and reader identities recorded in
  `STATUS.md`;
- authority comparison R2: 74,608 bytes, SHA-256
  `B4E04B2A31DB5CC60BE423F27813C5B168795252CF3C5194BE6FA6E46975DC34`;
- official Part I: 7,305,283 bytes, SHA-256
  `5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`;
- official Part II: 3,984,260 bytes, SHA-256
  `8D632A04EE0FA987B40B721BEE6E64BB3E641D6A1CE02335556213F1564C9A53`;
- local 103-page witness: 12,897,534 bytes, SHA-256
  `57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78`.

## Stable seam state

The p.120 paragraph `tohoku:introduction:III:p1` ends after `Pour la
multiplication en cohomologie`. The p.120 marker node
`tohoku:introduction:footnote:1bis` has state `marker_only_text_on_p121`.
Both require p.121 continuation, with the same stable IDs or an append-only ID
migration if direct authority disproves them.

Fourteen p.120 residuals remain open because their targets occur later or at
the final bibliography. They do not block the bounded p.120 candidate closure,
but they do block a complete-paper reference-completeness claim.

## p.121 operating sequence

1. Create a new no-overwrite p.121 production root.
2. Bind official Part I PDF page 3 / printed p.121 / local witness page 3 using
   the admitted authority comparison row.
3. Render one broad direct-authority page image near 1,200 dpi-equivalent;
   create 5,000–9,000-dpi crops only for genuinely ambiguous marks.
4. Transcribe diplomatic French first; record every mark-level decision.
5. Instantiate corrected French separately and record correction disposition.
6. Translate only from admitted diplomatic French.
7. Extend the shared semantic graph, close the p.120 paragraph and footnote
   seams, and carry every unresolved target explicitly.
8. Build once after source/scaffold validation; render and lead-review every
   reader page; seal exact hashes and privacy gates.

Reader PDFs may contain mathematical and genuine historical/editorial content
only. Workflow, AI, status, and private-path prose stays outside readers.
