# Printed p.120 R1 adverse findings and R2 closure

## Preserved R1 state

The first p.120 reader was built successfully but is not the active checkpoint.
It is preserved at
`../p120_direct_authority_20260804_r1/o/tohoku_p120_bilingual_r1.pdf`:

- 267,066 bytes;
- SHA-256 `0CD4896BE7FB8B1F97B8B9C3828477AC78D39A22308433A8A8974C93D4A25ED3`;
- five pages;
- its diplomatic continuation notice appeared alone on otherwise blank page 3.

The independent structural audit then found that equal row counts had hidden a
non-bijective semantic topology:

- all three R1 TeX layers contained `tohoku:introduction:II`, but the alignment
  table did not;
- the R1 alignment table contained `tohoku:introduction:footnote:1bis`, but no
  layer contained that target;
- nine chapter-reference edges used `forward_unadmitted`, whereas the exact
  state of their target nodes was `forward_target_unadmitted`;
- five of seventeen decisions lacked a reverse artifact binding.

Bound R1 identities include:

- `BILINGUAL_UNIT_ALIGNMENT.csv`: 4,098 bytes, SHA-256
  `B01DE27B504BBD97D1A2F51B8B3184039AA6C0BB39E0B13ECD0B7D1D90D813EE`;
- `REFERENCE_EDGES.csv`: 3,656 bytes, SHA-256
  `425B8C73DA05914A23F9E895AABADDF3F4C013945218C709478A641355DE21BA`;
- diplomatic TeX: 4,048 bytes, SHA-256
  `555446F5DA4CAFAF421A86CE4176420F1A2E5876A184391843CB27B78482F59A`;
- corrected TeX: 4,069 bytes, SHA-256
  `B842A750D9E6429183C8E88A5BD738795F1E3256DA5DFFDBE037240E228588D6`;
- English TeX: 3,775 bytes, SHA-256
  `7B711A9F6B4EDAD1F5E18B167924C6F097D16A744C9B691D126410BCDFF30DAB`.

## R2 global repair closure

The append-only decisions `TOH-P120-R2-REV-001` through `003` and
`TOH-P120-R2-NORM-001` record the repair and its inverse. R2:

- adds the zero-width footnote target to all three layers;
- adds the missing Applications-division alignment;
- yields identical eleven-element target/alignment sets in every layer;
- propagates the exact node-state token to all nine affected edges;
- gives each of the twenty-one inherited or repair decisions one canonical
  reverse binding;
- cites the no-correction disposition in every corrected-layer alignment;
- keeps the diplomatic continuation notice with its text through a reader-only
  page enlargement.

No visible French or English wording and no mathematics changed. R1 remains
adverse evidence and must not be rewritten or relabeled PASS.
