# Printed p.120 — direct-authority successor R2

This no-overwrite successor repairs the structural defects found after the
preserved R1 checkpoint was built. R1 remains unchanged as adverse evidence.

R2 changes only machine-readable topology, zero-width semantic targeting,
decision traceability, exact edge-state propagation, and reader layout. It does
not change the visible diplomatic French, corrected French, English wording, or
mathematics.

The direct authority remains official Part I PDF page 2 / printed page 120 /
local witness page 2. Direct-source QA evidence remains bound in the R1 root,
including the 1,200-dpi whole-page render and the 7,000-dpi crop establishing
the capital C with caron in `Čechiste`.

The R1 reader is 267,066 bytes with SHA-256
`0CD4896BE7FB8B1F97B8B9C3828477AC78D39A22308433A8A8974C93D4A25ED3`.
Its five-page layout is not the active deliverable because its diplomatic
continuation notice occupies an otherwise blank page.
