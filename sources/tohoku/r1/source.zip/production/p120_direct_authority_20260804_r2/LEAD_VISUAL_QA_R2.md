# Lead visual QA — printed p.120 R2

Lead review completed at 2026-08-04T04:02:05Z. No subagent supplied the
mathematical or visual PASS.

## Direct authority

The admitted coordinate is official J-STAGE Part I PDF page 2, printed page
120, local witness page 2. The bounded authority-comparison R2 row is `MATCH`;
its expected-page homography has 182 inliers and ratio 0.406250, against 14 and
0.041056 for the adjacent-page negative control.

The following direct-source renders were inspected before transcription:

- whole page, approximately 1,200 dpi-equivalent:
  `../p120_direct_authority_20260804_r1/qa/p120_1200g.png`, 2,457,284 bytes,
  SHA-256 `F00F30EFB3701E221362944DB580D68CB28ED9686BEF187E3174FFACA24EF1B4`;
- four broad reading bands with hashes recorded in the R1 README;
- capital-caron ambiguity crop, approximately 7,000 dpi-equivalent:
  `../p120_direct_authority_20260804_r1/qa/cechiste_7000.png`, 38,885 bytes,
  SHA-256 `58F37428D5F441E7B3F755E8949E86DA232B046534AAEFE0CB48EBDBD16B166D`.

The 7,000-dpi crop establishes the printed capital `Č` in `Čechiste`. The
whole-page and band review establishes the exact p.119 opening seam, the p.121
closing seam, the `1 bis)` marker, the Ext expression, `H^n(X;G,A)`, chapter and
section locators, bibliography numerals, punctuation, and the phrase
`ayant le degré de généralité et de simplicité nécessaire`.

## Delivered reader

Reader:

- `o/tohoku_p120_bilingual_r2.pdf`;
- 266,946 bytes;
- SHA-256 `61B350EC50101A40B543DB6F57EF8145AE9F0484788857F8F14AF845BD9C7DDB`;
- four A4 pages;
- all fonts embedded, subset, and Unicode-mapped;
- zero PDF image XObjects;
- one link annotation, exactly one DOI URI, and no other action type.

All four pages were rendered at 180 dpi and inspected at original render
resolution:

| Reader page | Render bytes | SHA-256 | Lead disposition |
|---:|---:|---|---|
| 1 | 87,180 | `1C76BAEE5D345479B8DDDA1CE165566D31DCAE6C7994AC4E5EA2592F056FCD7B` | PASS — title and DOI complete |
| 2 | 424,423 | `7858C150F5CD0D1B1F60CC3313CEBA47AC121CBD72395A96E1987AE248CCEC1C` | PASS — complete diplomatic layer; continuation retained on-page |
| 3 | 514,587 | `788D48268A499B9F6B35E1E5533A9CF9AB250893AC46129194EA17DF657820B7` | PASS — corrected/English opening; columns clear |
| 4 | 410,585 | `977C081102DAA50B2037FBC7935145A3CF414694E44D7E6B648EE090F103983B` | PASS — formulas, subitems, section III, marker, and seams clear |

There is no clipping, overlap, glyph loss, column collision, raster content,
or orphaned continuation page. The page-2 enlargement does not collide with
the footer. The corrected French and English remain visually distinct columns,
while diplomatic French remains a separate full-width layer.

Extracted reader text is 11,963 bytes with SHA-256
`825D9CFF2BD69FD674220C2420E62EEDD410200777694CF476EAF6D70FC38F6B`.
It contains the three expected p.121 continuation notices and zero private
root, operator-name, task-UUID, workflow, AI, checkpoint, or status hits.

Final visual disposition: **PASS for the bounded printed-p.120 checkpoint**.
This is not a claim about p.121 or the complete paper.
