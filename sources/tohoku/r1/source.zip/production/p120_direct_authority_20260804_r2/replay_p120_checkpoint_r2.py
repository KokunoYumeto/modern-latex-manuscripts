from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent.parent
P120_R1 = ROOT.parent / "p120_direct_authority_20260804_r1"
P119 = PROJECT / "repairs" / "p119_direct_authority_repair_20260804_r1"
MANIFEST = ROOT / "CHECKPOINT_MANIFEST_R2.csv"
VALIDATION = ROOT / "CHECKPOINT_VALIDATION_R2.json"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


authority_rows: list[dict[str, str]]
with (PROJECT / "SOURCE_AUTHORITY.csv").open("r", encoding="utf-8-sig", newline="") as stream:
    authority_rows = list(csv.DictReader(stream))
local_path = Path(next(row["path_or_url"] for row in authority_rows if row["witness_id"] == "TOH-COMP-LOCAL-103P"))
roots = {
    "TOHOKU_PROJECT": PROJECT,
    "TOHOKU_LOCAL_WITNESS": local_path.parent,
    "P119_REPAIR": P119,
    "P120_R1": P120_R1,
    "P120_R2": ROOT,
}

with MANIFEST.open("r", encoding="utf-8-sig", newline="") as stream:
    rows = list(csv.DictReader(stream))
validation = json.loads(VALIDATION.read_text(encoding="utf-8-sig"))
errors: list[str] = []

if validation.get("status") != "PASS" or validation.get("errors") != []:
    errors.append("validation receipt is not PASS/errors[]")
if len({row["artifact_id"] for row in rows}) != len(rows):
    errors.append("duplicate artifact ID")
if len({(row["root_alias"], row["relative_path"]) for row in rows}) != len(rows):
    errors.append("duplicate root/path pair")

for row in rows:
    root = roots.get(row["root_alias"])
    if root is None:
        errors.append(f"unknown root alias {row['root_alias']}")
        continue
    path = root / Path(row["relative_path"])
    if not path.is_file():
        errors.append(f"missing {row['artifact_id']}")
        continue
    if path.stat().st_size != int(row["bytes"]):
        errors.append(f"byte drift {row['artifact_id']}")
    if digest(path) != row["sha256"].upper():
        errors.append(f"hash drift {row['artifact_id']}")

ordered = sorted(rows, key=lambda row: (row["root_alias"], row["relative_path"]))
canonical = "".join(
    f"{row['root_alias']}|{row['relative_path']}|{row['bytes']}|{row['sha256']}\n"
    for row in ordered
).encode("utf-8")
aggregate = hashlib.sha256(canonical).hexdigest().upper()
if aggregate != validation["manifest"]["aggregate_sha256"]:
    errors.append("manifest aggregate mismatch")
if MANIFEST.stat().st_size != validation["manifest"]["bytes"]:
    errors.append("manifest byte count mismatch")
if digest(MANIFEST) != validation["manifest"]["sha256"]:
    errors.append("manifest SHA-256 mismatch")

result = {
    "status": "PASS" if not errors else "FAIL",
    "errors": errors,
    "rows_replayed": len(rows),
    "total_bytes_replayed": sum(int(row["bytes"]) for row in rows),
    "aggregate_sha256": aggregate,
    "manifest_bytes": MANIFEST.stat().st_size,
    "manifest_sha256": digest(MANIFEST),
    "validation_bytes": VALIDATION.stat().st_size,
    "validation_sha256": digest(VALIDATION),
}
print(json.dumps(result, ensure_ascii=False, indent=2))
raise SystemExit(0 if not errors else 1)
