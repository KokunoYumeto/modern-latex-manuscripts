# STATUS — Tôhoku printed p.120 R2

State: **PASS — bounded bilingual page checkpoint**  
Continuation cursor: **printed p.121 / official Part I PDF page 3 / local witness page 3**

## Closed scope

- direct-authority diplomatic French for printed p.120;
- separately instantiated corrected French, with no authorial correction
  established and visible body equal to the diplomatic layer;
- source-aligned English;
- one four-page bilingual reader;
- complete p.120 formula, term, subject, bibliography-mention, reference,
  residual, pre-Stacks-candidate, and cross-work-candidate inventories;
- exact decision-to-artifact reverse provenance;
- append-only R1 adverse finding and R2 repair history.

Active layer identities:

- diplomatic French: 4,163 bytes, SHA-256
  `AA982B53C7F7FAE36CC90DB43B2E68FD19C37A297877F470C8630FFFB4F30B6B`;
- corrected French: 4,184 bytes, SHA-256
  `51C383ECDB9BB328395A00867851DC0802EA0ABB1243E4E3F2B9AC73E560A570`;
- English: 3,890 bytes, SHA-256
  `EA9B809AEDF7D36A5FB6F8C27F7B83CAA91C287267BEF74F808B3FF956EDFB67`;
- reader: 266,946 bytes, SHA-256
  `61B350EC50101A40B543DB6F57EF8145AE9F0484788857F8F14AF845BD9C7DDB`.

Machine-readable counts: 54 nodes; 11 aligned text units; 25 terms; 16
formula occurrences; 0 diagrams; 21 reference candidates; 21 edges; 14 open
target-only residuals; 15 pre-Stacks candidates with zero official tags; six
cross-work candidates with zero external IDs; 21 decisions and 21 canonical
artifact bindings.

## Adverse history

The five-page R1 reader and its structural tables remain preserved. They are
not active deliverables. R2 closes the hidden alignment-set substitution, exact
edge-state mismatch, reverse-provenance gap, and orphan continuation page.

## Non-claims

This checkpoint does not claim p.121 closure, bibliography identities,
confirmed official Stacks tags, admitted external SGA/EGA/FGA relationships,
complete-paper readers, publication rights clearance, packaging, archive
publication, or public raw readback.

## Next exact action

Begin p.121 from direct authority. It must close the p.120 sentence beginning
`Pour la multiplication en cohomologie`, transcribe and translate the text of
footnote `1 bis)`, and reconcile the open p.120 semantic targets before
advancing further.
