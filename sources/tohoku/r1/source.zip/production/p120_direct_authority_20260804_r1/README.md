# Printed p.120 direct-authority production generation r1

State: open, no-overwrite sequential successor to the validated printed-p.119
repair checkpoint.

Authority coordinate: official J-STAGE Part I PDF page 2 / printed p.120 /
local comparison witness page 2. Part I identity: 7,305,283 bytes, SHA-256
`5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`,
DOI `10.2748/tmj/1178244839`.

The R2 no-OCR authority comparison binds this coordinate as `MATCH`; its
complete result is 102/102 paired-page matches and zero holds. Direct image
authority decides every transcription, correction, mathematical mark, and
layout feature. OCR is neither authorized nor used.

This generation must produce three distinct layers—diplomatic French,
separately corrected French, and source-aligned English—plus append-only
decisions and a shared semantic/reference scaffold. It may not mutate p.119,
authority custody, predecessor files, another corpus, or any shared log.
