# R3 adverse build

R3 is preserved and rejected. It produced a four-page reader, but both TeX
passes report an overfull box of 0.74916 pt in the English section 4.2 contents
entry.

- Reader source: `tex/readers/p121.tex`, 2,165 bytes, SHA-256
  `DC2BCC595AEEFBAC9FAA3F223312D7826F78592BCD99164D1DF8C766CCA39467`.
- Command log: `b/command.log`, 17,269 bytes, SHA-256
  `C75B83EB4E913E58BEE5EE774C70DC4397E7F25DF30DB4EC0809C859C6A97171`.
- TeX log: `b/p121.log`, 27,169 bytes, SHA-256
  `B7A18E66B69054E0FF8ACB58A7597EB39C6F4435697FA9E88CA2C3034E30DE2B`.
- Reader PDF: `o/p121.pdf`, 409,952 bytes, SHA-256
  `95EEFBA4A4A7FF778E973F25E275FBAB82EECD3C78A52E199AB06537BB959AFC`.

The offending text is the source-aligned English contents entry ending
`Ext^n_O(A,B) and the spectral sequence`. The language text must not be altered
to solve a reader-width problem. R3 must never be promoted, rebuilt, or
overwritten. A bounded line-breaking repair belongs to `p121_r4`.
