#!/usr/bin/env python3
"""Fail-closed relational prebuild check for the p.121 R2 checkpoint."""

from __future__ import annotations

import csv
import hashlib
import json
import re
import sys
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SEM = ROOT / "semantics"
LEDGERS = (
    "TRANSCRIPTION_DECISIONS.jsonl",
    "NORMALIZATION_DECISIONS.jsonl",
    "TRANSLATION_DECISIONS.jsonl",
    "SOURCE_CORRECTION_DISPOSITION.jsonl",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def read_csv(name: str) -> list[dict[str, str]]:
    path = SEM / name
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if not reader.fieldnames:
            raise ValueError(f"{name}: missing header")
        return list(reader)


def duplicate_values(rows: list[dict[str, str]], field: str) -> list[str]:
    counts = Counter(row[field] for row in rows)
    return sorted(value for value, count in counts.items() if not value or count != 1)


def main() -> int:
    errors: list[str] = []

    decisions: list[dict[str, object]] = []
    for name in LEDGERS:
        path = ROOT / name
        for number, line in enumerate(path.read_text(encoding="utf-8-sig").splitlines(), 1):
            if not line.strip():
                continue
            try:
                decisions.append(json.loads(line))
            except json.JSONDecodeError as exc:
                errors.append(f"{name}:{number}: invalid JSON: {exc}")
    decision_ids = [str(row.get("decision_id", "")) for row in decisions]
    if len(decisions) != 22:
        errors.append(f"decision count {len(decisions)} != 22")
    if len(set(decision_ids)) != len(decision_ids) or "" in decision_ids:
        errors.append("decision IDs are blank or non-unique")
    decision_set = set(decision_ids)

    tables = {
        path.name: read_csv(path.name)
        for path in sorted(SEM.glob("*.csv"), key=lambda item: item.name)
    }
    if len(tables) != 17:
        errors.append(f"semantic CSV count {len(tables)} != 17")

    nodes = tables["SEMANTIC_NODES.csv"]
    node_ids = {row["node_id"] for row in nodes}
    if len(nodes) != 81 or duplicate_values(nodes, "node_id"):
        errors.append("semantic nodes are not exactly 81 unique nonblank IDs")
    for row in nodes:
        if row["parent_id"] and row["parent_id"] not in node_ids:
            errors.append(f"missing parent: {row['node_id']} -> {row['parent_id']}")
        if row["provenance_decision"] not in decision_set:
            errors.append(
                f"missing provenance decision: {row['node_id']} -> "
                f"{row['provenance_decision']}"
            )

    bindings = tables["DECISION_ARTIFACT_BINDINGS.csv"]
    if len(bindings) != 22 or duplicate_values(bindings, "binding_id"):
        errors.append("decision bindings are not exactly 22 unique nonblank IDs")
    bound_decisions = {row["decision_id"] for row in bindings}
    for row in bindings:
        if row["decision_id"] not in decision_set:
            errors.append(f"binding has missing decision: {row['binding_id']}")
    if bound_decisions != decision_set:
        errors.append("decision/binding coverage is not one complete decision set")

    layer_targets: dict[str, list[str]] = {}
    for language in ("fr_diplomatic", "fr_corrected", "en"):
        path = ROOT / "tex" / language / "p121.tex"
        targets = re.findall(r"\\LayerTarget\{([^}]+)\}", path.read_text(encoding="utf-8"))
        layer_targets[language] = targets
        if len(targets) != 36 or len(set(targets)) != 36:
            errors.append(f"{language}: expected 36 unique LayerTarget values")
    target_set = set(layer_targets["fr_diplomatic"])
    if any(set(values) != target_set for values in layer_targets.values()):
        errors.append("the three language layers have different semantic target sets")

    alignments = tables["BILINGUAL_UNIT_ALIGNMENT.csv"]
    if len(alignments) != 36 or duplicate_values(alignments, "alignment_id"):
        errors.append("alignments are not exactly 36 unique nonblank IDs")
    if {row["node_id"] for row in alignments} != target_set:
        errors.append("alignment node set differs from the language-layer target set")
    for row in alignments:
        for path_field, hash_field in (
            ("fr_diplomatic_path", "fr_diplomatic_sha256"),
            ("fr_corrected_path", "fr_corrected_sha256"),
            ("en_path", "en_sha256"),
        ):
            path = ROOT / row[path_field]
            if not path.is_file():
                errors.append(f"missing aligned file: {row[path_field]}")
            elif sha256(path) != row[hash_field].upper():
                errors.append(f"alignment hash mismatch: {row[path_field]}")
        for decision_id in filter(None, row["decision_ids"].split(";")):
            if decision_id not in decision_set:
                errors.append(
                    f"alignment has missing decision: {row['alignment_id']} -> {decision_id}"
                )

    candidates = tables["REFERENCE_CANDIDATES.csv"]
    edges = tables["REFERENCE_EDGES.csv"]
    residuals = tables["REFERENCE_RESIDUALS.csv"]
    if [len(candidates), len(edges), len(residuals)] != [34, 34, 34]:
        errors.append("reference candidate/edge/residual counts are not 34/34/34")
    candidate_map = {row["candidate_id"]: row for row in candidates}
    edge_map = {row["candidate_id"]: row for row in edges}
    if duplicate_values(candidates, "candidate_id"):
        errors.append("candidate IDs are blank or non-unique")
    if duplicate_values(edges, "edge_id") or len(edge_map) != len(edges):
        errors.append("edge IDs/candidate links are blank or non-unique")
    if duplicate_values(residuals, "residual_id"):
        errors.append("residual IDs are blank or non-unique")
    for row in candidates:
        if row["source_node_id"] not in node_ids:
            errors.append(f"candidate missing source node: {row['candidate_id']}")
        if row["candidate_id"] not in edge_map:
            errors.append(f"candidate missing edge: {row['candidate_id']}")
    for row in edges:
        candidate = candidate_map.get(row["candidate_id"])
        if candidate is None:
            errors.append(f"edge missing candidate: {row['edge_id']}")
        elif candidate["source_node_id"] != row["source_node_id"]:
            errors.append(f"edge/candidate source mismatch: {row['edge_id']}")
        if row["source_node_id"] not in node_ids or row["target_node_id"] not in node_ids:
            errors.append(f"edge has missing semantic endpoint: {row['edge_id']}")
    unresolved_targets = {
        row["target_node_id"]
        for row in edges
        if row["target_state"] != "active_complete_on_p121"
    }
    open_targets = {
        row["candidate_or_target_id"] for row in residuals if row["state"] == "open"
    }
    if unresolved_targets != open_targets or len(open_targets) != 33:
        errors.append("open residual targets do not equal the 33 unresolved edge targets")
    predecessor_closures = [
        row
        for row in residuals
        if row["state"] == "closed"
        and row["candidate_or_target_id"] == "TOH-REFR-P120-014"
    ]
    if len(predecessor_closures) != 1:
        errors.append("the inherited p.120 residual has no unique closed propagation record")

    terms = tables["TERM_INDEX.csv"]
    formulas = tables["FORMULA_INDEX.csv"]
    diagrams = tables["DIAGRAM_INDEX.csv"]
    if len(terms) != 40 or duplicate_values(terms, "term_id"):
        errors.append("term index is not exactly 40 unique nonblank IDs")
    for row in terms:
        if row["node_id"] not in node_ids:
            errors.append(f"term missing owner node: {row['term_id']}")
        if row["decision_id"] not in decision_set:
            errors.append(f"term missing decision: {row['term_id']}")
    if len(formulas) != 8 or duplicate_values(formulas, "formula_id"):
        errors.append("formula index is not exactly 8 unique nonblank IDs")
    for row in formulas:
        if row["owner_node_id"] not in node_ids:
            errors.append(f"formula missing owner node: {row['formula_id']}")
    if diagrams:
        errors.append("p.121 diagram index must have zero data rows")

    prestacks = tables["PRESTACKS_CANDIDATES.csv"]
    confirmed = tables["PRESTACKS_CONFIRMED.csv"]
    if len(prestacks) != 25 or duplicate_values(prestacks, "mapping_id"):
        errors.append("pre-Stacks candidates are not exactly 25 unique nonblank IDs")
    for row in prestacks:
        if row["source_node_id"] not in node_ids:
            errors.append(f"pre-Stacks candidate missing source: {row['mapping_id']}")
        if row["official_stacks_tag"]:
            errors.append(f"unconfirmed official Stacks tag present: {row['mapping_id']}")
    if confirmed:
        errors.append("PRESTACKS_CONFIRMED must have zero data rows")

    cross_work = tables["CROSS_WORK_RELATION_CANDIDATES.csv"]
    if len(cross_work) != 6 or duplicate_values(cross_work, "relation_candidate_id"):
        errors.append("cross-work candidates are not exactly 6 unique nonblank IDs")
    for row in cross_work:
        if row["source_node_id"] not in node_ids:
            errors.append(f"cross-work candidate missing source: {row['relation_candidate_id']}")
        if row["target_external_id"]:
            errors.append(f"unverified external target ID present: {row['relation_candidate_id']}")

    page_map = tables["SOURCE_PAGE_MAP.csv"]
    expected_map = {
        "authority_sha256": "5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF",
        "official_pdf_page": "3",
        "printed_page": "121",
        "local_witness_page": "3",
        "local_witness_sha256": "57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78",
        "part": "I",
        "blank": "false",
    }
    if len(page_map) != 1 or any(page_map[0].get(key) != value for key, value in expected_map.items()):
        errors.append("source-page map does not bind the exact admitted p.121 identities")

    inventory_rows = tables["PAGE_OBJECT_COUNTS.csv"]
    expected_inventory = {
        "printed_page": "121",
        "semantic_text_units": "36",
        "formula_count": "8",
        "diagram_count": "0",
        "reference_candidate_count": "34",
        "term_rows": "40",
    }
    if len(inventory_rows) != 1 or any(
        inventory_rows[0].get(key) != value for key, value in expected_inventory.items()
    ):
        errors.append("page inventory does not match the semantic tables")

    report = {
        "status": "FAIL" if errors else "PASS",
        "counts": {
            "semantic_csvs": len(tables),
            "decisions": len(decisions),
            "bindings": len(bindings),
            "nodes": len(nodes),
            "targets_per_layer": len(target_set),
            "alignments": len(alignments),
            "terms": len(terms),
            "formulas": len(formulas),
            "diagrams": len(diagrams),
            "reference_candidates": len(candidates),
            "reference_edges": len(edges),
            "reference_residuals": len(residuals),
            "open_complete_paper_residuals": len(open_targets),
            "prestacks_candidates": len(prestacks),
            "prestacks_confirmed": len(confirmed),
            "cross_work_candidates": len(cross_work),
        },
        "errors": errors,
    }
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
