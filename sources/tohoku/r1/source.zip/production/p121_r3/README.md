# p.121 R3

R3 is the no-overwrite successor to the failed R2 reader wrapper. It inherits
the unchanged three language layers and semantic scaffold. Its only new content
decision repairs the definition order for a reader-only heading macro.

Direct authority evidence remains in `../p121_direct_authority_20260804_r1`.
The rejected R2 build is preserved in
`../p121_direct_authority_20260804_r2/ADVERSE.md`.
