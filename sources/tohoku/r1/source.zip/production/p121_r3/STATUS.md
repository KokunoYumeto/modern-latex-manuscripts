# Status

`FAIL-CLOSED` — semantic and build completion passed, but the TeX diagnostic
gate failed on a repeated 0.74916-pt overfull box. No visual promotion occurred.
See `ADVERSE.md`.
