# Printed p.121 R1 build adverse findings

R1 is preserved and is not the active p.121 reader checkpoint.

The two-pass build completed and produced a five-page reader:

- `o/tohoku_p121_bilingual_r1.pdf`;
- 337,386 bytes;
- SHA-256 `0FBB61C19BF3DEDD7190C448DB92862D8B7ECD7FAFD65FFDD0D75D619817FAEA`.

The build log is 17,568 bytes with SHA-256
`C89630B34460293E9A09EF62D931F6D275FD2E9870C2B12FD0AA19AA2738D871`.
It records an English Chapter I heading overfull by 10.07361 pt and severe
underfull heading lines. Those diagnostics fail the no-adverse-layout gate.

Lead inspection of all five 180-dpi renders found two related layout defects:

- the full-width diplomatic contents leaves only entries 4.1-4.2, footnote
  `1 bis)`, and the continuation notice on a sparse orphan page 3;
- parallel-column chapter headings are over-hyphenated and the two contents
  titles have inadequate visual separation.

The rendered pages remain preserved in `qa/reader_r1_180dpi`. Their hashes are:

- page 1: `42D9FA8354B9F07C5C8D33974722B413FE0C322F193A8530F9B66E90C9CC1F1A`;
- page 2: `79C5B8E0F022D4B343C9D0876AA708EC949CF9F237C7926562A1F6AC36CCC032`;
- page 3: `5C5943522385CF6F8C4BAFB3BEFF0D92113CB5507DC69E950D078720B7D546F5`;
- page 4: `56C4D96230343BF6E063B5FB3553A8B123C87421DF7C690D5EFCE93BCBC6AA73`;
- page 5: `3D4886D9555686A9D68611674E1436EDB9A323D2D4D38553AB189F876B44DB78`.

No source wording, mathematical notation, semantic target, or translation
defect was found. The no-overwrite R2 successor may alter reader-only layout
and TeX layout encoding, but it must retain R1 and bind this failure exactly.
