# STATUS - Tôhoku printed p.121 R1

State: **FAIL-CLOSED - reader layout not promoted**

The direct-authority language layers and semantic scaffold passed their
pre-build structural gate. The first reader build completed, but its log and
rendered pages exposed an overfull English chapter heading, severe heading
spacing, and a sparse diplomatic orphan page. R1 is preserved as adverse
evidence. It does not close printed p.121 and does not advance the cursor.

The authorized next action is the no-overwrite
`p121_direct_authority_20260804_r2` layout-only successor.
