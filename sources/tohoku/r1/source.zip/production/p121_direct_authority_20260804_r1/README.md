# Printed p.121 — direct-authority production R1

Exclusive scope: Grothendieck's Tôhoku paper, printed page 121 only.

Authority coordinate:

- official J-STAGE Part I PDF page 3;
- printed page 121;
- admitted local 103-page witness page 3;
- authority-comparison R2 state `MATCH`;
- expected-page homography: 314 inliers, ratio 0.497623;
- adjacent-page negative control: 20 inliers, ratio 0.053191;
- inlier margin 15.7.

Authority identities remain:

- Part I: 7,305,283 bytes, SHA-256
  `5A8E5720BC2EF8905BF85F7919C65AC4A87A31CFC854BD77E6B5084C0D2DEBEF`;
- local witness: 12,897,534 bytes, SHA-256
  `57B8FE1A4563FAB33D56F2CA0171D4843D37FBBDE982A84859E2E232494B6D78`;
- authority-comparison R2: 74,608 bytes, SHA-256
  `B4E04B2A31DB5CC60BE423F27813C5B168795252CF3C5194BE6FA6E46975DC34`.

No new OCR is authorized. Direct rendered authority decides. This root may
close the p.120 paragraph and `1 bis)` footnote seams but may not alter the
sealed p.119 or p.120 roots. Any later correction or reversal is append-only.
