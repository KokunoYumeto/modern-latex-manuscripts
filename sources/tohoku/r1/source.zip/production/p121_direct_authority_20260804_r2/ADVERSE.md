# R2 adverse build

R2 is preserved and rejected. Its only build attempt stopped on pass 1 before a
PDF was produced.

- Reader source: `tex/readers/p121_r2.tex`, 2,245 bytes, SHA-256
  `93C5C72A7187C139C65F2828548F26C98BFB18C78D1436012A68EC3D143FBF4D`.
- Build driver: `build_checkpoint.ps1`, 1,954 bytes, SHA-256
  `AE06FF5EEA1CC90303A37366BB65A1338C6430B06F29E9CDCA922CBEFE266A8D`.
- Command log: `b/r2/command.log`, 6,920 bytes, SHA-256
  `B77F09F0E222C59CEC54581A73B9E17A5C323F040392CA6C3D61FF9DDE1379A1`.
- TeX log: `b/r2/p121_r2.log`, 24,967 bytes, SHA-256
  `152FB0777038C424158A4403726EDBD3965D7453820C1CE1A4974556CAD68B1D`.

The fatal diagnostic is `Command \TohokuContentsChapter undefined` at reader
line 44. The layout override used `\renewcommand` before the layer fragment's
own `\providecommand` could establish the macro. This is a definition-order
error in the reader wrapper; it does not alter or impeach any language-layer or
semantic content.

R2 must never be promoted, rebuilt, or overwritten. The bounded repair belongs
to the no-overwrite `p121_r3` successor.
