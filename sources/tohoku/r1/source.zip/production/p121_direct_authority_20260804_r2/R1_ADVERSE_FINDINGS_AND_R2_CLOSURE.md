# Printed p.121 R1 adverse findings and R2 closure

The preserved R1 reader is 337,386 bytes with SHA-256
`0FBB61C19BF3DEDD7190C448DB92862D8B7ECD7FAFD65FFDD0D75D619817FAEA`.
Its build log is 17,568 bytes with SHA-256
`C89630B34460293E9A09EF62D931F6D275FD2E9870C2B12FD0AA19AA2738D871`.

R1 is not promoted because the log records a 10.07361 pt overfull English
Chapter I heading and severe heading underfull boxes. Lead inspection also
found an orphan-like diplomatic page 3 and overly hyphenated parallel chapter
headings. Exact render hashes and findings are retained in the R1 root's
`R1_BUILD_ADVERSE_FINDINGS.md`.

Append-only repair decision `TOH-P121-R2-REV-001` binds the R1 identities and
limits R2 to reader-only typography and pagination. No source, translation,
formula, semantic-node, alignment-set, reference, term, or pre-Stacks content
is altered.
