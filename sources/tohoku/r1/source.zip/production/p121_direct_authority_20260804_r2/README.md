# Printed p.121 - direct-authority successor R2

This no-overwrite successor repairs only the reader-layout defects exposed by
the preserved R1 build. The R1 root remains unchanged as adverse evidence.

Exact no-overlap was checked before creation:

- predecessor: `p121_direct_authority_20260804_r1`;
- successor: `p121_direct_authority_20260804_r2`;
- distinct literal roots: true.

The three language-layer bodies, all thirty-six semantic targets, all
mathematics, and the translation wording are inherited unchanged. R2 reduces
only contents typography in the dense reader context, adds controlled page
enlargement to avoid the R1 diplomatic orphan page, and gives parallel-column
chapter headings ragged-right footnote-size treatment.

Direct source evidence remains in the R1 root and is referenced by explicit
relative paths. The initial p.203 notation lookup remains rejected evidence;
the corrected same-paper notation lookup is printed p.185 / official Part II
page 1.

Authority remains official Part I PDF page 3 / printed p.121 / local witness
page 3, comparison state `MATCH`. No new OCR was used.
