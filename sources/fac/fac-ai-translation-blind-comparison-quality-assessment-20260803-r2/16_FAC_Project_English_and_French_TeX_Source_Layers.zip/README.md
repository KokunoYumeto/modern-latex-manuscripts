# FAC project source layers included with the quality assessment

This source bundle contains only active editable project files:

- `english/`: complete source-aligned English FAC master and 80 component TeX files through EOF;
- `french_diplomatic/`: complete diplomatic French TeX, preserving source-established printed forms;
- `french_corrected/`: complete corrected French TeX, applying only disclosed source-critical corrections.

The French journal scan and Achinger--Krupa comparator files are not included. Build scratch directories, logs, caches, auxiliary files, and compiled French PDFs are excluded. The source layers are working scholarly artifacts, not source authority, a critical edition, peer review, or blanket rights grant.
