# Interlanguage side-branch source-body update, 2026-07-07

This update preserves and publishes the useful payload material from the other-PC branch `origin/codex/noether-pc-20260629` as grouped source-body/provenance archives.

Read the methodology file first: `00_Interlanguage_Methodology_Current_20260706.pdf`.

## What is new in this update

The new files `04` through `08` are grouped archives produced directly from the side branch, not loose micro-packets:

- `04_Interlanguage_OtherPC_SourceBodies_Slavic_NoetherSlavic_20260707.zip`: Slavic non-Russian/non-Ukrainian source-body work, Noether Slavic handoff material, Noether Slavic source-canon material, and Noether source-corpus provenance.
- `05_Interlanguage_OtherPC_SourceBodies_Romance_CJK_20260707.zip`: Romance baseline/source-body packages and CJK source-body/source-evidence packages.
- `06_Interlanguage_OtherPC_SourceBodies_RTL_Persianate_Arabic_20260707.zip`: Arabic RTL, Persianate, and Tajik source-body/source-witness packages.
- `07_Interlanguage_OtherPC_SourceBodies_Turkic_Indigenous_SEA_OLP_20260707.zip`: Pan-Turkic, Indigenous/creole/sign, Malay/SEA/Pacific, Africa/Horn/West, and OLP/relation-function support bodies.
- `08_Interlanguage_OtherPC_Fable_Method_Transfer_Audits_20260707.zip`: Fable/interlanguage method ledgers, transfer audits, and uploader-transfer provenance.

The companion `09` files are the public inventory generated from the side branch: one human-readable Markdown map and one machine-readable CSV.

## Status caveat

These are source-body, provenance, methodology, and support corpora. They are not native-language approval, not accepted terminology, not final translation output, not source-fidelity certification, not reader editions, and not critical editions. Generated or AI-produced material may be useful for consistency checking and term discovery, but source-body/witness status remains separate from generated translation status.

The branch also contains coordination and session-control files. Those files are preserved only as provenance where they are inside the grouped archives; they should not be treated as public instructions or as authority over the main repository.
