# SGA 7 II English source-first successor — status

## Objective

Produce the complete cumulative English SGA 7 II TeX and PDF, Exposés X–XXII,
while simultaneously maintaining (a) a diplomatic, scan-faithful French TeX
canon and (b) a separately identified corrected French reading workpass with
individual verification readers, without overwriting any inherited witness.
The untouched French snapshot is provenance only; it is not automatically a
finished diplomatic canon because inherited transcription errors may remain.
The corrected French workpass is an editorial reading layer, not a replacement
for the printed canon. Exact policy: `FRENCH_CANON_AND_CORRECTED_READING_POLICY_20260801.md`.
After SGA 7 II, this lane's
durable queue is FAC, then GAGA, followed by reference cleanup of the standalone
SGA readers and a no-overwrite cumulative, cross-volume-linked SGA 1–7.2 reader.
That later reader pass must coordinate exact inputs before mutation, preserve
reviewed/public layers, no-op exact prior work, and retain complete
candidate/edge/residual, provenance/rights, build/render, privacy, and package
controls without duplicate concepts or archive transports. The analogous EGA
0–IV cumulative reader belongs to the separate EGA lane.

## Controlling inputs

- Ultimate scan authority: <REDACTED_USER_HOME>\Documents\Papors\OS\Number12.pdf,
  446 pages, SHA-256
  FA679DEBFC8ADA3232D7E752A1837FC6CE474488E20A44D7641CF296876E1297.
- Frozen coherent French input:
  <REDACTED_LOCAL_ROOT>/w\e620\sources\sga\sga7ii-french-source-transcription-working-x-xxi-partial-20260731.
  It covers scan indices 8–406 continuously: Exposés X–XX complete and 37/39 pages
  of Exposé XXI.
- Exact source-transcription continuation cursor from the frozen Claude input:
  scan index 407. Index 407 finishes Exposé XXI; Exposé XXII begins on its
  title page at scan index 408 and runs through index 445.
- Existing Floris GPU OCR is locator/drafting material only. No OCR is being
  generated or rerun.
- The May 2026 Kimi pages 351–444 TeX is comparison-only and rejected as a source
  substrate: its overlap compresses and rewrites the source rather than transcribing it.
- The frozen French snapshot remains immutable. Confirmed transcription
  repairs and explicitly disclosed printed-typo corrections are propagated in
  the separate no-overwrite `french_source_corrected_workpass`. Its corrected
  complete Exposé-XVIII body is 180,944 B, SHA-256
  751C9A6841137667BBFA948D2E6FB367755F2F6AD85463A4993EA3EB09B3F01D;
  the 129-entry XVII–XVIII correction register is 26,451 B, SHA-256
  3A51FDE3496C5E26EE55197DD8C0EA8D3142C2440A5AD3F9098F3B20E668135B.

## English progress

- Exposé X is translated continuously and completely, including its bibliography.
- Exposé XI is translated continuously and completely, including its bibliography.
- Exposé XII is translated continuously and completely, including its bibliography.
- Exposé XIII is translated continuously and completely, including its
  Introduction, §§1–2, the second printed occurrence of 2.4.6, and bibliography.
- Exposé XIV is translated continuously and completely, including its
  bibliography. Sections 1–4, both Picard--Lefschetz treatments, the De Rham
  comparison, and every source diagram are present.
- Exposé XV is translated continuously and completely through its terminal
  Picard--Lefschetz summary theorem. This includes the moduli of quadratic
  singularities, the standard quadratic computation of vanishing cycles, and
  both the even- and odd-dimensional Picard--Lefschetz formulas.
- Exposé XVI is translated continuously and completely, including the Milnor
  formula, its reduction to a global pencil, Proposition 2.5, and bibliography.
- Exposé XVII is translated continuously and completely through its references.
  This includes the local dual-morphism calculation, the existence proof, the
  Chern-class computation of the degree of the dual variety, and the general-base
  statement.
- Exposé XVIII is translated continuously and completely through its
  bibliography, including
  the title, contents, introduction, Deligne's degeneration theorem, the
  projective-bundle and blow-up formulas, the topological computation of
  the degree of the dual variety, the cohomology algebra of the pencil blow-up,
  the restriction/Gysin comparison with a smooth fiber, and the complete hard
  Lefschetz formalism for smooth hyperplane sections and smooth proper families,
  condition (A), the constancy lemma, the vanishing-cohomology sheaf, its
  direct-sum decomposition, the pencil degeneration theorem, its complete
  spectral-sequence computation, Theorem 5.6.8, Corollary 5.6.10, the
  primitive/vanishing decomposition of Theorem 5.7, its Gysin diagram,
  Remark 5.7.10, the Griffiths homomorphism, its base-change form, and the
  finite-flat pullback--trace proof of Corollary 5.8.7, condition (A), tame
  monodromy, Proposition 6.2, Theorem 6.3, Corollary 6.4, the asymptotic
  Betti-number calculation of Lemma 6.4.2, the Picard--Lefschetz formula,
  Theorem 6.6, Corollary 6.7, and the terminal bibliography.
- Continuous diplomatic-French, corrected-French, and English coverage now
  reaches the end of Proposition 2.2.5 in Exposé XXII, scan index 416 / folio
  409. The first nine authority pages of XXII were personally transcribed from
  the scan because no frozen Exposé-XXII TeX body exists.
- Exact next English and both French-layer cursor: §3, scan index 417 / folio
  410. This lane must personally transcribe the remaining scan indices
  417--445 before and while translating them, under the recorded high-detail
  authority method.
- Current cumulative master:
  source\SGA7_II_English_source_first_workpass.tex, 10,991 B, SHA-256
  6D10D3F2C7C24353C1109CFC7D29646B044082FA70B8F7734A4E3B8DD9BDAF51.
- Current cumulative PDF:
  build\c166_expose_XXII_through_proposition_2_2_5_r2\SGA7_II_English_source_first_workpass.pdf,
  241 A4 pages, 1,215,208 B, SHA-256
  AE8EF3113657D69347E886EFAEA2377F7F565E2D98B4F718EFDEDB6030312E2E.
- Three XeLaTeX passes exit 0; the final log has zero critical error, overfull,
  duplicate-destination, undefined-reference, fatal, or rerun diagnostics.
  The final log is 40,917 B, SHA-256
  87AD0257FC4EC56D0F071141548CE38DED15F7387D00B183C28326DDDE3798F3.
- The parallel corrected French workpass has been build-checked with its
  intended pdfLaTeX engine through the current Exposé-XXII cursor:
  206 pages / 1,403,821 B / SHA-256
  88D2AD262A6CDC10CD2290ACBC9AE785CCF7A3D7B23745C056AFC6BC177DBE2E.
  Its inherited pdfTeX-only `\pdfinfo` primitive makes XeLaTeX inapplicable
  to that French master; this is an engine fact, not a source-body failure.
  English render pages 3–45 have been inspected at the successive component
  boundaries; pages 39–45 pass the 600-dpi layout check after the three
  diagram-closing periods were restored. Pages 46–50 pass the 600-dpi layout
  check for the Exposé-XIII opening and §1.1; that check caught and removed one
  bad math-mode rendering of underlined prose before this status was recorded.
  Pages 50–53 then pass the 600-dpi §1.2 layout review, including the full
  Galois table and both native diagrams. Pages 53–55 pass the 600-dpi §1.3
  review, including both Cartesian diagrams and all displayed functor maps.
  Pages 55–60 pass the successive 600-dpi reviews for §1.4 and
  §2.1.1–2.1.8. Pages 60–62 pass the final 600-dpi §2.1 review, including
  the compactification diagram, both base-change lemmas, Proposition 2.1.12,
  and the derived tensor-product formula.
  Pages 62–64 pass the 600-dpi §2.2 review; all five trace diagrams are native,
  legible, and preserve their arrow directions, equality bars, labels, and
  source punctuation.
  Pages 64–69 pass the successive 600-dpi reviews for §2.3, §2.4, the two
  separately printed 2.4.6 diagrams, and the bibliography. All new diagrams
  are native TeX and the final pages are free of clipping or malformed labels.
  Pages 70–76 pass the successive 600-dpi reviews for the Exposé-XIV opening,
  §1.1, and all of §1.2. The disc-topos, specialization, distinguished-triangle,
  and two Cartesian diagrams are native, legible, and unclipped.
  Pages 76–81 pass the successive 600-dpi reviews for §§1.3–1.4. All topoi,
  specialization, quotient, and contraction diagrams are native and clean;
  the Thom theorem and support-cohomology displays are unclipped.
  Pages 81–83 pass the 600-dpi review for all of §2. The algebraic and
  transcendental nearby-cycle comparison maps, inverse-limit formula, and
  Theorem 2.8 are legible, aligned, and unclipped.
  Pages 83–91 pass successive 600-dpi reviews for all of §3.1. The four
  hand-drawn proof sketches and the $\tau/\varphi_i$ graph are rebuilt as
  native TikZ; the seven further categorical and monodromy diagrams are native,
  legible, correctly directed, and unclipped.
  Pages 91–95 pass the 600-dpi review for all of §3.2. Both Picard--Lefschetz
  drawings are rebuilt as native TikZ from the direct authority image; the
  dimension corrections, compact-support formulas, theorem, and sign table are
  legible and unclipped.
  Pages 95–100 pass the successive 600-dpi reviews for §§4.1–4.17. Pages
  100–104 pass the final 600-dpi review for §§4.18–4.20 and the bibliography.
  Both closing commutative diagrams are native, fit the page, and preserve the
  authority's arrow directions, equality bar, label sides, and vertical
  isomorphism marks.
  Pages 104–110 pass successive 600-dpi reviews for the Exposé-XV opening and
  §§1.1--1.2. The two opening henselian-deformation diagrams and the reduction
  triangle are native and clean; the normal forms, congruence calculations,
  source-typo notes, and final Remark 1.2.12 are legible and unclipped.
  Pages 110–118 pass the successive reviews for §§1.3--2.2; pages 119–121 pass
  the 600-dpi review for §§3.1--3.2. Pages 122–125 pass the final 600-dpi
  Exposé-XV review: both odd-dimensional native diagrams, the proof seams, and
  Theorem 3.4 are clean and unclipped. The first render joined proof item (D)
  to (C); the r2/r3 source fixes that seam. The r3 build also replaces twelve
  inherited Unicode smart quotes with TeX quotes, removing all twelve missing-
  glyph diagnostics without changing the English text.
  Pages 135–145 pass successive 600-dpi reviews for Exposé XVII through §3.7.
  The render review caught and corrected the label side in diagram (3.5.2),
  restored the missing backslash in `\longmapsto`, and removed the stray comma
  from the exponent of `\mathcal O_V^{r-n}`. All formulas, diagrams, footnotes,
  theorem seams, and page breaks in this range are legible and unclipped.
  Pages 155–162 pass successive 600-dpi reviews for Exposé XVIII §§1–2.
  Pages 163–164 pass the 600-dpi review for all of §3, including both native
  diagrams, the Euler-characteristic formulas, correction notes, proposition,
  proof, and terminal remark. The resized (2.2.25–26) ladder was rebuilt after
  its first mechanical ampersand failure and now compiles and renders cleanly.
  Pages 165–168 pass the 600-dpi review for all of §4, including its native
  blow-up, exact-sequence, and projective-bundle diagrams, the corrected sign
  in the transported decomposition, and the complete cup-product calculation.
  Pages 168–170 pass the 600-dpi review for §5.1. The large pencil/fiber
  diagram, Cartesian square, Gysin formulas, weak-Lefschetz corollary, and all
  source-correction seams are legible and unclipped.
  Pages 170–173 pass the 600-dpi review for §5.2. The two triangles, both
  Lefschetz squares, primitive decomposition, corrected degrees and twists,
  family lemma, and terminal corollary are legible and unclipped.
  Pages 173–175 pass the 600-dpi review for §§5.3–5.5. Condition (A), all
  direct-image formulas, the corrected (5.4.3), the vanishing-cohomology
  definition, and both decompositions are legible and unclipped.
  Pages 175–179 pass the lead 600-dpi review for §5.6. The spectral-sequence
  displays, primitive decomposition, proof seams, and source-correction notes
  are clean. The first render placed the left vertical $d_2$ label on the
  wrong side of its shaft; the r2 native diagram moves it to the authority's
  right-hand side, and page 178 was re-rendered and personally rechecked.
  Pages 179–181 pass the lead 600-dpi review for §5.7. The long decomposition
  formulas fit; the Gysin square preserves the authority's hook, directions,
  isomorphism marks, and all four label sides; the two correction notes and
  the terminal remark are legible and unclipped.
  Pages 182–186 pass the lead 600-dpi review for all of §5.8. The two base-change
  diagrams preserve the authority's label sides after the r2 repair; the
  quotient, cartesian square, factorization, and trace formulas are legible and
  unclipped. Final page-render SHA-256 values for pages 184–186 are
  4195564B5BE3A01F69DA37FCBD15963998D9ABFB7CE0B6770E36BF73CDF7EB5F,
  B9DE5FA3F664B2DD1EEA12DA761E6881EBFB9E1985F1C884B4E075F33DD99AC0,
  and C1B48B35DFD990EA5833C52BC8AA3EC11AB35005503AC74577AEB52FB9350D21.

## Source-image policy

The frozen French TeX is the immediate translation base. The authority image decides
suspected transcription defects, diagrams, and ambiguous formula details. Clear general
text is inspected at roughly 1100 dpi; small or ambiguous details are escalated toward
5000–9000 dpi only as needed. Scan index 12 was checked directly at 1100 dpi and confirms
the commas in every occurrence of (D_i,D_j) that the French TeX omitted once.
Indices 13, 14, and 18 were also checked directly at 1100 dpi to adjudicate three
mathematically obvious printed-source slips: $\omega_{X/S}$ is placed on $X$ rather
than the printed “on $S$”; $\deg_D(Rg^!\underline O_S)$ retains the $S$ required by
(1.10.2), rather than the printed $D$ in that one occurrence; and the exercise's
affine-Dynkin relation uses $n_j$ under the sum rather than the printed $n_i$.
Indices 25–45 were checked directly at 1100 dpi through the end of Exposé X.
Indices 46–89 were then checked directly at 1100 dpi through the Exposé XII
boundary and the Exposé XIII title page. Indices 90–96 were checked directly at
1100 dpi through Reminder 1.1.3; the authority image restores the frozen
transcription's erroneous vector accent on $\bar{\mathcal F}$ and controls the
nested Galois-descent formula at the page seam. Indices 97–104 were checked
directly at 1100 dpi through the end of §1.3. The simple specialization and
Cartesian diagrams were already unambiguous at that resolution, so no artificial
high-DPI escalation was made. The images confirm that
$\bar X=X\times_S\bar S$ uses the base $S$; they also expose the printed omission
of the bar from the top-middle $\bar X$ in diagram (1.3.5.1). The English restores
both mathematically required readings and states the second correction beside
the diagram. A targeted 5000-dpi-equivalent crop of Exposé XI folio 58
confirmed that the print itself reads the defective Hodge-level upper bound
`min(n,dim(X)-n)`; the English gives the mathematically required
`min(n,2dim(X)-n)` and discloses the correction in a footnote. Exposé XII's
printed ordinary-form normal forms use the impossible upper summation limit
`m-1`, and its definition of `f` repeats `f`; the English transparently uses
the nondegenerate normal-form limit `m` and `f'`, with source-typo notes.
The six
Enriques diagrams in 2.25 were compared individually with the authority;
the two dense space-curve diagrams were additionally inspected as targeted
5000-dpi-equivalent magnifications. Because Number12.pdf contains an embedded
roughly 300-dpi scan, these magnifications expose the source pixels without
claiming invented resolution. All six diagrams are rebuilt as native TikZ in
the English source; no raster image is loaded by the reader.
The English repairs the printed map-name, prime, and sign/order inconsistencies
so that all displayed identities and exact sequences are mutually coherent;
these repairs are itemized in LOGBOOK.md.
Indices 105–114 were personally checked directly at 1100 dpi through the end of
§2.1.13. The diagrams and fine labels were legible at that scale. A targeted
two-times enlargement of the 1100-dpi index-114 image was used only to settle the
small derived-category target; it confirms the printed
$D(X_s\times_sS,\Lambda)$ with no bar on the final $S$. The English also records
or transparently repairs the source-visible slips in §1.4.2, (2.1.2.4),
(2.1.7.3), (2.1.7.4), and (2.1.8.8), while retaining the genuinely arrowless
upper connector printed in (2.1.8.7). Exact image and component hashes are in
LOGBOOK.md.
Indices 115–117 were then checked directly at 1100 dpi through Scholium 2.2.6.
Targeted enlargements were used for the dense trace diagrams and the small
printed cross-references. They confirm the labels (2.1.10.1)/(2.1.10.2) as
printed and expose the definite $f/g$, $x/y$, and 2.3.5/2.2.5 slips corrected
transparently in the English. No detail required escalation beyond those
enlargements of the 1100-dpi source images.
Indices 118–122 were checked directly at 1100 dpi through the end of Exposé XIII.
The authority image controls all variation-morphism and local-cohomology
diagrams. It also confirms that the source itself repeats the paragraph number
2.4.6 and diagram number (2.4.6.1); the English retains both repeats and
disambiguates the second occurrence in prose. The obvious “smooth at X” typo in
2.4.1 is rendered “smooth at x”; the printed direct summand
$R\Phi(F)$ in the general complex formulation is rendered
$R\Phi(K)$; and the nonexistent (2.4.4.1) variation reference is rendered
(2.4.5.1).
Indices 123–132 were checked directly at 1100 dpi through the opening of
Exposé XIV §1.3. The §1.2 diagrams and their labels are unambiguous at that
scale. The print itself omits the mathematically necessary overline from the
top-right $\overline X^*$ in (1.2.7.1); the English restores it and discloses
the correction. The scan also shows that the target of $\Psi_\eta$ is
$X_0\times\mathcal D^*$, correcting the frozen transcription's mistaken
$X_0\times\widetilde D^*$.
Indices 133–138 were checked directly at 1100 dpi through the end of
Exposé XIV §1.4. The images confirm the derived targets
$X_0\times\mathcal D$ and $X_0\times\mathcal D^*$, the starred
$X_{\widetilde U^*}$ in §1.3.3, and every §1.4 diagram. They also confirm the
printed but impossible citation to “triangle 1.2.1”; the English identifies
the actually used distinguished triangle of 1.2.6.
Indices 139–142 were checked directly at 1100 dpi through the end of
Exposé XIV §2. The comparison morphisms, inverse-limit formula, and theorem
statement are clear at that resolution; no small detail required higher-DPI
escalation.
Indices 142–153 were checked directly at 1100 dpi through the end of
Exposé XIV §3.1. The four source sketches, the $\tau/\varphi_i$ graph, and all
categorical diagrams are unambiguous at that scale, so no artificial
higher-DPI escalation was made. The English corrects the source's forced
$r(d)/\tau(d)$, coordinate-order, $B_{s,t}/B_{t,d}$, missing $f(x)$, and
quotient-diagram top-right-node slips while preserving their mathematical
content.
Indices 153–159 were checked directly at 1100 dpi through the end of §3.2.
The two geometric drawings and every small arrow and label are unambiguous at
that scale, so no higher-DPI escalation was required. The English transparently
corrects $\mathbb R^n$ to the ambient $\mathbb R^{n+1}$, regularizes the printed
$x/n/d$ dimension mix to $d$, and restores the missing closing parenthesis in
$-\pi(1-\varphi(|u|))$.
Indices 160–171 were checked directly at 1100 dpi through the end of Exposé
XIV. The small formula characters and both closing commutative diagrams were
fully legible at that resolution, so no artificial escalation was made. The
English transparently restores $U^*$ in (4.18.2), $V$ in Lemma 4.18.4,
$E_2^{0n}$ in the spectral sequence, the reference to 4.18.5 in its proof,
and the missing $u^*$ in the Grauert-theorem argument. It also reads the
source's typewriter inverse-image marks as the mathematically required stars.
Indices 172–181 were checked directly at 1100 dpi through the end of Exposé XV
§1.2. The formulas, underlining, and three small diagrams are unambiguous at
that scale. The English transparently restores the local display number
(1.2.1.1) and removes the print's extra equals sign after $Q$, corrects the
impossible references 4.3 and 4.11.1 to 1.2.3 and (1.2.11.1), and retains the
proved congruence modulo $\delta^2\mathfrak q+(f)$.
Indices 182–197 were checked directly at 1100 dpi through the end of Exposé XV
§3.2.3.  All formula characters and the three §2.2.6–2.2.7 diagrams were clear
at that scale.  The English transparently repairs the printed $X'_s/H^o$ slips,
the omitted bar on $\bar\eta$, the $H_c^i/H_c^n$ degree slip, the undefined
support abbreviation $x/x_0$, the decisive \emph{seul}/\emph{nul} typo, and
the two local-cohomology occurrences that print $R^n\psi$ where the cited
duality and generator statements use $R\psi$.  Lead render review also moved
the specialization label above its leftward arrow to match the authority.
Indices 198–203 were checked directly at 1100 dpi through the end of Exposé XV.
Both §3.3 diagrams, all local-character formulas, and the terminal exact
sequence were unambiguous at that scale. The English preserves the printed
homological $H_n(X_{\bar\eta})(m)$ in Theorem 3.4, restores the untilded first
punctured henselization fixed by the displayed equality, and discloses the
source-backed formula corrections in the component notes and logbook.
Indices 204–218 were checked directly at 1100 dpi through the end of Exposé
XVI. All formula characters were decisive at that scale and the exposé contains
no diagrams, so no artificial higher-detail escalation was required. The
English transparently corrects the frozen $\mathbb Z/\ell$ transcription to the
printed $\mathbb Z_\ell$, the Chern-zero variable $u$ to the printed Greek
$\mu$, and $X\times_sS'$ to $X\times_SS'$. It also discloses the print's blank
citation in Proposition 1.13, the impossible minus sign in the Artin-conductor
formula, and the undefined base $T$ in the proof of Proposition 2.5 rather than
silently inventing source readings. Final English pages 126–134 pass lead
600-dpi layout review. That review caught one missing TeX backslash which had
rendered `operatornamepr` on page 133; the r2 build repairs it and the final
projection formula, theorem seams, footnotes, and bibliography are clean.
Indices 219–260 were checked directly at 1100 dpi through the end of Exposé
XVII; targeted higher-detail crops were used only where the source pixels or
dense diagrams required them. Indices 261–278 were then personally checked at
1100 dpi through Exposé XVIII §3.2.12. The diagrams and formulas were decisive
at that scale except for the local intersection-length abbreviation in the
proof of Proposition 3.2.10, which was inspected in a targeted 5000-dpi crop.
The parallel French workpass now restores the printed closing parenthesis and
the scanned exponent $n$, and transparently corrects the undefined morphism
$S$ to $\rho$, the Hesse parameter condition to $\mu^3=-1$, and printed
`rg` to the local length used by the intersection-multiplicity argument.
Indices 279–288 were personally checked directly at 1100 dpi through the end
of Exposé XVIII §5.1. The scan visibly controls the lower inclusion label $j$
and the full geometry of both §5.1 diagrams. The printed $h^*$ in (5.1.2) is a
source-level symbol defect rather than a transcription ambiguity: its displayed
degree, (5.1.5), and the proof all require the Gysin $h_*$. The corrected
French workpass and English therefore carry $h_*$ transparently, together with
the already-established minus sign on the second component of (4.2.2).
Indices 289–294 were then checked directly at 1100 dpi through the end of
§5.2. The authority itself prints the doubled twist in (5.2.2.2), the wrong
twist in (5.2.4.7), degree $n-i$ in the upper-right node of the surjectivity
square, and $H^{ii}$ for the $i$-th power of a degree-two Chern class. These are
source-level mathematical defects, not uncertain glyphs; the corrected French
and English use the degree/twist values forced by the displayed operators and
record every disposition in the correction register.
Indices 295–298 were then checked directly at 1100 dpi through Lemma 5.5.
The formulas are decisive at that scale. The scan confirms the direct-image
symbol $\rho_*$ in (5.4.3), where the frozen transcription had $\rho^*$, and
the corrected French workpass also restores the missing parenthesis in
$f^*c_1(\mathcal O_X(1))$ and fixes the harmless printed agreement
“la flèche … est injective.”
Indices 298–305 were checked directly at 1100 dpi through Corollary 5.6.10.
That comparison controls the Leray abutment, every $E_2$ index and $d_2$
target, the maps in (5.6.5), the corrected hard-Lefschetz isomorphism
(5.6.8.8), and the commutative square in the proof. A locator crop was enough
to settle the dense (5.6.5) formula; no unresolved source feature required
invented resolution. The corrected French workpass and English now carry the
same source-backed mathematical readings, while major printed corrections are
disclosed in the English notes.
Indices 306–308 were checked directly at 1100 dpi through Remark 5.7.10.
A targeted crop of index 306 settled the superscript/subscript placement in
the maps (5.7.2)–(5.7.6). It confirms $h_*$ where the frozen transcription
had $h^*$ and confirms that the print itself has the defective $2^*$ in
(5.7.6). Index 307 controls the complete Gysin square and also shows the
printed $H^N$, omitted Tate twist, and extra parenthesis corrected in both
workpasses. Every diagram feature was decisive without further escalation.
Indices 321–329 were subsequently checked directly at 1100 dpi through the
proof of Lemma 6.4.2. That pass settled the right-hand placement of the
vertical $i_{\bar\eta*}$ label in (6.1.5), the lower-case field tower, the
arithmetic tame group, the blank Galois numerator, the printed
$\operatorname{card}(k)\ne2$ defect, the dual-variety mark omitted by the
frozen transcription in Remark 6.3.4, the common (LV) hypothesis in Corollary
6.4, and the missing parenthesis in (6.4.2.3). The English 191-page r1 build
and corrected-French 201-page r1 build are both three-pass stable; English has
zero critical diagnostics, while French retains only two unrelated inherited
overfull warnings. English pages 190–191 and corrected-French pages 163–164
pass lead 600-dpi render review.
Indices 330–334 were then checked directly at 1100 dpi through the end of
Exposé XVIII. A targeted 5000-dpi crop on index 331 settles the small phrase
in Theorem 6.6: the print itself circularly calls $I_i$ the inertia group of
$\delta_i$ before defining $\delta_i$; the corrected reading is the inertia
group at $s_i$, transported by $\ell_i$. The same pass controls every
Picard--Lefschetz twist, the native L-shaped monodromy diagram, Corollary 6.7,
and the bibliography. English pages 190–194 and corrected-French pages
164–168 pass lead 600-dpi render review. Both three-pass builds converge,
with no critical English diagnostics and no new French overfull warning.

Exposé XIX is now translated continuously through its terminal bibliography.
Authority indices 335–347 / folios 328–340 were checked directly at 1100 dpi;
the two nontrivial diagrams were checked from direct 5000-dpi monochrome
authority crops. Components 136–138 are integrated. The current English reader
is 203 A4 pages / 1,077,752 B / SHA-256
`52E978B6DB2694B1B86CBA26592BF6F73B1C65EB5459A45802258DF2DA8BA596`;
three passes converge, pass-2/pass-3 console SHA-256 is
`766027A644035407849E7262FC17FB50467CB994E1842A22109F3E09740E4484`,
and the final log has zero critical diagnostics. English pages 199–203 and
French verification pages 170–173 pass lead render review. The exact next
translation cursor is Exposé XX, scan index 348 / folio 341,
`authority_snapshot/source/expose_XX_body.tex` line 2.

Floris's EGA French-canon instruction in attachment
`<REDACTED_TASK_ID>/pasted-text.txt` (16,563 B, SHA-256
`D9B79248A162437F4AEFE7015015317E2EBA54C67EF290757B8D81DD7CB7DE77`)
now applies analogously to SGA. The controlling implementation is
`FRENCH_CANON_AND_CORRECTED_READING_POLICY_20260801.md` (2,100 B, SHA-256
`5191EAC46F20B6F7C03759C275E3371E4177C8ACAFC08C2371051B5C61908F8D`):
the archival French canon is diplomatic and scan-faithful; transcription
deviations are repaired to the print; suspected printed defects remain in the
canonical body and are catalogued separately. The existing corrected-French
workpass is retained only as an explicit editorial reading/history layer, not
silently substituted for the canon. A full English omnibus remains intended;
French TeX and bounded/individual French verification readers are retained,
without implying a public aggregate French omnibus.

Exposé XX is now translated and integrated through Corollary 1.4. Authority
indices 348--353 / folios 341--346 were personally checked from the direct
1100-dpi page renders; the five nontrivial diagram/details were checked from
direct 5000-dpi crops. The source recheck reversed an incipient
misclassification: the apostrophe and minus twist in printed (1.0.6), the
missing prime in (1.0.9), and the bidegrees in Lemmas 1.1 and 1.3 are genuine
printed defects, not inherited transcription deviations. They remain in the
diplomatic canon and are corrected only in the explicit editorial/English
layer. The separate diplomatic tree now exists at
`french_source_diplomatic_canon` (20 files / 922,634 B); its Exposé-XX body
remains byte-identical to the inherited print-faithful witness at SHA-256
`6908F632DB6C60BEDEEC06AFFBDE92E86C8794BFC485339A7450E4DEDC257AAA`.

English component 139 is 7,585 B / SHA-256
`9CC9D79B82D4B21F7C2292971985EC1C2A0EBE8EB2AE5C845A17462020803F52`.
The cumulative master is 9,369 B / SHA-256
`C1B2918B1DFA27DC2310F20608B5531D3210D130CE162AAFB83CDFE869051A4A`.
Three converged XeLaTeX passes produce 206 A4 pages / 1,089,370 B / SHA-256
`03A2B8C6B63D12DB157CEB46E39A33333394FC8869C39CC8B38D5A0ACEFC4D05`;
pass-2/pass-3 console SHA-256 is
`4FFCA1EB1B337BFCE03DCC83304A40C9664B99E92B32BDBBF3E67D2A93FDFEA1`
and the final log has zero critical diagnostics. English pages 204--206 pass
lead 600-dpi review after repairing the visibly missing two `Longrightarrow`
control-sequence slashes caught on the first render.

The corrected-French control records 156 cumulative dispositions. Its current
Exposé-XX body is 41,925 B / SHA-256
`C9E36B7FFD4679B897718564E83D001EBC0ECBE459081BA985EBEFE3A2368051`;
the correction register is 32,093 B / SHA-256
`CFB1D089CB9270DB950CB0F215D8A3AD703C0FDC1F8246186EB4B9A476AA4EDD`.
The converged corrected-French control PDF remains 201 pages / 1,379,858 B /
SHA-256
`BE5EF5FF30C28D3D404F3AA4E6CDD2128F1442BDDD2EDBF7AB564253A68C8F9A`;
pages 174--176 pass lead 600-dpi review. The exact next translation and French
admission cursor is Exposé XX §1.5, scan index 353 / folio 346,
`authority_snapshot/source/expose_XX_body.tex` line 232.

## Current live checkpoint — Exposé XX through Proposition 3.2

Exposé XX is now translated and integrated continuously through §§1.5--3.2,
ending with the proof of Proposition 3.2.  The direct authority has been
personally checked through scan index 360 / folio 353.  The attached EGA
French-canon instruction remains binding by analogy: the diplomatic French
body follows the print, while English/editorial interventions remain explicit
and were rechecked against the scan.

This pass distinguishes printed defects from transcription deviations.  The
printed `annexe`, capital variables, joined `constantstordus`,
`hypersurfacesde`, $E^{2n-1}$, and the blank relation in the proof remain in
the diplomatic canon.  The inherited $g$ in (2.0.8), eight omitted printed
labels, and one omitted closing parenthesis are transcription deviations and
have been repaired to the scan.  The corrected-French/English layer uses the
mathematically coherent $q$, $E^{n-1}$, and nonzero-image formulation without
inventing missing source ink.

English components 140--142 have SHA-256 identities
`18137B09FCB7929375865DFA84508523CF9834BE71D4E494D5F58D23D4E9566D`,
`A1495E244AC30E40A7F83E4469EAA39060B77910A3F7E4ACD4D8FB502DCC445D`,
and `643F1BC84EB0D3477CA7AADA6342CB6DB1AD92AA3755E7F44695EBFA268769E5`.
The cumulative master is 9,524 B / SHA-256
`742AAFB0A5B933B0211DF7240B231C8FBFB8783877FC14847524AD0BAC22DA4E`.
Three converged XeLaTeX passes produce 211 A4 pages / 1,103,740 B / SHA-256
`DCF95AE21A5AA44EE34FD1FE0E629212030880B37B2AB47597D8973B978DE669`;
pass-2/pass-3 console SHA-256 is
`DD34964491BF2F7ED96AF48D875E2D9C7D97FB56D83A217417F56A9E1D8AEB38`,
and the final log has zero critical diagnostics.  English pages 207--211 pass
lead 600-dpi review.

The diplomatic Exposé-XX body is 41,998 B / SHA-256
`3EC1736E63D201F495A78D51787651E70C66167600B901A53F6B0090BC86B4F2`.
The corrected-French control records 166 cumulative dispositions; its
Exposé-XX body is 41,895 B / SHA-256
`CFE909B6E7B5654746B962F1730CCFE66C7A457F12DFDFE57BFDCD2EB82D201A`
and its register is 34,511 B / SHA-256
`9BCCD8C0BC9509A527306FE2F4C2A2056F0B3261E7256A7081218E822196F1BA`.
Its three-pass PDF is 201 pages / 1,379,817 B / SHA-256
`F38EAE641198FB3EF97D2940EE73527D80F870C4874D8554B499FAAF34DE2E7D`;
pages 178--181 pass lead 600-dpi review.  The two overfull diagnostics in that
French control remain inherited Exposé-XVII diagnostics and were not
introduced by the current block.

Exact next translation and diplomatic-admission cursor: Exposé XX §3.3, scan
index 361 / folio 354, `authority_snapshot/source/expose_XX_body.tex` line 485.

## Current live checkpoint — Exposé XX through §4.3

Floris's attached EGA French-canon rule remains the controlling analogue for
SGA. The exact attachment is 16,563 B / SHA-256
`D9B79248A162437F4AEFE7015015317E2EBA54C67EF290757B8D81DD7CB7DE77`;
the bound SGA policy is 2,100 B / SHA-256
`5191EAC46F20B6F7C03759C275E3371E4177C8ACAFC08C2371051B5C61908F8D`.
The diplomatic French body follows the bounded print; real transcription
deviations are repaired to the scan; printed defects remain in the diplomatic
body and are corrected only in the explicit editorial-French/English layers.

Exposé XX is now translated continuously through §§3.3--4.3. Direct 1100-dpi
authority review of scan indices 361--363 / folios 354--356 found two actual
transcription deviations in the inherited French TeX: the omitted bar in
$X_{\bar\eta}$ at (3.3.4), and the omitted closing parenthesis after the
§3.4 citation. Both are repaired in the diplomatic canon. The printed
geometric-map symbol $m^*$ in (4.1.3), malformed §4.2 punctuation, and the
printed characteristic sign in §4.3 remain diplomatic source peculiarities;
the English/editorial layers transparently use the coherent readings.

English components 143 and 144 are 1,244 B / SHA-256
`D77434478C11D6093819325FE0D1D1E46ED0D724FC56C38FD398B5C7EF88554B`
and 3,209 B / SHA-256
`439F0FFDE24BA1B3A6778242E86F5AA76AF70719DFDBFB6D169E2B0EC6DE5C13`.
The current master is 9,643 B / SHA-256
`3755341D8F82F581AC0160E2889FD19A673B757DA4E2B8FDFA7DAEE57DBECBC2`.
Three converged XeLaTeX passes produce 212 A4 pages / 1,108,748 B /
SHA-256
`BE785D0E6E87122F08254B4E09BED82E16214C8C5E40BDB0B9F15583D7D7E4C8`;
pass-2/pass-3 console SHA-256 is
`5B13814A06D8D7D5B5CF6D54DC880CFADAFCE785CE47C54CA75A15DB6977B569`,
and the 39,444 B final log has zero critical diagnostics and SHA-256
`F6599D0387E91EF27E01AD8CF26924E44F871371214D918FE33E8A8BA2A7047D`.

The diplomatic Exposé-XX body is 42,008 B / SHA-256
`3693890EAD0120DF30E5FC6A5A4D8A6EE69E093CDA042F84E2201A29339D4BA2`.
The corrected-French body is 41,941 B / SHA-256
`4691204209C06CA568BF1CBF377A94411D1ACCBFF68C0ADBDA76EB02D9C4DE50`;
its correction register is 35,744 B / SHA-256
`F6265E74D3557F13FD190F71EF96AFB7926D17D2A505B5F5D5BB33DA67621E19`.
The corrected-French three-pass control is 201 pages / 1,379,762 B / SHA-256
`23B807BD53A522303907899172870FD3D1252F705DE293859759458237F339BC`.
Lead 600-dpi review passes English pages 210--212 and corrected-French pages
179--181; all formulae, notes, punctuation, and page seams are legible and
unclipped.

Exact next translation and diplomatic-admission cursor: Exposé XX §4.4,
scan index 363 / folio 356, `authority_snapshot/source/expose_XX_body.tex`
line 547.

## Current live checkpoint — Exposé XX through §4.4

Exposé XX is now translated continuously through the proof of Theorem 4.1 in
§4.4.  The lead personally compared authority indices 363--367 / printed
folios 356--360 at 1100 dpi, with direct 5000-dpi crops for (4.4.6),
(4.4.10), the Griffiths quotient and membership formula, and all four
quadrants of the commutative diagram.  Five nodes, five plain single-headed
arrows, every label side, and the terminal comma are resolved directly from
the authority; no unresolved diagram reading required a 9000-dpi escalation.

Three actual inherited French-transcription deviations were repaired in the
diplomatic canon: the lost subscript in
$V_{\bar\eta}\circ P_{\bar\eta}$, the missing minus in
$P_{\bar\eta}-m^*Q_{\bar\eta}$, and the misread projection
$\mathrm{pr}_i^*$ for printed $\mathrm{pr}_1^*$.  Printed codimension,
target, delimiter, tag, spelling, twist, degree, and cross-reference defects
remain in the diplomatic body and have explicit corrected-French and English
dispositions; the diplomatic print was not silently normalized.

English component 145 is 6,840 B / SHA-256
`AAFD8A32C59C91197BE428170D1FEF3599E10CFB3F9204ECB2A8481E9E9D650B`.
The cumulative master is 9,697 B / SHA-256
`C016649D20D9CBDB9007A1BEA3057726F30CB90000D7D04F696D7592DE1FAA97`.
Three converged XeLaTeX passes produce 214 A4 pages / 1,116,572 B /
SHA-256
`332AE51DA915962032F355C2771E70479A037CB948985D60520A802B07678C61`;
all three console logs are byte-identical at SHA-256
`AD2B61AE735CFBEEB2DCE861405AE2D13E1F139B01B73D208788E6B1CCB70255`,
and the 39,401 B final log has zero critical diagnostics and SHA-256
`975AC8F59DB800F8B015CA1E35F7FF7D6C5304914E6FCBEFD874F8F2937D13D8`.

The diplomatic Exposé-XX body is 42,016 B / SHA-256
`EB545002453B806EC9F5EF4DC932B5382C2CBF6052E80EA9921DE5FF44DE8D5B`.
The corrected-French body is 41,934 B / SHA-256
`896FABC17E52445812E50C7B87F3494C1272E233BD5FA4551AD6B6691B2BF670`;
its register is 37,606 B / SHA-256
`414376F2F0D711FCF9E60631BF2C7AD4372543F15ECA92AA72FCFD7F0BDAE785`.
The corrected-French three-pass control is 201 pages / 1,379,738 B /
SHA-256
`FE93BF9F5D544D1D9274A246C09D477F0327AFC2496969F2AD50361B548C8329`;
pass-2/pass-3 console SHA-256 is
`E5BEE18EA460051C1010F19DCC49628052E0DB15A49808747A0EA87EC2901832`,
and its 40,814 B log SHA-256 is
`82C08A26FFC3C9FCF745E62194E45C1C624055499DA0B34EB0C9BC874C335632`.
Only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi render review passes English pages 212--214 and corrected-French
pages 181--184.  The final English disclosure reflow, long formulae, native
diagram, terminal vanishing, French §4.4/§5 seam, and page bottoms are all
legible and unclipped.

Exact next translation and diplomatic-admission cursor: Exposé XX §5, scan
index 367 / folio 360, `authority_snapshot/source/expose_XX_body.tex` line
711.

## Current live checkpoint — Exposé XX complete through references

Exposé XX is now completely translated and source-aligned through §5 and its
five-item bibliography.  Direct authority review covers scan indices
367--369 / folios 360--362.  The two §5 pages pass whole-page 1100-dpi
inspection.  The final printed parenthetical was checked from the native
300-dpi CCITT source image at a pixel-preserving 9000-dpi-equivalent
enlargement and unambiguously reads `(4.2)`; the mathematical specialization
from $\mathbb P^{2m+1}$ to $\mathbb P^5$ is $m=2$.  The diplomatic French
retains the literal print, while the corrected French and English disclose
and use the coherent specialization.

No inherited French transcription deviation was found in §5.  The printed
formula-tag comma, broken (4.1.5) locator, omitted Griffiths subscripts,
twist/parenthesis defect in Remark 5.2, and `(4.2)` parenthetical are recorded
as print-layer defects rather than being silently changed in the diplomatic
canon.

English component 146 is 3,917 B / SHA-256
`C510D481AEA1DF62723377A6F64542265775BE675B31D115BC14104607B896B3`.
The cumulative master is 9,755 B / SHA-256
`BE634E455A5FAFE2820C215DB2F54C055789C06EBADE4DADA6CC79ECB200101B`.
Three converged XeLaTeX passes produce 215 A4 pages / 1,120,901 B /
SHA-256
`5F0D2233C7175B066B90E701313E7CEB9A40842651E9E85A8FDBE501F64892FA`;
pass-2/pass-3 console SHA-256 is
`C386F869E57D216B996F5D409977747CC8894475883C0461E31BAC373388BF32`,
and the 39,460 B final log has zero critical diagnostics and SHA-256
`CAF6B9BA65BA0B7139596CF9501D5812CFD932A8E07C0C3FB9F2512F127203DE`.

The diplomatic Exposé-XX body remains 42,016 B / SHA-256
`EB545002453B806EC9F5EF4DC932B5382C2CBF6052E80EA9921DE5FF44DE8D5B`.
The corrected-French body is 41,968 B / SHA-256
`5709AC2CB0116B76E103BADF523A3E703E10B561BCCE60738F90DE225E3A85D3`;
its register is 38,849 B / SHA-256
`595797F00A99D087B0E9B157DAF79C0C2FC3C61EC07521E218FEB5F65DFDF465`.
Its converged 201-page PDF is 1,379,813 B / SHA-256
`E7ECC5ED5D2387C08EE147FC7F1FD2CFA32D1313C09EAEF93AAB9955ABA43540`;
pass-2/pass-3 console SHA-256 is
`BB06575ED8A94B2C46DA10C0BAE4F541EBB7C5F623F667634232EA6A22D125D0`.
Only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 214--215 and corrected-French page
184.  The §4.4/§5 seam, definitions, quotient map, Remark 5.2 formula,
bibliography, source-disclosure footnote, and page bottoms are legible and
unclipped.

Exact next translation and diplomatic-admission cursor: Exposé XXI title and
summary, scan index 370 / folio 363,
`authority_snapshot/source/expose_XXI_body.tex` line 1.

## Exposé XXI opening through Definition 1.0 — 2026-08-02

The title, contents, Introduction, section 1 heading, and Definition 1.0 are
translated and admitted through authority-source line 79, scan indices
370--373 / folios 363--366.  All four authority pages were personally checked
at 1100 dpi.  The formulas (1.0.1)--(1.0.3), the exponent $p^M$, the top
cohomology degrees, and the Hasse--Witt terminology are unambiguous.  No
inherited French transcription deviation was found in this block.

The printed wording defects `et de démontrer`, `suffisament`, `un vectoriel
en car. p`, `dûs`, and the `Appendice I` locator are retained literally in the
diplomatic French canon and recorded externally.  Editorial repairs appear
only in the separate corrected-French workpass.  The diplomatic Exposé-XXI
body is 70,201 B / SHA-256
`A9B2CC851B0BFB505F555299454B4B4260426819B1EF860085034C53DDDAFAC1`.
The corrected-French body is 70,238 B / SHA-256
`4D6A3124D67CC2057C5F049F58AEB1A89EA855CA78A9C7D6E0EB370151C3ECD8`;
its 39,624 B correction register has SHA-256
`C27BE5F68E4B4B3EF1F0D41F761E4C263E7DB34899A44D5378B8089C2BACF68C`.
The 6,048 B admission log has SHA-256
`7B829AFEEC4152CB068214322145B77570ACC11DB272E6F437AFDA6FFD164F43`,
and the 5,754 B source-defect register has SHA-256
`F2138FD5B561E0D8F801037E599A437B00E8BB633783784BDB0BCE453C9BD252`.

English component 147 is 4,047 B / SHA-256
`60CD80817F3F916DB774A7666B741E1C45EDEDC17DC7E72B245D683060DB5653`.
The cumulative master is 9,827 B / SHA-256
`03A4D1FF3D0D62573E27FE5601A607D2996035A605E5743991BF44A9A69FC062`.
Three byte-identical XeLaTeX console passes produce 217 A4 pages /
1,126,149 B / SHA-256
`788CAA769B5906A3256EBE4BD98501087424F79F033281E7A24400493BB4FD9E`;
the common console SHA-256 is
`8A836AAF3B1515D0B11AABC60074A6253C085DBDCBB197E4F16E9A11FEF938AE`,
and the 39,591 B final log has zero critical diagnostics and SHA-256
`7CA2DCFF9747A734374D91810E55688BE8A7FB41449447AC78CDF34A33BF69F5`.

The corrected-French three-pass build remains 201 A4 pages / 1,379,764 B /
SHA-256
`096AC65A9335A32999749982BAC7F56A0F9B65A726241F9BD96CB1D27AB20281`;
its pass-2/pass-3 console SHA-256 is
`6EB05A695F38E88D09D9D016F8A43CA35283B43E06FAADE43599A9C543426843`
and its 41,171 B log has SHA-256
`C5DF0B434D846D84F803DD1DF495BB7A81F2BE57F51414C373ABC12A9FC39CA7`.
Only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 216--217 and corrected-French pages
185--187 for layout and legibility.  Those later French render pages are only
visual witnesses: diplomatic admission remains strictly bounded through
source line 79 and does not follow merely from a successful whole-file build.

Exact next translation and diplomatic-admission cursor: Exposé XXI Theorem
1.1, scan index 373 / folio 366,
`authority_snapshot/source/expose_XXI_body.tex` line 81.

## Exposé XXI Theorem 1.1 through Proposition 1.1.5 — 2026-08-02

Theorem 1.1, its universal-family argument, Proposition 1.1.5, and its trace
proof are translated and admitted through authority-source line 136, scan
indices 373--375 / folios 366--368.  The three authority pages were personally
checked at 1100 dpi.  The universal-family map, locally free direct image,
iterated Hasse--Witt operation, matrix locus, trace congruence, cohomological
degrees, and nilpotence implication are unambiguous.  No inherited French
transcription deviation was found in this block.

The printed forms `parmi toute les`, `la``famille`, the interrupted rank
sentence, `théroème`, `intersection complète vérifiante`, and `n'a pas des
points` are preserved in the diplomatic French canon and recorded as print
defects.  The separate editorial French and English use the coherent readings.

English component 148 is 3,320 B / SHA-256
`026F773D2ADB06E34C630E827060017237C80010FEDACDF3D68C04DB8D8E1A75`.
The cumulative master is 9,895 B / SHA-256
`62F5E1D99848815A28D5AB60FEF7A621A5225505FA8876478E3792E7E41D0417`.
Three XeLaTeX passes produce 218 A4 pages / 1,130,049 B / SHA-256
`6E4BF362475EEB07FD051E6AC189AC8CAB950619A5AC081E172EB73704650277`;
pass 2 and pass 3 are byte-identical with SHA-256
`1967E6D0296B700A73B0123762C01EA0871993154266DEAE0F637241CCB7823D`.
The 39,725 B final log has zero critical diagnostics and SHA-256
`6AD094375D564E05925A6647390C63A4F9050C0266432D9D0A663777952BF54C`.

The diplomatic Exposé-XXI body remains 70,201 B / SHA-256
`A9B2CC851B0BFB505F555299454B4B4260426819B1EF860085034C53DDDAFAC1`.
The corrected-French body is 70,235 B / SHA-256
`5497E846CADE5260BC7E8FC7904FB41750208AF4F3F64D3838B6D319DC602363`;
its 40,375 B register has SHA-256
`B8DAC14FF33EE3325D04E0CB3FF27CD485F9336A49BAE34BE0088F29FDF7A22A`.
The 6,833 B admission log has SHA-256
`E1FF1E1E2933EB711BF6C4C454264CDC4F42C57D92CB3BEC66C7C51AC7C6C6B5`,
and the 6,254 B defect register has SHA-256
`252E2EF76C0BF605B151778066539DC954356B7A96057A56DD9737B9878682D1`.

The corrected-French build is 201 A4 pages / 1,379,744 B / SHA-256
`C4A695A3968AFD622B33CAF0811EA9ACD0F3E2B567B422B9E48DDA34D3B75DA0`;
pass 2 and pass 3 are byte-identical with SHA-256
`16F1CAC22F86E00BF6FEC2977A7A4DA265524578B1E6F969BCD907653344D51C`.
Its 41,218 B log has SHA-256
`1728C8E953AF06BFB913A1CC80A6A666181A51DB58499B6855F6F6735B7AC630`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 217--218 and corrected-French pages
185--187.  The latter include later unadmitted source on page 187; admission
is bounded strictly through line 136.

Exact next translation and diplomatic-admission cursor: Exposé XXI
Proposition 1.2, scan index 375 / folio 368,
`authority_snapshot/source/expose_XXI_body.tex` line 138.

## Exposé XXI Proposition 1.2 — 2026-08-02

Proposition 1.2 and its proof are translated and admitted through authority-
source line 192, scan indices 375--377 / folios 368--370.  The three authority
pages were personally checked at 1100 dpi.  Three formula-sensitive details
were then checked directly from the native 300-dpi CCITT page pixels enlarged
point-for-point to a 5000-dpi equivalent view; the enlargement introduces no
new image information.

The authority confirms three printed mathematical defects: the misplaced
parenthesis in (1.2.1), the literal lower bound `d_1\geq a_0`, and the missing
`+1` in the final block of variables defining `H_r`.  The inherited French
transcription reproduces all three accurately, so no diplomatic transcription
change is admitted.  The diplomatic canon preserves them as printed.  The
separate corrected-French workpass and the English translation use
`H(X_1,\ldots,X_{n+2})`, state `a_0=0` and
`d_i\geq a_i-a_{i-1}`, and begin the final block with
`X_{a_{r-1}+1}`.  Dispositions SGA7II-FR-XXI-007 through -010 record these
readings without replacing the diplomatic source.

English component 149 is 2,105 B / SHA-256
`D456560CFF215AA8CA329A739621087C7655651E88318AE71B5C7D5C3E7D4D98`.
The cumulative master is 9,945 B / SHA-256
`E78A190A6CF24264057237697582F0B66DF07226A9FAF2D815D311FC31A226D9`.
Three XeLaTeX passes produce 219 A4 pages / 1,132,799 B / SHA-256
`02D6DB000FCADA9D009F736E0DEE311882CFFB6FA7C40821C3C913EA6EFEBE06`;
pass 2 and pass 3 are byte-identical with SHA-256
`11AF4B038EA35154685915CE973BF7D3AF39C72BB791F07FF21EE5EB16B570B5`.
The 39,737 B final log has zero critical diagnostics and SHA-256
`8A3CEDD83E2A146FA3C198B2CA8B7A4668305DB7AE0D201B84FB4F8C1BE4C8F5`.

The diplomatic Exposé-XXI body remains 70,201 B / SHA-256
`A9B2CC851B0BFB505F555299454B4B4260426819B1EF860085034C53DDDAFAC1`.
The corrected-French body is 70,256 B / SHA-256
`00D47E4CCCECE0B9E1886C07D4DFE051759DF34E891CC6F510065ABC703E3F2E`;
its 41,390 B correction register has SHA-256
`85331470A051B81E7670B643784145F8A04537E6A1FF793F0F9DF0B65AAA46B6`.
The 7,652 B admission log has SHA-256
`1C9E337B07569B2052E0FE76F69EB660EDBD67F7A9EAD129EEB7C26470585998`,
and the 7,128 B source-defect register has SHA-256
`C5C91C471F9D41BF08F7FEEEA3659D46384638D7BAFA2839EA6D7B9506870303`.

The corrected-French build is 201 A4 pages / 1,379,736 B / SHA-256
`B20EF081BDB73499DEF8B945DA468AB16D1DA9162FFAEB48C6E261FF19C7787D`;
pass 2 and pass 3 are byte-identical with SHA-256
`EC16B8265B3E815BD49FD1529FF8AAE66C64F611D7A5366E7435BD998B73D4E7`.
Its 41,212 B log has SHA-256
`4F054B280C3AC6D41C7A6997D825A7CEABF4119992BD89D27228333550DF87E4`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 218--219 and corrected-French pages
186--188.  Later French text visible on page 188 is not thereby admitted;
the exact diplomatic boundary remains source line 192.

Exact next translation and diplomatic-admission cursor: Exposé XXI Theorem
1.3, scan index 377 / folio 370,
`authority_snapshot/source/expose_XXI_body.tex` line 193.

## Exposé XXI Theorem 1.3 — 2026-08-02

Theorem 1.3 is translated and admitted through its end at authority-source
line 312, scan indices 377--381 / folios 370--374.  The authority pages were
personally checked at 1100 dpi, with formula and diagram details inspected
from the native 300-dpi CCITT pixels at point-preserving 5000-dpi-equivalent
display scale.  This enlargement adds no source information.

The diplomatic French canon now corrects inherited transcription deviations
in (1.3.1), the Frobenius glyph, plain `E`, `H^0`, and the missing closing
delimiter.  It otherwise preserves the printed readings, including
`\mathfrak F_{p^n}`, `\mathcal O_u`, the citation `(1.5)`, the diagrammatic
base change `\times_U T`, and `se formation`.  The separate corrected-French
workpass and English use the mathematically coherent readings
`\mathfrak F_{p^M}`, `\mathcal O_U`, Proposition 1.1.5,
`(\widetilde X.H_T)\times_T U`, and `sa formation`; dispositions
SGA7II-FR-XXI-011 through -016 preserve the distinction append-only.

English components 150 and 151 are respectively 2,929 B / SHA-256
`B84C2704B0735FEB86A0B2FBF8CEDC37972789FA9CB27C31236559DF688C8230`
and 2,849 B / SHA-256
`EFDD0261F1BF9EB4B56654D28A73B61F530714249EADDE4B0FBD4A2E9467378B`.
The cumulative master is 10,068 B / SHA-256
`CE7D455771A51A6F7E5C7603773A4F0DB0DF37BF4128344D8F4BF65287783A0C`.
Three XeLaTeX passes produce 221 A4 pages / 1,140,478 B / SHA-256
`EFE8691C779F787FA859CF9D5D25F95820179ECECBE7B74446D6DE950495398A`;
pass 2 and pass 3 are byte-identical with SHA-256
`BEB15548F4C760DBEA9F86BE7F402F436592CE17999B65D7A43F92D203C868DC`.
The 39,385 B final log has zero critical diagnostics and SHA-256
`C904E09BC931E2C898790FAA7AB95C983B02C50A51D1EA6A769B9BCF190621CA`.

The diplomatic Exposé-XXI body is 70,191 B / SHA-256
`B85254EF9E3EE6AF42C5FEB77C0E791C9729364A0E4ACB002A10BA47FD5E5B55`.
The corrected-French body is 70,245 B / SHA-256
`A0D67F7EEDF9E0E0A29F2210A7BAFF85D24829A3A887EE9CE0B22FC23F889F11`;
its correction register has SHA-256
`F886DE978FD5E40001A598202D29971A0AECEC0C8AD6C849D24DBB498829B4A0`.
The admission log has SHA-256
`098A3378BFEC99F01E1BF0345BC7DD3D7156943DC7C8D5CFD996BCE47E164F41`,
and the source-defect register has SHA-256
`A8DF21A1AF0CFE66A448699E34334B7E78F718AAC2170B3594F17B58D0C27FB4`.

The corrected-French build is 201 A4 pages / 1,379,745 B / SHA-256
`D6553F8DC324804C3C97EEA230CCE79436CC30E9734CF9444617D1ACEB20699A`;
pass 2 and pass 3 are byte-identical with SHA-256
`B23D0768E868E4016573FA175474FCBB923C5286BA8904961C4CA55E9D82CFE6`.
Its 40,700 B log has SHA-256
`6A5583C87501881BD416A699401FF40AE314E0757A9DCFE1858D07E4706F4D7B`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 220--221 and corrected-French pages
189--190.  Later French text visible on page 190 is not thereby admitted;
the exact diplomatic boundary remains source line 312.

Exact next translation and diplomatic-admission cursor: Exposé XXI Theorem
1.4, scan index 381 / folio 374,
`authority_snapshot/source/expose_XXI_body.tex` line 316.

## Exposé XXI Theorem 1.4 — 2026-08-02

Theorem 1.4 is translated and admitted through its end at authority-source
line 383, scan indices 381--384 / folios 374--377.  All four authority pages
were personally checked at 1100 dpi.  The coordinate spelling, the relation
signs in (1.4.6), and the ellipsis in (1.4.8) were checked from native
300-dpi pixels at point-preserving 5000-dpi-equivalent display scale.

The diplomatic French canon restores three inherited transcription
deviations to the print: `coordonnées`, the two equality signs printed in
(1.4.6), and the three-dot ellipsis in (1.4.8).  It preserves the print's
letter-like zero subscripts $d_o,X_o$, `une $H$ défini`, and displaced
point-count parentheses.  The separate corrected-French workpass and the
English use $d_0,X_0$, masculine agreement, ordinary point-count evaluation,
and mathematically clearer congruence notation.  Dispositions
SGA7II-FR-XXI-017 through -022 record the distinctions append-only.

English component 152 is 4,683 B / SHA-256
`1EE4FBBFDDE90C2599786DA31E701D95E3748BFCA16676B5DEC6B7F6007E5E2C`.
The cumulative master is 10,114 B / SHA-256
`B7D3D7C555A425015A8102ADB1709CFE5EE332D11C4F33809A8B5017AD03A489`.
Three XeLaTeX passes produce 223 A4 pages / 1,146,316 B / SHA-256
`B5F1526D7794755BA48554EEDE527A4CFC85BA1B46ABBD0383CBCDBBC13180B5`;
pass 2 and pass 3 are byte-identical with SHA-256
`6709942C252A57282C7A3ABBF0E6D96038FDCAAF876489661170CF7E64322EE0`.
The 39,402 B final log has zero critical or overfull diagnostics and SHA-256
`F5F4E0179565DFD6D905522109D6C8799858CF99D4FE3D25102CFCA860C9C3A1`.

The diplomatic Exposé-XXI body is 70,183 B / SHA-256
`01AB0084D4430B9D0BD9C4C7EAB2D7EB0C65AD792F302FF943A35D5D1BED8050`.
The corrected-French body is 70,244 B / SHA-256
`063846A25A9FA289A721A58A1FE6C2A9826FACB15DB9336DE5E4E7FC05940C46`;
its correction register has SHA-256
`2B8CC796906F51F28F667937E14E4E37E79FECF189E5D266A7D9E53B4F11EF3B`.
The admission log has SHA-256
`E94FFA984A8FE195591CF21EC8837E6DE15B8D8FAEFE946544FA05C19377FB2C`,
and the source-defect register has SHA-256
`507491F949542D0C623CDBE9A22A7A335A84E9E3421F7FCA8DDF6AC7B5191304`.

The corrected-French build is 201 A4 pages / 1,379,715 B / SHA-256
`AEB8F5D6BF3F2F4D867E0C07B303B027962C07A3D11381D622B25451657A7AAE`;
pass 2 and pass 3 are byte-identical with SHA-256
`8DEB6AB9889455C7195041528CB880DCE927ACBC874009E73230B58E5DA6E54F`.
Its 40,700 B log has SHA-256
`48F679D2DBA327F763959EF57B065B8CDC30C451EDCA76638A1595A9753ADF08`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 221--223 and corrected-French pages
190--191.  The latter continues into later unadmitted §2 material; the exact
diplomatic admission boundary remains source line 383.

Exact next translation and diplomatic-admission cursor: Exposé XXI §2,
scan index 384 / folio 377,
`authority_snapshot/source/expose_XXI_body.tex` line 389.

## Exposé XXI §2 — 2026-08-02

Section 2, including Theorem 2.1, assertion (2.1 bis), Corollary 2.2, and its
proof, is translated and admitted through authority-source line 428, scan
indices 384--386 / folios 377--379.  Whole authority pages were personally
checked at 1100 dpi.  The overstruck finite-extension phrase and terminal
Galois-module map were checked from native 300-dpi pixels at point-preserving
5000-dpi-equivalent display scale.

No inherited transcription deviation was found.  The diplomatic French
therefore remains byte-identical.  It preserves the printed vector-space
terminology/agreement, overstruck $M$-th-power phrase, blank numerator in
$\mathrm{Gal}(/\mathbb F_q)$, and omitted domain direct-sum sign.  The
separate corrected-French workpass and English use standard vector-space
terminology, state the $M$-th-power operation plainly, restore
$\overline{\mathbb F}_q$ in the Galois group, and display the direct sum
required by $\oplus_i\operatorname{Cl}(Z_i)$.  Dispositions
SGA7II-FR-XXI-023 through -026 record these editorial readings.

English component 153 is 3,154 B / SHA-256
`537DBEDB6E4389A3C798EBAE84A5B58F05B48DDEB2CA656086D46B6348D3158F`.
The cumulative master is 10,158 B / SHA-256
`1DB73EA21CB53E1EC2B1857F95740EAE67FE3DE908751B38159342C40B6575F5`.
Three XeLaTeX passes produce 224 A4 pages / 1,150,581 B / SHA-256
`347468FE2203A91A65697D47AF20998B176DCA7D906D8DED7AC0772FFBF9BC73`;
pass 2 and pass 3 are byte-identical with SHA-256
`1654FA623EFC265D2CC1FDB7CD6FCE200F111862FD2E9029D2581601B17FFC4C`.
The 39,444 B final log has zero critical or overfull diagnostics and SHA-256
`2CFF8D268D22115DCB9926B15DE7C75ABFD5D42166CF8D63743197B744BF2D1D`.

The diplomatic Exposé-XXI body remains 70,183 B / SHA-256
`01AB0084D4430B9D0BD9C4C7EAB2D7EB0C65AD792F302FF943A35D5D1BED8050`.
The corrected-French body is 70,286 B / SHA-256
`A789921E77B7EAE2C8580B92CD24D4D10B723C018744DD478D6210A72440331E`;
its correction register has SHA-256
`DE79209D7787222B8C9687988A792E01E8EBA998E157100FD5B04F2443E7D66F`.
The admission log has SHA-256
`EE8FF7D1E29361CA72329B2C30F4DC94F3ADE1812EB8C99AB1862492FDD55DCC`,
and the source-defect register has SHA-256
`5844D2234624D3A2635A1ED13E21D179881D6A99C9A727DA1485AEAA82D6BE29`.

The corrected-French build is 201 A4 pages / 1,379,333 B / SHA-256
`DDD2FFAEC3A3B8E1E00A89ECE1856DAA7FCE7EE262D270130C68BA85D6324F62`;
pass 2 and pass 3 are byte-identical with SHA-256
`A1E044118E098D20F561A27F06BB1EFFDD26B15939EC667CAC1594B81D18E26F`.
Its 40,694 B log has SHA-256
`C843A321329F30D3CFF9ED84314A11D4E2F376EDBEEBE88C5BA45E600B0186E2`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 223--224 and corrected-French pages
191--192.  The latter continues into later unadmitted §3 material; the exact
diplomatic admission boundary remains source line 428.

Exact next translation and diplomatic-admission cursor: Exposé XXI §3,
scan index 386 / folio 379,
`authority_snapshot/source/expose_XXI_body.tex` line 434.

## Exposé XXI §3 opening through Corollary 3.1 — 2026-08-02

The opening of §3 through Corollary 3.1 is translated and admitted through
authority-source line 498, scan indices 386--388 / folios 379--381.  Whole
authority pages were personally checked at 1100 dpi.  Formula details were
read from the native scan pixels; no higher enlargement was needed for this
block.

No inherited French transcription deviation was found.  The diplomatic canon
therefore remains byte-identical and preserves the printed word order
`intersection complète dans P^N lisse`, the typo `da décomposition primitive`,
and the omitted index in `1 <= <= n-1` in (3.0.4).  The separate corrected
French and English use normal word order, `la décomposition primitive`, and
restore the mathematically forced index `i`.  These dispositions are recorded
as SGA7II-FR-XXI-027 and -028.  The controlling SGA analogue of the EGA French
canon rule is fixed in `FRENCH_CANON_AND_CORRECTED_READING_POLICY_20260801.md`,
2,100 B / SHA-256
`5191EAC46F20B6F7C03759C275E3371E4177C8ACAFC08C2371051B5C61908F8D`.

Lead render review found one English-only TeX slip in the first build of
(3.0.5), where `equiv` printed literally.  It was corrected to `\equiv`, the
three-pass build was repeated, and the repaired page 224 was re-rendered and
personally passed.  French source layers were unaffected.

English component 154 is 3,424 B / SHA-256
`CBA5397F87988F264C6EFD562968056C88D4DA7CB4A73CF15A14A9651FF850FC`.
The cumulative master is 10,232 B / SHA-256
`8BB984B09995F5EB1AE1874A0D42222A9ABA4D7F9D4D2D5775B5F76902B5FCE9`.
Three XeLaTeX passes produce 225 A4 pages / 1,154,535 B / SHA-256
`D2C9DC467C683DB4D9DFA0B158E9E89F85D54CCF5DD8BF8D2F671073FF504F09`;
pass 2 and pass 3 are byte-identical with SHA-256
`5C338E675866D4D532E5E93A7D69BB7238107922DBECB6B25D711396AE472E2A`.
The 39,414 B final log has zero critical or overfull diagnostics and SHA-256
`5D876ADC36D98BD3A1773A340405D24233B55E205FAABB52E543A83DC9E116D5`.

The diplomatic Exposé-XXI body remains 70,183 B / SHA-256
`01AB0084D4430B9D0BD9C4C7EAB2D7EB0C65AD792F302FF943A35D5D1BED8050`.
The corrected-French body is 70,282 B / SHA-256
`5FFA142C886CF00ED437FAE73A53BA307FB199F055D34DC3B07C2CD1F5B71490`;
its correction register has SHA-256
`942F20DBCE53B7732583F6E14A9E5ECBDED68B5F08FD7087A51B8D0CA31986C5`.
The admission log has SHA-256
`1807B501296727812AE8A63C6D22DA143CAF2CC202AF6371951C2AAA77B50E99`,
and the source-defect register has SHA-256
`FD3ADA1B01F9FBCEC416FA3656EED7D829D70C4C9A79F530BA1B742F63F49A1D`.

The corrected-French build is 201 A4 pages / 1,379,356 B / SHA-256
`C98BA8B73AB37903FF0F1D39E9DA0217F44A3074FF8FC7BFC1615C8CA8673B51`;
pass 2 and pass 3 are byte-identical with SHA-256
`6A61F00FA653EB96968B0A8BFDC362CAB11AF0E396372142984C0C15B3B8F32E`.
Its 40,700 B log has SHA-256
`F6748603B7E963BC2ABADB6F9110F0C0F860CE828FD971F95C607684B7F02AAD`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 224--225 and corrected-French pages
192--193.  The latter continues into unadmitted Proposition 3.2; the exact
diplomatic admission boundary remains source line 498.

Exact next translation and diplomatic-admission cursor: Proposition 3.2,
scan index 388 / folio 381,
`authority_snapshot/source/expose_XXI_body.tex` line 500.

## Exposé XXI Proposition 3.2 — 2026-08-02

Proposition 3.2 and its proof are translated and admitted through
authority-source line 545, scan indices 388--389 / folios 381--382.  Both
authority pages were personally checked at 1100 dpi.  Diagram (3.2.3) was
checked node-by-node and edge-by-edge: four nodes, four plain arrows, both
horizontal arrows leftward, both vertical arrows downward, $\pi$ on the left
of the left vertical shaft, and the terminal point after $\operatorname{Sp}(k)$.

No inherited French transcription deviation was found.  The diplomatic canon
retains the printed $X=\widetilde X/_{\eta}$ form in the diagram.  The
corrected-French and English layers use $X=\widetilde X_\eta$, agreeing with
the concluding sentence of the proof; disposition SGA7II-FR-XXI-029 records
the normalization.

English component 155 is 1,831 B / SHA-256
`95D59D2B364EDCD1A95B80BCBD7AC73197763CFF44478431A5C54CFA2A6994FB`.
The cumulative master is 10,282 B / SHA-256
`23DB4A3FFD5CC02F773CB8C246095CB747057E563CAE6B1F5151AF8F6B08333B`.
Three XeLaTeX passes produce 225 A4 pages / 1,156,665 B / SHA-256
`8B2993E1629A42D7A5F360D702011D1C0253FB35C941461C6AE41B02382DF390`;
pass 2 and pass 3 are byte-identical with SHA-256
`0AF7342DF6F4422402C92C17BFCD06D43D542FCF7C94A08248D2F10A6AE275A1`.
The 39,462 B final log has zero critical or overfull diagnostics and SHA-256
`F5F1229B7F8D271118FA0CEB8F041BC6632135779C26307C5A0E5908B68CF6AF`.

The diplomatic Exposé-XXI body remains 70,183 B / SHA-256
`01AB0084D4430B9D0BD9C4C7EAB2D7EB0C65AD792F302FF943A35D5D1BED8050`.
The corrected-French body is 70,280 B / SHA-256
`7467636289FFFAB0E6F340EBB80C4CA9D9ACA709A3A39E5C46167612413C1695`;
its correction register has SHA-256
`CDD15D53643192B779F26A524D1572CF10E3588BB936C95E673DA75CC5E61674`.
The admission log has SHA-256
`13B1CEBBE67E0EB9B56FF4F95BED7234F90B5406D99CF6FC6C38C858882EF314`,
and the source-defect register has SHA-256
`D932403D2E244A7B4A55767F2EF8661D79E9749C735965914C06FB2D9D227849`.

The corrected-French build is 201 A4 pages / 1,379,346 B / SHA-256
`4C4D48F5C38AC0ACE7977B933DF93064A9189C4AD34C3E9459C8456005A8E895`;
pass 2 and pass 3 are byte-identical with SHA-256
`AA83B2CFA5115FD3B7AB47EDB0E038371984CBB59145511D10E3ACA94A6D0EEE`.
Its 40,460 B log has SHA-256
`EF2A9A877AB4325E568412C81935C6009EC15623BACF7D4F78CEA9369F5ED00B`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English page 225 and corrected-French page 193;
corrected-French page 194 is a clean seam into unadmitted §4/§5 material.
Exact next translation and diplomatic-admission cursor: Exposé XXI §4,
scan index 389 / folio 382,
`authority_snapshot/source/expose_XXI_body.tex` line 548.

## Exposé XXI §4 and bibliography — 2026-08-02

Section 4 and its bibliography are translated and admitted through
authority-source line 594, scan indices 389--390 / folios 382--383.  Both
authority pages were personally checked at 1100 dpi.  No inherited French
transcription deviation was found.  The diplomatic French retains the printed
lower summation limit $1$ in (4.1.1) and `de meme`; corrected French and
English make the index explicit as $i=1$ and restore `de même`, recorded as
SGA7II-FR-XXI-030.

English component 156 is 2,017 B / SHA-256
`CA7D663CE5085CDE713CFC9044820BEF7919168264591F0433E5DE59AF557CF1`.
The cumulative master is 10,343 B / SHA-256
`CE1A54433642F6210F1A035BCDD7B7606C54D7976350544D764AFAB243C7610A`.
Three XeLaTeX passes produce 226 A4 pages / 1,159,050 B / SHA-256
`5C08B788FBBB197983115B6C197965D5C6F19E3A7C0A5755F095B73A6FDB7E33`;
pass 2 and pass 3 are byte-identical with SHA-256
`076C3C09868E80F8539DA6334391F4FF1BE4FE6167EC17EF5C1C5A345726098E`.
The 39,527 B final log has zero critical or overfull diagnostics and SHA-256
`CFBE7A0F49BAF5B22E4EAAD102FAF2C03C8B6DF27A63E5300509FE2DB289DB57`.

The corrected-French body is 70,280 B / SHA-256
`B522A8A22311092924AB2C1540CE9BBA4630FEBDB616EBB859E773011A9282BC`;
its correction register has SHA-256
`38A5DE0878CEAF8013BDBB89099EB80424890EB9E992DAB1D6D3597FFE4C8666`.
The admission log has SHA-256
`EEEE80D715F3F026AF8CAB6F2CBC25786ED2F297D1B6E84BE1DAE07E4D424902`,
and the source-defect register has SHA-256
`B102187A12E6CE952503F8019D75F9BF56502785B1CCA56A251983F48F695BA6`.
The diplomatic body remains 70,183 B / SHA-256
`01AB0084D4430B9D0BD9C4C7EAB2D7EB0C65AD792F302FF943A35D5D1BED8050`.

The corrected-French build is 201 A4 pages / 1,379,370 B / SHA-256
`C858138157FE1649F1E7409ADE1D988E9599F08110A44B5DA74B045AD520073F`;
pass 2 and pass 3 are byte-identical with SHA-256
`A2C55519EC22EB0229FD475811B66E5DE4C1A311CC3225F9D4624382A8F73D52`.
Its 40,460 B log has SHA-256
`A46C9F74B20335B3EF40E3350913533EC70FF9DC985D13B4ADEF311218B41474`;
only the two inherited Exposé-XVII overfull diagnostics remain.

Lead 600-dpi review passes English pages 225--226 and corrected-French pages
193--194.  The latter continues into unadmitted §5.  Exact next translation
and diplomatic-admission cursor: Exposé XXI §5 appendix, scan index 391 /
folio 384, `authority_snapshot/source/expose_XXI_body.tex` line 600.

## Exposé XXI Appendix §5 through the setup for Lemma 5.3.1 — 2026-08-02

Appendix §5 is translated and diplomatically admitted from its opening
through the setup immediately preceding Lemma 5.3.1, authority-source lines
600--745, scan indices 391--396 / folios 384--389.  All six authority pages
were personally checked at 1100 dpi.  Both diagrams were checked for every
node, arrow, hook, direction, label side, empty cell, and terminal punctuation.

Three dispositions are recorded as SGA7II-FR-XXI-031 through -033.  The
joined `nombresen`, generated calligraphic/pseudo-letter Galois symbols, and
`Désignnons` are genuine inherited transcription deviations and are repaired
to the printed spacing, Fraktur group symbols, ordinary $\operatorname{Gal}$
lettering, and `Désignons` in both French layers.  The diplomatic canon keeps
the directly confirmed printed $F[[t]]$ and restriction to $U$; corrected
French and English use the coefficient field $E$ fixed in 5.0 and the newly
chosen open $U'$.

English components 157 and 158 are respectively 3,722 B / SHA-256
`FD35E44CBAF2A4B32CBD5845502F27635DA240E197EF44A37812182C71B966D4`
and 5,537 B / SHA-256
`29B8B6350992F29FF86204A2393D591FE14572077654B62FABE9D39D8451A805`.
The cumulative master is 10,486 B / SHA-256
`F5C32E058DDE62144B556B2E96CDFE753B73CF0A9AC397C43F0923803564547A`.

The first English build compiled but rendered the literal word `simeq` in the
Poincaré-duality formula because a TeX backslash was absent.  That r1 build is
preserved as adverse history.  After the source repair, three fresh XeLaTeX
passes produce 229 A4 pages / 1,173,457 B / SHA-256
`1E9EE49990BA1879CBCA8605DBF4415005FB33D3D88638F7A88F97B099CCC538`;
pass 2 and pass 3 are byte-identical with SHA-256
`1F14E5855E24279B570FCBAE97857F415BCD43DA3A36DAB581F3EA0A3943E71A`.
The 39,832 B final log has zero critical and zero overfull diagnostics and
SHA-256
`24F956D08715B5690ED546B4BEF1F7D5115F455CC78FBF29C7B53C819EF4F32F`.
Lead 600-dpi review passes final English pages 226--229, including the repaired
formula and both reconstructed diagrams.

The diplomatic Exposé-XXI body is 70,179 B / SHA-256
`D86C73447721D4C7615440663AA02433FB9404BF0C07E4D797A813F29914B944`.
The corrected-French body is 70,275 B / SHA-256
`AFF04E7FEDF7FC608C328F3DF4464E5F0344BF659999C6FB372068E598547CD4`;
the correction register is 47,823 B / SHA-256
`466FE3AEBB7A49CCB0BC5C8E21191F447EA2F3DACD774957DCE4371D798350F2`.
The admission log is 14,253 B / SHA-256
`B16079DD448B300145E86B267137ECBAA9D70D812851DA9892F765BEC8833FA0`,
and the source-defect register is 12,442 B / SHA-256
`02CCEA26150782521E5114ED4043FAECA7CF4C1DBE2A0E0E7F34D37F5E8C22DB`.

Three pdfLaTeX passes produce the corrected-French verification reader at
201 A4 pages / 1,379,664 B / SHA-256
`0F47F6C722A579A25E258CB4108A475742E254796E54054EADC83116A46FDBF5`;
pass 2 and pass 3 are byte-identical with SHA-256
`A4BED35C6EFFBD90A0DF1EA83CD05B7C2EFDA1D43867D1EA4B73C7262442FD88`.
Its 40,709 B log has SHA-256
`D1D8AF9AC5B4FCC383D94842569C09ED6CCECF4399FA99FD4B2FF499C6CC9E78`;
only the two inherited Exposé-XVII overfull diagnostics remain.  Corrected-
French pages 194--196 pass lead 600-dpi review; later rendered pages are
continuation context and are not yet claimed as admitted.

Exact next translation and diplomatic-admission cursor: Lemma 5.3.1, scan
index 396 / folio 389,
`authority_snapshot/source/expose_XXI_body.tex` line 747.

## Exposé XXI Lemmas 5.3.1--5.3.2 and Theorem 5.4 — 2026-08-02

The English translation and both French layers are now source-checked through
Theorem 5.4, authority-source lines 747--829, scan indices 396--399 / folios
389--392.  The four authority pages were personally inspected at 1100 dpi;
the three-row cohomology diagram in Theorem 5.4 was checked node-by-node,
arrow-by-arrow, label-by-label, and for all terminal punctuation.

The diplomatic French preserves three printed-source peculiarities: the
eigenvalue index in Lemma 5.3.1 uses the ambient dimension $n$, the proof of
Lemma 5.3.2 cites `3.2`, and $k[T]/T^k$ is called irreducible.  Corrected
French and English introduce $r=\dim_E V^I$, cite 5.3.2, and use the exact
mathematical term \emph{indecomposable}; dispositions SGA7II-FR-XXI-034 and
-035 record these interventions.  No inherited French transcription
deviation was found in this range.

English components 159 and 160 are respectively 2,920 B / SHA-256
`8E193A99C487F86F3078C12D7B8CDC18CD8692E70B4BF6B028C956958A305F63`
and 2,011 B / SHA-256
`7003D60B9E443DAB3EB7CB9C38EC2635AE8CB035C8C9724E1F90C3050136D689`.
The cumulative master is 10,589 B / SHA-256
`C0CCABB6CC02230D4B794ECFF7A448DDC534E3FF176016F216102DC0035BC69B`.

The first English build exposed missing Unicode curly-quote glyphs in the
source note and is retained as adverse r1 history.  After replacing those
characters with native TeX quotation markup, r2 compiled cleanly, but direct
render-to-authority comparison found a terminal period where the source has
a comma in the third row of the Theorem 5.4 diagram.  The punctuation was
repaired and the affected page rebuilt and re-reviewed.  Final r3 is 231 A4
pages / 1,180,973 B / SHA-256
`5156D9A69E7B2314079190E9B19B67041772D92CAE54A0E34AE66F23B97983B6`;
pass 2 and pass 3 are byte-identical with SHA-256
`CD91B80F075A36BA2E86034342F6A88A2BF2FB13FDF8631566E75A8B95D129A4`.
The 39,892 B final log has zero critical, overfull, or missing-character
diagnostics and SHA-256
`95ADF2BE27286F8307B06FB1781BE7C7131FD84EF8CE0C37270C9C85BE74BA9F`.
Final English pages 229--231 pass lead 600-dpi review.

The diplomatic Exposé-XXI body remains 70,179 B / SHA-256
`D86C73447721D4C7615440663AA02433FB9404BF0C07E4D797A813F29914B944`.
The corrected-French body is 70,332 B / SHA-256
`FBBB53F8C5E731704C9D1955FD18466C72B4C4F72A51DA111CC7863697D43716`;
the correction register is 48,411 B / SHA-256
`74F86DE006382734733D0A2FA1872F3674CF9ACE78447845642D717275214E8F`.
The admission log is 15,131 B / SHA-256
`A4D51A0B722B9529D9EE21974952AE128D75307188CB7725865D27DC51394834`,
and the source-defect register is 13,107 B / SHA-256
`EF342556A7EE6E450F1D4C9FAFC7C73343C6FFD2C3B28B6CA570BDB572CBCE4E`.

Three pdfLaTeX passes produce the corrected-French verification reader at
201 A4 pages / 1,379,867 B / SHA-256
`E50CF28CE9A47B44A951FC729C8144D1E0AC3AD0BADFB1BE5C61CD2B392AD045`;
pass 2 and pass 3 are byte-identical with SHA-256
`22D7274EF01E72AB8667FD3F2AE13961447E75A47EF2D2C890401846D72249A3`.
Its 40,685 B log has SHA-256
`71E16759BCC593119A293C2C72C6E82CAE476517D652DAF8F123A311DD13F620`;
only the two inherited Exposé-XVII overfull diagnostics remain.  Corrected-
French pages 196--197 pass lead 600-dpi review.

Exact next translation and diplomatic-admission cursor: §5.5, scan index 399
/ folio 392, `authority_snapshot/source/expose_XXI_body.tex` line 831.

## Exposé XXI §§5.5--5.6 through EOF — 2026-08-02

Exposé XXI is now translated and source-checked continuously through its end.
The admitted range is authority-source lines 831--1053, scan indices 399--408 /
folios 392--401.  Authority pages were personally inspected at 1100 dpi;
targeted source crops resolved underlines and diagram details, and all three
§5.6 diagrams were compared node-by-node, edge-by-edge, label-by-label, and for
terminal punctuation at approximately 5000-dpi-equivalent detail.

Section 5.5 exposed one genuine inherited French transcription deviation: the
underlines on the sheaf $G$ and cohomology $H$ in Theorem 5.5.2 had been lost.
Both French layers now restore them.  The diplomatic French preserves three
printed-source peculiarities while corrected French and English use the
mathematically coherent readings: $c_k\in\log\sigma\mathbf Z$, the reference
to Theorem 5.2.2 rather than the circular 5.5.2, and the desired assertion (iv)
for $U$ rather than another invocation of 5.2.2.  Dispositions
SGA7II-FR-XXI-036 through -039 record the exact split.

Section 5.6 exposed two genuine inherited French transcription deviations:
the factorization diagram's $j$ label was on the wrong side of its horizontal
hook arrow, and the printed Fraktur Galois group had been normalized to
calligraphic $\mathcal G$.  Both French layers restore the authority geometry
and all three Fraktur occurrences.  Corrected French and English also repair
the printed accent in `diffère`, pluralize `morphismes`, write $f\circ j$,
remove the period/colon collision before hypothesis (*), and expand the
shortened locator to Lemma 5.6.2(i).  Dispositions SGA7II-FR-XXI-040 through
-043 record these interventions without altering the diplomatic readings of
the printed typos.

English components 161 and 162 are respectively 6,222 B / SHA-256
`4DB88480602DC3AD01245A38F4646220505380F5CC76BF029E472E1732A280A8`
and 6,701 B / SHA-256
`F50B948A1960A5C7AEA59699BAB5FBA1EA63629F6CCE5A8FF50FD7695E4EE8EA`.
The current cumulative master is 10,681 B / SHA-256
`FC9BCECD27A1AFC5A48CADC8E33D941FAAC0A568238590C8BE36728DA6BDBA81`.

The §5.5 checkpoint builds in three XeLaTeX passes to 233 A4 pages /
1,189,100 B / SHA-256
`B4210738FA99B251DFC0600ED450D1EDCD26F89AEF5423F3E9CF48C6B594D7DC`;
pass 2 and pass 3 are byte-identical with SHA-256
`CC12CEEFD9B99F3E80A3E836A50E80F1135E2D422C33CB8326184788DBCDFF7B`.
Its 39,989 B log has SHA-256
`3F5488DB42EF06CA246698C57FD5BAE432B77AFF87647CED61E5E3F61C5C5401`.
Final Exposé-XXI r1 builds in three passes to 235 A4 pages / 1,198,343 B /
SHA-256
`6CA36419DB4E8087DAA8FB563B0B5B9B0E9EEDFE0EB625D4003B7D58DD1C7D52`;
pass 2 and pass 3 are byte-identical with SHA-256
`4355941039B8D78029DF8DCCC508E91CED0DF3FDDCFA3CAA072D5D897C45CA5B`.
Its 40,012 B log has zero critical, overfull, or missing-character diagnostics
and SHA-256
`203357BEC3128FCE0DE81A8D3D636BE7042DAA7737DDB89F849447B30FE05820`.
English pages 231--235 pass the successive final 600-dpi layout reviews.

The current diplomatic Exposé-XXI body is 70,220 B / SHA-256
`06A9F91FC6327147A5F92E8B3CFBEF8F79578BAB55EAC5A7D9857E2D39A456E1`.
The corrected body is 70,389 B / SHA-256
`309F5CB9C69D43AA8FC1A81FBC204C34A308B93EE0E1509E8E58279FDB1A4C10`;
the 50,471 B correction register has SHA-256
`AE00A0485D9577B668567C556B55B5EE9D0B6A361483DA144C743F07A5641AB9`.
The diplomatic admission log is 16,969 B / SHA-256
`2AD24CEF765941F30C8C9B300425F2E46751DA78E441DE1D2951CCEF36B24E47`,
and its 15,298 B source-defect register has SHA-256
`CDC08C6F5C550084A713FB4D6EB485A506FE817C867DC82A7B5A17B01BB15AD7`.

The corrected-French §5.5 reader is 201 A4 pages / 1,379,903 B / SHA-256
`AD5ED514DEC9652F375F9E72868E6BF301334DFFBC69838A94B010596E2CFD84`;
pass 2/pass 3 SHA-256 is
`AF50E01AE1FCAE37EB3BF71C68EACB8F6A016AC285899E83ECAE149B84CF6D04`.
The final Exposé-XXI corrected-French reader is 201 A4 pages / 1,379,889 B /
SHA-256
`7FB00AD7000FB4F5B816A6F221CBFA76F9E997C80982C369B737DAB0FB129F20`;
pass 2 and pass 3 are byte-identical with SHA-256
`30488AB20F1851C4557DF35F4A8CEAB2AA812A60E7AC750CDFFBCCB56CFFFC00`.
Its 40,691 B log has SHA-256
`A21E19E0826B3A8D66EA45E3B92016EC9001AB34B45E22EB3B049DC9270CE8A9`;
only the two inherited Exposé-XVII overfull diagnostics remain.  Corrected-
French pages 198--201 pass the successive 600-dpi layout reviews.

Exact next English, diplomatic-French, and corrected-French cursor: Exposé
XXII opening, scan index 409 / folio 402.  The remaining authority range is
indices 409--445 (37 pages) through the end of SGA 7 II; there is no frozen
Exposé-XXII TeX body, so it must be personally transcribed from `Number12.pdf`
before and while it is translated.

## Exposé XXII through §3 — 2026-08-02

English, diplomatic French, and corrected French now cover scan indices
408--421 / folios 401--414 continuously through the end of §3.  The authority
pages were personally read at 1100 dpi, with targeted higher-detail crops for
ambiguous operators, Frobenius notation, and formula locators.

The latest tranche, indices 417--421 / folios 410--414, adds English
components 167 and 168.  They are 3,441 B / SHA-256
`113E61D8571993EFB39EF14906CF33E2C2C78C8A483C4F9F36B32F967C0C00BE`
and 4,668 B / SHA-256
`0FFD422C0FD5F999BE2DA218EDB275DB517AD24411091CE86691C9C5D763F581`.
The cumulative master is 11,129 B / SHA-256
`F3F1488DA4FFF15D27797D161987A919B2E3A821E55B4D392C03BAF886AFA075`.

The diplomatic layer retains the printed broken §3 locators and indices.
Corrected French and English use (3.1.2), (3.2.1)--(3.2.2), (3.3.1),
$(\mathrm{fr}_q^X)^*$, positive form degree $p\ne0$, and (3.4.1), as the
surrounding statements and proofs require.  Dispositions
SGA7II-FR-XXII-008 through -010 record the exact split.

The English reader builds in three passes to 245 A4 pages / 1,721,311 B /
SHA-256
`CADA3AB952A4A41EEEFCB5F3BD46A6C991160CB12E56442E6BBB1DA1A96A420A`.
Its 46,596 B log has SHA-256
`C1DE73D95B7AEAC8184722FDD6E268F5C27747EFA69AE3EADF35741324B2174E`;
pass-2/pass-3 console SHA-256 is
`91CF1CF026A98957737170F631280E4421EFAB71809B267B754413D80035F49B`,
with zero critical, overfull, missing-character, or rerun diagnostics.
English pages 240--245 pass personal 600-dpi review.

The corrected-French reader builds in three passes to 209 A4 pages /
1,418,669 B / SHA-256
`9620AD73ABAEBEAEE63A2602BF0F9C0F565F8067993ACE048F1117E6BC84DF74`.
Its 41,303 B log has SHA-256
`257B4C1C7C20493C40FBDA7B8253B004F5DDD6FDCFDD7B983980E4A3F428DE28`;
only the two inherited Exposé-XVII overfull diagnostics remain.  Corrected-
French pages 204--209 pass personal 600-dpi review.

Exact live cursor: Exposé XXII §4, scan index 422 / folio 415.

## Complete SGA 7 II bilingual local reader state — 2026-08-02

The translation and both French source layers now run continuously through
Exposé XXII §6.3, its complete bibliography, scan index 445, and volume EOF.
Together with the admitted predecessor this closes scan indices 8--445:
438/438 SGA 7 II body pages, Exposés X--XXII.  The exact next cursor is EOF;
there is no untranslated or untranscribed Tome-II continuation.

The English master 'source\SGA7_II_English_source_first_workpass.tex' is
12,130 B, SHA-256
'CE309601EB26AF0B83656C8CCD57D739761A553EC567104E03CCAA9C6D2A6588'.
It binds 183/183 unique numbered components, with zero missing inputs and zero
duplicate inputs.  The retained three-pass r3 reader is
'build\c183_expose_XXII_complete_r3\SGA7_II_English_source_first_workpass.pdf':
264 A4 pages / 1,785,484 B / SHA-256
'930446AC789F5B67C7093C02D5604AFB5A4ED1E0554B1A25CC7EEF633C9F0960'.
The 47,116 B final log has SHA-256
'8D9434E616374119643F0ADB3A31E82C455F4FAF562CED77FC83A82D1097C413';
pass 2 and pass 3 console logs are byte-identical at SHA-256
'D4CB4A12074932A2782B7D7393F36041F3099596169C52FBD4463202BCD7E7EE'.
No critical, overfull, missing-character, undefined-reference, fatal, or rerun
diagnostic is present.  The final r3 correction changes the §6 calculation
from the erroneous modulus p\mathcal O[[t]] to the source-controlled
\pi\mathcal O[[t]]; English page 258 was freshly rendered at 600 dpi and
personally checked after the rebuild.

The diplomatic French master binds 13/13 unique Exposé bodies with zero
missing inputs and preserves the printed readings while repairing only
source-to-TeX deviations.  Its complete reader is
'french_source_diplomatic_canon\build_check_exposeXXII_complete_pdflatex_r2\
SGA7II_French_Source_Transcription_Working_X-XXI_Partial_20260731.pdf':
227 A4 pages / 1,505,168 B / SHA-256
'C5FD43DF4A58BF860115D0D48F284FA9059B952CCCDC387266456D2E1A3F7AAD'.
Its pass-2/pass-3 console logs are byte-identical at SHA-256
'53B6830183FA7EF9444A25A1594679B8C39DCF84FC84F8759C821AEC836CFC5D'.

The corrected French master likewise binds 13/13 unique bodies with zero
missing inputs.  Its complete reader is
'french_source_corrected_workpass\build_check_exposeXXII_complete_pdflatex_r1\
SGA7II_French_Source_Transcription_Working_X-XXI_Partial_20260731.pdf':
227 A4 pages / 1,506,305 B / SHA-256
'C5FD45E9127603EC6E347C7AB7DFD77AF17DB0176F5DEAF5F59553752F96D513'.
Its 41,145 B log has SHA-256
'8727952C4AA5419853A03E362F45B66D22B4FA1645FAE56DAF2A84C6AC1A426C';
pass 2 and pass 3 console logs are byte-identical at SHA-256
'A55CD7C1E8D3CFABD8B0AB113F254EDAD970DE1C62A71A345B6D5206DFC90388'.
The correction register contains 254 unique stable dispositions through
SGA7II-FR-XXII-028.

Corrected-French terminal pages 217--227 and every changed diplomatic counterpart
were rendered at 600 dpi and personally reviewed.  Unchanged diplomatic pages
were pixel-compared to the already reviewed corrected pages.  Formula blocks,
underlines, diagrams, bibliography, terminal page, and footers are legible and
unclipped.  The apparent truncation of odd footer numbers in whole-page viewer
previews was disproved by direct 600-dpi footer crops.

This is local bilingual source/translation completion and build/render closure.
It is not a publication, archive-upload, or exhaustive reference-v2 claim.
Per Floris's final archival decision, the French TeX and bounded/per-volume
French witnesses are retained archivally; no omnibus public French PDF is
implied.  The cumulative public-facing reader may remain English.
