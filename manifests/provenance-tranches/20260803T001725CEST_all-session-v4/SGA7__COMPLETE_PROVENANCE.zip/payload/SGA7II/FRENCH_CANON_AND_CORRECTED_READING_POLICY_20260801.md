# SGA 7 French canon and corrected-reading policy — 2026-08-01

This control records Floris's EGA instruction as the analogous rule for SGA.
The controlling EGA note was supplied in
`<REDACTED_USER_HOME>\<REDACTED_CODEX_STATE>\attachments\<REDACTED_TASK_ID>\pasted-text.txt`.

1. The French canon is a diplomatic, source-faithful TeX transcription of the
   bounded printed authority. It preserves printed wording, notation, order,
   and genuine printed peculiarities. Suspected printed typos are not silently
   rewritten in that canonical body; they are catalogued externally.
2. Transcription errors are not part of the canon. When the TeX witness differs
   from the scan, the canonical French transcription is repaired to the scan.
3. The separate corrected French workpass is an editorial reading layer. It may
   repair a genuine printed mathematical or linguistic defect when the scan,
   context, and mathematics justify the reading, but every such intervention
   remains explicit in `french_source_corrected_workpass/CORRECTIONS.md`.
4. The English translation is synchronized to the corrected reading while
   remaining traceable to the printed French authority. Every English
   source-level intervention is rechecked against the scan; unsupported
   interventions must be reversed rather than defended by the English text.
5. Individual French verification PDFs are legitimate archival/build controls.
   A cumulative English SGA reader remains an intended deliverable. No public
   omnibus French PDF is implied by this task unless Floris later requests it.
   The archival French deliverable is therefore the diplomatic TeX plus its
   bounded source/verification identities, not an editorially rewritten French
   omnibus.
6. The inherited `authority_snapshot` stays immutable as provenance. It is not
   automatically the finished diplomatic canon because inherited transcription
   errors may remain. The finished diplomatic French TeX must be a separate
   no-overwrite layer.

This policy changes no active translation cursor and creates no archive or
publication authorization.
