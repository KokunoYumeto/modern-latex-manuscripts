# SGA 7 I source-language layer policy

The frozen transcription at
`<REDACTED_LOCAL_ROOT>/w\e620\sources\sga\sga7i-fresh-transcription-exposes-i-ii-vi-vii-viii-ix-working-20260731`
is immutable input.

This successor maintains two separate source-language layers:

- `french_source_diplomatic_canon`: a source-faithful archival TeX layer. It changes only scan-established source-to-TeX transcription deviations. Printed source peculiarities and typos remain as printed.
- `french_source_corrected_workpass`: a corrected-reading TeX layer. It contains the same transcription repairs and also the source-established mathematical, notation, and cross-reference emendations already used transparently in the English reader.

Exposé VI was published in English. It remains part of both source-language readers in its original language; its already source-aligned English component tree is the controlling corrected rendering until a later self-contained source-language integration is made.

The public-facing cumulative translation is English. These French/source-language readers are bounded archival and scholarly controls; they do not imply that an omnibus public French redistribution is required.

Authority-image review uses the smallest resolution that decides the reading: approximately 1,100 dpi for ordinary text, 5,000 dpi for small formula or diagram details, and up to 9,000 dpi only when genuine ambiguity remains. Existing lower-resolution evidence remains historical context but cannot decide an unresolved small glyph.

All edits are recorded append-only in `FRENCH_SOURCE_CORRECTION_LOGBOOK.md`. A successful compile is only a build check, not proof of source fidelity.
