"""Deterministically propagate the reviewed Expose IX French dispositions.

The diplomatic layer receives only scan-established transcription repairs.
The corrected layer receives those repairs plus the source-defect corrections
already adopted in the source-aligned English reader.  Every replacement is
literal and count-checked; the script aborts before writing if any precondition
does not hold.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FILES = {
    "diplomatic": ROOT / "french_source_diplomatic_canon/source/expose_IX_body.tex",
    "corrected": ROOT / "french_source_corrected_workpass/source/expose_IX_body.tex",
}


@dataclass(frozen=True)
class Edit:
    eid: str
    layers: tuple[str, ...]
    old: str
    new: str
    count: int = 1


BOTH = ("diplomatic", "corrected")
CORR = ("corrected",)


EDITS = [
    # Scan-established transcription deviations: both layers.
    Edit("IX-TR-001", BOTH, "$t \\in T$ \\underline{une g\u00e9n\u00e9risation de} $s$", "$t \\in S$ \\underline{une g\u00e9n\u00e9risation de} $s$"),
    Edit("IX-TR-002", BOTH, "le caract\u00e8re de la repr\u00e9sentation de $I$ dans $\\check{L}$", "le caract\u00e8re de la repr\u00e9sentation de $\\Gamma$ dans $\\check{L}$"),
    Edit("IX-TR-003", BOTH, "T_\\ell(\\Lambda^{\\mathrm{o}})^t", "T_\\ell(A^{\\mathrm{o}})^t"),
    Edit("IX-TR-004", BOTH, "$T_\\ell(A_K)$ \\underline{et} $T_\\ell(A_{K'})$", "$T_\\ell(A_K)$ \\underline{et} $T_\\ell(A'_K)$"),
    Edit("IX-TR-005", BOTH, "$\\Lambda'_K$", "$A'_K$"),
    Edit("IX-TR-006", BOTH, "${}_{p^{\\overline{\\infty}}}A_K$", "${}_{p^\\infty}A_K$"),
    Edit("IX-TR-007", BOTH, "$= {}_{p^N}A_o^o$ pour $N$ grand", "$= p^N A_o^o$ pour $N$ grand"),
    Edit("IX-TR-008", BOTH, "T_p(A'_k)^{ef}", "T_p(A'_{K'})^{ef}", count=1),
    Edit("IX-TR-009", BOTH, "T_p(A'_k)^{et}", "T_p(A'_{K'})^{et}", count=1),
    Edit("IX-TR-010", BOTH, "sur le normalis\u00e9 $S'$ de $S$ dans $K$", "sur le normalis\u00e9 $S'$ de $S$ dans $K'$"),
    Edit("IX-TR-011", BOTH, "une fonction trace sur $\\pi^!$", "une fonction trace sur $\\pi'$"),
    Edit("IX-TR-012", BOTH, "$A_K \\longrightarrow A_{K'}$", "$A_K \\longrightarrow A'_K$"),
    Edit("IX-TR-013", BOTH, "($u \\in U$, $g \\in I$)", "($x \\in U$, $g \\in I$)"),
    Edit("IX-TR-014", BOTH, "T_{\\ell}(T_o(\\overline{k}))", "T_{\\ell}(T'_o(\\overline{k}))"),
    Edit("IX-TR-015", BOTH, "\\longrightarrow \\wedge_s", "\\longrightarrow \\Lambda_s"),
    Edit("IX-TR-016", BOTH, "$\\underline{F}$ est cohomologiquement plat", "$\\underline{f}$ est cohomologiquement plat"),
    Edit("IX-TR-017", BOTH, "\\varphi_{\\lambda_{\\lambda}}", "\\varphi_{y_{\\lambda}}", count=2),
    Edit("IX-TR-018", BOTH, "T_\\ell(A_{\\overline{\\eta}})^{\\vee}", "T_\\ell(A_{\\overline{\\eta}})"),
    Edit("IX-TR-019", BOTH, "A[K']_o , A[K']_o^o", "A[K']_o/A[K']_o^o"),
    Edit("IX-TR-020", BOTH, "\\Psi[K'](\\ell)", "\\Phi[K'](\\ell)"),
    Edit("IX-TR-021", BOTH, "\\widetilde{C}_i \\times_C \\widetilde{C}_1", "\\widetilde{C}_i \\times_C \\widetilde{C}_i"),
    Edit("IX-TR-022", BOTH, "(U/V)^{\\vee} \\otimes V^{1}", "(U/V)^{\\vee} \\otimes V^{\\perp}"),
    Edit("IX-TR-023", BOTH, "T_{\\ell}(T_o)(\\overline{k}))", "T_{\\ell}(T_o)(\\overline{k})"),
    Edit("IX-TR-024", BOTH, "T_{\\ell}(T'_o(\\overline{k}))", "T_{\\ell}(T'_o)(\\overline{k})"),

    # Source/print defects already adjudicated in the English: corrected only.
    Edit("IX-SRC-001", CORR, "sa fibre sp\u00e9ciale $A_o$ .", "sa fibre sp\u00e9ciale $A'_o$ ."),
    Edit("IX-SRC-002", CORR, "(cf. 1.5.5)", "(cf. 2.1.5)"),
    Edit("IX-SRC-003", CORR, "l'\u00e9galit\u00e9 annonc\u00e9e (6.2.5.1)", "l'\u00e9galit\u00e9 annonc\u00e9e (2.2.5.1)"),
    Edit("IX-SRC-004", CORR, "sous le groupe d'inertie $I$ (1.6.5)", "sous le groupe d'inertie $I$ (2.2.5)"),
    Edit("IX-SRC-005", CORR, "T_{\\ell}(T_{o}) \\times T_{\\ell}(A_{o}^{\\,o})", "T_{\\ell}(T_{o}) \\times T_{\\ell}(A_{o}^{\\prime\\,o})"),
    Edit("IX-SRC-006", CORR, "l'inclusion d\u00e9j\u00e0 obtenue (1.10)", "l'inclusion d\u00e9j\u00e0 obtenue (2.4.7)"),
    Edit("IX-SRC-007", CORR, "V \\subset V^{\\perp}", "V^{\\perp} \\subset V", count=1),
    Edit("IX-SRC-008", CORR, "$I$ op\u00e8re trivialement sur $U^{I} = V$", "$I$ op\u00e8re trivialement sur $U/U^{I}=U/V$"),
    Edit("IX-SRC-009", CORR, "pour prouver que (v) implique (vi)", "pour prouver que (vi) implique (iv)"),
    Edit("IX-SRC-010", CORR, "(*) Le cas $\\ell \\neq p$ sera \u00e9tudi\u00e9", "(*) Le cas $\\ell = p$ sera \u00e9tudi\u00e9"),
    Edit("IX-SRC-011", CORR, "r\u00e9duction semi-stable (4.5)", "r\u00e9duction semi-stable (3.5)", count=1),
    Edit("IX-SRC-013", CORR, "quotient de $\\mathbb{Z}[T]/(T^{p^N}-1)$", "quotient de $\\mathbb{Z}[T]/((1-nT)^{p^N}-1)$"),
    Edit("IX-SRC-014", CORR, "une racine primitive $p^n$-\u00e8me de l'unit\u00e9 $u$", "une racine primitive $p^m$-\u00e8me de l'unit\u00e9 $u$"),
    Edit("IX-SRC-015", CORR, "$A_K$ \\underline{un sch\u00e9ma ab\u00e9lien sur} $S$ \\underline{ayant une r\u00e9duction semi-stable sur} $S$", "$A_K$ \\underline{un sch\u00e9ma ab\u00e9lien sur} $K$ \\underline{ayant une r\u00e9duction semi-stable sur} $S$"),
    Edit("IX-SRC-016", CORR, "$A_K = \\prod_{K'/K} A'_{K'}/K'$ est simple sur $K'$", "$A_K = \\prod_{K'/K} A'_{K'}/K'$ est simple sur $K$"),
    Edit("IX-SRC-017", CORR, "une extension quadratique ramifi\u00e9e de $S$", "une extension quadratique ramifi\u00e9e de $K$"),
    Edit("IX-SRC-018", CORR, "au sens pr\u00e9cis\u00e9 dans 6.5", "au sens pr\u00e9cis\u00e9 dans 5.12"),
    Edit("IX-SRC-019", CORR, "une polarisation de $A_K$, d'o\u00f9 une isog\u00e9nie $A_K \\longrightarrow A'_K$", "une polarisation de $A_K$, d'o\u00f9 une isog\u00e9nie $A_K \\longrightarrow A'_K$"),
    Edit("IX-SRC-020", CORR, "deux extensions isomorphes $K'$, $K'_1$ de $K'$", "deux extensions isomorphes $K'$, $K'_1$ de $K$"),
    Edit("IX-SRC-022A", CORR, "un Module inversible ample $\\underline{M}$ de $G$", "un Module inversible ample $\\underline{L}$ sur $A$"),
    Edit("IX-SRC-022B", CORR, "restriction $\\underline{L}_n$ de $\\underline{L}$ \u00e0 $G_n$", "restriction $\\underline{L}_n$ de $\\underline{L}$ \u00e0 $A_n$"),
    Edit("IX-SRC-023A", CORR, "$\\mathrm{Specf}(A)$", "$\\mathrm{Specf}(V)$"),
    Edit("IX-SRC-023B", CORR, "$\\hat{S} = \\mathrm{Specf}(A)$", "$\\hat{S} = \\mathrm{Specf}(V)$"),
    Edit("IX-SRC-023C", CORR, "$S_n = \\mathrm{Spec}(A/\\underline{m}^{n+1})$", "$S_n = \\mathrm{Spec}(V/\\underline{m}^{n+1})$"),
    Edit("IX-SRC-024A", CORR, "sch\u00e9ma en groupes fini $\\Phi_{o}$ sur $S$", "sch\u00e9ma en groupes fini $\\Phi_{o}$ sur $S_o$"),
    Edit("IX-SRC-024B", CORR, "groupes $\\Phi_{n}$ finis sur $S$", "groupes $\\Phi_{n}$ finis sur $S_n$"),
    Edit("IX-SRC-025", CORR, "X^o/X^1 \\xrightarrow{\\ \\sim\\ } P \\quad , \\quad X^1/X^2 \\xrightarrow{\\ \\sim\\ } R, \\quad X^2/X^3 = X^2 \\xrightarrow{\\ \\sim\\ } Q", "X^o/X^1 \\xrightarrow{\\ \\sim\\ } Q \\quad , \\quad X^1/X^2 \\xrightarrow{\\ \\sim\\ } R, \\quad X^2/X^3 = X^2 \\xrightarrow{\\ \\sim\\ } P"),
    Edit("IX-SRC-026A", CORR, "\\widetilde{\\overline{X}} \\simeq F", "\\widetilde{\\overline{X}} \\simeq E"),
    Edit("IX-SRC-026B", CORR, "\\widetilde{X}' \\simeq F", "\\widetilde{X}' \\simeq E"),
    Edit("IX-SRC-027", CORR, "reste \u00e0 prouver d)", "reste \u00e0 prouver c)"),
    Edit("IX-SRC-028", CORR, "\\mathrm{Ext}^2(R,Q)", "\\mathrm{Ext}^2(Q,P)", count=1),
    Edit("IX-SRC-029", CORR, "\\mathrm{EXT}(Q',P') \\times \\mathrm{EXTPAN}(E',F') \\arrow[r, \"\\omega\"]", "\\mathrm{EXT}(Q',P') \\times \\mathrm{EXTPAN}(E',F') \\arrow[r, \"\\omega'\"]"),
    Edit("IX-SRC-030", CORR, "c_X(Y)", "c_X(Y')", count=1),
    Edit("IX-SRC-031", CORR, "\\underline{\\mathrm{Hom}}(P,Q) = D(Q \\otimes Q^*)", "\\underline{\\mathrm{Hom}}(Q,P) = D(Q \\otimes Q^*)"),
    Edit("IX-SRC-032A", CORR, "\\mathrm{Ext}^1_\\Lambda(P,Q)", "\\mathrm{Ext}^1_\\Lambda(Q,P)"),
    Edit("IX-SRC-032B", CORR, "\\mathrm{Ext}^1_\\Lambda(P_\\eta\\ ,\\ Q_\\eta)", "\\mathrm{Ext}^1_\\Lambda(Q_\\eta\\ ,\\ P_\\eta)"),
    Edit("IX-SRC-033", CORR, "(9.4.6.2)", "(9.4.7.2)"),
    Edit("IX-SRC-034", CORR, "cons\u00e9quence imm\u00e9diate de 9.4.6", "cons\u00e9quence imm\u00e9diate de 9.4.7", count=1),
    Edit("IX-SRC-035", CORR, "se prolonge en un groupe de Barsotti-Tate $X_\\eta$ sur $S$", "se prolonge en un groupe de Barsotti-Tate $X$ sur $S$"),
    Edit("IX-SRC-036", CORR, "$Q(n)$ est \u00e9tale sur $n$", "$Q(n)$ est \u00e9tale sur $S$"),
    Edit("IX-SRC-037", CORR, "l'homomorphisme (9.5.6)", "l'homomorphisme (9.5.5)", count=1),
    Edit("IX-SRC-038", CORR, "X_\\eta/X^2_\\eta \\simeq F_\\eta = D(F'_\\eta)", "X_\\eta/X^2_\\eta \\simeq E_\\eta = D(F'_\\eta)"),
    Edit("IX-SRC-039", CORR, "un accouplement (9.5.6)", "un accouplement (9.5.5)", count=1),
    Edit("IX-SRC-040", CORR, "$X_\\eta = T_\\ell(A_K)$ sur $S$", "$X_\\eta = T_\\ell(A_K)$ sur $\\eta$"),
    Edit("IX-SRC-041", CORR, "monodromie (9.2.1)", "monodromie (9.1.2)"),
    Edit("IX-SRC-042", CORR, "(10.3.3)", "(10.3.4)", count=1),
    Edit("IX-SRC-043", CORR, "$\\bar{A}_K$ sur $k$", "$\\bar{A}_K$ sur $K$"),
    Edit("IX-SRC-044", CORR, "courbe propre, lisse et g\u00e9om\u00e9trique connexe $X_K$ sur $X$", "courbe propre, lisse et g\u00e9om\u00e9trique connexe $X_K$ sur $K$"),
    Edit("IX-SRC-045", CORR, "Comme dans 11.4", "Comme dans 11.3", count=1),
    Edit("IX-SRC-046", CORR, "fibre g\u00e9n\u00e9rique de (11.7.5)", "fibre g\u00e9n\u00e9rique de (11.6.5)"),
    Edit("IX-SRC-047", CORR, "Il r\u00e9sulte alors imm\u00e9diatement de 9.4.6", "Il r\u00e9sulte alors imm\u00e9diatement de 9.4.7"),
    Edit("IX-SRC-048", CORR, "sous-groupe extension de $K_n$ par $R_n$", "sous-groupe extension de $K'_n$ par $R_n$"),
    Edit("IX-SRC-049", CORR, "La construction faite dans 11.7", "La construction faite dans 11.6"),
    Edit("IX-SRC-049A", CORR, "\\Phi(\\ell) = V/M_{\\ell} \\quad , \\quad \\Phi'(\\ell) = V/\\check{M}'_{\\ell}", "M_{\\ell}\\otimes D_{\\ell}=V/M_{\\ell} \\quad , \\quad \\check{M}'_{\\ell}\\otimes D_{\\ell}=V/\\check{M}'_{\\ell}"),
    Edit("IX-SRC-050", CORR, "$\\underline{O}_X(X_o^i)$ \\underline{sur} $S$", "$\\underline{O}_X(X_o^i)$ \\underline{sur} $X$"),
    Edit("IX-SRC-051", CORR, "\\underline{\\mathrm{Pic}}^o_{X/k}", "\\underline{\\mathrm{Pic}}^o_{C/k}", count=1),
    Edit("IX-SRC-052", CORR, "\\tag{12.2.3}", "\\tag{12.3.3}"),
    Edit("IX-SRC-053", CORR, "\\tag{12.2.4}", "\\tag{12.3.4}"),
    Edit("IX-SRC-054", CORR, "\\mathbb{Z}^{(\\Gamma)}", "\\mathbb{Z}^{(\\Gamma_1)}", count=1),
    Edit("IX-SRC-054A", CORR, "\\begin{equation*}\nH_1(\\Gamma(C),\\mathbb{Z}\\ ) \\longrightarrow M \\qquad ,\n\\end{equation*}", "\\begin{equation}\\tag{12.3.8}\nH_1(\\Gamma(C),\\mathbb{Z}\\ ) \\longrightarrow M \\qquad ,\n\\end{equation}"),
    Edit("IX-SRC-055", CORR, "$T_\\ell(B_U)$", "$T_\\ell(P_U)$", count=1),
    Edit("IX-SRC-055A", CORR, "\\underline{\\mathrm{Hom}}(M,T_\\ell(\\mathbb{G}_{m\\underline{S}}) &", "\\underline{\\mathrm{Hom}}(M,T_\\ell(\\mathbb{G}_{m\\underline{S}})) &"),
    Edit("IX-SRC-056", CORR, "si et seulement si $x$ est \\underline{r\u00e9gulier}", "si et seulement si $X$ est \\underline{r\u00e9gulier}"),
    Edit("IX-SRC-057", CORR, "point maximal de $D$", "point maximal de $D_\\lambda$"),
    Edit("IX-SRC-058", CORR, "X \\times_{\\underline{S}} \\underline{S}^\\lambda", "\\underline{X} \\times_{\\underline{S}} \\underline{S}^\\lambda"),
    Edit("IX-SRC-059", CORR, "$\\underline{S}$ est un trait de \\underline{caract\u00e9ristique nulle}", "$\\underline{S}^\\lambda$ est un trait de \\underline{caract\u00e9ristique nulle}"),
    Edit("IX-SRC-060", CORR, "conditions} a), b), c) \\underline{de} 13.2.2", "conditions} a), b), c) \\underline{de} 13.2.1"),
    Edit("IX-SRC-061", CORR, "$A = A_o$", "$A = A^o$", count=1),
    Edit("IX-SRC-062", CORR, "$B = A^\\natural/T$ est un quotient de $A$", "$B = A^\\natural/T$ est un quotient de $A^\\natural$"),
    Edit("IX-SRC-063", CORR, "$B_{\\hat{\\underline{O}}}$ est projectif sur $S$", "$B_{\\hat{\\underline{O}}}$ est projectif sur $\\hat{\\underline{O}}$"),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    payloads = {name: path.read_bytes().decode("utf-8") for name, path in FILES.items()}
    failures: list[str] = []
    applied: list[tuple[str, str, int]] = []

    for edit in EDITS:
        for layer in edit.layers:
            actual = payloads[layer].count(edit.old)
            if actual != edit.count:
                failures.append(f"{edit.eid}:{layer}: expected {edit.count}, found {actual}")
                continue
            payloads[layer] = payloads[layer].replace(edit.old, edit.new, edit.count)
            applied.append((edit.eid, layer, actual))

    if failures:
        raise SystemExit("Precondition failure(s):\n" + "\n".join(failures))

    if args.apply:
        for name, path in FILES.items():
            path.write_bytes(payloads[name].encode("utf-8"))

    mode = "APPLIED" if args.apply else "DRY-RUN"
    print(f"{mode}: {len(applied)} layer-edits from {len(EDITS)} dispositions; errors=0")
    for eid, layer, count in applied:
        print(f"{eid},{layer},{count}")


if __name__ == "__main__":
    main()
