# SGA 7 I English translation status

## Durable objective

Produce a cumulative English TeX and PDF for all written expos\'es of SGA 7 I (I, II, VI, VII, VIII, IX), then continue with the separately frozen SGA 7 II allocation. This root is a no-overwrite working successor.

## Adopted Codex scholarly portfolio

SGA 7 I and II, Serre's FAC and GAGA, and later in-scope works by the same authors are adopted into the Codex source-first workflow. SGA 7 is the active production priority. The explicit post-SGA7 queue for this lane is FAC first, then GAGA. FAC and GAGA remain preserved complete-coverage working transcriptions and enter that later page-level source-audit/translation queue; their clean builds do not constitute fidelity certification. Additional works enter only after an exact authority witness and non-overlapping scope are frozen.

## Authority and controls

- French working transcription root: `<REDACTED_LOCAL_ROOT>/w\e620\sources\sga\sga7i-fresh-transcription-exposes-i-ii-vi-vii-viii-ix-working-20260731`.
- Frozen French master SHA-256: `7B7394BEAF970AC724EFDE80C841B2DAACC28D64E3145538A39AA2FA915BF355`.
- Controlling scan: `<REDACTED_USER_HOME>\Documents\Papors\OS\Groupes de monodromie en g\'eom\'etrie alg\'ebrique (Grothendieck, A. (Alexandre)).pdf`.
- Scan SHA-256: `9CD40FF06EB1E488AF385A56899D4F492492A06A1E2E3C0ED6876B82E3E3603F`.
- Current allocation control SHA-256: `8148E6E16FBCC19AD3AB089C70DCB0397AE117D9432DFE64A5E204594D44C550`.

The French package proves complete 528/528 page-marker coverage and a stable 267-page build. Its own documentation classifies it as a complete working transcription, not a critical or mathematical certification. Documented audit evidence includes two whole pages compared line by line, targeted high-detail diagram/glyph checks, and representative visual QA on 17 final reader pages; it is not an exhaustive 528-page source audit. The scan therefore decides consequential ambiguities during translation.

## Inherited English disposition

`inherited\SGA7_I_clean_cumulative_translation_inherited_through_IX_6_6.tex` is preserved as comparison material only. Its Expos\'e IX structure does not cleanly match the fresh French transcription (the authority proceeds from 6.4 to 7), so its filename is not accepted as a source-alignment claim. The active reader is being rebuilt source-first.

The inherited witness is 278,864 bytes, SHA-256 `CFCB4C17081E16F963DCBC3FA04A43C4D4065477CB37BD931233840D287AA2E9`. Its first observed Git appearance is generic mirror commit `cb420190bbc6311cff96a08a5a11a4caf483fdff` (2026-05-29), blob `2ac760f78b6107d2d71bd2e513e5baa4e3be418d`; neither that identity nor the surviving metadata establishes Claude, Codex, another model, or human authorship. Authorship remains unresolved. Direct comparison proves that the text is a synthetic abridgment with altered definitions, omitted proofs, and invented section structure, so only individually source-matched phrases may be reused.

## Active coverage

- Active master: `source\SGA7_I_English_source_first_workpass.tex`.
- Complete: all of Expos\'es I and II, including both bibliographies; scan indices 12--42 / source folios 1--31.
- Expos\'e VI, the originally English contribution by D. S. Rim, is source-aligned in full through Corollary 6.8 and its bibliography/end, authority `source\expose_VI_body.tex` lines 1--3673; scan indices 43--143 / source folios 32--132.
- Expos\'e VII is source-aligned in full through section 3.8 and its bibliography, authority `source\expose_VII_body.tex` lines 5--1977; scan indices 144--228 / source folios 133--217.
- Expos\'e VIII is source-aligned in full through Corollary 7.5 and its bibliography: authority `source\expose_VIII_body.tex` lines 5--2495; scan indices 229--323 / source folios 218--312.
- Expos\'e IX is source-aligned in full through Conjecture 14.4, Remarks 14.5, its complete bibliography, and the terminal publisher matter, authority `source\expose_IX_body.tex` lines 5--5221; scan indices 324--539 / source folios 313--528.
- Total continuous SGA 7 I authority coverage is 528/528 source folios (100%): all six written expos\'es I, II, VI, VII, VIII, and IX, their bibliographies, and the terminal publisher matter. The blank source folio 524 was directly confirmed blank and creates no English text page.
- Exact next cursor in SGA 7 I: EOF. There is no untranslated Tome-I continuation.
- Current master: 12,866 bytes, SHA-256 `8AD83C0E1E5BC0658FFB252D845390E0A36013ACB79475A3907AE541C0AA368A`.
- Current PDF: `build\checkpoint_sga7i_complete_full_volume_r1\SGA7_I_English_source_first_workpass.pdf`, 287 A4 pages, 2,126,411 bytes, SHA-256 `11118DB10640EE6F05428F4C35B18EB58224C91E2F6C2216E6ABDB253F7005D3`.
- SGA 7 I is locally translation-complete and buildable. This is not yet a publication/archive claim or an exhaustive clickable-reference certification.
- SGA 7 II is also locally complete through EOF in the disjoint successor `..\sga7ii_english_complete_translation_successor_20260801_r1`. Its English master SHA-256 is `CE309601EB26AF0B83656C8CCD57D739761A553EC567104E03CCAA9C6D2A6588`; its complete 264-page English PDF SHA-256 is `930446AC789F5B67C7093C02D5604AFB5A4ED1E0554B1A25CC7EEF633C9F0960`. The terminal Exposé-XXII gap was personally transcribed and translated from `Number12.pdf`; the exact next cursor is EOF.

## Retrospective French/source-language closure

- The frozen 2026-07-31 SGA 7 I transcription remains immutable. Two no-overwrite French layers now cover all six Tome-I exposés:
  - `french_source_diplomatic_canon` repairs only scan-established source-to-TeX deviations and retains printed peculiarities;
  - `french_source_corrected_workpass` contains the same transcription repairs plus the source-established mathematical, notation, and cross-reference emendations already used in the English reader.
- Both complete French/source-language readers build in three passes to 267 A4 pages, with byte-identical pass-2/pass-3 console output and no fatal, undefined-reference, missing-character, or rerun diagnostic.
- Diplomatic reader: `french_source_diplomatic_canon\build_full_tomeI_r3\SGA7I_Fresh_Source_Transcription_Complete_Working.pdf`, 2,002,348 bytes, SHA-256 `11512B3A3DDBF5901447E10DC6ACCF0FFD2634D617348ABC3AC7F1F030383528`.
- Corrected reader: `french_source_corrected_workpass\build_full_tomeI_r3\SGA7I_Fresh_Source_Transcription_Complete_Working.pdf`, 2,003,271 bytes, SHA-256 `B3D09A409770CD4D3FF6B58EE5870BBFD1B18C01C5E64B084F07A505D77D76EF`.
- The complete correction record and build/render evidence are in `FRENCH_SOURCE_CORRECTION_LOGBOOK.md`. The exact 19-row source/build identity table is `FRENCH_SOURCE_LAYER_IDENTITIES_20260802.csv`, SHA-256 `9B57A8CB975624A2F8C93EA1ECBA356FBF70822B1055A3F60DF28AE545CCD8CC`, and replays with zero missing/size/hash/formula-safety errors.
- The French layers are bounded archival/scholarly controls. Literal `CONT` page-seam tokens from the frozen diplomatic transcription remain where removing them would silently alter split words, footnotes, or print-page structure. The public-facing cumulative translation remains English; no public omnibus French redistribution is implied.

## Current task boundary

SGA 7 I and II are now locally bilingual-complete through EOF at the source/translation/build/render layer. Remaining reference-v2, cumulative SGA-reader, privacy-clean packaging, archive, and public-readback work are separate post-translation gates. The next translation portfolio item for this lane is FAC, followed by GAGA, before the queued all-SGA reader cleanup.

Build status is recorded in `LOGBOOK.md` after each material edit.
