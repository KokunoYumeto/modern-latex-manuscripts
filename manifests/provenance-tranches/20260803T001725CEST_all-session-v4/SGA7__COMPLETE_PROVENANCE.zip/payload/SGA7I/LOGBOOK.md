# SGA 7 English production logbook

## 2026-07-31 — intake and audit classification

- Froze the complete SGA 7 I French working-transcription identities and controlling scan identity.
- Verified the honest audit boundary: complete page-marker coverage and stable build; two documented line-by-line whole-page comparisons; targeted high-detail diagram/glyph work; 17-page representative final visual QA; no exhaustive full-volume source audit.
- Preserved the inherited English unchanged as comparison-only because its claimed Expos\'e IX endpoint is not structurally source-aligned.
- Recorded exclusive post-Tome-I ownership of SGA 7 II under allocation control SHA-256 `8148E6E16FBCC19AD3AB089C70DCB0397AE117D9432DFE64A5E204594D44C550`.

## 2026-07-31 — English checkpoint 1

- Created the source-first English master.
- Personally translated Expos\'e I source lines 1--54: title, contents, and terminology 0.0.
- Preserved all mathematics and the source page markers for scan indices 12--13.
- Next cursor: source line 57, paragraph 0.1.
- Two-pass PDFLaTeX build: PASS, one page, no fatal error.

## 2026-07-31 — inherited English provenance and quality disposition

- Traced exact SHA-256 `CFCB4C17081E16F963DCBC3FA04A43C4D4065477CB37BD931233840D287AA2E9` to its first observed public-mirror commit `cb420190bbc6311cff96a08a5a11a4caf483fdff` on 2026-05-29.
- The commit uses a generic project service identity; no surviving evidence establishes Claude, Codex, ChatGPT, or human authorship.
- Personally confirmed the first source-anchored mistranslation at inherited lines 567--571 and wholesale source substitution beginning at inherited line 579.
- Personally confirmed that inherited Expos\'e IX paragraphs 6.5--6.6 are absent from the fresh French authority, which proceeds from 6.4 to section 7.
- Classified the inherited English as adverse/navigation material only. Detailed durable disposition: `INHERITED_ENGLISH_PROVENANCE_AND_ADVERSE_USE.md`.

## 2026-07-31 — English checkpoint 2

- Personally source-reviewed and integrated Expos\'e I paragraphs 0.1--0.5 and section 1 through Variant 1.4, French lines 57--246, scan indices 13--18 / source folios 2--7.
- Preserved the complete formulas and the native two-part commutative diagram (1.3.1); restored all source page-marker boundaries.
- Corrected four unambiguous printed-source typos transparently in English: `\phi_n(u)` to `\phi_n(\sigma)`; the nonexistent cross-reference `(1.1.1)--(1.1.5)` to `(0.1.1)--(0.1.5)`; `GL(H)` to `GL(H_o)` in the reduction kernel; and `Gal(n,\mathbb Q_\ell)` to `GL(n,\mathbb Q_\ell)`. The printed readings were checked directly on the scan; the two symbol-sensitive sites were rendered at 1800 dpi.
- Active component: `source\components\02_expose_I_0_1_through_1_4.tex`, 12,440 bytes, SHA-256 `458726B12C45FBAE152F1DE2E212B711B20E07DE4AD64AFC85CA71B7DF25A51D`.
- Two-pass PDFLaTeX build: PASS, 4 A4 pages, no overfull/underfull/fatal diagnostics. PDF SHA-256 `125DAC1F772E5FB691426630D0622F0267D54A938886C98BB00CD9FF95178424`; log SHA-256 `0ACD10C3E2FEADFD442E723D10AB303A170CA324D1E34AAA7A86923992B3B947`.
- Rendered and personally inspected all four English pages; diagram geometry, mathematical labels, page breaks, and terminal hard stop PASS.
- Exact next cursor: French line 249, section 2, scan index 18 / source folio 7.

## 2026-07-31 — English checkpoint 3

- Personally translated and source-reviewed all of Expos\'e I section 2, French lines 249--366, scan indices 18--21 / source folios 7--10.
- Preserved the complete vanishing-cycle definitions, stalk formula, exact and spectral sequences, tame variants, and the seven-node/eight-arrow native morphism diagram.
- Checked authority folios 8--10 as direct 600-dpi page renders. That resolution made all relevant symbols and arrow geometry unambiguous; no artificial escalation was needed.
- Repaired three fresh-French-TeX transcription details from the visible print: restored `\bar j` on the right side of (2.2.2), restored the stalk subscript `\bar x` in Proposition 2.3, and normalized the printed zero in `\psi^0`.
- Active component: `source\components\03_expose_I_section_2.tex`, 6,309 bytes, SHA-256 `22B221D23A55ADDACD2E25D1D27E176ED64CC6FB38F246F8C2E4A7EE7594FEEE`.
- Two-pass PDFLaTeX build: PASS, 6 A4 pages, no overfull/underfull/fatal diagnostics. PDF SHA-256 `26FCD9687B898640DC7D463F2B432619A43E34A8EE3C08BACACA5C0BB0A30D36`; log SHA-256 `402250D7906C6A1055DBBDA657AED8E4A536B840992FD3A34AF75CB81A31FBF5`.
- Rendered and personally inspected the complete new English section and its diagram at 300 dpi; layout and terminal hard stop PASS.
- Exact next cursor: French line 368, section 3, scan index 21 / source folio 10.

## 2026-07-31 — English checkpoint 4

- Personally source-reviewed and integrated all of Expos\'e I section 3, French lines 368--457, through the geometric proof of the monodromy theorem and the terminal nilpotence bound in 3.8.
- Used direct scan pages for folios 11--13 at 600 dpi and targeted 1800-dpi crops where symbols or formula logic required adjudication. The print visibly confirms the anomalous readings `m=xd`, exponent `q'`, `A_\eta`, and coefficient field `\mathbb Q`; these were not transcription inventions.
- Corrected those source typos transparently in the English mathematics: `m=nd` in the inverse system; exponent `q'+1` in Corollary 3.4 (the printed exponent makes the $q=0$ case assert $1=0$); geometric fibre $A_{\bar\eta}$ in Remark 3.6; and $\mathbb Q_\ell$ in Remark 3.7.
- Corrected additional unambiguous transcription/notation slips: `(0.2)` to the actual definition `(0.0.2)`, `A[1/X]` to `A[1/x]`, `X_{(x)}` to the already-defined strict localization `X_{(\bar x)}`, printed Greek `U_{\eta_t}` where the French working TeX had `U_{n_t}`, and cohomological degree `\psi_t^0` where the print uses a letter-form superscript.
- Active component: `source\components\04_expose_I_section_3.tex`, 8,783 bytes, SHA-256 `64B7BED45A5753B8CE28C4AAD3AE79E29875EB2084B3A640A0077D6531B5D122`.
- Two-pass PDFLaTeX build: PASS, 8 A4 pages, with zero overfull, underfull, undefined, multiply-defined, fatal, or rerun diagnostics. PDF SHA-256 `C426AF1CDD4D088AC7769CF5E8C05E07DC552F5BA1D04CA6D55CD6BD0118A6B1`; log SHA-256 `890A9D87DA3C6A44FA66CBD93A5AD2FDBDC4E2C8647A97C0C953B74EEC6D0B0C`.
- Rendered English pages 4--8 at 300 dpi and personally inspected the complete new section at full-page detail. Formula placement, underlined theorem register, page breaks, and the hard stop all PASS.
- Exact next cursor: French line 459, section 4, scan index 24 / source folio 13.

## 2026-07-31 — SGA 7 II final Claude-state takeover

- Reconciled Claude's pasted status against the stable final disk tree. The prose status is stale: the latest `expose_XXI_body.tex` reaches scan index 406, not merely 37/39 of the previously reported batch.
- Exact surviving French coverage is 399/438 page markers (91.1%); the only missing interval is the terminal contiguous range `idx407`--`idx445`, 39 pages. Expose XXI exists outside the current master; Expose XXII does not yet exist.
- Classified the material as a strong but non-authoritative working transcription. A recorded 731-word double-transcription sample reached 98.2% agreement, but fresh direct-scan checks found a missing `\overline{\mathbb F}_q` numerator twice at `idx384` and one missing upward diagram arrow at `idx280`.
- Preserved the exact identities, quality evidence, scan-resolution limits, and personal takeover plan in `SGA7II_CLAUDE_FINAL_FREEZE_AND_QUALITY_TAKEOVER_20260731.md`.
- The active production cursor remains SGA 7 I Expose I section 4. The SGA 7 II missing tail will be personally transcribed and then translated after Tome I is complete.

## 2026-07-31 — English checkpoint 5

- Personally source-reviewed and integrated all of Expos\'e I section 4, French lines 459--589, through the vanishing criteria in 4.1--4.11; scan indices 24--28 / source folios 13--17.
- Rejected literal provisional carry-overs such as `deg tr`, `prof et`, and `locus of non`; rendered these as transcendence degree, \'{e}tale depth, and non-smooth locus in mathematical English.
- Direct-scan comparison restored the missing bars in $X_{(\bar x)}$ and $\bar S$, and replaced the transcription's pseudo-accented $\overset{\sim}{H}$ by the source's reduced-cohomology notation $\widetilde H$.
- Corrected two transparent source typos in Proposition 4.10: the source defines $d(y)$ but twice prints $d(g)$; the English uses $d(y)$. Likewise, the visibly incomplete phrase `lieu de non de f` is translated as the non-smooth locus of $f$.
- Personally inspected the 4.10 authority diagram. The lower horizontal map is a rightward hook arrow: its left glyph is a hook tail, not a contrary arrowhead. The native `tikzcd` reconstruction has exactly the source's two arrows and no vertical connection.
- Active component: `source\components\05_expose_I_section_4.tex`, 7,151 bytes, SHA-256 `DC6750B7CD6FF24F693568F22C7F7C2BC1E1D46EF8CD2C9A15D411AE3C753525`.
- Two-pass PDFLaTeX build: PASS, 10 A4 pages, with zero overfull, underfull, undefined, multiply-defined, fatal, or rerun diagnostics. PDF SHA-256 `4AE8E1FFE14D5C2075909D3A93AD9EE31A4E43E234F0F26162901D7F15041A48`; log SHA-256 `A32CB2C6E80712F88114524C6349A3C07D9140E3E64F0F33D39B27C05B892D74`.
- Rendered and personally inspected English pages 8--10 at 300 dpi. The theorem register, reduced-cohomology formulas, hook diagram, page breaks, and hard stop all PASS.
- Exact next cursor: French line 591, section 5, scan index 28 / source folio 17.

## 2026-07-31 — English checkpoint 6

- Personally source-reviewed and integrated all of Expos\'e I section 5, French lines 591--688, through the proof of the prime-to-$p$ monodromy theorem for $\pi_1$; scan indices 28--31 / source folios 17--20.
- Corrected ordinary source defects transparently: the stability condition uses singular points of the whole curve $C$, not merely of one component; $S'$ is the normalization in the named extension $\eta'$; the contracted rational components have self-intersection $-2$; and the canonical splitting is of the exact sequence (5.2.1), not the induced map (5.2.2).
- Restored the mathematically required arrow $0\to\pi_1(X_{\bar\eta},\xi)$ where the typescript prints only a rule. Replaced the source's spurious component index on the descent target by the actual normalization map $X'_{\bar\eta}\to X_{\bar\eta}$.
- Reconstructed the exact sequence and both Galois-action displays natively in TeX. Direct 600-dpi authority pages were fully legible; no higher interpolation was required.
- Active component: `source\components\06_expose_I_section_5.tex`, 9,475 bytes, SHA-256 `D31498C9010806AB3EBB184BC7F0E1A68A179B0E259A43D49B19E3D5AAD0C71D`.
- Two-pass PDFLaTeX build: PASS, 12 A4 pages, with zero overfull, underfull, undefined, multiply-defined, fatal, or rerun diagnostics. PDF SHA-256 `5E2D3165B7B2F7431A5A1FEC8674F2ED486CC0ADE4F68F8B6BF6A14E653657F1`; log SHA-256 `08E82C3B26F8EBC15FF854CA28AB806019A5BA20EDC4579443A0CB748959EE2F`.
- Rendered and personally inspected English pages 10--12 at 300 dpi. The stable-curve register, exact sequences, Galois actions, theorem underlining, page breaks, and hard stop all PASS.
- Exact next cursor: French line 689, section 6 / Deligne appendix, scan index 31 / source folio 20.

## 2026-07-31 — English checkpoint 7: Expos\'e I complete

- Personally source-reviewed and integrated Deligne's entire appendix, section 6 and bibliography, French lines 689--801 / end of `expose_I_body.tex`; scan indices 31--35 / source folios 20--24.
- Checked the complete authority span at direct 600-dpi page detail. No unresolved glyph reading required additional interpolation. The native four-node/four-arrow diagram in (6.2.1) was compared node-by-node and edge-by-edge with the scan.
- Corrected ordinary source defects transparently in English: Theorem 6.1 now names the base-changed variety $A_{\eta'}$; the special-fibre notation is made explicit; the lower-left diagram object is parenthesized; $S_i-D_i$ is used consistently; and the terminal Tate-module equality is $T_\ell(A)^{I_i}$ rather than the malformed printed $T_\ell(A^{I_i})$.
- Corrected the bibliography's printed `irreductibility` to the article's title `irreducibility`. A first visual pass also caught TeX's built-in Fraktur `\Im`; all four occurrences were replaced by upright `\operatorname{Im}` and rebuilt.
- Active component: `source\components\07_expose_I_section_6.tex`, 6,810 bytes, SHA-256 `3393CC452EA81EA0BA7738D3E22596E73B4055168DF4C4F5DB6AD6B498F3DE1C`.
- Four-pass PDFLaTeX build after the final correction: PASS, 14 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal diagnostics. PDF SHA-256 `895BD3D02447A46197FE2F7273EFD2EDFAE6CE8E08A7933E13E4E3B205219B25`; log SHA-256 `2FB8215FB67240528D2799CAB506BEABF11286510FFFD3BD607E3440C46B47B4`.
- Rendered and personally inspected English pages 11--14 at 300 dpi. Appendix transition, theorem register, diagram geometry and labels, formulas, bibliography, and terminal hard stop all PASS.
- Expos\'e I is complete. Exact next cursor: opening of Expos\'e II in the frozen SGA 7 I French source.

## 2026-07-31 — English checkpoint 8: Expos\'e II complete

- Personally translated and source-reviewed all of Expos\'e II, `expose_II_body.tex` lines 1--154 / end of file; scan indices 36--42 / source folios 25--31.
- Inspected every controlling authority page at 600 dpi and used tight 1800-dpi crops for the descent product, coinvariant formula, and bibliography. Reconstructed the sole cartesian square natively with the exact four nodes, four directions, and two vertical labels.
- Corrected consequential defects transparently: the Cech descent object is $X'\times_X X'$ rather than the printed $X'\times_X S'$; the characteristic-zero hypothesis is written $\operatorname{char}k=0$; the codimension condition applies to the finite exceptional set, not its open complement; the \'etale-depth term is based on $P^1$, not the unrelated surface $S$; coinvariant generators are $x^{-1}q(x)$; and the isomorphism of (4.7.4) has the required coinvariant subscript $K$.
- The bibliography's printed `characteristic $p=0$` was corrected to $p\neq0$, consistent with the cited positive-characteristic surface theorem and the surrounding argument.
- Active component: `source\components\08_expose_II_complete.tex`, 12,753 bytes, SHA-256 `7C6003D863EF1C900DFED9FCAE404D5FE1A9262C4533CAD7D70A6B29A096255C`.
- Two-pass PDFLaTeX build: PASS, 18 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal diagnostics. PDF SHA-256 `909588F13C429E590CAD6DB1BAC278BF2D236CABCF3CC3CBD9A80C4961377691`; log SHA-256 `90E5B9AC110454DE860117AED415602B0A77D9BE18ADECF0EDE614A14DBF1F53`.
- Rendered and personally inspected all four new English pages. Title/register, dense proof flow, codimension display, cartesian square, exact sequence, coinvariant formula, bibliography, and terminal hard stop all PASS.
- Expos\'e II is complete. Exact next cursor: opening of Expos\'e VI in the frozen SGA 7 I French source.

## 2026-07-31 — English checkpoint 9: Expos\'e VI through Remark 1.3(c)

- Classified Expos\'e VI correctly as D. S. Rim's originally English contribution. This portion is therefore being preserved and source-aligned against the controlling printed authority, not retranslated.
- Personally compared and integrated `source\expose_VI_body.tex` lines 1--195, from the title and introduction through Remark 1.3(c); scan indices 43--47 / source folios 32--36.
- Inspected the five controlling authority pages directly at 600 dpi. Preserved all categorical notation and reconstructed the completion square, projection and factorization forks, refinement diagrams, fibre-product diamonds, and vector-space factorization triangle as native `tikzcd` diagrams.
- Corrected only definite English/typesetting defects encountered in the inherited typescript, including `composit` to `composite`, the object label `P` rather than `p`, and a spurious closing bracket in the dual-number expression. No mathematical content was silently abridged.
- Active components: `source\components\09_expose_VI_opening_through_1_1.tex`, 6,346 bytes, SHA-256 `55D9BB829FF553CA389C71492189093E7B7DA77B99EADECACBFF785F248FD65F`; and `source\components\10_expose_VI_1_2_through_1_3.tex`, 4,428 bytes, SHA-256 `C584EF7945D01A1E7BC1921FCA946CAA23747A01441BE4E605AB0B50ADE1E578`.
- Two-pass PDFLaTeX build: PASS, 22 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal diagnostics. PDF SHA-256 `9376FF1E5D6300D536BB4E9E10C35798C1F19B9E46EC2EFB1B475E25DC1BC1A3`; log SHA-256 `6BD93891C85851CD5396D3554731A9267F766ED5F8A98AD653C4CA60995EDCE8`.
- Rendered and personally inspected English pages 19--22. The opening register, diagrams, formula placement, page breaks, and hard stop all PASS.
- Exact next cursor: Definition 1.4 at `source\expose_VI_body.tex` line 197, scan index 47 / source folio 36.

## 2026-07-31 — English checkpoint 10: Expos\'e VI through Corollary 1.6

- Personally source-aligned Definition 1.4, Proposition 1.5 with both proof parts, and Corollary 1.6 through authority `source\expose_VI_body.tex` line 305; scan indices 47--49 / source folios 36--38.
- Inspected all three authority pages directly at 600 dpi. Reconstructed the small-prolongation triangle, projection fork, the paired fibre-product diamonds, the section/retraction display, and the Corollary 1.6 diamonds as native TeX with source-matched nodes, directions, and label sides.
- Corrected definite typescript/transcription slips where the mathematics fixes the reading: the two maps denoted $\gamma$ in Proposition 1.5(2) have target the second $a'$, not $a$; the source fibre product is $R'\times_RR'$, not the malformed `R'\times_R h'`; and the comparison isomorphism is $1\times\widetilde f$ throughout.
- Active component: `source\components\11_expose_VI_1_4_through_1_6.tex`, SHA-256 `29F9D85EF54FFF3B5D7A1BBC6F00E6CB82D3D9ABC675303833DD7158A187E3E2`.
- Two-pass PDFLaTeX build: PASS, 23 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal diagnostics. PDF SHA-256 `9602FA084558ECC52A881DA3D0F5439BF4DD59340FD2A6A5BFA73FDDA07A1063`; log SHA-256 `9ABCC0A2314255D1859F85A3C28F09BC475540342B288969422E2BFA374F1532`.
- Rendered and personally inspected English pages 22--23. The theorem register, fibre-product notation, all diagram labels and directions, page flow, and hard stop PASS.
- Exact next cursor: Definition 1.7 at authority `source\expose_VI_body.tex` line 307, scan index 49 / source folio 38.

## 2026-07-31 — English checkpoint 11: Expos\'e VI through Proposition 1.10

- Personally source-aligned Definition 1.7, Proposition 1.8, the construction of the completed pro-categories, Definition 1.9, and Proposition 1.10 through authority line 406; scan indices 49--52 / source folios 38--41.
- Inspected every controlling page at direct 600-dpi detail. Reconstructed the exact-sequence grid, two factorization triangles, both pro-category squares, and the inverse system natively. The rendered English diagrams preserve the authority's nodes, arrow directions, equality connector, hooks, and label sides.
- Made only source-determined corrections: normalized lowercase $p(a)$ to the established functor $P(a)$; restored the cotangent-space denominators as $m_i/(m_\Lambda R_i+m_i^2)$ in accordance with Definition 1.7; corrected $\alpha_i\varphi_1$ to the coherent recursion $\alpha_i\varphi_i=\varphi_{i-1}$; and rendered the source's French pro-object parenthesis in English.
- Active components: `source\components\12_expose_VI_1_7_through_1_8.tex`, 3,465 bytes, SHA-256 `5BF00F979C04A1462BEBCBC0BBA601677272D7CF94FACBD24FE93BB822AE29FA`; and `source\components\13_expose_VI_pro_categories_through_1_10.tex`, 5,279 bytes, SHA-256 `5C4A9375381C48311914CAE16FA859483E4B6181D33D70F51092A7E95EC628A0`.
- Two-pass PDFLaTeX build: PASS, 26 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal diagnostics. PDF SHA-256 `D043B089A626DE4E7E371AA868915129250667B69E945834E0FC6FA981B036C1`; log SHA-256 `D76D5AE67C8E30134E1D647DD7EDC92F8064917DFF1E938B9BA70D6B5D33F821`.
- Rendered and personally inspected English pages 23--26. Exact sequences, pro-category notation, theorem register, diagrams, page flow, and hard stop PASS.
- Exact next cursor: Theorem 1.11 at authority line 408, scan index 52 / source folio 41.

## 2026-07-31 — English checkpoint 12: Expos\'e VI through Remark 1.14

- Personally source-aligned Schlessinger's Theorem 1.11 with both directions of its proof and Remarks 1.12--1.14 through authority line 518; scan indices 52--55 / source folios 41--44.
- Compared all four authority pages directly at 600 dpi. Reconstructed the necessity and sufficiency diagrams, projection fork, inverse system, lifting squares, and terminal lift as native TeX with exact source directions and labels.
- Preserved the full theorem rather than the common short summary: finite-dimensional tangent space, minimality, inductive construction, pro-object lift, the stabilized cotangent-space criterion, base change to $\underline C_k$, and the dimension identity are all present.
- Corrected only transparent defects: closed the malformed `Hom` display in the source transcription, consistently restored fibre products over $k$, and retained both the smooth and formally smooth cases in Remark 1.14 after the first render exposed an overly narrow wording.
- Active component: `source\components\14_expose_VI_1_11_through_1_14.tex`, 7,307 bytes, SHA-256 `9B1A5856F0155CD61EE787BD5105F5275CC6ED4C4934CC7D20ECCB883D167815`.
- Two-pass PDFLaTeX rebuild after the wording correction: PASS, 28 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal diagnostics. PDF SHA-256 `0DA5F16E945A26B5D684D3F3FAD09B2CA0D6D1AC5D9B27150917099CC7DCD3FC`; log SHA-256 `E64D336286DBDA5BBB71A5D08BA402DEDF8057FDEBB198011DCBEB916EB950B2`.
- Rendered and personally inspected English pages 26--28; after the correction, the theorem register, formula scope, diagrams, smoothness language, page flow, and hard stop PASS.
- Exact next cursor: paragraph 1.15 at authority line 523, scan index 56 / source folio 45.

## 2026-07-31 — English checkpoint 15: Expos\'e VI through 1.17

- Personally source-aligned paragraphs 1.15--1.17 against scan indices 56--57 / source folios 45--46, retaining the full semi-homogeneity conditions and their native diagrams.
- Active component: `source\components\15_expose_VI_1_15_through_1_17.tex`, SHA-256 `6FA03D5CF636798DF30B792437C99D8A99B0505F392B83BCF788EB6C0D225A34`.
- Two-pass PDFLaTeX build: PASS, 29 A4 pages, zero fatal or layout diagnostics. PDF SHA-256 `748857F41AF15105A7ECF87A711828CC1A62FD3055EE5BED9BEE8F8137D8324F`.
- Exact next cursor: Lemma 1.18, authority line 598, scan index 58 / source folio 47.

## 2026-07-31 — English checkpoint 16: Lemma 1.18

- Personally source-aligned the complete proof of Lemma 1.18, authority lines 598--698 / scan indices 58--59 / source folios 47--48.
- Corrected five definite mathematical/typescript defects in the active English: `(k,D)` to `(1,D)`; the two incompatible `K^n` domains to `K'^n`; `a\in V\otimes H` to `a\in V\otimes A`; and the self-inconsistent rule `uG(D)=F(uD)` to `uG(D)=G(uD)`.
- Reconstructed the two-by-three functor diagram natively and compared its nodes, directions, and label sides directly with the authority.
- Active component: `source\components\16_expose_VI_lemma_1_18.tex`, SHA-256 `1754156D0F212B03219A607C235B16A17DE725CBA163CF3D6255DC95F9C1A2D3`.
- Two-pass build and rendered-page review: PASS, 30 A4 pages. PDF SHA-256 `A836A2D4FD23E9808009745408BFE8559BBA62FF4ECAF9A80A6121C82804D735`.
- Exact next cursor: Definition 1.19, authority line 700, scan index 59 / source folio 48.

## 2026-07-31 — English checkpoint 17: Expos\'e VI through 1.20

- Personally source-aligned Definition 1.19 and Theorem 1.20, authority lines 700--733 / scan indices 59--60 / source folios 48--49.
- Corrected the visible source typo `\varphi_2-\varphi_2=Ds` to the mathematically required `\varphi_2-\varphi_1=Ds`, and normalized malformed wedge glyphs to `\Lambda`.
- Active component: `source\components\17_expose_VI_1_19_through_1_20.tex`, SHA-256 `131BF9448A87D4A8091DB72D4683C84C394DE81BAC48633D1574EA52D0000B86`.
- Two-pass build and rendered-page review: PASS, 31 A4 pages. PDF SHA-256 `744974C0CD49F9B52E04429DDE7AF3DD94A3CEB57DDD315A1A15EF997A84D796`.
- Exact next cursor: section 2 opening, authority line 736, scan index 60 / source folio 49.

## 2026-07-31 — English checkpoint 18: Expos\'e VI through Remark 2.2

- Personally source-aligned the opening of section 2, Definition 2.1, and Remarks 2.2(a)--(d), authority lines 736--791 / scan indices 60--62 / source folios 49--51.
- Reconstructed all triangles and the terminal versality diagram natively, preserving arrow direction and label placement.
- Active component: `source\components\18_expose_VI_section_2_opening_through_2_2.tex`, SHA-256 `4249CA3E3BB7980E28C235DB556A66C855348257B27F5F9B6F262BB4F829E123`.
- Two-pass build and rendered-page review: PASS, 33 A4 pages. PDF SHA-256 `78570A3ED33FDB8B455F67477E4445F8D38C1C96F5EEB3633AA3C4E1F04D65B3`.
- Exact next cursor: Proposition 2.3, authority line 793, scan index 62 / source folio 51.

## 2026-07-31 — English checkpoint 19: Expos\'e VI through Proposition 2.7

- Personally source-aligned Proposition 2.3, Remark 2.4, Definition 2.5, all four parts of Remark 2.6, and Proposition 2.7 with proof, authority lines 793--974 / scan indices 62--66 / source folios 51--55.
- Direct authority comparison corrected two transcription slips: the second arrow in Proposition 2.3 is labelled `\psi`, not a second `\varphi`; and the semi-homogeneity source object is `R_1\times_RR_2`, not `R\times_RR_2`.
- Reconstructed the homogeneity fork, paired fibre-product diamonds, categorical triangle and square, and the twelve-node proof diagram natively. Full-page 600-dpi authority views resolved the source geometry; no unresolved glyph required interpolation beyond the scan's native information.
- Active component: `source\components\19_expose_VI_2_3_through_2_7.tex`, 9,556 bytes, SHA-256 `40B68AE73E1AC1C99C804B62371979D1A9C736858FDA3139970EFD3DDF4FE83F`.
- Two-pass PDFLaTeX build: PASS, 36 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `84E448B10D50D97C55AFBACC004127F60279D212ACE9BA8A3BB791C9B650D1F3`; log SHA-256 `D8DCEBB0710B81E8EC60112B680CD2CC445A16C27DBF0AFAA3CB05FBE6CE1E0F`.
- Rendered and personally inspected cumulative English pages 33--36. All diagram nodes, arrows, labels, page flow, and the terminal hard stop PASS.
- Exact next cursor: authority line 976, the paragraph preceding Lemma 2.8, scan index 66 / source folio 55.

## 2026-07-31 — English checkpoint 20: Expos\'e VI through Proposition 2.9

- Personally source-aligned the construction of $\tau(a_1,a_2)$, Lemma 2.8 with proof, and Proposition 2.9 with both proofs, authority lines 976--1152 / scan indices 66--70 / source folios 55--59.
- Kept the statement's mathematically consistent composition $\psi\circ\varphi$ where the printed proof reverses it once. Repaired the French working TeX's malformed terminal diagram node `\varphi(a_{n+1}` by restoring the missing parenthesis; no mathematical content was omitted.
- Reconstructed the two fibre-product diamonds, inverse-system ladder, dotted lifting diagram, inductive fibre-product pair, and terminal six-node/nine-arrow diagram natively and compared them directly against full authority pages at 600 dpi.
- Active component: `source\components\20_expose_VI_2_8_through_2_9.tex`, 8,391 bytes, SHA-256 `7507926EA8ECA493919DEE56F25AD1FA1EE4E493213BC5F940B7C36E9AE12C4F`.
- Two-pass PDFLaTeX build: PASS, 39 A4 pages, with no actual warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `D07748D4073F76355DD01243937CA9E4F512879E002A54D00924E9FA312DBBFF`; log SHA-256 `4FB0CCD6D109AEC8D0E7C599DE92FA76B9D502C2AC6B6D68FD615B03EAA1CBF7`.
- Rendered and personally inspected cumulative English pages 36--39. Diagram geometry, dotted/solid distinctions, label placement, formula flow, and terminal hard stop PASS.
- Exact next cursor: Corollary 2.10 at authority line 1153, scan index 70 / source folio 59.

## 2026-07-31 — English checkpoint 22: Expos\'e VI through the representability introduction

- Personally source-aligned Corollary 2.10 and the complete cocategory/cogroupoid representability construction through authority lines 1153--1260 / scan indices 70--74 / source folios 59--63.
- Compared the controlling authority pages directly at 600 dpi. Reconstructed the Corollary 2.10 square, the cocategory composition diagram, both identity composites, the represented double-arrow object, and the triple-arrow composition diagram natively with source-matched arrow directions and label sides.
- Corrected only transparent editorial defects in the working transcription: `cocartegory` to `cocategory`, `composit map` to `composite map`, and the malformed comma-category notation around `R_0\amalg R_0`. The first unlabeled structural arrow in the printed cocategory diagram is explicitly identified as $c$ in prose without changing its printed geometry.
- Active components: `source\components\21_expose_VI_corollary_2_10.tex`, 1,861 bytes, SHA-256 `CC503CF4517E56460C3E4394590D8707A4053B6D932DE5EB3C918860A4F3B396`; and `source\components\22_expose_VI_representable_cogroupoids_intro.tex`, 7,628 bytes, SHA-256 `0860A8014F1E2B1CAF82150B6C3373D169FF28837CFB66DE24FB9F0069F5262A`.
- Two-pass PDFLaTeX build: PASS, 41 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `DAAB9212DBBFC5EF4D0DC139A7FAB63BE89E4F1690CE0A0B337B3C155571031F`; log SHA-256 `50DDB2A0E1A9CA7B6E5F3945572E2503390FC3BBA4ACEFFC1F1C959A2D0F07C7`.
- Rendered and personally inspected cumulative English pages 39--41. The theorem register, fibre-product orientation, cocategory arrows, triple-arrow label placement, formula flow, and terminal hard stop all PASS.
- Exact next cursor: Definition and Proposition 2.11 at authority line 1263, scan index 74 / source folio 63.

## 2026-07-31 — English checkpoint 23: Expos\'e VI through Proposition 2.12(b)

- Personally source-aligned Definition and Proposition 2.11 and Proposition 2.12 through the proof of part (b), authority lines 1263--1331 / scan indices 74--76 / source folios 63--65.
- Reconstructed the two-arrow test diagram and the four-object fibre-product diamond natively from the direct 600-dpi authority pages.
- The French working TeX's long Hom-set computation is syntactically broken at the terminal fibre product. Restored the complete argument as an explicit bijection $w_2\mapsto v^{-1}w_2$ and the resulting universal-property Hom-set identity, retaining every compatibility condition visible in the printed authority.
- Active component: `source\components\23_expose_VI_2_11_and_2_12_ab.tex`, 4,800 bytes, SHA-256 `6B3D783CC13F11240EECF9EEA121D83DBD860C4B8E79F0C8353F1EE8D10D4507`.
- Two-pass PDFLaTeX build: PASS, 43 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `9FC53E70139B19BFE786202AB261C990CF1BE1CC294902A1AE04C7CB2CEB3238`; log SHA-256 `978BD888C29F57B0626818F913EBECC8A565B3FD563E03AE3C02FDB0095BB734`.
- Rendered and personally inspected cumulative pages 41--43. The theorem register, native diagrams, long compatibility calculation, fibre-product identity, and hard stop all PASS.
- Exact next cursor: proof of Proposition 2.12(c) at authority line 1333, scan index 76 / source folio 65.

## 2026-07-31 — English checkpoint 24: Expos\'e VI through Proposition 2.14

- Personally source-aligned Proposition 2.12(c), Definition 2.13, and Proposition 2.14 with proof, authority lines 1333--1364 / scan indices 76--77 / source folios 65--66.
- Used an 1,800-dpi targeted authority crop for the dense completed-tensor-product formula in Proposition 2.12(c), resolving the representing object as $R_1\otimes_{R_0\widehat\otimes_\Lambda R_0}(T\widehat\otimes_\Lambda T)$. The full page and Proposition 2.14 square were separately checked at 600 dpi.
- Reconstructed the normalized-cogroupoid endomorphism square natively and repaired the working transcription's missing closing bracket in the induced $k[\varepsilon]$ map.
- Active component: `source\components\24_expose_VI_2_12_c_through_2_14.tex`, 2,794 bytes, SHA-256 `742EDD14653B0D9B5E963D504504F3D5188E81692E4B296097630177B49C2352`.
- Two-pass PDFLaTeX build: PASS, 44 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `43AB5A1ED491FC39F0876079843472A5CE98C85DD83C2A3448543DFD3A473C6A`; log SHA-256 `846DF3F35138F876071175417293AEE2654B954320F25B01F26116A60E1EDCF7`.
- Rendered and personally inspected cumulative pages 43--44. The completed-tensor notation, theorem flow, square geometry, labels, and terminal hard stop all PASS.
- Exact next cursor: Lemma 2.15 at authority line 1366, scan index 77 / source folio 66.

## 2026-07-31 — English checkpoint 25: Expos\'e VI through Theorem 2.17

- Personally source-aligned Lemma 2.15, Corollary 2.16, and Theorem 2.17 with their complete proofs, authority lines 1366--1442 / scan indices 77--79 / source folios 66--68.
- Reconstructed the two fibre-product squares and the fork defining the isomorphism functor natively, preserving the authority's nodes, arrow directions, and label placement.
- Active component: `source\components\25_expose_VI_2_15_through_2_17.tex`, 6,252 bytes, SHA-256 `82637B0A52FE4FAE4B86ECEFF013FDCFAE2D8E29812C88D051EBCFEE39736773`.
- Two-pass PDFLaTeX build: PASS, 46 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `7A4C0351913905805BBD72EBD685533BF813E1D6C1D04091516593FA0673331A`; log SHA-256 `354E0DDE48AB54D486A52103295500CAD8777714867161F5ADE8B2676247EF6E`.
- Rendered and personally inspected cumulative pages 44--46. Native diagram geometry, theorem flow, formula fit, page breaks, and the terminal hard stop all PASS.
- Exact next cursor: Corollary 2.18 at authority line 1447, scan index 80 / source folio 69.

## 2026-07-31 — Claude transcription quality and takeover disposition

- SGA 7 I is structurally complete at 528/528 unique page markers and builds to a 267-page French/source-language reader. Its producer validation visually sampled 17 reader pages, including expos\'e boundaries and warning pages; it did not perform a page-by-page mathematical audit. The present English source-alignment pass has already found definite source-to-TeX slips and malformed formulas/diagram labels within the first 68 source folios. Disposition: strong locator and drafting transcription, but every translated unit remains subject to direct scan comparison before admission.
- Serre FAC is structurally complete at 82/82 source pages. Twelve difficult/refused pages were transcribed manually from the leaves and seventy came from agent batches. The recorded typography sample found 24 of 26 bold spans correct and two fabricated. The current apparatus records 61 source defects and 242 uncertain readings. There is no exhaustive page-level audit. Disposition: useful and probably strong working transcription, with better difficult-page evidence than GAGA, but not critical-edition quality.
- Serre GAGA is structurally complete at 42/42 source pages and compiles to 24 pages. Its own STATUS explicitly records no page-level verification, no diagram audit, and no omission scan; the apparatus records 21 source defects and 82 uncertain readings. Disposition: readable first-pass transcription, currently the weakest-evidenced of these three despite its clean build.
- SGA 7 II disk truth is 399/438 unique body markers (91.1%), with the exact missing terminal interval scan indices 407--445. A 731-word independent double-transcription sample reported 98.2 percent agreement, but direct checks found a missing $\overline{\mathbb F}_q$ numerator twice and a missing reverse vertical diagram arrow. Disposition: strong but fallible working base; the remaining 39 pages and consequential formulas/diagrams will be completed personally from `Number12.pdf`.
- Production policy: audit is integrated with translation. The scan decides; ordinary pages receive direct page comparison, and formulas/diagrams or ambiguous glyphs receive tight high-detail crops up to the native-information ceiling. Compile success and page-marker coverage are never treated as fidelity evidence by themselves.

## 2026-07-31 — English checkpoint 26: Expos\'e VI through Remark 2.22

- Personally source-aligned Corollaries 2.18--2.20 and Remarks 2.21--2.22, authority lines 1447--1473 / scan indices 80--81 / source folios 69--70.
- Corrected the printed statement of Corollary 2.20 from “homogeneous cogroupoid” to the mathematically required “homogeneous cofibered groupoid”; the same paragraph distinguishes the cofibered groupoid $\underline A$ from the smooth cogroupoid that prorepresents it.
- Active component: `source\components\26_expose_VI_2_18_through_2_22.tex`, SHA-256 `CCFD6435C31245DA9A2713AC6113932CC56638C8085C419E406F73BCD5639FE6`.
- Two-pass PDFLaTeX build: PASS, 47 A4 pages, with no warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `1BF9C337D6B78A0C8DB3F5F2432F6FC8CFC73D8204EE892B1B02BD9B2D3F16C9`; log SHA-256 `A4D4CAC1A5AD5FF7017AB62EE3B1BA32B567B4028FEA4250B38ACC8AFDB6E3E0`.
- Rendered and personally inspected cumulative English pages 46--47. Formula flow, theorem register, line fit, page break, and terminal hard stop all PASS.
- Exact next cursor: section 3 opening, authority line 1476, scan index 81 / source folio 70.

## 2026-07-31 — English checkpoint 27: Expos\'e VI through 3.1(b)

- Personally source-aligned the section 3 opening, its site and sheaf conventions, 3.1(a), and 3.1(b), authority lines 1476--1602 / scan indices 81--84 / source folios 70--73.
- Compared four complete authority pages directly at 600 dpi. Reconstructed the two sheaf/presheaf squares and the 2/3/4-arrow \v{C}ech semisimplicial diagram natively, and restored the check-accented cohomology terms lost in the working transcription.
- Active component: `source\components\27_expose_VI_section_3_opening_through_3_1_b.tex`, SHA-256 `A32EB3483FAEB2FC6EA0C8572FA5F2A82ADC7994A716C40C0ECED98A472490CE`.
- Two-pass PDFLaTeX build: PASS, 49 A4 pages, zero substantive diagnostics. PDF SHA-256 `D43B9426FADFC0F34FC951DB59BC06DBE665805B2D7B63F32C8626EB5EAD8451`; log SHA-256 `23BD6AAA31DD84514A5DC37DBAFE3A1B4CA4ADD96EE4A628893483F297E546C8`.
- Rendered and personally inspected cumulative pages 47--49. The categorical squares, arrow multiplicities, notation, and page flow PASS.

## 2026-07-31 — English checkpoint 28: Expos\'e VI through Remark 3.4

- Personally source-aligned 3.1(c), Lemma 3.2, Corollary 3.3 with proof, and Remark 3.4, authority lines 1603--1704 / scan indices 84--87 / source folios 73--76.
- Corrected the printed backward reference “2.1(a)” to the actual 3.1(a), while preserving the mathematical content of the two spectral sequences. Direct 600-dpi authority pages controlled all accents, derived-functor symbols, and the reverse-arrow multiplicities in the complex.
- Rendered review caught a literal `mid` in the set-builder formula; the r2 source restores the mathematical relation `\mid`. Active component SHA-256: `EF1EE448FD5FC9E5A7F93EE9EAB64E421900944E2559E0683904A85D227EB26E`.
- Two-pass PDFLaTeX build: PASS, 51 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `6135C785A9014AD0FD8AF9304BE50ECE42ECC7EB6731400E042307B22281C8A1`; log SHA-256 `BFC11EAE94F9826C724D85782BF3FB73434FD613A0414446D307C964852FEF09`.
- Rendered and personally inspected cumulative pages 49--51, including a fresh page-51 render after the set-builder repair. Layout and formulas PASS.
- Exact next cursor: Lemma 3.5, authority line 1706, scan index 87 / source folio 76.

## 2026-07-31 — English checkpoint 29: Expos\'e VI through Corollary 3.6

- Personally source-aligned Lemma 3.5 with proof and Corollary 3.6 with proof, authority lines 1706--1781 / scan indices 87--89 / source folios 76--78.
- The printed Lemma 3.5 hypothesis gives $\operatorname{Tor}^R_i(B,S)=0$ only for $0<i<n$, while the printed proof explicitly uses the vanishing for $0<i\leq n$ to deduce the asserted range for the kernel $J$. Direct 600-dpi page comparison and targeted 1,800-dpi crops confirmed the print reading. The active English transparently restores the mathematically required $0<i\leq n$ hypothesis for $B$; the hypotheses on $C$ and the conclusion retain $0<i<n$.
- Reconstructed the six-object comparison square and the nine-node Tor exact diagram natively, preserving the equality verticals, zero objects, arrow directions, and source formula order.
- Active component: `source\components\29_expose_VI_3_5_through_3_6.tex`, SHA-256 `7C084004275E1E7F34ED4165577C9EBEE68DA819FC3778281012210C90D2A865`.
- Two-pass PDFLaTeX build: PASS, 53 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `3EB321FDC0613C0FB14A94329FAB3CCAB2DAA23CB8F2D04EB4FF5BBA6C30C9DC`; log SHA-256 `C12D33FDF02C632B10BA8CEF02C0854765C384DECD61B020FCDF8C38DCE31E28`.
- Rendered and personally inspected cumulative pages 51--53. Both native diagrams, the Tor ranges, formula fit, and terminal hard stop PASS.
- Exact next cursor: Proposition 3.7, authority line 1787, scan index 89 / source folio 78.

## 2026-07-31 — English checkpoint 30: Expos\'e VI through Proposition 3.7

- Personally source-aligned all three parts and the complete proof of Proposition 3.7, authority lines 1787--1892 / scan indices 89--92 / source folios 78--81.
- Compared the four complete authority pages at 600 dpi. Reconstructed the five-node spectral-sequence comparison and the low-degree exact-sequence diagram natively, preserving the intentionally empty middle-right cell, double abutment arrows, vertical directions, and equality bars.
- Restored three definite damaged readings in the working transcription: the omitted inequalities in the Tor range, the missing tensor symbol in $X\otimes_RS$, and the caron on the final \v{C}ech cohomology term. Corrected the printed English typo “flask” to the standard “flasque” without changing the argument.
- Removed three invalid in-math font-size commands exposed by the honest build diagnostics (one inherited in component 29 and two in component 30); the equivalent `center`-scoped native diagrams now compile without warnings. The current component-29 SHA-256 is `F7FBBA376219C872BB5750D4BEBD3DBE9D44757EAEB44AF2949C502BF42C3AAE`.
- Active component: `source\components\30_expose_VI_proposition_3_7.tex`, SHA-256 `79CCEA50769648093B5C6CDBCCEC54A545FE48DDB74016775F212965B4AA2295`.
- Two-pass PDFLaTeX build and rendered-page review: PASS, 56 A4 pages. The log contains no substantive diagnostics (the only broad string match is the package name `infwarerr`). PDF SHA-256 `B5288DE2B4E6B43018C62EF58619CAA3B24DBB076D754FF74DFC22B71B1E0817`; log SHA-256 `91295F981AE99140AFA1A4C47A36BEC13642BD849179AD06BA66A2DFFC65F838`.
- Exact next cursor: Corollary 3.8, authority line 1897, scan index 92 / source folio 81.

## 2026-07-31 — English checkpoint 31: Expos\'e VI through Corollary 3.9

- Personally source-aligned Corollaries 3.8 and 3.9 with their complete proofs, authority lines 1897--1979 / scan indices 92--94 / source folios 81--83.
- Direct 600-dpi authority comparison controlled the four-node base-change square and the exact sequences. Restored the missing relative-base separators in the working transcription's malformed $H^i(A\otimes_RB|A,F_A)\to H^i(A\otimes_RB|R,F)$ sequence.
- Active component: `source\components\31_expose_VI_corollaries_3_8_and_3_9.tex`, SHA-256 `7B52B88CBEA71FFB72BDDB28E5F4C47D9D028C249CAAA4558BBE060EEE2030B4`.
- Two-pass PDFLaTeX build: PASS, 57 A4 pages, zero LaTeX/package warning, undefined-reference, overfull/underfull, missing-character, fatal, or rerun diagnostics. PDF SHA-256 `78178D3AE970D94C9A859EB446A091089FC41436710F0ABD82010791FD4C7AAB`; log SHA-256 `AD9A86B1D53673EEABB0A9C729E62F1CB72018018809ED30282309840479BA7B`.
- Rendered and personally inspected cumulative pages 55--57. The 3.7 seam, native square, split exact sequences, localization formulas, and terminal hard stop all PASS.
- Exact next cursor: the paragraph introducing Definition 3.10, authority line 1984, scan index 94 / source folio 83.

## 2026-07-31 — English checkpoint 32: Expos\'e VI through Lemma 3.10

- Personally source-aligned the derivation-cohomology definition and the first low-degree computation, authority lines 1984--2054 / scan indices 94--95 / source folios 83--84. The source itself numbers both the definition and the following lemma 3.10; the active English preserves that numbering rather than silently renumbering the book.
- Compared both authority pages directly at 600 dpi and inspected the dense simplicial and exact-sequence formulas in targeted 1,800-dpi crops. Preserved the three/two face-map multiplicities and distinguished $\overline I$, $I^{(n)}$, and $\overline I^{(n)}$ throughout.
- Active component: `source\components\32_expose_VI_definition_and_lemma_3_10.tex`, SHA-256 `E50ED0111863312D90511AF34EAB69D4F5F44E39949BAC890E2DE4AAE631368A`.
- Two-pass build and rendered-page review: PASS, 58 A4 pages, zero diagnostics. PDF SHA-256 `AA5EC141F1AA41BDBA7BC110BE36BDAD7CC2B6F5E66D7B8B6351044628ACFBF3`; log SHA-256 `3DF272330952B4277E3222210B30A123D422FDCD7024390833AF611EDFD9076B`.
- Exact next cursor: Lemma 3.11, authority line 2057, scan index 95 / source folio 84.

## 2026-07-31 — English checkpoint 33: Expos\'e VI through Lemma 3.11

- Personally source-aligned Lemma 3.11 and its complete Koszul-complex proof, authority lines 2057--2114 / scan indices 95--96 / source folios 84--85.
- Direct 600-dpi page comparison controlled the three face lifts, all ideals, intersections, quotient modules, and the two exact symmetric-algebra sequences. A targeted 2,400-dpi crop resolved the terminal source inconsistency: the printed derivation identifies the quotient with $H_1(K_I)$ but then types $H^1(K_I)$ inside the last $\operatorname{Hom}_A$. The active statement and final formula use the mathematically coherent $\operatorname{Hom}_A(H_1(K_I),M)$, while retaining $H^1(K_I,M)$ as the domain.
- Active component: `source\components\33_expose_VI_lemma_3_11.tex`, SHA-256 `F49F021F11BF329ED858AA7533B5FFC9796CAE8A20208C45A46164D37E18054C`.
- Two-pass build: PASS, 60 A4 pages, zero diagnostics. PDF SHA-256 `1CA906F93BF9B4DD0E1414367AFFD3C133D0DA6D4B3F115DEA27E93F66A436E9`; log SHA-256 `D2F2C8A3C6C5005C51758097D049B9F83E3924461CC16945E1CA1569795FA1D5`.
- Rendered and personally inspected cumulative pages 58--60. The Koszul notation, face maps, quotient formulas, line wrapping, and hard stop all PASS.
- Exact next cursor: Theorem 3.12, authority line 2120, scan index 97 / source folio 86.

## 2026-07-31 — English checkpoint 34: Expos\'e VI through Theorem 3.12

- Personally source-aligned the complete eight-part statement and proof of Theorem 3.12, authority lines 2120--2288 / scan indices 97--100 / source folios 86--89.
- Compared all four authority pages directly at 600 dpi. Reconstructed the two algebra-extension diagrams natively and preserved every long exact sequence, base-change map, localization formula, and low-degree description.
- Restored the coefficient sheaf omitted by the working transcription in proof part (6): the source-controlled map is $E\otimes_A\operatorname{Der}_R(-,M)\to\operatorname{Der}_R(-,E\otimes_AM)$.
- Active components: `source\components\34_expose_VI_theorem_3_12_statement.tex`, 3,593 bytes, SHA-256 `A97F2407812FD1FFBEEC6DFCBEC622E3FD7797F232B9BCE68D8DBE771D252C85`; and `source\components\35_expose_VI_theorem_3_12_proof.tex`, 5,280 bytes, SHA-256 `C581C0129DDB73733C9FDA6E4E342F1F4F9CBCF7D63FD4D9AF93B0003C63DDB5`.
- Two-pass build and rendered review: PASS, 63 A4 pages, zero diagnostics. PDF SHA-256 `E4C1A698E9DD2DC3620A931A0432EC4ED18D00AAE980B522366FD3C6BCC79041`; log SHA-256 `55FE1FC7FCF399D1341D3A0899EBE8A45777AE9D5F44B9222C5C84009335B810`.
- Exact next cursor: Corollary 3.13, authority line 2290, scan index 100 / source folio 89.

## 2026-07-31 — English checkpoint 35: Expos\'e VI through Corollary 3.13

- Personally source-aligned Corollary 3.13 and its complete proof, authority lines 2290--2366 / scan indices 100--102 / source folios 89--91.
- Compared the three complete authority pages at 600 dpi and used a targeted 1,800-dpi crop for the completion argument. Reconstructed the two-row exact completion diagram natively, preserving the equality connector and both downward completion arrows.
- Corrected three definite damaged readings without changing the argument: the missing relative separator in $D^i(A|R,\widehat A\otimes_AE)$; the omitted completion hat on the target of the extension classifying $D^1(\widehat A|R,-)$; and the duplicated $D^1$ in the proof's closing sentence.
- Active component: `source\components\36_expose_VI_corollary_3_13.tex`, 5,694 bytes, SHA-256 `8306B67AA5E1AE5D9C8AD4C1494BC64CA59F4B5BF09ADE3529FB4D0B877D38EE`.
- Two-pass build and rendered review: PASS, 65 A4 pages, zero diagnostics. PDF SHA-256 `2CF59E89B484342E7CCBBF6D65DAB025DD02EF979BED6F0180CE300BBF6F46D5`; log SHA-256 `E60003989932B98A59BC8B7AA343D3708378A6F9C5DB21B307B8FB09BBE7FC39`.
- Exact next cursor: Corollary 3.14, authority line 2371, scan index 103 / source folio 92.

## 2026-07-31 — English checkpoint 36: Expos\'e VI section 3 complete

- Personally source-aligned Corollary 3.14, both source-numbered 3.15 units, and Remark 3.16 through the end of section 3, authority lines 2371--2448 / scan indices 103--105 / source folios 92--94.
- Compared all three authority pages at 600 dpi and inspected the dense topological-cohomology and deformation exact-sequence formulas at 1,800 dpi.
- Restored source-coherent notation where the working transcription or print was defective: $A_\alpha\otimes_AE$ (rather than a meaningless tensor over the index $\alpha$), the localization basis 3.13(c) for the quasi-coherent sheaf construction, the residue-field base $X_0|k$, and the extant low-degree item 3.12(8) rather than the printed non-existent 3.12(10). The source's duplicated numbering ``Remark 3.15 / Corollary 3.15'' is preserved.
- Active component: `source\components\37_expose_VI_3_14_through_3_16.tex`, 5,822 bytes, SHA-256 `DADB691E3070006787D499F150F4FDD505F55A24497B5D75AB7001A0BA369ED0`.
- Two-pass build: PASS, 66 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `4D9E33CB347517265B73026B3561F89B74EE658785AC864663697B1C929F1AD2`; log SHA-256 `A781EFDC371530BC2A5EA6D99BB9E76E10842B5AA3DB16C95D2A40C4F49B0FF5`.
- Rendered and personally inspected cumulative pages 64--66. The Corollary 3.13 seam, completion diagram, sheaf notation, exact sequences, section ending, and terminal hard stop all PASS.
- Exact next cursor: section 4, ``Formal moduli of deformations,'' authority line 2451, scan index 105 / source folio 94.

## 2026-07-31 — English checkpoint 37: Expos\'e VI through 4.1

- Personally source-aligned the section 4 opening and all four parts of 4.1, authority lines 2451--2559 / scan indices 105--108 / source folios 94--97.
- Compared the complete authority pages directly at 600 dpi. Reconstructed six diagrams natively: the defining deformation square, the six-node morphism diagram, the cocartesian base-change square, the affine-algebra square, the repeated deformation square, and the open-restriction square.
- Active component: `source\components\38_expose_VI_section_4_opening_through_4_1.tex`, 7,180 bytes, SHA-256 `0D83516258C251F2DD7DEEE1294598D281DE5A52919B4AD89378A0DAAE533418`.
- Two-pass build: PASS, 69 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `15B1FCEFB6F9E46895E2203AA705F8700B359465DE13A65186EEA0B2D6CD915D`; log SHA-256 `FE830F4B19090FBC2A7831066A5BF51CB23E7720114B8C98C3865CF27B9A0397`.
- Rendered and personally inspected cumulative pages 66--69. All six diagrams, arrows, labels, formula attachment, page breaks, and the terminal hard stop PASS.
- Exact next cursor: Lemma 4.2, authority line 2561, scan index 108 / source folio 97.

## 2026-07-31 — English checkpoint 38: Expos\'e VI through Corollary 4.3

- Personally source-aligned Lemma 4.2 and Corollary 4.3 with both proofs, authority lines 2561--2607 / scan indices 108--110 / source folios 97--99.
- Direct 600-dpi comparison controlled the two three-node diagrams, the fiber products, the Tor criterion, and the scheme pushout formulas. Restored the prime omitted by the working transcription in the proof's definition $S=R\times_{\bar R}R'$, and restored the missing amalgamation symbol in the induced map to $X\amalg_{\bar X}X'$.
- Active component: `source\components\39_expose_VI_lemma_4_2_and_corollary_4_3.tex`, 3,370 bytes, SHA-256 `159C94030588938B5A7AFD84A4E7DA21676CEE9D0B5AAFA49E684985B56B8CC0`.
- Two-pass build: PASS, 70 A4 pages, zero diagnostics. PDF SHA-256 `618A4C79A415E47B5E17DE4962D59F8465536761469D52E0B8CB93AFF8A7E872`; log SHA-256 `912AC6FCBD76126FF95FC2BEE27EC82977450ABFF7931648CC62D9FC5AAEDA93`.
- Rendered and personally inspected cumulative pages 69--70. Diagrams, primes, fiber-product bases, exact sequences, and page flow PASS.

## 2026-07-31 — English checkpoint 39: Expos\'e VI through Lemma 4.4

- Personally source-aligned Lemma 4.4 and its affine/general-case proof, authority lines 2609--2652 / scan indices 110--111 / source folios 99--100.
- Compared both complete authority pages at 600 dpi. Reconstructed the ten-node extension diagram natively and rendered the automorphism-sheaf/gluing argument in source-faithful mathematical English.
- Active component: `source\components\40_expose_VI_lemma_4_4.tex`, 3,035 bytes, SHA-256 `AF7C08FB1C0230086B19806D7AFBDD9DCBC648299C344C90E61EAA232D974F94`.
- Two-pass build: PASS, 71 A4 pages, zero diagnostics. PDF SHA-256 `A06B3309A8EF3E2FA12320D8598ABA008A827E62544A747925647FB28874757C`; log SHA-256 `DCF733E84BC66DBE79FA1FF3090D4B10AD363B3A2E60E4FD445BAD54749956C2`.
- Rendered and personally inspected cumulative pages 70--71. The native extension diagram, exact-sequence terms, vector-space maps, and terminal hard stop PASS.
- Exact next cursor: Theorem 4.5, authority line 2654, scan index 111 / source folio 100.

## 2026-07-31 — English checkpoint 40: Expos\'e VI through Theorem 4.5

- Personally source-aligned the full statement and proof of Theorem 4.5, authority lines 2654--2693 / scan indices 111--112 / source folios 100--101.
- Compared both complete authority pages at 600 dpi. Reconstructed the cartesian formal-scheme square natively and preserved the prorepresentability automorphism criterion, the proper/affine alternatives, and the exact tangent-space sequence.
- Active component: `source\components\41_expose_VI_theorem_4_5.tex`, 3,084 bytes, SHA-256 `537DC111C3032CB23EA2FA00D92E55AD977FC00CCCBDCA06B1FC75E3B72973A1`.
- Two-pass build: PASS, 72 A4 pages, zero diagnostics. PDF SHA-256 `DD0726302422398CBD8E9A0AFA3F0DBB1603B58B8BDD8D082893CDF47636911C`; log SHA-256 `C503B7168C57504F3872AFE4302A93E6ED418934B8F8D3E20EF7B8736D49F550`.
- Rendered and personally inspected cumulative pages 71--72. The cartesian square, singular-support formula, automorphism map, proof sequence, and hard stop PASS.

## 2026-07-31 — English checkpoint 41: Expos\'e VI through Remarks 4.6

- Personally source-aligned Remarks 4.6(a)--(c) and the ensuing construction of the deformation category of a pair $(X_0,Y_0)$, authority lines 2695--2728 / scan indices 112--113 / source folios 101--102.
- Direct 600-dpi comparison controlled the base-ring change, dimension formula, and the six-node/nine-arrow pair-deformation diagram. The active native diagram supplies the mathematically required arrowhead on $X\to\operatorname{Spec}(R)$ that is visibly absent from the printed stroke while retaining its source label and direction.
- Active component: `source\components\42_expose_VI_remarks_4_6_and_pair_deformations.tex`, 2,946 bytes, SHA-256 `3558079A5FCC09B7E0C7CEEF2631448D82498E1B214E48A3844D8B9D9B6D1A7F`.
- Two-pass build: PASS, 72 A4 pages, zero diagnostics. PDF SHA-256 `DB8412C53E4D20E26CFF1AC37147599E1930CEA068B432EA3A304E2271757FE7`; log SHA-256 `76DF6A5F76C8242ED36F149B8497A852B5B27E120C55F1ACDFC022D0AC8337A9`.
- Rendered and personally inspected cumulative page 72. Diagram geometry, hook arrows, flatness labels, base-change formulas, typography, and terminal hard stop PASS.
- Exact next cursor: Lemma 4.7, authority line 2730, scan index 113 / source folio 102.

## 2026-07-31 — English checkpoint 42: Expos\'e VI through Theorem 4.9

- Personally source-aligned Lemma 4.7 with proof, Remark 4.8, and Theorem 4.9 with proof, authority lines 2730--2804 / scan indices 113--115 / source folios 102--104.
- Compared the three complete authority pages at 600 dpi. Reconstructed the deformation-inside-$X_0$ triangle and the two-row ideal/extension diagram natively, preserving all special-fiber conditions, equality bars, and sheaf-Hom identifications.
- Corrected two definite source/working-text defects: the relative cotangent term is $\underline D^1_{Y_0|X_0}$, not the zero-less $\underline D^1_{Y_0|X}$; and the proof of Theorem 4.9 invokes the immediately preceding Lemma 4.7, not the printed Remark 4.6. Restored both base-change terms in the pair-automorphism map.
- Active component: `source\components\43_expose_VI_lemma_4_7_through_theorem_4_9.tex`, 5,041 bytes, SHA-256 `BA0CA15202D8AC0AA671901E64E3839ADC7FD7CD1A2AD500FCD2818838498AFA`.
- Two-pass build: PASS, 74 A4 pages, zero diagnostics. PDF SHA-256 `80CE6AE2DA67D27096C23F4994AC012E304D18AA802B6FDDB95DE03B5C8126FB`; log SHA-256 `8DCCD3B020708E913B94098B1835F93F87C05E9B5A51E3483BA8221534899B33`.
- Rendered and personally inspected cumulative pages 72--74. Both native diagrams, special-fiber maps, sheaf-Hom formulas, automorphism criterion, fiber-product tangent space, and terminal hard stop PASS.
- Exact next cursor: localization-and-completion discussion preceding Theorem 4.10, authority line 2806, scan index 115 / source folio 104.

## 2026-07-31 — English checkpoint 43: Expos\'e VI through Theorem 4.10

- Personally source-aligned the localization/completion discussion and Theorem 4.10 with its complete proof, authority lines 2806--2908 / scan indices 115--118 / source folios 104--107.
- Compared the four complete authority pages directly at 600 dpi. Reconstructed the three-row long exact comparison diagram natively and retained the precise localization/completion functors and completed local rings.
- Corrected definite damaged readings: the second preliminary functor is completion rather than a duplicated localization; the small-extension class lies in $D^1(R|R',k)$; and the vanishing used in the proof is the existing low-degree item 3.12(8), not the printed nonexistent 3.12(11).
- The first rendered checkpoint exposed one dropped backslash that printed the literal word `longrightarrow`. The original r1 build is retained as failed visual history; component 45 was repaired copy-on-write and the r2 render confirms the mathematical arrow.
- Active components: `source\components\44_expose_VI_localization_and_completion_intro.tex`, SHA-256 `E16301A1304AAA10E665CDC15679AF445A1B547872DBAF5F45FAF1E8D484E1F7`; and `source\components\45_expose_VI_theorem_4_10.tex`, 5,550 bytes, SHA-256 `5C01CD0823C7CC1715FF1D8F350F8054BB10B6814F76092C44F3810CEC1BC585`.
- Two-pass r2 build and rendered review: PASS, 76 A4 pages, zero diagnostics. PDF SHA-256 `60C95915754778B88BF564FBA5F1DA522DE057FD0DA4ADA5F53AA6028C4B8136`; log SHA-256 `EBE6D11E59998C1DA500DDF02FB63BDC8918952F7894DC59A0F0C76ED84D0FA6`.
- Exact next cursor: Theorem 4.11, authority line 2910, scan index 118 / source folio 107.

## 2026-07-31 — English checkpoint 44: Expos\'e VI through Corollary 4.13

- Personally source-aligned Theorem 4.11, Remark 4.12, and Corollary 4.13 with their proofs, authority lines 2910--2990 / scan indices 118--121 / source folios 107--110.
- Compared the four complete authority pages directly at 600 dpi. Reconstructed the formal-versal comparison square natively and restored the product signs suppressed in the working transcription's tangent-space sequence.
- Corrected the statement's duplicated $x_0$ subscript to the source-coherent indexed family $x_i$ and retained the separation caveat plus its gerbe-theoretic removal.
- Active components: `source\components\46_expose_VI_theorem_4_11_and_remark_4_12.tex`, 2,781 bytes, SHA-256 `29D1E27FF3ADBAD7DD8F7E91825B9DB3C58FD86542C27B7E23859EA1BBABFD24`; and `source\components\47_expose_VI_corollary_4_13.tex`, 3,427 bytes, SHA-256 `7962DF43841616B3505B450D58C625AAEBACF142644B55D2C2A35AD8B0ED35DA`.
- Two-pass build and rendered review: PASS, 78 A4 pages, zero diagnostics. PDF SHA-256 `980BC40F566A3B22B150686BEF5246494CDAFC169FDE8CD0A1FC7A8122F9F8F8`; log SHA-256 `BFDBEC6BC1BEDDA9DE2FAB0F4A73BA8F93E51D92BC99308DEF9F232015126359`.

## 2026-07-31 — English checkpoint 45: Expos\'e VI section 4 complete

- Personally source-aligned 4.14, Remarks 4.15 and 4.16 through the end of section 4, authority lines 2992--3083 / scan indices 121--125 / source folios 110--114.
- Compared the five authority pages directly at 600 dpi. Preserved the complete-intersection versal construction, the global cotangent-complex classification, the spectral sequence, its low-degree exact sequence, and all three geometric obstruction classes.
- Repaired source-coherent notation without changing the argument: wrote $A_0=S/J$ explicitly; replaced the internally inconsistent $P_{jk}/P_{ji}$ indices by $P_{ij}\equiv p_i(f_j)$ so that $G_j=F_j-\sum_i t_iP_{ij}$ is well-defined; restored arrows in the printed low-degree sequence; and corrected the impossible cross-reference 4.12(b) to Corollary 4.13(b).
- Active components: `source\components\48_expose_VI_4_14_and_4_15.tex`, 3,120 bytes, SHA-256 `80B1143B96F53B1818894D406D9BEEDD2B8CD3934DFC857AB024B110C5996A0B`; and `source\components\49_expose_VI_remark_4_16.tex`, 5,662 bytes, SHA-256 `7650F6FCA9885EF18568E91C21B0E1AF03D1BD8C3290C23BBDACE18780370ED8`.
- Two-pass build: PASS, 80 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `6CD50A06526EABB8D8BB65716BFC5E8AEA07F4ED4F4B4AB69EA06883DE042AE4`; log SHA-256 `A640E2155ED4DB4678A1E7B02DA0687DCC57C4A76C6EB4C6015C1DB3F671979F`.
- Rendered and personally inspected cumulative pages 78--80. The versal construction, index repair, derived-category notation, spectral sequence, obstruction sequence, and terminal hard stop all PASS.
- Exact next cursor: section 5, ``Formal Jacobian subschemes,'' authority line 3085, scan index 125 / source folio 114.

## 2026-07-31 — English checkpoint 46: Expos\'e VI through Definition 5.2

- Personally source-aligned the section 5 opening, all five parts of 5.1, the globalization of Fitting ideals, and Definition 5.2, authority lines 3085--3151 / scan indices 125--127 / source folios 114--116.
- Compared the three complete authority pages directly at 600 dpi. Preserved the exterior-power definition, base change, localization, support criterion, direct-sum formula, adic limit, sheaf globalization, and the Jacobian-subscheme definition.
- Active component: `source\components\50_expose_VI_section_5_opening_through_5_2.tex`, 3,555 bytes, SHA-256 `257A52FB701612304E770D4B50C0D61EE5164B2C834D832601B9EB4300C45E2F`.
- Two-pass build: PASS, 82 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `319C907F62883DA51FB13A624A50BDEAEA6067EBF31D7B764A541B3693603909`; log SHA-256 `5542AB2F2B53CBDBC059491C78E72D6A7DD8A6A7CC77474C7287B35F6F3589D8`.
- Rendered and personally inspected cumulative pages 80--82. The section seam, Fitting-ideal formulas, support and completion formulas, Definition 5.2, and terminal hard stop all PASS.
- Exact next cursor: Theorem 5.3, authority line 3153, scan index 127 / source folio 116.

## 2026-07-31 — English checkpoint 47: Expos\'e VI through Theorem 5.3

- Personally source-aligned Theorem 5.3 and its proof, authority lines 3153--3198 / scan indices 127--128 / source folios 116--117.
- Compared the two complete authority pages directly at 600 dpi and inspected the rendered native diagram at 1,200 dpi. The closed-immersion hook, arrow direction, labels, and terminal proof layout PASS.
- Corrected two definite damaged readings while preserving the argument: restored the Jacobian minor as $\partial f_i/\partial x_j$ rather than the meaningless $f_i/x_j$, and oriented the diagram as the theorem requires, $U\hookrightarrow U'$, rather than the printed/working-text reversal.
- Active component: `source\components\51_expose_VI_theorem_5_3.tex`, 3,471 bytes, SHA-256 `632A637AB05AFB3C017281196725E317C6D33958FDD951A11C8E2032AF563386`.
- Two-pass build: PASS, 83 A4 pages, zero warning/undefined/overfull/underfull/missing-character/fatal/rerun diagnostics. PDF SHA-256 `988CB6549F85F39F2E4DBE203254E56B97E2728256C82B73FAF65CCA7E3ABABC`; log SHA-256 `90D9116253DDEEA0DDA3469CD8EDA6FDA81EA0057A7B4FC213744B61AF6279EC`.
- Rendered and personally inspected cumulative pages 82--83. The theorem statement, all five assertions, the native immersion diagram, Jacobian minor, and terminal hard stop PASS.
- Exact next cursor: Theorem 5.4, authority line 3202, scan index 128 / source folio 117.

## 2026-07-31 — English checkpoint 48: Expos\'e VI through Theorem 5.4

- Personally source-aligned Theorem 5.4 and its proof, authority lines 3202--3244 / scan indices 128--129 / source folios 117--118.
- Compared both complete authority pages directly at 600 dpi. Reconstructed the closed-immersion triangle natively and preserved the flatness, complete-intersection, and Jacobian-ideal argument.
- Active component: `source\components\52_expose_VI_theorem_5_4.tex`, 2,297 bytes, SHA-256 `44F4AEF99BB9AEFD1BB7A0ED82419369824F86E59D2A0E7CB61EC07658654DB0`.
- Intermediate two-pass build: PASS, 84 A4 pages, zero diagnostics. Rendered cumulative pages 83--84; the theorem seam, native triangle, formulas, and terminal hard stop PASS.

## 2026-07-31 — English checkpoint 49: Expos\'e VI through Definition 5.6

- Personally source-aligned Definitions 5.5 and 5.6, authority lines 3246--3312 / scan indices 129--131 / source folios 118--120.
- Compared the complete authority pages directly at 600 dpi and resolved the localization triangle from a targeted 1,800-dpi crop. The authority reads the hatted formal localization $\mathfrak X_{(\widehat{x})}$ with arrow $i_{(\widehat{x})}$; the working transcription's fraktur-$x$ reading was corrected. Restored the coherent module as the inverse limit $\mathcal E=\varprojlim E_\nu$.
- Active component: `source\components\53_expose_VI_5_5_through_5_6.tex`, 3,526 bytes, SHA-256 `CC19F59CB1ACC111C8721F2FEC09A5C2A68649251540DA0FCF48284B01F977ED`.
- A temporary explanatory sentence exposed by the first render was removed from the reader and retained only as a TeX comment. The corrected 85-page build and page 85 render PASS.

## 2026-07-31 — English checkpoint 50: Expos\'e VI section 5 complete

- Personally source-aligned Corollary 5.7, Remark 5.8, Definition 5.9, Corollary 5.10, and Remark 5.11 through the end of section 5, authority lines 3314--3408 / scan indices 131--135 / source folios 120--124.
- Compared the five complete authority pages directly at 600 dpi. Preserved the completed tensor-product/base-change formulas, the two levels of completed differentials, all hatted localizations, and the formal Jacobian-subscheme identities.
- Corrected definite damaged readings: $\mathfrak X'=\mathfrak X\times_S S'$ rather than a self-equality; an equality rather than a stray minus in the connected-component decomposition; and the smooth-locus quotient $\mathcal O_X/\underline I_{X|Y}$ rather than $\mathcal O_X/\mathcal O_{X|Y}$.
- Active components: `source\components\54_expose_VI_corollary_5_7.tex`, SHA-256 `50DD387A8BEEBE826B7049F33F9FE6A87E889BEE6F822CABC205739706EB39EF`; `source\components\55_expose_VI_remark_5_8.tex`, SHA-256 `916784D0FA982FEF8FF3A14DC6BA55A75498B589661132E510C8E4CCB4884731`; and `source\components\56_expose_VI_5_9_through_5_11.tex`, SHA-256 `CED388013A7CDC641475A1F59530E9F7CAFBF3D165FF022C24A96F0234DBA3F7`.
- Two-pass build: PASS, 88 A4 pages, zero diagnostics. PDF SHA-256 `8C9AD94682201F46B39B489C772AAC5D39AE427CCE7B426607BBB7E7AF507607`; log SHA-256 `75A86DB6B323ADDCFE1B48B781570C431CAADBFE17AE98F1CBB92410C6E5526E`.
- Rendered and personally inspected cumulative pages 84--88. The theorem seam, formal-localization triangle, completion formulas, Definitions 5.6 and 5.9, both corollaries, Remark 5.11, and terminal hard stop PASS.
- Exact next cursor: section 6, authority line 3411, scan index 135 / source folio 124.

## 2026-07-31 — English checkpoint 51: Expos\'e VI through Corollary 6.3

- Personally source-aligned section 6 through Corollary 6.3, authority lines 3411--3518 / scan indices 135--138 / source folios 124--127.
- Compared the complete authority pages directly at 600 dpi and used a targeted 1,800-dpi view for the dense algebra in Lemma 6.2. Preserved the non-degenerate quadratic-singularity criterion, completed local-ring construction, and characteristic-dependent normal forms.
- Corrected damaged working readings to the source-coherent forms $x_i^{(1)}$, $X_i$, the ideal $I_R$, $\widehat A=\varprojlim A\otimes_R R_\nu$, the relative derivative $dF$, the equation $F-a$, and $a=ub$.
- Active components: `source\components\57_expose_VI_section_6_opening_and_lemma_6_1.tex`, 3,178 bytes, SHA-256 `5B15599A58BDF7BEBCF1F81277E745CAACB2B761970FC63318A9CD4D8DB46C22`; `source\components\58_expose_VI_lemma_6_2.tex`, 2,816 bytes, SHA-256 `B699C95CE28E729817576152BEDCA619F19483A2118733AB40761B45CF8B474C`; and `source\components\59_expose_VI_corollary_6_3.tex`, 3,076 bytes, SHA-256 `8A8F8EA4E465DFD76007EC0B675EC4D6AE5239FEBC20B3BAD440CAC6B61179E2`.
- The first render exposed same-line component seams. That r1 build is retained as failed visual history; explicit paragraph boundaries were added and the r2 build/render passed.
- Corrected two-pass build: PASS, 92 A4 pages, zero diagnostics. PDF SHA-256 `CDB40324EB3E37BA0D7607051251849B0551A8F848EEAB9089C3C39141433E91`; log SHA-256 `A391E5F2D3DDAE1F25769442BFB9278384C93A378A339267F8CB5F866D15A51E`.
- Rendered and personally inspected cumulative pages 88--92. Section seam, formulas, proof flow, and terminal hard stop PASS.

## 2026-07-31 — English checkpoint 52: Expos\'e VI complete

- Personally source-aligned Theorem 6.4 through Corollary 6.8 and the Expos\'e VI bibliography/end, authority lines 3520--3673 / scan indices 139--143 / source folios 128--132.
- Compared the complete authority pages directly at 600 dpi. Compared the four-node cartesian square in Theorem 6.4 against both authority and rendered reader at 1,800 dpi; its nodes, arrows, directions, lower-label placement, and formal-localization notation PASS.
- Corrected the damaged working text's formal-localization maps, Jacobian variables, character notation, completed node local ring, characteristic-two formula, and several duplicated or misindexed symbols. The printed formula following $F=f+t_1+tX_0$ reads $dF=df+dX_0$; the English transparently restores the mathematically forced coefficient $dF=df+t\,dX_0$, since the next ideal explicitly contains $t$.
- Active components: `source\components\60_expose_VI_theorem_6_4_through_part_4.tex`, 4,361 bytes, SHA-256 `2C56810AA8E9A994EE13E7E4B2AB8CD56B7195ED9D5BEC1759FDBD13BE627019`; `source\components\61_expose_VI_theorem_6_4_part_5_and_remark_6_5.tex`, 3,636 bytes, SHA-256 `ABF43F77ADC42CF8F41F03E9CF033BE605988AE111A23223BD6ABA0FD12FA88B`; and `source\components\62_expose_VI_6_6_through_6_8.tex`, 4,092 bytes, SHA-256 `62435B4D9F8E9010559068A69F0FA7B9F269EEB471CF0D0F6664E9DDF119C2A2`.
- Two-pass build: PASS, 96 A4 pages, zero diagnostics. PDF SHA-256 `A81A591A9E040EB2E5E7DF0A0B2600959EAF2B91F9C5740A70D59E4E7840FCB7`; log SHA-256 `4D553CA6F966AFD47066A9BBCF9E3894A7B180A6441FD11A1E1C96EA95DC1F33`.
- Rendered and personally inspected cumulative pages 92--96. All formulas, the native square, bibliography, expos\'e ending, and terminal hard stop PASS.
- Exact next cursor: Expos\'e VII title and introduction, authority `source\expose_VII_body.tex` line 5 (prose line 17), scan index 144 / source folio 133.

## 2026-07-31 — English checkpoint 53: Expos\'e VII through 1.3.8.2

- Personally translated and source-aligned Expos\'e VII from its opening through 1.3.8.2, authority lines 5--418 / scan indices 144--165 / source folios 133--154 (last folio partial). The active cumulative reader now has continuous written-expos\'e coverage from I through II, VI, and VII 1.3.8.2.
- Compared all authority pages in this range directly at 600 dpi. The associativity diagram at 1.1.4 and the birigidification square in 1.2 were separately checked from 1,800-dpi crops for node, arrow, label-side, and attachment fidelity.
- Corrected source/transcription defects only where mathematical context decides them: recurring $P_p/E_p$ slips; induced-topos and base-change notation; the Proposition 1.3.5 opening variable $Q/G$ mismatch; the torsor/bitorsor mismatch in 1.3.5(b); the three associativity specializations required by the proposition's own hypothesis; and the truncated references 3.5/3.6 to 1.3.5/1.3.6. The French authority remains unchanged.
- Latest components: `source\components\68_expose_VII_1_3_4.tex`, 2,339 bytes, SHA-256 `A7AC17BD0D6B5B18C975C01792C18A24512EE272C9BBD694190A267A27288EDB`; `69_expose_VII_proposition_1_3_5.tex`, 5,718 bytes, SHA-256 `C6BD8D2A91B4D45F4D9BC71853D7DAF5BE9E591BF5E85C78C42DB23FC61805A9`; `70_expose_VII_1_3_6_through_1_3_7.tex`, 3,474 bytes, SHA-256 `38D44ED16F44DB044D103AEBF97BD40E6D8D5850D5B6994344CBB4A6CD0058DB`; and `71_expose_VII_1_3_8.tex`, 2,889 bytes, SHA-256 `76D2696C05295878142B4D17CB659F04D9C62F5FC75E1466211B8F5D1128281B`.
- Two-pass build: PASS, 106 A4 pages, zero diagnostics. PDF SHA-256 `7406E1D7A2A33EAAE6F271D9806413BFB19943A704D1BB16A2F9D8F0BD2DB8F8`; log SHA-256 `D3F8EEF4E0703A017771B16D7070614EB7686CEAF66E40AEFF561EB097EF6F36`.
- Exact next cursor: Expos\'e VII section 1.4, authority line 421, scan index 165 / source folio 154.

## 2026-07-31 — English checkpoint 54: Expos\'e VII through Remark 2.4.3

- Personally translated and source-aligned section 1.4 and sections 2.0--2.4 through Remark 2.4.3, authority lines 421--773 / scan indices 165--176 / source folios 154--165.
- Compared the complete authority pages directly at 600 dpi. The five extension/biextension diagrams (2.0.5)--(2.1.1) were separately checked from direct 1,800-dpi scan crops for every node, arrow, direction, label, prime, and attachment.
- Corrected transparent source/transcription defects where the surrounding definitions and displayed laws decide the reading: the $\varphi$ and $\psi$ extension directions and identity-section loci; the target $E_{p,qq'}$ in (2.0.7); the missing prime in (2.0.5); the inverse image in $E$ rather than $G$ in 2.2; $(P,Q)$ rather than $(P,G)$ in the cofibred construction; and $\operatorname{BIEXT}(P,Q;G\times G')$ rather than the repeated wrong second argument in (2.4.2). Component headers preserve each disposition.
- Active new components: `72_expose_VII_section_1_4.tex`, SHA-256 `8BF5115AF1E74DB69F4B64C70C7D0C91B9DE50FC78FC04CB81BE10ECC7A7F8DB`; `73_expose_VII_section_2_0_phi.tex`, SHA-256 `368F9A15045BD08D3B44C5C4FFB92488C184D072839BE96ABEB5CBDB3A2A46C3`; `74_expose_VII_psi_and_definition_2_1.tex`, SHA-256 `08A9A5904F91140EA2E406B5031A15428142D4BB10871E4AB7BA09F5DD73C636`; `75_expose_VII_section_2_2.tex`, SHA-256 `4063215E544D02933A0F22F857BB844BBB8BE5A7EECDBA2AA3D89CD53A3A0E5C`; `76_expose_VII_section_2_3.tex`, SHA-256 `93EF2C898DEFBE107124210E168A7718C33CE3D2B9EA483EEC1E5E9FAFDA23DF`; and `77_expose_VII_section_2_4.tex`, SHA-256 `F0F8C08C563CE912716B3B4B056AF5CB0E4084B82B27DCF5FA7F44503C2E6C32`.
- Two-pass build: PASS, 111 A4 pages, zero error/undefined-reference/overfull/missing-character diagnostics. PDF SHA-256 `7BEAC23B408310CD6C23CF14F2927F5F42E3B8F2100DD9CFD136632686AD731B`; log SHA-256 `F772928C4DCCF63B1B2E683C0BD5695558EF2D8386F4C663713B99B06B7F5FF1`.
- Rendered and personally inspected cumulative pages 106--111 at 300 dpi for reader layout. All formulas, native diagrams, underlining, list indentation, section seams, and terminal hard stop PASS.
- Exact next cursor: Expos\'e VII section 2.5, authority line 776, scan index 176 / source folio 165.

## 2026-07-31 — English checkpoint 55: Expos\'e VII section 2 complete

- Personally translated and source-aligned sections 2.5--2.10.3, authority lines 776--1007 / scan indices 176--190 / source folios 165--179.
- Compared physical authority pages 177--191 directly at 600 dpi. Preserved the multiplicative structure on biextensions, the additivity constraints, the contracted-product construction, all compatibility laws, and the categorical equivalences through the end of section 2.
- Active components 78--83 have SHA-256 identities `D0376C18F759D3BD3FBDA2EBDFF45DEE40B5B4C2B4B58A92487D3A115A75B98A`, `10427C8C8B4D308F0983BFC68BAE8251E89DB04F23BBBA9481C30C0B970F9D05`, `63A99B96C2ECF570AA03D523E86283C13C05DBC3B70578D70C8827A9EB8C5941`, `00C9FACD56B51B3B53EB513B02A3623D6B2F2EC19A1593D77F5298EBEE8F5CFD`, `E5538D5E632456838B448C857DC561E634251FD4F283CBC3E70238EDCFE17FC3`, and `1D0EF78A87AB1CC32987017662BFF18315A11BA1706384E099B8E0A2A4F3E21F` respectively.
- Two-pass build and rendered review: PASS, 116 A4 pages, zero diagnostics. PDF SHA-256 `65BC2A1E40117745E722613EE441ED6C0657F992DD0B60E4CCD4AB4F0C3BBEAB`; log SHA-256 `FE8CF16202EDFD7A79FF184E896DA12858AF806EE1A62EAA6EF9F4F5FC3D649B`.

## 2026-07-31 — English checkpoint 56: Expos\'e VII through 3.1.9

- Personally translated and source-aligned the section 3 opening and all of 3.1, authority lines 1010--1110 / scan indices 190--194 / source folios 179--183.
- Compared physical authority pages 191--195 directly at 600 dpi. Checked diagram (3.1.3) node-by-node and arrow-by-arrow; its seven nodes, six arrows, labels, direction, and diagonal attachment agree with the authority.
- Transparently normalized the typewritten letter-$o$ subscripts to zero and corrected the impossible prose reference 3.1.7.1 to the displayed isomorphism (3.1.8).
- Active component `84_expose_VII_section_3_1.tex`: 6,698 bytes, SHA-256 `589D16E17672450B8D9EA6DD67EF3F3C3482D5B3B23E0886CBFCDE1CD395C230`.
- Two-pass build and rendered review: PASS, 118 A4 pages, zero diagnostics. PDF SHA-256 `7B4A0D6AE9BB18EC134D0F85C5EABEF5DC543C41F4F575DD720242672728905B`; log SHA-256 `A3DF30BF8DB21FB3ACF40D1C67811E18ED851EE982334130DB464601CB1BA9A5`.

## 2026-07-31 — English checkpoint 57: Expos\'e VII through Theorem 3.2.5

- Personally translated and source-aligned all of section 3.2, authority lines 1116--1243 / scan indices 194--197 / source folios 183--186.
- Compared physical authority pages 195--198 directly at 600 dpi. Checked all three native diagrams, (3.2.3), (*), and (3.2.5.2), for exact nodes, arrows, directions, labels, label sides, and omitted ellipsis arrows.
- Preserved the two distinct printed displays both numbered (3.2.3). Transparently normalized typewritten letter-$o$ subscripts to zero and corrected the injectivity conclusion's certain $j/s$ slip to the morphism $s:L_0\to X$ required by (3.2.5.1).
- Active component `85_expose_VII_section_3_2.tex`: 6,362 bytes, SHA-256 `9C01BF410113941CE140B6AD084102890A0B92E17D0AA1C3365BC97A18072369`.
- Converged build and rendered review: PASS, 120 A4 pages, zero diagnostics. PDF SHA-256 `AB2EE163B8EE02CDD76205B9C3FCD478389629C9E44B2D86C5D5C62BED5FC5CE`; log SHA-256 `3E1D7407B412C61823F86298503E8AE95C417AF084913B1351C44E2F8ADB200A`.
- A PowerShell interpolation error initially directed generated files to a literal `$build` directory under `source`; the generated files were moved to the intended checkpoint, the empty accidental directory was removed, and a fresh correctly targeted pass reproduced the clean reader. No source file was affected.
- Exact next cursor: Expos\'e VII section 3.3, authority line 1246, scan index 197 / source folio 186.

## 2026-07-31 — English checkpoint 58: Expos\'e VII section 3.4 complete

- Personally translated and source-aligned sections 3.3 and 3.4 through Remark 3.4.9.2, authority lines 1246--1542 / scan indices 197--209 / source folios 186--198.
- Compared physical authority pages 198--210 directly at 600 dpi. The native diagrams (3.3.2.1), (3.3.3.1), (3.4.2), (3.4.6), and the 21-node/27-arrow diagram in 3.4.8 were checked against the scan. The dense diagram's apparent second head on the $X'$--$L'_0$ diagonal belongs to the crossing $\alpha'$ arrow; the English correctly encodes the single source morphism $j':X'\to L'_0$, not the working transcription's bidirectional arrow.
- Transparent source corrections include the internal references 3.2.3 to 3.3.2.1, the canonical injection $i$ in place of a stray $j$, the missing boundary symbol $\partial$, the anticommutativity reading, the object subscript in $0_{L_\bullet,A}$, the defining relations with $j'$, the concluding category $\underline\Psi_{L''_\bullet}$, and the missing comma in $\Ext^0(L'_\bullet,A)$.
- Active components: `86_expose_VII_section_3_3.tex`, 11,712 bytes, SHA-256 `CFE019B8FB2C63440F7D2EB3D5440525E3127968A712C654C92D0C5A8B4A047C`; `87_expose_VII_section_3_4_opening_through_3_4_7.tex`, 4,067 bytes, SHA-256 `8907F196C64F13B2DBC84B6FC99500DA0AB4CF2733CFBB09C8CD775B02D003FF`; and `88_expose_VII_sections_3_4_8_and_3_4_9.tex`, 10,141 bytes, SHA-256 `EB3AC95451694684F0168412A9E7429C9370251F7066F8A2D878E6BEA5690381`.
- Two-pass build: PASS, 125 A4 pages, zero diagnostics. PDF SHA-256 `B7844DE2B3A5136E7EFAFAAFD508A1B43CDBA1B6F2A21F97A440693156B697CE`; log SHA-256 `1CECB0EF6DA65352829C45D86F791AED7B9BEA927AC173B2055010C88B4A7B0C`.
- Rendered and personally inspected cumulative pages 123--125. The section seam, all formulas, dense native diagram, exact sequence, sign remark, and hard stop before section 3.5 PASS. The first diagram render placed $\alpha'$ and $\alpha''$ too low; the r2 source moves both labels toward their arrowheads and the corrected render passes.
- Exact next cursor: Expos\'e VII section 3.5, authority line 1545, scan index 209 / source folio 198.

## 2026-07-31 — English checkpoint 59: Expos\'e VII section 3.5 complete

- Personally translated and source-aligned all of section 3.5, authority lines 1545--1662 / scan indices 209--214 / source folios 198--203.
- Compared physical authority pages 210--216 directly at 600 dpi. The augmented-complex diagram (3.5.1), the functorial square, all differential formulas, the torsor dictionary, the $A$-module variant, and the Breen editor's note were checked against the scan.
- Transparently restored the printed $L_2$ overbrace in (3.5.1), normalized typewritten letter-$o$ subscripts to zero, wrote the chain relation coherently as $d_0d_1=0$, and restored the scan's omitted $(*)$ display tag used throughout the proof.
- Active component `89_expose_VII_section_3_5.tex`: 8,151 bytes, SHA-256 `D4DDC419FEAC2626DEB4B5BC5CA7E81B109C80E4CC835E8D260E2E52A860AB21`.
- The first visual build exposed three escaped-command losses that TeX accepted as prose: literal `overbrace`, `qquad`, and `longrightarrow`. The r1 build is retained as failed visual history; all three exact commands were restored before r2.
- Corrected two-pass build and rendered review: PASS, 128 A4 pages, zero diagnostics. PDF SHA-256 `31C1D13B454CEE296DF55C28E60EBF15A39D3E2E129FAD22C23C50815A7118C2`; log SHA-256 `2AFD4A63859948F141CC2115FBD60A094D0A4F0129C3C76C8F628EE8BD48F2FF`.
- Rendered and personally inspected cumulative pages 126--128. Both native diagrams, formulas (3.5.1)--(3.5.6), footnote placement, prose flow, and hard stop before section 3.6 PASS.
- Exact next cursor: Expos\'e VII section 3.6, authority line 1668, scan index 215 / source folio 204.

## 2026-07-31 — English checkpoint 60: Expos\'e VII through section 3.7

- Personally translated and source-aligned all of sections 3.6 and 3.7, authority lines 1668--1804 / scan indices 215--223 / source folios 204--212.
- Compared physical authority pages 216--224 directly at 600 dpi. Checked the section-3.7 square (3.7.2), both exact sequences, all boundary arrows, Proposition 3.7.5, and its proof against the scan.
- Transparent corrections in section 3.6 restore the complex \(L'_\bullet(P,Q)\), the extension \(L_0(P,Q)\), the map targets \(P\times Q\times Q\to P\times Q\), the extension of \(P_Q\) by \(G_Q\), and zero subscripts. Section 3.7 likewise normalizes typewritten letter-\(o\) superscripts to zero while preserving the printed covariant third factor in the proposition.
- Active components: `source\components\90_expose_VII_section_3_6.tex`, 8,217 bytes, SHA-256 `27FEB91DFA19B0B7FFF3148243611B3E918B0126DE6F22F9E0D860C826B9EC7A`; and `source\components\91_expose_VII_section_3_7.tex`, 6,909 bytes, SHA-256 `50A9BE4C8E6CF2AF979C4D70E98D6C6C4B3F2F53B5CABF4B2221057646869F7B`.
- The first section-3.7 render exposed three escaped-command losses that TeX had accepted as prose: one literal `qquad` and two literal `longrightarrow` strings. That r1 remains failed visual history; the commands were restored and r2 rebuilt.
- Corrected build and rendered review: PASS, 131 A4 pages, zero diagnostics. PDF SHA-256 `C00F34D8BF22AD71FFA8BA3C0EE964F3BCAA86BFA115DFD3142A2E6E943C534F`; log SHA-256 `8BF8D282556DD7327461FF866CAA8D137DA16C5A36B5D2CA9DDF6988E77A0954`.
- Rendered and personally inspected cumulative pages 128--131. Section seams, formulas, native square, exact sequences, proposition underlining, proof flow, and hard stop before section 3.8 PASS.
- Current master SHA-256: `34D94726B136A28D4A6517ABF3BFAEABC79D18B593F90876BEF516D8C70FCE27`.
- Exact next cursor: Expos\'e VII section 3.8, authority line 1810, scan index 223 / source folio 212.

## 2026-07-31 — English checkpoint 61: Expos\'e VII complete

- Personally translated and source-aligned all of section 3.8 and the complete six-item bibliography, authority lines 1810--1977 / scan indices 223--228 / source folios 212--217.
- Compared physical authority pages 224--229 directly at 600 dpi. Checked the native triangle (3.8.2), both resolving complexes, the tensor-product complex, every derived-category arrow, and formulas (3.8.1)--(3.8.13) against the scan.
- Preserved the authority's direction in (3.8.10), from the cohomology of the Hom complex to the derived Ext group; the inherited abridgment had reversed this arrow. Typewritten letter-$o$ subscripts were transparently normalized to zero.
- Active component `source\components\92_expose_VII_section_3_8_and_bibliography.tex`: 9,664 bytes, SHA-256 `0A2773CB5FEC7952D8CD0F24A56D085179875B5927E302ECA30F2EDD4A0AA6B4`. Current master: 7,417 bytes, SHA-256 `33B8F9996A4C7B841E04EC3D6A5CC6EF80A35C45AA8D4EDF5D2AE9EC81372742`.
- The first render exposed two presentation defects: the $u\times v$ label was on the wrong side of its arrow, and `\Hom^\bullet` produced an oversized superscript. The r1 build is retained as visual-fail history; r2 places the label as printed and uses the source-faithful small degree dot.
- Corrected two-pass build: PASS, 134 A4 pages, zero diagnostics. PDF SHA-256 `2D37D3F19500ECE58FEA2182E33D6695D7A742093D6EFE3F01C91415031D1CCC`; log SHA-256 `9C15070ECEDE5D56F282A95BBDB31C9EEBAD60F2E322751F66F8D930C0CD380B`.
- Rendered and personally inspected cumulative pages 132--134 at 600 dpi. The diagram, formula typography, proposition underlining, bibliography, Expos\'e-VII ending, and hard stop all PASS.
- Exact next cursor: Expos\'e VIII title/opening, authority `source\expose_VIII_body.tex` line 5, scan index 229 / source folio 218.

## 2026-07-31 — English checkpoint 62: Expos\'e VIII through Remark 2.1.14

- Personally translated and source-aligned the Expos\'e VIII title, introduction, all of section 1, and section 2 through Remark 2.1.14: authority `source\expose_VIII_body.tex` lines 5--675 / scan indices 229--248 / source folios 218--237. The last folio is partial because section 2.2 begins on the same authority page.
- Compared physical authority pages 230--249 directly at 1100 dpi. Ordinary prose, formulas, and page seams were legible at that level. For the dense six-node diagram (2.1.14.6), extracted the one-page vector witness and personally inspected six overlapping targeted crops at 5000 dpi, covering every node, arrowhead, attachment, label, label side, quotient, and terminal punctuation. This avoided rendering a full 5000-dpi page and its attendant memory spike.
- Transparent source dispositions include: neutralizing the impossible blanket-Tor-vanishing wording in the introduction; restoring `Hom(Q,P)` and several object/coefficient slips; normalizing typewritten letter-$o$ homological indices to zero; repairing the internal reference 1.3.4 to 1.3.5; restoring the second biextension argument; replacing the impossible map ${}_nP\to Q$ by ${}_nP\to P$; restoring the two-argument Tor formula; repairing 2.11.1/2.11.2 to 2.1.11.1/2.1.11.2; rendering the authority's contradictory ``injective isomorphism'' as ``injective homomorphism''; and restoring the missing second `pq` in the target numerator after (2.1.14.6), as required by multiplication by `pq` and the printed diagram.
- Active components and exact identities:
  - `93_expose_VIII_opening_and_introduction.tex`: 4,359 bytes, SHA-256 `94FF7AA35F08D786F7258F8F803F7403D47D0EC014109FEE2137216C79D82E72`.
  - `94_expose_VIII_section_1.tex`: 11,005 bytes, SHA-256 `C9CF280AAF2F483AEDFDAA62A14E8706AF1FCD967A9D16189BC91E630C3EF28C`.
  - `95_expose_VIII_section_2_1_opening_through_2_1_8.tex`: 6,701 bytes, SHA-256 `FB656FA4253F3F76CB9687D39CE932E7BE2D380923E38EF9E909356F4CD89798`.
  - `96_expose_VIII_section_2_1_9_through_2_1_12.tex`: 7,221 bytes, SHA-256 `95E143B76630E2875EEFD6AE87261A74EA25A74186E36B8EC8B4A9C22329BBFC`.
  - `97_expose_VIII_section_2_1_13_and_remark_2_1_14.tex`: 7,765 bytes, SHA-256 `BE7BE7F3E460CE539EF2EE36E85C3BF86797BAFB31EE48EBA2D2CD335C3564DA`.
- Three-pass build: PASS, 145 A4 pages, zero logged warnings/errors/overfull/underfull diagnostics. PDF 1,188,887 bytes, SHA-256 `8DB286E4391EACAAA7CB89CBCF76D5DAD189309BA6453F229DD227E94225A7AA`; log SHA-256 `7FE3DCAAECFB3D23B2D8309BA54465A967C67FC667BA06C975AC7C280733C1CB`.
- Rendered and personally inspected the final cumulative pages 143--145 at 600 dpi after successive earlier section checkpoints. The inverse-system formulas, both anticommutative squares, exact sequence, six-node native diagram, label placement, quotient typography, prose flow, and hard stop all PASS.
- Current master: 7,839 bytes, SHA-256 `C63F1667FA2AF684DFB89A61B4CE1F1DEC1BF0F918D7F6AC503CE003CAEDB9FF`.
- Exact next cursor: Expos\'e VIII section 2.2, authority line 676, scan index 248 / source folio 237.

## 2026-07-31 — English checkpoint 63: Expos\'e VIII through section 3.3

- Personally translated and source-aligned sections 2.2, 2.3 in full, 2.4, and sections 3.1--3.3 through Remarks 3.3.3--3.3.4: authority `source\expose_VIII_body.tex` lines 676--1481 / scan indices 248--270 / source folios 237--259. The terminal folio is partial because Proposition 3.4 begins on the same authority page.
- Compared physical authority pages 249--271 directly in overlapping 1,100-dpi bands. For the ambiguous $f_0/f_1$ component in the proof of 2.3.11 and the dense homotopy/derived-Hom diagrams in 2.3.19, used targeted 5,000-dpi-equivalent crops covering the disputed glyph and every node, arrow, label side, attachment, sign mark, and punctuation. Ordinary prose and formulas were fully legible at 1,100 dpi, so no needless higher-resolution whole-page renders were made.
- Transparent source dispositions include: restoring the image of $\alpha^n_{P,Q}$ and the cited pairings in 2.2.7; repairing the right vertex of (2.3.10); the proof-number, minus-sign, and zero-index slips in 2.3.11; the type-correct $f_0$ on the degree-one diagram; the pairing subscript in 2.3.17; preserving the circled unresolved ``$-?$'' in 2.3.19; and restoring $D(T)$ as the terminal dual of $0\to T\to M\to L\to0$ while declining to invent the visibly blank citation after SGA 3 X 4.9.
- Active components and exact identities:
  - `98_expose_VIII_section_2_2.tex`: 8,622 bytes, SHA-256 `5E21063DB7D5D60B415820D012022D91847B6DA0672C8AE0B1B1BF3DF40B6FFD`.
  - `99_expose_VIII_section_2_3_opening_through_proposition_2_3_11.tex`: 4,017 bytes, SHA-256 `04605A500F3C9C2C06D2D34D9E4BAABB890765B2C112839BF60C599CF653DB38`.
  - `100_expose_VIII_proof_2_3_11_parts_a_and_b.tex`: 4,798 bytes, SHA-256 `547344001003DA2CD418FCC08EB4B51B7408A8F7A56C243575C641861676DC92`.
  - `101_expose_VIII_proof_2_3_11_parts_c_through_e_and_remark_2_3_16.tex`: 7,064 bytes, SHA-256 `4360D286739C930F4DDC6011DD53C163BEECA9780D0C6D628F1554CF796E4D6F`.
  - `102_expose_VIII_section_2_3_17.tex`: 3,479 bytes, SHA-256 `0EF5234A6727FB95FAB57A877C87F064ABAEE67A073CC438E365674605691033`.
  - `103_expose_VIII_alternative_proof_2_3_19.tex`: 2,904 bytes, SHA-256 `C250997932F114093FD9B7F8537661494ECFCE1EE2F4359E649006DC22795D66`.
  - `104_expose_VIII_section_2_4.tex`: 1,515 bytes, SHA-256 `9BC779BE3F18E2E3CAE9F8041441DF9D19854053EA4BEF462013925AF4715B6F`.
  - `105_expose_VIII_sections_3_1_and_3_2.tex`: 3,258 bytes, SHA-256 `8E998DBBC3F49951222F6009FFB2CE04F541A8B71732E522D5FA202FA41C8FB3`.
  - `106_expose_VIII_section_3_3.tex`: 6,523 bytes, SHA-256 `EB4D8690B9B5E3C7A61BDF56FF919832350693F9A11B9B2A80735BDE997197B0`.
- Three-pass build: PASS, 157 A4 pages, zero logged warning/error/overfull/underfull/missing-character diagnostics. PDF 1,258,275 bytes, SHA-256 `A377D43C480307E6E8FDD473B1134A53FD64554F6534F178C5748114D0B54E0D`; log SHA-256 `DE0B4F48CEDC192916C189C4B546090E72DBAB75154F4C15037F288C82551ACF`.
- Rendered and personally inspected all newly affected cumulative pages through page 157 at 600 dpi. The native diagrams, theorem register, underlining, exact sequences, subscripts, formula punctuation, page breaks, and hard stop before Proposition 3.4 PASS.
- Current master: 8,372 bytes, SHA-256 `32ED78ADF609714B4FB84400B1AA0ABD27EC0F22B20E6AF7D34BBEA97B6D4A85`.
- Exact next cursor: Expos\'e VIII Proposition 3.4, authority line 1483, scan index 270 / source folio 259 / physical PDF page 271.

## 2026-07-31 — English checkpoint 64: Expos\'e VIII through Proposition 3.7

- Personally translated and source-aligned Proposition 3.4, Lemma 3.4.2, Corollary 3.5, Remark 3.6, and Proposition 3.7: authority `source\expose_VIII_body.tex` lines 1483--1553 / scan indices 270--275 / source folios 259--264.
- Compared physical authority pages 271--276 directly in overlapping 1,100-dpi bands. Ordinary prose, primes, homological degrees, and formulas are clear at that resolution; there was no real ambiguity requiring a 5,000--9,000-dpi escalation. This implements the standing variable-resolution rule rather than treating either low or extreme DPI as a ritual threshold.
- Transparent source dispositions: the printed proof phrase asking for a section of $P$ over $P$ is rendered as the mathematically required section of the extension $E$ over $P$; formula (3.6.2) has $\Biext^i$ on both sides, consistent with $i=0,1$ and the asserted equivalence; and the cyclic reduction in 3.7 is written $M=\mathbb Z/n\mathbb Z$, not the printed `Z=Z/nZ` slip. The French authority files remain unchanged.
- Active components: `107_expose_VIII_section_3_4.tex`, 5,336 bytes, SHA-256 `B8E109210FEFDB7D1E2598D0F50A26274CDDB17A46C9760D5534DC87810CA563`; and `108_expose_VIII_sections_3_5_through_3_7.tex`, 5,403 bytes, SHA-256 `141DDA968653366A6D39C935A0679EB6318717C4E23D3D2E7DC6FFE47D96796D`.
- Three-pass build: PASS, 160 A4 pages, zero logged warnings/errors/overfull/underfull/missing-character diagnostics. PDF 1,277,083 bytes, SHA-256 `52F65D358E1F4ADCDD947D8993E98AD395E986CBFE1AB6FB6C3711574B01D2FA`; log 41,192 bytes, SHA-256 `C4010657D5451CAC240AECAA373204A043B53CE9239B1877B3DC5CDBA5CD9E78`.
- Rendered and personally inspected cumulative pages 158--160 at 600 dpi. The proposition/lemma register, underlining, exact sequences, category arrows, tensor notation, page breaks, and hard stop before section 4 all PASS.
- Current master: 8,479 bytes, SHA-256 `89F8F81E122829C86ADB9EB8C93895A7EC8FA6417B156081C425E0EE1A4D5EE3`.
- Exact next cursor: Expos\'e VIII section 4 and Lemma 4.1, authority line 1559, scan index 276 / source folio 265 / physical PDF page 277.

## 2026-07-31 — English checkpoint 65: Expos\'e VIII through Corollary 4.10

- Personally translated and source-aligned sections 4.1--4.10, authority `source\expose_VIII_body.tex` lines 1559--1696 / scan indices 276--284 / source folios 265--273.
- Compared physical authority pages 277--284 directly in overlapping 1,100-dpi bands. Ordinary prose, formulas, primes, and subscripts are fully legible there; no actual ambiguity required a 5,000--9,000-dpi escalation. This follows the standing variable-resolution rule: use enough source detail to decide the reading, not a fixed extreme resolution for every page.
- Transparent source dispositions: Proposition 4.2 uses the newly introduced line bundle $\mathbb L$ in its three pullbacks rather than the printed $P$; the second case of Proposition 4.6 uses the type-correct base $P\times B$ and identity section $P\times e_Q$; and Corollary 4.8 retains the authority's displayed $\Biext^i(P,M;\underline G_m)$ while explicitly explaining how (4.7.1) identifies these with the $A,M$ groups required by the exact sequence.
- Active components: `109_expose_VIII_sections_4_1_through_4_4.tex`, 3,774 bytes, SHA-256 `DB7DDB8B1A1F2CC99F08857AE3A24AC72ACC7919E7F5BA2B57793E3916FAF7FD`; `110_expose_VIII_sections_4_5_and_4_6.tex`, 4,996 bytes, SHA-256 `8B67123FD5729C601520BF611D4471EE4CB8BF8199B29AC35073D2E8D8A2414B`; and `111_expose_VIII_sections_4_7_through_4_10.tex`, 6,178 bytes, SHA-256 `5740FA1DD549DC3BF525B1045535FAD235789B4B79F0A256014E232A19647488`.
- Three-pass build: PASS, 163 A4 pages, zero logged warnings/errors/overfull/underfull/missing-character diagnostics. PDF 1,305,315 bytes, SHA-256 `7AD05CB12C52193E93E3A7644BE2879CBB5115DEC3DB1D507FEC7A13A8DE9E7E`; log 41,385 bytes, SHA-256 `4ACCBBD4D3B92FC6B6677558556D94E0CAC3896544BEE3964FD9DC98EBF6015B`.
- Rendered and personally inspected cumulative pages 161--163 at 600 dpi. The theorem register, underlining, category arrows, exact sequences, Picard notation, Tate-module pairings, prose flow, and hard stop before 4.11 all PASS.
- Current master: 8,656 bytes, SHA-256 `8B6EB415D3C4D928C2D69EC24705A635C5AF4F78DAB328795D394592F295A064`.
- Exact next cursor: Expos\'e VIII section 4.11, authority line 1701, scan index 284 / source folio 273 / physical PDF page 285.

## 2026-07-31 — English checkpoint 66: Expos\'e VIII section 4 complete

- Personally translated and source-aligned sections 4.11--4.14 through the section-4 endpoint, authority `source\expose_VIII_body.tex` lines 1701--1799 / scan indices 284--289 / source folios 273--278.
- Compared physical authority pages 285--290 directly in overlapping 1,100-dpi bands. The Tate-module formulas, primes, kernels, arrow directions, Picard pullback, and Neron--Severi formulas are fully legible at that resolution; no actual ambiguity required a 5,000--9,000-dpi escalation.
- Transparent source dispositions: repaired the impossible reference (1.11.1) to (4.11.1); in 4.12 restored the canonical quotient $f:P\to A$, the resulting pullback $\Pic(A)\to\Pic(P)$, the relation $\mathbb L\simeq f^*\mathbb M$, and the fact that $\mathbb M$ lives on $A$; and in the final sentence of 4.14 cited the applicable map (4.14.2), not (4.14.1). The French authority remains unchanged.
- Active components: `112_expose_VIII_section_4_11.tex`, 4,452 bytes, SHA-256 `C014DFF0B4022E6A07B8B6A52F0AFD06C795E5F361B45E91C46568BDDE0024BE`; and `113_expose_VIII_sections_4_12_through_4_14.tex`, 5,737 bytes, SHA-256 `D756FEBBB341FE8DAB63EF2E5A1EB6CDA9473191E223A5C0AAD5AF49B9EAE2BF`.
- Three-pass build: PASS, 166 A4 pages, zero logged warnings/errors/overfull/underfull/missing-character diagnostics. PDF 1,318,248 bytes, SHA-256 `2B24BCA71BCE54002E9FC07D908AE77D380C45CEB5FF8A85B8FAA887102C8A11`; log 41,527 bytes, SHA-256 `7614B0E81A5F07E40A4F076A7C5D0B07F1E528C069981932D643FEF79F18956F`.
- Rendered and personally inspected cumulative pages 164--166 at 600 dpi. All six numbered displays in 4.11, the pullback formulas, theorem underlining, symmetry statements, Neron--Severi maps, page breaks, and hard stop before section 5 PASS.
- Current master: 8,766 bytes, SHA-256 `334D3D1C91E0F5486C019521D5FD58ACADFE0656B3B0FB6A1E7ACA1CEB01CD85`.
- Exact next cursor: Expos\'e VIII section 5 and Proposition 5.1, authority line 1800, scan index 289 / source folio 278 / physical PDF page 290.

## 2026-07-31 — English checkpoint 67: Expos\'e VIII section 5 complete

- Personally translated and source-aligned all of section 5, authority `source\expose_VIII_body.tex` lines 1800--1974 / scan indices 289--298 / source folios 278--287.
- Compared physical authority pages 290--299 directly in overlapping 1,100-dpi bands. Ordinary prose, formulas, arrows, and subscripts were fully legible; no actual ambiguity required higher resolution.
- Transparent source dispositions include: restoring $Z_S$ and $Z$ in Proposition 5.1; restoring the source category of Corollary 5.2 to torsors on $P$ under $Z_P$ and the terminal generic fibre to $P_{i\eta}$; restoring $Z,Z_k$ and the finite-type example $P$ in Proposition 5.5; reading $\Phi,\Psi$ as groups of connected components in Corollary 5.6; correcting printed (2.7.2) to local (5.7.2); and restoring $Z_{S,T}$ in 5.8--5.9.  The French authority files remain unchanged.
- Active components: `114_expose_VIII_section_5_opening_through_5_6.tex`, 10,888 bytes, SHA-256 `1CE86BFCD805197A6E752944FD1288FD986F26F380DC1A0F1070CF3241C70D69`; and `115_expose_VIII_sections_5_7_through_5_10.tex`, 4,988 bytes, SHA-256 `81BD361A901C2F4DEEC5FDCB1193A6DCCA821EACEC7904F7DA5EF0699E0B857B`.
- Three-pass build: PASS, 170 A4 pages, zero material diagnostics. PDF 1,351,012 bytes, SHA-256 `23F8633D9A59DA2FE072F49D8D10D7E9B201CF8A980A920FF60F38A65394FAC7`; log SHA-256 `96ECB0A9D51B2C973523573E5EC2E37F1D5C930A16221A3544FD5CEA4F08206A`.
- Rendered and personally inspected cumulative pages 166--170 at 600 dpi. The theorem register, exact sequences, quotient notation, underlining, page breaks, and hard stop before section 6 PASS.
- Exact next cursor: Expos\'e VIII section 6, authority line 1976, scan index 298 / source folio 287 / physical PDF page 299.

## 2026-07-31 — English checkpoint 68: Expos\'e VIII section 6 complete

- Personally translated and source-aligned all of section 6, authority `source\expose_VIII_body.tex` lines 1976--2170 / scan indices 298--310 / source folios 287--299.
- Compared physical authority pages 299--311 directly in overlapping 1,100-dpi bands.  The only consequential visual ambiguity was the hand-corrected $U\to S\leftarrow Y$ display on physical page 310; a targeted direct-authority crop at 5,000 dpi confirms the open-immersion hook at $U$, the heavy corrective leftward arrowhead from $Y$ to $S$, labels below their shafts, and terminal period.
- Transparent source dispositions include: correcting $\mathbb Z_Z$ to $\mathbb Z_S$ before Lemma 6.2; removing a corrupt insertion in that lemma without changing its construction; correcting `description 3.2` to 6.2; using the type-correct canonical section $s_{-D}$ with $\underline O_S(-D)$ in (6.3.2); correcting local rings of $X$ to local rings of $S$ in Theorem 6.5; and restoring $j:U\hookrightarrow S$ and $j_*\underline G_{mU}$ in 6.9(a). The French authority remains unchanged.
- Active components and identities:
  - `116_expose_VIII_section_6_1_and_lemma_6_2.tex`: 3,636 bytes, SHA-256 `32714336C9F3C5778103B533755C4D37D5F09986EA9B298E3E419DD1E3988597`.
  - `117_expose_VIII_sections_6_2_1_through_6_2_4.tex`: 4,204 bytes, SHA-256 `1DF153DA5CD9B49CF9BA9D4668261F707425C1486EF42BDC033955380BD562E3`.
  - `118_expose_VIII_sections_6_3_and_6_4.tex`: 5,342 bytes, SHA-256 `1F8A224F41CA06498EFD385A398EBE980D35B820B9ED76E1FFF24A3466F35E56`.
  - `119_expose_VIII_theorem_6_5_through_corollary_6_7.tex`: 4,970 bytes, SHA-256 `21078D2A254069EAB80C2C2D6ABC5E44118F78EB648D9702FA5EB3CA7D28E54F`.
  - `120_expose_VIII_remarks_6_8_and_autocritique_6_9.tex`: 5,929 bytes, SHA-256 `556591D9DF399E31A0454D1BCD0B5E59DD0E3EEB7E8FFA1ACD33910BA44BAE86`.
- The first clean render revealed only an unnecessarily stretched one-line family display in 6.2.1; the r2 layout divides the same formula over two source-faithful lines. Three-pass r2 build: PASS, 175 A4 pages, zero warning/error/overfull/underfull/missing-character matches. PDF 1,389,506 bytes, SHA-256 `9BCF29C0D85306BEB7402DFAA5F03363634136AEE6E6605B79E1B215BEC10F0B`; log 42,010 bytes, SHA-256 `E0DBCAFCDDA5A651766C33011B8B43289774AC9551D39E6F29650CBA43616771`.
- Rendered and personally inspected cumulative pages 169--175 at 600 dpi, then re-rendered the adjusted page 171. The formulas, footnote, native corrected diagram, label sides, terminal punctuation, underlining, page breaks, and hard stop before section 7 PASS.
- Current master: 9,210 bytes, SHA-256 `EFBDA7288077A7107D6322953897CFB128F40336328547D91D68FD19FC7A02B2`.
- Exact next cursor: Expos\'e VIII section 7, authority line 2171, scan index 310 / source folio 299 / physical PDF page 311.

## 2026-07-31 — English checkpoint 69: Expos\'e VIII through Remark 7.2

- Personally translated and source-aligned the section-7 opening, Theorem 7.1 with its proof, and Remark 7.2: authority `source\expose_VIII_body.tex` lines 2171--2261 / scan indices 310--314 / source folios 299--303.
- Compared physical authority pages 311--315 directly in overlapping 1,100-dpi bands. Prose, generic/special-fibre subscripts, bars, degree-one Ext/Biext notation, and the displayed obstruction maps were fully legible; no actual ambiguity required a 5,000--9,000-dpi escalation.
- Transparent source dispositions include: restoring the generic-fibre subscript $\eta$ in the criterion of Theorem 7.1(b); rendering the proof's printed `biextensions by $\overline G$' as the mathematically required extensions in part (a), in agreement with Theorem 6.6 and the surrounding exact sequence; and restoring the target $(\mathbb Q/\mathbb Z)_k$ in (7.1.2). The French authority remains unchanged.
- Active components and identities:
  - `121_expose_VIII_section_7_opening_and_theorem_7_1_statement.tex`: 3,470 bytes, SHA-256 `F18F44D274B781F45270C94D32C929EF364BF90C98F4BC07FA20DE6D319701F2`.
  - `122_expose_VIII_theorem_7_1_proof.tex`: 3,710 bytes, SHA-256 `9796073266392354D0CAB00B8C9CE6BBB697E68F9A6662A642054B3B6C9DFF0A`.
  - `123_expose_VIII_remark_7_2.tex`: 2,643 bytes, SHA-256 `F04A3F8F0F0CB305BEAC5E8D6FDC4AE4EB7A413D030A3E491D8F19CCD40ADBC6`.
- Three-pass build: PASS, 177 A4 pages, zero warning/error/overfull/underfull/missing-character matches. PDF 1,405,019 bytes, SHA-256 `273979F560559F9D97FD138588449BBCD658459F1CC68EBE01834E8F214E1CD0`; log 42,173 bytes, SHA-256 `5629F78873973FF28E1C06CBA59CC486CBE4F292B21AFC7996DCB177A8098990`.
- Rendered and personally inspected cumulative pages 175--177 at 600 dpi. The section seam, theorem register, formulas, footnote, page breaks, and hard stop after Remark 7.2 PASS.
- Current master: 9,388 bytes, SHA-256 `F9F77CC77A1F57ABB0E382F1E500790D8E89AB3A46CA2DDCB441CAFD91BE5309`.
- Exact next cursor: Expos\'e VIII section 7.3, authority line 2262, scan index 314 / source folio 303 / physical PDF page 315.

## 2026-07-31 — English checkpoint 70: Expos\'e VIII complete

- Personally translated and source-aligned sections 7.3.1--7.3.5, Proposition 7.4, Corollary 7.5, and the terminal bibliography: authority `source\expose_VIII_body.tex` lines 2262--2495 / scan indices 314--323 / source folios 303--312. Expos\'e VIII is now complete.
- Compared physical authority pages 315--324 directly in four overlapping 1,100-dpi bands per page. Prose, generic-fibre notation, primes, base-change subscripts, arrow directions, labels, and terminal punctuation were unambiguous at that resolution; no genuine ambiguity required a 5,000--9,000-dpi escalation.
- Transparent source dispositions include: restoring the generic-fibre coefficient $\mathbb G_{m\eta}$ in 7.3.1; distinguishing the transposed biextension ${}^sE$ from the subsequent symmetry condition; correcting the type-inconsistent transcription $d(q_\eta^*(E_*))$ to the authority/source-mathematics reading $d(q_\eta^*(E_\eta))$ in 7.3.4; making $P_{\eta Q_\eta}$ explicit as $P_\eta\times_\eta Q_\eta$; and rendering the ramification length as $\operatorname{length}_{V'}(V'/\mathfrak mV')$. The French authority files remain unchanged.
- Active components and exact identities:
  - `124_expose_VIII_section_7_3_1.tex`: 2,531 bytes, SHA-256 `92CF1624C3077A9ADECB3C63B218D684673F28C93929B62CB27F1A68453AD0C8`.
  - `125_expose_VIII_sections_7_3_2_and_7_3_3.tex`: 4,545 bytes, SHA-256 `BBB519FCA6B299D90F095A789F9898569FD65E6AF3DEBEA156AB96FB291DE4A4`.
  - `126_expose_VIII_sections_7_3_4_and_7_3_5.tex`: 6,002 bytes, SHA-256 `BE6DA4EC24971816A6645E0C971396689D14BF0304D90D2883AB57B20E7CD5D3`.
  - `127_expose_VIII_proposition_7_4_corollary_7_5_and_bibliography.tex`: 5,543 bytes, SHA-256 `73AA209F4AB74230C51082B24838CEFE1A42537D97CCF23F3EBAEE9182B520B9`.
- Three-pass build: PASS, 181 A4 pages. The only logged warning is the pre-existing `\footnotesize`-in-math-mode warning in component 97; this tranche introduced no fatal, undefined-reference, overfull, underfull, or missing-character diagnostic. PDF 1,433,416 bytes, SHA-256 `21A9DC25B45F1D67450675F46E6374791483C88F6DBAA051C4B4BF133675361D`; log 42,431 bytes, SHA-256 `79B03FA6761F2A19227F3053D9003AD5FCDD263738E036C33A52288AA1EC9422`.
- Rendered and personally inspected all newly affected cumulative pages 177--181 at 600 dpi. Both triangular diagrams, the symmetry diagram, formula alignment, theorem register, page breaks, terminal corollary, and bibliography PASS.
- Current master: 9,639 bytes, SHA-256 `5F961FCF47C38663922F251502CB36165328A851769E675D63B037A152BBEE94`.
- Exact next cursor: Expos\'e IX opening/title and Introduction 0.1, authority `source\expose_IX_body.tex` line 5, scan index 324 / source folio 313 / physical PDF page 325.

## 2026-07-31 — English checkpoint 71: Expos\'e IX title, introduction, and Leitfaden

- Personally translated and source-aligned the Expos\'e IX title, complete contents, Introduction 0.1--0.5, and the Leitfaden dependency graph: authority `source\expose_IX_body.tex` lines 5--140 / scan indices 324--329 / source folios 313--318.
- Compared physical authority pages 325--330 directly in four overlapping 1,100-dpi bands per page. The prose, formulas, primes, accents, footnote markers, and contents hierarchy were clear at that resolution. The dependency graph alone required escalation: four direct-source crops at 5,000 dpi resolved every junction and terminal stroke. It has 14 bare numbered nodes and exactly 18 plain, unlabelled, undirected segments; there are no arrowheads. No 9,000-dpi escalation was needed.
- Reconstructed the graph as native TikZ from the verified node positions and complete 18-edge list rather than retaining the transcription's misleading directional `tikzcd` commands. The French transcription and authority scan remain unchanged.
- Active components: `128_expose_IX_title_and_contents.tex`, 2,522 bytes, SHA-256 `0EE36C41955C95BA39062B6D9A59EB2F829658AD23AF401D04390EFFA7300237`; and `129_expose_IX_introduction_and_leitfaden.tex`, 8,890 bytes, SHA-256 `78D58F70264F9855E72BE9B874101202D64A06DE561817D6A26D87FD60C9B646`.
- Three-pass build: PASS, 184 A4 pages. No fatal, undefined-control-sequence, overfull, underfull, missing-character, or reference diagnostic was introduced; the console retains only the pre-existing component-97 font warning. PDF 1,452,666 bytes, SHA-256 `61B34E48E0D1FEEC41B913A65098FDB742218BA2CE7013BCC2003CFC48C4033C`; log 42,565 bytes, SHA-256 `CA22B9F7F882BBDF244490A4EB37EF1F679F7C2998C8C268E7B7D15B299AA69B`.
- Rendered and personally inspected cumulative pages 182--184 at 600 dpi. The title and contents, theorem/register typography, footnotes, paragraph flow, native graph geometry, line crossings, node labels, and hard stop before section 1 all PASS.
- Current master: 9,762 bytes, SHA-256 `1DFDEC4A999D82B8285162AA4D98ACEF962DBE20F26136A1E37070875CD12445`.
- Exact next cursor: Expos\'e IX section 1, authority line 144, scan index 330 / source folio 319 / physical PDF page 331.

## 2026-07-31 — English checkpoint 72: Expos\'e IX section 1 complete

- Personally translated and source-aligned all of section 1 (1.0--1.5), authority `source\expose_IX_body.tex` lines 144--341 / scan indices 330--337 / source folios 319--326.
- Compared physical authority pages 331--338 directly in four overlapping 1,100-dpi bands per page. Ordinary prose, formulas, primes, bars, subscripts, and displayed arrows were legible at that resolution. Formula (1.4.2) alone required direct 5,000-dpi crops; they resolved the printed glyphs completely, so no 9,000-dpi escalation was needed.
- Transparent source dispositions: restored the missing prime in the prose identifying the special fibre $A'_o$ of the dual Neron model; and disambiguated the printed notational collision in (1.4.2), which reuses $\Phi'_o$ for the first subgroup and writes $\Psi'_o\subset\Psi_o$ for the second despite the established component groups $\Phi_o,\Phi'_o$. The English formula uses neutral local names $F_o,F'_o$ and carries a visible editorial footnote recording the exact printed forms. The French authority remains unchanged.
- Active components: `130_expose_IX_section_1_0_and_1_1.tex`, 6,667 bytes, SHA-256 `5DC86D14EBCB539E19CD4DEC13C78CC180B7C2EEED267783524A3C1E7399425C`; and `131_expose_IX_sections_1_2_through_1_5.tex`, 6,227 bytes, SHA-256 `CBB92732711B1607FD58F42180C7842CEF4238A4F57F4A9ADA3ACCDA2C40B217`.
- Three-pass build: PASS, 187 A4 pages. No fatal, undefined-control-sequence, overfull, underfull, missing-character, or reference diagnostic was introduced; the console retains only the pre-existing component-97 font warning. PDF 1,473,872 bytes, SHA-256 `428130778B26205CB2CDA8023E5454F18EC93F22DD674729E4639CCA20F38DDC`; log 42,681 bytes, SHA-256 `E7B01916E38CE02CC7546B4295A5D44AB93E8E29B018D9B6F4E941D5D3F4C45C`.
- Rendered and personally inspected cumulative pages 184--187 at 600 dpi. The section seam, formulas (1.0.1)--(1.4.4), theorem register, footnote placement, page breaks, and hard stop before section 2 all PASS.
- Current master: 9,873 bytes, SHA-256 `8A64A2DBB70589D69C23E097674F8ED5E4EEF4D4BAB501EC3618013C2A593A75`.
- Exact next cursor: Expos\'e IX section 2, authority line 344, on the same authority page as the end of section 1: scan index 337 / source folio 326 / physical PDF page 338. This corrects the one-page seam offset in the original checkpoint entry.

## 2026-08-01 — English checkpoint 73: Expos\'e IX section 2.1 complete

- Personally translated and source-aligned the section-2 title and sections 2.1--2.1.14: authority `source\expose_IX_body.tex` lines 344--441 / scan indices 337--340 / source folios 326--329 / physical authority pages 338--341.
- Compared all four physical authority pages directly in four overlapping 1,100-dpi bands. Diagram (2.1.6) required fine inspection: four overlapping direct-source crops at 5,000 dpi establish the exact five-node top row, two lower nodes, six plain arrows, both vertical $\wr$ labels on the right of their shafts, and terminal comma. No 9,000-dpi escalation was needed.
- The first English render caught two mechanical defects: both $\wr$ labels had been placed on the left, and literal `qquad` text appeared in (2.1.9) and 2.1.14. The r2 source moves both labels to the source side and restores the missing TeX spacing commands; the re-render is clean.
- Transparent source disposition: the printed prose calls the displayed exact sequence (2.1.6) `(2.1.5)`; the English uses the existing displayed label (2.1.6). The French authority remains unchanged.
- Active component `132_expose_IX_section_2_1.tex`: 5,454 bytes, SHA-256 `B6279D0224DBB63F41254D41D66A24EE51E198A32CEF6DD734C7610C64ADA97B`.
- Three-pass r2 build: PASS, 189 A4 pages, zero fatal/error/undefined/overfull/multiply-defined/duplicate-destination/rerun matches. PDF 1,481,596 bytes, SHA-256 `FFFCAB7DF7C7B75D33E228593500BDA9BA47E4E595AFCAC6FAA9C86F816CBCA2`; log 42,742 bytes, SHA-256 `2B50CDEA839EE9807ABFF2C8E88E90DDA22880DC0C03E4A3506D840A1441D4C4`.
- Rendered and personally inspected cumulative pages 187--189 at 600 dpi after the repairs. Formula spacing, diagram nodes/arrows/label sides/punctuation, theorem register, and page flow PASS.
- The exact next cursor was section 2.2, authority line 443, on the same physical authority page 341 / scan index 340 / source folio 329.

## 2026-08-01 — English checkpoint 74: Expos\'e IX section 2.2 complete

- Personally translated and source-aligned all of section 2.2 through the proof of the good-reduction criterion 2.2.9: authority `source\expose_IX_body.tex` lines 443--599 / scan indices 340--347 / source folios 329--336 / physical authority pages 341--348.
- The opening on physical page 341 was already included in checkpoint 73; physical pages 342--348 were compared directly in four overlapping 1,100-dpi bands per page. Ordinary prose, superscripts, primes, bars, torsion notation, and displayed maps were unambiguous at that resolution.
- The small inverse-limit display (*) on physical page 345 was additionally checked in a direct 5,000-dpi crop. It confirms that the print gives an inverse-limit sign on the first limit but plain `lim` on the second, although the surrounding prose and compatible family $(x_\nu)$ require inverse limits on both sides. The English renders both as $\varprojlim_\nu$ and calls the compared term the rightmost term.
- Transparent source dispositions: corrected the nonexistent `(1.5.5)` in Lemma 2.2.1 to local 2.1.5; corrected `(6.2.5.1)` in the proof to (2.2.5.1); and restored the inverse-limit operator in the rightmost term of (*). The French authority remains unchanged.
- Active component `133_expose_IX_section_2_2.tex`: 12,935 bytes, SHA-256 `A4E66A15D5C793600200F3DDD0AFCA1FA70AAAA70954CC29F67449FBEBBE083C`.
- Three-pass build: PASS, 192 A4 pages, zero fatal/error/undefined/overfull/multiply-defined/duplicate-destination/rerun matches. PDF 1,506,076 bytes, SHA-256 `E8A78154EE32FA54BD74B473985EE09879029541E065F5C925C49C7E96C8F849`; log 42,803 bytes, SHA-256 `5068AFEDC84B1A1CDF1073CAFE510BBEC8E6B9F045CA95B5E1122AC9FC49A734`.
- Rendered and personally inspected cumulative pages 189--192 at 600 dpi. Underlining, formulas, inverse-limit notation, proposition/corollary register, line wrapping, and hard stop before section 2.3 PASS.
- Current master: 9,963 bytes, SHA-256 `E588471D6C0EC9E566DE530E38BE5CBAF3152F276951866802ADA6C828A4FF79`.
- Exact next cursor: Expos\'e IX section 2.3, authority line 601, on physical page 348 / scan index 347 / source folio 336.

## 2026-08-01 — English checkpoint 75: Expos\'e IX sections 2.3--2.4 complete

- Personally translated and source-aligned section 2.3 and the Orthogonality Theorem 2.4 with its complete proof: authority `source\expose_IX_body.tex` lines 601--685 / scan indices 347--351 / source folios 336--340 / physical authority pages 348--352.
- The opening on physical page 348 was already included in checkpoint 74; physical pages 349--352 were compared directly in four overlapping 1,100-dpi bands per page. Prose, primes, bars, orthogonal-complement notation, sheaf fibers, and all displayed pairings were unambiguous at that resolution, so no 5,000--9,000-dpi escalation was warranted.
- Transparent source dispositions: corrected the impossible fixed-part citation `(1.6.5)` to Proposition 2.2.5; restored the mathematically required prime on the second factor $T_\ell(A'{}_o^o)$ in printed formula (2.4.5), as confirmed by (2.4.3), (2.4.4), and (2.4.7); and replaced the nonexistent printed citation `(1.10)` by an unnumbered verbal introduction to the displayed inclusion (2.4.7). The French authority remains unchanged.
- Active component `134_expose_IX_sections_2_3_and_2_4.tex`: 7,271 bytes, SHA-256 `AED671ED59D1674F5210FA32D885F4448C10AF806D6BECFB492A21206BA2E61E`.
- Three-pass build: PASS, 194 A4 pages, with zero LaTeX warning, fatal/error, undefined-control-sequence, overfull, missing-character, multiply-defined, or duplicate-destination matches. PDF 1,517,612 bytes, SHA-256 `190A9A9C78A488D47DFCF8CC95A1EACF37D35DAB29A975C91C5E2303D644ED9E`; log 42,894 bytes, SHA-256 `30670C750168FA8A635272205A382A79A11BAC2654FCBB4062D45A776255F9A5`.
- Rendered and personally inspected cumulative pages 191--194 at 600 dpi. The section seam, filtration formulas, underlined theorem register, pairings (2.4.1)--(2.4.5), orthogonal-complement formulas (2.4.6)--(2.4.7), line wrapping, and hard stop before section 2.5 PASS.
- Current master: 10,017 bytes, SHA-256 `27EB0975279F3BAB05BD1AD082438832DF5DBAB30CCCF698028066BEC12AB131`.
- Exact next cursor: Expos\'e IX section 2.5, authority line 687, on physical page 352 / scan index 351 / source folio 340.

## 2026-08-01 — English checkpoint 76: Expos\'e IX section 2 complete

- Personally translated and source-aligned section 2.5 and both parts of Remarks 2.6, completing section 2: authority `source\expose_IX_body.tex` lines 687--757 / scan indices 351--353 / source folios 340--342 / physical authority pages 352--354. The opening on physical page 352 was covered in checkpoint 75; the hard boundary before section 3 was confirmed on physical page 355.
- Compared the ordinary prose and formulas on physical pages 353--354 directly in four overlapping 1,100-dpi bands. The six-arrow filtration diagram (2.5.4) was then checked separately in five overlapping direct-authority 5,000-dpi crops, resolving all six arrow directions, tail hooks, label sides, node formulas, and the terminal comma without a 9,000-dpi escalation.
- The first clean English render exposed that all six diagram labels had landed on the opposite side of their shafts even though the arrows and hooks were correct. The r1 build is preserved as adverse history. Component r2 flips only the six label-side controls: both $\mu$ labels are above the horizontal arrows; $2\lambda$ and $2\alpha$ are respectively above-left and below-left on the left diamond; $2\alpha$ and $2\lambda$ are respectively above-right and below-right on the right diamond. The 600-dpi r2 page render agrees with the 5,000-dpi authority crops.
- Active component `135_expose_IX_section_2_5_and_remarks_2_6.tex`: 4,390 bytes, SHA-256 `9C2886B1FA28C789EB97BC556E64323DAD69AE1A6FB10C1A1D331ED7B9C0B6B3`.
- Three-pass r2 build: PASS, 195 A4 pages, with zero LaTeX warning, fatal/error, undefined-control-sequence, overfull, underfull, missing-character, multiply-defined, or duplicate-destination matches. PDF 1,523,059 bytes, SHA-256 `0486096480823D068E3D0F4D3C2A6C3428AB3CDB18E79ED7EAE4D6467EBDDF0C`; log 42,953 bytes, SHA-256 `A8B7C9CB0C13BD11FFC2AD7C918481C53ABA3EF1DB2E64CB15EAD9BC479724FC`.
- Rendered and personally inspected cumulative pages 194--195 at 600 dpi after repair. Formulas (2.5.1)--(2.5.5), the native filtration diagram, all label sides/hooks/directions/punctuation, Remarks 2.6, line wrapping, and the hard stop before section 3 PASS.
- Current master: 10,078 bytes, SHA-256 `185B9BC497407F0A133F69D5F49F6B4B1B56A84361699CDF9D8CEC4FC7835C5A`.
- Exact next cursor: Expos\'e IX section 3, authority line 763, physical page 355 / scan index 354 / source folio 343.

## 2026-08-01 — English checkpoint 77: Expos\'e IX section 3.1 complete

- Personally translated and source-aligned the section-3 opening, Proposition 3.1 with its complete proof, Lemma 3.1.3, and Remark 3.1.4: authority `source\expose_IX_body.tex` lines 763--839 / scan indices 354--358 / source folios 343--347 / physical authority pages 355--359, stopping before Proposition 3.2.
- Compared physical authority pages 355--358 and the opening/boundary on page 359 directly in four overlapping 1,100-dpi bands per page. Prose, reduced-identity-component notation, ranks, primes, citations, and the hooked geometric-fibre injection were clear at that resolution, so no 5,000--9,000-dpi escalation was warranted.
- Transparent transcription disposition: Lemma 3.1.3 says that $t$ is a generalization of $s$, but the inherited French TeX gives the impossible `t\in T`; the authority scan clearly prints $t\in S$, which the English restores. The French working transcription remains unchanged.
- Active component `136_expose_IX_section_3_1.tex`: 8,534 bytes, SHA-256 `B256581FE6DCDCD1F31F22E0707E74200AC9C4D012FE5EAB69A71CA2853DE65D`.
- The first build attempt caught one missing math delimiter in the new component and produced no PDF. After that mechanical repair, three passes succeeded. Final build: PASS, 197 A4 pages, no fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic; it retains only the pre-existing component-97 font warning. PDF 1,540,633 bytes, SHA-256 `0AE2BB37976586459A641B6D1501CCCD6A7FB6060C5215943A5240894E18A414`; log 42,987 bytes, SHA-256 `5E1F988E3D2A08413C65B848DDCE82063895EB3851C2FFA9F52146F5FE4660AC`.
- Rendered and personally inspected cumulative pages 195--197 at 600 dpi. The long proposition statement, theorem register, footnote, hooked injection, dimension formulas, lemma, multiplicative-rank formula, page breaks, and clean hard stop before Proposition 3.2 PASS.
- Current master: 10,123 bytes, SHA-256 `D8178AF3E1E2208CA38B245312CB12FAD630D8B3AF8421581AC0EA2E2F0EC6C7`.
- Exact next cursor: Expos\'e IX Proposition 3.2, authority line 841, physical page 359 / scan index 358 / source folio 347.

## 2026-08-01 — English checkpoint 78: Expos\'e IX sections 3.2--3.4 complete

- Personally translated and source-aligned Proposition 3.2, 3.2.1 and its proof, Corollary 3.3, Remark 3.3.2, Definition 3.4, and 3.4.0: authority `source\expose_IX_body.tex` lines 841--875 / scan indices 358--360 / source folios 347--349 / physical authority pages 359--361, stopping before Proposition 3.5.
- The opening on physical page 359 was already directly checked with checkpoint 77. Physical pages 360--361 were compared in four overlapping 1,100-dpi bands per page. Prose, primes, identity-component notation, base-change formulas, arrow direction, and terminal punctuation were unambiguous at that resolution, so no 5,000--9,000-dpi escalation was warranted.
- The inherited French transcription's duplicated phrase in 3.4.0 (`cas S ou S`) is an ordinary prose typo; the English transparently renders the source meaning as “the case where $S$ is a strictly local trait.” The French working transcription remains unchanged.
- Active component `137_expose_IX_sections_3_2_through_3_4.tex`: 4,601 bytes, SHA-256 `963E3E432A52C7E1E07817FFA078652C3D9F05052AD9A3E0847F11812C3AB607`.
- Three-pass build: PASS, 198 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 font warning. PDF 1,551,833 bytes, SHA-256 `BF474B377BBFF5BECB561A0FBDBF8E426842F70FDE3043572687D159F864395F`; log 43,175 bytes, SHA-256 `B5195F5542489226046FA5EE0082D8224A61F175E1211D5C5A5D43BF0DDBF143`.
- Rendered and personally inspected cumulative pages 196--198 at 600 dpi. The preceding-section seam, proposition/corollary register, base-change formulas (3.3.1), line wrapping, Definition 3.4, and clean stop before Proposition 3.5 PASS.
- Current master: 10,181 bytes, SHA-256 `71F2D7A16CCEABEDC4E2E3E1F0612B2CA1895583751EB43C7361C6949CBEC2A4`.
- Exact next cursor: Expos\'e IX Proposition 3.5, authority line 880, physical page 362 / scan index 361 / source folio 350.

## 2026-08-01 — English checkpoint 79: Expos\'e IX sections 3.5--3.9 complete

- Personally translated and source-aligned Proposition 3.5, Remarks 3.5.1, Corollary 3.5.2, the semistable reduction Theorem 3.6 and proof, and Corollaries 3.7--3.9: authority `source\expose_IX_body.tex` lines 880--960 / scan indices 361--365 / source folios 350--354 / physical authority pages 362--366, stopping before section 4 on the same final page.
- Compared all five physical authority pages directly in four overlapping 1,100-dpi bands per page. Prose, formulas, primes, orthogonal-complement notation, and the section-4 seam were legible at that resolution. The empty parenthesis printed after $\mathbb Z_\ell(1)$ in 3.5.2 contains no recoverable text and is omitted rather than guessed; no 5,000--9,000-dpi escalation could recover absent print.
- Transparent source dispositions: diagram (2.5.4) and the immediately preceding rank computation show that the printed $\operatorname{rank}(V/W)=2\lambda$ in (2.5.5) must read $2\alpha$; Proposition 3.5(ii) prints the inclusion in the direction incompatible with its condition (iii), proof, and monodromy criterion, so the English gives the type-correct $V^\perp\subset V$; the proof's tautological printed $U^I=V$ is restored to $U/U^I=U/V$; and the proof of Corollary 3.8 is correctly identified as (vi)$\Rightarrow$(iv), not the printed (v)$\Rightarrow$(vi). The exact printed readings remain recorded in source comments, and the French files remain unchanged.
- Active component `138_expose_IX_sections_3_5_through_3_9.tex`: 8,073 bytes, SHA-256 `9626C5387129D5D005364BC2F97ED7FB0F41CE0172831DD188F48716881E3667`. The rank correction updates component `135_expose_IX_section_2_5_and_remarks_2_6.tex` to 4,595 bytes, SHA-256 `1FB6D87EE41AD57791A9B5FE51E8DED71DA950D612E203748BBE7BC90A1FC165`; the earlier checkpoint-76 bytes remain historical evidence of the printed reading.
- Three-pass build: PASS, 200 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,567,669 bytes, SHA-256 `30BF850F9032C532001B5EADEA95A81199EB3367D80AF1E9BE970CA9932CF511`; log 43,243 bytes, SHA-256 `BC1A19E5A1242198EBABB6D909DDAC507EB095348F56FFABB53A045911088177`.
- Rendered and personally inspected cumulative pages 197--200 at 600 dpi. The preceding seam, all four equivalence conditions, theorem/corollary register, formulas (3.5.3) and (*), page breaks, identity-component display, terminal paragraph, and hard stop before section 4 PASS.
- Current master: 10,239 bytes, SHA-256 `B0D82D3F445C3AAE9B37E08EB0913474919F28B08AD323B041A35CCA6FD1A874`.
- Exact next cursor: Expos\'e IX section 4, authority line 963, physical page 366 / scan index 365 / source folio 354.

## 2026-08-01 — English checkpoint 80: Expos\'e IX sections 4.1--4.2 complete

- Personally translated and source-aligned the section-4 title and sections 4.1--4.2, through the Serre--Tate transition immediately before Theorem 4.3: authority `source\expose_IX_body.tex` lines 963--1093 / scan indices 365--369 / source folios 354--358 / physical authority pages 366--370.
- Compared all five physical authority pages directly in four overlapping 1,100-dpi bands per page. Ordinary prose, formulas, primes, bars, superscripts, and the field-extension diagram were legible at that resolution. Diagram (4.2.4) was additionally compared in four overlapping 5,000-dpi direct-authority crops, resolving its six arrowheads, three unheaded segments, two curved segments, all node formulas, label sides, and the absence of terminal punctuation. No unresolved feature required 9,000 dpi.
- Transparent source dispositions: corrected the footnote's printed `$\ell\ne p$` to `$\ell=p$`, since the main text already assumes `$\ell\ne p$` and sections 5--6 treat the `$\ell=p$` case; corrected the printed semistable-reduction citation `(4.5)` to the actual criterion (3.5); rendered the character after (4.2.11) as trivial on `$\Gamma$`, the kernel in (4.2.3), rather than the undefined printed `$\Gamma^o$`; and explicitly marked the blank citation after `cf. I` following (4.2.6) as omitted in the source instead of inventing a locator. The French authority remains unchanged.
- Reconstructed (4.2.4) as native TikZ: seven field nodes; six directed inclusion arrows; the plain diagonal `$K$--$K'$` segment; the unheaded top `$K$--$\widetilde K$` arc; and the unheaded right `$\widetilde K$--$\overline K$` arc. The English render agrees with the direct scan on arrow direction, arrowhead absence, curvature, label side, and node placement.
- The first render exposed a stranded closing parenthesis after the displayed canonical isomorphism (4.1.2). The r2 component replaces that parenthetical construction with a continuous “More precisely” sentence; the re-render is clean. The first build also briefly wrote three generated files into an accidental literal `source\$out` directory because of a PowerShell native-argument quoting mistake; those generated files were moved into their intended checkpoint directory and the empty accidental directory was removed. No source artifact was lost or overwritten.
- Active component `139_expose_IX_sections_4_1_and_4_2.tex`: 9,792 bytes, SHA-256 `8950A2DC6C93BC2D581C9CCC1AE67E402E7F94248F992B3745609E0A54ABFCB7`.
- Three-pass r2 build: PASS, 202 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,582,384 bytes, SHA-256 `84792403EEC472B68B7DA7F7FBE304476146D0E0920A0F6B506F682561741D35`; log 43,254 bytes, SHA-256 `DA1509AB815B5A7DC64748F3AD1CFA2DC5468AA0575D2769498CE1AB7EDD84E3`.
- Rendered and personally inspected cumulative pages 200--202 at 600 dpi after repair. The preceding-section seam, corrected footnote, filtration and trace formulas, native field diagram, underlined source register, reference-omission note, footnote placement, line wrapping, and clean hard stop before Theorem 4.3 PASS.
- Current master: 10,293 bytes, SHA-256 `23F8DAE97F3D490068B01639CB4D6BCE1EAB184BFF12AA6AF5570E93515FA3CD`.
- Exact next cursor: Expos\'e IX Theorem 4.3, authority line 1098, physical page 371 / scan index 370 / source folio 359.

## 2026-08-01 — English checkpoint 81: Expos\'e IX Theorem 4.3 and Corollary 4.4 complete

- Personally translated and source-aligned Theorem 4.3, its complete proof and Lemma 4.3.2, and Corollary 4.4 with its final eigenvalue argument: authority `source\expose_IX_body.tex` lines 1098--1171 / scan indices 370--374 / source folios 359--363 / physical authority pages 371--375, stopping before section 4.5 on the same final page.
- Compared all five physical authority pages directly in four overlapping 1,100-dpi bands per page. The formulas, Frobenius powers, inverses, Tate twists, primes, bars, characteristic-polynomial language, and theorem/corollary seam were unambiguous at that resolution. This diagram-free block contained no unresolved small feature warranting a 5,000--9,000-dpi escalation.
- The printed shorthand in the application of Lemma 4.3.2 replaces `$k$` by a barred `$k'$`; the English states invariantly that `$k$` is replaced by an algebraic closure of `$k'$`, which is then identified with the `$\overline k$` used in the tensor product. No mathematical content is added. The French authority remains unchanged.
- The first reader render exposed a mechanical TeX-escaping defect that the successful compile could not detect: the intended spacing command in `$q=p^r,\quad r\geq0$` had printed as the literal word `quad`. The r2 component restores the backslash. The 600-dpi r2 re-render shows the formula correctly and preserves the surrounding layout.
- Active component `140_expose_IX_theorem_4_3_and_corollary_4_4.tex`: 8,827 bytes, SHA-256 `A537A7D089965A238340ACDC3B847D28C99B377C557E7D95D058D39E2C1EF5B8`.
- Three-pass r2 build: PASS, 204 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,601,443 bytes, SHA-256 `08D7C6FF911DAD262C32E7DCC1AEED25E560757EB78348F9DAED82A694097CEE`; log 43,355 bytes, SHA-256 `38D07DB287BC29DF0696781C35243B518DA4F00D0C46822B3638481EA8FA4702`.
- Rendered and personally inspected cumulative pages 202--204 at 600 dpi, and re-rendered page 203 after the spacing repair. The preceding-section seam, long underlined theorem statement, formulas (4.3.0)--(4.3.5), Dwork--Fatou citation, Frobenius exponents, inverse-limit paragraph, corollary eigenvalue lists, page flow, and hard stop before section 4.5 PASS.
- Current master: 10,356 bytes, SHA-256 `405A53E7762A962EC26859D9226E6E7796FD8CA809B5ACF928894CB1FD316D64`.
- Exact next cursor: Expos\'e IX section 4.5, authority line 1173, physical page 375 / scan index 374 / source folio 363.

## 2026-08-01 — English checkpoint 82: Expos\'e IX section 4 complete

- Personally translated and source-aligned sections 4.5--4.7.5, including the local wild-conductor construction, Corollary 4.6 with its character calculation, Raynaud's semistable-reduction criterion, and the complete proofs of Lemmas 4.7.1--4.7.2: authority `source\expose_IX_body.tex` lines 1173--1270 / scan indices 374--379 / source folios 363--368 / physical authority pages 375--380, stopping before section 5 on physical page 381.
- Compared all six physical authority pages directly in four overlapping 1,100-dpi bands per page. Ordinary prose, group-ring notation, characters, primes, exponents, torsion subscripts, ideals, and terminal punctuation were legible at that resolution.
- Two one-character/source-logic questions in 4.7.3 were escalated to direct 5,000-dpi crops. The print unambiguously says that the ring $E$ is generated by $v$, although its following polynomial $T^{p^N}-1$ is the relation for $u$; since $u=1-nv$, the English gives the type-correct relation $(1-nT)^{p^N}-1$ and then changes variables back to $u$. The print also uses $n$ as the exponent in the root order and immediately says “$u\ne1$, i.e. $m\ge1$”; the English restores $p^m$ and reserves $n$ for the torsion integer. The French authority remains unchanged and the exact readings are preserved in source comments.
- A further transcription correction restores $\Gamma$ (clearly printed on physical page 377) as the group whose representation on $\check L$ has character $\psi$; the inherited French TeX had `I`. No new source ambiguity remains in this block.
- Active component `141_expose_IX_sections_4_5_through_4_7.tex`: 11,561 bytes, SHA-256 `7EB01CDA593EEA2A27AE4F99F068B1F4DDD9C286D6CD27DE6755666EF584CD9B`.
- Three-pass build: PASS, 207 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,629,980 bytes, SHA-256 `C676AA49B9ECEAAAC863E0267B8D029893063681947525E99B1D62D4514F466C`; log 43,500 bytes, SHA-256 `E1CE42C175952C0ED5C0ECF3353AB53F60D5B95696BBB11CE212BC6734EAD2F0`.
- Rendered and personally inspected cumulative pages 203--207 at 600 dpi. The preceding-section seam, two long footnotes, equations (4.5.1)--(4.6.3), proposition/lemma register, corrected cyclotomic argument, page breaks, and hard stop before section 5 PASS.
- The initial accidental XeLaTeX invocation wrote only generated build artifacts into a literal `source\$out` directory and failed before producing a PDF; after the correct pdfLaTeX build, that exact in-root generated directory was verified and removed. The source component and final checkpoint build were unaffected.
- Current master: 10,414 bytes, SHA-256 `72EB785FA30DCE48C4CF963B211AE8529BCE373696EE94F6286D1D3A7ABCE553`.
- Exact next cursor: Expos\'e IX section 5, authority line 1276, physical page 381 / scan index 380 / source folio 369.

## 2026-08-01 — English checkpoint 83: Expos\'e IX section 5.1 complete

- Personally translated and source-aligned the section-5 heading and section 5.1, defining the formal toric part and the fixed/toric filtrations for an abelian scheme and its dual: authority `source\expose_IX_body.tex` lines 1276--1348 / scan indices 380--382 / source folios 369--371 / physical authority pages 381--383, stopping before Theorem 5.2.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands per page. Prose, infinitesimal-neighbourhood exponents, formal-completion hats, torsion subscripts, projective-system notation, primes, and terminal punctuation were unambiguous at that resolution. This diagram-free block contained no small or damaged feature warranting a 5,000--9,000-dpi escalation.
- Transparent transcription correction: formula (5.1.7) in the French working TeX has $T_\ell(\Lambda^o)^t$, whereas the direct print and the surrounding definition both have $T_\ell(A^o)^t$. The English restores $A^o$; the French working transcription remains unchanged.
- Active component `142_expose_IX_section_5_1.tex`: 4,669 bytes, SHA-256 `7B9454AB91C740C03C5F249E846B036809929E738234130FB57D4792D8A7E599`.
- Three-pass build: PASS, 208 A4 pages, with no fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,636,147 bytes, SHA-256 `3C087E2370CEAB5C5DB4349CC16A34BF82FA8F25BC0343066B45D71EAFB8F338`; log 43,551 bytes, SHA-256 `00C444338A18F1F424FF7F111B1DD4AD1BB192ADEB4B7CDB40EFE5D9079E2F8A`.
- Rendered and personally inspected cumulative pages 207--208 at 600 dpi. The section seam, long underlined heading, formulas (5.1.1)--(5.1.11), formal hats, footnote placement, line wrapping, and hard stop before Theorem 5.2 PASS.
- Current master: 10,459 bytes, SHA-256 `2798A7916A3843547C83BDD0D426E3B0FDFCD59361E5D40591613A0742373847`.
- Exact next cursor: Expos\'e IX Theorem 5.2, authority line 1350, physical page 383 / scan index 382 / source folio 371.

## 2026-08-01 — English checkpoint 84: Expos\'e IX Theorem 5.2 complete

- Personally translated and source-aligned Theorem 5.2, its pro-object interpretation, pairings (5.2.4.1)--(5.2.4.4), Lemma 5.2.5 and its applications, and the semistable-reduction argument 5.2.6: authority `source\expose_IX_body.tex` lines 1350--1448 / scan indices 382--386 / source folios 371--375 / physical authority pages 383--387, stopping before section 5.3.
- Physical page 383 was compared with checkpoint 83, and physical pages 384--387 were compared directly in four overlapping 1,100-dpi bands per page. Prose, orthogonal complements, primes, formal duals, projective-system indices, arrows, special-fibre superscripts/subscripts, ranks, and punctuation were unambiguous at that resolution. This diagram-free block required no 5,000--9,000-dpi escalation.
- Transparent transcription corrections: the theorem statement corrupts the dual abelian scheme first as $A_{K'}$ and then as $\Lambda'_K$; the direct print clearly has $A'_K$ in both places, which the English restores. The French working transcription remains unchanged.
- Active component `143_expose_IX_theorem_5_2.tex`: 7,511 bytes, SHA-256 `66BCA6CA48C1C2425096B6D305C4A333E9319606278E941123F784284469D2C4`.
- Three-pass build: PASS, 210 A4 pages, with no fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,648,261 bytes, SHA-256 `33C266199F024C6085153E4F035ECAB7BACBF719E4C38E8331FA87BADA135EDC`; log 43,606 bytes, SHA-256 `56C3651127AB0FAB20D06C1E5B03AFBD540688555CD46A36E2A81F17ECF04574`.
- Rendered and personally inspected cumulative pages 208--210 at 600 dpi. The preceding seam, long underlined theorem statement, formulas (5.2.1)--(5.2.7), lemma register, pro-object caveat, page flow, and hard stop before section 5.3 PASS.
- Current master: 10,504 bytes, SHA-256 `A0E0BB8B0F59D43AA0BC1FC6CA3F294796759F8339055D59E81AA906AF3D796F`.
- Exact next cursor: Expos\'e IX section 5.3, authority line 1450, physical page 388 / scan index 387 / source folio 376.

## 2026-08-01 — English checkpoint 85: Expos\'e IX sections 5.3--5.4 complete

- Personally translated and source-aligned section 5.3 and Theorem 5.4, including the divisorial-correspondence interpretation of the perfect duality between the abelian parts of the special fibres: authority `source\expose_IX_body.tex` lines 1450--1499 / scan indices 387--389 / source folios 376--378 / physical authority pages 388--390, stopping before section 5.5.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands per page. Prose, primes, abelian-part superscripts, the duality morphisms, and terminal punctuation were unambiguous at that resolution; the diagram-free block required no 5,000--9,000-dpi escalation.
- Transparent source correction: the printed Theorem 5.4 calls $A_K$ an abelian scheme over $S$ and then separately requires semistable reduction over $S$. The type-correct English says that $A_K$ is an abelian scheme over $K$ having semistable reduction over $S$; the exact printed wording remains identifiable and the French authority is unchanged.
- Active component `144_expose_IX_sections_5_3_and_5_4.tex`: 4,769 bytes, SHA-256 `16E135D3ADD8133CC3B468D3A4999D1E4DFC0E0D30D604CA090F2973B3F177FE`.
- The first build caught a missing closing math delimiter in the new component and produced no PDF. After that mechanical repair, three passes succeeded with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. PDF: 211 A4 pages, 1,656,613 bytes, SHA-256 `05BE3C539431C879607D03777EE5CD1C718872F1D70E19F172F4E5CFE57E2E66`; log 43,691 bytes, SHA-256 `B3854096399B15952EC75E0BE569787A71FF3374FC6B16A4CCFFE1C00FB6AF3F`.
- Rendered and personally inspected cumulative pages 209--211 at 600 dpi. Pairings (5.3.2)--(5.3.7), the long underlined theorem, primes and duals, footnote placement, line wrapping, and the hard stop before section 5.5 PASS.
- Checkpoint master: 10,558 bytes, SHA-256 `AF69E24448A817120B2C7C35E8F5B6FAE02703E5610F38340F83E6F23493778E`.
- Exact next cursor at that checkpoint: Expos\'e IX section 5.5, authority line 1501, physical page 390 / scan index 389 / source folio 378.

## 2026-08-01 — English checkpoint 86: Expos\'e IX sections 5.5--5.6.1 complete

- Personally translated and source-aligned sections 5.5--5.6.1, including the twisted constant character groups, formulas (5.5.1)--(5.5.9), Proposition 5.6, and the common minimal splitting extension: authority `source\expose_IX_body.tex` lines 1501--1570 / scan indices 389--391 / source folios 378--380 / physical authority pages 390--392, stopping before Proposition 5.7.
- The opening authority page was already checked with checkpoint 85. Physical pages 391--392 were compared directly in four overlapping 1,100-dpi bands per page. The check accents, hats, primes, fixed/toric superscripts, tensor factors, duals, and punctuation were unambiguous at that resolution, so no 5,000--9,000-dpi escalation was warranted.
- Transparent transcription correction: in (5.5.8) the French working TeX writes $T_\ell(A')$ in the second numerator, whereas the direct print clearly has $T_\ell(A'_K)$. The English restores the missing base subscript; the French working transcription remains unchanged.
- Active component `145_expose_IX_sections_5_5_and_5_6.tex`: 4,681 bytes, SHA-256 `62082A959E0B4C3E1BE550EE845797D496677C76726E301AF4B5E7AA26241146`.
- The initial three-pass build itself succeeded but, because PowerShell passed an output-directory token literally, wrote generated files under `source\$out`. The exact generated artifacts were verified, moved to the intended checkpoint directory, and the empty accidental directory was removed. No source file was changed. The r1 visual render then caught a section-seam defect: 5.5 followed the last 5.4 sentence on the same line. The r2 component adds an explicit paragraph boundary and preserves r1 as adverse build history.
- Three-pass r2 build: PASS, 212 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. The sole pattern match is Babel's informational activation of `!`. PDF 1,664,132 bytes, SHA-256 `0A075FB7CFBCB27F83CB0E2F122A94D19A22EBCA2BC9CF3957EA66C974C4D66D`; log 43,749 bytes, SHA-256 `57BA8C8A7E5763A89BB1B8C5EE32CB32EC283B3EFBFDB44C619AE4C0EB24473D`.
- Rendered and personally inspected cumulative pages 210--212 at 600 dpi after the seam repair. The 5.4--5.5 transition, formulas (5.5.1)--(5.5.9), Proposition 5.6, all primes/checks/hats, page flow, and the clean stop before Proposition 5.7 PASS.
- Current master: 10,612 bytes, SHA-256 `EAF75F5E85568FA73A44AD6AA58193D6AE4930A36FBE79DC7C94998CF89764A1`.
- Exact next cursor: Expos\'e IX Proposition 5.7, authority line 1575, physical page 393 / scan index 392 / source folio 381.

## 2026-08-01 — English checkpoint 87: Expos\'e IX Proposition 5.7 through Corollary 5.10 complete

- Personally translated and source-aligned Proposition 5.7, Theorem 5.8, Corollary 5.9 and Lemma 5.9.2, and Corollary 5.10 with its complete proof: authority `source\expose_IX_body.tex` lines 1575--1691 / scan indices 392--397 / source folios 381--386 / physical authority pages 393--398, stopping before Remark 5.11.
- Compared all six physical authority pages directly in four overlapping 1,100-dpi bands per page. Prose, exact sequences, fixed/toric superscripts, primes, Galois actions, generic- and special-fibre notation, and terminal punctuation were clear at that resolution. This diagram-free block contained no unresolved feature requiring escalation to 5,000--9,000 dpi.
- Two obvious printed source typos were corrected transparently in English. First, after the exact sequence $0\to F''(n)\to F(n)\to F'(n)\to0$, the proof of Corollary 5.9 calls $F'(n)$ connected even though $F'$ is the pro-etale factor; the English gives the forced reading that $F'(n)$ is etale, while $F''(n)_o$ is purely infinitesimal. Second, the proof of Corollary 5.10 says that $X$ acts trivially on the special fibre of $X\times_S S'$, whereas the acting group throughout is $G=\operatorname{Gal}(K'/K)$; the English restores $G$. The French authority remains unchanged.
- Active component `146_expose_IX_proposition_5_7_through_corollary_5_10.tex`: 8,627 bytes, SHA-256 `7A77709FF74349FD95B6040505F57309FB169C7E36AEEC77BD19378686770D0C`.
- The first build exposed a TeX-structure defect: displayed maps had been nested inside underlining commands, so no PDF was admitted. The component was repaired by keeping the proposition/theorem/corollary statement maps inline and placing the lemma body outside its underlined heading.
- Three-pass r2 build: PASS, 214 A4 pages. There is no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic; the only matched line is Babel's informational activation of `!`. PDF 1,680,894 bytes, SHA-256 `AD8342B1FAD2621277D52973E0EA007AFF4BB05AB04AD858494BF0029DE46529`; log 43,886 bytes, SHA-256 `A4DBB5CB11CD5354D3D5A13B90EDA169229912949BCD1743C2122F3446C02E6F`.
- Rendered and personally inspected cumulative pages 211--214 at 600 dpi. The preceding seam, Proposition 5.7, Theorem 5.8, Corollaries 5.9--5.10, Lemma 5.9.2, exact sequences, formula alignment, footnote 18, page flow, and the hard stop before Remark 5.11 all PASS.
- Current master: 10,684 bytes, SHA-256 `1EFB13E3B6EB69A4DC7227FD9E4C444C80E3DA21989803CB6A0F29D904190CE1`.
- Exact next cursor: Expos\'e IX Remark 5.11, authority line 1693, physical page 398 / scan index 397 / source folio 386.

## 2026-08-01 — English checkpoint 88: Expos\'e IX Remark 5.11 through Corollary 5.15 complete

- Personally translated and source-aligned Remark 5.11, Definition 5.12, 5.12.1--5.12.2, Proposition 5.13 and its proof, Remark 5.13.1, Proposition 5.14 and its proof, and Corollary 5.15 with its proof: authority `source\expose_IX_body.tex` lines 1693--1780 / scan indices 397--403 / source folios 386--392 / physical authority pages 398--404, stopping before section 6.
- Compared the authority pages directly in four overlapping 1,100-dpi bands per page. The prose, filtrations, Galois groups, inertia representations, exterior-power notation, primes, superscripts, and terminal punctuation were clear at that resolution; this diagram-free block contained no unresolved feature requiring escalation to 5,000--9,000 dpi.
- Transparent source dispositions: the printed proof of Proposition 5.13 gives the impossible tautological group `Gal(\bar K/\bar K)`; the English restores `Gal(\bar K/K)`. Proposition 5.14(b) calls the automorphism group merely `\mathbb Z_\ell`, although the displayed character and following sentence require `\mathbb Z_\ell^\times`; the English uses the unit group. The source leaves the exact Expos\'e-III citation in 5.12.2 blank, which is disclosed in footnote 20 rather than guessed; a second wholly empty parenthetical citation after `$I'$` is omitted. The French working files remain unchanged.
- Active component `147_expose_IX_remark_5_11_through_corollary_5_15.tex`: 10,209 bytes, SHA-256 `C32A08EA226402ABF89D45C01F9B1CEE2BC4D58B6F3F99DF4C217E08B19FF96B`.
- The first compile command accidentally reused PowerShell's automatic `$args` variable, so pdfLaTeX received no source filename and exited at its interactive `**` prompt without reading or changing the TeX. Re-running with a dedicated argument variable produced three successful passes. Passes 2 and 3 are byte-identical (25,662 bytes, SHA-256 `671292419B5699B9C568D15A763AD4CB6A18324CC079727857D5F715448D8174`).
- Final build: PASS, 217 A4 pages, with no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic. It retains only the pre-existing component-97 `\footnotesize`-in-math-mode warning. PDF 1,693,913 bytes, SHA-256 `C0E3B378E46F6DCD35202991B62C8C3FA57385F1DDB377A70F37A06C62E8D335`; log 43,958 bytes, SHA-256 `5D85D0F0F04ACD1BC04A1798BD0140FE6036E92273F290DECB631D2DDF38E8CB`.
- Rendered and personally inspected cumulative pages 214--217 at 600 dpi. The 5.10--5.11 seam, Definition 5.12 and footnotes, Proposition 5.13's three-part statement and proof, Proposition 5.14's exterior-power character, Corollary 5.15, formula placement, page flow, and the clean hard stop before section 6 PASS.
- Current master: 10,752 bytes, SHA-256 `DC69F63C9A210F6D8D62DC600586225B6AE6D545FDAB0E49E186ED2B6BD46FBE`.
- Exact next cursor: Expos\'e IX section 6, authority line 1783, physical page 404 / scan index 403 / source folio 392.
- Queue control recorded: after completing SGA 7 I and II, this lane proceeds to FAC and then GAGA unless Floris explicitly reallocates either work.

## 2026-08-01 — English checkpoint 89: Expos\'e IX section 6 complete

- Personally translated and source-aligned all of section 6: the toric construction without semistable reduction (6.1), the fixed-part obstruction and Raynaud example (6.2--6.2.2), the essentially fixed/toric filtration and Proposition 6.3.3, and the trace-function construction of 6.4. Authority `source\expose_IX_body.tex` lines 1783--1842 / scan indices 403--410 / source folios 392--399 / physical authority pages 404--411, stopping before section 7 on the final page.
- Compared all eight physical authority pages directly in four overlapping 1,100-dpi bands per page. Subscripts, primes, infinity signs, orthogonal complements, trace symbols, and terminal punctuation were clear at that resolution; no unresolved feature warranted a 5,000--9,000-dpi escalation. The first mechanical band-generation attempt accidentally repeated the top crop four times; the complete 28-image set was regenerated at the intended overlapping offsets before any source judgment was admitted.
- Direct comparison corrected the working transcription's barred infinity to ordinary $\infty$; restored the printed $p^N A_o^o$ (image of multiplication, not left-subscript torsion); restored $A'_{K'}$ in both terms of (6.3.2); restored the missing prime in the normalization field $K'$; and restored the final trace domain $\pi'$ in place of the transcription's `pi-exclamation' glyph.
- Three obvious printed source slips were corrected transparently in English. Raynaud's example must require $A_K$ simple over $K$, not over $K'$, and $K'/K$ is the ramified quadratic field extension (the print calls it an extension of $S$). The nonexistent forward reference 6.5 was replaced by 5.12, where essential good reduction is actually defined. The French authority and transcription remain unchanged, and all dispositions are recorded in the component comments.
- Active component `148_expose_IX_section_6.tex`: 15,217 bytes, SHA-256 `04D35BFCFF692160139FF331174332FAC79970CA21227A3CD15342B9A9A8DE40`.
- The r1 build passed; its reader render prompted only proper-name/technical-accent cleanup (N\'eron, Dieudonn\'e, and \'etale) and restoration of the heading's terminal period. The no-overwrite r2 build incorporates those reader-facing corrections.
- Three-pass r2 build: PASS, 220 A4 pages. Passes 2 and 3 are byte-identical (25,618 bytes, SHA-256 `B20F3F419B7F6BCD2CB84A290E817C8C3E208D3ACF7BBF1DE58C3D2801FDCE39`). There is no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic; only the pre-existing component-97 `\footnotesize`-in-math-mode warning remains. PDF 1,714,355 bytes, SHA-256 `A1B657A90243949C7062355A22772270DD7DE060D5FDF28CA77D60953F1958A8`; log 43,941 bytes, SHA-256 `551E7E449F51983F80DC91F6ABDCB5735BCE98C036543785B0F2409ED1C431FF`.
- Rendered and personally inspected cumulative pages 217--220 at 600 dpi after r2. The section seam, long underlined heading, Raynaud example, formulas (6.3.1)--(6.3.2), Proposition 6.3.3 and both footnotes, primes/subscripts/orthogonals, page flow, and clean hard stop before section 7 PASS.
- Current master: 10,795 bytes, SHA-256 `66FAF07AB3D5C750A6527E7B8B4D83A2FD6FA80E62399D25783FDC93145E233F`.
- Exact next cursor: Expos\'e IX section 7, authority line 1845, physical page 411 / scan index 410 / source folio 399.

## 2026-08-01 — English checkpoint 90: Expos\'e IX section 7.1 complete

- Personally translated and source-aligned the section-7 heading and 7.1--7.1.6: the formal abelian quotient, its algebraizability criterion, the polarization/biextension construction, Proposition 7.1.5, and Remark 7.1.6. Authority `source\expose_IX_body.tex` lines 1845--1887 / scan indices 410--413 / source folios 399--402 / physical authority pages 411--414, stopping before 7.2.
- Compared all four authority pages directly in four overlapping 1,100-dpi bands per page. Prose, hats, primes, special-fibre subscripts, biextension bases, inverse powers, and terminal punctuation were clear at that resolution; no unresolved feature warranted escalation toward 9,000 dpi.
- Transparent printed-source correction in 7.1.3: the print changes incoherently from an invertible sheaf $\mathbb M$ on $G$ to the restriction $\mathbb L_n$ of $\mathbb L$ to $G_n$. The English uses the type-correct construction fixed by the surrounding text and Proposition 7.1.5: $\mathbb L$ on $A$, $\mathbb L_n$ on $A_n$, and the descended $\mathbb M_n$ on $B_n$. The print remains disclosed in a reader footnote; the French transcription is unchanged.
- Active component `149_expose_IX_section_7_1.tex`: 5,979 bytes, SHA-256 `66730F9BF9981C079B02B2D8379FA60A4A332FA2B86C594652FB55A9DE4AE89B`.
- The first build command mistakenly invoked XeLaTeX and passed a literal output-directory token; it failed before reading the body because this pdfLaTeX master uses `\DeclareUnicodeCharacter`. The sole generated log under the literal `source\$out` directory was inspected and that accidental directory was then removed. No source artifact was lost or altered.
- Correct three-pass pdfLaTeX build: PASS, 221 A4 pages. Passes 2 and 3 are byte-identical (25,675 bytes, SHA-256 `D1F4FAE3AE763B1B67F1CCA414130F2A2170375E6FC7C25A8980679B50D0F654`). There is no fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic; only the pre-existing component-97 `\footnotesize`-in-math-mode warning remains. PDF 1,722,990 bytes, SHA-256 `5D2172BDE3521FF2AF2F0216AFEF47DBF5F94E88B5AE1BC0E53469C14B03B0AC`; log 43,996 bytes, SHA-256 `A6153FC877C3D8CCDD57ECCC4903B7E5825D4CFE9E318583177AB69D7A9DA5D8`.
- Rendered and personally inspected cumulative pages 217--221 at 600 dpi. The section-6 seam, section-7 heading, formulas (7.1.1)--(7.1.4), Proposition 7.1.5, reader footnote, page flow, and clean stop before 7.2 PASS.
- Current master: 10,840 bytes, SHA-256 `3FD7C5A49B157B7D76CD65635D21A8914601BDC9DD71008F670C60B2C21238C4`.
- Exact next cursor: Expos\'e IX section 7.2 / Lemma 7.2.1, authority line 1889, physical page 414 / scan index 413 / source folio 402.

## 2026-08-01 — English checkpoint 91: Expos\'e IX Lemma 7.2.1 complete

- Personally translated and source-aligned Lemma 7.2.1 and its proof 7.2.1.1--7.2.1.5, including full faithfulness of formal completion, algebraization of the identity component by character-group duality, and algebraization of the component extension by finite-flat torsor descent. Authority `source\expose_IX_body.tex` lines 1889--1938 / scan indices 413--417 / source folios 402--406 / physical authority pages 414--418, stopping before 7.2.2.
- Compared all five authority pages directly in four overlapping 1,100-dpi bands per page. Formal hats, identity-component superscripts, character groups, duals, torsor bases, finite-flat descent arrows, and punctuation were clear at that resolution; no feature required higher-detail escalation.
- Transparent source dispositions: the printed statement writes `Specf(A)` and `Spec(A/m^{n+1})` although the adic base ring introduced there is $V$ and $A$ denotes the varying group scheme; the English restores $\operatorname{Spf}(V)$ and $\operatorname{Spec}(V/\underline m^{n+1})$. In 7.2.1.3 the print writes $S$ for the bases of $\Phi_o$ and $\Phi_n$; the English restores $S_o$ and $S_n$. The printed parenthetical citation said to justify representability is blank and is disclosed rather than guessed.
- Active component `150_expose_IX_lemma_7_2_1.tex`: 8,519 bytes, SHA-256 `A8154B759122945D2B5D96BF5C521B20C4F787762D8A6FD37329B8FEA7F947BA`.
- Three-pass build: PASS, 223 A4 pages. Passes 2 and 3 are byte-identical (25,731 bytes, SHA-256 `EC9B28740E94A206F3E9F1C1DA9207B7C35E4EFF17B33EFD4FC21BFF24CC2B78`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode warning remains. PDF 1,736,609 bytes, SHA-256 `EFA95C2ECE0A5512B3DA6ABFA33DEA273E5003BBABCFE730C0FA4C099C84FAD6`; log 44,051 bytes, SHA-256 `411F8E77FC372FD9B7D014DADE8CF7EBCA4F6CF3188AC9141CB1C6D4E569B3E8`.
- Rendered and personally inspected cumulative pages 220--223 at 600 dpi. The 7.1--7.2 seam, long lemma statement, displays $(*)$ and $(**)$, both source-disclosure footnotes, formal hats, torsor formula, page flow, and clean stop before 7.2.2 PASS.
- Checkpoint master: 10,885 bytes, SHA-256 `37053F3942D627555BB933183FF6B95E66676057FCCB2A87D14916FC4DE9785D`.

## 2026-08-01 — English checkpoint 92: Expos\'e IX section 7.2 complete

- Personally translated and source-aligned 7.2.2--7.2.6: construction of the Raynaud group $A^\natural$, canonical formal-completion isomorphism (7.2.3), finite etale component group (7.2.4), extension (7.2.5), and functorial/base-change statement. Authority `source\expose_IX_body.tex` lines 1940--1967 / scan indices 417--418 / source folios 406--407 / physical authority pages 418--419, stopping before 7.3.
- Both authority pages were compared directly in four overlapping 1,100-dpi bands. Natural symbols, hats, identity-component superscripts, exact-sequence arrows, and primes on the adic base ring were unambiguous; no escalation was needed.
- Active component `151_expose_IX_sections_7_2_2_through_7_2_6.tex`: 1,983 bytes, SHA-256 `E284480C0EBBDBBF0B499023829765548B8AEC739E6CBEA6737D7E511A8DA5D2`.
- Three-pass build: PASS, 223 A4 pages. Passes 2 and 3 are byte-identical (25,830 bytes, SHA-256 `8D5C0B1CCFA9B6F92672878EA17CE214E47E564AAD6C08BAFB9CEADEBDFA126D`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode warning remains. PDF 1,738,261 bytes, SHA-256 `93734375D6FC7E1D3785B09696CAD7565006AB68BD2DE2CCD2E4AB2702E8612F`; log 44,138 bytes, SHA-256 `D6D943A38DBFC94700082D410F08D17EB23A08C45F86CB8DBF2B09E3F19813B2`.
- Poppler's Windows build could not open the final PDF at its long absolute path. A byte-identical short-path inspection copy (matching SHA-256) was used solely for `pdfinfo` and rendering. The cumulative terminal page 223 was rendered and personally inspected at 600 dpi: (7.2.3)--(7.2.5), natural symbols, hats, exact sequence, base-change primes, and the hard stop before 7.3 PASS.
- Current master: 10,947 bytes, SHA-256 `F90426C9C2FED0218BB7811C5EBAF623304BE51BC725AA6984AC50C737002E50`.
- Exact next cursor: Expos\'e IX section 7.3, authority line 1969, physical page 419 / scan index 418 / source folio 407.

## 2026-08-01 — English checkpoint 93: Expos\'e IX section 7.3 complete

- Personally translated and source-aligned section 7.3: the fixed, toric, and abelian parts of $T_\ell(A^o)$, the algebraizable identification with $T_\ell(B)$, and the canonical exact sequence obtained from the formal and ordinary Raynaud extensions. Authority `source\expose_IX_body.tex` lines 1969--2015 / scan indices 418--420 / source folios 407--409 / physical authority pages 419--421, stopping before 7.4.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands per page. Hats, natural and identity-component superscripts, exact-sequence arrows, quotient notation, and punctuation were clear at that resolution; no ambiguity required escalation.
- Active component `152_expose_IX_section_7_3.tex`: 2,705 bytes, SHA-256 `0435839CC30A1E6AB1B1685D8BC7EA89E7967BCD7247424B61D871D3ADEA7DE2`.
- Three-pass pdfLaTeX build: PASS, 224 A4 pages. Passes 2 and 3 are byte-identical (25,842 bytes, SHA-256 `3ABFDF3CDDADFC3392F64364FA2668AA40BB134B0204DE983270A276E43BE415`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode font warning remains. PDF 1,741,137 bytes, SHA-256 `77DB2B635BA96297679B396404A26E9FE48EBC55431EABE84FE2BB4AF395259A`; log 44,160 bytes, SHA-256 `3AAD0CC7ADAC42842502DB62EE34D106A155458AB035D07EB96D2E05B50EE5FB`.
- Rendered and personally inspected cumulative pages 222--224 at 600 dpi. The 7.2--7.3 seam, formulas (7.3.1)--(7.3.6), hats, superscripts, quotient, exact sequences, page flow, and clean stop before 7.4 PASS.
- Current master: 10,992 bytes, SHA-256 `807E4733C3849DE828D5300383F13CB9A234935A8F4AB9CED0A5A90DE21E23A7`.
- Exact next cursor: Expos\'e IX section 7.4, authority line 2017, physical page 421 / scan index 420 / source folio 409.

## 2026-08-01 — English checkpoint 94: Expos\'e IX section 7.4 complete

- Personally translated and source-aligned all of 7.4: the biextension pairings (7.4.1)--(7.4.4), algebraization of $W^{ab}$, the isogeny criterion (7.4.5), the proofs of the duality and orthogonality results, and the dual filtrations (7.4.9) over an open $U$. Authority `source\expose_IX_body.tex` lines 2017--2080 / scan indices 420--423 / source folios 409--412 / physical authority pages 421--424, stopping before the summary and Proposition 7.5.
- Compared all four authority pages directly in four overlapping 1,100-dpi bands per page. Hats, primes, abelian superscripts, pairing arrows, dual-abelian notation, the two-row filtration brace, underlining, and punctuation were clear; no higher-resolution escalation was needed.
- Transparently normalized the print's three evident $G/G'$ letter slips in this $A/A'$ construction: the opening hypothesis, the completions in (7.4.2), and the description of $B'_n$. The French authority/transcription remains unchanged.
- Active component `153_expose_IX_section_7_4.tex`: 5,525 bytes, SHA-256 `2922E1B780445706AB442DA83E03B56D9B3256407D8C1F9316AFDD110F07E4D5`.
- Three-pass pdfLaTeX build: PASS, 226 A4 pages. Passes 2 and 3 are byte-identical (25,898 bytes, SHA-256 `7F64B33B4334622C302D2C55D87C276AF0934DFFEE350A4D225762330F64B68E`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode font warning remains. PDF 1,748,893 bytes, SHA-256 `2146CD891F742DE58DE5A54A58C6F5AC4F7737D868146A5F41D571CEE9FA36EF`; log 44,215 bytes, SHA-256 `FFFE3BA484B61087A2D919C6AF76AEEA1266F1C9C872F58316B459C7F513EB06`.
- Rendered and personally inspected cumulative pages 223--226 at 600 dpi. The 7.3--7.4 seam, all nine numbered formulas, hats/primes/superscripts, filtration brace, underlining, page flow, and clean hard stop before Proposition 7.5 PASS.
- Current master: 11,037 bytes, SHA-256 `5DB532169037C07839B3B599F0EA02661FC3A895334E58B450860A9D4A07E6DE`.
- Exact next cursor: the summary preceding Proposition 7.5, authority line 2082, physical page 424 / scan index 423 / source folio 412.

## 2026-08-01 — English checkpoint 95: Expos\'e IX section 7 complete

- Personally translated and source-aligned the summary, Proposition 7.5, its compatibility/polarization observation, and all of 7.6: the functorial abelian part of a semistable N\'{e}ron model, induced divisorial correspondences, and the generic-fibre Raynaud extension $A_K^\natural$. Authority `source\expose_IX_body.tex` lines 2082--2103 / scan indices 423--424 / source folios 412--413 / physical authority pages 424--425, stopping before section 8.
- Compared both authority pages directly in four overlapping 1,100-dpi bands. Underlined proposition text, overbars, primes, $ab/o/\natural$ superscripts, arrows, and formulas (7.6.1)--(7.6.2) were clear; no escalation was needed. Physical page 426 was also checked to confirm the exact section-8 boundary.
- Active component `154_expose_IX_proposition_7_5_and_section_7_6.tex`: 3,043 bytes, SHA-256 `B70A7736A60C5307330BD9B8FE07B3D111757CADFF684D9F94E160127C9AE1A9`.
- Three-pass pdfLaTeX build: PASS, 226 A4 pages. Passes 2 and 3 are byte-identical (25,990 bytes, SHA-256 `676AC0D40B120B630107BA4312AD5246462B691E5FB41763EA9BB4BEE3086313`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode font warning remains. PDF 1,755,718 bytes, SHA-256 `85FB07F0D69814443704B30E7BA4C97BD1389306BBA97E2CE7AEF4FE6BBE43F4`; log 44,299 bytes, SHA-256 `BBE721A8922D16D14A848F6364E88A2B5DC35B3516CFA9548E3D38AEC16C8F6D`.
- Rendered and personally inspected cumulative pages 225--226 at 600 dpi. Proposition 7.5, the dense underlined statement, the section-7.6 formulas and triple identification of the identity component, page flow, and clean hard stop before section 8 PASS.
- Current master: 11,102 bytes, SHA-256 `22C229F67B7789D03703808D75363B2FDFFC7CD3CCC6F34B59F7B13A475F4ACC`.
- Exact next cursor: Expos\'e IX section 8 heading and 8.1, authority line 2109, physical page 426 / scan index 425 / source folio 414.

## 2026-08-01 — English checkpoint 96: Expos\'e IX section 8.1 complete

- Personally translated and source-aligned the section-8 heading and all of 8.1: descent of the non-semistable Raynaud extension, the torus/abelian exact sequence, the essentially fixed and essentially toric Tate-module filtration, and the Cartier-dual description of its third quotient. Authority `source\expose_IX_body.tex` lines 2109--2154 / scan indices 425--427 / source folios 414--416 / physical authority pages 426--428, stopping before 8.2.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands per page. Natural and identity-component superscripts, primes, $ef/et$ superscripts, underlined Hom symbols, tensor subscripts, and formulas (8.1.1)--(8.1.8) were clear; no higher-resolution escalation was needed.
- Active component `155_expose_IX_section_8_1.tex`: 3,584 bytes, SHA-256 `EA93EC93770337144B16CBC44231312D8A39D8509446A34BFFFD5E5729E3AD02`.
- Three-pass pdfLaTeX build: PASS, 227 A4 pages. Passes 2 and 3 are byte-identical (26,012 bytes, SHA-256 `AE109ABBAB5F82824899F6A9EA8FA67E8A3754A866BEF39FB2A49EFA482EEB1F`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,760,129 bytes, SHA-256 `EF9A0D57C84A0A8EB84DFC9C0199F543AF45432054562BB911F4A7AF44952148`; log 44,327 bytes, SHA-256 `F293C9C0F68E43F837909A6489A4BB4B5099ED4876C5C67213E02CECD25F9F31`.
- Rendered and personally inspected cumulative pages 226--227 at 600 dpi. The section-7/8 seam, all eight numbered formulas, primes and superscripts, title underline, page flow, and clean stop before 8.2 PASS. Render hashes: page 226 `F2D6630A469A58A22AFC3206920009D1F0D34AFCED05B82B0F5E01E3C272A061`; page 227 `5D4A4784ABDEAAC7EE346EC289437D66EE18014438DE638EACD5879551D4C540`.
- Current master: 11,147 bytes, SHA-256 `6B3B794F67C08225A95353935AB5BEF0024D13AEC598DE1A063A15307BD9A5CE`.
- Exact next cursor: Expos\'e IX section 8.2, authority line 2159, physical page 428 / scan index 427 / source folio 416.

## 2026-08-01 — English checkpoint 97: Expos\'e IX section 8 complete

- Personally translated and source-aligned sections 8.2--8.3: functoriality and base change for the non-semistable Raynaud extension, descended biextensions and dual abelian quotients, the open-immersion inductive system over finite Galois extensions, and the ind-group $A_K^\flat$. Authority `source\expose_IX_body.tex` lines 2159--2188 / scan indices 427--428 / source folios 416--417 / physical authority pages 428--429, stopping before section 9.
- Compared both authority pages directly in four overlapping 1,100-dpi bands, and checked physical page 430 for the exact section-9 boundary. Natural/flat/identity-component marks, bars, primes, hook arrows, direct limits, quotients, and formulas (8.3.1)--(8.3.4) were clear; no escalation was needed.
- Transparently restored the authority's visible $A_K\longrightarrow A'_K$ polarization isogeny where the working transcription had misplaced the prime as $A_{K'}$. The print's evident phrase "two isomorphic extensions ... of $K'$" was rendered as extensions of $K$, as required by the immediately following restriction to subextensions of $\overline K/K$; the French source remains unchanged.
- Active component `156_expose_IX_sections_8_2_and_8_3.tex`: 3,861 bytes, SHA-256 `9A050D38BCD101A914AA7F902E6ED7A0799B0CCA396D7DD3F4D578F6442CD8E9`.
- Three-pass pdfLaTeX build: PASS, 228 A4 pages. Passes 2 and 3 are byte-identical (26,099 bytes, SHA-256 `4D8D4734140FE94420A960278B0900D35A33AE741C852E0EE819FB9B801E01B5`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,764,508 bytes, SHA-256 `F5E60F9E506FDD07AFD62D2FA121B0A4577E05B7B84F291146715B75B83BBC66`; log 44,406 bytes, SHA-256 `F8938CDFB104342967BA5EDF8317B8C434AA49A3836DC36AB67437553520B217`.
- Rendered and personally inspected cumulative pages 227--228 at 600 dpi. The 8.1--8.2 seam, primes and bars, open-immersion hook, four numbered formulas, direct limits, page flow, and hard stop before section 9 PASS. Render hashes: page 227 `11ACFB7F5083ABF3C11B5153992B12580E085D5F1005D4D2D765DC68D758D35F`; page 228 `84BB388B215C284B8AE2D3BD12646649B01D058A4C10187EC342162640F038B3`.
- Current master: 11,201 bytes, SHA-256 `2D9D2E3ECAC0E52C8ADA04D65A45F957A95A27BF8E3E3813CD6631E8F2B54AF3`.
- Exact next cursor: Expos\'e IX section 9 heading and 9.1, authority line 2194, physical page 430 / scan index 429 / source folio 418.

## 2026-08-01 — English checkpoint 98: Expos\'e IX section 9.1 complete

- Personally translated and source-aligned the section-9 heading and all of 9.1: the twisted constant lattices $\underline M,\underline M'$, their $\ell$-adic sheaves, the canonical monodromy pairing, and its Galois-module formulation. Authority `source\expose_IX_body.tex` lines 2194--2214 / scan indices 429--430 / source folios 418--419 / physical authority pages 430--431, stopping before 9.2.
- Compared both authority pages directly in four overlapping 1,100-dpi bands. Underlines, bars, primes, Tate-module arguments, tensor subscripts, and formulas (9.1.1)--(9.1.3) were clear; no escalation was needed.
- Active component `157_expose_IX_section_9_1.tex`: 2,412 bytes, SHA-256 `1F0BA6C8650D070937FBC2AB112A47F82DD48F0AE113E8C7FA04C7AF19D2AE5B`.
- Three-pass pdfLaTeX build: PASS, 229 A4 pages. Passes 2 and 3 are byte-identical (26,121 bytes, SHA-256 `B33BBA585A02230626F1B4C28B6241B7E2944A4EB6B019B3CCBC0BF1BBEB1963`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,767,708 bytes, SHA-256 `A9D69E570F8BB77ACBF86F92DF7A001EFD2425507BFF3BD88964A472E48D5F74`; log 44,434 bytes, SHA-256 `96A68F790DD7D5CCC1757F50347D72A1A265C769E479B4A60FE64F4BCD08932B`.
- Rendered and personally inspected cumulative pages 228--229 at 600 dpi. The section-8/9 seam, title and term underlines, all three numbered formulas, bars/primes, page flow, and clean stop before 9.2 PASS. Render hashes: page 228 `D8D14328BA114CF26B5FB0B609CDFD4D9F2DF37A3813AA9DE3873C0A75DD770F`; page 229 `66BE2393F31E28E2D3152C0B777C4580EECBDE5EE361C2F1AF3BD650B77F3D6B`.
- Exact next cursor: Expos\'e IX section 9.2, authority line 2216, physical page 431 / scan index 430 / source folio 419.

## 2026-08-01 — English checkpoint 99: Expos\'e IX section 9.2 complete

- Personally translated and source-aligned the full $\ell\neq p$ construction: inertia transvections, orthogonality and Tate twists, the toric/cocharacter identifications, and the resulting canonical monodromy pairing. Authority `source\expose_IX_body.tex` lines 2216--2276 / scan indices 430--432 / source folios 419--421 / physical authority pages 431--433, stopping before mixed extensions in 9.3.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands and checked physical page 434 for the exact 9.3 boundary. Perpendicular/dual/check accents, primes, twists, braces, tensor factors, invariant superscript, and formulas (9.2.1)--(9.2.9) were clear at that resolution; no valid higher-resolution escalation was required.
- Transparently repaired working-transcription slips controlled by the page images and formulas: $x$ rather than $u$ in the generator phrase, $V^\perp$ rather than $V^1$ in (9.2.4), $T'_o$ in the second line of (9.2.7), and stray/missing parentheses. The French transcription remains unchanged.
- Active component `158_expose_IX_section_9_2.tex`: 4,111 bytes, SHA-256 `34F95E7FB813D8141CD1959F3DE6C3FA342F19B05A7BF0E516334888833FB3A6`.
- Three-pass pdfLaTeX build: PASS, 230 A4 pages. Passes 2 and 3 are byte-identical (26,171 bytes, SHA-256 `7D3F1C46694A3FA834165261F9BEA8F95C863384C6F955E96C97BECE8A297E30`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,772,402 bytes, SHA-256 `F3D2DCE21BB59540CF46DA7852413E83B6BC1FB145AA93FD2EA4115F3BA0CA09`; log 44,483 bytes, SHA-256 `E08507B5E115051FB693DE85CCE4F5CB757CA24792C5374AC8593778C5F8C041`.
- Rendered and personally inspected cumulative pages 229--230 at 600 dpi. All nine numbered formulas, the two-row brace, $\check M/\check M'$ accents, primes, twists, invariant superscript, paragraph flow, and hard stop before 9.3 PASS. Render hashes: page 229 `23877F2EDD3B69A0D398A259C18DEF3E3264F3D9BA7665F6EA0CE91C833157D3`; page 230 `9840692EF76C64AEE0582069BEACCB900B069CAD3B49E3257C572BE3A2A4A749`.
- Current master: 11,291 bytes, SHA-256 `330353640604EDE85689CE4AF39D57256C7134954727D744A2255EC0320A2417`.
- Exact next cursor: Expos\'e IX section 9.3, authority line 2279, physical page 433 / scan index 432 / source folio 421.

## 2026-08-01 — English checkpoint 100: Expos\'e IX section 9.3 complete

- Personally translated and source-aligned all of 9.3: the category of mixed extensions, the $\operatorname{EXT}(Q,P)$ action by Brauer composition, Proposition 9.3.8 and its obstruction class, exact-functor compatibility, and the canonical change-of-base coset. Authority `source\expose_IX_body.tex` lines 2279--2430 / scan indices 432--438 / source folios 421--427 / physical authority pages 433--439, stopping before 9.4.
- Compared all seven authority pages directly in overlapping 1,100-dpi bands. The filtration, exact sequences, tildes/bars, Brauer-composition symbols, obstruction group, primes, functor square, and terminal quotient were legible at that resolution. A bounded 5,000-dpi diagram-row crop was generated for the only targeted detail; the lower-label disposition is independently clear in the 1,100-dpi band and in the facing prose.
- Transparently corrected six internally forced print defects while leaving the French transcription unchanged: the graded-piece order $P,R,Q$ to $Q,R,P$; two impossible identifications with $F$ to the required $E$; “prove (d)” to “prove (c)”; $\operatorname{Ext}^2(R,Q)$ to $\operatorname{Ext}^2(Q,P)$; the lower functor label $\omega$ to the prose-defined $\omega'$; and $c_X(Y)$ to $c_X(Y')$. Reader notes disclose every substantive correction. Exact disposition notes: `qa\ix_section_9_3_src_1100\AUTHORITY_DISPOSITION_NOTES.md`, 1,298 bytes, SHA-256 `DAF9E6136F1347FD7BFC151E955DFAE1E746B6F9511B0391D622DD42DD76BB55`.
- Active component `159_expose_IX_section_9_3.tex`: 11,582 bytes, SHA-256 `8CF5CC7061D017C187816127545F4827849F0F513BD6635452B3D12AC17BEE2D`.
- Three-pass pdfLaTeX build: PASS, 233 A4 pages. Passes 2 and 3 are byte-identical (26,233 bytes, SHA-256 `EF7DC14D73AF4D091C3FD3BB66F8D700AEDE1BF14AA2667EF9985F6E883B84D3`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode font warning remains. PDF 1,790,403 bytes, SHA-256 `E6D3E95B1E0F925C623760E767E8C039B3DCD1FEE010DF24F5D58928999683D4`; log 44,544 bytes, SHA-256 `E4D59B1FEE9FFC7E13731AEA333BBCF704979F888FC1DC887748B672B0211D6E`.
- Rendered and personally inspected cumulative pages 230--233 at 600 dpi after the final footnote-placement repair. The 9.2--9.3 seam, three-step filtration, corrected exact sequences, Brauer formulas, proposition underlining, obstruction sequence, native functor square, source-disclosure notes, and clean hard stop before 9.4 PASS. Render hashes: p230 `70C4776D39E408300F937393BB2A9F8F46ECE85914F492EBFB01795901FCCDF3`; p231 `4DC7B1C296AEB83035F16ECAD9D96145A5445E3DE85578EE18FBC70C6B00719B`; p232 `846487246DD429FB17ED0F79E3C8D6F8C6E34B6B78008050C48C03B536F2361F`; p233 `402151C262AEB7E67096827B904DF08D9E129C3CAA070497080CC892E15C8451`.
- Current master: 11,336 bytes, SHA-256 `D7DEC618BF62E7904121CF007567F08EBF25D8C91A426BFFD068666180CF0743`.
- Exact next cursor: Expos\'e IX section 9.4, authority line 2435, physical page 439 / scan index 438 / source folio 427.

## 2026-08-01 — English checkpoint 101: Expos\'e IX section 9.4 complete

- Personally translated and source-aligned all of 9.4: the canonical obstruction pairing for a mixed extension over the generic point, Lemma 9.4.3 and its Kummer-cohomology calculation, Corollary 9.4.4, descent from the strict henselization, and Proposition 9.4.7 on full faithfulness and the local extension criterion. Authority `source\expose_IX_body.tex` lines 2435--2576 / scan indices 438--443 / source folios 427--432 / physical authority pages 439--444, stopping before section 9.5.
- Compared all six authority pages directly in four overlapping 1,100-dpi bands per page. Checks/duals, subscripts, Ext arguments, equation numbers, Kummer arrows, and terminal punctuation were clear; no ambiguity required escalation above 1,100 dpi.
- Transparently corrected source/transcription defects controlled by the scan and the immediately preceding formalism: missing checks and parentheses in Lemma 9.4.3/Corollary 9.4.4; `m>0` for the impossible Kummer choice `m>=0`; `H_{oU}` and `\check H_o` in the base-$U$ construction; `\Lambda_s` for the transcription's `\wedge_s`; printed `Hom(P,Q)` and `Ext^1(P,Q)` to the structurally forced `(Q,P)` order; and nonexistent `(9.4.6.2)` to `(9.4.7.2)`. Reader footnotes disclose the three substantive print corrections. Exact disposition notes: `qa\ix_section_9_4_src_1100\AUTHORITY_DISPOSITION_NOTES.md`, 2,146 bytes, SHA-256 `5749904F2B7A9B929FAFA797BAAE7E9147025F2481B6511F8A1308ED33C6A7BC`.
- Active component `160_expose_IX_section_9_4.tex`: 10,743 bytes, SHA-256 `ADF32FF3CB7809215FFB75F7A0494FC08834937D7F2059791C0AF9A8D1419CBF`.
- The first build invocation passed an unexpanded literal output-directory token and created only generated build artifacts in `source\$out`; after a clean build at the intended path, the exact accidental directory was validated and removed. No source or evidence file was altered.
- Three-pass pdfLaTeX build: PASS, 236 A4 pages. Passes 2 and 3 are byte-identical (26,295 bytes, SHA-256 `E4E1A982998797679DBA4B93ACE0C862BDF07F27E6D2FA18369372CD0E1966A7`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,806,730 bytes, SHA-256 `FB42D0A263CC9E4F51F23BEBE6BFB5186C0DDCBB4CC9C17E17818C4F2BB4008F`; log 44,605 bytes, SHA-256 `7D33CC5E337AD4708BC03EBF979BF8C6B4660527E099939D8CA00669782A93FE`.
- Rendered and personally inspected cumulative pages 232--236 at 600 dpi. The 9.3--9.4 seam, Lemma 9.4.3, Kummer sequence, Corollary 9.4.4, Proposition 9.4.7, all corrected formulas/footnotes, paragraph flow, and clean hard stop before 9.5 PASS. Render hashes: p232 `846487246DD429FB17ED0F79E3C8D6F8C6E34B6B78008050C48C03B536F2361F`; p233 `A70E7510DC19FAD37A1387CEECB7C7AA105C43BF39DD4B4B3104024BD1828233`; p234 `8F8945AE2E937DCE0184454C621800C69E42FD1508D46B34657B913B921115DF`; p235 `18CC3A64590E00E27DB734D86D1B923A58582311CD4515142526EC60B1F3BDC6`; p236 `3F0E03C48571F9A615D5461460FB5D9608F1389C57755FD96BAEA185D5813629`.
- Current master: 11,381 bytes, SHA-256 `A098D0E755A6B77A82044253CFAC3FE419085822D921645F7C6FC1BEAE55187D`.
- Total continuous coverage is 432/528 source folios (81.82%). Exact next cursor: Expos\'e IX section 9.5, authority line 2578, physical page 444 / scan index 443 / source folio 432.

## 2026-08-01 — English checkpoint 102: Expos\'e IX section 9 complete

- Personally translated and source-aligned sections 9.5--9.7: componentwise Barsotti--Tate mixed extensions and their canonical pairing, the fully faithful extension criterion, construction of the canonical semistable monodromy pairing, and its Galois-descent extension without a semistability assumption. Authority `source\expose_IX_body.tex` lines 2578--2711 / scan indices 443--449 / source folios 432--438 / physical authority pages 444--450, stopping before section 10.
- Compared every authority page directly in four overlapping 1,100-dpi bands. Checks, primes, filtration superscripts, Tate-module quotients, Cartier duals, pairing codomains, and normalized-valuation notation were clear; no detail required escalation above 1,100 dpi.
- Transparently corrected source slips where the formalism forced the reading: 9.4.6 to Proposition 9.4.7; the extension over $S$ renamed $X$ rather than $X_\eta$; $Q(n)$ correctly based over $S$; homomorphism (9.5.6) to (9.5.5); printed $F_\eta=D(F'_\eta)$ to $E_\eta=D(F'_\eta)$; printed pairing reference (9.5.6) to (9.5.5); generic-fibre $X_\eta$ over $\eta$ rather than $S$; one missing closing parenthesis and one missing sentence stop. Reader footnotes disclose the substantive corrections; the French source remains unchanged.
- Active component `161_expose_IX_section_9_5.tex`: 7,539 bytes, SHA-256 `5ACA4FFC1DF566EDC20CF08DC95DEF27D985DC34C930C2090D5AC65617D605C7`. Its intermediate three-pass build passed at 238 A4 pages, PDF SHA-256 `AAC5E80ED7CA6C65AA1F0FC769052BB0CAF66C2E27B01BF27CC6DF557750CA88`.
- Active component `162_expose_IX_sections_9_6_and_9_7.tex`: 5,436 bytes, SHA-256 `55AB915D34BC3F8EC26564F7CB7A33CA7A3A8BEA470A8E9D2D8AB87C7362F23D`.
- Three-pass pdfLaTeX build: PASS, 239 A4 pages. Passes 2 and 3 are byte-identical (26,438 bytes, SHA-256 `B2C856E09973A43524D886D9D4238DD1C3192736EF06DBBF75D7517C83BA02D5`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs. PDF 1,826,728 bytes, SHA-256 `C6EA862D655C0FB4570B16489BDAC50EE91BE9DD764CE607216776F67C269B43`; log 44,698 bytes, SHA-256 `0E80A6E8F904379DE5E4DA1479E91FA646BC0C106EB2296915FDD0DA39160874`.
- Rendered and personally inspected cumulative pages 236--239 at 600 dpi. The 9.4--9.5 seam, all mixed-extension and monodromy formulas, corrected quotient, footnotes, page flow, and hard stop before section 10 PASS. Render hashes: p236 `73EBC246B6DAB8572F7757AC88B8E64C0D7F7B4465CC21AEC7811A036B11F96A`; p237 `123165A5174F20E8C6C927A1DBA89071887CE96A45639E0DB537D80719432FF5`; p238 `C9A789E907644361AEC55AC0799C989A71E83FDB266215533365907FBB846A9A`; p239 `1AA08E35740F8BCBCB12CC4CAD878DC0681B94E5CEF2D883AEDEDFDF5C17CB24`.
- Current master: 11,480 bytes, SHA-256 `9EB4A97A82CFC99B8A90E3936DA9B5773F408A2C4CE2B4AA9F062593E63F5154`.
- Total continuous coverage is 438/528 source folios (82.95%). Exact next cursor: Expos\'e IX section 10, authority line 2717, physical page 451 / scan index 450 / source folio 439.

## 2026-08-01 — English checkpoint 103: Expos\'e IX through section 10.2

- Personally translated and source-aligned the section-10 opening and sections 10.1--10.2: formal properties of monodromy pairings, transport of structure, symmetry under duality, the polarized symmetric form, and the equivalent transpose relation for arbitrary biextensions. Authority `source\expose_IX_body.tex` lines 2717--2786 / scan indices 450--452 / source folios 439--441 / physical authority pages 451--453, stopping before 10.3. Physical page 454 was also checked to fix the exact boundary.
- Compared all four relevant authority pages directly in four overlapping 1,100-dpi bands. Dual primes, overbars, toric subscripts, transposes, tensor order, symmetry arrows, formula tags, and punctuation were clear; no escalation was required.
- Transparently resolved two print defects: the undefined right-hand $\varphi^t$ in (10.2.7) is the underlying monodromy pairing $u_\ell^{A_K}$ used in the identical construction (10.2.4), and the printed claim that the canonical Weil biextension gives pairing (9.2.1) was corrected to (9.1.2), since (9.2.1) is instead the inertia-orthogonality formula. Both are disclosed in reader footnotes; the French source remains unchanged.
- Active component `163_expose_IX_sections_10_0_through_10_2.tex`: 5,799 bytes, SHA-256 `1B4173071605CA599400C871CAF6FD55CED62479F2F655DAB7D21F0BA4C56005`.
- Three-pass pdfLaTeX build: PASS, 241 A4 pages. Passes 2 and 3 are byte-identical (26,523 bytes, SHA-256 `18388387DBF6D9CB164ED55261F622F5CECD2FCE5D9A6B25D320CA28B9D602AD`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs. PDF 1,836,040 bytes, SHA-256 `54007A2AA9CC06C649F05C877111779CFABF62FF0399AC3E15794CBB106D1D30`; log 44,777 bytes, SHA-256 `9E25DC4AD7B8145AF7A0C2CBEB3A31AFB979D674E7EF82B605019294D9856F55`.
- Rendered and personally inspected cumulative pages 239--241 at 600 dpi. The section-9/10 seam, all eight numbered formulas, dual and transpose notation, source-disclosure footnotes, paragraph flow, and hard stop before 10.3 PASS. Render hashes: p239 `C27AF1FA807BE61C83AE53E459A480CC3B254E59CB555387EF35B8703DB5659F`; p240 `1029AFA6AF5B03C7FAB6EE49C566BE47EA1F99F2359CA8C22E654DD23BE0DA09`; p241 `6E472177474BD6B3054A7F9C250728C5D7811C89CC973585126240D711611D8B`.
- Current master: 11,540 bytes, SHA-256 `00976ED35F6588CF1ABD4A277136620FBB4993C3DC8F40CCBF55BEFAAD404331`.
- Total continuous coverage is 441/528 source folios (83.52%). Exact next cursor: Expos\'e IX section 10.3, authority line 2792, physical page 454 / scan index 453 / source folio 442.

## 2026-08-01 — English checkpoint 104: Expos\'e IX through section 10.4

- Personally translated and source-aligned sections 10.3--10.4: change of henselian trait and ramification scaling of the monodromy pairing, the integral pairing theorem, and the symmetric positive nondegenerate form induced by a polarization. Authority `source\expose_IX_body.tex` lines 2792--2883 / scan indices 453--455 / source folios 442--444 / physical authority pages 454--456, stopping before section 10.5. Physical page 457 was also checked to establish the exact boundary.
- Compared all four relevant authority pages directly in four overlapping 1,100-dpi bands. The tame-inertia products, primes, base-change subscripts, formula tags, four-arrow square, polarization notation, underlining, and punctuation were clear; no detail required escalation above 1,100 dpi.
- Transparently repaired three source defects while preserving the French source: the printed citation (10.3.3) was corrected to the multiplication formula (10.3.4); the printed ``norm'' inducing `K^*/V^*\simeq\mathbb Z` was rendered as the normalized discrete valuation; and the right-hand side of (10.4.2) was given the same subscripted name `\varphi_\xi^t` as its declared left-hand side. The blank internal reference after ``Expos\'e I'' is disclosed rather than guessed.
- Active component `164_expose_IX_sections_10_3_and_10_4.tex`: 4,942 bytes, SHA-256 `33767E2FDC74EFB6BC822F255C965F1E5BF12EEF2F392EEAA19595631724AA52`.
- Three-pass pdfLaTeX build: PASS, 242 A4 pages. Passes 2 and 3 are byte-identical (26,588 bytes, SHA-256 `F0082D09124916EF7FE0EC329D4CE90F844CEAB0D70AF587AE52E9EFE67536BD`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,844,604 bytes, SHA-256 `1B2BEE359CB090634481B47CC4AB51BF9A3339BD88B0C0E09F50B89BB2BC2604`; log 44,881 bytes, SHA-256 `AF6CCB6980E290E71447F7A40C0507221B703346169C14F9028E73907623A315`.
- Rendered and personally inspected cumulative pages 240--242 at 600 dpi. The 10.2--10.3 seam, all five new numbered formulas, the native commutative square and label placement, source-disclosure footnotes, Theorem 10.4 underlining, paragraph flow, and clean hard stop before 10.5 PASS. Render hashes: p240 `1029AFA6AF5B03C7FAB6EE49C566BE47EA1F99F2359CA8C22E654DD23BE0DA09`; p241 `F749C4EB299CAF987EE61FAA43EC155BFCA8A25C3E764A2A691E8BEE8D0B3AA7`; p242 `007224DD0D29393DF5284A1578CD39052A42AF80DF78AFD9A35DC9E3FE142770`.
- Current master: 11,596 bytes, SHA-256 `4CA8C58D7F2CCA53BD2CE4321E3FEC1715FE1460AB489CAB662E4684914CF196`.
- Total continuous coverage is 444/528 source folios (84.09%). Exact next cursor: Expos\'e IX section 10.5, authority line 2889, physical page 457 / scan index 456 / source folio 445.

## 2026-08-01 — English checkpoint 105: Expos\'e IX section 10 complete

- Personally translated and source-aligned all of section 10.5: rational and integral descent of the monodromy pairing, invariance under isogeny and direct factors, reduction to Jacobians with semistable curve models, and independence of the positivity/nondegeneracy assertions from the chosen polarization. Authority `source\expose_IX_body.tex` lines 2889--2955 / scan indices 456--459 / source folios 445--448 / physical authority pages 457--460, stopping at the section-11 heading on the same terminal page.
- Compared all four authority pages directly in four overlapping 1,100-dpi bands. Transposes, Rosati involutions, primes, tensor subscripts, sums, formula tags, and citation blanks were clear; no detail required escalation above 1,100 dpi. This follows the adaptive 1,100--9,000-dpi rule: higher resolution is used only when the scan actually leaves a reading unresolved.
- Transparently corrected two visible source typos while preserving the French transcription: the direct-factor abelian scheme $\overline A_K$ is over $K$, not $k$, and the curve $X_K$ is over $K$, not $X$. The blank citation pinpoint after [15] and the blank internal reference after Expos\'e V are disclosed rather than guessed.
- Active component `165_expose_IX_section_10_5.tex`: 6,982 bytes, SHA-256 `41985CC67348AD23154C6B240A995783AA6C74BCA57F9D8A01565F1AF771E69D`.
- The first build invocation passed an unexpanded literal output-directory token and created generated artifacts only in `source\$build`. After the correct checkpoint build succeeded, that exact scratch directory was resolved under the working root, verified, and removed; no source or evidence file was lost.
- Three-pass pdfLaTeX build: PASS, 244 A4 pages. Passes 2 and 3 are byte-identical (26,485 bytes, SHA-256 `37E75B973D0E92A22E31EB2411050CAA1A386B2B21D924EA35DB04F4DBADDCF3`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode font warning remains. PDF 1,853,604 bytes, SHA-256 `89E74BAAFC44F59B70710D1BB0C1997EF43B3655E1EBBD25409530A3C3AC8335`; log 44,928 bytes, SHA-256 `D0315898E3BAE7B3BC7173201B32A35A6E6AF1B3EEC20F06E40602B8E76F4C1D`.
- Rendered and personally inspected cumulative pages 242--244 at 600 dpi. The 10.4--10.5 seam, all displayed formulas, transpose/Rosati notation, source-disclosure notes, paragraph flow, and clean section ending PASS. Render hashes: p242 `FADE265075A063EFC1FA2B9C04F47D60B13D80FC0FE3BD85476B3EEA27E2B8A7`; p243 `1CE936B47DB22E60D9D70B888163CA4671287CE9694AF6761258B811470147AE`; p244 `B5FBCE6BAB8D5ABA0FCAB2413D0BF0B8BDFA7616F071ACB1E6215F4189F31C62`.
- Current master: 11,642 bytes, SHA-256 `487E9590D8AA77F6A354ED7A4DBA980F85716876E57EAD7EE93806758CD8FC80`.
- Total continuous coverage is 448/528 source folios (84.85%). Exact next cursor: Expos\'e IX section 11 heading and 11.0, authority line 2956, physical page 460 / scan index 459 / source folio 448.

## 2026-08-01 — English checkpoint 106: Expos\'e IX through Proposition 11.2

- Personally translated and source-aligned the section-11 heading, 11.0--11.1, and Proposition 11.2: reduction to a strictly local trait, the component group as $A(K)/A(K)^o$, its prime-to-$p$ torsion, passage to inertia invariants in the Tate module, and the canonical formula for $\Phi_o(\ell)$. Authority `source\expose_IX_body.tex` lines 2956--3027 / scan indices 459--462 / source folios 448--451 / physical authority pages 460--463, stopping before section 11.3 on the same terminal page.
- Compared all four authority pages directly in four overlapping 1,100-dpi bands. Bars, tildes, invariant superscripts, torsion subscripts, tensor bases, quotient placement, underlining, and formula tags were clear; no detail required escalation above 1,100 dpi.
- Restored one direct scan-controlled transcription slip: the family in 11.0 is $\Phi_o(\ell)$, not $\Phi_o(1)$. No French source wording or mathematical claim was otherwise altered.
- Active component `166_expose_IX_sections_11_0_through_11_2.tex`: 4,904 bytes, SHA-256 `4CDBB9F9E50BF8BAB1C6DCF88FB1C731E3D9FBFABDEEC5CF96FD246E1FC28822`.
- Three-pass pdfLaTeX build: PASS, 245 A4 pages. Passes 2 and 3 are byte-identical (26,726 bytes, SHA-256 `3D2FECB8CBD0A1B1A286B901F7FC9B006610B9387C327A605C7B5EEE85F8A2B1`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs; only the pre-existing component-97 `\footnotesize`-in-math-mode font warning remains. PDF 1,860,287 bytes, SHA-256 `0FBDFFA36BDC82A578F90E5EEE891AAF2D8D789E478C7C9AD836E0A7C27A585D`; log 45,013 bytes, SHA-256 `485EF63099CEE669D89AFB6C5F53A53D961DB1BD42D28AEEE63FAD001CC255C3`.
- Rendered cumulative pages 243--245 at 600 dpi and personally inspected the two changed terminal pages 244--245. The section-10/11 seam, all eight numbered formulas, quotient and invariant placement, Proposition 11.2 underlining, paragraph flow, and clean hard stop before 11.3 PASS. Render hashes: p243 `1CE936B47DB22E60D9D70B888163CA4671287CE9694AF6761258B811470147AE`; p244 `7C9C83FD3A9E4BD492D8508758C40EB9B6C9AA04314D95638E7CAB4F250A22AC`; p245 `39D29F1F9021703E779E4D42FB49C916FE3C15B7D8E0C74B819BFBB81CA0C27F`.
- Current master: 11,702 bytes, SHA-256 `532B3C91289F8A03B052A4FB11BBBFA1941D1D66C26DF3E5FBD9C83412A6F3C9`.
- Total continuous coverage is 451/528 source folios (85.42%). Exact next cursor: Expos\'e IX section 11.3, authority line 3029, physical page 463 / scan index 462 / source folio 451.

## 2026-08-01 — English checkpoint 107: Expos\'e IX section 11.3 complete

- Personally translated and source-aligned all of 11.3: the canonical perfect duality on the $\ell$-primary component groups, its formulation through continuous cohomology of inertia, the torsion description of $\Phi$, finite-level Cartier duality, and the transpose construction yielding the pairing. Authority `source\expose_IX_body.tex` lines 3029--3147 / scan indices 462--465 / source folios 451--454 / physical authority pages 463--466, stopping exactly before section 11.4 on the terminal page.
- Compared all four authority pages directly in four overlapping 1,100-dpi bands per page. The two source diagrams, all arrows and arrow directions, vertical isomorphism signs, primes, superscripts, tensor bases, quotient bars, and formula tags were clear; no unresolved detail required escalation above 1,100 dpi.
- The printed source leaves the internal reference following the first occurrence of $I$ blank; the English reader discloses the blank rather than inventing a target. No French mathematical claim was otherwise altered.
- Active component `167_expose_IX_section_11_3.tex`: 6,008 bytes, SHA-256 `146F47E5823BBCD3BFFAB02C532175525C00B8053A065FE8951685BC12273A04`.
- The first compile attempt used XeLaTeX, which is not this reader's engine and stopped before producing pages at the pre-existing `\DeclareUnicodeCharacter` setup. The correct three-pass pdfLaTeX build then passed cleanly; no source edit was needed for that engine correction.
- Three-pass pdfLaTeX build: PASS, 247 A4 pages. Passes 2 and 3 are byte-identical (26,725 bytes, SHA-256 `C7B7D5B9339F4C0DC2CBD186A60FA9F465230937F05A28542FFF0E5E2E0F0035`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,869,471 bytes, SHA-256 `31BAE6F4830DF8B689DB802EE2D5155ACF3EA275C597BD8F811A86DD9618268F`; log 44,986 bytes, SHA-256 `ACB2A46156B5E826E756CF9A9362FA662CF79ACA982EE8359A7D9E9AC485CBC9`.
- Rendered and personally inspected cumulative pages 245--247 at 600 dpi. The 11.2--11.3 seam, wide exact-cohomology diagram, all thirteen numbered formulas, transpose diagram, footnote placement, paragraph flow, and clean hard stop before 11.4 PASS. Render hashes: p245 `311232D4B346FE02AE27F170DB46F1A14EF8E3675D6F9369E80592B1FA73D475`; p246 `42575A2741E922B8417352294385E631F7CF5B0AB9BD347C4513843C29EE2C8E`; p247 `07D91392229CBE754511F68F53982B10084C416D98DD97C98B9AB5BCC8C38FF6`.
- Current master: 11,748 bytes, SHA-256 `CB1A8024693581CC0BC905F85B10A90D2FD24CD86DA247005F133104C718F123`.
- Total continuous coverage is 454/528 source folios (85.98%). Exact next cursor: Expos\'e IX section 11.4, authority line 3148, physical page 466 / scan index 465 / source folio 454.

## 2026-08-01 — English checkpoint 108: Expos\'e IX through Remarks 11.5.2

- Personally translated and source-aligned sections 11.4--11.5: the perfect component-group pairing in the semistable case, Theorem 11.5 identifying the component group as the cokernel of the monodromy homomorphism, its dual formulation, and the prime-independent integral formulation in Remarks 11.5.2. Authority `source\expose_IX_body.tex` lines 3148--3191 / scan indices 465--467 / source folios 454--456 / physical authority pages 466--468, stopping exactly before section 11.6 on the terminal page.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands per page. Checks, primes, transposes, underlines, cokernels, displayed arrows, subscripts, and formula tags were clear; no unresolved detail required escalation above 1,100 dpi.
- Transparently corrected the printed self-reference ``as in 11.4'' within section 11.4 to the immediately preceding construction in 11.3. A reader footnote records the printed reading and correction; the French source remains unchanged.
- Active component `168_expose_IX_sections_11_4_and_11_5.tex`: 3,521 bytes, SHA-256 `E689A4DA415256CEEAC92C23379B216EB6AFE3CA733E995E6758DE1FEA0AC7D1`.
- The first build invocation passed an unexpanded literal output-directory token and created generated artifacts only in `source\$out`. The exact scratch directory was resolved beneath the working root and removed; no source or evidence file was altered. The same TeX then built at the intended checkpoint path.
- Three-pass pdfLaTeX build: PASS, 248 A4 pages. Passes 2 and 3 are byte-identical (26,828 bytes, SHA-256 `F70E2454040A1B758EAB83F3F406301FD62F5477D2BB2A8E759EF1F6B8F70FE3`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,874,183 bytes, SHA-256 `4222E19B3A0BA4C5EE7854C5264C5EAD19CBB7340781CCD6D3F61D2D50BA1856`; log 45,076 bytes, SHA-256 `74EC802C0EAC527F1AAF4068CB77706A4CB867C0C6626A3E96A376DFECE36E17`.
- Rendered and personally inspected cumulative pages 247--248 at 600 dpi. The 11.3--11.4 seam, Theorem 11.5 underlining, all four displayed formulas, transpose/check/prime placement, source-correction footnote, paragraph flow, and clean hard stop before 11.6 PASS. Render hashes: p247 `A9EE5E16AC2C2CE130D60BDC2739EF19EBCDCBBC47968D2D72A6151DD59D6DD5`; p248 `F25622F4217D8BFDE869D0E9225070A6D8A48F9815BEB211B9FAB299CDB3AFA1`.
- Current master: 11,804 bytes, SHA-256 `9DCF2813A805195CE026BE7B6AAA7022C6CBF4469AF4417E2522E52E6238AEAC`.
- Total continuous coverage is 456/528 source folios (86.36%). Exact next cursor: Expos\'e IX section 11.6, authority line 3192, physical page 468 / scan index 467 / source folio 456.

## 2026-08-01 — English checkpoint 109: Expos\'e IX section 11.6 through Lemma 11.6.13 statement

- Personally translated and source-aligned the opening construction of section 11.6 through the statement of Lemma 11.6.13: the finite-level form of Theorem 11.5, the fixed/toric filtration of ${}_nA$, the \'etale scheme ${}_n\Psi$, Lemma 11.6.8 and its open immersion, the finite open component scheme ${}_n\Phi$, and the kernel assertion whose proof remains next. Authority `source\expose_IX_body.tex` lines 3192--3299 / scan indices 467--470 / source folios 456--459 / physical authority pages 468--471, stopping exactly before the proof of Lemma 11.6.13.
- Compared all four authority pages directly in four overlapping 1,100-dpi bands per page. Checks, primes, subscripts, quotient bars, hook arrows, underlines, formula tags, and punctuation were clear; no unresolved detail required escalation above 1,100 dpi.
- Corrected one genuine printed formula contradiction transparently: the source labels the infinite quotients $V/M_\ell$ and $V/\check M'_\ell$ as finite component groups. The English text instead identifies them as the source and target of $\widetilde u_\ell\otimes D_\ell$, whose kernel is the finite cokernel $\check M'_\ell/M_\ell$; a reader footnote records the printed labels and the correction.
- Active component `169_expose_IX_section_11_6_opening_through_lemma_11_6_13.tex`: 7,334 bytes, SHA-256 `5718815DD881473F153FF183FCAFCC7A452FF048A814E2D216869F7FD64FA70A`.
- The first rendered check exposed a missing TeX escape that printed the command name `qquad` in formula display. The source line was corrected to `\qquad`, rebuilt, and the final pages were re-rendered; no defective PDF identity is retained as current.
- Final three-pass pdfLaTeX build: PASS, 250 A4 pages. Passes 2 and 3 are byte-identical (26,908 bytes, SHA-256 `CE0309CFDBCF74A2C15B8DE9EFCA6B518C6810CDD3BB63031648C11478906D9F`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,884,054 bytes, SHA-256 `01176D8EA02F7B8B15F1C4C2E6188D51FED768EA45A3EB71D8393CA2ABD36F05`; log 45,156 bytes, SHA-256 `5E8050CF640AB9A6F7C8E3789B394178EDB419B1F711241DF7E8FA752B1C9125`.
- Rendered and personally inspected cumulative pages 248--250 at 600 dpi after the repair. The 11.5--11.6 seam, all twelve numbered formulas, the finite/infinite quotient correction and footnote, open-immersion hooks, Lemmas 11.6.8 and 11.6.13 underlining, paragraph flow, and clean proof boundary PASS. Final render hashes: p248 `39BDBE46635776E05E3E72D5C751A34817D14FA00CC98097BEED2723A82395BA`; p249 `CE15939462AABF03108B828EFD0ECF54B17A5FDDD427A296256E90C62994D3D1`; p250 `998E1494A8C6E6084098DE51251A37FD8A3992605873CC32F0A3C693800647AB`.
- Current master: 11,880 bytes, SHA-256 `E9066945FD3B3DF4ACB32C0D5B360E83DF173EBC32FF5FE5510BDDCDDF1EAC54`.
- Total continuous coverage is 459/528 source folios (86.93%). Exact next cursor: proof of Lemma 11.6.13, authority line 3304, physical page 472 / scan index 471 / source folio 460.

## 2026-08-01 — English checkpoint 110: Lemma 11.6.13 proved and Remarks 11.7 complete

- Personally translated and source-aligned the proof of Lemma 11.6.13 and all of Remarks 11.7: the annihilator characterization of $K_n$, the two finite-level extension diagrams, the extension criterion for the mixed extension, the identification $K_n={}_n\Phi$, and reconstruction of the inductive/projective system of mixed extensions. Authority `source\expose_IX_body.tex` lines 3304--3391 / scan indices 471--473 / source folios 460--462 / physical authority pages 472--474, stopping exactly before section 11.8.
- Compared all three authority pages directly in four overlapping 1,100-dpi bands per page. Both diagrams, their exact nodes and arrows, equality/isomorphism marks, checks, primes, bars, punctuation, and surrounding formula attachment were decisive at that resolution; under the adaptive 1,100--9,000-dpi rule, no higher-resolution escalation was warranted.
- Transparently corrected four internally forced print defects while preserving the French source: nonexistent `(11.7.5)` to `(11.6.5)`; the extension-criterion citation 9.4.6 to Proposition 9.4.7; the varying subgroup $K'_n$ in the general criterion where the print prematurely says $K_n$; and the self-reference “construction made in 11.7” to the construction just completed in 11.6. Reader footnotes disclose each correction.
- Active component `170_expose_IX_lemma_11_6_13_proof_and_remarks_11_7.tex`: 5,799 bytes, SHA-256 `C65993F1658FE7D8320D903EFE236D9E269EE99CE2D394746C24D1AD0F4D182B`.
- The first build used the repository root rather than the source directory and therefore could not resolve relative component paths. The next compile exposed two local TikZ-cd wrapping issues in the new wide diagram (math-mode protection and macro-argument ampersand catcodes); both were repaired without altering mathematical content before the retained build.
- Final three-pass pdfLaTeX build: PASS, 252 A4 pages. Passes 2 and 3 are byte-identical (27,025 bytes, SHA-256 `E95DF9C658F48F561BF3502CDC549E31E7FA073AD3E1030A5FB98CFBE20E7942`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs. PDF 1,892,600 bytes, SHA-256 `E0343759506503179EE0CA1A766EECB57073E048C1CDD21D30A751EB9C3CE301`; log 45,264 bytes, SHA-256 `34ECD6A9872B403B77F9E2CC6A3A8C4E05960B416408C2E44F884BBE77373E29`.
- Rendered and personally inspected cumulative pages 249--252 at 600 dpi. The pre-existing/new seam, both extension diagrams, checks and primes, equality/isomorphism placement, four source-correction footnotes, paragraph flow, and clean hard stop before 11.8 PASS. Render hashes: p249 `CE15939462AABF03108B828EFD0ECF54B17A5FDDD427A296256E90C62994D3D1`; p250 `998E1494A8C6E6084098DE51251A37FD8A3992605873CC32F0A3C693800647AB`; p251 `943981E6DF099A323124177D57B6B7CAE7D95F81B2B4610D12450604A739CA33`; p252 `E01A6D031B27C7BD3D9F96350DE3623AD7CCF9D537ADFE2B3459FAB0A90C6218`.
- Current master: 11,950 bytes, SHA-256 `18F36A93BD27A3900C6606DCE005AEA80662B33E6C9CA2EF2DD86518F5B7723B`.
- Total continuous coverage is 462/528 source folios (87.50%). Exact next cursor: Expos\'e IX section 11.8, authority line 3393, physical page 474 / scan index 473 / source folio 462.

## 2026-08-01 — English checkpoint 111: Expos\'e IX through Remarks 11.11

- Personally translated and source-aligned sections 11.8--11.11: the inductive system of component groups over finite subextensions, its prime-primary embeddings into the monodromy lattice, Theorem 11.9 identifying the limit with $M\otimes\mathbb Q/\mathbb Z$, Corollary 11.10 for $A_K^{\flat}$, and both concluding remarks. Authority `source\expose_IX_body.tex` lines 3393--3446 / scan indices 473--475 / source folios 462--464 / physical authority pages 474--476, stopping exactly before section 12. Physical page 477 was checked to establish the boundary.
- Compared the three content pages and the section-12 boundary directly in four overlapping 1,100-dpi bands per page. Quotients, checks, primes, direct limits, hook arrows, underlines, ind-group notation, subscripts/superscripts, and punctuation were decisive; no higher-resolution escalation was warranted under the adaptive 1,100--9,000-dpi rule.
- Restored two page-controlled transcription slips without modifying the French working tree: the quotient sign in (11.8.1), which the transcription had reduced to a comma, and $\Phi[K'](\ell)$ rather than $\Psi[K'](\ell)$ on the left of (11.8.3). The printed blank pinpoint after “cf. I” is disclosed in a reader footnote rather than guessed.
- Active component `171_expose_IX_sections_11_8_through_11_11.tex`: 5,025 bytes, SHA-256 `0D3322AF562EB8CDE8C9560CBA8811B2E733C2CD07534F2FDAFB665897EF931B`.
- Three-pass pdfLaTeX build: PASS, 253 A4 pages. Passes 2 and 3 are byte-identical (27,083 bytes, SHA-256 `33BFFE3F88868FB9DEBCAF46EC08BF95C8D34FA0833483640114E3EC9C6E3BDF`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs. PDF 1,899,976 bytes, SHA-256 `0E099ADA15A26B41D355FB3E00B5E5F0E6E8A0A27EB7157562C409860F141DD0`; log 45,322 bytes, SHA-256 `8EF053739AAAB0997C0941DE6378745D3796DC2BAE2452CB5BF1137AA89ECD59`.
- Rendered and personally inspected cumulative pages 251--253 at 600 dpi. The preceding proof/new-section seam, all five numbered formulas, direct-limit subscripts, theorem/corollary/remarks underlining, source-disclosure footnote, page flow, and clean hard stop before section 12 PASS. Render hashes: p251 `943981E6DF099A323124177D57B6B7CAE7D95F81B2B4610D12450604A739CA33`; p252 `108A35D14996E4B27FAC5C6C7438C5EC10DF2D2DFD1C8BDB512D81311E396083`; p253 `40E0BE7384EFF4BA7013970BE362CA76D58951D8808A42090D3682B6C4F664FE`.
- Current master: 12,011 bytes, SHA-256 `FBDB5429BCC9921B0A813F76BD2F1CE7537E986A8358C4A97C7D396FA7E03366`.
- Total continuous coverage is 464/528 source folios (87.88%). Exact next cursor: Expos\'e IX section 12 heading and Theorem 12.1, authority line 3452, physical page 477 / scan index 476 / source folio 465.

## 2026-08-01 — English checkpoint 112: Expos\'e IX through section 12.2

- Personally translated and source-aligned the section-12 heading, Raynaud's Theorem 12.1 in full, Remarks 12.1.11, and section 12.2: representability of the relative Picard functor, its identity closure and separated quotient, the explicit N\'eron model of the Jacobian, and the ordinary-double-point criterion for semistable reduction. Authority `source\expose_IX_body.tex` lines 3452--3547 / scan indices 476--480 / source folios 465--469 / physical authority pages 477--481, stopping exactly before section 12.3.
- Compared all five authority pages directly in four overlapping 1,100-dpi bands per page. Fibre indices, gcd superscripts, exact-sequence arrows, Picard superscripts/subscripts, overbars, implication arrows, underlining, and punctuation were decisive. No ambiguity warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- Restored the scan-controlled missing $i$ in $\underline{\mathcal O}_{X_o,x_i}$. The reader also discloses rather than silently normalizes the print's statement that $\underline{\mathcal O}_X(X_o^i)$ is ``on $S$'' and its later reversal $X_i^o$, and it records the blank internal locator after ``III'' without inventing a target. The French working transcription remains unchanged.
- Active component `172_expose_IX_section_12_1_through_12_2.tex`: 8,568 bytes, SHA-256 `18B83CAF4C79FDE1D2D975310164C8B07B2D814FCAD410C7D435DF7C1B3F24E4`.
- Final three-pass pdfLaTeX build: PASS, 256 A4 pages. Passes 2 and 3 are byte-identical (27,151 bytes, SHA-256 `24FEFB709BCA3C44CAE43B97A21D8445EBCE4BFF9CBFA036BDD2D913AE31BCD9`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs. PDF 1,918,688 bytes, SHA-256 `F0EB9D841B6752593E8BF60763B42F17C988205B0CFB21A7ABA3CBF7CE08FAFB`; log 45,391 bytes, SHA-256 `2ED9CA8C48E8E2161A6A21B8841F11F0D6ED2F4388459138F29EFAB18B66E7F1`.
- Rendered and personally inspected cumulative pages 253--256 at 600 dpi. The 11.11--12 seam, all twelve numbered formulas, theorem underlining, source-disclosure footnotes, paragraph flow, and clean hard stop before 12.3 PASS. Render hashes: p253 `632C33E2F6C62807862151A51F35C6C4516179CACF6B2DB14676F8BAF3E86F09`; p254 `3DABE31FD8302C3AB73797AE5CF9482E6833D4320C1D5987672DF92F75EDF53B`; p255 `069299BAAE0EAE4E3E2B424C7070664A2F13A5E65BD338E2C1C98762B9AB18CA`; p256 `46DA2B054E759FE6DC120DFEA3CF0D6DA39722AAEADD365F3CF1947BC24A0E48`.
- Current master: 12,070 bytes, SHA-256 `0602899FE09D803DB6EEDBA7F507EC2292A89054CA0CFB5DCBF8946463069C32`.
- Total continuous coverage is 469/528 source folios (88.83%). Exact next cursor: Expos\'e IX section 12.3, authority line 3549, physical page 481 / scan index 480 / source folio 469.

## 2026-08-01 — English checkpoint 113: Expos\'e IX section 12.3 complete

- Personally translated and source-aligned all of section 12.3: the dual graph of the special fibre, the canonical map from its cycle group to the toric character lattice, the intersection pairing, its equality with the monodromy pairing, and the resulting exact sequence. Authority `source\expose_IX_body.tex` lines 3549--3642 / scan indices 480--484 / source folios 469--473 / physical authority pages 481--485, stopping exactly before section 12.4.
- Physical page 481 had already been inspected at the preceding seam; pages 482--485 were compared directly in four overlapping 1,100-dpi bands per page. Subscripts, tildes, graph vertices and edges, boundary signs, pairing brackets, direct-sum indices, exact-sequence arrows, and formula tags were decisive. No unresolved detail warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- Five source-controlled corrections are disclosed in reader footnotes while leaving the French working transcription unchanged: the final printed `Pic^o_{X/k}` is corrected to `Pic^o_{C/k}`; printed tags `(12.2.3)` and `(12.2.4)` are corrected to `(12.3.3)` and `(12.3.4)`; the canonical-map display cited immediately afterward is supplied the missing tag `(12.3.8)`; the chain group in (12.3.13) is restored as `Z^{(\Gamma_1)}` rather than printed `Z^{(\Gamma)}`; and the transcription's `\widetilde C_i\times_C\widetilde C_1` is restored from the scan as `\widetilde C_i\times_C\widetilde C_i`.
- Active component `173_expose_IX_section_12_3.tex`: 8,098 bytes, SHA-256 `4E46C94CBCFB24BFA6BD0BB65EB902DF9A39EB90A010339845BECA38D4C7FB28`.
- Three-pass pdfLaTeX build: PASS, 258 A4 pages. Passes 2 and 3 are byte-identical (27,244 bytes, SHA-256 `3B690BBF85E7022A86BA9AA2DE8CD84CD7DCCA320EDDE08BA3C5532E32B5FF6C`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination diagnostic occurs. PDF 1,939,844 bytes, SHA-256 `7A5AA4A0A77686CF9ED9898995BA23E16EED78D364A5C7388314BD8952E5C1E9`; log 45,496 bytes, SHA-256 `90BB2F313A483450D9EF496601337EA6CAEE4F32301A93C73DD06D9F2E406771`.
- Rendered and personally inspected cumulative pages 255--258 at 600 dpi. The 12.2--12.3 seam, all displayed maps and exact sequences, the wide chain complex, correction footnotes, paragraph flow, and clean hard stop before 12.4 PASS. Render hashes: p255 `069299BAAE0EAE4E3E2B424C7070664A2F13A5E65BD338E2C1C98762B9AB18CA`; p256 `FD18ADFFA224D6F883429B1C2005DED6954E5FACA360E72701168F6F8BE1FA2C`; p257 `DC55249DC5E6FCEFBE1795BE1AE6F63091BAD75F7F7C17C44A05930126680194`; p258 `4D4587B61A634942F4E1C3E610FE6E365C110B9D7FE4AF557CA79982FC0AD35B`.
- Current master: 12,116 bytes, SHA-256 `C2A8CCBE8C737EF4A1A8E2AB08B72B5337A214B5AC8B3EFC71DD5FED4925273C`.
- Total continuous coverage is 473/528 source folios (89.58%). Exact next cursor: Expos\'e IX section 12.4, authority line 3643, physical page 485 / scan index 484 / source folio 473.

## 2026-08-01 — English checkpoint 114: section 12.4 and Theorem 12.5 complete

- Personally translated and source-aligned section 12.4 and Theorem 12.5: the explicit character lattice of the Jacobian's torus, the sign-independent positive integral pairing, identification with the dual through the canonical polarization, and the Picard--Lefschetz formula identifying this pairing with the $\ell$-adic monodromy pairing. Authority `source\expose_IX_body.tex` lines 3643--3688 / scan indices 484--486 / source folios 473--475 / physical authority pages 485--487, stopping exactly before section 12.6 on physical page 488.
- Physical page 485 had already been inspected at the preceding seam; pages 486--488 were compared directly in four overlapping 1,100-dpi bands per page, with page 488 controlling the stop boundary. Branch primes, check accents, projections, tensor subscripts, summation indices, isomorphism arrows, theorem underlining, and formula tags were decisive. No genuine ambiguity warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- The English prose naturally corrects the print's elementary spellings `billin\'eaire` and `standart`. The blank pinpoint following citation [5] is disclosed in a reader footnote rather than guessed. Render review also caught two vertically stranded disclosure markers at the 12.3--12.4 seam and after Theorem 12.5; each marker was reattached to the sentence it documents, without changing mathematical content.
- Active component `174_expose_IX_section_12_4_and_theorem_12_5.tex`: 3,933 bytes, SHA-256 `7D9A23A94EBF78D0F0AF3D95618587496791E28FCCAD1920309A41DA86BECC67`. The layout-only footnote-anchor repair gives active component `173_expose_IX_section_12_3.tex` the successor identity 8,096 bytes, SHA-256 `A5B536C3B487397E9358198B5563B20B38C0033C0153393BD4131A72DB55A62F`.
- Final three-pass pdfLaTeX build: PASS, 259 A4 pages. Passes 2 and 3 are byte-identical (27,380 bytes, SHA-256 `1919EB84519E3EF051801C592CD37784D4205716C71A273AD5D8A5458C85DECC`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,946,831 bytes, SHA-256 `D431F2EC587E70679DDF0FCA235633A98A09BE4F8E2E0BE86F849340349232E5`; log 45,656 bytes, SHA-256 `F5026FA27E30181DD5A3300EAFDEE8093EDF51D4241B95385801CAFE2F0FB5D9`.
- Rendered and personally inspected cumulative pages 257--259 at 600 dpi. The 12.3--12.4 seam, both repaired footnote anchors, all seven numbered formulas, checks/primes/subscripts, theorem underlining, paragraph flow, and clean hard stop before 12.6 PASS. Render hashes: p257 `DC55249DC5E6FCEFBE1795BE1AE6F63091BAD75F7F7C17C44A05930126680194`; p258 `D3FCBA9C405DCA8CAD1D6024CD9BEAEB5A94D4570574DE7F5131CCE1C6E3C9E6`; p259 `305FED489FCCCAF4BD6DDCD74BA7DAE3CEADF965FC274A2BC920E6DDC64692F8`.
- Current master: 12,179 bytes, SHA-256 `37304E87A276401AE0BC42306255E8BB428EEF38B4A0925B53DE00ACF0A78256`.
- Total continuous coverage is 475/528 source folios (89.96%). Exact next cursor: Expos\'e IX section 12.6, authority line 3693, physical page 488 / scan index 487 / source folio 476.

## 2026-08-01 — English checkpoint 115: sections 12.6--12.7 complete

- Personally translated and source-aligned section 12.6, the $\ell\ne p$ proof reduction in 12.7, and all of Remarks 12.7.2: reduction of Theorem 10.4 to the canonical polarization case, the cohomological Picard--Lefschetz formula, the remaining $\ell=p$ problem, and the explicitly transcendental character of the known proofs. Authority `source\expose_IX_body.tex` lines 3693--3707 / scan indices 487--488 / source folios 476--477 / physical authority pages 488--489, stopping exactly before section 12.8.
- Physical page 488 was already controlled in four overlapping 1,100-dpi bands at the preceding boundary; physical page 489 was likewise compared in four overlapping 1,100-dpi bands. One genuinely ambiguous tiny superscript in (12.7.1) was then isolated and inspected directly at 5,000 dpi. The print has $\operatorname{Hom}(T_\ell(A_{\bar\eta}),\mathbb Z_\ell)$ with no dual superscript; the working transcription's added $\vee$ was therefore removed and the restoration disclosed in a reader footnote. All remaining notation and prose were decisive at 1,100 dpi.
- Active component `175_expose_IX_sections_12_6_and_12_7.tex`: 2,557 bytes, SHA-256 `DEF1C61331F9B6EFC8E5AF148FD98FDD58F424F9EC76898A8D39FF104F1E481C`. The 5,000-dpi targeted authority crop is 591,570 bytes, SHA-256 `8F7BEF500706737688CC5C5DA7754A019BC2D6F8052BCDD1A99BEAA24FAFC8E6`.
- Three-pass pdfLaTeX build: PASS, 260 A4 pages. Passes 2 and 3 are byte-identical (27,413 bytes, SHA-256 `104B8099011170B5919173252086E173D326D856093C9C1191F0D5093727B06D`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,950,611 bytes, SHA-256 `700C737B01BC501120EDB49A63699EAA056D9245BFC660BECA742B8F76973987`; log 45,694 bytes, SHA-256 `AD6E0F8AC147F4549BFF5418B1BE0036ECA66814902EFDF595A9A20A712035DF`.
- Rendered and personally inspected cumulative pages 259--260 at 600 dpi. The 12.5--12.6 seam, heading underlines, corrected Tate-module formula, both disclosure notes, paragraph flow, and clean hard stop before 12.8 PASS. Render hashes: p259 `03F4A68635628C27E23BBAEF86F27AE410F04B1BEE1808988902FD69242F1D7F`; p260 `F872C4E17936C8BBB88264E324C5DE3D1ACD454518B276B36E31309047037792`.
- Current master: 12,235 bytes, SHA-256 `0159171726E4B6BFF05E3D0FC6ADF9202892D13558A0827E29D6260CFC2F25FC`.
- Total continuous coverage is 477/528 source folios (90.34%). Exact next cursor: Expos\'e IX section 12.8, authority line 3709, physical page 489 / scan index 488 / source folio 477.

## 2026-08-01 — English checkpoint 116: section 12.8 through formula (12.8.8)

- Personally translated and source-aligned the opening of section 12.8 through formula (12.8.8): reduction of Theorem 12.5 to characteristic zero, the formal universal curve and its normal-crossings discriminant, the relative Picard scheme, its Tate-module filtration, the canonical Jacobian self-duality, and the resulting pair of dual Barsotti--Tate groups. Authority `source\expose_IX_body.tex` lines 3709--3794 / scan indices 488--491 / source folios 477--480 / physical authority pages 489--492, stopping exactly before the large diagram (12.8.9).
- Physical page 489 had already been controlled at the preceding seam; pages 490--492 were compared directly in four overlapping 1,100-dpi bands per page. The square (12.8.2), formulae (12.8.3)--(12.8.8), underlines, superscripts, quotient bars, labels, punctuation, and surrounding prose were decisive at that resolution; no unresolved detail warranted escalation under the adaptive 1,100--9,000-dpi rule.
- The English reader transparently repairs two source-layer defects while leaving the French working transcription unchanged. The transcription's capital $\underline F$ is restored from the printed page as the morphism $\underline f$ that is cohomologically flat. The print's isolated $T_\ell(B_U)$ is restored as $T_\ell(P_U)$ because no $B_U$ is introduced and the pairing and every adjacent term concern $P_U$. Blank internal pinpoints after Expos\'es V and VI are disclosed rather than guessed.
- Active component `176_expose_IX_section_12_8_opening_through_before_12_8_9.tex`: 6,309 bytes, SHA-256 `A64A663F224179DD4DCC88EA9E80309E63237C13B6779E38C50375F197FAB652`.
- Three-pass pdfLaTeX build: PASS, 261 A4 pages. Passes 2 and 3 are byte-identical (27,545 bytes, SHA-256 `7D26AA91053ED6CA9139448B95D9C4CF81C80B17A3601B3DA60563B2D6A9210B`). No fatal/error/undefined/overfull/underfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. PDF 1,960,628 bytes, SHA-256 `10C808CF569E3828D3B0AC0608014EBD52E172C3D7B64C1F10796A262133E52B`; log 45,770 bytes, SHA-256 `86C20530299D19E3330A8F4723572B40902CF1C01F71CEB181F893898B10C425`.
- Rendered and personally inspected cumulative pages 260--261 at 600 dpi. The 12.7--12.8 seam, all eight numbered displays, the four-arrow square and label sides, the source-disclosure notes, the deliberately retained authorial register, paragraph flow, and the exact hard stop before (12.8.9) PASS. Render hashes: p260 `133F936F77366506509EB525B8C2BED824E0F9AC0889E6093686F197DBB7F7BD`; p261 `8BC70AE0F0781966C3532362DE953C6844359F8265CB44C69186854EE56E4938`.
- Current master: 12,311 bytes, SHA-256 `60007E04601FDB15385EF39B5CF645767BCE4FD51D649345E615F9E140BF4740`.
- Total continuous coverage is 480/528 source folios (90.91%). Exact next cursor: Expos\'e IX diagram (12.8.9), authority line 3796, physical page 492 / scan index 491 / source folio 480.

## 2026-08-01 — English checkpoint 117: Expos\'e IX section 12 complete

- Personally translated and source-aligned the remainder of 12.8, all of Remarks 12.9, and section 12.10: the two dual exact sequences in (12.8.9), the multivariable monodromy pairing, its localization at each discriminant component, Lemma 12.8.13 and its reduction to characteristic zero, and the general weighted pairing (12.10.1). Authority `source\expose_IX_body.tex` lines 3796--3951 / scan indices 491--495 / source folios 480--484 / physical authority pages 492--496, stopping exactly before section 13 on the terminal page.
- Physical page 492 had already been controlled at the preceding seam. Pages 493--496 were compared directly in four overlapping 1,100-dpi bands per page. All four native diagrams, their nodes, arrows, identification bars, exact label sides, punctuation, primes, subscripts, and surrounding formula attachment were decisive at that resolution; no genuine ambiguity warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- The scan and mathematical context support six transparent source-layer repairs while the French working transcription remains unchanged: (12.8.9) is balanced by supplying the print's missing outer closing parenthesis; the print's lowercase $x$ in “$x$ is regular” is restored as the scheme $X$; the reduction restores the missing $\lambda$ on $D_\lambda$ and the missing underline on the universal curve $\underline X$; the transcription's right-hand label $\varphi_{\lambda_\lambda}$ in (12.8.15) is restored from the diagram as $\varphi_{y_\lambda}$; and the final trait is restored from printed $\underline S$ to the localized $\underline S^\lambda$. Both blank internal pinpoints after Expos\'e VI are disclosed rather than guessed.
- Active component `177_expose_IX_section_12_8_9_through_12_10.tex`: 8,137 bytes, SHA-256 `B768A0FA6228F2142B98FB57693751C29D36C6A5DA8C36F43DB5830D842E666E`.
- The first retained render exposed a missing TeX escape that printed the command name `qquad` in (12.8.12). The source was corrected to `\qquad`, rebuilt in a no-overwrite r2 directory, and all affected pages were re-rendered. The defective r1 PDF is not current.
- Final three-pass pdfLaTeX build: PASS, 264 A4 pages. Passes 2 and 3 are byte-identical (27,831 bytes, SHA-256 `D8F21B376AD00CCCC7AA1EF9B3B4D967CF2ED1B45EBB3531EFE8C590570C432A`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. One bounded underfull box in the large native (12.8.9) diagram remains and is visually harmless. PDF 1,973,967 bytes, SHA-256 `1A0D5452CE161E612587445D7A15FA30B18960C70E36AEDA8F2D42B587694801`; log 46,009 bytes, SHA-256 `F06060C54C782A4D03880CC9A11DF6ABA3FD6800EDAEEA51E144AD7CE2756E71`.
- Rendered and personally inspected cumulative pages 261--264 at 600 dpi, then re-rendered affected pages 262--264 after the escape and disclosure-note repair. The 12.8 seam, all four native diagrams and label placement, all numbered displays, correction notes, paragraph flow, and exact hard stop before section 13 PASS. Final affected-page render hashes: p262 `DF8C9A817D254702FDDD4F2EB915092DBD05BA82B5648221472D7A6927D81F20`; p263 `0C0AA9981F5ECCED1CE14C083B03EE468CDFE68A05B7E32F6FAA0BA03601DEF0`; p264 `2DA4B168C77B8048F794A71A6DE6635505A9E8FFC9F540AC26E6738EF2F069DE`.
- Current master: 12,373 bytes, SHA-256 `3217D30F9AB57CBA8B311D048F2DEFD2B6C8067F89B9D273F57800B709B3CC44`.
- Total continuous coverage is 484/528 source folios (91.67%). Exact next cursor: Expos\'e IX section 13 heading, authority line 3953, physical page 496 / scan index 495 / source folio 484.

## 2026-08-01 — English checkpoint 118: Expos\'e IX sections 13.1--13.2 complete

- Personally translated and source-aligned the section-13 heading, section 13.1, and section 13.2 through Corollary 13.2.2: the exponential sequence for a smooth relative analytic group, the equivalence with pairs $(E,R)$, the abeloid/local-system interpretation, formal completion along a fibre, and Lemma 13.2.1 identifying analytic homomorphism germs with formal homomorphisms under hypotheses a)--c). Authority `source\expose_IX_body.tex` lines 3953--4032 / scan indices 495--500 / source folios 484--489 / physical authority pages 496--501, stopping exactly before section 13.3.
- Physical page 496 had already been controlled at the preceding seam. Pages 497--501 were compared directly in four overlapping 1,100-dpi bands per page. Hats, underlines, primes, local-ring notation, completion accents, exact-sequence arrows, Hom subscripts, formula tags, and punctuation were decisive at that resolution; no genuine ambiguity warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- Corollary 13.2.2 in the printed source refers to conditions a), b), and c) ``of 13.2.2,'' although those conditions are introduced in Lemma 13.2.1. The English text corrects the cross-reference to 13.2.1 and discloses the print's self-reference in a reader footnote. The French working transcription remains unchanged.
- Active component `178_expose_IX_sections_13_1_and_13_2.tex`: 8,311 bytes, SHA-256 `604ADE53C4229A8563A04FA9F8298ED2D7EBACECA256BF4F6AF207AF08CEDC3E`.
- Three-pass pdfLaTeX build: PASS, 266 A4 pages. Passes 2 and 3 are byte-identical (SHA-256 `2D844CB9D19853DA002E7AFD5D65DD0D64D01B06282C56D885B6EF8CC3CB67A8`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. One bounded underfull box from the preceding large native diagram (12.8.9) remains and is visually harmless. PDF 1,987,610 bytes, SHA-256 `DDC20CF60CC5EF45F52B9B42BBAEE237888C5D4EB4176092192D27BFBCCA5905`; log 46,057 bytes, SHA-256 `279C95040E088697A2381997A359D8B6444951B9D97AC76072947C7F596104A9`.
- Rendered and personally inspected cumulative pages 263--266 at 600 dpi. The section-12/13 seam, all six displayed formulae, completion hats, prime placement, theorem/corollary underlining, disclosure footnote, paragraph flow, and exact hard stop before section 13.3 PASS. Render hashes: p263 `0C0AA9981F5ECCED1CE14C083B03EE468CDFE68A05B7E32F6FAA0BA03601DEF0`; p264 `1D82D3BCBE84BCD3522FBCF5AB472C8AAEA0F894E55691E08D7AE8790180917F`; p265 `F2222A5D966B948E599D223C68E9DE29F59D23F2112F613E010D0A057FF56325`; p266 `6261610B45E900BCD948E43EE6774D50CBB344E0E67618F1ED289AF0FD53C2D9`.
- Current master: 12,429 bytes, SHA-256 `97F543F17AB57E6ADFE810D2C7B77D680965F5F616CC7D2AAF81261B5C82E971`.
- Total continuous coverage is 489/528 source folios (92.61%). Exact next cursor: Expos\'e IX section 13.3, authority line 4035, physical page 501 / scan index 500 / source folio 489.

## 2026-08-01 — English checkpoint 119: Expos\'e IX section 13.3 complete

- Personally translated and source-aligned all of section 13.3: construction of the analytic Raynaud extension $A^\natural=E/R^f$, its formal identification with $A$, the deformation of a chosen complex subtorus, and the resulting unique torus-by-abeloid extension near the distinguished fibre. Authority `source\expose_IX_body.tex` lines 4035--4172 / scan indices 500--504 / source folios 489--493 / physical authority pages 501--505, stopping exactly before section 13.4 on the terminal page.
- Physical page 501 had already been controlled at the preceding seam; pages 502--505 were compared directly in four overlapping 1,100-dpi bands per page. Fixed-part superscripts, natural symbols, hats, lattice and vector-bundle superscripts, injection and isomorphism arrows, formula tags, underlines, and punctuation were decisive. No genuine ambiguity warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- The printed opening has $A=A_o$, although the hypothesis required by the construction and introduced in Lemma 13.2.1 is $A=A^o$. The English reader uses $A=A^o$ and discloses the printed reading in a footnote. The French working transcription remains unchanged.
- Active component `179_expose_IX_section_13_3.tex`: 7,383 bytes, SHA-256 `B9AF90D742FD1A82DEA060E2EBF3028D30EF878FC9CD78F9A25B21469096ABCF`.
- Three-pass pdfLaTeX build: PASS, 268 A4 pages. Passes 2 and 3 are byte-identical (27,890 bytes, SHA-256 `1A96577F8A9237CFE668BFA60023B71242D94EFF2E97B360A981AA0BC58E7C7B`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. One bounded underfull box from the preceding large native diagram (12.8.9) remains and is visually harmless. PDF 1,997,677 bytes, SHA-256 `4BF69CEDD15ECC3F58704493A00D014CB4D5F783D08F5A87CE90D0129A7954E1`; log 46,083 bytes, SHA-256 `20D17B6A125DAC7FE9DF17F880DDD0744E03794146F4CF7D47A48C0433FFE9D5`.
- Rendered and personally inspected cumulative pages 265--268 at 600 dpi. The 13.2--13.3 seam, all sixteen numbered displays, hats and natural symbols, injection/isomorphism directions, source-correction footnote, paragraph flow, and exact hard stop before section 13.4 PASS. Render hashes: p265 `F2222A5D966B948E599D223C68E9DE29F59D23F2112F613E010D0A057FF56325`; p266 `8C12FCCF43FCF4389485038DDBDAFA1DC52D13D3081FD6CEE0A7F899C5DC326C`; p267 `D8A3464EC7F19DF746B23C3EF09EDEF40079D443CB9BD65D53998A45E9936F71`; p268 `A5F9783AE16EDC8773729ACC80EF1007BF3A4A76385B8A4FBB4AA99C7FB114CC`.
- Current master: 12,475 bytes, SHA-256 `FE57363B40486E549C2EDD7090B13FB7DAC69403C2628DE3A624E5B707181B67`.
- Total continuous coverage is 493/528 source folios (93.37%). Exact next cursor: Expos\'e IX section 13.4, authority line 4175, physical page 505 / scan index 504 / source folio 493.

## 2026-08-01 — English checkpoint 120: Expos\'e IX section 13.4 complete

- Personally translated and source-aligned all of section 13.4: reformulation of the analytic-group dictionary in terms of the Hodge filtration, construction of the weight filtration from the fixed and toric lattice parts, the induced abeloid quotient, Proposition 13.4.17, and Deligne's mixed-Hodge interpretation and duality caveat. Authority `source\expose_IX_body.tex` lines 4175--4331 / scan indices 504--510 / source folios 493--499 / physical authority pages 505--511, stopping exactly before section 13.5 on physical page 512.
- Physical page 505 had already been controlled at the preceding seam; physical pages 506--512 were compared directly in four overlapping 1,100-dpi bands per page, with page 512 controlling the stop boundary. Filtration superscripts, underlines, natural symbols, tensor subscripts, exact-sequence arrows, quotient notation, proposition subitems, formula tags, and punctuation were decisive. No unresolved detail warranted escalation above 1,100 dpi under the adaptive 1,100--9,000-dpi rule.
- The direct authority corrects two source-layer defects while the French working transcription remains unchanged. Formula (13.4.14) contains `\mathcal E(B)`, omitted entirely in the working transcription. The printed prose calls $B=A^\natural/T$ a quotient of $A$; the English text uses the mathematically and definitionally correct $A^\natural$ and discloses the printed reading in a footnote.
- Active component `180_expose_IX_section_13_4.tex`: 12,446 bytes, SHA-256 `10F863550F7AF49D14351781F329CC63CA131D0B7BC3FD7757DC5D345EC68839`.
- Three-pass pdfLaTeX build: PASS, 271 A4 pages. Passes 2 and 3 are byte-identical (27,953 bytes, SHA-256 `44320B441FF5F038E886D53340F9610876CB8F1F5751CB63D6C3E2AE0B1272D6`). No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. One pre-existing font warning in Expos\'e VIII and one bounded underfull box in the native (12.8.9) disclosure remain; both predate this component and their rendered pages are visually sound. PDF 2,015,172 bytes, SHA-256 `19C9494AF65F50FD0DBF303C0F5D8ACED326CD07754AC3BC6751D5ACFB5DBE8B`; log 46,145 bytes, SHA-256 `B0C1624559E150D83E4E7BCCEDE566BB2FF415BBD46E9C5472B6C6F8EE7B481A`.
- Rendered and personally inspected cumulative pages 267--271 at 600 dpi. The 13.3--13.4 seam, all numbered displays, Hodge/weight superscripts, exact arrows, correction footnote, proposition structure, paragraph flow, and exact hard stop before section 13.5 PASS. Render hashes: p267 `D8A3464EC7F19DF746B23C3EF09EDEF40079D443CB9BD65D53998A45E9936F71`; p268 `591094CD0B1D342F80CEA07FCBF8BFD33DB4E12A086C68E64F1806FA281375BC`; p269 `B8A2C404EA3563824764E7D6372F95F74508023C0798DDC8F228F70353B0A088`; p270 `4824ED88375A3A9886F5DB9EDCA7626B59063785E1F1B02378B4CBA14E49F469`; p271 `7FEADB635EFD4CF5C8EA50586C306C51B5738F2F92F3D8C4092310792C35957F`.
- Current master: 12,521 bytes, SHA-256 `2A1162460A3CA728675B42C8E1F740D62740E95194B6D684D9519918A6D79AF0`.
- Total continuous coverage is 499/528 source folios (94.51%). Exact next cursor: Expos\'e IX section 13.5, authority line 4336, physical page 512 / scan index 511 / source folio 500.

## 2026-08-01 — English checkpoint 121: Expos\'e IX section 13.5 complete

- Personally translated and source-aligned all of section 13.5: relative algebraization of the analytic Raynaud extension, the polarization lemma and its descent remarks, comparison with the integral and $\ell$-adic fixed/toric filtrations, and the resulting duality and monodromy consequences. Authority `source\expose_IX_body.tex` lines 4336--4434 / scan indices 511--517 / source folios 500--506 / physical authority pages 512--518, stopping exactly before section 14.
- Physical page 512 had already been controlled at the preceding seam; pages 513--518 were compared directly in four overlapping 1,100-dpi bands per page. Completion hats, natural symbols, local-ring letters, tensor subscripts, fixed/toric superscripts, pairing arrows, formula tags, and punctuation were decisive. The small natural superscript in (13.5.13) remained clear at 1,100 dpi; no unresolved detail required a higher-resolution ruling under the adaptive 1,100--9,000-dpi policy.
- The authority corrects source-layer transcription defects while the French working transcription remains unchanged: the opening algebraized extension is $A^{\natural}_{\hat{\underline O}}$, not $A_{\hat{\underline O}}$; the formal-base symbols in Lemma 13.5.2 are $\hat{\underline O}$, not the transcribed $\hat{\underline C}$; and the pairings (13.5.10) use the local-ring subscript $\underline O$, not the digit zero. The printed Remark 13.5.3(a) says projective ``over $S$'' where Lemma 13.5.2 and the ensuing normality argument require ``over $\hat{\underline O}$''; the English repair is disclosed in a footnote.
- Active component `181_expose_IX_section_13_5.tex`: 12,271 bytes, SHA-256 `0616E8746E22A29A1FC47C39CE92F5066475B7F86293C2459657DC16D39325FC`.
- Three-pass pdfLaTeX build: PASS, 274 A4 pages. No fatal/error/undefined/overfull/missing-character/multiply-defined/duplicate-destination/rerun diagnostic occurs. The only retained warnings are the pre-existing Expos\'e-VIII font warning and the bounded underfull box in the earlier (12.8.9) disclosure. PDF 2,034,366 bytes, SHA-256 `4B0985FA0BA6FD3238BDDE2D48D127383174AE015B01B62475F0C90EEEEDD02A`; log 46,207 bytes, SHA-256 `0DAA4D4F5CFB1D690E1AC63DFC68CF1469F2BE44247A817F73A022F7A1862F6E`.
- Rendered and personally inspected cumulative pages 271--274 at 600 dpi. The 13.4--13.5 seam, proposition and lemma underlining, all nine numbered displays, completion/natural notation, the source-correction footnote, paragraph flow, and the exact hard stop before section 14 PASS. Render hashes: p271 `9DC6CBF90D1CF45E9AC7EBD5833738DDC56049F167D89BF76F0FF80E9BB68FBF`; p272 `16BA7F2F77D0DA6F720FF6DDCBF0F21753E01C293FB2E532EFC9A50ECA28FDA8`; p273 `96CFAD43405D2AE14FBB71011F4DC39F63A2DFADCE32300B611FE5C78F0E67BA`; p274 `A10BA01E1707AF4B71CC96B4E7F9B4975A1C8FE6840160D8F4583B46A728FBAD`.
- Current master: 12,567 bytes, SHA-256 `41AB4F846F97FD5D3E8FABE20B4FBC37D0FB16332903D41FD1DD77926CF02025`.
- Total continuous coverage is 506/528 source folios (95.83%). Exact next cursor: Expos\'e IX section 14 heading, authority line 4437, physical page 518 / scan index 517 / source folio 506.

## 2026-08-01 — English checkpoint 122: Expos\'e IX section 14.1 complete

- Personally translated and source-aligned section 14.1, authority lines 4437--4531 / scan indices 517--520 / source folios 506--509 / physical pages 518--521, stopping before 14.2.
- Compared the four authority pages directly at 1,100 dpi. The maps, pairings, primes, subscripts, and monodromy notation were decisive; no 5,000--9,000-dpi escalation was warranted. The scan restores lowercase $p'_K$ where the working transcription had uppercase notation.
- Active component `182_expose_IX_section_14_1.tex`: 6,628 bytes, SHA-256 `89B7F576DA7FDD72F9669D17814195FBA2C61CDA484E608AA4C507A53439D828`.
- The first build/render exposed literal `qquad` in two displays; the TeX escapes were repaired and the failed r1 state was preserved. Final r2 build PASS: 276 A4 pages, PDF 2,043,602 bytes, SHA-256 `F05C50BF7B65657C4256B764E51EB17629E43123E62A5973996F90296F790545`.
- Personally inspected cumulative pages 274--276 at 600 dpi after repair; PASS. Render hashes: p274 `908D9A69C7A0E33F85C27E206A5319941F503C3C1756729104D3F7DB6F113F95`; p275 `066062B57D92324E68C88499CDEC2C0343C78B29D5E0A14172219969490E8962`; p276 `26C3FC7897EDC258A619EC1DFE9FCE3288BECC539EEBCD4A810BD3D45FF84B9F`.
- Coverage reached 509/528 folios (96.40%). Next cursor: 14.2, line 4537 / physical 522 / scan 521 / folio 510.

## 2026-08-01 — English checkpoint 123: Expos\'e IX section 14.2 complete

- Personally translated and source-aligned section 14.2, authority lines 4537--4624 / scan indices 521--525 / source folios 510--514 / physical pages 522--526, stopping before 14.3.
- Direct 1,100-dpi authority comparison controlled all formulae. The English restores the omitted second map label $p':\underline M'\to B'$ and the basis symbol $u_0$.
- Active component `183_expose_IX_section_14_2.tex`: 8,193 bytes, SHA-256 `717B450635CF33647F54001C7885C9319DDEA5B208D70C46E6568FC39B3C9574`.
- The r1 render exposed an unseparated heading and a literal `qquad`; both TeX layout defects were repaired copy-on-write. Final r2 build PASS: 278 A4 pages, PDF 2,054,535 bytes, SHA-256 `9524D0184DAE4164B670FFC6FB9DB8B2A12A3A8D8514E6B8B5EAAC2F07056665`.
- Personally inspected cumulative pages 276--278 at 600 dpi; PASS. Render hashes: p276 `0F373D9865FD5E0E145C44312ADC5F26333176E652C487AC947A80B6ACEA2847`; p277 `CD06418CD95F40A788C74B5320E9084BD28FCA8627207C543C20D01AEFA78EA6`; p278 `4C0619691B24CE13FA7F487FF644D0195FC1CB8089BC4AEEA1BC053E368F5178`.
- Coverage reached 514/528 folios (97.35%). Next cursor: 14.3, line 4627 / physical 526 / scan 525 / folio 514.

## 2026-08-01 — English checkpoint 124: Expos\'e IX section 14.3 complete

- Personally translated and source-aligned section 14.3 through the sentence introducing Conjecture 14.4, authority lines 4627--4721 / scan indices 525--529 / source folios 514--518 / physical pages 526--530.
- Every page was checked in direct 1,100-dpi full-page and overlapping-band views. No notation or diagram ambiguity required a higher-resolution ruling.
- Transparent source repairs include the missing parenthesis in (14.3.2), $G_K(K)=K^*$ in the $\mathbb G_m$ case, $A'$ and its toric part $T'$ in the second Raynaud construction, and correction of impossible prose citations `(14.3.8)`/`(14.3.10)` to the displayed `(14.3.5.3)`/`(14.3.5.5)`.
- Active component `184_expose_IX_section_14_3.tex`: 8,331 bytes, SHA-256 `4EA364D739EE16341800C20B597A26C0AC0456D2D403E0F1EB314EBEDBDA255B`.
- Three-pass build PASS: 280 A4 pages, PDF 2,066,575 bytes, SHA-256 `D992452A27C14CD1F299681F39369932D187BE93E52661A6948FFA5865D61C5B`. The only diagnostic is one pre-existing visually harmless underfull box.
- Personally inspected cumulative pages 278--280 at 600 dpi; PASS. Render hashes: p278 `BB5DFD3AE584CB360C145877EF16E6F093B9A48E80E2B1EC00230CF932787BCD`; p279 `B8BC41A65BEFD32876C7EA5290736FE49E64E7A9E2E3B01859A6BE2137EDB3ED`; p280 `5FBE6C331B3C799E102EB20A195D2DFA2DC51DD6761499825448A0D587DEF936`.
- Coverage reached 518/528 folios (98.11%). Next cursor: Conjecture 14.4, line 4726 / physical 531 / scan 530 / folio 519.

## 2026-08-01 — English checkpoint 125: mathematical body and bibliography complete

- Personally translated and source-aligned Conjecture 14.4, 14.4.2--14.4.3, Remarks 14.5, and the full bibliography, authority lines 4726--4827 / scan indices 530--534 / source folios 519--523 / physical pages 531--535.
- Direct 1,100-dpi page review controlled the final statement, the $S'$ pullback omitted by the transcription, every bibliography entry, and the deliberately incomplete printed entries [13] and [24]. No high-resolution escalation was needed.
- Active components: `185_expose_IX_sections_14_4_and_14_5.tex`, 2,635 bytes, SHA-256 `724BB49D398E53C1B7EA731AB077698F116722A3BF18EA6DC8C3899F590EC4BB`; `186_expose_IX_bibliography.tex`, 4,967 bytes, SHA-256 `DE648F309292C613AD67D0ACA9FC5B1650141CC68E93E5C5F79B97B4A150D739`.
- Three-pass body build PASS: 282 A4 pages, PDF 2,078,898 bytes, SHA-256 `2FD2D31B9FDA4F7C4014C43444DFFD7DBA2B9E2D7EA8EB96C722BC2FA797FD23`; pass 2 and pass 3 consoles are byte-identical, SHA-256 `896C46BDE8F2351D35B44BA54A855A1FCC82359F86CAEAA54731811C2AA37B23`.
- Personally inspected cumulative pages 280--282 at 600 dpi; statement, bibliography flow, accents, and terminal entry all PASS. Render hashes: p280 `A662204731F50FBAF35D6D1CFE3FF21C0D7D560B13AC486AA170E051021C2A4A`; p281 `8B4A3E635AD0D87CDD3EAD8380F0A5E3C938B5D547E52B5BB8971D34C445B56A`; p282 `FF5269A7D2673CBA4DF63AB0EF3E67DCAE73F496E9DA85C5CDD835D048DB994D`.

## 2026-08-01 — English checkpoint 126: SGA 7 I complete through terminal matter

- Confirmed scan index 535 / source folio 524 as a genuinely blank leaf at 1,100 dpi, then retained the publisher's terminal catalogue and ISBN matter from scan indices 536--539 / source folios 525--528 / physical pages 537--540. The catalogue titles remain in their printed languages; no false English-title translation was introduced.
- Active terminal component `187_expose_IX_terminal_publisher_matter.tex`: 19,654 bytes, SHA-256 `6DE62176FB5B8F2AE98F543A6FE5EC2238E9B7C8A0BF1E4BC94FC80DE99D272D`.
- Final master: 12,866 bytes, SHA-256 `8AD83C0E1E5BC0658FFB252D845390E0A36013ACB79475A3907AE541C0AA368A`.
- Final three-pass Tome-I build PASS: `build\checkpoint_sga7i_complete_full_volume_r1\SGA7_I_English_source_first_workpass.pdf`, 287 A4 pages / 2,126,411 bytes / SHA-256 `11118DB10640EE6F05428F4C35B18EB58224C91E2F6C2216E6ABDB253F7005D3`; log 46,673 bytes / SHA-256 `552BAFEE953C0BB59A7384A91300ADF822D74807A841FFE03E90DA125056F440`; pass 2 and 3 consoles byte-identical / SHA-256 `16122F26FBCB2BF4C04392DC722721E733570EAE49D0FE2033D9DE6A8F7F4C4A`.
- Personally inspected terminal reader pages 282--287 at 600 dpi. Bibliography-to-catalogue seam, multilingual glyphs, catalogue flow, horizontal rules, final SGA-7-I listing, ISBNs, and page boundaries PASS. Render hashes: p282 `FF5269A7D2673CBA4DF63AB0EF3E67DCAE73F496E9DA85C5CDD835D048DB994D`; p283 `8AC76DCA003A3489FFDC9F2C96F11C87E91C260C22F6AB18C926F83865E4AF24`; p284 `261F01866F0DAB9531F06824CFB9CBB59DCB5B57C68A1A3CDDC0394EF747E4EA`; p285 `111D806ACAA241C936DBBCF6F66E2D0433D7160FC46479F0BADD642C6FB4A039`; p286 `2D186E52DF5564B778AAD9D2519BDB461D2CF132050D09ACCD7E797384892372`; p287 `D2F24DF3F18C1534428B396C38A5D62E24B9F2F2700D2B37D11A89C585B489C8`.
- Continuous SGA 7 I coverage is now 528/528 source folios (100%), with all six written expos\'es, bibliographies, and terminal matter included. Exact Tome-I cursor: EOF. This is local translation/build completion, not an archive/publication or exhaustive reference-v2 claim.
