param(
    [string]$OutputPath = (Join-Path $PSScriptRoot 'CHECKPOINT_VALIDATION.json')
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash
}

function Get-CsvStats([string]$Path) {
    Add-Type -AssemblyName Microsoft.VisualBasic.Core
    $parser = [Microsoft.VisualBasic.FileIO.TextFieldParser]::new($Path)
    try {
        $parser.TextFieldType = [Microsoft.VisualBasic.FileIO.FieldType]::Delimited
        $parser.SetDelimiters(',')
        $parser.HasFieldsEnclosedInQuotes = $true
        $header = @($parser.ReadFields())
        $rowCount = 0
        $rectangular = $true
        $formulaUnsafe = 0
        $firstValues = [System.Collections.Generic.HashSet[string]]::new()
        $uniqueFirst = $true
        while (-not $parser.EndOfData) {
            $fields = @($parser.ReadFields())
            $rowCount++
            if ($fields.Count -ne $header.Count) { $rectangular = $false }
            if ($fields.Count -gt 0 -and -not $firstValues.Add([string]$fields[0])) {
                $uniqueFirst = $false
            }
            foreach ($field in $fields) {
                $trimmed = ([string]$field).TrimStart()
                if ($trimmed.Length -gt 0 -and $trimmed[0] -in @('=', '+', '-', '@')) {
                    $formulaUnsafe++
                }
            }
        }
    } finally {
        $parser.Close()
    }
    [ordered]@{
        rows = $rowCount
        columns = $header.Count
        rectangular = $rectangular
        formula_unsafe_cells = $formulaUnsafe
        unique_first_column = $uniqueFirst
        bytes = (Get-Item -LiteralPath $Path).Length
        sha256 = Get-Sha256 $Path
    }
}

function Get-LogDiagnostics([string]$Path) {
    [ordered]@{
        hard = @(Select-String -LiteralPath $Path -Pattern '^!|Undefined control sequence|LaTeX Error|Fatal error|Emergency stop|multiply defined|destination with the same identifier|Missing character').Count
        overfull = @(Select-String -LiteralPath $Path -Pattern 'Overfull \\hbox|Overfull \\vbox').Count
        underfull = @(Select-String -LiteralPath $Path -Pattern 'Underfull \\hbox|Underfull \\vbox').Count
    }
}

$csvNames = @(
    'CHECKPOINT_IDENTITIES.csv',
    'FRENCH_CORRECTIONS.csv',
    'FRENCH_TRANSCRIPTION_REPAIRS.csv',
    'SOURCE_INPUTS.csv',
    'TRANSLATION_LINEAGES.csv',
    'TRANSLATION_PROGRESS.csv',
    'EDITORIAL_SELF_CORRECTION_LEDGER.csv',
    'ENGLISH_NORMALIZATION_OCCURRENCES.csv',
    'SEMANTIC_ENTITIES.csv',
    'SEMANTIC_RELATIONS.csv'
)
$csv = [ordered]@{}
foreach ($name in $csvNames) {
    $csv[$name] = Get-CsvStats (Join-Path $PSScriptRoot $name)
}
$selfRows = @(Import-Csv -LiteralPath (Join-Path $PSScriptRoot 'EDITORIAL_SELF_CORRECTION_LEDGER.csv'))
$selfOccurrences = 0
foreach ($row in $selfRows) {
    $value = 0
    if (-not [int]::TryParse([string]$row.occurrence_count, [ref]$value)) {
        throw "Nonnumeric self-correction occurrence count: $($row.self_correction_id)"
    }
    $selfOccurrences += $value
}

$texFiles = [System.Collections.Generic.List[string]]::new()
$texFiles.Add((Join-Path $root 'english_source_first_workpass\source\Serre_FAC_English_source_aligned_workpass.tex'))
Get-ChildItem -LiteralPath (Join-Path $root 'english_source_first_workpass\source\components') -File -Filter '*.tex' |
    Sort-Object Name |
    ForEach-Object { $texFiles.Add($_.FullName) }
$texTextParts = [System.Collections.Generic.List[string]]::new()
foreach ($path in $texFiles) { $texTextParts.Add((Get-Content -LiteralPath $path -Raw)) }
$texText = [string]::Join("`n", $texTextParts)
$labels = @([regex]::Matches($texText, '\\label\{([^}]+)\}') | ForEach-Object { $_.Groups[1].Value })
$hyperrefs = @([regex]::Matches($texText, '\\hyperref\[([^\]]+)\]') | ForEach-Object { $_.Groups[1].Value })
$labelSet = [System.Collections.Generic.HashSet[string]]::new()
foreach ($label in $labels) { [void]$labelSet.Add($label) }
$missingHyperrefs = @($hyperrefs | Where-Object { -not $labelSet.Contains($_) } | Sort-Object -Unique)

$entityRows = @(Import-Csv -LiteralPath (Join-Path $PSScriptRoot 'SEMANTIC_ENTITIES.csv'))
$relationRows = @(Import-Csv -LiteralPath (Join-Path $PSScriptRoot 'SEMANTIC_RELATIONS.csv'))
$entitySet = [System.Collections.Generic.HashSet[string]]::new()
foreach ($entity in $entityRows) { [void]$entitySet.Add([string]$entity.entity_id) }
$missingEntityLabels = @($entityRows | Where-Object { $_.tex_label -and -not $labelSet.Contains($_.tex_label) })
$brokenEntityRefs = 0
foreach ($relation in $relationRows) {
    if (-not $entitySet.Contains([string]$relation.source_entity_id)) { $brokenEntityRefs++ }
    if ($relation.target_entity_id -and -not $entitySet.Contains([string]$relation.target_entity_id)) { $brokenEntityRefs++ }
}

$manifestPath = Join-Path $PSScriptRoot 'CHECKPOINT_IDENTITIES.csv'
$manifestRows = @(Import-Csv -LiteralPath $manifestPath)
$manifestErrors = [System.Collections.Generic.List[string]]::new()
$manifestBytes = [long]0
foreach ($row in $manifestRows) {
    $absolute = Join-Path $root ($row.path -replace '/', '\')
    if (-not (Test-Path -LiteralPath $absolute -PathType Leaf)) {
        $manifestErrors.Add("missing:$($row.path)")
        continue
    }
    $item = Get-Item -LiteralPath $absolute
    $manifestBytes += $item.Length
    if ([long]$row.bytes -ne $item.Length) { $manifestErrors.Add("bytes:$($row.path)") }
    if ($row.sha256 -ne (Get-Sha256 $absolute)) { $manifestErrors.Add("sha256:$($row.path)") }
}

$privacyFiles = 0
$privacyOccurrences = 0
foreach ($row in $manifestRows) {
    $absolute = Join-Path $root ($row.path -replace '/', '\')
    if (-not (Test-Path -LiteralPath $absolute -PathType Leaf)) { continue }
    if ([IO.Path]::GetExtension($absolute).ToLowerInvariant() -notin @('.md','.tex','.csv','.json','.ps1','.txt','.log')) { continue }
    $matches = [regex]::Matches((Get-Content -LiteralPath $absolute -Raw), 'C:[\\/]Users[\\/]Floris', 'IgnoreCase')
    if ($matches.Count -gt 0) {
        $privacyFiles++
        $privacyOccurrences += $matches.Count
    }
}

$diplomaticBody = Join-Path $root 'french_source_diplomatic_canon\source\fac_body.tex'
$correctedBody = Join-Path $root 'french_source_corrected_workpass\source\fac_body.tex'
$diplomaticLines = @(Get-Content -LiteralPath $diplomaticBody)
$correctedLines = @(Get-Content -LiteralPath $correctedBody)
if ($diplomaticLines.Count -ne $correctedLines.Count) { throw 'French layer line counts diverge.' }
$changedLines = [System.Collections.Generic.List[int]]::new()
for ($i = 0; $i -lt $diplomaticLines.Count; $i++) {
    if ($diplomaticLines[$i] -cne $correctedLines[$i]) { $changedLines.Add($i + 1) }
}

$englishBuild = Join-Path $root 'english_source_first_workpass\build_checkpoint_III_5_73_r4'
$englishPdf = Join-Path $englishBuild 'Serre_FAC_English_source_aligned_workpass.pdf'
$englishLog = Join-Path $englishBuild 'Serre_FAC_English_source_aligned_workpass.log'
$englishDiag = Get-LogDiagnostics $englishLog
$dipBuild = Join-Path $root 'french_source_diplomatic_canon\build_checkpoint_T0043_r1'
$dipPdf = Join-Path $dipBuild 'fac.pdf'
$dipLog = Join-Path $dipBuild 'fac.log'
$dipDiag = Get-LogDiagnostics $dipLog
$corBuild = Join-Path $root 'french_source_corrected_workpass\build_checkpoint_C0039_T0043_r1'
$corPdf = Join-Path $corBuild 'fac.pdf'
$corLog = Join-Path $corBuild 'fac.log'
$corDiag = Get-LogDiagnostics $corLog

$errors = [System.Collections.Generic.List[string]]::new()
foreach ($entry in $csv.GetEnumerator()) {
    if (-not $entry.Value.rectangular) { $errors.Add("csv_rectangular:$($entry.Key)") }
    if ($entry.Value.formula_unsafe_cells -ne 0) { $errors.Add("csv_formula:$($entry.Key)") }
    if (-not $entry.Value.unique_first_column) { $errors.Add("csv_unique:$($entry.Key)") }
}
foreach ($entry in $manifestErrors) { $errors.Add("manifest:$entry") }
foreach ($target in $missingHyperrefs) { $errors.Add("missing_hyperref:$target") }
if ($missingEntityLabels.Count -ne 0) { $errors.Add("semantic_labels_missing:$($missingEntityLabels.Count)") }
if ($brokenEntityRefs -ne 0) { $errors.Add("semantic_broken_refs:$brokenEntityRefs") }
if ($englishDiag.hard -ne 0 -or $englishDiag.overfull -ne 0) { $errors.Add('english_build_diagnostics') }
if ($dipDiag.hard -ne 0 -or $corDiag.hard -ne 0) { $errors.Add('french_build_hard_diagnostics') }

$validation = [ordered]@{
    schema = 'fac_checkpoint_validation_v35'
    status = if ($errors.Count -eq 0) { 'PASS_BOUNDED_INTERNAL_CHECKPOINT' } else { 'FAIL_HOLD' }
    errors = @($errors)
    overall_work_status = 'ACTIVE_NOT_COMPLETE_NOT_PUBLICATION_READY'
    scope = [ordered]@{
        english_source_lines = 'fac_body.tex:1-2885'
        printed_pages = '197-268'
        next_cursor = 'fac_body.tex line 2887; printed 268; Chapter III section 5 no. 74 Vanishing of certain Ext modules'
        active_english_components = $csv['TRANSLATION_PROGRESS.csv'].rows
        french_corrections = $csv['FRENCH_CORRECTIONS.csv'].rows
        french_transcription_repairs = $csv['FRENCH_TRANSCRIPTION_REPAIRS.csv'].rows
        editorial_self_correction_events = $selfRows.Count
        recorded_self_corrected_occurrences = $selfOccurrences
        known_post_admission_math_or_translation_reversals = 1
        normalization_occurrences = $csv['ENGLISH_NORMALIZATION_OCCURRENCES.csv'].rows
        semantic_entities = $entityRows.Count
        semantic_relations = $relationRows.Count
        semantic_broken_entity_references = $brokenEntityRefs
    }
    tex_reference_closure = [ordered]@{
        active_tex_files = $texFiles.Count
        labels = $labels.Count
        unique_labels = $labelSet.Count
        duplicate_labels = $labels.Count - $labelSet.Count
        hyperref_occurrences = $hyperrefs.Count
        missing_hyperref_targets = $missingHyperrefs.Count
        semantic_entity_labels_missing_from_tex = $missingEntityLabels.Count
    }
    csv = $csv
    manifest = [ordered]@{
        path = 'controls/CHECKPOINT_IDENTITIES.csv'
        rows = $manifestRows.Count
        total_replayed_bytes = $manifestBytes
        sha256 = Get-Sha256 $manifestPath
        replay_errors = $manifestErrors.Count
    }
    english = [ordered]@{
        checkpoint = 'english_source_first_workpass/build_checkpoint_III_5_73_r4'
        pages = 68
        bytes = (Get-Item -LiteralPath $englishPdf).Length
        sha256 = Get-Sha256 $englishPdf
        xelatex_passes = 3
        pass2_pass3_console_equal = ((Get-Sha256 (Join-Path $englishBuild 'pass2_console.txt')) -eq (Get-Sha256 (Join-Path $englishBuild 'pass3_console.txt')))
        final_console_sha256 = Get-Sha256 (Join-Path $englishBuild 'pass3_console.txt')
        log_sha256 = Get-Sha256 $englishLog
        hard_diagnostics = $englishDiag.hard
        overfull = $englishDiag.overfull
        underfull = $englishDiag.underfull
        rendered_pages_checked = '67-68'
        render_dpi = 200
        render_sha256 = @(
            Get-Sha256 (Join-Path $root 'qa\english\III_5_73_200dpi_r4\fac-en-73-67.png')
            Get-Sha256 (Join-Path $root 'qa\english\III_5_73_200dpi_r4\fac-en-73-68.png')
        )
        native_diagrams_checked_this_tranche = 0
        diagram_authority_detail_dpi = 'not_applicable'
        diagram_authority_detail_sha256 = ''
        render_result = 'PASS'
    }
    diplomatic_french = [ordered]@{
        checkpoint = 'french_source_diplomatic_canon/build_checkpoint_T0043_r1'
        pages = 63
        bytes = (Get-Item -LiteralPath $dipPdf).Length
        sha256 = Get-Sha256 $dipPdf
        pdftex_passes = 3
        pass2_pass3_console_equal = ((Get-Sha256 (Join-Path $dipBuild 'pass2_console.txt')) -eq (Get-Sha256 (Join-Path $dipBuild 'pass3_console.txt')))
        final_console_sha256 = Get-Sha256 (Join-Path $dipBuild 'pass3_console.txt')
        log_sha256 = Get-Sha256 $dipLog
        hard_diagnostics = $dipDiag.hard
        accepted_preexisting_layout_diagnostics = $dipDiag.overfull + $dipDiag.underfull
        authority_pages_checked_through = 'physical 73 / printed 268'
        rendered_pages_checked = '52-55'
        render_dpi = 200
        render_sha256 = @(
            Get-Sha256 (Join-Path $root 'qa\french\T0043_r1_200dpi\diplomatic-52.png')
            Get-Sha256 (Join-Path $root 'qa\french\T0043_r1_200dpi\diplomatic-53.png')
            Get-Sha256 (Join-Path $root 'qa\french\T0043_r1_200dpi\diplomatic-54.png')
            Get-Sha256 (Join-Path $root 'qa\french\T0043_r1_200dpi\diplomatic-55.png')
        )
        render_result = 'PASS_T0043_SOURCE_PRESERVATION'
    }
    corrected_french = [ordered]@{
        checkpoint = 'french_source_corrected_workpass/build_checkpoint_C0039_T0043_r1'
        pages = 63
        bytes = (Get-Item -LiteralPath $corPdf).Length
        sha256 = Get-Sha256 $corPdf
        pdftex_passes = 3
        pass2_pass3_console_equal = ((Get-Sha256 (Join-Path $corBuild 'pass2_console.txt')) -eq (Get-Sha256 (Join-Path $corBuild 'pass3_console.txt')))
        final_console_sha256 = Get-Sha256 (Join-Path $corBuild 'pass3_console.txt')
        log_sha256 = Get-Sha256 $corLog
        hard_diagnostics = $corDiag.hard
        accepted_preexisting_layout_diagnostics = $corDiag.overfull + $corDiag.underfull
        repaired_source_span_checked_through = 'printed 268; no.73 requires no new repair and is line-identical across French layers'
        rendered_pages_checked = '52-55'
        render_dpi = 200
        render_sha256 = @(
            Get-Sha256 (Join-Path $root 'qa\french\C0039_T0043_r1_200dpi\corrected-52.png')
            Get-Sha256 (Join-Path $root 'qa\french\C0039_T0043_r1_200dpi\corrected-53.png')
            Get-Sha256 (Join-Path $root 'qa\french\C0039_T0043_r1_200dpi\corrected-54.png')
            Get-Sha256 (Join-Path $root 'qa\french\C0039_T0043_r1_200dpi\corrected-55.png')
        )
        render_result = 'PASS_C0039_AND_T0043'
    }
    french_layer_alignment = [ordered]@{
        diplomatic_lines = $diplomaticLines.Count
        corrected_lines = $correctedLines.Count
        changed_line_count = $changedLines.Count
        changed_lines = @($changedLines)
        declared_corrections = $csv['FRENCH_CORRECTIONS.csv'].rows
        note = 'Transcription repairs are common to both French layers and therefore absent from this diff.'
    }
    authority_rendering = [ordered]@{
        pages = 'physical 2-73 / printed 197-268'
        routine_dpi = 'bounded 600-dpi authority pages for no.73; no high-detail escalation required'
        higher_dpi_policy = 'escalate only bounded unresolved details within the user-authorized 1100-9000-dpi range; no whole-volume high-resolution rendering'
        latest_finding = 'no.73 is legible throughout at 600 dpi; frozen diplomatic and corrected French lines 2810-2885 are identical; no inherited transcription deviation or printed defect is admitted; the fraction map resolution four exact sequences and local Ext conclusion match the authority'
        authority_comparison_findings_this_tranche = @('fraction phi/P and element m/P-prime','map m/P-prime to phi(m)/(PP-prime)','exact citation to no.14 Proposition 5','finite free resolution terms L^q','boundary and cycle modules B^q and Z^q','two original and two localized exact sequences','local Hom complex conclusion')
        authority_page_sha256 = @(
            Get-Sha256 (Join-Path $root 'qa\authority\bounded_600dpi\fac-72.png')
            Get-Sha256 (Join-Path $root 'qa\authority\bounded_600dpi\fac-73.png')
        )
    }
    privacy_and_release = [ordered]@{
        manifest_text_files_with_private_home = $privacyFiles
        manifest_text_private_home_occurrences = $privacyOccurrences
        active_public_projection_built = $false
        archive_handoff_authorized = $false
        status = 'HOLD_MUTABLE_INTERNAL_WORK; PRIVACY_CLEAN_PROJECTION_REQUIRED_AT_BOUNDED_OR_FINAL_FREEZE'
        excluded_adverse_builds = @(
            'english_source_first_workpass/build_checkpoint_III_3_64_REJECTED_wrong_cwd',
            'english_source_first_workpass/build_checkpoint_III_3_64_REJECTED_literal_output_argument',
            'french_source_diplomatic_canon/build_checkpoint_T0036_REJECTED_wrong_engine_xelatex',
            'english_source_first_workpass/build_checkpoint_III_3_65_r1',
            'english_source_first_workpass/build_checkpoint_III_3_66_r1',
            'english_source_first_workpass/build_checkpoint_III_3_67_r1',
            'english_source_first_workpass/build_checkpoint_III_3_67_r2',
            'english_source_first_workpass/build_checkpoint_III_3_67_r3',
            'english_source_first_workpass/build_checkpoint_III_3_67_r4',
            'english_source_first_workpass/build_checkpoint_III_3_67_r5',
            'english_source_first_workpass/build_checkpoint_III_4_68_r1',
            'english_source_first_workpass/build_checkpoint_III_4_69_r1',
            'english_source_first_workpass/build_checkpoint_III_4_70_r1',
            'english_source_first_workpass/build_checkpoint_III_4_71_r1',
            'french_source_diplomatic_canon/build_checkpoint_T0042_r1',
            'english_source_first_workpass/build_checkpoint_III_5_73_r1',
            'english_source_first_workpass/build_checkpoint_III_5_73_r2',
            'english_source_first_workpass/build_checkpoint_III_5_73_r3',
            'english_source_first_workpass/source/$out',
            'english_source_first_workpass/source/$build'
        )
    }
    provenance_control = [ordered]@{
        path = '00_lane_control/PROJECT_LOGBOOK_METHODOLOGY_REPLICATION_DOI_REQUIREMENT_20260802.md'
        bytes = 2296
        sha256 = 'BFA1E3A3EDA94E8C3425BAE50C842610A47D508FB260BF761BA3206883012679'
        archive_decision = 'EG-ARCHIVE-DUAL-DOI-LOGBOOK-CUSTODY-CONTROL-20260802-0001'
        methodology_doi = '10.5281/zenodo.21124403'
        replication_doi = '10.5281/zenodo.20461174'
    }
}

$validation | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $OutputPath -Encoding utf8

[pscustomobject]@{
    output = $OutputPath
    status = $validation.status
    errors = @($validation.errors)
    manifest_rows = $manifestRows.Count
    privacy_files = $privacyFiles
    privacy_occurrences = $privacyOccurrences
}
