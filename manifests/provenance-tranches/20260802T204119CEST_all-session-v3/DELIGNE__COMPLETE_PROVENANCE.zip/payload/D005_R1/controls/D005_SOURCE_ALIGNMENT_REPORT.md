# D005 source-alignment report

The complete 35-page IAS authority was replayed page by page against the inherited English original and French translation. Existing GPU OCR served only as a locator; no OCR was generated. Direct enlarged authority images control every admitted decision.

The final source-action table has 28 unique rows. It distinguishes inherited transcription/notation losses, genuine printed slips, encoding-only repairs, and rejected false positives. Printed defects are corrected only when the surrounding definitions, formulas, or cited result make the required reading determinate, and every such correction is disclosed visibly in both language readers.

Representative mathematical repairs include the strict-completion tildes in Definition 1.8; the isomorphism in `H^0(O_D) \simeq k`; the semidefinite intersection-form statement; the missing `s_*G` target; the base-change object `X_1`; the self-reference in Theorem 5.13; the lower-case generator `x_i`; the acting-group coset index in Theorem 5.15; and `Sp_{2g}` in Lemma 5.16. The terminal bibliography restores Wilhelm Mangler and the printed `I. Šafarevich` form from direct source evidence.

The final diagram table has 27 unique rows. Every surface was personally checked at 5,000 dpi, with 9,000-dpi escalation for the finite-extension geometry and the small coproduct index. Inherited native geometry was repaired wherever arrow multiplicity, direction, incidence, line style, or label placement differed from the printed source. Twelve compiled high-detail witnesses verify the final native output. All active delivered diagrams are TeX vector constructions; the PDFs contain no raster image objects.

Final readers are continuous through the bibliography and received date. English is 26 pages, French 27 pages, and the bilingual wrapper 53 pages. All three builds converge with zero required diagnostics. Whole-reader 600-dpi layout review passes; this layout evidence is not used to adjudicate diagram semantics.
