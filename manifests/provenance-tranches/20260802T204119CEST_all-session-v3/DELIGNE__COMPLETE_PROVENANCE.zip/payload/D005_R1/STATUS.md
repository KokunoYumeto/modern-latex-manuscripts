# D005 bilingual source-aligned successor — final local status

Status: `PASS_LOCAL_SOURCE_ALIGNED_BILINGUAL_EOF`

Scope: Deligne corpus item D005 only, P. Deligne and D. Mumford, “The irreducibility of the space of curves of given genus,” complete authority pp.1–35 / printed pp.75–109 through the terminal bibliography and received date. D006 and later items are excluded.

## Authority and lineage

Controlling authority:

`<REDACTED_USER_HOME>\Documents\arxiv_latex\library\IAS_scans\deligne\Number7 [~300dpi].pdf`

- 1,906,093 bytes / 35 pages / SHA-256 `A934793198705091919B281046FECA286942D9605805E40D7C790AF9239A3BB8`
- Original language: English
- Every page is a 2490×3495 bilevel image. Source decisions were made from enlarged direct authority detail, not the nominal scan DPI and never from OCR alone.

Comparison-only PDF:

`<REDACTED_USER_HOME>\Documents\Papors\OS\Deligne\01_papers\05_The_irreducibility_of_the_space_of_curves_of_a_given_genus.pdf`

- 735,455 bytes / SHA-256 `62516E7DB6DFBF7DD1DA6F766767BD11B6BB760A9CB43D86BE14ABBE501516B`

The pre-existing GPU OCR batches were used only as locator evidence. No OCR was generated or delegated. The inherited complete English/French pair was preserved as lineage and repaired only after direct-source adjudication.

## Final editable sources and readers

- English TeX: `tex\D005_DM_EN_source_aligned.tex` — 123,871 bytes — SHA-256 `B1F4017E122AFEA81FCAC6E1C4E4DE49854C2487FC2DE40E68A0483298F1E2AD`
- French TeX: `tex\D005_DM_FR_source_aligned.tex` — 133,141 bytes — SHA-256 `9452E01E971DA57F473A12359A090FEBE2EB4F37E6A860B541263B8E2B8BC19C`
- Bilingual wrapper: `tex\D005_DM_Bilingual_Reader.tex` — 719 bytes — SHA-256 `520EBF9FA30C245E58CF545ED948FCEC5E1E5C28B56BCE6B915F3C002553BFBD`
- English reader: 26 pages / 233,732 bytes — SHA-256 `2B4219B8B893BB2817F95CC7F78DF1B4DB746EA05A73DD77DAEAABBE596AAEE9`
- French reader: 27 pages / 238,772 bytes — SHA-256 `E695779A32B0FA22CC9300A4D8A49E66AF65BE8201C21F1BF81E42020F7F4AAE`
- Bilingual reader: 53 pages / 495,673 bytes — SHA-256 `E956EBCE32AA6C4239613A4074F9AE82D8771A943E496A11B8BA43C088795297`

English and French converge in three XeLaTeX passes; the bilingual wrapper converges in four. Passes 2–3 are byte-identical at the console for each language and passes 3–4 are byte-identical for the wrapper. Required build diagnostics are all zero.

The bilingual PDF has two correct language outline nodes, 67 embedded non-Type-3 font objects, and zero raster image objects. The native TeX diagrams remain vector output.

## Source and diagram review

All 35 authority pages were personally replayed through EOF. The exact disposition ledger contains 28 unique source actions, including rejected false positives, inherited losses, and printed source slips that are visibly disclosed rather than silently normalized.

All 27 diagram surfaces were personally compared against direct authority detail. Thirty-four decisive 5,000-dpi authority crops and three 9,000-dpi ambiguity crops support the review. Material repairs include dashed continuation geometry, exceptional-chain incidences, deformation overlays, fibered-category cospans, the valuative extension diagram, the four-level `M_g`/`Z_g`/`H_g` comparison, and the Jacobi-multiplicator square. Twelve compiled 5,000-dpi details confirm native-output fidelity and label separation. No mathematical or visual judgment was delegated.

Every final English and French page was rendered at 600 dpi for compiled-layout review. Four whole-reader contact sheets, the terminal page bands, and the five-page bilingual seam pass without clipping, collision, broken glyphs, accidental blanks, or seam defects. The 600-dpi evidence is layout-only; diagram semantics are controlled by the separate 5,000/9,000-dpi comparisons.

## Exact controls

- Input identities: `controls\INPUT_IDENTITIES.csv`
- Source actions: `controls\SOURCE_ALIGNMENT_ACTIONS.csv` — 28 rows / SHA-256 `C4F219A48C136136E7F64F9D97F224E304EF70CA239AD8DABD05F8899A8638E0`
- Diagram review: `controls\DIAGRAM_REVIEW.csv` — 27 rows / SHA-256 `5224C9EAED9FDABC0FF16C61CD83887301DF80254B7E187E409C8721F8745498`
- Source-alignment report: `controls\D005_SOURCE_ALIGNMENT_REPORT.md` — SHA-256 `10937A1509BC285D67C91F7074425AA7C18B05D1FCC711927A1AB809C9661040`
- Final validation: `controls\FINAL_LOCAL_VALIDATION.json` — 2,507 bytes — SHA-256 `7330B67EEE69CEDD3D63D03A53106B7348C0ED16EFCF005ED348C9B11B840AD2` — `PASS_LOCAL_SOURCE_ALIGNED_BILINGUAL_EOF`, `errors: []`
- Final self-excluding evidence manifest: `controls\FINAL_LOCAL_SHA256.csv` — 75 rows / 10,249 bytes — SHA-256 `F8C1432765AD38041179CA5D7DE54EBD164937319B3D6F430B3041E038A2D17C`; replay 75/75, errors 0, formula-risk 0
- Layout ledger: `qa\D005_LAYOUT_REVIEW_600DPI.csv` — SHA-256 `52CDD4606065CAB637D64E3D86563AD607EE3113A9EA20AE47FCE51606B4B71F`
- Build/render receipt: `qa\D005_BILINGUAL_EOF_BUILD_RENDER_PASS.md` — SHA-256 `E9B2AAC3C3FE88D47EACA073D530E47CF8F23C70B9C739B57AA43748228F857C`

D005 is locally complete. Exact next production item: D006. No archive, publication, letter-lane, or whole-corpus completion claim is made.
