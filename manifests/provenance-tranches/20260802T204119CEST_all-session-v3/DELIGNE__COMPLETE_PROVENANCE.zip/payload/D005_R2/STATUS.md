# D005 source-synchronized parallel bilingual successor — final local status

Status: `PASS_LOCAL_SOURCE_SYNCHRONIZED_PARALLEL_BILINGUAL_EOF`

Scope: Deligne corpus item D005 only, P. Deligne and D. Mumford, “The irreducibility of the space of curves of given genus,” complete through the terminal bibliography and received date. D006 and later items are excluded.

## Controlling source lineage

The source-aligned French and English TeX inputs are byte-identical copies of the closed predecessor `D005_bilingual_source_aligned_successor_20260801_r1`:

- English: `inputs\D005_EN_source_aligned.tex` — 123,871 bytes — SHA-256 `B1F4017E122AFEA81FCAC6E1C4E4DE49854C2487FC2DE40E68A0483298F1E2AD`
- French: `inputs\D005_FR_source_aligned.tex` — 133,141 bytes — SHA-256 `9452E01E971DA57F473A12359A090FEBE2EB4F37E6A860B541263B8E2B8BC19C`

The predecessor already closed direct authority replay, translation/source decisions, and native-diagram fidelity. This successor changes no mathematical, linguistic, bibliographical, diagram, or source-note content. It corrects only the predecessor's adverse sequential bilingual composition.

## Final source-level parallel composition

Each language body has exactly 265 blank-line source blocks. Their order agrees one-for-one. Two LaTeX environments cross a blank-line boundary in both languages, so source blocks 33–34 and 143–144 are each retained as one logical unit. The resulting 263 logical bilingual blocks are emitted French-left / English-right through `paracol`, with synchronization after every logical block and independent language footnote counters.

- Generator: `tools\GENERATE_PARALLEL_SOURCE.ps1` — 3,928 bytes — SHA-256 `204DD50482DF86FADFB723AA5AC52F04FCFDE208CE84404490F370BC2F578BDA`
- Generated bilingual TeX: `tex\D005_Parallel_Bilingual_Source.tex` — 339,600 bytes — SHA-256 `F273BE3D523BE6A6A597F3BF4604167A85DD55475D99C9DA2738081AEA769E58`
- Generator replay: 265 French blocks / 265 English blocks / 263 logical pairs; 339,600 output bytes; replay SHA equals the frozen generated source.

The final reader is A3 landscape so the two complete source measures remain readable without shrinking the mathematical material into narrow portrait columns.

## Final build and PDF

- Reader: `build\source_parallel_r1\D005_Parallel_Bilingual_Source.pdf` — 23 A3 landscape spreads / 326,879 bytes — SHA-256 `976C3C06E55F8CAFE85E38720ECCA91F8DF7D007A65510F8F935AE71D64B98AB`
- Final log: `build\source_parallel_r1\D005_Parallel_Bilingual_Source.log` — 32,503 bytes — SHA-256 `4C6B7D31AB0D5D9057F9110BBB33C61E7D0319C5638BB83D968185450D88365C`
- Three XeLaTeX passes completed. Final diagnostics: fatal 0; undefined control sequences 0; multiply-defined labels 0; duplicate destinations 0; missing characters 0; overfull boxes 0; rerun requests 0.
- PDF inspection: 23 pages; A3 landscape; 33 embedded non-Type-3 fonts; zero image objects.

## Personal layout review

All 23 spreads were rendered independently at 600 dpi and personally inspected at full-page scale. French and English remain paired by logical unit throughout, including title, section boundaries, displayed formulas, native diagrams, notes, footnotes, bibliography, and received date. No side is missing or blank; no clipping, collision, broken glyph, column intrusion, or terminal mismatch was found.

The 600-dpi renders prove output layout only. Source readings and diagram semantics remain controlled by the predecessor's direct 5,000/9,000-dpi authority review.

## Exact controls

- Input identities: `controls\INPUT_IDENTITIES.csv`
- Logical-block closure: `controls\PARALLEL_SOURCE_CLOSURE.csv`
- Render ledger: `controls\LAYOUT_RENDER_SHA256.csv`
- Personal review receipt: `qa\PARALLEL_BILINGUAL_SOURCE_LAYOUT_PASS_20260802.md`
- Final validation: `controls\FINAL_LOCAL_VALIDATION.json`
- Self-excluding final manifest: `controls\FINAL_LOCAL_SHA256.csv`
- Full rationale/adverse-history record: `LOGBOOK.md`

Terminal provenance is governed by `PROJECT_LOGBOOK_METHODOLOGY_REPLICATION_DOI_REQUIREMENT_20260802.md`, 2,296 bytes, SHA-256 `BFA1E3A3EDA94E8C3425BAE50C842610A47D508FB260BF761BA3206883012679`. Privacy-clean final logbooks and revision histories must ultimately be deposited and read back on both the methodology and replication DOIs.

D005 is locally complete. The next production item in this session's frozen D001–D045 lane is D006. No archive, publication, letter-lane, or whole-corpus completion claim is made.
