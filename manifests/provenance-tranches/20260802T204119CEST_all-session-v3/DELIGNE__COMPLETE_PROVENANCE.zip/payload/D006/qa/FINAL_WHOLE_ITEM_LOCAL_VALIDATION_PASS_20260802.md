# D006 final whole-item local validation PASS

Date: 2026-08-02  
Result: `PASS_LOCAL_SOURCE_ALIGNED_SIDE_BY_SIDE_BILINGUAL_EOF`  
Scope: D006 only, complete through the French bibliography/sigla and English references/initials. D007 and later items are excluded.

## Source and decision closure

- Canonical French authority: 35 physical pages / printed pp. 139--172 / 1,975,508 bytes / SHA-256 `19509C19B0CB056F4A5EBA83A48A99F54BB6DF0C7A96AB7F4018B0765E1ED98C`.
- English IAS authority: 20 physical pages / 220,415 bytes / SHA-256 `4407CECD765982D67523F2F21700238698C4E3A6E4C056B00C2E69F61C7FA3B2`.
- Both authorities were replayed sequentially through EOF. Source detail was inspected directly at 1,200--5,000 dpi as needed; canonical French terminal pages were inspected at 1,800 dpi. Existing GPU OCR was locator evidence only. No OCR was generated.
- `controls/SOURCE_ALIGNMENT_ACTIONS.csv`: 81 rows, 81 unique IDs, eight rectangular columns, no empty ID, formula-risk cells 0; 32,540 bytes / SHA-256 `C258C874E34E6DB00C55D9E2AC5F67A9CF126A1368E11240351B216341C27E59`.
- `controls/ACTIVE_SOURCE_SHA256.csv`: 17 rows / 2,451 bytes / SHA-256 `3932781C42410FBFC8727A3D1CFDDA947141EE7A930CF534E7AADB24777B3370`; replay 17/17, errors 0. It is an internal local-closure ledger because `INPUT_IDENTITIES.csv` intentionally records local authority locations.

## Final readers

| edition | pages | bytes | SHA-256 |
|---|---:|---:|---|
| French `build/fr_authority_eof_r3_terminal_sync/D006_LAD_FR.pdf` | 19 letter | 168,840 | `80E69F2487F840C2B46A76D0FEF6D7E709363C5E7FD8A653A9DADAD0518B6267` |
| English `build/en_bibliography_eof_r2_terminal_sync/D006_LAD_EN.pdf` | 19 letter | 165,813 | `95A7962CDFD15136940763DE3490E4D96C0B8A0DE8A73BEE412F4189363085FC` |
| French-left/English-right `build/bilingual_parallel_eof_r3_terminal_sync/D006_LAD_Bilingual.pdf` | 19 A3 landscape spreads | 346,301 | `F7CBC207ACFD540591D101CF7C9EDB330DC2EC1A2BD9313AE158F17862B1FDEC` |

All three final logs have zero required diagnostic hits. PDF inspection found 19/19 nonblank text pages in each reader; fonts are fully embedded and non-Type-3 (French 23 rows, English 22, bilingual 45); image rows are zero in all three. The side-by-side reader imports vector PDF pages and does not rasterize the editions.

## Complete final layout evidence

`controls/FINAL_LAYOUT_RENDER_SHA256.csv` has 19 rows / 3,196 bytes / SHA-256 `E4186FB930E0D1220970CAA423DE784B970D96BDE673EAA3A91DD54626430FEA`; replay 19/19, errors 0.

- Final spreads 1--5 were personally inspected at 600 dpi.
- Final spreads 6--16 are pixel-hash-identical at 600 dpi to the personally inspected bounded checkpoint renders named in the respective source-band receipts.
- Final spread 17 and monolingual page 17 were personally inspected after the terminal proof edits.
- Final spreads 18--19 and both monolingual page pairs were personally inspected after the matched bibliography/sigla synchronization.

All 19 final spreads are nonblank, French-left/English-right, correctly ordered, legible, and free of clipping, collision, or footer intrusion. The 600-dpi evidence carries output-layout status only; mathematical and textual source decisions remain controlled by the direct authority evidence.

## Append-only adverse history and privacy

The initial EOF side-by-side reader omitted the French sigla page, and the first compression remedy visibly crossed the footer. Both are preserved as rejected adverse history in the logbook and terminal receipt. The accepted remedy gives both languages an explicit matching page 19.

The French/English/bilingual TeX, action ledger, status, and logbook were scanned after replacing the sole private absolute path with a workspace-relative path: six files, private-home hits 0. This does not make the whole working tree a public package; local authority locations and private source witnesses remain intentionally internal and must be excluded or projected before custody.

## Disposition

D006 is locally complete in canonical/source-aligned French, source-aligned English, and true side-by-side bilingual form. No public-package/reference-v2, archive, DOI deposition/readback, D007, letter-lane, or whole-corpus completion is claimed. Privacy-clean provenance remains governed by `PROJECT_LOGBOOK_METHODOLOGY_REPLICATION_DOI_REQUIREMENT_20260802.md`, SHA-256 `BFA1E3A3EDA94E8C3425BAE50C842610A47D508FB260BF761BA3206883012679`.
