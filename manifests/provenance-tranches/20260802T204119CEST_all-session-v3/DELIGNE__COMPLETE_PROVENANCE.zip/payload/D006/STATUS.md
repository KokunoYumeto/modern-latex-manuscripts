# D006 bilingual source-alignment status

Status: `PASS_LOCAL_SOURCE_ALIGNED_SIDE_BY_SIDE_BILINGUAL_EOF`

## Scope and exact cursors

- Item: D006, Pierre Deligne, *Formes modulaires et représentations ℓ-adiques*.
- Canonical French authority: NUMDAM Bourbaki original, physical pp. 1--35 / printed pp. 139--172, 1,975,508 bytes, SHA-256 `19509C19B0CB056F4A5EBA83A48A99F54BB6DF0C7A96AB7F4018B0765E1ED98C`.
- English authority: IAS born-digital retype dated 28 June 2004, physical pp. 1--20, 220,415 bytes, SHA-256 `4407CECD765982D67523F2F21700238698C4E3A6E4C056B00C2E69F61C7FA3B2`.
- English sequential cursor: EOF, including references and initials.
- French sequential cursor: EOF, including bibliography and sigla.
- Hard stop: end of D006. D007 and later items are untouched in this root.

## Current source-aligned editions

- French TeX: `tex/D006_LAD_FR.tex`, 72,397 bytes, SHA-256 `A526D9D69B5CDAAAFCFE69567FB164F0D56E8CBAA7940FEF6DED018BFF064BDC`.
- English TeX: `tex/D006_LAD_EN.tex`, 68,885 bytes, SHA-256 `2B3F627FF1CB8081528E37EA309F3C94F5D7FEA72012E10513B14BFB4FA264AC`.
- Side-by-side composition TeX: `tex/D006_LAD_Bilingual.tex`, 1,345 bytes, SHA-256 `6497485EBDE0DB87C6CB75EC798D34D9DAE2BE1369EE932074ACA6CD1134E6D2`.
- Source decision ledger: `controls/SOURCE_ALIGNMENT_ACTIONS.csv`, 81 unique actions / 32,540 bytes / SHA-256 `C258C874E34E6DB00C55D9E2AC5F67A9CF126A1368E11240351B216341C27E59`.

The French original controls the diplomatic French edition and adjudicates damaged English-retype passages. The IAS retype controls the English wording where sound. Existing GPU OCR is locator evidence only; no OCR was generated. Every mathematical/source/translation and visual decision was made by the top-level session lead; none was delegated.

## Current verified readers

- French: `build/fr_authority_eof_r3_terminal_sync/D006_LAD_FR.pdf`, 19 letter pages / 168,840 bytes / SHA-256 `80E69F2487F840C2B46A76D0FEF6D7E709363C5E7FD8A653A9DADAD0518B6267`.
- English: `build/en_bibliography_eof_r2_terminal_sync/D006_LAD_EN.pdf`, 19 letter pages / 165,813 bytes / SHA-256 `95A7962CDFD15136940763DE3490E4D96C0B8A0DE8A73BEE412F4189363085FC`.
- Genuine side-by-side bilingual: `build/bilingual_parallel_eof_r3_terminal_sync/D006_LAD_Bilingual.pdf`, 19 A3 landscape spreads / 346,301 bytes / SHA-256 `F7CBC207ACFD540591D101CF7C9EDB330DC2EC1A2BD9313AE158F17862B1FDEC`.

All final logs have zero required diagnostics. Bounded receipts cover the complete English authority and French printed bands 139--143, 144--148, 149--153, 154--159, 160--164, 165--169, and 170--172/EOF. The final terminal receipt records the rejected 18-spread omission, the rejected clipping-prone compression attempt, and the accepted explicit matched page-19 synchronization.

## Final local validation and provenance

The global control `PROJECT_LOGBOOK_METHODOLOGY_REPLICATION_DOI_REQUIREMENT_20260802.md`, 2,296 bytes, SHA-256 `BFA1E3A3EDA94E8C3425BAE50C842610A47D508FB260BF761BA3206883012679`, is mandatory. Final privacy-clean logbook, decisions, append-only reversals, continuation record, and exact manifests must ultimately be deposited/read back on both methodology DOI `10.5281/zenodo.21124403` and replication DOI `10.5281/zenodo.20461174`.

The final machine controls are `controls/ACTIVE_SOURCE_SHA256.csv`, `controls/FINAL_LAYOUT_RENDER_SHA256.csv`, `controls/FINAL_LOCAL_VALIDATION.json`, and the self-excluding `controls/FINAL_LOCAL_SHA256.csv`. The whole-item receipt is `qa/FINAL_WHOLE_ITEM_LOCAL_VALIDATION_PASS_20260802.md`.

D006 is locally complete through EOF in canonical/source-aligned French, English, and genuine French-left/English-right form. Public-package/reference-v2 closure, dual-DOI deposition/readback, archive custody, D007, letters, and whole-corpus completion remain unclaimed.

## Semantic scaffold and recovered control state

Preparatory machine-readable indexing is present in `controls/SEMANTIC_UNITS.csv` (56 stable language-neutral units) and `controls/SEMANTIC_DEPENDENCIES.csv` (19 explicit source-supported relations). This is a scaffold for later multilingual/interlanguage and Stacks-style work, not a claim of formalization. It follows `Transcription/00_lane_control/DELIGNE_BILINGUAL_SEMANTIC_INDEX_AND_INTERLANGUAGE_SCAFFOLD_20260802.md`, SHA-256 `C348283EBC3ED045AFBE2107D2C8B4A068E04C6D3E9639244E1F074423EC2009`.

The prior `LOGBOOK.md` and `STATUS.md` were found NUL-corrupted during the PC-instability interval and were restored exactly from immutable task file-change history before this append. Recovery evidence and exact adverse identities are recorded in `controls/LOGBOOK_STATUS_NUL_CORRUPTION_AND_RECOVERY_20260802.md`; the no-overwrite recovery copies remain preserved. TeX, PDF, diagrams, and semantic CSVs were not implicated.
