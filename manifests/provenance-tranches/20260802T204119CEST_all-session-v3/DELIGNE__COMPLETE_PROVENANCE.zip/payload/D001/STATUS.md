# D001 parallel bilingual layout successor

Status: `PASS_PARALLEL_LAYOUT_CORRECTION__MONOLINGUAL_CONTENT_UNCHANGED`

Scope is layout only. The predecessor monolingual French and English source decisions are unchanged and the two input PDFs remain byte-identical. The adverse sequential bilingual composition is superseded for the bilingual gate.

The A3 landscape reader contains four French-left/English-right spreads. Root review inspected all four 600-dpi output spreads and found the same theorem/proof region on each pair, no clipping, no wrong-section pairing, and no blank or missing half. English reflow runs modestly ahead inside some spreads but remains within the same logical region; that bounded drift is accepted and recorded rather than silently described as line synchronization.

Exact receipt: `qa/PARALLEL_BILINGUAL_LAYOUT_PASS_20260802.md`.
Machine validation: `controls/FINAL_LOCAL_VALIDATION.json`, `PASS`, `errors=[]`.

No publication, archive, rights, reference-v2, or public-readback claim is made.
