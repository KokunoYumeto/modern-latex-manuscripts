# D007 bilingual source-alignment status

Date: 2026-08-02

Status: `OPEN__SOURCE_REPLAY_NOT_YET_ADVANCED`

Scope is Deligne paper D007, *Travaux de Griffiths*, complete 25-page authority item only. D006 is the closed predecessor. D008 and later papers remain excluded and untouched.

Selected authority is the 25-page IAS scan `Number8 [~300dpi].pdf`, 2,564,345 bytes, SHA-256 `A598A5D176A3A8C729D47FAD27AF5879DFC7E68F4FEDCEAADA78D9FEEC0FC561`. The 25-page collected-paper split, 374,084 bytes, SHA-256 `34ED5E545A1F85AFC19A8063B2A0B355CC53EE6109CAA294F657A17D5A73C039`, is comparison evidence rather than controlling authority.

Inherited French and English TeX drafts are bound in `controls/INPUT_IDENTITIES.csv` and have been copied byte-identically into `tex/` without source edits. Existing GPU OCR covers authority pages 1–13 and 14–25 and is locator/drafting evidence only. No OCR will be regenerated or delegated.

Exact current cursor: authority physical page 2 of 25, paragraph 1.3 immediately after equation (1.2.3). Authority page 1 and the top of page 2 are sequentially closed; actions `D007.source.action.001`--`.010` are admitted. The equation-tag-side decision is closed consistently in both editions. No compilation, public package, archive action, or completion claim has been made.

The locator-only structural map is `controls/PAGE_STRUCTURE_BASELINE.csv`: title/§1 at p.1, §2 p.3, §3 p.4, §4 p.10, §5 p.13, §6 p.21, bibliography p.24. These positions are not source-certification claims.
