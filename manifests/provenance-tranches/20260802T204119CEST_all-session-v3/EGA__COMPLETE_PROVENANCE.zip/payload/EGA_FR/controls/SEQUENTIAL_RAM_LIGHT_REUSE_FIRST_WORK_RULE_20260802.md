# Sequential RAM-light reuse-first work rule

Date: 2026-08-02  
Scope: the active EGA French diplomatic transcription / English source-recheck lane, and its later bounded Deligne handoff.

1. Work proceeds in small sequential source units. Only one CPU- or RAM-heavy operation may run at a time.
2. Existing authority pages and detail crops are searched and reused before generating anything new.
3. New source imagery is generated only when the current reading cannot be decided from existing evidence. Generate one narrowly relevant page or crop at a time, never a speculative batch.
4. Resolution follows represented detail: ordinary context generally uses roughly 1100--1400 dpi; genuinely small or ambiguous glyphs, indices, primes, arrows, or attachments may use higher resolution. Do not use 5000/9000 dpi automatically.
5. Compiled-output layout may be checked at a lower resolution sufficient to see clipping, overlap, placement, and page seams. Such output renders never adjudicate source fidelity.
6. No new OCR is authorized. Floris's existing OCR is locator/drafting witness only.
7. At most two or three agents may be active, and only for disjoint low-intensity mechanical or preliminary grunt work. Agents may not run image/render/OCR/build swarms, duplicate ranges, or make final source, mathematical, translation, diagram, or visual judgments.
8. Reuse existing images and generated artifacts whenever their provenance and resolution are sufficient. Do not regenerate equivalent files for convenience.
9. Every source-affecting decision, retained normalization, discovered lead error, reversal, and workflow failure is recorded append-only with exact authority/source identities and rationale.
10. Scratch or misdirected generated output is preserved as adverse history and excluded from evidence/manifests; it is not silently promoted or deleted.

This rule controls resource scheduling and evidence generation. It does not relax source fidelity, exact cursor custody, compilation after real edits, or restartable logbook requirements.
