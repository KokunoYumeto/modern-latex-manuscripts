# Upload instructions for Codex Alpha

1. Do not unpack this archive into the repository root without preserving the top-level folder.
2. Recommended path: `releases/interlanguage_connection_framework_20260706/`.
3. Commit this release archive or its unpacked tree as a derived-artifact release.
4. Upload the large source-body archives listed in `source_indexes/SOURCE_ARCHIVE_ASSET_MANIFEST.csv` as separate release assets if repository size matters.
5. Do not overwrite frozen baselines.
6. Do not apply patch proposals directly. Batch-0 and Batch-1 patch artifacts are dry-run / task-spec inputs only.
7. Required acknowledgement file for the receiving repo/branch: `FABLE_REQUIREMENTS_ACKNOWLEDGED_20260706.md`, stating this package path and which source-body zips were separately preserved.

## Minimal commit message

`Add interlanguage connection framework release 20260706`

## Required post-push note

Record the release path, SHA256, and source-body asset handling in the branch logbook.
