# Interlanguage Connection Framework — GitHub Release Bundle

Generated: 2026-07-06

This archive is a targeted GitHub-uploadable release package for the interlanguage / computational interlinguistics work. It contains derived frameworks, weighted automaton ledgers, review packets, coordination task specs, and source-archive indexes. It intentionally does **not** embed all large source-body zips; those are listed in `source_indexes/SOURCE_ARCHIVE_ASSET_MANIFEST.*` and should be uploaded separately as release assets or kept in the source archive.

## What this release is

- A unified interlanguage marker/evidence automaton over all active lanes.
- A multilane weighted framework for Slavic/Interslavic, Pan-Romance, Arabic/Persianate, CJK, Turkic-frontier, and source-history layers.
- A reconciled Interslavic weighted automaton layer with State C as the current quotable branch-balance number.
- Pan-Romance and non-Slavic weighted automaton packages.
- Global mathematical-register / concept-history / predictive-routing layers.
- Codex Alpha / Codex Beta / Fable coordination packets.

## Current quotable Interslavic branch-balance number

State C: `E=2341, W=223, S=239, D1=1.753704, KL=0.536882`.

Do not quote the old v2 automaton branch masses as current measurement; retain them as architecture/snapshot evidence.

## Directory layout

```text
core_framework/          unified and multilane framework packages
lane_packages/           per-lane automata and review packages
global_register/         global math-register, concept-history, predictive model
normalization_patchwork/  dry-run patch and normalization proposal packets
source_indexes/          source-body and archive manifests; source bodies not embedded
coordination/            instructions for Codex Alpha/Beta/Fable
docs/                    source-use policy, atlas, framework draft, status, authorship
tables/                  key direct CSV/JSON exports
provenance/              originating-session and source-history documentation
manifests/               release manifest and checksums
```

## Boundaries

No term in this package is certified. Native source-body hits are witness candidates until row-context reviewed. Generated/draft material is internal consistency or discovery material only. Adverse evidence is kept separate from support.

## How to push

See `UPLOAD_TO_GITHUB.md`.
