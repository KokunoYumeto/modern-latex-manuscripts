# Noether German Source Audit Logbook

## 2026-06-25 - P36 R127/GDZ600 disposition / no new patch

- Built `Noether_R127_LocalCodex_P36_GDZ600_SourceDisposition_NoNewPatch_WebDrop_20260625.zip`.
- Scope: Paper 36, `Idealdifferentiation und Differente`.
- Upstream checked: fixed Web package `Noether_R127_REBUILT_20260625.zip`, SHA256 `0F2E740924671F0C32E66524BC887DC8567B5CF3D9C0D920ACFE8AFCBB218497`.
- Current local target checked: `Noether_R127_LocalCodex_P01_SourceRepair_P02_P04Survival_WebDrop_20260625/tex/cum_de_R127_plus_localcodex_P01_P22_P30_P37_P42_sourcefix_20260625.tex`.
- Best staged source: `P36_JDMV39_p017_GDZ_canvas0312_600ppi.jpg`, 3280 x 5046 with 600 ppi metadata. This is below the standing 650 ppi floor, so this is best-available source disposition, not strict high-resolution certification.
- Visual check result: the GDZ source page confirms `2. E. Noether, Göttingen: Idealdifferentiation und Differente.`, italic `Differentialquotient`, italic `Ideals`, and the final sentence.
- Current R127-plus-local already has those source-visible readings. No TeX patch was made.
- Rejected old-package trap: an older P36 package changed `J. Ber. d. DMV 39` to `J. Ber. d. DMV39`, but the GDZ meeting-program source page does not contain that collected-volume wrapper citation line. It also carried a repaired segment that dropped source-visible `2.`. Therefore the `DMV39` spacing row is not source-actionable here.
- Package contents include current cumulative TeX, current P36 segment, GDZ source page, labelled P36 crop, source-quality CSV, disposition CSV, no-fix-trap CSV, and provenance hashes.

## 2026-06-25 - P41/P43 source-restoration survival in R126 / no new patch

- Built `Noether_R126_LocalCodex_P41_P43_SourceRestorationSurvival_NoNewPatch_WebDrop_20260625.zip`.
- Purpose: replace signature-only high-queue reconciliation with direct R126 section-level proof for P41 and P43.
- P41: current R126 lines 19791--19944 are byte-identical to `Noether_R124plus_P41_SourceRestorationSurvival_NoNewPatch_20260624/tex/P41_source_restore_reference_slice.tex`; diff is 0 bytes. No patch.
- P43: current R126 fixed-length 814-line source-restored span beginning at line 20178 is byte-identical to `Noether_R124plus_P43_SourceRestorationSurvival_NoNewPatch_20260624/tex/P43_source_restore_reference_slice.tex`; diff is 0 bytes. No patch.
- Source-quality caveats preserved: P41 prior restoration uses best staged GDZ/IIIF but lacks strict 650+ native-DPI certainty; P43 prior restoration uses best local source around 360 ppi. This package proves survival, not upgraded source certification.
- Practical continuation: do not replay P41/P43 source-restoration fixes into R126 from stale queue rows. Reopen only for better native source acquisition or a new concrete defect.

## 2026-06-25 - P35/P36 R126 disposition / no new patch

- Built `Noether_R126_LocalCodex_P35_P36_SourceRepairDisposition_NoNewPatch_WebDrop_20260625.zip`.
- Purpose: compare current R126 against prior P35/P36 source-repair packages and prevent stale queue replay.
- P35: `Über Maximalbereiche aus ganzzahligen Funktionen`, Rec. Soc. Math. Moscou 36 (1929), pp. 65--72. Current R126 differs from the prior repaired segment, but the difference is preferred: R126 removes a non-source English abstract and keeps the source-style closing line `(Rec. Math. XXXVI:1; 1929).` No new patch.
- P36: `Idealdifferentiation und Differente`, Jahresbericht DMV 39 (1930), p. 17. Current R126 differs from the prior repaired segment by preserving the source-visible `2. E. Noether...` author-numbering. I opened the GDZ source image and confirmed the `2.` is printed. Do not revert to the older segment that omitted it. Current R126 also preserves the emphasized `Differentialquotient` and `Ideals`.
- Source-quality caveat: prior P35/P36 repair packages used best-available 600ppi witnesses, below the strict 650+ preference. This package is a current-state disposition/survival package, not upgraded strict certification.
- Practical continuation: do not replay stale P35/P36 high-queue rows into R126. Reopen only for a new concrete defect or better native source.

## 2026-06-25 - P38 source-repair survival in R126 / no new patch

- Built `Noether_R126_LocalCodex_P38_SourceRepairSurvival_NoNewPatch_WebDrop_20260625.zip`.
- Purpose: resolve the stale R126 `queued_high_fidelity` row for P38 by proving that the prior source-repaired P38 section survived into the current R126 cumulative.
- Paper: R. Brauer, H. Hasse, E. Noether, `Beweis eines Hauptsatzes in der Theorie der Algebren`, J. reine angew. Math. 167 (1932), pp. 399--404.
- Compared current R126 P38 span (`cum_de_R126.tex` lines 18682--18898) against `Noether_P38_GDZ600_SourceRepair_R123plusP08P30P33P34P35P36_20260624/tex/P38_repaired_section_after_source_repair_20260624.tex`.
- Result: byte-identical; `audit/p38_prior_source_repair_vs_R126.diff` is 0 bytes. No new TeX patch is needed.
- Prior source-repair ledgers copied into the package: confirmed fixes, source-quality ledger, open items, summary JSON, and prior README.
- Source-quality caveat: prior P38 repair used GDZ/JRAM167 full-page witnesses tagged 600 ppi. This is best-available evidence from that package but below the strict 650+ preference. The package proves survival, not upgraded strict 650+/1000dpi certification.
- Practical continuation: do not replay P38 from stale queue rows unless a better native source appears or a new concrete defect is found.

## 2026-06-25 - P37 GDZ source-certified cumulative patch

- Built `Noether_R126_LocalCodex_P37_GDZSourceFix_WebDrop_20260625.zip`.
- Purpose: replace the earlier P37 source-witness-only package with an actual web-drop containing source-certain R126 German cumulative repairs, a patched cumulative TeX/PDF, a P37 patched slice, diff, CSV ledgers, and GDZ source witnesses.
- Paper: `Normalbasis bei Koerpern ohne hoehere Verzweigung`, J. reine angew. Math. 167 (1932), pp. 147--152.
- Source authority used: GDZ IIIF full-page images from manifest `PPN243919689_0167`, locally staged as `source_witnesses/GDZ_fullres/P37_GDZ_Crelle167_printed_p147...p152...jpg`.
- Source quality: highest found in this pass, about 666--668 ppi wide and 627--628 ppi high by local page-size estimate. This is much better than the older 360 ppi RA08 witness. Readability crops in the package are 200 percent enlargements of native GDZ crops and are not independent higher-native-DPI evidence.
- Confirmed TeX repairs applied to package copy `tex/cum_de_R126_p37_gdzfix.tex`: p147 Deuring footnote quotient readings corrected to source multiplication products; p148 `(einseitigen)` restored; p148 section-opening base order corrected from `\frakO` to `\frako`; p149 `(isomorphen)` restored; p150 `(rationalen)` restored; p150 determinant punctuation restored to source semicolon; p151 footnote 10 `(K_\frakp)_\mathfrak P` corrected to `(K_\frakp)_P`; p152 generic prime explanatory line corrected from indexed `\frakp_i`, `\mathfrak P_i` to `\frakp`, `\mathfrak P`.
- Build status: XeLaTeX compiled twice; output PDF is 466 pages; no fatal errors or emergency stops.
- No-fix traps logged: project title/author wrapper convention, `J. f. Math.` versus source `J. f. M.` bibliographic abbreviation, general macro styling, and Satz heading style. These are not current math/content defects.
- Practical continuation: if Web accepts this, fold only the eight CSV-confirmed repairs into its newest cumulative. Do not treat the package as blanket certification of all P37 beyond those audited loci.

## 2026-06-25 - P30 MA96 IA JP2 source-status package

- Built `Noether_R126_LocalCodex_P30_MA96_IAJP2_SourceStatus_WebDrop_20260625.zip`.
- SHA256: `8302E672012229E67ECDE2918F71CBBB05712B63C950D657E840A1C5B87B9C42`.
- Purpose: provide a complete, page-mapped Paper 30 source witness for the R126 queue item, without claiming strict 650+ certification.
- Paper: `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, Math. Ann. 96 (1927), pp. 26--61.
- Current R126 status: P30 remains `active_partial_after_pp58_61_repair`; prior pp. 58--61 source repair is absorbed, but full sequential source audit remains open.
- Source authority staged: IA volume `sim_mathematische-annalen_1927_96_jp2.zip`, leaves 31--66 mapped to printed pp. 26--61. IA PDF pages 32--67 are the corresponding PDF pages.
- Source quality: native JP2 pages are 2208 x 3372, 400 ppi. The IA grayscale witness is cleaner than the local 1-bit GDZ-style `PPN235181684_0096.pdf`, but still below the 650+ rule, so status remains `best_available_below_650`.
- Boundary check: p026 opens with the Noether P30 title/author line; p061 ends with `(Eingegangen am 13. 8. 1925.)`.
- Package includes raw JP2 leaves, native PNG conversions, a 36-page IA PDF cutout, current R126 cumulative TeX/PDF, current P30 TeX span, source dimensions, page map, source inventory, and queue-disposition CSV.
- Practical continuation: use this package for P30 source auditing. Do not redo pp. 58--61 except to check survival. If no higher native scan appears, work honestly from this 400 ppi best-available witness.

## 2026-06-25 - P29 R126 GDZ400 survival/source-quality package

- Built `Noether_R126_LocalCodex_P29_GDZ400_SurvivalStatus_WebDrop_20260625.zip`.
- SHA256: `3DCD948D6BAB1C72475C95C195FBA0192AB6204546B991DC7D8DFADFB708C6C2`.
- Purpose: convert stale/open Paper 29 queue status into a current R126 web-drop with actual source witnesses, current TeX slice, and explicit source-quality caveat.
- Paper: `Der Endlichkeitssatz der Invarianten endlicher linearer Gruppen der Charakteristik p`, Nachrichten von der Gesellschaft der Wissenschaften zu Goettingen, 1926, pp. 28--35.
- Current R126 span: `cum_de_R126.tex` lines 14351--14452; P29 starts at line 14352 and P30 starts at line 14453.
- Result: no new TeX patch. Current R126 preserves the prior RA71 survival items: section/title, journal citation, footnote counter reset, `Von Emmy Noether in Goettingen`, and Courant presentation line.
- Source witnesses included: GDZ full-page JPGs for printed pp. 28--35, convenience PDF assembled from those images, and previous 1200dpi inspection enlargements for the p28 header/footnotes.
- Source-quality caveat: GDZ pages are native 400 ppi, so P29 remains `best_available_below_650`, not strict 650+ certified. The 1200dpi crops are enlargement/inspection aids only, not independent optical source quality.
- Trap recorded: do not use `noether_p29_ia_source_20260623` or Math. Ann. 90 pp. 229--261 for P29; that is Paper 24 material.
- Public route checked: EUDML/GDZ point to the same 1926 Goettingen source; no better native-resolution public witness found in this pass.
- Practical continuation: drop stale generic P29 rows unless a concrete line/symbol defect is later found, or unless a better native source appears. Move audit time to Tail, actual P30 leftovers, or the high-queue later papers.

## 2026-06-25 - P15-P20 post-P14 anchor-survival package / no new patch

- Built `Noether_R124plus_P15_P20_PostP14AnchorSurvival_NoNewPatch_20260625.zip`.
- SHA256: `3DE989865A451A845D868C4AFF70DBB46815FEDB80C869304AF49A74E7F1E3DB`.
- Purpose: current-state non-regression package proving that known P15-P20 anchors and accepted prior fixes still survive in the newest local cumulative after the Paper 14 pp. 195--203 pass.
- Base/current TeX copied into the package: `Noether_R124plus_P14_p195_203_GDZ600_SourceFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P14_p195_203_gdz600_sourcefix_20260625.tex`.
- Extracted current span: P15 starts at base line 9309; P21 starts at base line 12696, so P15--P20 are captured as `tex_anchors/current_postP14_P15_P20_span.tex`.
- Result: no new TeX patch. This is for Web/NASA as a small drag-drop current-state ledger, not as a new source-image bundle.
- Verified 38/38 checks in `audit/P15_P20_postP14_anchor_survival_checks.csv`.
- Key surviving anchors include: P15 Schur citation `S. 355`; P16 `k_\lambda-\lambda+1=i` and `linear zusammensetzen aus $F$ ... $M$`; P17 `t_{ii}a_i=a_i`, footnote markers 21/22, and `\xi_1^2`, `\xi_2^2`; P18 Hentzelt title and resultant congruence; P19 sigma-exponent correction `g=p_1^{\sigma_1}\cdots p_\nu^{\sigma_\nu}`, ideal-order anchors, and element-divisor chain; P20 title and varrho/sigma/field-symbol support.
- Verified stale-negative checks include absence of P15 `S. 555`, P17 `Fortsetzung zu 17`, P18 stale `R^{(m)}(x_n)`, P19 stale `g=p_1^{\nu_1}\cdots p_\nu^{\nu_\nu}`, P20 stale `\tag{12'}`, and generic TODO/FIXME/MISSING/PLACEHOLDER hazard tokens in the P15--P20 span.
- ZIP expansion test passed: 15 files, 2,892,007 expanded bytes.
- Source-quality caveat retained: no new visual source check was performed for this package. It proves anchor survival only. Prior P13--P18 and P19--P20 ledgers are included for provenance.
- Practical continuation: do not redo P15--P20 for these known anchors unless the web cumulative loses one. Move to either a source-weak slice, a genuinely unverified paper, or a source-image acquisition task.

## 2026-06-25 - Web failed-thinking 106m49s P42 / RA82 salvage package

- Verified existing package `Noether_WebFailedThinking5_106m_P42_RA82_Salvage_WebDrop_20260625.zip`.
- SHA256: `98F2B35A3A6C0C724CB41025B0694736E0D73236EF9EB16C754A745DC35A9D31`.
- Purpose: extracts the useful residue from the failed web-thinking transcript supplied as `Activity · 106m 49s ... pasted-text.txt`.
- Verdict: no source-certified TeX patch came out of that failed web run. Do not import its half-built P42 reconstruction into the cumulative.
- Useful salvage retained: P42 source/provenance anchors; RA82 footnote-reset guardrails; warning that P42 remains survival/disposition only; notation hazards for a later P42 rebuild; raw failed transcript and excerpts.
- Main warning: the failed run was working from an older R124/P19-era candidate and reports a stale 467-page cumulative. Its base assumptions are not current after the later local P14 packages.
- Practical continuation: if P42 is reopened, use only the best available source witness and keep the caveat loud. The currently staged RA10/Actualites cutout has embedded 2048 x 3322 images at about 360 ppi, good enough for boundary/footnote-reset evidence but below the 650/1000 dpi dense-source rule.

## 2026-06-25 - P01-P08 post-P14 body survival package / no new patch

- Built `Noether_R124plus_P01_P08_PostP14BodySurvival_NoNewPatch_20260625.zip`.
- SHA256: `B228418301105EBA18EB40A7437205C936C17D5ED7C67B5FF4836450E88E31AF`.
- Purpose: current-state survival package proving that the accepted early-band Paper 01--08 body/fix anchors still survive in the newest local cumulative after the Paper 14 pp. 195--203 pass.
- Base/current TeX copied into the package: `Noether_R124plus_P14_p195_203_GDZ600_SourceFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P14_p195_203_gdz600_sourcefix_20260625.tex`.
- Result: no new TeX patch. The package is for Web/NASA as a small drag-drop current-state ledger, not as a new source-image bundle.
- Verified that the current post-P14 P01--P08 body, after stripping only the P09 boundary reset and final blank-line convention, is byte-identical to the prior post-P11 survival reference.
- Verified body SHA256: `72E3B03AF1975B34C832EB63F106D1EE43B0D1A4504CDE8338A769C2F0595E28`.
- Verified key survival checks in `audit/P01_P08_postP14_body_survival_checks.csv`: P01/P02/P03/P05/P07/P08 title anchors; P03 source-spelling title `Variabeln`, P03 author line, and formula (2) `\le n`; P08 source-confirmed `(zy)x` substitution, lambda-operator anchor, and restored Omega block; symbolic source-note apparatus anchor in the early Math. Ann. band.
- Verified stale-negative searches in `audit/P01_P08_postP14_negative_stale_searches.csv`: stale P08 `(xy)x` substitution absent, stale P03 `<n` inequality absent, no obvious lower Faber article leakage, and old P02 `theta H^3u` literal absent.
- ZIP expansion test passed: 20 files, 2,946,013 expanded bytes.
- Source-quality caveat retained: this package proves survival of accepted early-band fixes in the current TeX. It is not a fresh blanket 650/1000dpi certification of P01--P08. Prior source-quality limits remain binding: P04 and P06--P08 have stronger targeted exact-locus evidence; P01/P02/P03/P05 are mostly inherited/context survival rows unless reopened against best available source.
- Practical continuation: P01--P08 should not be re-opened for the listed anchors unless the web cumulative loses one. Next useful Noether work should move to an uncovered/weaker source-quality or source-restoration lane rather than duplicate this survival check.

## 2026-06-25 - P09 post-P14 survival package / no new patch

- Built `Noether_R124plus_P09_PostP14Survival_NoNewPatch_20260625.zip`.
- SHA256: `8D6333D857504A6FEEFC9938F3B729ECA2E3F09F1C667E4343136CE2193D2B4D`.
- Purpose: current-state survival package proving that the accepted Paper 09 source fixes and no-fix anchors still survive in the newest local cumulative after the Paper 14 pp. 195-203 pass.
- Base/current TeX copied into the package: `Noether_R124plus_P14_p195_203_GDZ600_SourceFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P14_p195_203_gdz600_sourcefix_20260625.tex`.
- Result: no new TeX patch. The package is for Web/NASA as a small drag-drop current-state ledger, not as a new source-image bundle.
- Verified that the current post-P14 Paper 09 span is byte-identical to the prior post-P11 Paper 09 survival span.
- Verified key survival checks in `audit/P09_postP14_survival_checks.csv`: Paper 09 title, source-style author line, Zermelo citation `Math. Ann. 75, S. 484 (1914)`, `\xi_1\cdots\xi_t` no-fix anchor, p112 dense anchors `f(z;a\cdots c)`, `a^\lambda`, and `c^\mu`, and the p127 definition block.
- Verified p127 definition block state: six source-intended `\Omega` occurrences and zero frak-R-like stale readings in that narrow block.
- Verified stale-negative searches in `audit/P09_postP14_negative_stale_searches.csv`: old `Math. Ann. 75, S. 434` is absent from P09; no global frak-R to Omega rewrite is requested or implied.
- ZIP expansion test passed: 17 files, 2,217,927 expanded bytes.
- Source-quality caveat retained: this package proves survival of accepted fixes in the current TeX. It is not a fresh blanket 650/1000dpi certification of P09; the prior P09 source witnesses remain best-staged GDZ/IIIF mixed 400/600ppi, and the p127 `\Omega` fix remains accepted only because the six source symbols are repeated, large, and unambiguous.
- Practical continuation: P09 should not be re-opened for the listed anchors unless the web cumulative loses one. Next useful Noether work should move to the next uncovered or weaker slice.

## 2026-06-25 - P10-P12 post-P14 survival package / no new patch

- Built `Noether_R124plus_P10_P12_PostP14Survival_NoNewPatch_20260625.zip`.
- SHA256: `89BC9828146AB1A30887B22B7C1E0B7E7B5FE687F1D470CA47FEFA0BB7BFC065`.
- Purpose: current-state survival package proving that the accepted Paper 10, Paper 11, and Paper 12 source fixes still survive in the newest local cumulative after the Paper 14 pp. 195-203 pass.
- Base/current TeX copied into the package: `Noether_R124plus_P14_p195_203_GDZ600_SourceFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P14_p195_203_gdz600_sourcefix_20260625.tex`.
- Result: no new TeX patch. The package is for Web/NASA as a small drag-drop current-state ledger, not as a new source transcription pass.
- Verified 12 survival checks in `audit/P10_P12_postP14_survival_checks.csv`: P10 author line, P10 `\Jdom` p538 repair, P10 `k_\sigma`, P10 indexed `F(t;\vartheta_i)\cdot G(t;\vartheta_i)`, P10 final parentheses; P11 p221 source comma, P11 `\Omega_\Gamma`, P11 plain `G_k(x)/H_k(x)`, P11 `\varphi_3(x)=w\cdot u/v`; P12 initial `f(x;dx)`, `d\delta x`, and barred-delta notation.
- Verified stale-negative searches in `audit/P10_P12_negative_stale_searches.csv`: no stale unindexed P10 `F(t;\vartheta)\cdot G(t;\vartheta_i)`, no stale P11 `\mathfrak L_\Gamma`, no false `G'_k(x)`, and no stale `\varphi_3(x)=u\cdot w/v`. The global `\Sdomain` macro still exists as a macro definition, so it is not by itself a defect.
- ZIP expansion test passed: 6 files, 2,121,629 expanded bytes.
- Source-quality caveat retained: this package proves survival of accepted fixes in the current TeX. It is not a new blanket 650/1000dpi certification of P10-P12; full-page witnesses in this band remain mostly 400-600ppi best-available, with targeted high-detail crops only for selected dense loci.
- Practical continuation: P10-P12 should not be re-opened for these known fixes unless the web cumulative loses one of the listed anchors. Next useful work should move to the next uncovered or weaker Noether slice rather than duplicate this survival check.

## 2026-06-25 - P14 pp.195-203 GDZ600 source-fix pass

- Built `Noether_R124plus_P14_p195_203_GDZ600_SourceFix_WebDrop_20260625`.
- Scope: Paper 14, `Die arithmetische Theorie der algebraischen Funktionen`, printed/source pp. 195-203.
- Base: local p190-194 package `Noether_R124plus_P14_p190_194_GDZ600_SourceFix_WebDrop_20260625`.
- Source authority: official GDZ IIIF page images `00000199`-`00000207`, staged as printed pp. 195-203, dimensions about 3152/3160 x 5101/5102. Caveat: locally treated as about 600 ppi, slightly below the preferred 650 ppi floor but best currently staged.
- Applied p196 source-confirmed correction: `gewöhnliche vielfach Punkte` -> `gewöhnliche vielfache Punkte`.
- Applied p202 source-visible notation correction: `\ell` -> Latin `l` at `Primzahl l`, `l`-te Wurzeln, and `l`-te Potenzreste.
- Checked pp. 195, 197-201, and 203 with no further patch. Noted no-fix traps for source-inline/current-display layout around p195-p196 and for the Brouwer article starting on p203 after Noether's paper ends.
- Evidence crops: p196 `vielfache Punkte`, p202 `Primzahl l` / `l`-te Wurzeln, and p202 `l`-te Potenzreste. These are enlarged from the staged GDZ source images, not new optical-resolution captures.
- XeLaTeX compiled successfully twice; resulting cumulative candidate PDF has 469 pages.

## 2026-06-25 - P13 pp.251-254 Commons DjVu source audit / two source-confirmed fixes

- Built `Noether_R124plus_P13_p251_254_CommonsDjVu_Audit_WebDrop_20260625`.
- Scope: Paper 13, `Invariante Variationsprobleme`, printed/source pp. 251-254.
- Source authority used in this pass: Commons DjVu page images fetched at 3984 x 5592 px for DjVu pages 17-20 / printed pp. 251-254. Caveat: image metadata is 72/undefined, so these are higher-detail best-available witnesses, not native PPI-certified 650+ source pages.
- Visually checked pp. 251-254 against the current local R124+ German cumulative candidate.
- Applied p252 source-confirmed mathematical correction: `\Div B` -> `\Div\bar B` in the relative-invariance paragraph. The source crop visibly reads `Div \bar B`.
- Confirmed nearby no-fix trap: later `\Div(B-\Gamma)` and function system `B-\Gamma` are source-visible unbarred and were left unchanged.
- Applied p254 source-visible textual mark correction: restored the apostrophe/prime-like mark in `Divergenzrelationen' werden`.
- Checked p251, p253, and the remaining p254 group/divergence paragraphs without further source-certified patch.
- XeLaTeX compiled successfully twice; resulting candidate PDF has 469 pages.
- Next P13 continuation point: printed/source p255 onward, if the web cumulative has not already moved beyond this slice.

## 2026-06-24 - P42 Source-Quality Blocker / No Patch

- Built `Noether_R124plus_P42_SourceQualityBlocker_BestAvailable_NoPatch_20260624`.
- Scope: Paper 42, `Zerfallende verschränkte Produkte und ihre Maximalordnungen`.
- Checked local staged source situation after R124: the usable source remains the RA10 local cutout `p42_scan.pdf`.
- Verified the PDF renders readably, but its embedded page images are only about 2048 x 3322 px / roughly 360 ppi. This is below the standing 650+ ppi source-check rule and must not be represented as final certification evidence.
- Checked Celebratio article 109 and title/source web searches. Celebratio has the exact bibliographic entry but its scraped PDF link is only the generic `/media/` endpoint; guessed PDF endpoints returned 404. No better open scan was resolved in this pass.
- No TeX patch was made. P42 stays open as `best_available_lowres_source_present_no_final_certification`.

## 2026-06-24 - P41 Source Restoration Survival / No Patch

- Built `Noether_R124plus_P41_SourceRestorationSurvival_NoNewPatch_20260624`.
- Scope: Paper 41, `Der Hauptgeschlechtssatz für relativ-galoissche Zahlkörper`.
- Compared the P41 span in the current local R124+ candidate against the prior `Noether_R124_PostWeb_P41_SourceRestoration_BestAvailable_20260624` source-restored reference span.
- Result: the extracted spans are byte-identical, SHA256 `01332AB8DDAEA3F677E111F23F39B831AF6F322C110B5ABE8F8223834EF02CF4`.
- No TeX patch was made. P41 restoration survives in the current local candidate.
- Caveat retained: the staged GDZ/IIIF source images are best-local and readable but not strict 650+ ppi certified.

## 2026-06-24 - P43 Source Restoration Survival / No Patch

- Built `Noether_R124plus_P43_SourceRestorationSurvival_NoNewPatch_20260624`.
- Scope: Paper 43, `Idealdifferentiation und Differente`.
- Compared the current local R124+ candidate against the prior `Noether_R124_PostWeb_P43_SourceRestoration_BestAvailable_20260624` replacement segment.
- Important method note: P43 cannot be safely extracted by searching for the next numbered paper, because later/tail material follows directly in the cumulative. I compared the exact 814-line source-restored replacement segment beginning at `\section*{43.`.
- Result: the extracted current and prior restored P43 spans are byte-identical, SHA256 `641F9310543B6E0BA24BE591C849A941E6A43DB5C67ACF7182185AE083B5FC69`.
- No TeX patch was made. P43 restoration survives in the current local candidate.
- Caveat retained: best local P43 source is only about 360 ppi.

## 2026-06-24 - P37 RA08 Survival / Wrapper Only

- Built `Noether_R124plus_P37_RA08Survival_WrapperOnly_NoNewPatch_20260624`.
- Scope: Paper 37, `Normalbasis bei Körpern ohne höhere Verzweigung`.
- Compared current local R124+ candidate P37 span against prior RA08 P37 reference segment.
- Result: actual P37 body survives; only current-cumulative wrapper lines differ (`\clearpage` and `\setcounter{footnote}{0}`).
- No TeX patch was made.
- Caveat retained: RA08 source scan is carried as provenance only, not fresh high-resolution certification.

## 2026-06-24 - R124 post-web P09 p112 dense hotspot no-patch closure

- Built `Noether_R124_PostWeb_P09_p112_Hotspot_NoPatch_WebDrop_20260624.zip` as a small web-drag package for the single RA88 P09 dense-hotspot row.
- SHA256: `79ACEEBF3B6A2970027B49B39DC02C82DB90CA264C9412EB01033ACF61A30FFB`.
- Checked current base `cum_de_R124_plus_LocalCodex_P40Complete_20260624_REFERENCE_UNCHANGED.tex`, Paper 09 lines 6774-6785, against GDZ printed p112 / canvas `00000118`.
- Result: no TeX patch. The `f(z;a\cdots c)` display, the `a^\lambda` / `c^\mu` gathered coefficient display, and the immediate p112/p113 continuity match the source witness at the checked locus.
- Source-quality caveat recorded: best staged witness for this exact locus is native 400 PPI. The package includes a labelled 2x visual enlargement for navigation, but it is not a new optical 1000-PPI source and must not be used to claim strict whole-paper certification.
- R124 queue status remains: Paper 09 still needs full-page best-available source audit beyond this one hotspot, because the complete GDZ article witness is mixed 400/600 PPI.

## 2026-06-24 - R124 post-web P10 dense hotspot no-patch package

- Built `Noether_R124_PostWeb_P10_DenseHotspots_NoPatch_WebDrop_20260624.zip` as a compact web-drag package for the four RA88 P10 dense/table hotspot rows.
- SHA256: `3254B587A79FD327D236705E8A1B2A97A1B369A4BC9E17A65E6338C3B37F4C67`.
- Checked current base `P10_currentbase_lines7647_7841.tex` against GDZ printed pp. 536, 543, and 544.
- Result: no TeX patch. The opening functional-equation two-column display, the rank-four determinant, the rank-four linear system, and the rank-two determinant/formula match the staged source witnesses.
- Source-quality caveat recorded: these exact staged pages are native 400 PPI, so the package closes only the four listed hotspot rows as no-patch dispositions; it is not a strict 650/1000-PPI full-paper certification.

## 2026-06-24 - R124 post-web Local Codex delta wrapper for NASA/Web

- Built and ZIP-tested `Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624.zip` as the clean post-R124 local delta wrapper for web/NASA.
- SHA256: `44AEC971E09666E6CAC3C65B3D91CA7936D358A66622B6677F2BF8D740D435AD`.
- Contents: unzipped final P30 repair package; P10/P11/P12 current-base no-new-patch zips; R124 source queue, source-quality, and closure-ledger copies; local delta summary CSV.
- P30 repairs carried inside: restored footnotes 27 and 28, moved footnote 28 marker to Satz III, corrected the Axiom IV display and contradiction chain around printed pp. 53-54, and centered the received-date line.
- P10/P11/P12 carried only as no-new-patch/current-base survival packages; they are not strict full-paper source certifications.

2026-06-13

- Confirmed current task: German Noether source certification, not InterSlavic local search.
- Located working lane at `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual`.
- Found newest German source-critical package: `N_SYM_RA41_P04_complete_20260613.zip`.
- Read RA41 status: Paper 01, Paper 02, and Paper 04 are closed at the current German source-symbol standard. Paper 04 pp. 118-154 are closed; source PDF tail p. 155 belongs to the next article and is excluded.
- Recorded next source-critical target from RA41: Paper 07 or another staged original. Paper 03 original is not directly staged in the current runtime.
- Built staging folders for a core source-audit support package and a separate high-DPI witness companion.
- Copied all current `N_SYM_RA*.zip` packages into the core package.
- Copied and extracted the compact source-original handoff containing original journal/source PDFs and auxiliary OCR/Markdown.
- Copied 650/1000 dpi witness ZIPs for Papers 02, 08, 17, and 19 into the high-DPI companion.
- Extracted 306 key ledger files from existing RA directories into the core package for quick web/pro session access.
- Created `noether_RA41_first_propagation_sweep_candidates.csv` from exact literal searches against the current cumulative German TeX.
- First propagation sweep result: no literal residue for several RA40/RA41 already-fixed bad strings; three `KH^3u` occurrences remain as high-DPI table/exponent candidates and must not be edited without source-page confirmation.
- Performed first high-DPI visual follow-up on the `KH^3u` candidates.
- Confirmed printed p68 source distinction: prose says `Faltung von K mit H_3`, but the immediately following irreducible form says `(KH^3u)^6`. Current German TeX has prose `H^3`, so this is a source-confirmed fix request.
- Confirmed printed p91 Tabelle I row 21 `(KH^3u)^6` as source-visible; no fix.
- Confirmed printed p92 Tabelle II row 17 `((KH^3u)^4,s,u)^3` as source-visible; no fix.
- Added witness crops/raw slices under `03_key_ledgers/p02_flagged_KH3u_witnesses/`.
- Added `noether_immediate_source_confirmed_fix_requests.csv`, `noether_first_visual_dispositions_KH3u.csv`, and `noether_p02_KH3u_witness_manifest.csv`.
- Started a second-auditor pass on Paper 05 because the web/pro session is actively repairing that area and Paper 05 was suspected to be a weak output.
- Located source authority `N_RA04_20260604/01_scan/p05.pdf` and newer standalone `p05_de_critical_RA42.pdf`.
- Rendered Paper 05 source pages at 650 dpi and RA42 output pages at 220 dpi under `Noether_RA42_P05_local_audit_20260613`.
- Visually checked source pp. 316-319 against the current RA41 cumulative and RA42 standalone.
- Confirmed one source-visible cumulative integration defect: RA41 cumulative omits source footnote 1, `Vortrag, gehalten auf der Naturforscherversammlung Wien 1913.` RA42 already has this as a title footnote.
- Confirmed the Steinitz footnote, Lüroth/Castelnuovo/Enriques footnote, integrality-basis display, and closing `je n Polynomen` locus as source-checked no-fix items. OCR damage in those areas must not be used as authority.
- Built labelled witness crops and a web-drop ledger for Paper 05 RA42 integration.
- Mapped Paper 06 source `N_RA04_20260604/01_scan/p06.pdf` against the RA41 cumulative block starting at line 4426.
- Rendered selected Paper 06 source pages at 650 dpi: opening page, p. 195, and p. 196.
- Found a systematic source-fidelity issue in Paper 06: source notes use page-local symbol markers such as `*)` and `**)`, while RA41 uses ordinary numbered `\footnote` markers throughout the Paper 06 block. Content is present at checked loci; marker fidelity remains an open style/canonical fix decision.
- Closed a suspected Paper 06 tail false alarm: the source really has `dem Umstand ergibt daß`; no modernization should be made without a stronger source authority.
- Closed a second Paper 06 tail false alarm: denominator `/i`, final symmetric identity, and `\pm 1` are source-visible at checked loci.
- Started Paper 07 as the next non-overlapping second-auditor target, using `N_RA03_20260604/01_scan/p07.pdf` as the clean four-page page-map authority and the five-page `paper_07_mathann077_pp089_092_ORIGINAL.pdf` only as a comparator.
- Rendered all four Paper 07 source pages at 650 dpi under `Noether_P07_local_audit_20260613`.
- Confirmed Paper 07 formula anchors as no-fix at checked loci: opening linear transformation display, formula (1), the Galois resolvent, the `J_{\mu_1\ldots\mu_n}` finite bound, the Weber correction derivative relation, and the closing relative-invariant note.
- Found a repeated source-fidelity defect class in Paper 07: all six source footnotes use page-local symbolic markers `*)` / `**)`, while RA41 cumulative uses ordinary numbered `\footnote` markers. This repeats the Paper 06 apparatus issue and should be handled as a canonical style/source-fidelity decision across the early Math. Ann. papers.
- Built the Paper 07 targeted web-drop with labelled 650 dpi crops and exact CSV fix/no-fix rows.
- Started Paper 08 targeted audit against `N_RA03_20260604/01_scan/p08.pdf`, using the ten-page article slice as page-map authority and the eleven-page original wrapper only as comparator.
- Confirmed the recurring P06/P07/P08 source-apparatus pattern: source notes use page-local symbolic markers `*)`, while the current cumulative uses ordinary numbered `\footnote` markers.
- Found source-confirmed Paper 08 math defects: line 6029 has `(xy)x` where source has `(zy)x`; line 6087 has first operator argument `\partial/\partial x` where source has `\partial/\partial\lambda`; lines 6183-6185 collapse the source Omega equation and omit its middle equality plus source `*)` note marker.
- Closed a possible false alarm in Paper 08: the source really says `volle Systeme`, so the current plural is source-visible and should not be changed.
- Built the Paper 08 targeted web-drop with labelled 650 dpi crops, exact fix/no-fix rows, and source/comparator PDFs.
- Switched to the non-overlap audit direction requested by the user: Paper 20 downward toward Paper 10, CSV-first, images only where they prove a correction.
- Audited Paper 20 against `N_RA05_20260604/01_scan/p20.pdf` (Math. Ann. 85 (1922), pp. 26-33), using the RA41 cumulative German TeX lines 12323-12558.
- Confirmed that Paper 20 uses ordinary numbered source footnotes; the P06-P08 symbolic-footnote-apparatus issue must not be propagated to Paper 20.
- Found one source-confirmed Paper 20 source-fidelity/math-index correction: formula (13) should use factor-sum indices `\kappa,\lambda`; current RA41 uses `\mu,\nu`. The following prose product indices `\mu,\nu` are source-visible and should remain.
- Built a lean Paper 20 audit drop: CSV, source PDF, one labelled 650 dpi crop, and no bulk page images.
- Continued the non-overlap audit direction with Paper 19 tail, using `N_RA05_20260604/01_scan/p19.pdf` as the 43-page source/page-map authority for Math. Ann. 83 (1921), pp. 24-66.
- Rendered printed pp. 58-66 for manual visual checking, but did not include those bulk page images in the web drop.
- Found one source-confirmed Paper 19 mathematical index error in the final element-divisor proof: current RA41 lines 12291-12298 use shifted auxiliary exponents `s_\nu...s_i`, `t_\nu...t_i`, and `r_\nu=s_\nu\le...`; source printed pp. 65-66 uses `s_1...s_\lambda`, `t_1...t_\mu`, and `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`.
- Found one low-priority Paper 19 source-order cleanup: current line 12050 reverses the source pair after `Wegen`; source printed p. 58 has `\ideal Q\eqzero{\ideal P}` before `\ideal P^\rho\eqzero{\ideal Q}`.
- Checked and recorded no-fix anchors for printed pp. 59-66: polynomial example ideal chains, even-polynomial example, even-number/composite-number examples, Noether-Schmeidler paragraph, matrix-module construction, element-divisor vertical-bar notation, Brandt matrix footnote, and closing date/receipt.
- Built `Noether_P19_Tail_Source_Audit_WebDrop_20260613.zip` as a lean 4.76 MB package: CSV ledgers, source PDF, three labelled 650 dpi crops, README/source map, and checksums; no full rendered page folder.
- Audited Paper 18 as the next backward target, using `N_RA04_20260604/01_scan/p17c18.pdf`; split out page 14 as the one-page P18 source witness.
- Confirmed the old audit lead that RA41 already has the correct final resultant factor `R^{(n)}(x_n)`, not `R^{(m)}(x_n)`.
- Found one source-confirmed Paper 18 formula-symbol correction: current RA41 line 11150 has the resultant display ending with `=0(\mathfrak M)`, while the source printed p. 101 has `\equiv 0(\mathfrak M)`.
- Built `Noether_P18_Source_Audit_WebDrop_20260613.zip` as a 0.66 MB package: CSV ledgers, single-page source PDF, one labelled 650 dpi crop, README/source map, and checksums.
- Audited the targeted Paper 17 old-lead loci against `paper_17_mathzs008_pp001_035_ORIGINAL.pdf`, focusing on printed pp. 24, 25, and 28 rather than redoing the whole article.
- Confirmed old Paper 17 leads already fixed in RA41: formula (34) has `t_{ii}a_i=a_i`; the finite-rest-group basis has `\xi_1^2,\xi_2^2`; footnote 20 after `Isomorphie` is present.
- Found two source-confirmed Paper 17 omissions: footnote 21 is missing after the displayed equality ending `=r^{\sigma\rho}b_\rho`; footnote 22 is missing immediately after the `=a_\sigma` relation inside formula (39).
- Built `Noether_P17_Targeted_Audit_WebDrop_20260613.zip` as a 6.58 MB targeted package: CSV ledgers, the original Paper 17 source PDF, three single-page source witnesses, one labelled 650 dpi crop, README/source map, and checksums.
- Audited Paper 16 against the clean six-page source `N_RA04_20260604/01_scan/p16.pdf`, using the active German cumulative block lines 9824-10002.
- Found one source-confirmed Paper 16 correction: current line 9985 says invariants are linearly composed from `\Phi` and forms from `M`, while the source printed p. 30 says they are composed from `F` and forms from `M`.
- Checked and rejected several Paper 16 OCR false-positive traps: formula (2) really has `[identisch in x,y]`; formula (3) really has `[identisch in \xi]`; formula (9) keeps the `k_\lambda-\lambda+1=i` index pattern; the determinant notation in section 2 is unstarred.
- Built `Noether_P16_Source_Audit_WebDrop_20260613.zip` as a 1.91 MB package: CSV ledgers, source PDF, two useful 650 dpi crops, README/source map, and checksums; no full rendered page dump.
- Audited targeted Paper 15 loci against `N_RA04_20260604/01_scan/p15.pdf`, using the active German cumulative block starting at line 9204.
- Found one source-confirmed Paper 15 symbol correction: current lines 9708 and 9712-9715 use Greek `\chi` indices in the normalization block; source printed p. 152 uses ordinary italic Latin `x_1,x_2,\ldots,x_{\rho+\sigma}` and corresponding `\xi_{x_i,\cdot}` indices. Do not replace this with `\varkappa` or `\kappa`.
- Found one source-confirmed Paper 15 citation correction: current line 9772 has Schur `Math. Ann. 71, S. 555 (1912)`; source printed p. 154 footnote 3 has `S. 355 (1912)`.
- Checked and rejected two Paper 15 false-positive traps: source printed p. 153 really has `(n,n-1)\not\equiv0\pmod p`; source printed p. 154 footnote 2 matches the current block-matrix apparatus well enough for this pass.
- Built `Noether_P15_Targeted_Source_Audit_WebDrop_20260613.zip` as a 3.33 MB package: CSV ledgers, source PDF, two 650 dpi crops, current-TeX excerpt, README/source map, and checksums; no bulk rendered page dump.
- Started Paper 14 targeted audit against `N_RA04_20260604/01_scan/p14.pdf`, using the active German cumulative block lines 8980-9190.
- Found three source-confirmed Paper 14 corrections:
  - current line 9076 has `mod. (z-\alpha)`, but source printed p. 190 has `mod. (z-c)`;
  - current line 9155 has `\fra=\frp_1^{e_1}\cdots\frp_\rho^{e_\rho}`, but source printed p. 198 has the exponent/index pattern `\fra=\frp_1^{\rho_1}\cdots\frp_\sigma^{\rho_\sigma}`;
  - current line 9175 has `\calA\calN^\nu` with `\calB\calN^{\nu'}` and `(\nu\ne\nu')`, but source printed p. 200 has the exponent pair `\rho,\sigma` and condition `(\rho\ne\sigma)`.
- Checked and rejected Paper 14 false-positive traps around the Hilbert module-basis footnote, Verzweigungsideal/Diskriminante display, free-variable derivative display, Hensel `q_i=\frp_i^{\ell_i}`/terminating-series block, birational `g_1/g_2` setup, singular-point derivative quotient, adjoint quotient, `\psi=A f+B\varphi` display, and Restsatz ideal relations.
- Built `Noether_P14_Audit_Results_WebDrop_20260613.zip` as a 17 KB results-only package: CSV ledgers, source map, current-TeX excerpt, and checksums; no image/source-PDF payload.
- Reset Paper 13 source authority after the low-resolution warning: discarded the exploratory local-slice render/crops and used the GDZ original 1918 article witness, downloaded as full-resolution IIIF JPEGs for source pp. 235-257 / canvases 241-263.
- Confirmed Paper 13 front-matter discrepancy: the original article title page includes `(F. Klein zum fünfzigjährigen Doktorjubiläum.)` and `Von Emmy Noether in Göttingen.`, while the current cumulative uses a collected-work style title block. Logged as an editorial/source-critical decision rather than a mathematical defect.
- Confirmed Paper 13 source-fidelity differences: footnote 1 source spelling is `endgiltige`; the Lie footnote on source p. 236 includes `[zitiert "Grundlagen"]`, which is missing from the current cumulative.
- Confirmed Paper 13 derivative-index source-fidelity issue on source p. 245: source uses fixed index `x_\kappa` and summation index `\lambda`, while current line 8626 uses fixed `x_\lambda` and summation index `\nu`.
- Confirmed Paper 13 hard mathematical notation defect on source p. 250 / current lines 8764-8765: the Klein (30) formula is not source-faithful; source witness reads `\sum \mathfrak{R}_{\mu\nu}g_{\tau}^{\mu\nu}+2\sum(\partial g^{\mu\nu}\mathfrak{R}_{\mu\tau})/(\partial w^\sigma)=0`.
- Checked and rejected a Paper 13 false-positive trap on source p. 247: the initial system really has `u_i=v`, so current line 8713 should not be changed to `v_i`.
- Built `Noether_P13_GDZ_Source_Audit_WebDrop_20260613.zip` as a lean GDZ-source package: CSV ledgers, patch suggestions, source map/dimensions, seven labelled inspected high-resolution crops, provenance note, and checksums; no full raw page dump.
- Audited Paper 12 against the GDZ original 1918 article witness, source pp. 37-44 / canvases 41-48, after detecting a duplicate-label trap in the GDZ manifest: labels 37-44 also occur at canvases 531-538, but those are a different Gauss article and must not be used for Noether P12.
- Confirmed Paper 12 front-matter discrepancy: the original article has `Von Emmy Noether in Göttingen.` under the title, while the current cumulative uses a collected-work style title block. Logged as an editorial/source-critical decision rather than a mathematical defect.
- Confirmed Paper 12 source-fidelity issue at current line 7977: the initial source display has `f(x;dx)=...`, while current has `f(x,dx)=...`. Later source prose uses `f(x,dx)`, so this must not be applied globally.
- Confirmed Paper 12 notation defects at current lines 7994 and 8160: current has `ddx`, while source pp. 37 and 40 have `d\delta x`.
- Confirmed Paper 12 barred-delta defects at current lines 8144 and 8159: source p. 40 has `identisch in \bar{\delta}x`, while current has plain `\delta x`.
- Checked and rejected a Paper 12 false-positive trap: source p. 41 formula (9) really has plain `\delta x`, so the p. 40 barred-delta correction must not be propagated there. Formula (7)'s `d^{\sigma-1}\delta\chi` sequence also matches source.
- Built `Noether_P12_GDZ_Source_Audit_WebDrop_20260613.zip` as a lean GDZ-source package: CSV ledgers, patch suggestions, source map/dimensions, five labelled inspected high-resolution crops, provenance note, and checksums; no full raw page dump.

Next actions:
- Continue transforming recent RA correction rows into normalized machine-readable error-pattern rows.
- For any unresolved table/alignment candidates, provide page-level high-DPI witness crops rather than guesses.
- Continue second-auditor work in a non-overlapping lane as the web/pro session advances, prioritizing source-visible footnotes, tables/alignment, displayed formulas, and OCR false-positive traps.

## 2026-06-13 / P03 Source-Staging Gap Closed

Web note received: Paper 03 standalone original scan was not staged in its runtime, so it was skipped rather than falsely certified. Next sequential target reported there: Paper 06 p. 179 onward.

Resolved locally: staged the authoritative GDZ Paper 03 source package:
`Noether_P03_GDZ_Standalone_Source_WebDrop_20260613.zip`

Contents: GDZ article PDF for `Zur Invariantentheorie der Formen von n Variablen`, Jahresbericht DMV 19 (1910), pp. 101-104, plus four raw full-resolution IIIF page JPGs, each 3352 x 5277 px, source map CSV, manifest, and SHA256 ledger.

Authority details:
- GDZ PURL: `http://resolver.sub.uni-goettingen.de/purl?GDZPPN002122545`
- Volume manifest: `PPN37721857X_0019`
- Article range: `LOG_0012`
- Source pages/canvases: printed pp. 101-104 = canvases 00000109-00000112.

Caveat: printed p. 101 begins with tail matter from the previous article before Noether's title. This is not a defect; retain the full page as the source witness.

## 2026-06-13 / P06 Remaining Source Package Staged

Built source-only web drop for Paper 06 continuation:
`Noether_P06_GDZ_Remaining_Source_p173_196_WebDrop_20260613.zip`

## 2026-06-14 / P03 RA57 Source-Critical Fix Drop

Returned to Paper 05 first because the local RA42 audit had one open cumulative-integration row. Checked the newer RA47/RA56 base and found that the old Paper 05 RA42 title-footnote issue is already closed there: the current base has `{\Large\bfseries 5. Rationale Funktionenkörper\footnotemark}` plus `\footnotetext{Vortrag, gehalten auf der Naturforscherversammlung Wien 1913.}`. No new Paper 05 patch was made.

Audited newly staged Paper 03 against the GDZ standalone source package `Noether_P03_GDZ_Standalone_Source_WebDrop_20260613`. Source authority used: raw GDZ IIIF page JPGs for printed pp. 101-104, 3352 x 5277 px, native 600 ppi. Because the user rule forbids low-resolution source checking, the package includes labelled 1000 dpi inspection enlargements made from those raw 600 ppi images and explicitly records that they do not add optical detail.

Built new package:
`Noether_P03_RA57_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256:
`1D07BE9F2A337FF09A1EB5837C31892BC1E8111F955D8EE203505FFE7AEDEA0F`

Package size: 26,384,049 bytes. ZIP-open tested and copied to the Edge/intake drop folder.

Base TeX: `Noether_P09_P10_P11_RA56_SourceCritical_Fix_WebDrop_20260614/tex/cum_de_RA56_p09_p10_p11_sourcecritical_candidate_20260614.tex`.

Candidate TeX: `Noether_P03_RA57_SourceCritical_Fix_WebDrop_20260614/tex/cum_de_RA57_p03_sourcecritical_candidate_20260614.tex`.

Candidate PDF compiled successfully with `pdflatex` twice; PDF length 429 pages. Compile log scan found no fatal errors, emergency stops, undefined control sequences, or LaTeX errors.

Source-confirmed fixes applied:

- P03 printed p. 101 / GDZ canvas 00000109: source title reads `Zur Invariantentheorie der Formen von n Variabeln`; base TeX had `Variablen`. Changed title spelling to `Variabeln`.
- P03 printed p. 101 / GDZ canvas 00000109: source title block includes `Von Emmy Noether in Erlangen.`; base TeX omitted the author line. Inserted author line below title.
- P03 printed p. 103 / GDZ canvas 00000111: source formula (2) has `\rho=\sum_i\rho_i\le n`; base TeX had `<n`. Changed the formula line to `\le n`.

No-fix traps recorded:

- Printed p. 101 starts mid-page after the tail of the previous article; do not treat that upper material as missing Paper 03 text.
- Printed p. 102 symbolic product/faltung paragraph matches checked source at the inspected locus: `$s_x t_x u_\sigma u_\tau$`, `(stu)`, and `(\sigma\tau x)`.
- Printed p. 103 formula (1) matches checked source at the inspected locus; only formula (2)'s inequality was patched.
- Printed p. 104 is a shared page; Noether ends above the horizontal rule and the lower Faber article must not be pulled into Paper 03.

Reason: local RA44 says Paper 06 pp. 161-172 are checked and next target is p. 173 onward; web note says next sequential target is p. 179 onward. This package covers both ranges without asserting that pp. 173-178 are locally complete.

Authority source:
- Paper: Emmy Noether, `Körper und Systeme rationaler Funktionen`, Math. Ann. 76 (1915), S. 161-196.
- GDZ volume manifest: `PPN235181684_0076`.
- Article PDF range: `LOG_0016`.
- Included raw full-resolution IIIF JPG pages: printed pp. 173-196, each 2008 x 3248 px.

Quality rule: use the raw JPG pages as authority. Generate any later dense formula/matrix/alignment crops from these pages at 1000 dpi/equivalent high detail; do not use the old 2 MB pypdf convenience source as authority for exact symbol checking.

## 2026-06-13 / RA45 Located and Web Note Interpreted

After a deeper sweep, RA45 was located as a ZIP, not an extracted normal folder:
`N_SYM_RA45_P06_p173_178_20260613.zip`

RA45 workspace state says:
- Paper 06 pp. 161-178 checked.
- Next target: p.179 onward.
- Source insufficiency: Paper 03 standalone original unstaged in that runtime.

Resolution:
- Paper 03 source gap is covered by `Noether_P03_GDZ_Standalone_Source_WebDrop_20260613.zip`.
- Paper 06 p.179 onward source coverage is covered by `Noether_P06_GDZ_Remaining_Source_p173_196_WebDrop_20260613.zip` using GDZ raw IIIF pages. This package deliberately also includes pp.173-178 for local continuity, but RA45 itself reports those pages checked.

## 2026-06-14 / P11 GDZ Targeted Audit Drop

Built compact web-drag audit package:
`Noether_P11_GDZ_Source_Audit_WebDrop_20260614.zip`

Copied to Noether intake folder:
`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P11_GDZ_Source_Audit_WebDrop_20260614.zip`

SHA256:
`E2A1AD3388FB46C04E7C3CAA32666558E7D17E2FFD131E7AA4A841770CB2E358`

Authority source:
- Paper: Emmy Noether, `Gleichungen mit vorgeschriebener Gruppe`, Math. Ann. 78 (1918), S. 221-229.
- GDZ volume manifest: `PPN235181684_0078`.
- Article range: `LOG_0015`.
- Raw full-resolution IIIF JPG pages staged locally for printed pp. 221-229 / canvases 00000225-00000233.

Confirmed fixes against raw GDZ source:
- P11 source pp. 224-228 / active RA41 lines 7823, 7825, 7901, 7905, 7913, 7925, 7929, 7933, 7946: replace all 25 P11 occurrences of `\mathfrak L_\Gamma` with source-visible `\Omega_\Gamma`. This is a systematic notation drift in the active German block.
- P11 source p. 221 / active RA41 heading lines 7775-7781: source-visible front matter `Von / Emmy Noether in Göttingen.` is absent from the active block. Logged as a source-critical front-matter omission.
- P11 source p. 229 / active RA41 line 7954: final italic theorem paragraph has source `konstruieren; ihre Mannigfaltigkeit`, while active has `konstruieren: ihre Mannigfaltigkeit`.

No-fix traps recorded:
- Formula (11) on source p. 226 has plain `G_k(x)/H_k(x)`, not `G'_k(x)/H_k(x)`. The older 20260602 P11 audit note claimed a prime, but the raw GDZ crop contradicts it.
- The p. 228 Tschirnhaus footnote really has `y=x a_2/a_3` and repeats `a_2^3/a_3^2` in the adjacent displayed `y^{n-2}` and `y^{n-3}` coefficients; do not normalize this away.
- Source p. 227 spelling is `Tschirnhausentransformation`; active RA41 is correct there.
- Original p. 222 source says `Zahlkörper \Omega`; the later Ostrowski correction elsewhere in the corpus should be treated as an erratum/editorial note, not silently rewritten into the P11 source body.

Package contents: CSV ledgers, patch/readme note, source map/dimensions, GDZ article PDF + manifest provenance, five labelled high-detail crops derived from raw GDZ pages, SHA256 ledger. Zip expansion tested: 14 files. This is a targeted audit drop, not a page-by-page P11 certification.

## 2026-06-14 / P10 GDZ Targeted Audit Drop

Built compact web-drag audit package:
`Noether_P10_GDZ_Source_Audit_WebDrop_20260614.zip`

Copied to Noether intake folder:
`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P10_GDZ_Source_Audit_WebDrop_20260614.zip`

SHA256:
`F692224A0860459FBBEDCA6BBD87030CDF5DBDAAE82A8212F13C4F59442A6714`

Authority source:
- Paper: Emmy Noether, `Die Funktionalgleichungen der isomorphen Abbildung`, Math. Ann. 77 (1916), S. 536-545.
- GDZ volume manifest: `PPN235181684_0077`.
- Article range: `LOG_0057`.
- GDZ PURL: `http://resolver.sub.uni-goettingen.de/purl?GDZPPN002266598`.
- Raw IIIF pages staged locally for printed pp. 536-545 / canvases 00000554-00000563.

Confirmed fixes against raw GDZ source:
- P10 source p. 536 / active RA41 heading lines 7580-7583: source-visible front matter `Von / Emmy Noether in Göttingen.` is absent from the active block. Logged as a source-critical front-matter omission.
- P10 source p. 540 / active RA41 line 7628: definition (d) uses terminal index `k_\sigma`, not `k_\nu`, in both `z=\psi(...)` and `f(z)=\psi(...)`.
- P10 source p. 541 / active RA41 line 7663: divisibility display has `F(t;\vartheta_i)\cdot G(t;\vartheta_i)`, not `F(t;\vartheta)\cdot G(t;\vartheta_i)`.

No-fix traps recorded:
- P10 source p. 545 / active RA41 lines 7759-7761: raw source has `für jedes reelle x` and `f(x\cdot(1\pm ic))`, not `r`. The active `x` is source-correct; do not apply the older `r` note.
- P10 source p. 544 / active RA41 lines 7747 and 7757: source uses the paired sign `(Y∓y)`; active `\mp` is the right TeX encoding in context after `f(i)=\pm i`.
- Current P10 block has 16 `\footnote` tokens; the source-visible footnotes observed across pp. 536-545 are present at this targeted-audit level. This is not currently a missing-footnote lane.

Package contents: CSV ledgers, source map/dimensions, GDZ article PDF + manifest provenance, four labelled high-detail crops derived from raw GDZ pages, SHA256 ledger. This is a targeted audit drop, not a page-by-page P10 certification.

## 2026-06-14 / P9 GDZ Targeted Audit Drop

Built compact web-drag audit package:
`Noether_P09_GDZ_Source_Audit_WebDrop_20260614.zip`

Copied to Noether intake folder:
`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P09_GDZ_Source_Audit_WebDrop_20260614.zip`

SHA256:
`79F3108D42FFFC80A5A487785F624D137A415A8B7AE407B711CAB15600F083A6`

Authority source:
- Paper: Emmy Noether, `Die allgemeinsten Bereiche aus ganzen transzendenten Zahlen`, Math. Ann. 77 (1916), S. 103-128.
- GDZ volume manifest: `PPN235181684_0077`.
- Article range: `LOG_0014`.
- Raw IIIF pages staged locally for printed pp. 103-128 / canvases 00000109-00000134.
- Native GDZ images for this paper vary between 400ppi and 600ppi metadata; they are still the highest-detail institutional IIIF witnesses exposed by GDZ here. The evidence crops in the web-drop are labelled 1000dpi enlargements derived from those raw pages, with native dimensions recorded in provenance.

Confirmed fixes against raw GDZ source:
- P9 source p. 103 / active RA41 heading lines 6264-6267: source-visible front matter `Von / Emmy Noether in Erlangen.` is absent from the active block. Logged as a source-critical front-matter omission.
- P9 source p. 103 / active RA41 lines 6278-6279: first Zermelo footnote reads `Math. Ann. 75, S. 484 (1914)`, not `S. 434`.

No-fix traps recorded:
- P9 source p. 119 / active RA41 lines 7074-7076: source uses `z=\varphi(\xi_1\cdots \xi_t)`, so active `\xi_t` is correct. Do not change the last index to `h`.
- P9 source p. 125 / active RA41 lines 7425-7445: module subscripts around formulas (5)-(6) are multiplicative dimension subscripts, matching active `\mathfrak M_{\nu\kappa}`, `\mathfrak M_{\nu\kappa+1}`, and `\mathfrak M_{2\nu\kappa}`. Do not introduce comma-separated indices.

Package contents: CSV ledgers, source map/dimensions, GDZ article PDF + manifest provenance, five labelled high-detail crops derived from raw GDZ pages, SHA256 ledger. Zip expansion tested: 13 files. This is a targeted audit drop, not a page-by-page P9 certification.

## 2026-06-14 / Goal Addendum: Fix-Producing Mode

The Noether audit lane is now explicitly fix-producing, not only hint-producing. When source certainty is high, make reversible German LaTeX fixes in a candidate TeX or patch/diff, record every fix and its motivation in CSV plus this logbook, and provide updated TeX when useful. Each fix row must include source page, active TeX anchor, old/current state, replacement state, source rationale, confidence, and reversibility note. After the current non-overlap lane is exhausted, continue the same workflow across all remaining Noether papers, including prior web/pro work that is not yet page-by-page source-certified.

Hard source rule retained: no crop under 650dpi may be used to check source material; dense formulas, diagrams, matrices, and alignment-heavy evidence should use 1000dpi crops. When the institutional source images themselves are native 400/600ppi, use the raw institutional images as authority and label any 1000dpi crops as enlargements, not as new source detail.

## 2026-06-14 / P7/P8 GDZ Refined Fix Web-Drop

Built compact web-drag package:
`Noether_P07_P08_GDZ_Refined_Fix_WebDrop_20260614.zip`

Copied to Noether intake folder:
`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P07_P08_GDZ_Refined_Fix_WebDrop_20260614.zip`

SHA256:
`2D7D690127AF8D549148091923626DDFDD2211B054347D445C7FFEBEB60A476E`

Size and integrity:
- 18,992,841 bytes.
- 27 ZIP entries.
- ZIP-open tested.

Authority source:
- P07: Emmy Noether, `Der Endlichkeitssatz der Invarianten endlicher Gruppen`, Math. Ann. 77 (1916), S. 89-92.
- P08: Emmy Noether, `Über ganze rationale Darstellung der Invarianten eines Systems von beliebig vielen Grundformen`, Math. Ann. 77 (1916), S. 93-102.
- GDZ volume manifest: `PPN235181684_0077`.
- Source PDFs, IIIF manifests, and source map/dimensions CSVs included.

Candidate TeX:
`tex/cum_de_RA41_p07_p08_sourcecritical_candidate_20260614.tex`

Diff:
`tex/cum_de_RA41_to_p07_p08_sourcecritical_candidate_20260614.diff`

Compile check:
- `pdflatex -interaction=nonstopmode -halt-on-error` succeeded.
- Candidate PDF included: `tex/cum_de_RA41_p07_p08_sourcecritical_candidate_20260614.pdf`.
- Output PDF length: 430 pages.

Applied in candidate:
- P07 p89: restored printed source title/author block `Der Endlichkeitssatz... / Von / Emmy Noether in Erlangen.`
- P07 pp89-92: converted six ordinary numbered notes to source-visible symbolic note apparatus `*)` / `**)` via reversible macro `\NoetherSrcNote`.
- P08 p93: restored printed source title/author block `Über ganze rationale Darstellung... / Von / Emmy Noether in Erlangen.`
- P08 pp93-96: converted ordinary numbered notes to source-visible symbolic note apparatus.
- P08 p100: replaced the active paraphrase of the Omega footnote with a displayed source-style operator formula from the raw GDZ source.

Already-applied/currently verified P08 fixes carried in ledger:
- P08 p97: substitution formula has source-correct `(zy)x+(xz)y`.
- P08 p98: operator formula begins with source-correct `\partial/\partial\lambda`.
- P08 p100: Omega differential equation has restored middle equality and source `*)` marker.

Caveats:
- P08 p100 Omega footnote formula is a high-value repair but should receive one downstream exact-symbol micro-audit because the raw GDZ crop is difficult.
- P08 p96 display-attached note marker is source-style and compiled, but exact typographic placement may be polished later.
- The older P07/P08 20260613 drops remain useful historically but should not be used as current visual authority because they contain lower-resolution helper images. This refined package supersedes them for current web/pro handoff.

Package ledgers:
- `audit/p07_p08_refined_fix_ledger_20260614.csv` has 16 fix/status rows.
- `audit/p07_p08_no_fix_and_caveats_20260614.csv` has 4 no-fix/caveat rows.
- `audit/witness_crop_manifest_20260614.csv` has 12 targeted 1000dpi crop rows.
## 2026-06-14 - P06 pp. 191-196 RA48 tail apparatus repair

Base used: `N_SYM_RA47_P06_p185_190_20260614`, because RA47 was the newest web-session P06 cumulative and already checked pp. 161-190.

Package produced: `Noether_P06_p191_196_RA48_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `3E355DD26F579E3C00F31FA132E5861F00F3D5A503986F1149F99F609A97806F`

Scope: source pp. 191-196, the remaining P06 tail after RA47. Raw GDZ page images were used as source authority. Packaged crops are labelled 1000 dpi enlargements from native 400 ppi GDZ images.

Applied in candidate TeX:

- p191: converted display `(2)` to source-left-numbered style.
- p191: converted display `(3)` to source-left-numbered style and attached source `*)` note to the display.
- p191: converted the following theorem note to source `**)` apparatus.
- p193: converted source displays `(1)`, `(2)`, `(3)` to left-numbered source style.
- p194: converted source displays `(4)`, `(5)` to left-numbered source style.
- p195: converted Hilbert-extension note to source `*)` apparatus.

Candidate compile: `pdflatex -halt-on-error` succeeded, producing a 428-page PDF.

Caveat: this is a targeted tail-apparatus repair package, not a claim that every character on pp. 191-196 has been globally certified.

## 2026-06-14 - P12/P13 RA48 source-critical repair

Package produced: `Noether_P12_P13_GDZ_RA48_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `35BACC29B683124C4D3D86CB1FAEE819B5EB5006EC18F479CDC79E81B3EF9660`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA48_p12_p13_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF included in `build/`.

Applied in candidate TeX:

- P12 front matter: restored `Von Emmy Noether in Göttingen.`
- P12 p37: corrected initial defining display from `f(x,dx)` to source `f(x;dx)`.
- P12 p37/p40: corrected `d\delta x` and barred-delta identity occurrences confirmed by GDZ crops.
- P13 front matter: restored Klein dedication and author line.
- P13 p235: restored source spelling `endgiltige`.
- P13 p236: restored Lie citation bracket `[zitiert "Grundlagen"]`.
- P13 p245: corrected derivative display to fixed `x_\kappa` and summed `\lambda`.
- P13 p250: corrected dense Klein/Einstein formula (30).

No-fix traps recorded:

- P12 p41 formula (9) keeps plain `\delta x`.
- P13 p247 initial system keeps source `u_i=v`.

Notes: all source checking used the included 1000ppi GDZ labelled crops from the P12/P13 audit packages. This is a targeted repair drop, not a global P12/P13 certification.

## 2026-06-14 - P20 RA49 source-critical repair

Package produced: `Noether_P20_RA49_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `C2A6DDEA80A54972695F1C707C327FB24A94D18C1ED65DE86DEE6694301E7099`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA49_p20_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF included in `build/`.

Applied in candidate TeX:

- P20 source printed p31, formula (13): changed factor-sum indices from `\mu,\nu` to source `\kappa,\lambda`.

No-fix traps recorded:

- The following prose products `\varrho_\mu\sigma_\nu` remain unchanged, because the source separately uses `\mu,\nu` there for products occurring in `\zeta(u)`.
- P20 uses ordinary numbered footnotes; do not apply the P06-P08 symbolic-footnote pattern to this paper.

Notes: the dense formula witness was regenerated as a 1000dpi labelled crop from the local article PDF. The article PDF embeds native 360ppi page images; the crop is labelled as a 1000dpi enlargement from the best local source, not as new optical detail. The older 650dpi crop was not included in the RA49 package.

## 2026-06-14 - P19 RA50 source-critical repair

Package produced: `Noether_P19_RA50_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `BB49467AB7D67FEC6F5E1A19C97F9273153E891FC0FD19AD336DA0E99020583D`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA50_p19_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 428 pages and included in `build/`.

Applied in candidate TeX:

- P19 source printed p. 58/source PDF p. 35: restored source order after `Wegen`, reading `\ideal Q\eqzero{\ideal P}`, then `\ideal P^\rho\eqzero{\ideal Q}`.
- P19 source printed pp. 65-66/source PDF pp. 42-43: restored elementary-divisor exponent sequences to source `s_1...\s_\lambda` and `t_1...\t_\mu`, and restored the continuation inequality `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`.

No-fix traps recorded:

- P19 tail anchors printed pp. 59-66/source PDF pp. 36-43 are retained from the input audit as checked no-fix traps, except for the separately repaired C/D exponent sequence.

Notes: the three source witnesses were regenerated as 1000dpi labelled crops from the local P19 article PDF. The article PDF embeds native 360ppi page images; the crops are labelled as 1000dpi enlargements from the best local source, not as new optical detail. The older 650dpi audit crops are provenance only and were not used as the final authority for this package.

## 2026-06-14 - P18 RA51 source-critical repair

Package produced: `Noether_P18_RA51_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `C1236ED7F50F665419EE270001721642E4BE37D81123BEF8109AD3777B482911`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA51_p18_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 428 pages and included in `build/`.

Applied in candidate TeX:

- P18 source printed p. 101/source page from `p17c18` page 14: changed the resultant-form display endpoint from `R^{(n)}(x_n)=0(\mathfrak M)` to source `R^{(n)}(x_n)\equiv0(\mathfrak M)`.

No-fix traps recorded:

- P18 title/metadata/meeting heading and the surrounding primary-decomposition sentence are retained from the input audit as checked no-fix traps.
- The final factor remains `R^{(n)}(x_n)`, not `R^{(m)}(x_n)`; only the relation symbol was changed.

Notes: the source witness crops were regenerated at 1000dpi from the local P18 source page PDF. I checked the tempting GDZ volume page labelled printed p. 101 in `PPN37721857X_0030`; it is a different article and was not used.

## 2026-06-14 - P17 RA52 source-critical repair

Package produced: `Noether_P17_RA52_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `DAFC9C3F1585F928E0F86697EE6E901E7A971DA7E16F0D43EB4495C548929EF6`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA52_p17_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 428 pages and included in `build/`.

Applied in candidate TeX:

- P17 source printed p. 25/source PDF p. 25: restored source footnote 21 after the displayed equality ending `=r^{\sigma\rho}b_\rho`.
- P17 source printed p. 25/source PDF p. 25: restored source footnote 22 immediately after the `=a_\sigma` relation inside formula (39).

No-fix traps recorded:

- Formula (34) remains source-correct as `t_{ii}a_i=a_i`.
- Source footnote 20 after `Isomorphie` is already present.
- The finite rest-group basis example remains source-correct as `\xi_1^2, \xi_2^2`.
- Formula (40) assignment remains source-correct.

Notes: the p. 25 source witness was regenerated as a 1000dpi labelled crop from the P17 original source PDF, whose page images are native 600ppi. The old 650dpi crop was not included as final authority.

## 2026-06-14 - P16 RA53 source-critical repair

Package produced: `Noether_P16_RA53_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `E56EC9D5F48609C275C28EEA5B6016120B957EC634931DFB6451B8AF12B9D19E`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA53_p16_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 428 pages and included in `pdf/`.

Applied in candidate TeX:

- P16 source printed p. 30/source PDF p. 6: corrected the paragraph before formula (10) from `linear zusammensetzen aus $\Phi$ und aus Formen aus $M$` to the source reading `linear zusammensetzen aus $F$ und aus Formen aus $M$`.

No-fix traps recorded:

- Opening `\Omega`-Prozess is not OCR `2-Prozess`.
- Formula (2) remains `[identisch in x,y]`.
- Formula (3) remains `[identisch in \xi]`.
- Formula (9) retains `k_\lambda-\lambda+1=i`.
- Determinant notation in section 2 remains unstarred.
- The Berichtigungen block and acceptance date are already present.

Notes: the earlier P16 RA41 finding was source-confirmed but used 650dpi crops. RA53 promotes the fix into the RA47 base and regenerates the witness as a targeted 1000dpi labelled crop from the best local six-page source PDF. The source PDF embeds 360ppi page images, so the 1000dpi crop is an inspection enlargement, not additional optical detail.

## 2026-06-14 - P15 RA54 source-critical repair

Package produced: `Noether_P15_RA54_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `047DD6F4C8D18F5C94EFF671DA21FC453CBC99DEED992736F2B153124AD9275F`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA54_p15_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 428 pages and included in `pdf/`.

Applied in candidate TeX:

- P15 source printed p. 152/source PDF p. 15: changed the normalization index family from Greek `\chi_1,\ldots,\chi_{\rho+\sigma}` to source Latin `x_1,\ldots,x_{\rho+\sigma}`, including the associated `\xi_{x_*,*}` display and the following prose `zu festen x_1,x_2,\ldots`.
- P15 source printed p. 154/source PDF p. 17: corrected the J. Schur citation footnote from `Math. Ann. 71, S. 555 (1912)` to source `Math. Ann. 71, S. 355 (1912)`.

No-fix traps recorded:

- Printed p. 153 confirms `(n,n-1)\not\equiv0\pmod p`; do not swap the order.
- Printed p. 154 footnote 2 matrix apparatus is already represented adequately by the current `\frS` block matrix.
- Printed p. 152 Gordan-Kerschensteiner citation ending `S. 132` is already present.

Notes: the prior P15 RA41 targeted audit used 650dpi crops. RA54 promotes the fixes into the RA47 base and regenerates the two decisive witnesses as targeted 1000dpi labelled crops from the best local 19-page Göttingen source PDF. The source PDF embeds 360ppi page images, so the 1000dpi crops are inspection enlargements, not additional optical detail.

## 2026-06-14 - P14 RA55 source-critical repair

Package produced: `Noether_P14_RA55_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `D38A8AC2C72E020BB39DF320545A2A287C6583145E8975CAB7625A6736AB49EA`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA55_p14_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 428 pages and included in `pdf/`.

Applied in candidate TeX:

- P14 printed p. 190/source PDF p. 9: corrected the line-factorization sentence from `mod. (z-\alpha)` to source `mod. (z-c)`. Other nearby `z-\alpha` occurrences were left unchanged.
- P14 printed p. 198/source PDF p. 17: corrected the ideal factorization from `\frp_1^{e_1}\cdots\frp_\rho^{e_\rho}` to source `\frp_1^{\rho_1}\cdots\frp_\sigma^{\rho_\sigma}`.
- P14 printed p. 200/source PDF p. 19: corrected the polygon-class exponents from `\nu,\nu'` to source `\rho,\sigma`.

No-fix traps recorded:

- Hilbert module-basis footnote wording on p. 188.
- Discriminant/verzweigung displays on p. 189 and derivative display on p. 191.
- Hensel series and local expansion on p. 192.
- Birational setup on p. 193.
- Derivative/quotient material on pp. 195--196.
- Fundamental theorem `\psi=A f+B\varphi` on p. 197.
- Restsatz relation and footnote on p. 199.

Notes: the source cutout embeds 360ppi page images. The decisive witnesses were regenerated as targeted 1000dpi labelled crops from that best local source; these are inspection enlargements, not extra optical detail.

## 2026-06-14 - P09/P10/P11 RA56 source-critical repair

Package produced: `Noether_P09_P10_P11_RA56_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `7BAFF38484F7F73D12C3F457A9DB02F947AB162CADAF6C402D4055BB93441DB0`

Base used: `N_SYM_RA47_P06_p185_190_20260614`, the current RA47 cumulative German TeX.

Candidate TeX: `tex/cum_de_RA56_p09_p10_p11_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 429 pages and included in `pdf/`.

Applied in candidate TeX:

- P09 printed p. 103/GDZ canvas 00000109: restored source-visible author line `Von Emmy Noether in Erlangen.`
- P09 printed p. 103/GDZ canvas 00000109: corrected the first Zermelo footnote from `Math. Ann. 75, S. 434 (1914)` to source `Math. Ann. 75, S. 484 (1914)`.
- P10 printed p. 536/GDZ canvas 00000554: restored source-visible author line `Von Emmy Noether in Göttingen.`
- P10 printed p. 540/GDZ canvas 00000558: corrected definition (d) terminal index from `k_\nu` to source `k_\sigma` in both occurrences.
- P10 printed p. 541/GDZ canvas 00000559: corrected the divisibility display from `F(t;\vartheta)` to source `F(t;\vartheta_i)`.
- P11 printed p. 221/GDZ canvas 000225: restored source-visible author line `Von Emmy Noether in Göttingen.`
- P11 printed pp. 224--228/GDZ canvases 000228/000232: changed all 25 P11 occurrences of `\mathfrak L_\Gamma` to source `\Omega_\Gamma`.
- P11 printed p. 229/GDZ canvas 000233: corrected final theorem punctuation from `konstruieren: ihre Mannigfaltigkeit` to source `konstruieren; ihre Mannigfaltigkeit`.

No-fix traps recorded:

- P09: retain source `\xi_t` and multiplicative module subscripts such as `\nu\kappa`.
- P10: retain the final real `x` formula, rank-three `\pm/\mp` sign pairing, and existing footnote count.
- P11: retain plain `G_k(x)` in formula (11), source Tschirnhaus footnote wording, source spelling `Tschirnhausentransformation`, and do not silently fold the later erratum into the original P11 body.

Notes: all accepted fixes were checked visually against the 1000dpi evidence crops from the GDZ raw-source audit packages before promotion. P11 replacement count was recomputed against the current RA47-derived candidate: 25 replaced, 0 remaining.

## 2026-06-14 - P03 standalone source and RA57 source-critical repair

Standalone source package staged: `Noether_P03_GDZ_Standalone_Source_WebDrop_20260613.zip`

Standalone source SHA256: `F3606FF9B21DB15E4B666EE88E8C205EB0616DDC06767E9E84B64FFF9EA4935F`

Repair package produced: `Noether_P03_RA57_SourceCritical_Fix_WebDrop_20260614.zip`

Repair package SHA256: `1D07BE9F2A337FF09A1EB5837C31892BC1E8111F955D8EE203505FFE7AEDEA0F`

Base used: `cum_de_RA56_p09_p10_p11_sourcecritical_candidate_20260614.tex`.

Candidate TeX: `tex/cum_de_RA57_p03_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 429 pages and included in `pdf/`.

Applied in candidate TeX:

- P03 printed p. 101/GDZ canvas 00000109: corrected title spelling from `Variablen` to source `Variabeln`.
- P03 printed p. 101/GDZ canvas 00000109: restored source-visible author line `Von Emmy Noether in Erlangen.`
- P03 printed p. 103/GDZ canvas 00000111: corrected formula (2) from strict `< n` to source `\le n`.

No-fix/status notes:

- The stale RA42 Paper 05 missing Vienna title-footnote issue is already closed in the RA47/RA56 base; no Paper 05 patch was made here.
- Paper 03 was checked from the standalone GDZ cutout and raw IIIF page witnesses rather than a low-resolution derivative.

## 2026-06-14 - RA58 source-critical roll-up

Package produced: `Noether_RA58_SourceCritical_Rollup_WebDrop_20260614.zip`

SHA256: `B5CA4D9EEA7E6C3D5C643247E538CD97099EB2BF7D920B9FC89824CE228E546C`

Base used: `cum_de_RA57_p03_BASE.tex`, carrying the RA57 Paper 03 source-critical repairs.

Candidate TeX: `tex/cum_de_RA58_sourcecritical_rollup_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 430 pages and included in `pdf/`.

Roll-up scope:

- Consolidated the source-confirmed repair diffs for Papers 06, 07, 08, 12, 13, 14, 15, 16, 17, 18, 19, and 20.
- Preserved the Paper 03 and Papers 09--11 fixes already present in the RA57 base.
- Added reversible diffs: `audit/RA57_to_RA58_rollup.diff` and `audit/RA47_to_RA58_all_known_sourcecritical.diff`.
- Added machine-readable ledgers: `audit/ra58_rollup_applied_sources.csv`, `audit/ra58_rollup_validation_checks.csv`, and `audit/ra58_rollup_caveats.csv`.

Validation:

- All ten input diffs check-applied and applied cleanly.
- `pdfinfo` reported 430 pages.
- Compile logs had zero hits for fatal LaTeX patterns.
- Focused validation confirmed the Paper 03 repaired anchors were present and the known old-bad strings were absent.

Caveat:

- RA58 is a consolidation package, not a fresh page-by-page certification of the full Noether corpus. High-resolution source witnesses remain in the individual paper packages.

## 2026-06-14 - P21 RA59 source-critical repair

Package produced: `Noether_P21_RA59_SourceCritical_Fix_WebDrop_20260614.zip`

SHA256: `0AA7EBC7B61C47F2D3D0DFF516A743C5C06AF5F9B58D4815050B1C0A34F6F7DE`

Base used: `cum_de_RA58_sourcecritical_rollup_candidate_20260614.tex`.

Candidate TeX: `tex/cum_de_RA59_p21_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 430 pages and included in `pdf/`.

Applied in candidate TeX:

- P21 printed p. 405/source PDF p. 1: corrected the Riemann cross-reference from `Riemann\textsuperscript{72)}` to source `Riemann\textsuperscript{78)}`. Lipschitz remains `73)`.
- P21 printed p. 405/source PDF p. 1, footnote 150: corrected `Artikel IV, 1 11, p. 447` to source `Artikel IV, 1 II, p. 447`.
- P21 printed p. 406/source PDF p. 2, prose after formula (143): corrected `$h^{(1)}(dx,dx)$ stellt` to source `$h^{(1)}(dx,\delta x)$ stellt`.

No-fix traps recorded:

- Formulae (140)--(146), including the displayed (143), were checked visually. The displayed (143) itself did not need a patch; only the following prose did.
- The post-(146) sentence correctly uses `p(d,\delta)` and `p(\delta,\delta)`; do not copy the OCR's p(d,d)/p(d,d) drift.
- Formula (142) and the geodesic sentence keep `p^\nu(d,d)=0`.
- The final invariant-variation paragraph keeps the finite-parameter meaning: `G_\rho`, `\rho` independent divergences, `\rho` arbitrary functions, and `\sigma`-th derivative order.

Notes: source PDF `N_RA05_20260604/01_scan/p21.pdf` is a four-page local cutout of the Weitzenböck/Encyklopädie paper. `pdfimages -list` reports 360ppi embedded page images. The included 1000dpi crops are inspection enlargements from that source, not additional optical detail.

## 2026-06-14 - P23 RA60 source-critical repair

Package produced: `Noether_P23_RA60_SourceCritical_Fix_WebDrop_20260614.zip`

Base used: `cum_de_RA59_p21_sourcecritical_candidate_20260614.tex`.

Candidate TeX: `tex/cum_de_RA60_p23_sourcecritical_candidate_20260614.tex`

Candidate compile: `pdflatex` passed twice; candidate PDF is 430 pages and included in `pdf/`.

Applied in candidate TeX:

- P23 printed p. 183 / cumulative book p. 442: corrected the displayed expansion of `f(x,dx)`. RA59 reused `i` indices in the primed `y`-expansion and ended with `\varphi(y,dy)`. The source has primed coefficients with `j` indices and ends with `g(y,dy)`, so RA60 now reads `\sum a'_{j_1\ldots j_n}(y) dy_1^{j_1}\cdots dy_n^{j_n}=g(y,dy)`.

No-fix traps recorded:

- P23 printed pp. 177--182 and 184 were checked from 1000dpi inspection renders with no source-critical TeX patch.
- The local fraktur-style macros `\ma`, `\mo`, `\mJ`, `\mS`, and `\D` are style macros and were not treated as source defects.
- Historical compounded spellings such as `endlichvielen` and `irgendsolchen` were left untouched.
- Formula (4), formula (5), the `[\Omega_i]` block, footnotes 13--15, and the received date were checked after the display repair; no additional patch was made.

Notes: source PDF `N_RA05_20260604/01_scan/p23.pdf` is an eight-page local cutout of Jahresbericht DMV 32 (1923), pp. 177--184. `pdfimages -list` reports 360ppi embedded page images. The included 1000dpi crop is an inspection enlargement from that source, not additional optical detail.

## 2026-06-14 - P22 RA61 source-critical no-patch audit, pp. 53-60

Package produced: `Noether_P22_RA61_Pages53_60_SourceCritical_Audit_WebDrop_20260614.zip`

SHA256: `711BC8725FA9F5A1B664ACD333638AFE3AFB8CC41E4AA2FE6B9FF8DB23402C15`

Base used: `cum_de_RA60_p23_sourcecritical_candidate_20260614.tex`.

Scope audited: Paper 22, printed source pp. 53--60 / source PDF pages 1--8 / cumulative book pp. 409--416.

Result: no source-confirmed TeX patch was found in this first P22 tranche.

Checked anchors:

- p. 53: title, bibliographic line, theorem statement, `R_m` formula, and footnote 1.
- p. 54: second theorem paragraph, module interpretation, result factor/norm paragraph, and footnotes 2--4.
- p. 55: §1 opening, rank/determinant divisors/elementary divisors, formula (1), and Grundmodul heading.
- p. 56: Definition I, formulas (2)--(4), Satz I, proof, and footnote 6.
- p. 57: Definition II quotient, formulas (5)--(6), footnotes 7--8, and start of Satz III.
- p. 58: Satz III, formula (7), determinant setup, formula (8), and footnote 9.
- p. 59: proof after (8), determinant array, §2 opening, Definition III, and formula (9).
- p. 60: rest-class/norm paragraph, Satz IV, Satz V opening, formulas (10)--(11), footnote 10, and the `r_i/s_i` setup.

No-fix traps recorded:

- Local fraktur/module macros such as `\Amod`, `\Gmod`, `\Rmod`, `\Smod`, `\zero{...}`, and `\Norm(...)` are project style macros and should not be patched merely because the source print uses fraktur/module typography.
- The source PDF embeds 2048 x 3322 page images at 360ppi. Local 1000dpi renders were used as inspection enlargements only, not as additional optical source detail.
- Next sequential P22 audit target is printed p. 61 / source PDF page 9.

## 2026-06-14 RA62 - P22 source pp. 61-69 / book pp. 417-425

Created `Noether_P22_RA62_Pages61_69_SourceCritical_Fix_WebDrop_20260614`.

Base: RA60 German cumulative after P23 source-critical patch. Source: local P22 PDF from `N_RA05_20260604/01_scan/p22.pdf`, with 1000dpi inspection crops for dense math.

Confirmed fixes:
- Removed false non-source continuation heading before §4 on printed p64/book p420.
- Restored congruence signs in formulas (21) and (22) on printed p65/book p421.
- Restored source auxiliary `\mathfrak C_1` and zeta-family notation around formulas (23), (24), and (27), replacing incorrect collapsed `\Gmod_1`/`\xi` forms.
- Restored `\mathfrak C_{i-1}`/zeta in formula (28) and induction text.
- Extended the source check to printed p69/book p425 to verify the same auxiliary-module defect in formula (32), restoring `\mathfrak C_i` and the `x_i^\gamma\zeta_\nu` family.

Package includes patched TeX/PDF/TXT, source PDF and pp. 61-69 source slice, labelled 1000dpi evidence crops, CSV repair ledger, page disposition ledger, crop manifest, diff, source note, summary JSON, and SHA256 manifest.

## 2026-06-14 RA63 - P22 source pp. 70-79 / book pp. 426-435

Created `Noether_P22_RA63_Pages70_79_SourceCritical_Fix_WebDrop_20260614`.

Base: RA62 German cumulative after P22 pp. 61-69 source-critical patch. Source: local P22 PDF from `N_RA05_20260604/01_scan/p22.pdf`, rendered at 1000dpi for checked dense anchors.

Confirmed fixes:
- Printed p72/book p428: in Satz IX, restored `\mathfrak C_{i-1}` in `\Nmod_{i-1}=(\Nmod^*_{i-1},\mathfrak C_{i-1})`; current TeX had incorrectly repeated `\Gmod_{i-1}`.
- Printed p79/book p435: restored barred `\bar R^{(i)}(z,x)` in the closing specialization paragraph; current TeX had unbarred `R^{(i)}(z,x)`.

No-fix trap:
- Printed p70/book p426 footnote 15 has an odd final isomorphism phrase in the current TeX, but the available 1000dpi source crop did not justify a correction; left untouched for possible later independent witness comparison.

Package includes patched TeX/PDF/TXT, source PDF and pp. 70-79 source slice, two labelled 1000dpi evidence crops, CSV repair ledger, page disposition ledger, no-fix trap ledger, crop manifest, diff, source note, summary JSON, and SHA256 manifest.

## 2026-06-14 RA64 - P04 source-critical footnote repair / p152

Created `Noether_P04_RA64_SourceCritical_Fix_WebDrop_20260614`.

Base: RA63 German cumulative after P22 pp. 70-79 source-critical patch. Source: local P04 tail cutout `N_RA04_20260604/01_scan/p04b.pdf`, rendered at 1000dpi for the checked P04 tail anchors.

Confirmed fix:
- Paper 04 printed p152: restored the source-visible footnote attached to the `§ 9. Formenreihen. Reduktionssätze` heading. The source heading reads with a star marker and the footnote text reads: `Vgl. die entsprechenden Betrachtungen im ternären Gebiete. Diss. §§ 1--3.`

No-new-patch traps checked:
- Printed p148: formula (65) RHS entries are plain parenthesized products, not matrix-product pairs; RA63 already has the corrected form from RA41.
- Printed p149: the special case `n=2\lambda` reads `(S^{n/2}|T_{n/2})=(S^\lambda|T_\lambda)`; RA63 already has this.
- Printed p151: the prose pair reads `q_{n-\sigma-\lambda},p_{\tau-\lambda}`; RA63 already has this and no `i` substitution should be introduced.

Package includes patched TeX/PDF/TXT, source tail PDF, one full-page 1000dpi p152 render, labelled 1000dpi source crops, CSV fix/no-fix/witness ledgers, diff, summary JSON, compile logs, and SHA256 manifest.

## 2026-06-14 RA65 - P02 final German consolidation audit / no new patch

Created Noether_P02_RA65_FinalConsolidation_Audit_WebDrop_20260614.

Base: RA64 German cumulative after P04 source-critical footnote repair.

Result: no new source-confirmed TeX patch.

Closed suspicion:
- Paper 02 body, printed p66 / § 14. Formen neunter Ordnung (System III): the remaining L_j^2 in the irreducible-form display was checked against the labelled 1000dpi source slice. The source visibly prints C) L_j on the first display row and L_j^2 on the second. This is a source-faithful body occurrence and must not be changed by analogy with the separate Table I row-10 correction.

Consolidation checks recorded:
- P02 equation-tag inventory: 39 \tag{...} anchors across the P02 block.
- Environment balance: align, align*, equation, tabular, array, landscape, and adjustbox begin/end counts balance inside P02.
- Table propagation checks: RA31/RA34 old bad patterns are absent or restricted to source-valid contexts; the KH^3u family remains only where earlier 1000dpi table/body checks validated it.
- RA28 nu/v rebase check: bad Latin-v form-grammar patterns remain absent; protected polar/variable Latin-v contexts were retained.

Package includes CSV ledgers, a method note, witness manifest, and one exact 1000dpi source slice. No TeX/PDF is included because there was no patch.

## 2026-06-14 RA66 - P08 p100 Omega-note exact-symbol micro-audit

Package: `Noether_P08_RA66_P100_Omega_MicroAudit_WebDrop_20260614.zip`

Scope: Paper 08, printed p. 100, Omega-note source footnote formula, following up the P07/P08 refined package's `medium_high` caveat for `P08_FIX_004`.

Source authority: raw-GDZ P08 p100 1000dpi inspection crop from `Noether_P07_P08_GDZ_Refined_Fix_WebDrop_20260614`, split into left/middle/right 1000dpi source windows. No OCR used as authority; no sub-650dpi crops used.

Result: no new TeX patch. The RA64 current TeX lines 6165-6179 represent the source formula. The apparent extra right-edge material resolves in the 1000dpi middle/right slices as the continuation and closing of the existing `[z(...)]^{p-1}` bracket followed by `g(\lambda;\xi,\eta)`, not as a separate missing factor.

Machine ledgers: `audit/p08_RA66_p100_omega_microaudit.csv`, `audit/p08_RA66_no_new_patch_traps.csv`, `audit/source_witness_manifest_RA66.csv`.

Reversibility / trap: do not add a second post-`z(...)^{p-1}` bracket factor at this locus unless a higher-quality independent witness contradicts the GDZ crop.

## 2026-06-14 RA67 - P06 source-marker wrapper repair / printed pp. 161, 164, 165

Package: `Noether_P06_RA67_SourceMarker_Fix_WebDrop_20260614.zip`

Base: RA64 German cumulative after P04 source-critical footnote repair. Scope: Paper 06 opening source-apparatus fidelity only.

Confirmed fixes:
- Printed p161: converted two ordinary `\footnote{...}` wrappers to source-symbol wrappers `\srcfn{*)}{...}` and `\srcfn{**)}{...}`.
- Printed p164: converted three ordinary `\footnote{...}` wrappers to `\srcfn{*)}{...}`, `\srcfn{**)}{...}`, and `\srcfn{***)}{...}`.
- Printed p165: converted one ordinary `\footnote{...}` wrapper to `\srcfn{*)}{...}`.

No prose or mathematical content was changed. This repair only restores the source's page-local star-note apparatus so the cumulative TeX follows the printed note structure.

Source authority: local GDZ article PDF `P06_GDZ_article_LOG_0016_pp161_196.pdf`, rendered at 1000dpi inspection scale for printed pp. 161, 164, and 165. No OCR used as authority; no sub-650dpi crops used.

Build status: XeLaTeX compile succeeded. Output PDF: 432 pages.

## 2026-06-14 RA71 - P29 source header and footnote counter repair

Package: `Noether_P29_RA71_SourceHeader_FootnoteCounter_WebDrop_20260614.zip`

Base: RA70 German cumulative after P25 source-header repair. Scope: Paper 29, `Der Endlichkeitssatz der Invarianten endlicher linearer Gruppen der Charakteristik p`, `Nachr. v. d. Ges. d. Wiss. zu Göttingen` 1926, S. 28--35.

Confirmed fix:
- Restored the source author line `Von Emmy Noether in Göttingen.` at the P29 opening.
- Centered the Courant submission line with the source header block.
- Inserted `\setcounter{footnote}{0}` at P29 opening so source footnotes begin at 1.

No mathematical/body prose content was changed.

Source authority: GDZ `PPN252457811_1926`, printed pp. 28--35, canvases 32--39. The package includes the IIIF manifest, page/canvas map, raw full-page JPGs, an assembled convenience PDF, and labelled 1200dpi inspection crops for printed p28 header and footnote block. The old local `p29.pdf` is complete but lower/equivalent 360ppi and was treated only as a locator/comparator.

Build status: XeLaTeX compile succeeded. Output PDF: 432 pages. Rendered text confirms the P29 author line and first P29 footnote as `1`.

## 2026-06-14 RA72 - P30 source header and footnote counter repair

Package: `Noether_P30_RA72_SourceHeader_FootnoteCounter_WebDrop_20260614.zip`

Base: RA71 German cumulative after P29 source-header and footnote-counter repair. Scope: Paper 30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, Math. Ann. 96 (1927), S. 26--61.

Confirmed fix:
- Restored the source author block `Von` / `Emmy Noether in Göttingen.` at the P30 opening.
- Inserted `\setcounter{footnote}{0}` at P30 opening so source footnotes begin at 1.

No mathematical/body prose content was changed.

Source authority: GDZ `PPN235181684_0096`, article range `LOG_0005`, printed pp. 26--61, canvases 30--65. The package includes the official GDZ article PDF, IIIF manifest, page/canvas map, raw full-page printed p26 JPG, and labelled 1200dpi inspection crops for printed p26 source header and first footnote. The old local `p30.pdf` is complete but a lower/equivalent 360ppi collected/reprint-style cutout and was treated only as a locator/comparator.

Build status: XeLaTeX compile succeeded. Output PDF: 432 pages. Rendered text confirms the P30 author block and first P30 footnote as `1`.

Package includes updated TeX/PDF, full TeX diff, source-marker fix ledger CSV, remaining ordinary-footnote closure CSV for the P06 block, source witness manifest, 1000dpi full-page evidence images, method note, README, and SHA256 manifest.

## 2026-06-14 RA68 - P08 p096 source-marker placement repair

Package: `Noether_P08_RA68_P096_SourceMarker_Placement_WebDrop_20260614.zip`

Base: RA67 German cumulative after P06 source-marker wrapper repair. Scope: Paper 08 printed p096, closing the earlier `P08_CAVEAT_001` typographic/source-apparatus caveat.

Confirmed fix:
- Printed p096: moved the source `*)` marker from a generic post-display `\NoetherSrcNote{*)}{...}` form to explicit formula-side `\srcfnmark{*)}` plus matching `\srcfntext{*)}{...}`. This matches the source crop, where the marker is attached to the displayed formula and repeated before the explanatory note.

No prose or mathematical content was changed.

Source authority: raw-GDZ-derived 1000dpi source crop `P08_p096_operator_definition_star_note_rawGDZ_1000dpi.png` from the refined P07/P08 package. No OCR used as authority; no sub-650dpi crops used.

Build status: XeLaTeX compile succeeded. Package includes updated TeX/PDF, full diff against RA67, fix ledger CSV, residual caveat disposition CSV, source witness manifest, method note, README, and SHA256 manifest.

## 2026-06-14 RA69 - P24 source footnote counter reset

Package: `Noether_P24_RA69_FootnoteCounter_SourceCritical_WebDrop_20260614.zip`

Base: RA68 German cumulative after P08 p096 source-marker placement repair. Scope: Paper 24, `Eliminationstheorie und allgemeine Idealtheorie`, Math. Ann. 90 (1923), S. 229--261.

Confirmed fix:
- Inserted `\setcounter{footnote}{0}` immediately before the P24 section heading. The source article begins printed footnotes at `1)`, `2)`, `3)` on printed p229, while the cumulative TeX previously entered P24 without a footnote reset and therefore inherited earlier paper numbering.

No prose or mathematical content was changed.

Source authority: GDZ article PDF `LOG_0025` from Mathematische Annalen 90. Article PDF page 1 is a GDZ cover/terms page; PDF page 2 is printed p229, so `source_pdf_page = printed_page - 227`. The package includes the source PDF, GDZ canvas map, raw fullres inventory, and a 1000dpi inspection render of printed p229.

Local reconciliation note: the current RA68 P24 section and `Noether_Paper24_German_FINAL_AUDITED_slice.tex` differ only by a UTF-8 BOM, so no hidden local P24 TeX fix was waiting to merge.

Build status: XeLaTeX compile succeeded. Output PDF: 432 pages.

## 2026-06-14 RA70 - P25 source header and footnote placement repair

Package: `Noether_P25_RA70_SourceHeader_FootnotePlacement_WebDrop_20260614.zip`

Base: RA69 German cumulative after P24 footnote counter reset. Scope: Paper 25, `Eliminationstheorie und Idealtheorie`, J. Ber. d. DMV 33 (1924), S. 116--120.

Confirmed fix:
- Restored the source subtitle/occasion line `Vortrag, gehalten in Marburg am 25. September 1923.` and source author line `Von Emmy Noether in Göttingen.`
- Moved the existing footnote text from the first body sentence to the source subtitle marker, where the scan has printed marker `1)`.
- Inserted `\setcounter{footnote}{0}` at P25 opening so the source marker begins at 1.

No mathematical/body prose content was changed.

Source authority: GDZ JDMV 33 article PDF `LOG_0016`, printed pp. 116--120. Article PDF page 1 is a GDZ cover/terms page; PDF page 2 is printed p116, so `source_pdf_page = printed_page - 114`. The package includes the source PDF, structure/canvas maps, raw fullres inventory, and a 1000dpi inspection render of printed p116.

Source-map caveat closed: full-volume canvas labels contain duplicate pages 116--120; the manifest structure range for Noether's article anchors the correct canvases 125--129.

Build status: XeLaTeX compile succeeded. Output PDF: 432 pages.
## 2026-06-14 - RA73 / Paper 31 source-header and footnote-counter repair

- Base: RA72 cumulative TeX after the P30 source-header/footnote-counter repair.
- Source authority: GDZ `PPN243919689_0157`, Journal fuer die reine und angewandte Mathematik 157 (1927), printed pp. 82--104.
- Source page used for the patch: printed p. 82, GDZ canvas `00000090`, raw image 3896 x 5939.
- Confirmed issue: RA72 started P31 without the source author line `Von Emmy Noether in Göttingen.`
- Confirmed issue: RA72 had no `\setcounter{footnote}{0}` before P31; the source article first footnote is numbered `1)`.
- Fix applied in RA73: inserted `\setcounter{footnote}{0}` immediately before P31 and restored `Von \emph{Emmy Noether} in Göttingen.` in the heading block.
- No P31 mathematical body text was changed in this pass.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; rendered PDF text confirms the restored author line and first P31 footnote 1.
- Deliverable: `Noether_P31_RA73_SourceHeader_FootnoteCounter_WebDrop_20260614.zip`.

## 2026-06-14 - RA74 / Paper 32 source author block and article boundary repair

- Base: RA73 cumulative TeX after the P31 source-header/footnote-counter repair.
- Source authority: Internet Archive item `sitzungsberichte-der-preussischen-akademie-der-wissenschaften-1927`, extracted JP2 leaves for printed pp. 221--228.
- Source page used for the patch: printed p. 221, IA leaf 0382, JP2-derived full-page image 4001 x 5988.
- Confirmed issue: RA73 had only the corpus-style joint-author title and Schur presentation note for P32, omitting the source author block for Richard Brauer and Emmy Noether.
- Confirmed issue: RA73 started P32 on the same rendered page as the tail of P31, mixing P31 footnote 28 with P32 footnote 1 on one rendered page.
- Fix applied in RA74: inserted `\clearpage` before P32 and restored the source author block:
  `Von Privatdozent Dr. Richard Brauer / in Königsberg / und Prof. Dr. Emmy Noether / in Göttingen.`
- The existing P32 `\setcounter{footnote}{0}` was retained and not duplicated.
- No P32 mathematical body text was changed in this pass.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; rendered PDF text and 650 dpi rendered page confirm P32 starts cleanly with the restored author block.
- Deliverable: `Noether_P32_RA74_SourceAuthorBlock_WebDrop_20260614.zip`.

## 2026-06-14 - RA75 / Paper 33 Bologna source-text repair

- Base: RA74 cumulative TeX after the P32 source author block and article boundary repair.
- Source authority: Internet Archive item `attidelcongresso0002nico`, `Atti del Congresso Internazionale dei Matematici`, Bologna, vol. 2, printed pp. 71--73.
- Source mapping: IA scandata maps printed pp. 71--73 to leaves 0079--0081. The full original JP2 tar was downloaded to the local source-master folder and only those leaves were extracted for the handoff.
- Confirmed issue: RA74 P33 began with the later Math. Z. introduction (`Die wichtigsten allgemeinen Sätze...`) instead of the Bologna talk opening (`Ich möchte Ihnen zeigen...`).
- Confirmed issue: RA74 P33 lacked a clean article boundary, local footnote reset, and the Bologna source author/title block with title footnote.
- Fix applied in RA75: inserted `\clearpage` and `\setcounter{footnote}{0}` before P33, restored `Emmy Noether (Göttingen -- Germania)`, restored the source title block, and replaced the P33 body with the verified Bologna pp. 71--73 text.
- Matrix handling: retained editable TeX matrices and adjusted the first matrix to match the source lower-triangular blank-entry shape. No figures, tables, or diagrams occur in this three-page paper beyond the two matrix displays.
- Render handling: literal guillemets in the new P33 block rendered as wrong glyphs in this TeX setup, so the new P33 guillemets were switched to `\guillemotleft`/`\guillemotright`.
- Evidence included: raw IA original JP2 leaf extracts, JP2-derived JPGs, source PDF assembled from those pages, full IA volume PDF as secondary witness, 650 dpi rendered QA pages, and labelled high-detail crops for the title/footnotes and matrix regions.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 433 pages.
- Deliverable: `Noether_P33_RA75_Bologna_SourceText_WebDrop_20260614.zip`.

## 2026-06-14 - Paper 34 GDZ source-witness acquisition

- Deliverable: `Noether_P34_GDZ_SourceWitness_WebDrop_20260614.zip`.
- Scope: Paper 34, `Hyperkomplexe Größen und Darstellungstheorie`, Math. Z. 30 (1929), printed pp. 641--692.
- Live source found through EuDML doc 168145, whose full-text link points to GDZ volume `PPN266833020_0030`.
- Downloaded GDZ IIIF full-page images for printed pp. 641--692, canvas leaves `00000645` through `00000696`, plus the GDZ IIIF manifest and a printed-page/canvas map.
- Source quality finding: GDZ full-page source images are 400 ppi, around 2080--2208 px by 3312--3344 px. The local p34a/p34b/p34c slices embed only 360 ppi images and their OCR/Markdown layer contains visible corruption.
- Method caveat: this package is source acquisition, not mathematical certification. Because the strongest true image witness found so far is below the 650 dpi crop-check rule, it must not be used alone to certify dense matrices, tables, or formula microgeometry. Prefer a higher-resolution Springer/institutional witness if one becomes available.
- No TeX body changes were made in this pass.
- Structural audit note: RA75 currently contains P34 in three repeated section blocks, and the section inventory also shows later duplicate P40--P43 blocks. These are audit targets, not automatic edits.

## 2026-06-14 - RA76 / P40--P43 duplicate cumulative-run repair

- Package: `Noether_RA76_StructuralDuplicateFix_P40_P43_WebDrop_20260614.zip`.
- Base: RA75 cumulative TeX after the P33 Bologna source-text repair.
- Confirmed issue: RA75 contained two full P40--P43 runs. The later run was marked by RA10 appended-body comments and carried the scan-visible apparatus after Paper 43.
- Pairwise duplicate audit:
  - P41: identical across both runs.
  - P40: body-equivalent; differences were stranded macro/comment material.
  - P42: body-equivalent; difference was an RA10 appended-body comment.
  - P43: body-equivalent but the later RA10 run includes the scan-visible apparatus appendix.
- Fix applied in RA76: removed the first duplicate P40--P43 run and retained the later RA10 P40--P43 run plus apparatus.
- Macro handling: moved macro support formerly stranded in the deleted duplicate run into the support area before `\begin{document}`.
- Render handling: converted Unicode German quotes, guillemets, and em dashes to TeX-safe forms after XeLaTeX reported missing glyphs.
- Source-image status: no source-image or OCR evidence was used to alter mathematical content. This was an internal cumulative-structure repair.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 398 pages; log audit found zero missing characters, undefined controls, LaTeX errors, emergency/fatal stops, overfull boxes, or underfull boxes.
- Deliverable includes updated TeX/PDF/TXT, full RA75-to-RA76 diff, duplicate-span diff ledgers, section inventories, fix CSV, method note, README, and SHA256 manifest.

## 2026-06-14 - RA77 / Paper 17 footnote-continuity and display-footnote rendering repair

- Package: `Noether_RA77_P17_FootnoteContinuity_WebDrop_20260614.zip`.
- Base: RA76 cumulative TeX after the P40--P43 duplicate cumulative-run repair.
- Source authority carried forward from the accepted RA52 P17 source-critical package: Emmy Noether and W. Schmeidler, `Moduln in nichtkommutativen Bereichen, insbesondere aus Differential- und Differenzenausdrücken`, Math. Zs. 8 (1920), pp. 1--35.
- Included source/witness files: original P17 source PDF, source p. 25 PDF, and the RA52 1000dpi witness crop for printed p. 25 formula (39) footnotes 21/22.
- Confirmed issue: the first P17 section header in RA76 omitted `Differential- und` from the source title.
- Confirmed issue: P17 was split into two artificial production blocks. The second block reset the footnote counter to 0 before §5, even though twelve source footnotes had already occurred before the split. This made the first §5 continuation note render as 1 instead of 13.
- Confirmed issue: RA76 rendered the source footnote marker after formula (39), `r^{\sigma\rho}r_{\rho\sigma}a_\sigma=a_\sigma`, as 25, while the accepted P17 source witness and RA52 audit identify it as source footnote 22. The display-math `\footnotemark` was being handled unsafely.
- Fix applied in RA77: corrected the first P17 title to the full source title, replaced the duplicate artificial second `\section*{17...}` with a continuation note, set the §5 continuation counter to 12, made the two display footnote anchors explicit as `\footnotemark[21]`/`\footnotetext[21]` and `\footnotemark[22]`/`\footnotetext[22]`, then normalized the counter to 22 after the second source note.
- Render verification: the first §5 continuation footnote now renders as 13; the formula witness markers render as 21 and 22 rather than 21 and 25.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 398 pages; log audit found zero missing characters, undefined controls, LaTeX errors, emergency/fatal stops, overfull boxes, underfull boxes, multiply-defined warnings, or rerun warnings.
- Scope caveat: this is a targeted P17 counter/rendering repair, not a full page-by-page recertification of Paper 17. P34 continuation blocks remain logged but unchanged because the current best local P34 source witness is 400ppi and should not be used for dense-math certification under the current 650/1000dpi rule.

## 2026-06-14 - RA78 / Papers 14--16 article-boundary footnote reset repair

- Package: `Noether_RA78_P14_P15_P16_FootnoteResets_WebDrop_20260614.zip`.
- Base: RA77 cumulative TeX after the P17 footnote-continuity repair.
- Confirmed issue: Paper 14 began without a local footnote reset; its first visible source notes rendered as 188, 189, 190.
- Confirmed issue: Paper 15 had an article boundary and `\clearpage` but no local footnote reset; its first source note rendered as 240.
- Confirmed issue: Paper 16 began without a local footnote reset; its first source notes rendered as 251, 252, 253.
- Fix applied in RA78: inserted `\clearpage` plus `\setcounter{footnote}{0}` before Paper 14, inserted `\setcounter{footnote}{0}` after the existing `\clearpage` before Paper 15, and inserted `\clearpage` plus `\setcounter{footnote}{0}` before Paper 16.
- No mathematical formula, prose, table, or diagram content was changed.
- Render verification: Paper 14 opening notes now render as 1 and 2; Paper 15 first note renders as 1; Paper 16 first note renders as 1.
- Included source/provenance files: P14 JDMV 1919 pp. 182--203 source cutout, P15 Göttingen 1919 pp. 138--156 source cutout, and P16 Math. Ann. 81 pp. 25--30 source cutout.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 398 pages; log audit found zero missing characters, undefined controls, LaTeX errors, emergency/fatal stops, overfull boxes, underfull boxes, multiply-defined warnings, or rerun warnings.
- Scope caveat: this is a structural article-boundary/counter repair. The included source cutouts are carried forward from earlier source-critical packages and are not used here for dense-math certification.

## 2026-06-14 - RA79 / Papers 9--13 article-boundary footnote reset repair

- Package: `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614.zip`.
- Base: RA78 cumulative TeX after the Paper 14--16 footnote reset repair.
- Confirmed issue: Paper 9 began with the inherited cumulative footnote counter; its first visible source notes rendered as 87, 88, 89, 90.
- Confirmed issue: Paper 10 began with the inherited cumulative footnote counter; its first source note rendered as 129.
- Confirmed issue: Paper 11 began with the inherited cumulative footnote counter; its first source note rendered as 145.
- Confirmed issue: Paper 12 began with the inherited cumulative footnote counter; its first display source note rendered as 160.
- Confirmed issue: Paper 13 began with the inherited cumulative footnote counter; its first source notes rendered as 163 and 164. Paper 13 also lacked an explicit new-paper page break after Paper 12.
- Fix applied in RA79: inserted `\setcounter{footnote}{0}` after the existing `\clearpage` before Papers 9, 10, 11, and 12; inserted `\clearpage` plus `\setcounter{footnote}{0}` before Paper 13.
- No mathematical formula, prose, table, diagram, or bibliography text was changed.
- Render verification: Paper 9 now starts at note 1; Paper 10 starts at note 1; Paper 11 starts at note 1; Paper 12 starts at note 1 and then note 2; Paper 13 starts at note 1 and then note 2.
- Included source/provenance files: P09/P10/P11 GDZ article PDFs; P09--P13 full-resolution GDZ IIIF JPEG page sets; GDZ manifests, canvas maps, and source image dimension ledgers; prior RA56/RA48 source-critical fix ledgers.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 399 pages; log audit found zero missing characters, undefined controls, LaTeX errors, emergency/fatal stops, overfull boxes, underfull boxes, multiply-defined warnings, or rerun warnings.
- Scope caveat: this is a structural article-boundary/counter repair. Included full-resolution source images support source provenance, but no new dense-math certification is claimed in this pass.

## 2026-06-14 - RA80 / Papers 2--5 article-boundary footnote reset repair

- Package: `Noether_RA80_P02_P05_FootnoteResets_WebDrop_20260614.zip`.
- Base: RA79 cumulative TeX after the Paper 9--13 footnote reset repair.
- Confirmed issue: Paper 2 began with the inherited cumulative footnote counter; its title/source note rendered as 7 and the next opening source note rendered as 8.
- Confirmed issue: Paper 3 began with the inherited cumulative footnote counter; its title/source note rendered as 32.
- Confirmed issue: Paper 4 began with the inherited cumulative footnote counter; its opening source notes continued the prior-paper numbering.
- Confirmed issue: Paper 5 began with the inherited cumulative footnote counter; its title/source note rendered as 82 and the next Steinitz note rendered as 83.
- Fix applied in RA80: inserted `\setcounter{footnote}{0}` at the article boundaries before Papers 2, 3, 4, and 5.
- No mathematical formula, prose, table, diagram, or bibliography text was changed.
- Render verification: Paper 2 now starts at note 1; Paper 3 starts at note 1; Paper 4 starts at note 1 and then proceeds locally; Paper 5 starts at note 1 and then note 2.
- Included source/provenance files: P02 source PDF and source ledger; P03 GDZ article PDF plus full-resolution GDZ page JPEGs; P04 prior source slices plus RA64 provenance note; P05 RA42 source PDF and witness ledgers.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 399 pages; log audit found no fatal errors, undefined controls, rerun warnings, overfull boxes, underfull boxes, or duplicate-anchor warnings in the checked patterns.
- Scope caveat: this is a structural article-boundary/counter repair. It does not certify source marker style for early title notes, and it does not recertify dense math in Papers 2--5.

## 2026-06-14 - RA81 / Paper 38 article-boundary footnote reset repair

- Package: `Noether_RA81_P38_FootnoteReset_WebDrop_20260614.zip`.
- Base: RA80 cumulative TeX after the Papers 2--5 footnote reset repair.
- Confirmed issue: Paper 38, `Gemeinsam mit R. Brauer und H. Hasse: Beweis eines Hauptsatzes in der Theorie der Algebren`, is a separate JRAM article but inherited Paper 37's footnote counter. Its opening source note pair rendered as 13 and 14 in RA80.
- Source acquired for this pass: GDZ/JRAM 167 IIIF manifest plus raw GDZ full-page images for printed pp. 399--404, canvas IDs 00000404--00000409.
- Source quality caveat: the retrieved GDZ images report 600 ppi. They are the best local source witness found in this pass but are below the current 650/1000 dpi dense-check rule, so no dense-math certification is claimed.
- Fix applied in RA81: inserted `\setcounter{footnote}{0}` after the P37 clearpage and before the Paper 38 article heading.
- No mathematical formula, prose, table, diagram, or bibliography text was changed.
- Render verification: Paper 38 now opens with source notes 1 and 2; the next Hasse source note renders as 3.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 399 pages; log audit found no fatal errors, undefined controls, rerun warnings, overfull boxes, underfull boxes, multiply-defined warnings, or missing-character warnings in the checked patterns.
- Follow-up queue: Papers 39--42 still need separate article-boundary counter audit. They were not patched in this package.

## 2026-06-14 - RA82 / Papers 39--42 article-boundary footnote reset repair

- Package: `Noether_RA82_P39_P42_FootnoteResets_WebDrop_20260614.zip`.
- Base: RA81 cumulative TeX after the Paper 38 article-boundary footnote reset repair.
- Confirmed issue: Papers 39, 40, 41, and 42 are separate publications but inherited the cumulative footnote counter in RA81.
- Fix applied in RA82: inserted `\setcounter{footnote}{0}` immediately before the section headings for Papers 39, 40, 41, and 42.
- No mathematical formula, prose, table, diagram, or bibliography text was changed.
- No-fix trap recorded: Paper 43 was checked as the next boundary, but the current German P43 body has zero `\footnote{}` calls, so no visible counter defect exists there in the present TeX.
- Source acquired for this pass: official MathUnion ICM 1932 full-volume PDF and six-page P39 cutout; P40 GDZ IIIF manifest, canvas map, and raw full-page JPEGs for printed pp. 514--541; P41 GDZ article PDF plus GDZ IIIF manifest, canvas map, and raw full-page JPEGs for printed pp. 411--419; local RA10 P42 cutout; local RA10 P43 no-fix reference cutout.
- Source quality caveat: P40/P41 GDZ images report 400 ppi, and the P42 local cutout is below the current 650/1000 dpi dense-source-check rule. These witnesses were used only for article-boundary and local-footnote-sequence evidence, not for dense math/prose/table certification.
- Render verification: P41 now opens with visible note 1, and P42 opens with visible notes 1 and 2. P39 rendered body markers begin locally at 1/2/3. P40 reset is immediately before the P40 section, and the first P40 `\footnote{}` occurs inside that reset section.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 399 pages.

## 2026-06-14 - RA83 / Paper 23 article-boundary footnote reset repair

- Package: `Noether_RA83_P23_FootnoteReset_WebDrop_20260614.zip`.
- Base: RA82 cumulative TeX after the Papers 39--42 article-boundary reset repair.
- Confirmed issue: Paper 23, `Algebraische und Differentialvarianten`, is a separate J. Ber. d. DMV article, and its source cutout starts article footnotes at `1)`. RA82 rendered the first P23 note as inherited note 20.
- Fix applied in RA83: inserted `\setcounter{footnote}{0}` immediately before the Paper 23 section heading.
- No mathematical formula, prose, table, diagram, or bibliography text was changed.
- Source used for this pass: local P23 source cutout, `Noether_P23_Algebraische_und_Differentialvarianten_DMV32_1923_pp177_184_source.pdf`, carried from the RA60 P23 source-critical package.
- Source quality caveat: the P23 source cutout is below the current 650/1000 dpi dense-source-check rule. It was used only for article-boundary and local-footnote-sequence evidence, not for dense math/prose/table certification.
- Render verification: the P23 opening note at the Ostrowski--Schur reference now renders as 1 rather than 20.
- Structural scan classification: P8 is a scanner artifact because P9--P12 are not introduced by standard numbered `\section*` headings in this cumulative; P21 has an intentional source offset; P25/P29/P30 already reset after their source title blocks; P35 intentionally starts at source note 13; P37 renders correctly with first note 1.
- Build check: XeLaTeX pass 1 and pass 2 succeeded; output PDF is 399 pages.

## 2026-06-14 - P18/P19/P20 official source backfill package

Deliverable: `Noether_P18_P19_P20_OfficialSourceBackfill_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P18_P19_P20_OfficialSourceBackfill_WebDrop_20260614.zip`

SHA256: `42876C80DB5E0A4575AF047D58B84193EE7DD21D634ED1EBB9D30BCDB58E7BB6`

Scope: source/provenance/page-map backfill only; no cumulative TeX content changes.

Included:
- P18 GDZ JDMV 30 (1921), correct printed p.101 canvas `00000301`, selected by visual inspection from duplicated printed-p101 candidates. Raw GDZ image is 600 ppi, so it is below the 650 dpi checking threshold and must be treated as provenance/source unless no better witness appears.
- P19 GDZ Math. Ann. 83 (1921), `LOG_0008`, `Idealtheorie in Ringbereichen`, printed pp.24-66, 43 raw full-page images at 400 ppi plus article PDF and IIIF manifest/map/dimensions.
- P20 GDZ Math. Ann. 85 (1922), `LOG_0010`, `Ein algebraisches Kriterium fuer absolute Irreduzibilitaet`, printed pp.26-33, 8 raw full-page images at 400 ppi plus article PDF and IIIF manifest/map/dimensions.

Important correction: P20 is `LOG_0010`; exploratory `LOG_0004`-`LOG_0008` candidates were wrong, with `LOG_0008` being Kummer/Fermat rather than Noether. Those false candidates were removed from the staging folder before packaging.

Use limit: package is useful to stop missing-source confusion and establish clean source page maps; it is not a 650/1000 dpi dense-math certification package.

## 2026-06-14 - P05 official GDZ source backfill package

Deliverable: `Noether_P05_OfficialGDZ_SourceBackfill_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P05_OfficialGDZ_SourceBackfill_WebDrop_20260614.zip`

SHA256: `7F0D234235D01A94E8AD79F2E3B6F8F8F7D8DB97A0167E8CB3F9F3E36FE4C1AA`

Scope: source/provenance/page-map backfill only; no cumulative TeX content changes.

Included: GDZ JDMV 22 (1913), `PPN37721857X_0022`, `LOG_0038`, Emmy Noether, `Rationale Funktionenkörper`, printed pp.316-319; article PDF, IIIF manifest, raw full-page images, page/canvas map, image dimensions, inventory, checksums.

Use limit: the official GDZ raw pages report 600 ppi. This improves over the older local 360 ppi cutout but still falls below the project 650 dpi source-checking floor and 1000 dpi dense-math floor. It should prevent wrong-source confusion but does not certify dense math.

## 2026-06-14 - RA83 current coverage/gap ledger

Deliverable: `Noether_RA83_CurrentCoverage_GapLedger_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA83_CurrentCoverage_GapLedger_WebDrop_20260614.zip`

SHA256: `FD291950F6773737B72AF56FD9B9E79D5D275B8A86392FEEF3F838B1F34C1C3C`

Scope: compact machine-readable status/gap ledger, no TeX changes and no source images.

Key findings recorded: P09-P23 non-overlap lane has substantial targeted source-critical coverage already; P05/P18-P20 source backfills are clean provenance improvements but below dense-certification thresholds; current RA83 has three top-level Paper 34 headings and should receive a source/intent structural audit before edit/certification.

## 2026-06-14 - P26/P27/P28 clean short-abstract source package

Deliverable: `Noether_P26_P27_P28_CleanShortAbstractSources_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_P26_P27_P28_CleanShortAbstractSources_WebDrop_20260614.zip`

SHA256: `1F6EE1731BD5EA279FC4F0E25AC961FF28874D5D4AAD301CF148F31489FE8FC1`

Scope: source/provenance cleanup only; no cumulative TeX content changes.

Included correct source pages:
- P26: GDZ `PPN37721857X_0033`, printed p.102, canvas `000367`; excluded same printed-page candidate `000111` as unrelated Fraenkel page.
- P27: GDZ `PPN37721857X_0034`, printed p.101, canvas `000358`; excluded same printed-page candidate `000110` as unrelated variations/Randwertproblemen page.
- P28: GDZ `PPN37721857X_0034`, printed p.144, canvas `000401`; excluded same printed-page candidate `000153` as unrelated Paul Finsler page.

Use limit: all three selected GDZ images report 600 ppi, below the project 650 dpi source-checking floor. The package is clean source/provenance/page-map staging, not dense certification.

## 2026-06-14 - RA84 / P40-P43 RA10 appended apparatus placement audit

Deliverable: `Noether_RA84_P40_P43_RA10_ApparatusPlacement_Audit_WebDrop_20260614.zip`

Scope: compact audit package only; no cumulative TeX changes.

Finding: the RA83 German cumulative still contains the top-level appended section `RA10: scan-sichtbarer Apparat zu den Arbeiten 40--43` after Paper 43. The older RA10 documentation itself states that the scan-visible scholarly apparatus was appended because it could not yet be placed safely inline, and that Paper 40 inline body resynchronization remains the next audit target before Papers 40--43 can be treated as closed.

Disposition: this is not random trash and should not be deleted blindly, because it may preserve source-visible notes. It is also not a finished canonical source placement. Web/pro should treat it as an open apparatus-placement and body-resynchronization blocker: either integrate each apparatus item into the corresponding source note/footnote location after visual checking, or keep it outside the front-facing cumulative as an explicit audit appendix.

Marker scan: fixed-string scan of the RA83 cumulative for TODO/FIXME/MISSING/unsure/??/[...]/illegible/unreadable/unclear/placeholder/HALT/XXX/TBD found no hits. The RA10 appended apparatus is therefore a structural/editorial hotspot, not an unresolved-token marker.

Source-quality caveat: currently staged P40/P41 GDZ raw images and RA10 cutout PDFs remain below the 650/1000 dpi dense-certification rule. They may support structure/apparatus orientation, but dense math/table certification needs a highest-quality witness or a source-quality blocker label.

## 2026-06-14 - RA85 / Papers 9--15 section-anchor structural repair

Deliverable: `Noether_RA85_P09_P15_SectionAnchors_WebDrop_20260614.zip`

Scope: reversible structural TeX fix only; no source prose, mathematical formula, table, diagram, or footnote text changed.

Base: `cum_de_RA83_p23_footnote_reset_candidate_20260614.tex`.

Finding: in RA83 the numbered top-level section inventory jumped from Paper 8 to Paper 14, then from Paper 14 to Paper 16. Papers 9, 10, 11, 12, 13, and 15 were present as separate source title blocks with article-boundary `\setcounter{footnote}{0}` resets, but lacked corresponding top-level numbered `\section*{...}` anchors. This was the real mechanism behind the earlier P8/P9 scanner-artifact class.

Fix applied in candidate TeX: inserted six missing `\section*{...}` anchors immediately before the existing source title blocks for Papers 9, 10, 11, 12, 13, and 15.

Verification: XeLaTeX pass 1 and pass 2 succeeded; output PDF has 400 pages. Compile-log scan found no flagged lines for the checked fatal/error/missing-character/overfull/underfull/rerun/multiply-defined patterns. `RA85_numbered_section_inventory.csv` now records continuous top-level anchors from Paper 7 through Paper 43 except the known Paper 34 multi-block segmentation.

Motivation: this prevents downstream web/pro agents from reading present-but-unanchored papers as missing or merged, while preserving source title blocks and all prior source-critical content.

## 2026-06-14 - RA86 / Papers 9--20 source-quality witness ledger

Deliverable: `Noether_RA86_P09_P20_SourceQuality_WitnessLedger_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA86_P09_P20_SourceQuality_WitnessLedger_WebDrop_20260614.zip`

SHA256: `753CB7A68A46B54833DF25A9879A7CBD82F9651ECC38605F3D5F222126C9155A`

Scope: compact CSV/provenance package only; no TeX changes and no images.

Finding: current full-page witnesses for P09-P13 and P18-P20 are mostly GDZ/IIIF pages reporting 400 or 600 ppi. They are useful for provenance, source-page mapping, and broad orientation, but they do not clear the 650 dpi source-check floor or the 1000 dpi dense-math/table/diagram floor.

P14-P17 are staged through their RA52-RA55 source-critical packages rather than `source_master_checks`. Those packages contain targeted 1000 dpi witnesses for specific repaired/no-fix loci, but they are localized evidence, not blanket full-paper certification.

Online check: Internet Archive metadata for `sim_mathematische-annalen_1916_77_2`, `_77_3`, `_77_4`, and `sim_mathematische-annalen_1917_78` exposes PDFs, OCR layers, scandata, and processed JP2 ZIPs, but the scandata reports 400 ppi. These are alternate page-map/OCR witnesses, not source-resolution upgrades.

Action carried forward: for new dense corrections in P09-P13 or P18-P20, require a targeted >=1000 dpi crop from the best available source or explicitly label the locus as unresolved/source-quality blocked. Quarantine the existing P11 p226 crop for source-critical checking because it reports about 400 ppi.

## 2026-06-14 - RA87 / Paper 20 clearpage boundary fix

Deliverable: `Noether_RA87_P20_ClearpageBoundary_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA87_P20_ClearpageBoundary_WebDrop_20260614.zip`

SHA256: `ED9F661687F0216C4FD15524FEBA07C44ECBC00B93888B0B59C1F496C03E1164`

Scope: one-line structural TeX fix on top of RA85, with updated cumulative TeX/PDF, diff, fix ledger, compile logs, and checksums.

Finding: Paper 20 had a proper `\section*{20...}` anchor and footnote reset, but it started immediately after Paper 19's closing received-date block without a `\clearpage`. Surrounding paper boundaries, including Paper 21, use an explicit page break.

Fix applied: inserted `\clearpage` between the Paper 19 closing block and Paper 20's footnote reset/section anchor. No source prose, formulas, tables, diagrams, footnotes, or bibliographic text were changed.

Verification: XeLaTeX pass 1 and pass 2 both exited 0. Candidate PDF built successfully. Compile-log scan recorded zero flagged lines for the checked fatal/error/missing-character/overfull/underfull/rerun/multiply-defined patterns.

## 2026-06-14 - RA88 / Papers 9--20 dense hotspot aid ledger

Deliverable: `Noether_RA88_P09_P20_DenseHotspot_AidLedger_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA88_P09_P20_DenseHotspot_AidLedger_WebDrop_20260614.zip`

SHA256: `C7DD8F1507A97635B12979B254110B5CFFD49A713FC70BA68FCBC32535238F4D`

Scope: compact targeting/audit package only; no TeX changes and no images.

Base: RA87 German cumulative candidate.

Files included: priority dense hotspot CSV, per-paper display count CSV, P09--P20 boundary check after RA87, guarded unresolved-marker scan after RA87, provenance JSON, and checksums.

Finding: P09--P20 contains 61 priority dense/table/matrix/aligned/gathered-style triggers where future source-critical certification should use targeted >=1000 dpi crops. Per-paper priority counts are P09=1, P10=4, P11=0, P12=7, P13=8, P14=0, P15=5, P16=7, P17=15, P18=0, P19=11, P20=3.

No-fix structural checks: after RA87, every P09--P20 top-level paper anchor has a `\clearpage` boundary in the preceding five nonblank lines. Guarded marker scan for TODO/FIXME/MISSING/unsure/illegible/unreadable/unclear/placeholder/HALT/XXX/TBD/??/[...] returned no hits. The scanner explicitly avoids the false `HALT` hit inside German `enthalten`.

Use limit: this is a targeting ledger, not a defect ledger. Rows in the priority hotspot CSV mean "make/check a targeted >=1000 dpi source crop before certifying or editing this locus," not "the TeX is wrong."

## 2026-06-14 - RA89 / Papers 14--17 source PDF native-resolution amendment

Deliverable: `Noether_RA89_P14_P17_SourcePDF_NativeResolution_Amendment_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA89_P14_P17_SourcePDF_NativeResolution_Amendment_WebDrop_20260614.zip`

SHA256: `3646418B2F4064861F29FC41D17D236D630B6AB26FF44315CC879C3CC1D95E50`

Scope: compact source-quality amendment only; no TeX changes and no images.

Reason: RA86 noted targeted 1000 dpi witnesses in the P14--P17 RA52--RA55 packages but had not remeasured the native source PDFs. This pass used `pdfimages -list` on the actual source PDFs.

Findings:
- P14 source PDF: embedded image layers at 120/360 ppi.
- P15 source PDF: embedded image layers at 120/360 ppi.
- P16 source PDF: embedded image layers at 120/360 ppi.
- P17 source PDF: embedded image layers at 600 ppi.

Disposition: all four native source PDFs are below the 650 dpi full-page source-check floor, and below the 1000 dpi dense-math floor. The RA52--RA55 targeted 1000 dpi PNGs should therefore be treated as localized visual aids/renders for specific audit loci, not as native >=1000 dpi source evidence. P17 remains the strongest of the four local source PDFs at native 600 ppi, but still does not clear the project floor.

## 2026-06-14 - RA90 / Papers 14--17 official GDZ source-route ledger

Deliverable: `Noether_RA90_P14_P17_OfficialGDZ_SourceRoutes_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA90_P14_P17_OfficialGDZ_SourceRoutes_WebDrop_20260614.zip`

SHA256: `88F52DD5F0DB73194AA73BA7B75414F10C6CFC9645CDC0056360006F027073B6`

Scope: exact official GDZ page/canvas/IIIF route ledger for P14--P17; no images and no TeX changes.

Purpose: replaces guessing from old local cutout PDFs with precise institutional page routes. The package includes 82 rows: one for each printed source page in P14--P17, with printed page, canvas, image dimensions, IIIF service, full JPG URL, and info JSON URL.

Measured sample-page ppi:
- P14, JDMV 28 (1919), pp. 182--203, GDZ `PPN37721857X_0028`: 600 ppi.
- P15, Göttingen Nachrichten 1919, pp. 138--156, GDZ `PPN252457811_1919`: 400 ppi.
- P16, Math. Ann. 81, pp. 25--30, GDZ `PPN235181684_0081`: 400 ppi.
- P17, Math. Z. 8, pp. 1--35, GDZ `PPN266833020_0008`: 600 ppi.

Disposition: these official raw routes are the best current institutional routes identified, but still below the 650/1000 dpi floor. Use them for source context/page routing; for dense fixes, either find a stronger source or explicitly record the source-quality limitation.

## 2026-06-14 - RA91 / Paper 34 duplicate-section scaffold fix

Deliverable: `Noether_RA91_P34_DuplicateSectionScaffoldFix_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA91_P34_DuplicateSectionScaffoldFix_WebDrop_20260614.zip`

SHA256: `E5293B3F9ED37A3B30FD3847D69971A33F2DB5694A3C0475297213A2F7C45E83`

Scope: compact TeX/PDF/audit package; no source images and no dense-source certification claim.

Fix applied: in Paper 34, `Hyperkomplexe Größen und Darstellungstheorie`, removed duplicate visible top-level `\section*{34...}` scaffolding before `§ 5` and before `III. Kapitel`. Also removed the associated non-source `Fortsetzung...` labels and the mid-article `\setcounter{footnote}{0}` tied to the duplicate scaffold before `§ 5`.

Reason: the source work is a continuous article in Math. Z. 30 (1929), pp. 641--692. The repeated Paper 34 headings and continuation labels in the cumulative TeX were batch-production scaffolding, not source body. This structural error could confuse web/pro integration and footnote continuity.

What changed: only scaffold/boundary lines. No source prose, mathematical formula, table, diagram, or footnote text was altered.

Verification:
- XeLaTeX pass 1 exit 0.
- XeLaTeX pass 2 exit 0.
- Post-patch inventory finds exactly one visible `\section*{34. Hyperkomplexe Größen und Darstellungstheorie}`.
- Diff shows only the two duplicate scaffold blocks removed.

## 2026-06-14 - RA92 / boundary clearpage cleanup

Deliverable: `Noether_RA92_BoundaryClearpageCleanup_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA92_BoundaryClearpageCleanup_WebDrop_20260614.zip`

SHA256: `5D38E74BBD90A4D6D3F33A0E4DDEEE08ADE572C1B55C4253F0DD5CCE38BCCD75`

Scope: compact TeX/PDF/audit package on top of RA91; no source images and no dense-source certification claim.

Fix applied: added missing paper-boundary `\clearpage` before P7, P23, P24, P25, P26, P27, P28, P29, P34, P37, P40, and P42. Added paper-start `\setcounter{footnote}{0}` before P7 and P37, where no nearby reset was present. Removed one duplicate `\clearpage` before P35 that appeared during this cleanup layer.

Reason: after RA91, the numeric top-level paper-section scan still found paper starts chained directly to prior paper bodies or macro scaffolding. The affected changes are boundary/layout only and are meant to make web/pro integration less likely to merge articles accidentally.

What changed: page-boundary commands and two paper-start counter resets only. No source prose, mathematical formula, table, diagram, or footnote text was altered.

Verification:
- XeLaTeX pass 1 exit 0.
- XeLaTeX pass 2 exit 0.
- Post-patch scan finds every numeric top-level `\section*{N...}` has a `\clearpage` in the preceding five nonblank lines.
- Duplicate numeric top-level section scan remains clean after RA91.

## 2026-06-14 - RA93 / current-state ledger after RA92

Deliverable: `Noether_RA93_CurrentStateAfterRA92_Ledger_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA93_CurrentStateAfterRA92_Ledger_WebDrop_20260614.zip`

SHA256: `F070E4CC8AAFCAA92BF87A11B2DC053D1CE6E9F9DA1F5F21250DA643A4E31E8A`

Scope: compact ledger only; no TeX changes and no source images.

Purpose: updates the stale RA83 gap view after RA91 and RA92. RA83's repeated Paper 34 heading hotspot is now closed; all numeric top-level paper starts in the RA92 candidate have a nearby `\clearpage`; duplicate numeric paper-heading scan is clean.

Amendment before web handoff: added `audit/ra93_p01_p06_center_title_inventory.csv` and updated the README/summary to prevent a false missing-paper reading. The numeric `\section*` inventory starts at Paper 7 because Papers 1--6 are center-title blocks; Paper 4 is a multiline title block around line 3493 and is therefore manually listed in the early-title inventory.

Known-fix integration scan:
- P03 current TeX contains the corrected source-style `Variabeln` title block in the multiline Paper 03 heading.
- P09 source citation `Math. Ann. 75, S. 484` is present; old bad `S. 434` is absent.
- P34 continuation scaffold labels are absent.
- RA10 scan-visible apparatus marker remains present and is treated as an open apparatus-placement blocker, not random trash.

Remaining global blocker class: source quality. Several sources remain only 400--600 ppi locally/officially; they are page-map/provenance witnesses until a stronger source appears or a specific dense locus receives acceptable 1000+ dpi evidence from a sufficiently detailed master.

## 2026-06-14 - RA94 / Paper 17 source-unfaithful continuation scaffold fix

Deliverable: `Noether_RA94_P17_SourceUnfaithfulContinuationScaffoldFix_WebDrop_20260614.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_RA94_P17_SourceUnfaithfulContinuationScaffoldFix_WebDrop_20260614.zip`

SHA256: `FCB4506B6AC3C339852F3B1ECB1A0113210E754AEF806118DA55CED57B518CD7`

Scope: compact TeX/PDF/audit package on top of RA92; includes one 650 dpi source witness page for the checked structural transition. No dense formula/table/diagram certification claim.

Fix applied: removed the visible centered production label `Fortsetzung zu 17. Moduln in nichtkommutativen Bereichen, insbesondere aus Differential- und Differenzenausdrücken.` before Paper 17 `§ 5`. Removed the paired artificial `\clearpage` and `\setcounter{footnote}{12}` immediately before that non-source label.

Source basis: source printed p11 / source PDF p11, rendered at 650 dpi, shows `Satz I` followed directly by `§ 5. Rechnen mit Einheiten und Reduzibilität in k Untergruppen.` There is no centered continuation notice in the source.

What changed: only the scaffold block. No source prose, formula, table, diagram, theorem text, or footnote text was changed.

Verification:
- XeLaTeX pass 1 exit 0.
- XeLaTeX pass 2 exit 0.
- P17-band marker scan after RA94 has zero hits for `Fortsetzung zu 17` and zero hits for the targeted artificial `\setcounter{footnote}{12}`.

## 2026-06-19 - R101 tail source-gap closure search and IA scan slice

Deliverable: `Noether_R101_SourceGap_pp725_796_IA_ScanSlice_WebDrop_20260619.zip`

Local path: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Microsoft Edge is shit so every download goes here instead of subfolders\Codex_Noether_Intake_20260613\Noether_R101_SourceGap_pp725_796_IA_ScanSlice_WebDrop_20260619.zip`

SHA256: `7C6D60D9D7BED9657A3C8ECD66228F97A5EBA9C3A94974F3BD5CD2DD1736FC4A`

Scope: source acquisition / provenance package for the new R101 source gap, not a TeX repair package and not symbol-level certification.

R101 gap inspected: `Noether_R101_working_20260619.zip` marks source PDF pages 725--796 as provisional because only locator markdown existed, with no page images or scan PDF.

Local source found: full IA-derived Noether collected-papers PDF at `C:\Users\Floris\Documents\Papors\OS\Gesammelte Abhandlungen = Collected papers (Noether, Emmy, 1882-1935, Jacobson, Nathan etc.).pdf`. `pdfinfo` identifies it as IA item `gesammelteabhand0000noet`, 798 pages. `pdfimages -list` reports 360 ppi embedded images for the tail pages.

Package created: exact source PDF slice `Noether_GesammelteAbhandlungen_IA_source_pdf_pages_725_796_tail.pdf`, plus IA metadata/scandata, page concordance, candidate-source ledger, and source-search report.

Important mapping correction: R101's source-page ordinals are PDF/source pages, not printed collected-volume page numbers. In the actual IA PDF, p725 starts the Deuring/Noether lecture title page, p778 starts Kapferer, p787 starts the bibliography, p790 starts the short communications/book reviews list, p792--p794 are publisher ads/backmatter, and p795--p796 are blank/end leaves.

Stronger source route found but not downloaded here: IA metadata exposes `gesammelteabhand0000noet_orig_jp2.tar` (1,125,386,240 bytes) and `gesammelteabhand0000noet_jp2.zip` (376,102,852 bytes). These are the preferred next witnesses if accessible through an authenticated IA session. This runtime could read IA metadata and scandata but got 401/403 on direct PDF/JP2/archive-member endpoints. Springer chapter records and HathiTrust limited view were also found but access-gated here.

Next action for certification: use the included scan slice immediately to close the "no source PDF" blocker, then audit source PDF pages 725--791 page by page. If the IA original JP2 TAR becomes available, rerun the audit from those original page images before making final high-confidence symbol claims.

## 2026-06-24 - R122 P10/P12 reconciliation web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R122_P10_P12_Reconcile_WebDrop_20260624.zip`

SHA256: `9B132F2F13A0ECA36F0D12E57B857528B735CD77BC02AF96D227637FC72410CE`

Scope: reconciled current R122 German cumulative against older RA57/RA58/RA59 material for Papers 10-12.

Findings and actions:

- P10: R122 is source-correct against GDZ Math. Ann. 77 printed p540 (`PPN235181684_0077`, canvas `00000558`, original TIFF 600 dpi). Do not re-promote RA57's comma-separated / `i_\nu` wording. Source shows juxtaposed/dot-ellipsis argument lists and `i_\tau`.
- P11: RA58 and R122 spans are exact SHA256 matches; no action.
- P12: R122 correctly keeps the opening `f(x;dx)=...` formula inline; RA59's displayed version should not be promoted.
- P12: source-confirmed reversible TeX fix created for formula (11): terminal punctuation is comma, not semicolon. Candidate cumulative TeX compiled successfully with local xelatex to 457 pages.
- P12: do not promote RA59 period after formula (12); source p42 shows no visible final period after the ellipsis.

Source floor note: P10 GDZ original TIFF is 600 dpi and P12 GDZ original TIFF is 400 dpi. These were the best GDZ original endpoints found in the pass; they are below the preferred 650/1000 dpi threshold, so the package records the exception explicitly.

Continue: keep working backward in the non-overlap lane; do not trust older `complete` labels without page-level source checks. Prefer candidate cumulative TeX plus CSV/logbook for confirmed fixes, not CSV-only dumps.

## 2026-06-24 - R123 salvage rollup after failed web-session trace

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_Salvage_P12_P13_P16_P20_P39_WebDrop_20260624.zip`

Scope: salvaged the failed web-session R123 work from the pasted transcript and merged it with local source-certified fixes the failed R123 script did not include.

Base: R122 German cumulative.

Final candidate TeX: `tex/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`.

Compile: local XeLaTeX pass 1 and pass 2 succeeded. The resulting PDF is 457 pages. Pass-2 log checks report zero fatal errors, emergency stops, undefined control sequences, missing characters, overfull boxes, underfull boxes, or rerun warnings.

Integrated fixes:

- P12: formula (11) terminal punctuation corrected from semicolon to comma.
- P13: footnote differential indices corrected to `u_alpha / x_beta x_gamma`; `Herrn` corrected to `Heun`.
- P16: formula [7] and following prose corrected from `c_i`/`c_1...c_i` to source `alpha_i`/`alpha_1...alpha_lambda`.
- P20: formula tag `(12')` corrected to `(12)`.
- P39: transplanted the R122 source-fidelity block for printed pp. 189--194 and applied the additional R123 failed-web-script refinements: source title period, author line, source spelling `Princip`, source emphasis, and source-style `\srcnumdisplay` lineation for formulas (1)--(5).

Important salvage decision: the failed web trace built an R123 candidate from R122 with P16/P20/P39, but it did not include the local P12/P13 fixes. The package therefore supersedes both the local P12/P13/P16/P20 rollup and the incomplete failed R123 transcript by combining P12 + P13 + P16 + P20 + P39.

Included evidence: cumulative TeX/PDF, changed-paper slice TeX/PDF, diff from R122, diff from the P12/P13/P16/P20 rollup, combined confirmed-fix ledger, compile checks, source witness hashes, the failed web trace, and targeted source witnesses for the touched loci.

Open caveat: this is a source-certified salvage for the listed loci only. It is not a full page-by-page certification of the entire Noether corpus.

## 2026-06-24 - R123 Paper 18 GDZ600 source-closure no-patch drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_P18_GDZ600_SourceClosure_WebDrop_20260624.zip`

SHA256: `65DFA5EC25DC285CE786E1D7D6D8812E7BDBC589D5C6E7E72AA795A34B07BB36`

Scope: Paper 18, `Über eine Arbeit des im Kriege gefallenen K. Hentzelt zur Eliminationstheorie`, checked against the best staged GDZ full-page witness.

Source used: GDZ JDMV 30 (1921), printed p. 101, canvas `00000301`; local file `P18_GDZ_JDMV30_p101_Noether_Hentzelt_canvas00000301_600ppi.jpg`, 3224 by 5157 pixels, 600 ppi.

Source floor caveat: this witness is below the preferred 650 ppi floor, but it is the best staged source for P18. No lower-resolution crop or OCR derivative was used for certification.

Result: no TeX patch proposed. The current R123 salvage already contains the known RA51 correction in the resultant display: final factor `R^{(n)}(x_n)` and relation `\equiv 0(\mathfrak M)`.

Checked anchors:

- session/chair/title heading;
- opening Hentzelt paragraph;
- general elimination-problem paragraph;
- resultant display;
- uniqueness sentence after the display;
- final primary-decomposition / primary-factor paragraph.

No-fix traps recorded: source letterspacing/title emphasis is normalized by project TeX; source blackletter symbols are represented by `\mathfrak`; source emphasis on `allgemeine Problem der Eliminationstheorie` is represented with `\emph{...}`. None of these is a content defect.

Included evidence: source full-page JPG and same-page PDF, provenance CSVs, standalone current P18 TeX/PDF slice from the R123 salvage cumulative, rendered current PDF page, no-patch audit CSV, compile log summary, and checksums.

## 2026-06-24 - R123 P14-P18 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_P14_P18_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `5FA7AE6855AC03B437F1361BEEB2C5A86757209C94B6E4FF84E8699F364576CF`

Scope: current-state survival audit, not new full source certification. This package proves that older accepted P14--P17 repairs survive in the current R123 salvage cumulative, and carries the P18 no-patch closure forward as a reference.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.pdf`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.txt`

Verified survived in R123:

- P14 RA55: `(z-c)` reading; `\frp_1^{\rho_1}\cdots\frp_\sigma^{\rho_\sigma}` ideal-exponent family; polygon-class `\rho,\sigma` exponents.
- P15 RA54: Latin `x_1,\ldots,x_{\rho+\sigma}` family and related `\xi_{x_*,*}` display; Schur citation `Math. Ann. 71, S. 355 (1912)`.
- P16 RA53/R123: `linear zusammensetzen aus F und aus Formen aus M`; formula [7] uses the source `\alpha_1,\ldots,\alpha_\lambda` family rather than the old `c_i` family.
- P17 RA77/RA94: full title includes `Differential- und Differenzenausdrücken`; artificial `Fortsetzung zu 17` scaffold absent; formula (39) display footnotes survive as explicit `\footnotemark[21]` and `\footnotemark[22]`.
- P18: already closed no-patch against the GDZ600 package above.

No TeX patch was applied in this package. Purpose is to prevent stale-base regression and unnecessary duplicate work in web sessions.

Still open: this does not make a blanket page-by-page certification claim for P14--P17. Native source quality caveats from RA86/RA89/RA90 remain in force.

## 2026-06-24 - R123 P10-P13 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_P10_P13_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `5E506652CEBA2AED8EA82FFB665B8FFFB76222F0324D808A7D5DC31E7DDBB08C`

Scope: current-state survival audit, not new full page-by-page source certification. This package proves that older accepted P10--P13 repairs and no-fix traps survive in the current R123 salvage cumulative.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.pdf`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.txt`

Verified survived in R123:

- P10 RA56: source-visible author line; terminal index `k_\sigma` in definition (d); repaired `F(t;\vartheta_i)\cdot G(t;\vartheta_i)` display. Later prose `F(t;\vartheta)` is a different source locus and not a regression.
- P11 RA56: source-visible author line; `\Omega_\Gamma` systematic notation repair, with bad `\mathfrak L_\Gamma` absent; final theorem sentence uses source semicolon; formula (11) keeps plain `G_k(x)`, with bad `G'_k(x)` absent.
- P12 RA48/R123: source-visible author line; initial `f(x;dx)` survives while later prose `f(x,dx)` remains a no-fix trap; `d\delta x` and `\bdelta` identities survive; formula (11) has source comma, not semicolon; formula (12) no-period trap preserved.
- P13 RA48/R123: Klein dedication and author line; source spelling `endgiltige`; Lie citation `[zitiert "Grundlagen"]`; differential-index footnote `u_\alpha / x_\beta x_\gamma`; derivative display with fixed `x_\kappa` and summation `\lambda`; Klein formula (30); source `u_i=v` trap; Heun wording.

Bad-string counts in the cumulative: `S. 434`, `S. 555`, `\mathfrak L_\Gamma`, `G'_k(x)`, `ddx`, and `konstruieren: ihre Mannigfaltigkeit` all return zero.

No TeX patch was applied in this package. Purpose is to prevent stale-base regression and unnecessary duplicate work in web sessions.

Still open: this does not make a blanket page-by-page certification claim for P10--P13. Native GDZ full-page witnesses in this band are mostly 400--600 ppi, so future dense-math/table/diagram claims still require best-available source and targeted high-detail evidence, with explicit source-floor caveats if native source is below floor.

## 2026-06-24 - R123 P19-P20 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_P19_P20_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `B944E4ECE9500A4388E1E0768C693A2EF33E416A2001174C02B0273B4CE360E2`

Scope: current-state survival audit, not new full page-by-page source certification. This package closes the immediate P19--P20 survival gap after the P10--P18 cumulative survival drops.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.pdf`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.txt`

Verified survived in R123:

- P19 RA50: source order after `Wegen` reads `\ideal Q\eqzero{\ideal P}`, then `\ideal P^\rho\eqzero{\ideal Q}`.
- P19 RA50: elementary-divisor sequences survive as `s_1,\ldots,s_\lambda`, `t_1,\ldots,t_\mu`, with the continuation inequality `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`.
- P20 RA87: explicit `\clearpage` boundary between the P19 received-date block and the P20 section heading survives.
- P20 RA49: formula (13) factor display uses source `\varrho_\kappa` and `\sigma_\lambda` in the factor sums.
- P20 R123: formula tag correction survives as `(12)`, not `(12')`.

No-fix trap recorded: P20 still contains legitimate `\mu,\nu` prose around the index set of (9). This is not the RA49 formula (13) defect and must not be blindly patched.

No TeX patch was applied in this package. Purpose is to prevent stale-base regression and unnecessary duplicate work in web sessions.

Still open: this does not make a blanket page-by-page certification claim for P19--P20. The official GDZ article witnesses for P19/P20 are 400 ppi full-page sources, so future dense-math/table/diagram claims still need best-available source and targeted high-detail evidence, with source-floor caveats unless better witnesses are found.

## 2026-06-24 - R123 P09 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_P09_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `954327CB79E28534973A56B34C0C12D86BEDB2F679B4BCBAA34C23134BDEB5D2`

Size: 3,511,113 bytes. ZIP extraction test passed with 13 files.

Scope: current-state survival audit, not new full page-by-page source certification. This package closes the immediate P09 survival gap below the already packaged P10--P20 band.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.pdf`
- `cumulative_current/cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.txt`

Verified survived in R123:

- P09 RA56: printed author line `Von Emmy Noether in Erlangen.` survives at current R123 line 6317.
- P09 RA56: first Zermelo footnote reads `Math. Ann. 75, S. 484 (1914).` at line 6332; stale `S. 434` is absent from the P09 block.
- P09 RA56 no-fix trap: `z=\varphi(\xi_1\cdots\xi_t)` survives at line 7133; P09 block has no false `xi_h` reading.
- P09 RA56 no-fix trap: formula (5) module subscript `\mathfrak M_{\nu\kappa}` survives at line 7492; no comma-separated `\nu,\kappa` subscript appears in the P09 block.
- P09 RA56 no-fix trap: formula (6) module subscript `\mathfrak M_{\nu\kappa+1}` survives at line 7503; no comma-separated `\nu,\kappa+1` subscript appears in the P09 block.
- P09 RA79: footnote reset `\setcounter{footnote}{0}` survives at line 6312 immediately before the P09 title block.

Important non-survival / no-patch note:

- The older RA85 visible `\section*{9. Die allgemeinsten Bereiche aus ganzen transzendenten Zahlen}` structural anchor is not present in current R123. I did not reinsert it here. It is a structural/indexing anchor, not a source-text correction, and adding it visibly before the printed centered title risks duplicating the source title. If the web session needs machine anchors, prefer a non-printing/stable metadata anchor rather than a visible duplicate heading.

No TeX patch was applied in this package. Purpose is to prevent stale-base regression and unnecessary duplicate work in web sessions.

Still open: P09 is not globally certified page-by-page. Native full-page GDZ witnesses are mixed 400/600 ppi; accepted RA56 loci used targeted 1000 dpi crops. RA88 still flags one P09 dense display hotspot requiring targeted high-detail recheck before source-critical certification.

## 2026-06-24 - R123 P08 source fix cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123_P08_SourceFix_Cumulative_WebDrop_20260624.zip`

SHA256: `454C0691F6AF6F5FFA66F0ED3C206910F2C07F237497C0779FE79227A698A3D7`

Size: 4,754,389 bytes. ZIP extraction test passed with 20 files.

Scope: targeted P08 source fix plus current-state survival audit against the R123 salvage cumulative. This package includes a fresh cumulative candidate, not just ledgers.

Updated cumulative candidate:

- `cumulative_candidate/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_candidate/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_candidate/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Confirmed patch:

- P08 printed p097 substitution formula: current R123 had regressed to
  `f[x,y,(xy)x+(xz)y]=(xy)^p f(x,y,z).`
- The accepted source-critical reading from the earlier P07/P08 refined package, backed by the included 1000 dpi crop, is
  `f[x,y,(zy)x+(xz)y]=(xy)^p f(x,y,z).`
- I patched the cumulative candidate accordingly at current candidate line 6076.

Included source witness:

- `source_witnesses/P08/P08_p097_zy_substitution_formula_rawGDZ_1000dpi.png`

Also checked as survived in the patched candidate:

- P08 article-level `\section*{8. ...}` anchor is present at line 5925.
- P08 source-style split title/author block is present at lines 5930--5936.
- `volle Systeme` no-fix trap remains at line 5985.
- RA68 p096 display-side `\srcfnmark{*)}` / `\srcfntext{*)}{...}` survives at lines 6028--6030.
- RA66 p100 Omega-note lead `Man hat nach 3.` and closing `\Omega(h)` sentence survive at lines 6240--6254.

Build status:

- XeLaTeX pass 1 exit code 0.
- XeLaTeX pass 2 exit code 0.
- Fresh PDF length: 457 pages.
- Pass-2 scan found no fatal, emergency, undefined, missing-character, overfull, underfull, or rerun warnings. The only matched diagnostic was the pre-existing harmless font-shape warning `TU/lmr/m/scit`.

Still open: this is not full P08 page-by-page certification. It closes one concrete source regression and carries forward the old P08 no-fix/survival trail.

## 2026-06-24 - R123+P08 P07 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P07_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `5B9032D6C4B05EC9E3E83A19BFBC54CB04FCF48D847E33216320710FC1033FED`

Size: 3,511,490 bytes. ZIP extraction test passed with 11 files.

Scope: current-state survival audit for P07 using the P08-fixed cumulative baseline. No new P07 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Verified survived in the P08-fixed cumulative:

- P07 article-level `\section*{7. Der Endlichkeitssatz der Invarianten endlicher Gruppen}` at line 5810.
- P07 printed title/author block at lines 5816--5820.
- Opening Weber symbolic note at line 5823.
- Section 1 `Vgl. die Anmerkung zu 2.` symbolic note at line 5838.
- Section 2 double-star note at line 5858.
- Weber II §58 long correction note at line 5903.
- Final `Math. Ann. 76, S. 161` and Satz III relative-invariants notes at line 5920.
- Galois resolvent display no-fix trap retained at lines 5838--5855; do not alter signs/indices without a fresh full-page source audit.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix from the prior entry, so downstream sessions do not need to merge it separately.

Still open: this is not full P07 page-by-page certification. It proves survival of known accepted P07 repairs/no-fix decisions in the current text baseline.

## 2026-06-24 - R123+P08 P06 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P06_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `8EA181E678EBA344C1EB0B875632DD993332ACA2D49160279BA5123B15ED9D3F`

Size: 3,510,609 bytes. ZIP extraction test passed with 11 files.

Scope: current-state survival audit for P06 using the P08-fixed cumulative baseline. No new P06 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Verified survived in the P08-fixed cumulative:

- P06 printed title/citation block at lines 4530--4534.
- RA67 printed p161 preliminary-communication star note at line 4537.
- RA67 printed p161 Involutionsbasis double-star name note at line 4541.
- RA67 printed p164 Definition I quotient star note at line 4582.
- RA67 printed p164 special-fields exhaustion double-star note at line 4594.
- RA67 printed p164 algebraic-rank triple-star note at line 4610.
- RA67 printed p165 projective-invariant-fields star note at line 4641.
- Current P06 block from the title through start of P07 contains zero ordinary `\footnote{...}` tokens.

Stale prior-lane note:

- The old RA67 `remaining_ordinary_footnotes_check` rows at prior lines 4425, 4435, and 4443 are not active P06 defects in the current baseline. They fall before the current P06 title block and should not be chased as P06 unless a fresh current-base audit reclassifies them.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

## 2026-06-24 - P29 GDZ400 gross-gap anchor audit on P30-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P29_GDZ400_GrossGapAnchorAudit_R123plusP08P30_20260624.zip`

SHA256: `62DABA24C83B6090C7B7DF4E3772AACB9A9BEF51F94B68C5BA4DE07D60F527BF`

Size: 3,596,746 bytes. ZIP extraction test passed with 28 files.

Scope: Paper 29, `Der Endlichkeitssatz der Invarianten endlicher linearer Gruppen der Charakteristik p`, `Nachr. v. d. Ges. d. Wiss. zu Göttingen` 1926, printed pp. 28--35.

Base/current cumulative carried forward:

- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.tex`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.pdf`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.txt`

Result: no P29 TeX patch proposed in this pass.

Method and result:

- Source authority located in the RA71 package: GDZ `PPN252457811_1926`, canvases 32--39, full-page images 2176 x 3424/3432 at 400 ppi.
- GDZ OCR XML for printed pp. 28--35 was fetched and used only as a locator against the P30-repaired cumulative candidate.
- All eight P29 source pages had exact or high-fuzzy anchor coverage in the current P29 block.
- This is evidence against a gross missing-page or missing-paragraph defect like the P30 pp. 58--61 defect. It is not a symbol-level certification.

Important caveats and traps:

- The GDZ full-page images are 400 ppi, below the 650+ strict source-certification floor. Use them as best staged authority only unless a higher-resolution witness is found.
- The local folder `noether_p29_ia_source_20260623` is misnamed for P29 work: it contains Math. Ann. 90 printed pp. 229--261, i.e. P24 source material, not P29. Do not use that folder as a P29 source witness.

Included audit files:

- `audit/p29_gdz_ocr_vs_current_anchor_coverage.csv`
- `audit/p29_anchor_audit_summary.json`
- `audit/p29_no_patch_dispositions.csv`
- `audit/p29_current_tex_block_R123plusP08P30.tex`
- `source_ocr/P29_GDZ_fulltext_printed_p*.xml`
- `source_ocr/P29_GDZ_fulltext_printed_p*.txt`

## 2026-06-24 - P26-P28 GDZ600 gross-gap anchor audit on P30-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P26_P28_GDZ600_GrossGapAnchorAudit_R123plusP08P30_20260624.zip`

SHA256: `0590098D3B9820A964AF9D213EB7A22615389D361E85FB3FCBA5A1AF776E502C`

Size: 11,924,458 bytes. ZIP extraction test passed with 26 files.

Scope: three one-page report/abstract entries:

- P26, `Abstrakter Aufbau der Idealtheorie im algebraischen Zahlkörper`, JDMV 33 (1924), p. 102.
- P27, `Hilbertsche Anzahlen in der Idealtheorie`, JDMV 34 (1925), p. 101.
- P28, `Gruppencharaktere und Idealtheorie`, JDMV 34 (1925), p. 144.

Base/current cumulative carried forward:

- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.tex`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.pdf`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.txt`

Result: no P26/P27/P28 TeX patch proposed in this pass.

Method and result:

- Used the clean selected GDZ witnesses staged in the P26-P28 source package:
  - P26: GDZ `PPN37721857X_0033`, canvas `000367`, printed p. 102.
  - P27: GDZ `PPN37721857X_0034`, canvas `000358`, printed p. 101.
  - P28: GDZ `PPN37721857X_0034`, canvas `000401`, printed p. 144.
- Fetched the corresponding GDZ OCR XML and used it only as a locator.
- Because the source pages contain neighboring meeting notices, the useful comparison direction was current-text windows against the source-page OCR.
- All three current blocks had strong current-to-source anchor coverage. No gross omitted-paragraph defect surfaced.

Important caveats and traps:

- The selected GDZ full-page images report 600 ppi. They are the best clean staged witnesses and are included in the package, but they remain below the 650+ source-checking floor and below the 1000+ dense-math rule.
- This pass is a gross-gap/no-patch locator audit, not a strict symbol-level certification.
- The package carries forward the P30-repaired cumulative to prevent regressing to the older P08-only baseline.

Included audit/source files:

- `audit/p26_p28_current_to_gdz_ocr_anchor_coverage.csv`
- `audit/p26_p28_anchor_audit_summary.json`
- `audit/p26_p28_no_patch_dispositions.csv`
- `source_ocr/P26_GDZ_fulltext...`, `P27...`, `P28...`
- `source_pages/P26_GDZ_printed102_canvas000367_full.jpg`
- `source_pages/P27_GDZ_printed101_canvas000358_full.jpg`
- `source_pages/P28_GDZ_printed144_canvas000401_full.jpg`

## 2026-06-24 - P31 GDZ600 gross-gap anchor audit on P30-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P31_GDZ600_GrossGapAnchorAudit_R123plusP08P30_20260624.zip`

SHA256: `68B9A4A0884E82A58DEFD71667E840981D1DDE31364195BC778AD016D00A75FD`

Size: 3,800,636 bytes. ZIP extraction test passed with 59 files.

Scope: Paper 31, `Der Diskriminantensatz für die Ordnungen eines algebraischen Zahl- oder Funktionenkörpers`, J. reine angew. Math. 157 (1927), printed pp. 82--104.

Base/current cumulative carried forward:

- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.tex`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.pdf`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.txt`

Result: no P31 TeX patch proposed in this pass.

Method and result:

- Source authority: GDZ `PPN243919689_0157`, canvases 90--112, printed pp. 82--104.
- The raw 600 ppi page images remain in `Noether_P31_RA73_SourceHeader_FootnoteCounter_WebDrop_20260614/source/raw_fullres_gdz/` and are not duplicated in this compact package.
- Fetched GDZ OCR XML for all 23 article pages and used it only as a locator against the P30-repaired cumulative candidate.
- All 23 source pages had exact/high-fuzzy anchor coverage. Minimum exact anchor windows per page: 5. Minimum high-fuzzy windows per page: 30.
- No gross missing-page or missing-paragraph defect surfaced.

Important caveat:

- The GDZ full-page images report 600 ppi, below the 650+ strict source-certification floor. This pass is a gross-gap/no-patch locator audit, not a strict symbol-level certification.

Included audit files:

- `audit/p31_gdz_ocr_vs_current_anchor_coverage.csv`
- `audit/p31_anchor_audit_summary.json`
- `audit/p31_no_patch_dispositions.csv`
- `audit/p31_current_tex_block_R123plusP08P30.tex`
- `source_ocr/P31_GDZ_fulltext_printed_p*.xml`
- `source_ocr/P31_GDZ_fulltext_printed_p*.txt`

## 2026-06-24 - P32 IA600 gross-gap anchor audit on P30-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P32_IA600_GrossGapAnchorAudit_R123plusP08P30_20260624.zip`

SHA256: `1756B8BE798730C5F11299FC68B378D4C984C076657765E9E80C02FC0637F864`

Size: 3,612,900 bytes. ZIP extraction test passed with 30 files.

Scope: Paper 32, R. Brauer and E. Noether, `Über minimale Zerfällungskörper irreduzibler Darstellungen`, Sitzungsberichte der Preußischen Akademie der Wissenschaften 1927, printed pp. 221--228.

Base/current cumulative carried forward:

- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.tex`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.pdf`
- `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.txt`

Result: no P32 TeX patch proposed in this pass.

Method and result:

- Source authority: IA item `sitzungsberichte-der-preussischen-akademie-der-wissenschaften-1927`, printed pp. 221--228 = IA leaves 0382--0389.
- The JP2/JPG source leaves remain in `Noether_P32_RA74_SourceAuthorBlock_WebDrop_20260614/source/` and are not duplicated here.
- Fetched IA DjVu XML for the article leaves and used it only as a locator against the P30-repaired cumulative candidate.
- All eight source pages had high-fuzzy anchor coverage. No gross missing-page or missing-paragraph defect surfaced.

Important caveats:

- IA metadata and DjVu XML report 600 DPI, below the 650+ strict source-certification floor. This pass is a gross-gap/no-patch locator audit, not a strict symbol-level certification.
- Printed p. 228 has zero exact anchor windows because the OCR is noisy and includes closing-page boilerplate, but it still has 33 high-fuzzy windows and best score 1.000. No patch is proposed from this locator evidence.

Included audit files:

- `audit/p32_ia_ocr_vs_current_anchor_coverage.csv`
- `audit/p32_anchor_audit_summary.json`
- `audit/p32_no_patch_dispositions.csv`
- `audit/p32_current_tex_block_R123plusP08P30.tex`
- `source_ocr/P32_IA_djvu_xml_printed_p*.xml`
- `source_ocr/P32_IA_djvu_text_printed_p*.txt`

## 2026-06-24 - P24 MA90 source-upgrade package

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P24_MA90_SourceUpgrade_R123plusP08_20260624.zip`

SHA256: `FF7BB8D6AAC866DDE2F7F3ED0213A16E3EB0E6819C8509ED728433C70F955487`

Size: 22,941,629 bytes. ZIP extraction/open test passed with 46 entries.

Scope: Paper 24, Emmy Noether, `Eliminationstheorie und allgemeine Idealtheorie`, Math. Ann. 90 (1923), printed pp. 229--261.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source upgrade:

- IA Math. Ann. 90 raw JP2 leaves 234--266.
- IA generated PDF slice pages 235--267.
- Concordance CSV mapping printed pp. 229--261 to IA leaves 234--266 and IA PDF pages 235--267.
- IA `scandata.xml`, `page_numbers.json`, `meta.xml`, and `files.xml`.

Source-quality caveat:

- IA metadata/scandata records this scan at 400 ppi.
- This is a complete useful source witness and closes the local article-level source-map gap for P24, but it is below the 650+ dpi strict certification floor and below the 1000 dpi dense-math rule.
- No TeX correction was applied in this package. Use it as a source/concordance upgrade for future P24 source-critical audit, not as a claim that P24 is symbol-certified.

## 2026-06-24 - P24 MA90 gross-gap anchor audit

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P24_MA90_GrossGapAnchorAudit_R123plusP08_20260624.zip`

SHA256: `27BBC9289144A645FC305543089CFC5E38FD92D3D296FCDF9E7042738E39B9CB`

Size: 3,536,727 bytes. ZIP extraction/open test passed with 9 entries.

Scope: Paper 24, `Eliminationstheorie und allgemeine Idealtheorie`, Math. Ann. 90 (1923), printed pp. 229--261. This pass used the IA Math. Ann. 90 OCR/djvu XML only as a locator against the current R123+P08 cumulative.

Current TeX bounds checked:

- P24 starts at current cumulative line 13709.
- P24 ends at current cumulative line 14226.
- P25 starts at current cumulative line 14227.

Result:

- 33 source pages checked for page-level prose anchoring: printed pp. 229--261.
- All 33 source pages have an exact high-confidence OCR prose anchor in the rough-unTeX current P24 block.
- Lowest overlap pages were printed pp. 235, 250, 244, 254, 241, 230, 236, and 237; all still had exact anchors.
- No missing-page or large dropped-prose failure was detected by this locator pass.

Files included:

- `audit/p24_ma90_source_to_current_anchor_coverage.csv`
- `audit/p24_ma90_source_ocr_by_page.csv`
- `audit/p24_ma90_anchor_audit_summary.json`
- `audit/p24_current_tex_bounds.csv`
- current cumulative TeX/PDF/TXT

Important limit:

- This is a gross-gap/source-anchor audit only. It does not certify every mathematical symbol, accent, formula, or line break.
- IA records this source as 400 ppi, so it remains below the local 650+ final-certification floor. No TeX correction was applied.

## 2026-06-24 - P30 MA96 source repair, printed pp. 58--61

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P30_MA96_SourceRepair_p058_061_R123plusP08_20260624.zip`

SHA256: `84F9E753F0CF123A34DBB9674D3D0FC60CE0D5186E46150CE7FADF33E479E4C2`

Size: 16,054,109 bytes. ZIP extraction/open test passed with 24 entries.

Scope: Paper 30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, Math. Ann. 96 (1927), printed pp. 58--61.

Baseline defect:

- The R123+P08 cumulative compressed/omitted the detailed final proof region of §10.
- The p30 MA96 locator pass found no strict exact anchor on printed p60, and visual inspection of IA leaf 65 confirmed that the current text lacked the source `2\gamma. Vorbemerkung` and `2\delta. Nachweis des Vielfachenkettensatzes` material.
- Visual inspection of printed pp. 58--61 showed the compression begins earlier, covering the source definition/details, full footnote 34, the α--ε induction-hypothesis list, and steps 2α--2ε.

Repair candidate:

- Repaired cumulative TeX: `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.tex`
- Repaired cumulative PDF: `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.pdf`
- Repaired cumulative TXT: `cumulative_candidate/cum_de_R123_plus_P08_P30_p058_061_repair_20260624.txt`
- The baseline cumulative was not overwritten.

Confirmed restored:

- Definition details for `einfach`, `einfach in`, and `Kompositionsreihe`.
- Full footnote 34.
- The α--ε list of induction hypotheses.
- Steps 2α, 2β, 2γ, 2δ, and 2ε.
- Final source equivalence statement and received date.

Build/QA:

- XeLaTeX second pass completed successfully.
- Output PDF length: 458 pages.
- Rendered QA pages 294--296 are included; page 295 contains the restored 2β--2ε material.
- Diff included as `audit/p30_p058_061_repair.diff`.
- Post-repair gross-gap locator audit included: all 36 P30 source pages, printed pp. 26--61, now have exact high-confidence OCR prose anchors in the repaired cumulative candidate.
- Post-repair files: `audit/p30_ma96_postrepair_source_to_current_anchor_coverage.csv` and `audit/p30_ma96_postrepair_anchor_audit_summary.json`.

Source-quality caveat:

- IA/GDZ MA96 witnesses available here are 400 ppi.
- This is a best-available visual source repair below the strict 650+ certification floor; do not describe it as strict 650+ symbol certification.

## 2026-06-24 - R123+P08 P09-P13 source-fix survival and anchor-regression web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P09_P13_SourceFixSurvival_AnchorRegression_R123plusP08_20260624.zip`

SHA256: `37BF5207DF81D688C07C792B613F1B4456DA1774E13002C958D2CB3EA635BB50`

Size: 3,577,096 bytes. ZIP extraction test passed with 43 files.

Scope: targeted survival audit for prior source-backed fixes in P09-P13, plus a section-anchor regression/style audit. No new P09-P13 TeX patch was applied in this pass.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Prior audit material carried forward:

- `Noether_P09_P10_P11_RA56_SourceCritical_Fix_WebDrop_20260614`
- `Noether_P12_P13_GDZ_RA48_SourceCritical_Fix_WebDrop_20260614`
- `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614`
- `Noether_RA85_P09_P15_SectionAnchors_WebDrop_20260614`

Verified survived in the P08-fixed cumulative:

- P09 line 6317: `Von Emmy Noether in Erlangen.`
- P09 line 6332: `Math. Ann. 75, S. 484 (1914).`
- P10 line 7648: `Von Emmy Noether in Göttingen.`
- P10 line 7696: terminal index `k_\sigma`.
- P10 line 7731: `H(t;a_i(\vartheta))=F(t;\vartheta_i)\cdot G(t;\vartheta_i).`
- P11 line 7846: author line.
- P11 lines 7898--8027: `\Omega_\Gamma` survives; the old bad `\mathfrak L_\Gamma` drift was not found in the checked range.
- P11 line 8035: semicolon phrase `konstruieren; ihre Mannigfaltigkeit`.
- P12 line 8049: author line.
- P12 line 8060: `f(x;dx)`.
- P12 lines 8075 and 8238: `d\delta x`.
- P12 lines 8210, 8223, and 8237: `\bdelta x`.
- P13 line 8447: Klein dedication.
- P13 line 8449: author line.
- P13 line 8456: `endgiltige`.
- P13 line 8465: Lie citation with Grundlagen note.
- P13 lines 8704--8707: fixed `x_\kappa` and summed `\lambda`.
- P13 line 8840: Klein/Einstein formula anchor term `\mathfrak{R}_{\mu\nu}g_\tau^{\mu\nu}`.
- P09-P13 article-local footnote resets survive at lines 6311--6312, 7642--7643, 7787--7788, 8043--8044, and 8442--8443.

Structural/style issue left open rather than patched:

- Prior RA85 added top-level numbered `\section*` anchors for P09, P10, P11, P12, P13, and P15.
- The current R123+P08 cumulative has visible numbered centered title blocks for these papers, but does not retain those exact top-level `\section*` anchors.
- I did not patch this directly because adding the RA85 anchors naively would duplicate visible titles in the current layout. This is a layout/style integration question, not a source-symbol correction.
- Current P14 also uses a centered title block rather than a top-level `\section*{14...}` anchor, but RA85 did not list P14 as a repair target; recorded as style-policy open.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

## 2026-06-24 - P18 Hentzelt best-available source audit web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P18_Hentzelt_BestAvailableAudit_R123plusP08_20260624.zip`

SHA256: `EDE7924EE7262B03ABF4B974C133F8EE688E816D366F877DDA1C831E93446201`

Size: 8,175,985 bytes. ZIP integrity/open test passed with 11 files.

Scope: Paper 18, E. Noether, `Über eine Arbeit des im Kriege gefallenen K. Hentzelt zur Eliminationstheorie`, JDMV 30 (1921), printed p. 101.

Included current text baseline:

- `cum/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source:

- `source/P18_GDZ_JDMV30_p101_Noether_Hentzelt_canvas00000301_600ppi.jpg`
- `source/P18_GDZ_JDMV30_p101_Noether_Hentzelt_local_pdf_from_canvas00000301.pdf`
- source page/canvas and image-dimension ledgers.

Disposition:

- No TeX body patch applied.
- The current P18 block at `cum_de_R123_plus_P08_zy_fix_20260624.tex` lines 11225--11249 was visually checked against GDZ canvas `00000301`.
- Conference heading, Loewy chair line, Noether/Hentzelt title, memorial prose, elimination-theory theorem paragraph, resultant-form formula, divisor statement, and final primary-ideal interpretation all match at the level visible in this witness.

Source-quality caveat:

- The GDZ raw page is 600 ppi. It is the best local/online witness found in this pass, but it is below the 650 dpi checking floor.
- Therefore this is recorded as `checked_no_patch_best_available`, not strict 650+ symbol-level certification. If a 650+ witness appears, P18 can be closed more strongly.

## 2026-06-24 - P19/P20 IA source-upgrade web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P19_P20_IA_SourceUpgrade_R123plusP08_20260624.zip`

SHA256: `1A7BAC24D58D41431972FD12F4F2CAD18989C9306ACD07E66029AF61111686AF`

Size: 33,559,929 bytes. ZIP integrity/open test passed with 80 files.

Scope:

- P19, `Idealtheorie in Ringbereichen`, Math. Ann. 83 (1921), printed pp. 24--66.
- P20, `Ein algebraisches Kriterium für absolute Irreduzibilität`, Math. Ann. 85 (1922), printed pp. 26--33.

Included current text baseline:

- `cum/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source:

- IA raw processed JP2 article leaves for P19 and P20.
- IA PDF slices:
  - `P19_IA_MA83_pp030_072_print024_066.pdf`
  - `P20_IA_MA85_pp036_043_print026_033.pdf`
- IA scandata/page-number/meta files.
- `audit/ia_page_concordance.csv`.
- prior correction history from P19 RA50 and P20 RA49/RA87/RA88, including the P19 pp.58/65--66 source repairs, P20 formula (13) `\kappa,\lambda` repair, and P20 no-fix traps.
- `audit/p19_p20_prior_fix_survival_check_R123plusP08.csv`, confirming those known P19/P20 source-backed repairs survive in the included R123+P08 cumulative.

Concordance:

- P19 printed pp. 24--66 = IA MA83 leaves 29--71 = IA PDF pages 30--72.
- P20 printed pp. 26--33 = IA MA85 leaves 35--42 = IA PDF pages 36--43.

Disposition:

- No TeX body patch applied.
- This package upgrades source availability and gives clean article-level IA cutouts to compare against the existing GDZ backfill.

Source-quality caveat:

- IA scandata reports 400 ppi for both volumes. This does not meet the 650+ source-certification rule and does not beat the best 600 ppi GDZ leaves already available for some P20 pages.
- Use these IA cutouts for source-location, gross audit, and alternate-witness comparison; do not claim strict dense-symbol certification from them alone.

## 2026-06-24 - P17 RA94 scaffold-fix survival check web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P17_RA94_ScaffoldFix_Survival_R123plusP08_20260624.zip`

SHA256: `CC4BA4B40EC7E7EF089D1948767D848305D9DF1094919316827FCB1390606521`

Size: 6,033,562 bytes. ZIP integrity/open test passed with 13 files.

Scope: Paper 17, survival check for the RA94 source-unfaithful continuation-scaffold cleanup.

Included current text baseline:

- `cum/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included prior source/witness history:

- RA94 README, applied-fix ledger, marker scan, and diff.
- `source/P17_source_pdfpage_11_printed_p11_section5_transition_650dpi.png`.

Disposition:

- No new TeX body patch applied.
- Current R123+P08 cumulative was checked for the forbidden visible `Fortsetzung zu 17...` scaffold marker: absent.
- Current transition at lines 10336--10340 has `Satz I` followed directly by `\pseventeenheading{5}{Rechnen mit Einheiten und Reduzibilität in $k$ Untergruppen.}`, matching the prior RA94 source-based cleanup.

Caveat: targeted survival check only, not global P17 certification.

## 2026-06-24 - P14-P16 source-fix survival check web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P14_P16_SourceFixSurvival_R123plusP08_20260624.zip`

SHA256: `03C720DD04AEB2133DA082C2A71588E6E2EF273C9824BD40DEEDBC22466E279A`

Size: 3,519,336 bytes. ZIP integrity/open test passed with 21 files.

Scope: targeted survival check for prior P14/P15/P16 source-critical repairs and RA78 footnote resets in the current R123+P08 cumulative.

Included current text baseline:

- `cum/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included prior ledgers:

- P14 RA55 README, applied fixes, no-fix traps.
- P15 RA54 README, applied fixes, no-fix traps.
- P16 RA53 README, applied fixes, no-fix traps.
- P14/P15/P16 RA78 footnote-reset README and applied fixes.

Fresh survival ledger:

- `audit/p14_p16_prior_fix_survival_check_R123plusP08.csv`

Confirmed survival:

- P14 RA55: `mod. (z-c)`, `\frp_1^{\rho_1}\cdots\frp_\sigma^{\rho_\sigma}`, and polygon exponents `\rho,\sigma` survive.
- P15 RA54: Latin `x` index family and Schur citation `S. 355 (1912)` survive; no `S. 555` in the checked range.
- P16 RA53: `linear zusammensetzen aus $F$` survives; the old `\Phi` drift is absent in the checked locus.
- RA78: article-local `\setcounter{footnote}{0}` survives before Papers 14, 15, and 16.

Caveat: targeted survival/rebase check only, not page-by-page certification of P14-P16.

## 2026-06-24 - P30 Math. Ann. 96 source-upgrade web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P30_MA96_SourceUpgrade_20260624.zip`

SHA256: `D37F91C3E0404181039188CE2D24F4AD4C09088D718941B5EE174F9BFD7CA85C`

Size: 28,835,359 bytes. ZIP extraction test passed with 50 files.

Scope: source upgrade and page concordance for P30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, Math. Ann. 96 (1927), pp. 26--61. No new TeX patch was applied in this pass.

Included cumulative baseline:

- `cum/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cum/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source witnesses:

- IA raw JP2 leaves 0031--0066 as `src/ia_jp2/leaf0031_p026.jp2` through `src/ia_jp2/leaf0066_p061.jp2`.
- IA PDF cutout: `src/ia_pdf/P30_IA_MA96_pp032_067_print026_061.pdf`.
- GDZ/PPN PDF cutout: `src/gdz_pdf/P30_GDZ_PPN0096_pp031_066_print026_061.pdf`.

Verified mapping:

- Printed pp. 26--61 = IA leaves 31--66 = IA PDF pp. 32--67 = GDZ `PPN235181684_0096.pdf` pp. 31--66.
- The GDZ mapping was visually spot-checked: PDF p. 31 is printed p. 26 title/author/first footnote; PDF p. 66 is printed p. 61 ending page.

Source-quality caveat:

- Both IA and GDZ witnesses are 400 PPI internally. This improves source provenance and completeness but does not satisfy the 650+ dpi strict certification floor or 1000+ dpi dense-math rule.
- Therefore this package closes the local source-location blocker for P30, but leaves P30 body prose/math/footnotes open for careful best-available audit unless a higher-resolution witness is found.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

## 2026-06-24 - R123+P08 P09 rebased survival drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P09_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `6BEBEEBDACFE3AFE52DC1AB526E04D0C4D172FAADD8880ABD59A8B5E031061F7`

Size: 3,513,252 bytes. ZIP extraction test passed with 16 files.

Scope: rebase of the existing P09 R123 survival audit onto the P08-fixed cumulative baseline. No new P09 TeX patch was applied.

Shared rebase verification:

- Old baseline: `cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`
- New baseline: `cum_de_R123_plus_P08_zy_fix_20260624.tex`
- Both files have 23416 lines.
- The only text difference found is line 6076, the intended P08 source fix from `(xy)x+(xz)y` to `(zy)x+(xz)y`.

Still open: this remains a survival/rebase package, not fresh page-by-page source certification of P09.

## 2026-06-24 - R123+P08 P10-P20 rebased survival drops

These packages rebase the existing P10-P20 R123 survival drops onto the P08-fixed cumulative baseline. No new P10-P20 TeX patches were applied.

Shared rebase verification:

- Old baseline: `cum_de_R123_salvage_P12_P13_P16_P20_P39_20260624.tex`
- New baseline: `cum_de_R123_plus_P08_zy_fix_20260624.tex`
- Both files have 23416 lines.
- The only text difference found is line 6076, the intended P08 source fix from `(xy)x+(xz)y` to `(zy)x+(xz)y`.

Packages:

- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P10_P13_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
  - SHA256: `5F6ABAE49D0F27CD273247D9ADC029A72294778EA95C02845D373AA891DFC335`
  - Size: 3,510,539 bytes. ZIP extraction test passed with 12 files.
- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P14_P18_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
  - SHA256: `0F3C0A9449BFBE43745C6994CC6574F022BF995A139DFECCD497951F35FD070F`
  - Size: 3,509,690 bytes. ZIP extraction test passed with 11 files.
- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P19_P20_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
  - SHA256: `CCBAE4BF897C9BA638C9B5B2B20AD97F62FFF2A8136A5400B64B372FC5E804AB`
  - Size: 3,509,966 bytes. ZIP extraction test passed with 12 files.

Scope limits:

- These are survival/rebase packages, not fresh page-by-page source certifications.
- The existing range-specific survival ledgers are preserved inside each package under `audit/`.

## 2026-06-24 - R123+P08 P21-P43 context cumulative drops

These packages carry the P08-fixed cumulative baseline forward and attach the relevant P21-P43 prior context/source/caveat folders. They do not introduce new TeX patches.

Packages:

- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P21_P23_Context_Cumulative_WebDrop_20260624.zip`
  - SHA256: `50C6C02A658B6A0FDBCD9084BEFA656012E162E18D94E3B34E0DEC7F5A3F3D88`
  - Size: 37,636,150 bytes. ZIP extraction test passed with 57 files.
  - Includes P21/P23 GDZ 600 ppi source upgrades and P22 absorbed/no-duplicate context. 600 ppi is useful but still below the local 650+ final-certification rule.
- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P24_P30_Context_Cumulative_WebDrop_20260624.zip`
  - SHA256: `8DE22EEFC9322B2E333D58564E64D3A6C3A440769053AE18B5071555A3905AEB`
  - Size: 338,690,774 bytes. ZIP extraction test passed with 130 files.
  - Includes P24/P25/P30 absorbed contexts plus P29/P30 source context. Largest package because it keeps source provenance attached.
- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P31_P37_Context_Cumulative_WebDrop_20260624.zip`
  - SHA256: `931A851EDD3646ED9CCB5258AD758816682F070A0720B9E74C3396A135F1876E`
  - Size: 8,038,955 bytes. ZIP extraction test passed with 42 files.
  - Includes P31-P36 RA07 absorbed/no-duplicate context and P37 RA08 restored-context package. P38/P39 are explicitly not closed by this package.
- `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P38_P43_Context_Cumulative_WebDrop_20260624.zip`
  - SHA256: `F3361ABD9FAF5ADC630D3A6FECFB7F650430D999763A7D9119BA717160D54AA2`
  - Size: 70,754,815 bytes. ZIP extraction test passed with 129 files.
  - Caveat-heavy: P38-P42 reset context, Slavic P38/P39 overwrite warning, P39 source-fidelity context, R123 salvage context, and P40-P43 RA10 apparatus-placement caveat.

Scope limits:

- These are context/handoff packages, not new full source certifications.
- P38-P43 remains especially open because source audit and apparatus placement are not fully closed.

Still open: this is not full P06 page-by-page certification. It proves survival of the known RA67 source-marker fixes in the current text baseline.

## 2026-06-24 - R123+P08 P05 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P05_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `D0DE593C40FAD60FAAA0A48DD8B774C70B5C03E64BA7D4659A60E99DCA036654`

Size: 3,511,905 bytes. ZIP extraction test passed with 12 files.

Scope: current-state survival audit for P05 using the P08-fixed cumulative baseline. No new P05 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Verified survived in the P08-fixed cumulative:

- P05 starts at line 4489 and P06 starts at line 4530, so the audited block is small and well bounded.
- The printed P05 title includes the source lecture note: `Vortrag, gehalten auf der Naturforscherversammlung Wien 1913.`
- The opening Steinitz reference note survives at line 4498.
- The Lüroth/Castelnuovo/Enriques note survives at line 4508.
- The Hilbert problems note survives at line 4516.
- The display-side source marker `\srcfnmark{2)}` survives at line 4520 and its body survives at line 4522.
- Current P05 block contains zero ordinary `\footnote{...}` tokens.

Stale prior-lane note:

- The older RA42 missing-title/source-note defect and the RA80 footnote-reset concern are absorbed in the current baseline. Current P05 uses explicit source-note labels, so I did not add a `\setcounter{footnote}{0}` patch.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

Still open: this is not full P05 page-by-page certification. It proves survival of the known P05 source-note/title fixes in the current text baseline.

## 2026-06-24 - R123+P08 P04 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P04_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `64079D06EE84237537D51947550AC9CBCC854BB9F7B0EFBC6E8C65485136DB5D`

Size: 3,511,953 bytes. ZIP extraction test passed with 13 files.

Scope: current-state survival audit for P04 using the P08-fixed cumulative baseline. No new P04 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Verified survived in the P08-fixed cumulative:

- P04 starts at line 3538 with `\clearpage`; P05 starts at line 4489.
- RA80 article-boundary `\setcounter{footnote}{0}` survives at line 3539.
- P04 title/source note survives at lines 3541--3542.
- Opening Study, Gordan, and Clebsch notes survive at lines 3554--3556 after the local reset.
- RA64 section 9 heading footnote survives at line 4456: `Vgl. die entsprechenden Betrachtungen im ternaren Gebiete. Diss. §§ 1--3.`
- RA64 no-fix traps survive: plain RHS products around line 4314, special-case source order around line 4351, and the `q_{n-\sigma-\lambda},p_{\tau-\lambda}` prose pair around line 4098.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

Still open: this is not full P04 page-by-page certification. It proves survival of known RA64/RA80 repairs and no-fix decisions in the current text baseline.

## 2026-06-24 - R123+P08 P03 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P03_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `280CDC211FD81D4D92807583EDC48C18EC281DA4D716BCDD74E7ABDFDFE03330`

Size: 4,047,391 bytes. ZIP extraction test passed with 16 files.

Scope: current-state survival audit for P03 using the P08-fixed cumulative baseline. No new P03 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source:

- `source/Noether_P03_Zur_Invariantentheorie_DMV19_1910_pp101_104_GDZ_article.pdf`

Verified survived in the P08-fixed cumulative:

- P03 starts at line 3499 with `\setcounter{footnote}{0}`; P04 starts at line 3538.
- P03 title/source note survives at line 3503.
- Publication line `Jahresbericht d. DMV 19 (1910), S. 101--104` survives at line 3507.
- Opening Study and dissertation source notes survive at line 3513.
- Symbolic faltung no-fix trap survives at line 3513: `$s_x t_x u_\sigma u_\tau$`, `(stu)`, and `(\sigma\tau x)`.
- Formula (1) no-fix trap survives at line 3521.
- RA57 formula (2) inequality correction survives at line 3530: `\rho=\sum_i\rho_i\le n`.
- Noether/Faber page-continuity trap is carried forward: the terminal source page continues with a Georg Faber article after Noether; do not import that as P03 continuation.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

Still open: this is not full P03 page-by-page certification. It proves survival of known RA57/RA80 repairs and no-fix decisions in the current text baseline.

## 2026-06-24 - R123+P08 P02 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P02_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `3B1F049D456D6DBC99D3D0AF1678C39276F4297EC8778D29E78401B7ECE4E009`

Size: 3,940,063 bytes. ZIP extraction test passed with 19 files.

Scope: current-state survival audit for P02 using the P08-fixed cumulative baseline. No new P02 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source evidence:

- `source_evidence/P02_key_scan.pdf`
- `source_evidence/P02_printed_p066_slice1of3_1000dpi_Lj_Lj2_source_no_patch.png`

Verified survived in the P08-fixed cumulative:

- P02 starts at line 439 with `\clearpage`; P03 starts at line 3499.
- RA80 article-boundary `\setcounter{footnote}{0}` survives at line 440.
- P02 title/source note survives at line 453.
- Opening Gordan/Maisano/Pascal note begins at line 466.
- Old bad table literals remain absent by current-base literal search: `theta H^3u`, `a_eta(aLu)^2L_j`, and `a_eta H dot L`.
- RA65 `L_j^2` no-fix trap survives at line 2267, with the targeted 1000 dpi source evidence included.
- `KH^3u` source-valid contexts survive, e.g. line 2408.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

Still open: P02 is table-heavy and is not freshly certified cell-by-cell here. Any future P02 table/matrix adjudication must use 650+ dpi source pages or 1000+ dpi dense crops, not low-resolution images.

## 2026-06-24 - R123+P08 P01 survival audit cumulative web drop

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R123plusP08_P01_SurvivalAudit_Cumulative_WebDrop_20260624.zip`

SHA256: `9919E69D947C2A6DF0336970812D85AAC05A97CCD1933D270654C9296CA4A475`

Size: 3,752,803 bytes. ZIP extraction test passed with 15 files.

Scope: current-state survival/inheritance audit for P01 using the P08-fixed cumulative baseline. No new P01 TeX patch was applied.

Included cumulative baseline:

- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.tex`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.pdf`
- `cumulative_current/cum_de_R123_plus_P08_zy_fix_20260624.txt`

Included source:

- `source/p01_source_R101_360ppi.pdf`

Verified present in the P08-fixed cumulative:

- P01 center-title block at line 360.
- Pascal-footnote context at line 369.
- Pascal footnote displayed relations at lines 372--376.
- Opening module-formula flow context at lines 383--394.
- Faltung array at line 406.

Inherited audit context:

- R99/R101 records P01 as closed/dispositioned, including old Pascal-footnote alignment and module-flow repairs.
- This package preserves those ledgers and source witness for the web session.

Source-quality caveat:

- The included P01 source PDF has internal 360 ppi page images. It is the best staged local P01 witness found in this pass, but it is below the 650+ dpi fresh-check rule.
- Therefore this is not a fresh symbol-level P01 source certification. A better source witness should be used if P01 needs strict re-adjudication.

Carried-forward baseline fix:

- The package baseline already includes the P08 printed p097 `(zy)x+(xz)y` fix.

## 2026-06-24 - P33 Bologna matrix/notation repair on P30-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P33_Bologna_MatrixNotationRepair_R123plusP08P30_20260624.zip`

SHA256: `37D44EC58C2C9092FF05688BDBAE8178799E05F652CC1C440788C9D565DE23D8`

Size: 40,479,406 bytes. ZIP extraction test passed with 14 files.

Scope: targeted Paper 33 Bologna source pass, focused on title/opening/footnotes and the two matrix-display regions already isolated by the RA75 high-detail source crops. Baseline is the P30-repaired cumulative candidate.

Source authority:

- IA `attidelcongresso0002nico`, original JP2 leaves 0079--0081 for printed pp. 71--73, via the local RA75 source package.
- Included source witnesses are the three labelled inspection crops from RA75:
  - `P33_p071_title_opening_and_footnotes_1200dpi.png`
  - `P33_p072_operator_group_and_matrix_1200dpi.png`
  - `P33_p073_diagonal_matrix_and_closing_1200dpi.png`

Confirmed TeX fix:

- P33 p071 opening representation definition: source shows a fraktur group symbol in `der Gruppe ... werden Matrizen ...`; active cumulative had plain `$G$`. Patched to `$\mathfrak{G}$`.

No-patch visual dispositions:

- P33 p072 first matrix display: current editable `pmatrix` keeps source lower-triangular block shape with `B_1`, `B_2`, `A_{ik}`, dot run, and `B_r`.
- P33 p073 second matrix display: current editable `pmatrix` keeps source diagonal block shape with `C_1`, `C_2`, dot run, `C_s`, and trailing comma.

Build status:

- Rebuilt cumulative candidate with XeLaTeX successfully after the P33 patch.
- Updated text extraction from rebuilt PDF.

Still open:

- This is not a full P33 symbol-by-symbol certification; it is a targeted repair/display audit of the known-risk Bologna source block.

## 2026-06-24 - P34 GDZ400 title/footnote repair and weak OCR-locator audit

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P34_GDZ400_GrossGapAnchorAudit_R123plusP08P30P33_20260624.zip`

SHA256: `238C9FFA18587074BF42016D8A72356F02FD66722E0EC7715F6171D041EB3292`

Size: 5,117,921 bytes. ZIP extraction test passed with 120 files.

Scope: Paper 34, `Hyperkomplexe Größen und Darstellungstheorie`, Math. Z. 30 (1929), printed pp. 641--692.

Source authority:

- GDZ `PPN266833020_0030`, printed pp. 641--692, canvases 00000645--00000696.
- Staged full-page images are 400 ppi. This is the best local source witness found here, but it is below the 650+ strict certification floor.
- GDZ fulltext XML was downloaded for all 52 pages and used only as a locator layer.

Confirmed TeX fix:

- P34 p641: restored the source title block and author line, and moved the van der Waerden explanatory footnote from the end of the first paragraph onto the source title marker. Evidence: `source_witnesses/P34_GDZ_MathZ30_printed_p641_canvas00000645_fullres.jpg`.

Locator result:

- GDZ OCR is weak for this paper: exact current-text anchors were found on only 2 of 52 pages.
- This means the P34 OCR locator package is useful mainly as a warning and triage ledger, not as proof of completeness.

Build status:

- Rebuilt cumulative candidate with XeLaTeX successfully after the P34 p641 patch.
- Updated text extraction from rebuilt PDF.

Still open:

- P34 remains not certified page-by-page or symbol-by-symbol. Dense math/formula work must be visual against the best available source image, or postponed until a better than 400 ppi witness is found.

## 2026-06-24 - P35 MathNet600 source repair on P34-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P35_MathNet600_SourceRepair_R123plusP08P30P33P34_20260624.zip`

SHA256: `A6D7318A93296B594C500AD86FE679F8FE4DCFDC00FBFA43CAEF0F34C3356208`

Size: 24,684,044 bytes. ZIP extraction/open test passed with 34 entries.

Scope: Paper 35, `Über Maximalbereiche aus ganzzahligen Funktionen`, Recueil Mathématique de Moscou 36 (1929), printed pp. 65--72.

Source authority:

- MathNet `sm7340` standalone full-text PDF, 8 pages, source images at 600 ppi.
- Local R101 `p35_source.pdf` was checked as a comparator and found to contain only 360 ppi main page images.
- The MathNet witness is the best source found in this pass, but it remains below the 650 ppi strict certification floor. This is therefore a best-available repair, not final high-resolution certification.

Confirmed TeX fixes:

- P35 p65: restored the source variable family `x_1,\ldots,x_n` where the active cumulative had `z_1,\ldots,z_r`, and restored the finite generating family `f_1,\ldots,f_r` where it had collapsed to `f_1,\ldots,f_t`.
- P35 pp. 65--66: restored source-global full polynomial/function contexts to `u_1,\ldots,u_r` and `x_1,\ldots,x_n`, while preserving the theorem matrix range `i=1,\ldots,t`, `k=1,\ldots,n`.
- P35 pp. 67--68: restored the section 2 distinction between full `f_1,\ldots,f_r` and irreducible subsystem `f_1,\ldots,f_t`; restored `f_{t+1},\ldots,f_r`; corrected `t \leq r` to the source `t \geq 1`.
- P35 pp. 68--69: restored the source `\omega_1,\ldots,\omega_s` combination and integer multiplier `a H(u)` where the active cumulative had alpha-collapsed notation.
- P35 pp. 69--70: restored the source argumented formula lists
  `G_1(u_{t+1};u_1,\ldots,u_t),\ldots,G_{r-t}(u_r;u_1,\ldots,u_t)`
  and the corresponding starred `G_j^*` list. The active cumulative had compressed these to `G_j(u)` and barred `G` notation with the wrong `s-t` range.
- P35 p71: corrected the final exceptional-prime and lambda-product indices, including the product ending in `\lambda_s^{\alpha_s}`.

Build status:

- Rebuilt cumulative candidate with XeLaTeX successfully after the P35 patch.
- Current repaired cumulative PDF length after P35 is 457 pages.
- Updated text extraction from rebuilt PDF is included in the package.

Still open:

- P35 still needs a higher-than-650 ppi witness before strict final certification. No better-than-600 ppi source was found in this pass.

## 2026-06-24 - P36 GDZ600 source-style repair on P35-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P36_GDZ600_SourceStyleRepair_R123plusP08P30P33P34P35_20260624.zip`

SHA256: `FFC7AECBEBA942B9B2161019D104114D385A73EF30A61017C990B913C3ECEFC9`

Size: 5,939,412 bytes. ZIP extraction/open test passed with 18 entries.

Scope: Paper 36, `Idealdifferentiation und Differente`, J. Ber. d. DMV39 (1930), p. 17.

Source authority:

- GDZ/JDMV 39 original page image, canvas 0312, embedded 600 ppi.
- RA07 local `p36_scan.pdf` was checked as a comparator and contains only a 360 ppi collected-volume slice.
- The GDZ witness is the best source found in this pass, but still below the 650 ppi strict certification floor.

Confirmed TeX fixes:

- Bibliographic line restored from `J. Ber. d. DMV 39` to the collected-source `J. Ber. d. DMV39`.
- Source italics restored in the report paragraph: `\emph{Differentialquotient}` and `\emph{Ideals}`.

Build status:

- Rebuilt cumulative candidate with XeLaTeX successfully after the P36 patch.
- Updated text extraction from rebuilt PDF is included in the package.

Still open:

- This is a one-page best-available style/prose repair, not a final high-resolution strict certification.

## 2026-06-24 - P38 GDZ600 source repair on P36-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P38_GDZ600_SourceRepair_R123plusP08P30P33P34P35P36_20260624.zip`

SHA256: `492EB19CF2810F8A943F5195E0E881B11A5316E8D8872659928306FE2F1ACAFC`

Size: 34,671,857 bytes. ZIP extraction/open test passed with 35 entries.

Scope: Paper 38, R. Brauer, H. Hasse, E. Noether, `Beweis eines Hauptsatzes in der Theorie der Algebren`, Journal für die reine und angewandte Mathematik 167 (1932), pp. 399--404.

Source authority:

- GDZ/JRAM167 full-resolution page images for printed pp. 399--404, locally staged under `source_master_checks\P38_GDZ_JRAM167_1932_Brauer_Noether_Hasse\raw_fullres_gdz`.
- Images are 3792 x 5789/5790 and tagged 600 ppi.
- This is the best local witness found for this pass, but still below the 650 ppi strict floor; therefore this is a best-available source repair, not a full strict certification.

Confirmed TeX fixes:

- P38 p399: restored the source title/author block and the source footnote stating that H. Hasse undertook the drafting of the note.
- P38 p399: restored the source-style Hauptsatz statement and removed punctuation drift.
- P38 p399: moved the drafting footnote away from the later proof sentence; kept the source footnote about the order of the three reductions.
- P38 p400: restored Reduktion 2 wording, including `(die übrigens durch den Hauptsatz mitgelöst wird -- s. u.)`.
- P38 p400: changed the non-source Sylow field notation `X` back to source `\Sigma`, with `A_{\Sigma}` and `A_{\Sigma}\sim\Sigma`.
- P38 p400: restored the source proof sentence that the index is prime to `p` as a divisor of the Sylow field degree.
- P38 p400: restored footnote 4 and its `Zusatz während der Drucklegung` block in source order.
- P38 pp. 400--401: restored the historical setup paragraph for Reduktion 3.
- P38 p401: corrected the mathematically significant reversed Lambda chain to source `K=\Lambda_0>\Lambda_1>\cdots>\Lambda_r=\Omega` and restored the corresponding proof indices `A_{\Lambda_1}`, `A_{\Lambda_2}`, ..., `A_{\Lambda_r}`.
- P38 p401: restored the source Normensatz paragraph, including the Hilbert-Furtwängler special case, the displayed Normenrestsymbol, `A=(\alpha,Z)`, and the local-to-global norm conclusion.
- P38 p402: restored source wording for the Grundideal definition/proof and Satz 3 setup.
- P38 p402: restored the source-style prime decomposition/norm display.
- P38 pp. 402--403: corrected the proof of Satz 3 from non-source `\alpha` and `B_i` notation to source `\pi`, `\Delta_{\mathfrak P_i}`, and `d_{\mathfrak P_i}`.
- P38 p403: restored the omitted divisibility calculation involving `(m_{\mathfrak p}/d_{\mathfrak P_i}, f_{\mathfrak P_i}/d_{\mathfrak P_i})=1`.
- P38 p403: corrected Satz 4 from the global non-source `A^f\sim\Omega` to the source local condition `A_{\mathfrak p}^{\,f}\sim\Omega_{\mathfrak p}`.
- P38 pp. 403--404: restored source group notation `\mathfrak K`, `\mathfrak K'`, and `\mathfrak A`, source Normenrestsymbol displays, and Satz 5 source order/notation.
- P38 p404: restored source notation for Satz 6, including `\mathfrak G`, group ring `G`, representations `\Gamma_i`, centers `\Omega_i`, and corrected the source discriminant statement from the cumulative's `n^h` drift to source `n^n`.

Build status:

- Rebuilt cumulative candidate with XeLaTeX successfully after the P38 repair.
- Current repaired cumulative PDF length after P38 is 458 pages.
- Pass 2 has no undefined-reference warning for the new repeated-footnote anchor.
- Updated text extraction from rebuilt PDF is included in the package.

Still open:

- P38 has now had source-certain repairs across pp. 399--404, but this remains a best-available 600 ppi pass, not a strict 650+ certification.
- A higher-than-600 ppi witness would still be preferable for strict dense-symbol certification.
- Translation lanes should rebase on this repaired German before trusting P38.

## 2026-06-24 - P39 ICM1932 600ppi source repair on P38-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P39_ICM1932_600ppi_SourceRepair_R123plusP08P30P33P34P35P36P38_20260624.zip`

SHA256: `3F9EA3B45ABFA7A7CCF86380EE29CF1C2CBD95D66066FD82D17D6D5DB52ACDBA`

Size: 10,101,998 bytes. ZIP extraction/open test passed with 26 entries.

Scope: Paper 39, `Hyperkomplexe Systeme in ihren Beziehungen zur kommutativen Algebra und Zahlentheorie`, Verhandl. Intern. Math.-Kongress Zurich 1 (1932), printed pp. 189--194.

Source authority:

- Official six-page ICM1932 cutout staged at `source_master_checks\P39_MathUnion_ICM1932_Hyperkomplexe_Systeme\P39_ICM1932_official_cutout_pdfpages197_202_printed189_194.pdf`.
- Embedded page images are 600 ppi. This is the best staged witness for this pass but below the local 650+ strict-certification floor, so the pass is a best-available source repair rather than final dense-symbol certification.

Confirmed TeX fixes:

- P39 p189: removed the non-source final period from the title.
- P39 p189: corrected the author line from the wrong `Von Emmy Noether in Bryn Mawr (U.S.A.).` to source `Von Emmy Noether, Göttingen`.
- P39 p189: corrected `Princip` to source `Prinzip` and restored source italics on the principle sentence beginning `Man sucht...`.
- P39 p189: restored source wording/styling in the crossed-product principle sentence: `durch die gleichzeitige Betrachtung von Körper und Gruppe` and source quotation marks around `verschränkten Produkts`.
- P39 p191: restored source italics on `Definition des verschränkten Produkts`.

Checked with no patch:

- P39 p192: `endlichvielen` is printed as one word in the source, so no patch.
- P39 pp. 191--194: formulas (1)--(5'), barred `\bar a`, `\mathfrak J`, `\Gg^\ast`, and Hauptgeschlecht expressions already survived from the earlier P39 repair in the current cumulative.

Build status:

- Rebuilt cumulative candidate with two XeLaTeX passes after the P39 patch.
- Current repaired cumulative PDF length remains 458 pages.
- Console-log scan found no fatal/emergency/undefined/missing-character/LaTeX-error rows in this pass.
- Package includes both the original carried filename and a clear P39-labelled duplicate cumulative TeX/PDF/TXT to avoid baseline confusion.

Still open:

- P39 still needs a higher-than-650 ppi witness before strict final certification. No better-than-600 ppi source was staged in this pass.

## 2026-06-24 - P40 GDZ400 source-apparatus repair on P39-repaired cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P40_GDZ400_SourceApparatusRepair_R123plusP08P30P33P34P35P36P38P39_20260624.zip`

Scope: Paper 40, `Nichtkommutative Algebra`, Math. Z. 37 (1933), printed pp. 514--541.

Source authority:

- GDZ full-resolution page images for printed pp. 514--541 staged under `Noether Multilingual\source_master_checks\P40_MathZ37_1933_Nichtkommutative_Algebren\raw_fullres_gdz`.
- These images are the best local witness currently available but are only 400 ppi, below the local 650+ strict floor. All P40 repairs in this pass are therefore best-available source repairs, not strict final certification.
- `p40_scan.pdf` and `p40_scan_pdftotext_layout.txt` were used as locator aids only; the actual repair decisions were checked against the GDZ page images.

Confirmed TeX fixes:

- P40 pp. 514--516: restored source article title, author line, opening framing, and source-style introduction through the start of §1.
- P40 pp. 514--516: restored source footnotes 1--7.
- P40 p518: restored source footnote 8 about nonabelian groups as generalized rings and H. Fitting.
- P40 p519: restored source footnote 9 on `Produktring`, including the ring-of-integers example with `2x-1=0`, `2y-1=0`, and `(2x-1)y-x(2y-1)=0`.
- P40 p525: restored source footnote 10 about extension of the paragraph's theorems by well-ordering arguments and the Köthe reference.
- P40 p526: restored source footnotes 11 and 12.
- P40 p527: restored source footnotes 13 and 14.
- P40 p528: restored source footnote 15 about the infinite-rank caveat.
- P40 p536: restored source footnote 20, `R. Brauer--E. Noether, a. a. O.`

Build status:

- Rebuilt cumulative candidate with two XeLaTeX passes after the P40 apparatus patch.
- Current repaired cumulative PDF length is 459 pages.
- Console-log scan found no fatal/emergency/undefined/missing-character/LaTeX-error rows.
- Package includes a clear P40-labelled cumulative TeX/PDF/TXT copy, the raw GDZ page images and metadata, source-page map, diff, confirmed-fix ledger, footnote-status ledger, open-items ledger, compile logs, and checksums.

Still open:

- P40 is not closed. The active body text remains visibly compressed in places and needs page-by-page source rebuild/audit from printed pp. 514--541.
- Footnotes 8--10 were placed at nearest stable anchors in the compressed current text; during full body rebuild, relocate them exactly to source sentence positions.
- Later existing footnotes 16--19 and 21--22 were carried forward after numbering correction, but still need full source recheck during P40 closure.
- Higher-resolution source should replace the 400 ppi GDZ witness if found.

## 2026-06-24 - P40 GDZ400 body repair 001 on P40-apparatus cumulative

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P40_GDZ400_BodyRepair001_p517_520_R123plusP08P30P33P34P35P36P38P39_20260624.zip`

SHA256: `9D273A43C9FC7DF6982F582128F01A0D8E5FE88475B099EA5448A512B310B5E9`

Size: 15,799,620 bytes. ZIP extraction/open test passed with 28 files.

Scope: P40 printed pp. 517--520, first body-text repair tranche after the P40 source-apparatus restoration.

Source authority:

- Same GDZ Math. Z. 37 raw page images for printed pp. 514--541 as the P40 apparatus package.
- The images used here for pp. 517--520 are best local source but only 400 ppi. Repairs are best-available source repairs, not strict 650+ dense-symbol certification.
- `p40_scan.pdf` and `p40_scan_pdftotext_layout.txt` remain locator aids only.

Confirmed TeX fixes:

- P40 p517: corrected the heading to source `Par. 1. Automorphismen, Moduln und Doppelmoduln`, removing non-source `Ueber`.
- P40 p517: restored the missing proof paragraph after formula (1a), including the anti-isomorphism relation and the convention on operating directions.
- P40 pp. 517--518: restored the missing bridge after formulas (2) and (2*) and the source paragraphs explaining the Abbildungsschlussweise for ring homomorphisms.
- P40 pp. 519--520: restored the compressed Produktring theorem proof and construction, including the product-ring element formula and its action on module elements.
- P40 p520: restored the source transition into Par. 2 before the Linearformenmodul definition.

Build status:

- Rebuilt cumulative candidate with two XeLaTeX passes after the P40 body001 patch.
- Current repaired cumulative PDF length is 459 pages.
- Console-log scan found no fatal/emergency/undefined/missing-character/LaTeX-error rows.
- Package includes a clear P40-body001-labelled cumulative TeX/PDF/TXT copy, raw GDZ images for pp. 514--520, source cutout/OCR locator, diff, confirmed-fix ledger, open-items ledger, compile logs, and checksums.

Still open:

- P40 printed pp. 521--541 still need page-by-page source rebuild/audit.
- Later existing footnotes 16--19 and 21--22 still need source placement/content recheck during full P40 closure.
- P40 should be recertified against a higher-than-400 ppi witness if one appears.

## 2026-06-24 - R124 intake and P40 rebase through printed p523

Incoming web package: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\Noether_R124_20260624.zip`

Incoming SHA256: `A152CCBB411767A7D3E9B44D6B7D81E5BDBDAEFCF539FD2ECC5EE9531D726F93`

Incoming status:

- R124 provides canonical `1/01_de/cum_de_R124.tex`.
- R124 absorbed web/local P16/P20/P30/P34/P39-related work and ledgers.
- R124 still contains the compressed P40 scaffold: source title/apparatus absent, non-source `§1. Über Automorphismen...` heading present, and Par. 2 representation theory compressed.

Rebased package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_P40_GDZ400_Rebased_BodyRepair002_p514_523_20260624.zip`

Rebased package SHA256: `C367DF1ADDBD42D82D89ED5457730201D332A95500A300516EBF9625FCE7A75B`

Size: 46,633,532 bytes. ZIP extraction/open test passed with 70 files.

Method:

- Treated R124 as the new incoming authority.
- Replaced exactly the R124 P40 block, from `\section*{40...}` up to before `\section*{41...}`, with the local source-repaired P40 block through printed p523.
- Preserved all non-P40 R124 material.
- Recompiled the R124-rebased candidate with `lualatex`; output PDF has 457 pages.
- Final compile-log scan found no fatal error, emergency stop, undefined control sequence, missing-character report, or LaTeX error.

Confirmed content rebased onto R124:

- P40 pp. 514--516: source title/author/opening and footnotes 1--7.
- P40 p517: source heading and proof after (1a).
- P40 pp. 517--518: source bridge after (2)/(2*) and Abbildungsschlussweise paragraphs.
- P40 pp. 519--520: Produktring theorem proof/construction and Par. 2 transition.
- P40 pp. 520--523: Par. 2 representation-theory block, including Satz 1, Satz 1', Satz 2, transition theorem, theorem on commuting matrices, and remarks.
- Bundled full local GDZ 400 ppi P40 source images for printed pp. 514--541.

Still open after R124 rebase:

- Continue P40 from printed p524 onward.
- Source is still best-available GDZ 400 ppi, not strict 650+ certification.
- Later existing footnotes 16--19 and 21--22 still need final source placement/content recheck.
- P41--P43 untouched by this rebase.

## 2026-06-24 - R124 P40 body repair through printed p529

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_P40_GDZ400_BodyRepair003_p524_529_20260624.zip`

Base: `Noether_R124_P40_GDZ400_Rebased_BodyRepair002_p514_523_20260624`

Method:

- Continued from the R124-compatible P40 repair, not from the older pre-R124 draft.
- Opened and visually checked GDZ full-resolution source pages for printed pp. 524--529.
- Used OCR only as a locator and line-order sanity check.
- Preserved R124 outside the P40 block.

Confirmed repairs:

- P40 p524: expanded the source definition/proof of `2. Erweiterungsmodul`.
- P40 p524: restored Folgerung a) parenthetical basis argument and Folgerung b) proof.
- P40 pp. 524--525: expanded `3. Satz über invariante Moduln`, including the Hilfssatz proof, normal-basis coefficient comparison, and \(T=L\cap M\); moved the Köthe footnote to the source position.
- P40 pp. 525--526: rebuilt §4 opening and `Erweiterungssatz` source sequence.
- P40 pp. 526--527: expanded representation-class theorem, rank relation, and sharpened rank relation block.
- P40 pp. 527--528: rebuilt §5 opening, reducible/irreducible embedding, and inner-automorphism theorem with footnotes 13--15.
- P40 pp. 528--529: expanded centralizer theorem and sharpened commutation theorem; distinguished paired/overlined centralizer notation where source requires it.
- P40 p529: removed the artificial `\clearpage` before §6 so the §5/§6 boundary follows the source page flow.

Build status:

- Recompiled cumulative German candidate with two `lualatex` passes.
- Output PDF has 457 pages.
- Log scan found no fatal/emergency/undefined/missing-character/LaTeX-error rows.
- Rendered QA checks cover output PDF pages 373--376.

Still open:

- Continue P40 from printed p530 onward.
- Current P40 source remains GDZ 400 ppi: best-available source repair, not strict 650+ high-resolution certification.
- English/other-language lanes are not synchronized to this P40 body003 repair.
## 2026-06-24 - R124 P40 BodyRepair004, printed pp. 530-533

- Base: `Noether_R124_P40_GDZ400_BodyRepair003_p524_529_20260624`.
- New package folder: `Noether_R124_P40_GDZ400_BodyRepair004_p530_533_20260624`.
- Source checked: GDZ full-resolution JPEGs for P40 printed pp. 530-533.
- Source-quality caveat: local GDZ witness is 400 ppi, below the preferred 650+ ppi source-checking threshold. This is a best-available-source repair, not strict final certification.
- Confirmed fix: §7 opening Brauer-class theorem block on printed pp. 532-533.
- Details: corrected \(A_f\times_P B_g=C_h\) to \(A_r\times_P B_s=C_t\); corrected the following multiplication reference from \(A_f,B_g\) to \(A_r,B_s\); restored a source-style separate `Satz von R. Brauer` heading; corrected inverse-class notation to \((A)^{-1}\); corrected final specialization from \(A_A=P_f\) to \(A_A=P_t\).
- Build: LuaLaTeX two-pass compile succeeded; output PDF has 457 pages; second log has no fatal errors, emergency stops, undefined control sequences, LaTeX errors, or missing-character hits.
- Next sequential target: continue P40 from printed p. 534 on the BodyRepair004 cumulative candidate.

## 2026-06-24 - R124 P40 BodyRepair005, printed pp. 534-541

- Base: `Noether_R124_P40_GDZ400_BodyRepair004_p530_533_20260624`.
- New package folder: `Noether_R124_P40_GDZ400_BodyRepair005_p534_541_20260624`.
- Source checked: GDZ full-resolution JPEGs for P40 printed pp. 534-541.
- Source-quality caveat: local GDZ witness is 400 ppi, below the preferred 650+ ppi source-checking threshold. This is a best-available-source repair, not strict final certification.
- Confirmed fixes:
  - p. 534: corrected the general rank-relation sentence from `A_Z\simeq D_l`/center `Z` to source `A_L\sim D`/center `L`.
  - p. 535: corrected the separable splitting-field proof indexing from the erroneous `Z_1/Z_2` chain to the source `Z_0/Z_1` chain.
  - p. 538: restored the source scalar equations and full matrix identity for complementary bases.
  - p. 541: corrected `P(\sqrt2)` to `P(\sqrt[3]{2})`.
  - p. 541: restored source radical/extension-ideal notation `\mathfrak C` / `\mathfrak c` and quotient notation.
- Build: LuaLaTeX two-pass compile succeeded; output PDF has 457 pages; second log has no fatal errors, emergency stops, undefined control sequences, LaTeX errors, or missing-character hits.
- Status: this reaches the end of P40 in the local source-repair lane. P40 still needs high-resolution final certification if a 650+ ppi witness becomes available.

## 2026-06-24 - R124+P40 P09-P20 prior-fix survival audit

- Package folder: `Noether_R124plusP40_P09_P20_SurvivalAudit_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Method: line-range mechanical survival checks against the live R124+P40 candidate, using the prior source-certified P09-P20 fix ledgers as the target list. This was not treated as a fresh page-by-page certification and did not use OCR as authority.
- Result: no new TeX body patch applied. All checked prior P09-P20 repairs survive in the live candidate.
- Confirmed surviving lanes:
  - P09 source-visible author line and Zermelo `S. 484`.
  - P10 author line, `k_\sigma`, and `F(t;\vartheta_i)`.
  - P11 author line, `\Omega_\Gamma`, and final semicolon phrase.
  - P12 author line, `f(x;dx)`, `d\delta x`, `\bdelta x`, and formula (11) comma.
  - P13 Klein dedication, author line, `endgiltige`, Heun reference, `\alpha/\beta/\gamma` footnote indices, and dense Klein/Einstein anchor.
  - P14 `mod. (z-c)`, ideal exponents `\rho_1...\rho_\sigma`, and polygon exponents `\rho,\sigma`.
  - P15 Latin `x` index family and Schur `S. 355 (1912)`.
  - P16 `F` not `\Phi`, plus `\alpha_1,\alpha_2,\alpha_\lambda` coefficient formula.
  - P17 non-source continuation scaffold remains absent.
  - P18 Hentzelt best-available/no-patch anchor survives.
  - P19 congruence-order and elementary-divisor index repairs survive.
  - P20 `\kappa/\lambda` formula (13) repair and formula tag `(12)` survive.
- Carried-open item: RA85-style top-level section anchors for P09-P13/P15 remain a style/indexing policy issue. The visible paper titles survive, but reapplying RA85 naively would duplicate titles. Do not silently treat this as a mathematical source defect.

## 2026-06-24 - R124+P40 P10 RA57 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P10_RA57Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 10 only, current live line block 7647--7845.
- Result: no new TeX body patch. This pass exists to prevent replaying stale or conflicting P10 fixes.
- Confirmed survival:
  - P10 title/frontmatter author line is present.
  - P10 has 16 occurrence-level `\srcfn` source-local footnote markers, matching RA57's stated marker-conversion count.
  - Source-confirmed definition (d) keeps `k_\sigma` and not `k_\nu`.
  - Source-confirmed p. 541 display keeps `H(t;a_i(\vartheta))=F(t;\vartheta_i)\cdot G(t;\vartheta_i)`.
  - Final date `Erlangen, 30. Oktober 1915` is present.
- No-fix trap recorded: RA57 standalone has a comma-separated `\psi(\vartheta_{k_1},\ldots,\vartheta_{k_\sigma})` variant in definition (d), but the older raw-GDZ source audit records the source reading without comma separators and with `k_\sigma`. The current R124+P40 candidate matches that source-audit reading; do not replay the RA57 comma-separated variant without a fresh high-resolution source check.
- Source-quality note: this was a survival/no-new-patch audit against existing source-audit artifacts, not a fresh page-by-page certification. The earlier P10 GDZ source package contains the targeted 1000 dpi labelled crops for the source-critical P10 fixes.

## 2026-06-24 - R124+P40 P11 RA58 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P11_RA58Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 11 only, current live line block 7846--8049.
- Result: no new TeX body patch.
- Confirmed survival:
  - P11 source-visible author line is present.
  - P11 has 15 occurrence-level `\srcfn` source-local footnote markers, matching RA58's stated marker-conversion count.
  - P11 has 25 occurrences of source-confirmed `\Omega_\Gamma` and zero stale `\mathfrak L_\Gamma` occurrences.
  - Numbered formulas (1)--(12) are present as left-labelled array displays; no right `\tag{...}` occurrences were found in the P11 block.
  - Formula (11) retains plain `G_k/H_k` and `H_k\cdot\sigma_k=G_k`; no prime notation was introduced.
  - The final theorem paragraph retains the source semicolon in `konstruieren; ihre Mannigfaltigkeit`.
- No-fix traps recorded: do not replace `\Omega_\Gamma` with stale Lagrange-symbol variants, and do not introduce primes into formula (11) without fresh source evidence.
- Source-quality note: RA58 calls P11 full page-level closure, but the staged full-page GDZ witness is 400 ppi. Under the current rule this is best-available/prior-audit survival, not strict 650+ final certification. The older RA56/P11 package contains targeted 1000 dpi crops for exact P11 source-critical loci.

## 2026-06-24 - R124+P40 P12 RA59/R122 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P12_RA59_R122Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 12 only, current live line block 8050--8448.
- Result: no new TeX body patch.
- Confirmed survival:
  - Opening definition `f(x;dx)=f(x_1,\ldots,x_n;\,dx_1,\ldots,dx_n)` remains inline in prose, matching the later R122 source reconcile and avoiding the stale RA59 display-promotion trap.
  - Formulae (1)--(14) each occur exactly once as `\srcnumdisplay` source-numbered displays, with zero `\tag{...}` occurrences in the P12 block.
  - The `d\delta x` / `\bdelta x` barred-delta repairs survive.
  - Formula (11) keeps the source-confirmed comma after `u_i=(t-t_0)(dx_i/dt)_0`.
  - Formula (12) does not add the stale RA59 final period after the terminal ellipsis.
  - Formulae (13)--(14) are present, with the final period after formula (14) retained.
  - The final sentence `Eine ausführlichere Darstellung soll demnächst in den Math. Annalen erscheinen.` survives.
- No-fix traps recorded: do not replay RA59's display promotion of the opening inline definition, and do not replay RA59's final period after formula (12), without a fresh higher-resolution source check.
- Source-quality note: P12 full-page GDZ/IIIF witnesses are best-available but only 400 ppi; older exact-locus crops are readability aids derived from that source. This pass is a survival/no-new-patch audit, not strict 650+ full-page certification.

## 2026-06-24 - R124+P40 P13 RA48/R122 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P13_RA48_R122Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 13 only, current live line block 8449--9057.
- Result: no new TeX body patch.
- Confirmed survival:
  - Dedication `(F. Klein zum fünfzigjährigen Doktorjubiläum.)` and author line `Von Emmy Noether in Göttingen.` survive.
  - Source spelling `endgiltige` survives; normalized `endgültige` is absent from the P13 block.
  - The Lie footnote includes the bracketed citation `[zitiert ``Grundlagen'']`.
  - The suppressed-index footnote example has `\p^2u_\alpha/\p x_\beta\p x_\gamma`; the stale `\nu/i/k` variant is absent.
  - The Heun Zentralgleichung prose says `von Heun sogenannten`; the nonsensical `von Herrn` variant is absent.
  - The derivative display uses fixed `x_\kappa` and summation index `\lambda`.
  - The source-no-fix line `u_i=v` at the section 4 initial-system locus survives; unrelated `v_i` occurrences elsewhere are not this trap.
  - The Einstein/Klein formula (30) footnote uses `\mathfrak{R}_{\mu\nu}g_\tau^{\mu\nu}` and derivative numerator `g^{\mu\nu}\mathfrak{R}_{\mu\tau}`; stale `g_{\mu\nu}^{\alpha\beta}` forms are absent.
- Included targeted witnesses: seven RA48 P13 1000 ppi labelled crops plus two R122 P13 1000 dpi labelled crops for the exact checked loci.
- No-fix traps recorded: do not modernize `endgiltige`, do not alter the specific `u_i=v` no-fix line to `u_i=v_i`, and do not call the package a full page-by-page P13 certification.

## 2026-06-24 - R124+P40 P14 RA55/RA78 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P14_RA55_RA78Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 14 only, current live line block 9058--9286.
- Result: no new TeX body patch.
- Confirmed survival:
  - Article-local footnote reset survives before P14.
  - Printed p. 190 source repair `mod. (z-c)` survives.
  - Printed p. 198 ideal factorization repair `\fra=\frp_1^{\,\rho_1}\cdots\frp_\sigma^{\,\rho_\sigma}` survives.
  - Printed p. 200 polygon exponent repair `\calA\calN^\rho` with `\calB\calN^\sigma` and `(\rho\ne\sigma)` survives.
- Included targeted witnesses: three RA55 1000 dpi labelled crops for p. 190, p. 198, and p. 200.
- Carried structural note: P14 is represented by a center-title block rather than a top-level `\section*{14...}` anchor in the current cumulative. This is an indexing/style risk, not a mathematical source defect.
- No-fix traps recorded: do not revert `z-c`, do not revert the `\rho_1...\rho_\sigma` family, and do not replace polygon exponents `\rho,\sigma` with stale variants.

## 2026-06-24 - R124+P40 P15/P16 RA54/RA53/RA78 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P15_P16_RA54_RA53_RA78Survival_NoNewPatch_20260624`.
- ZIP: `Noether_R124plusP40_P15_P16_RA54_RA53_RA78Survival_NoNewPatch_20260624.zip`.
- ZIP SHA256: `A721A644349EB3F5B6ACF6166C27CB8EFE1E151E10AA8FCBBE3D480D7A1BDF2D`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 15 current live line block 9287--9917; Paper 16 current live line block 9918--10082.
- Boundary note: Paper 17 starts after the `\clearpage` at line 10083 and custom metadata begins at line 10085, so the P16 audit stops at the acceptance date on line 10080.
- Result: no new TeX body patch.
- Confirmed P15 survival:
  - Article-local footnote reset survives immediately before P15.
  - RA54 Latin-index repair survives: the printed p. 152 normalization block uses `x_1,\ldots,x_{\rho+\sigma}` and `\xi_{x_1,n-1}\cdots`.
  - RA54 Schur citation repair survives: `Math. Ann. 71, S. 355 (1912)`, not `S. 555`.
  - Known no-fix traps survive: `(n,n-1)\not\equiv0\pmod p`, the exceptional `\begin{pmatrix}\frS&0\\0&0\end{pmatrix}` block-matrix footnote apparatus, and the carried Gordan-Kerschensteiner `S. 132` citation trap.
- Confirmed P16 survival:
  - Article-local footnote reset survives immediately before P16.
  - RA53 printed p. 30 source repair survives: `linear zusammensetzen aus $F$ und aus Formen aus $M$`, not `\Phi`.
  - Known no-fix traps survive: opening `\Omega`-Prozess, formula (1)/(2) `[identisch in x,y]`, formula (3) `[identisch in \xi]`, formula (9) `k_\lambda-\lambda+1=i`, unstarred determinant notation, and the `Berichtigungen`/`(Angenommen September 1919.)` block.
- Included targeted witnesses: P15 p. 152 and p. 154 1000 dpi labelled crops, plus P16 p. 30 1000 dpi labelled crop and full p. 30 1000 dpi page witness.
- Source-quality note: this is a survival/no-new-patch audit for already source-critical fixes and known OCR traps, not a fresh full page-by-page certification of Papers 15 and 16.

## 2026-06-24 - R124+P40 P17 RA52/RA77/RA94 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P17_RA52_RA77_RA94Survival_NoNewPatch_20260624`.
- ZIP: `Noether_R124plusP40_P17_RA52_RA77_RA94Survival_NoNewPatch_20260624.zip`.
- ZIP SHA256: `0E55E4F1487FA43D2B0ED06A0D9475876CE63142877CC94722AF575DBB662969`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 17 current live line block 10085--11229.
- Boundary note: Paper 18 begins after the Paper 17 `\endgroup`, `\clearpage`, and footnote reset; Paper 18 marker begins at line 11232.
- Result: no new TeX body patch.
- Confirmed survival:
  - RA77 title repair survives: full title includes `aus Differential- und Differenzenausdrücken`.
  - RA94 scaffold cleanup survives: no visible `Fortsetzung zu 17...` production label remains before §5.
  - RA52/RA77 footnote repairs survive at formula (39): explicit source footnotes 21 and 22 appear at the correct display anchors.
  - RA52 no-fix traps survive: formula (34) has `t_{ii}a_i=a_i`, formula (40) has `b_\rho\sim r_{\rho\sigma}a_\sigma` and `a_\sigma\sim r^{\sigma\rho}b_\rho`, and the finite rest-group example retains `\xi_1^2,\xi_2^2`.
  - Final Göttingen date and received date survive before the paper closes.
- Included witnesses: full P17 source PDF, page-25 source slice, RA52 formula/footnotes 21--22 localized 1000 dpi rendered witness, and RA94 §5-transition 650 dpi rendered witness.
- Source-quality note: local ledgers identify the best known complete P17 source as native 600 ppi, below the strict 650+ rule. The included 1000/650 dpi images are localized render aids from that 600 ppi source, so this package is best-available survival evidence, not strict full-paper certification.

## 2026-06-24 - R124+P40 P18 GDZ600/RA51 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P18_GDZ600_RA51Survival_NoNewPatch_20260624`.
- ZIP: `Noether_R124plusP40_P18_GDZ600_RA51Survival_NoNewPatch_20260624.zip`.
- ZIP SHA256: `4F9D077C1A69E45D67BCC3369A2DBD130D58FDB3FB18EB8DDCEE7379D35FB4A3`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 18 Hentzelt conference note only, current live line block 11232--11256.
- Boundary note: the following `Idealtheorie in Ringbereichen` block begins only after a clearpage and footnote reset at lines 11257--11259; it is not part of the P18 one-page note.
- Result: no new TeX body patch.
- Confirmed survival:
  - Session/chair/title block and opening Hentzelt prose survive.
  - RA51 resultant-display correction survives: `R^{(n)}(x_n)\equiv 0(\mathfrak M)`, not equality and not `R^{(m)}`.
  - Uniqueness sentence and final primary-decomposition paragraph survive.
- Included witnesses: GDZ JDMV 30 p. 101 600 ppi JPG and local PDF made from the same canvas.
- Source-quality note: staged source is 600 ppi, below the strict 650+ rule; the prior closure treated it as a best-available exception for this one-page note. This R124+P40 pass verifies survival of that closure and of the RA51 fix.

## 2026-06-24 - R124+P40 P19/P20 IA400 RA50/RA49 survival audit, no new patch

- Package folder: `Noether_R124plusP40_P19_P20_IA400_RA50_RA49Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 19 current live block starts at line 11261 and ends at accepted-date line 12438; Paper 20 current live block starts at line 12443 and ends at accepted-date line 12670, followed by clearpage line 12673.
- Result: no new TeX body patch.
- Source upgrade carried forward:
  - P19 IA MA83 article cutout: printed pp. 24--66 = IA leaves 29--71 = IA PDF pp. 30--72.
  - P20 IA MA85 article cutout: printed pp. 26--33 = IA leaves 35--42 = IA PDF pp. 36--43.
  - IA metadata/scandata records native 400 ppi; useful as clean paper-level witnesses but below the strict 650+/1000 dpi certification rule.
- Confirmed survival:
  - P19 printed p. 58 RA50 order repair survives at current line 12163: `Wegen \ideal Q\eqzero{\ideal P}, \ideal P^\rho\eqzero{\ideal Q}`.
  - P19 printed pp. 65--66 RA50 exponent/index repair survives at current lines 12410--12416: `p^{s_1}...p^{s_\lambda}`, `p^{t_1}...p^{t_\mu}`, and `r_\nu=s_1\le\cdots\le s_\lambda\le r_\nu`.
  - P20 RA49 formula (13) repair survives at current lines 12598--12602: formula (13) uses `\varrho_\kappa` and `\sigma_\lambda`, while the following prose correctly retains `\varrho_\mu\sigma_\nu`.
- No-fix traps recorded: do not reverse the P19 p. 58 order, do not reopen the P19 elementary-divisor chain without a better witness, do not replace P20 formula (13) kappa/lambda indices with the following-prose mu/nu indices, and do not merge P21 into P20.

## 2026-06-24 - R124+P40 P09 RA56/RA85 standalone survival audit, no new patch

- Package folder: `Noether_R124plusP40_P09_RA56_RA85Survival_NoNewPatch_20260624`.
- Base audited: `Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.
- Scope: Paper 09 current live block line 6315 through clearpage line 7644; Paper 10 starts at line 7647.
- Result: no new TeX body patch.
- Confirmed survival:
  - Current R124+P40 already has a visible RA85-style `\section*{9...}` anchor at line 6315.
  - Printed centered title remains at line 6317, so no further visible title/section anchor should be inserted.
  - RA56 printed author line `Von Emmy Noether in Erlangen.` survives at line 6319.
  - RA56 Zermelo footnote page repair survives at line 6334 as `Math. Ann. 75, S. 484 (1914).`
  - RA56 no-fix traps survive: terminal `\xi_t` at line 7135, `\mathfrak M_{\nu\kappa}` at line 7494, and `\mathfrak M_{\nu\kappa+1}` at line 7505.
- Included prior evidence: RA56 P09 critical TeX/PDF, page-check dossier, audit ledgers, and available source page images; RA85 section-anchor discussion.
- Source-quality note: prior RA56 reports mixed 400/600 ppi source pages and targeted 1000 dpi crops for exact loci, but the extracted local copy here does not expose a clean standalone crop folder. This is a current-base survival package plus prior evidence, not a fresh full-paper 650+/1000 dpi recertification.
## 2026-06-24 -- R124+P40 rebase of missing P35/P36/P38/P39 source repairs

R124 and the current Local Codex R124+P40 cumulative still had stale P35/P36/P38/P39 text even though local source-repair packages existed for those papers. I checked the actual TeX, not only the package self-reports. Concrete stale anchors included P35 still using `z_1,\ldots,z_r` and `f_1,\ldots,f_t`, P36 still using `J. Ber. d. DMV 39` and roman `Differentialquotient`, P39 still giving the title with a final period and the wrong Bryn Mawr author line, and P38 still using the reversed `K=\Lambda_r\supset\cdots\supset\Lambda_0=\Omega` chain.

Created:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624/`

The cumulative TeX is:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624/tex/cum_de_R124_plus_P35_P36_P38_P39_P40_repair_20260624.tex`

Method: compared the current R124+P40 TeX with the prior local repaired chain `Noether_P39_ICM1932_600ppi_SourceRepair_R123plusP08P30P33P34P35P36P38_20260624`. P37 was byte-identical between the two, so I replaced the whole P35-through-P39 span from the repaired chain into the current R124+P40 base. P40 remains the current R124+P40 completion; this did not roll P40 backward.

Build: LuaLaTeX pass 1 and pass 2 exited 0; final PDF is 457 pages. Anchor ledger and source context are packaged. Important caveat: P35/P36/P38/P39 best staged witnesses are 600 ppi, below the strict 650+ floor, so this is best-available source repair rather than strict 650+ certification.

## 2026-06-24 -- P34 hotspot dispositions after R124+P40/P35-P39 rebase

Created:

`Noether_R124plusP40_P34_HotspotDisposition_NoNewPatch_20260624/`

Scope was intentionally narrow: P34 printed p641 title/author/title-footnote/opening and printed p660 multiplication table. Source was the GDZ full-page image set for P34, which reports native 400 ppi. This remains below the 650+ source-check floor, so the result is best-available-source disposition only, not full P34 certification.

Results:

- p641: no new patch. The current rebased TeX already has the prior source title repair with `Von Emmy Noether in Göttingen` and the B. L. van der Waerden note attached to the title marker.
- p660: no patch. The current TeX multiplication table matches the visible source structure and entries: rows/columns `e_1,e_2,u` with entries `e_1,0,u / 0,e_2,0 / 0,u,0`.

P34 remains globally open for page-by-page audit; this package only prevents reopening these two hotspots as suspected defects.

## 2026-06-24 -- P11 current-base RA58/RA56 survival audit after R124+P35-P39/P40 rebase

Created:

`Noether_R124plusP35P39_P11_RA58_CurrentBase_NoNewPatch_20260624/`

Base audited:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624/tex/cum_de_R124_plus_P35_P36_P38_P39_P40_repair_20260624.tex`

Scope: Paper 11, `Gleichungen mit vorgeschriebener Gruppe`, current live block lines 7846--8045.

Result: no new TeX patch.

Confirmed survival in the current base:

- source-visible author line `Von Emmy Noether in Göttingen.`;
- 25 occurrences of `\Omega_\Gamma`;
- zero occurrences of stale `\mathfrak L_\Gamma`;
- 15 source-local `\srcfn` markers inside the P11 block;
- numbered displays `(1)` through `(12)` as source-style left-labelled array displays, with no right `\tag` form;
- formula `(11)` keeps source-confirmed plain `G_k/H_k` and `H_k\cdot\sigma_k=G_k`;
- final theorem paragraph keeps the source semicolon in `konstruieren; ihre Mannigfaltigkeit`.

No-fix traps carried forward: do not introduce primes into formula `(11)`, do not normalize the Tschirnhaus footnote coefficients on p228, do not replace source `Tschirnhausentransformation`, and do not silently fold the later Ostrowski erratum into the P11 body.

Source-quality caveat: prior RA58 labels P11 as full page-level closure, but the complete GDZ full-page article witness is below the current strict 650 ppi floor. The package therefore certifies survival of the exact known source-critical loci, with five targeted 1000 dpi witness crops, but does not assert fresh full-paper 650+ final certification.

## 2026-06-24 -- P12 current-base RA59/R122 survival audit after R124+P35-P39/P40 rebase

Created:

`Noether_R124plusP35P39_P12_RA59_R122_CurrentBase_NoNewPatch_20260624/`

Base audited:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624/tex/cum_de_R124_plus_P35_P36_P38_P39_P40_repair_20260624.tex`

Scope: Paper 12, `Invarianten beliebiger Differentialausdrücke`, current live block lines 8050--8445.

Result: no new TeX patch.

Confirmed survival in the current base:

- opening definition remains inline in prose: `f(x;dx)=f(x_1,\ldots,x_n;\,dx_1,\ldots,dx_n)`;
- three logical source-local notes survive: two direct `\srcfn` notes and one `\srcfnmark`/`\srcfntext` pair;
- barred-delta and `d\delta x` loci survive;
- formulas `(1)` through `(14)` each occur once as `\srcnumdisplay`, with no right-side `\tag` form;
- formula `(11)` keeps the source comma after `u_i=(t-t_0)(dx_i/dt)_0`;
- formula `(12)` ends with `\cdots` and no added final period;
- formulas `(13)` and `(14)` survive, with formula `(14)` retaining its period;
- the final sentence at lines 8444--8445 matches the RA59 source reading: `Eine ausführlichere Darstellung soll demnächst in den Math. Annalen erscheinen.`

No-fix traps carried forward: do not replay the RA59 display promotion for the opening `f(x;dx)` definition, do not add a final period after formula `(12)`, and do not call P12 globally strict-certified from the current staged source.

Source-quality caveat: P12 complete GDZ page images are best-available locally but report native 400 ppi. This package records current-base survival and improves the old final-sentence `check_needed` status to `survives`, but it does not assert strict 650+ full-paper certification.

## 2026-06-24 -- P10 current-base RA57 survival audit after R124+P35-P39/P40 rebase

Created:

`Noether_R124plusP35P39_P10_RA57_CurrentBase_NoNewPatch_20260624/`

Base audited:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624/tex/cum_de_R124_plus_P35_P36_P38_P39_P40_repair_20260624.tex`

Scope: Paper 10, `Die Funktionalgleichungen der isomorphen Abbildung`, current live block lines 7647--7841.

Result: no new TeX patch.

Confirmed survival in the current base:

- title, author line, and source line survive;
- definition (d) keeps the source-confirmed no-comma product reading `z=\psi(\vartheta_{k_1}\cdots\vartheta_{k_\sigma})`;
- definition (d) also keeps `f(z)=\psi(f(\vartheta_{k_1})\cdots f(\vartheta_{k_\sigma}))`;
- no stale `\vartheta_{k_\nu}` substitution occurs in the P10 block;
- the factorization display survives as `H(t;a_i(\vartheta))=F(t;\vartheta_i)\cdot G(t;\vartheta_i).`;
- the final date `Erlangen, 30. Oktober 1915.` survives;
- 16 current `\srcfn` markers occur inside the P10 block.

No-fix traps carried forward: do not replay the RA57 standalone comma-separated `\psi(\vartheta_{k_1},\ldots,\vartheta_{k_\sigma})` variant into the cumulative; the prior source audit records the no-comma product reading and current TeX matches it. Do not use the old low-resolution RA57 page PNGs as fresh source authority.

Source-quality caveat: the best staged full-page P10 witness in this package is `P10_p540_GDZ_original_600dpi.png`, measured at about 600 ppi. This is below the strict 650+ page-check floor, so the package is a current-base survival/no-replay package rather than full fresh certification of every P10 symbol. Prior targeted 1000 dpi evidence remains the relevant support for the difficult formula loci.

## 2026-06-24 -- P30 MA96 complete IA JP2 source cutout

Created:

`Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624/`

Zip:

`Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624.zip`

Scope: Paper 30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, Mathematische Annalen 96 (1927), printed pp. 26--61.

Action: extracted the complete paper from the newly available Internet Archive raw JP2 volume ZIP `sim_mathematische-annalen_1927_96_jp2.zip`. The cutout maps printed pp. 26--61 to IA leaves 0031--0066 and includes raw JP2 files, native PNG conversions, a convenience PDF assembled from the native PNGs, IA metadata/scandata, and checksums.

Source-quality finding: this is a clean source-file acquisition, not a higher-resolution breakthrough. Sample raw JP2 pages identify as 2208 x 3372 px with undefined resolution metadata, matching the existing 400 ppi/native-detail class. Use this as the complete best-available P30 paper-level source witness, but do not claim strict 650+ full-page certification from it.

## 2026-06-24 -- P30 current-base source-page anchor audit

Created:

`Noether_P30_MA96_RemainingPages_CurrentBase_AnchorAudit_20260624/`

Zip:

`Noether_P30_MA96_RemainingPages_CurrentBase_AnchorAudit_20260624.zip`

Base audited:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624/tex/cum_de_R124_plus_P35_P36_P38_P39_P40_repair_20260624.tex`

Scope: Paper 30, current cumulative lines 14431--15638, printed pp. 26--61.

Result: no TeX patch in this pass.

Method: extracted OCR text from the IA DjVu XML for the complete P30 page span and compared source-page prose anchors against the current P30 TeX slice. OCR was used only as a locator layer, not as a symbol/formula authority. The first pass over-stripped TeX command arguments, so I reran with a safer normalizer and retained both ledgers for provenance.

Finding: gross prose anchors were found for 28 of 36 printed source pages. Eight pages still need visual/manual anchor or symbol-level review because OCR did not give a robust current-text anchor:

`36, 39, 42, 44, 47, 54, 59, 61`

These pages are not declared missing. They are the prioritized visual-audit pages against the complete IA JP2 source cutout. Since the source is still native 2208 x 3372 class, this remains below strict 650+ full-page certification.

## 2026-06-24 -- Incremental web-return wrapper P10-P12 plus P30

Created:

`Noether_R124plus_LocalCodex_Incremental_WebReturn_P10P12_P30_20260624.zip`

SHA256:

`D6D00CF00748DAB3D96F77C3F602CFDB435569625049C2508EF8BA59702BD355`

Purpose: one drag/drop wrapper for the newest local work after R124:

- P10/P11/P12 current-base no-new-patch survival packages;
- P30 complete IA JP2 source cutout package;
- P30 current-base source-page anchor audit package.

This wrapper is the preferred handoff ZIP if the web session needs the newest local Noether delta in one upload.
## 2026-06-24 -- P30 footnote 27/28 repair rebased on current R124+local cumulative

Package folder:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP35P39_P30_FootnoteRepair_p046_048_20260624\`

Baseline:

`Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624\tex\cum_de_R124_plus_P35_P36_P38_P39_P40_repair_20260624.tex`

Incoming web reference checked:

`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\Noether_R124_20260624.zip`

Finding: incoming R124 and the current local cumulative both still had the same P30 footnote defects around printed pp. 46--48.

Confirmed repairs:

- P30 printed pp. 46--47: expanded source footnote 27. The prior TeX retained only the first two sentences, omitting the general set-theoretic \(\Sigma\)-menge formulation and conclusion. Source witness: `P30_MA96_printed_p046_IA_leaf0051_native.png` and `P30_MA96_printed_p047_IA_leaf0052_native.png`.
- P30 printed p. 48: restored full source footnote 28 and moved it to the Satz III statement, where the source marker appears. The prior TeX shortened the Krull citation and placed the note after the following paragraph.

Build status: repaired cumulative compiled successfully in two LuaLaTeX passes. The repaired material appears on cumulative PDF page 287. Rendered check pages are included in the package.

Source-quality caveat: the complete IA/JP2-derived P30 witness is the best complete local source currently staged, but remains below the strict 650+ ppi certification floor. These are best-available-source footnote repairs, not full P30 certification.

## 2026-06-24 -- P30 p54 Axiom IV formula repair added to same R124+local web-return lane

Package folder:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP35P39_P30_FootnoteRepair_p046_048_20260624\`

Incoming web reference checked:

`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\Noether_R124_20260624.zip`

Finding: incoming Web R124 still had the P30 p54 formula defect. In §9, Axiom IV proof, the current TeX used an `r`-indexed null-ideal decomposition and a malformed contradiction display beginning with `\mpideal_1^{\varrho_1}`. Source pp. 53--54 show the product over `k` and the display beginning with `\mpideal_1^{\varrho_1+1}`.

Confirmed repair:

- P30 printed pp. 53--54: changed `(0)=\mpideal_1^{\varrho_1}\cdots\mpideal_r^{\varrho_r}` to `(0)=\mpideal_1^{\varrho_1}\cdots\mpideal_k^{\varrho_k}`.
- Replaced the following display with the source chain:
  `\mpideal_1^{\varrho_1+1}=(\mpideal_1^{\varrho_1+1},\mpideal_1^{\varrho_1}\cdots\mpideal_k^{\varrho_k})=\mpideal_1^{\varrho_1}(\mpideal_1,\mpideal_2^{\varrho_2}\cdots\mpideal_k^{\varrho_k})=\mpideal_1^{\varrho_1}`.

Source witnesses:

- `P30_MA96_printed_p053_IA_leaf0058_native.png`
- `P30_MA96_printed_p054_IA_leaf0059_native.png`

Build status: repaired cumulative compiled successfully in two LuaLaTeX passes after the p54 patch. The repaired formula appears on cumulative PDF page 291.

Source-quality caveat: the complete IA/JP2-derived P30 witness remains the best complete local source currently staged, but it is still approximately 400 ppi/native-detail class. The added p53/p54 crops are 2x readability enlargements from that source, not higher-resolution authority.

## 2026-06-24 -- P30 anchor-failure queue disposition and p61 received-date repair

Package folder:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP35P39_P30_FootnoteRepair_p046_048_20260624\`

Queue source:

`Noether_P30_MA96_RemainingPages_CurrentBase_AnchorAudit_20260624\audit\P30_pages_needing_visual_or_manual_anchor.csv`

Completed disposition for all eight OCR-anchor-failure pages: 36, 39, 42, 44, 47, 54, 59, 61.

No-new-patch dispositions:

- p36: corrected line mapping to §2 close / §3 opening; visual comparison found no source-certain TeX defect.
- p39: compared Funktionalbereich/Hauptideal paragraph, footnote 15, §4 opening, homomorphism definition, and footnote 16; no source-certain TeX defect found.
- p42: earlier visual pass found the direct-sum-definition wording source-faithful.
- p44: earlier visual pass found Hölzer footnote/exponent locus source-faithful.
- p59: compared the alpha--epsilon assumptions, 2α construction, displayed isomorphisms, and 2β comparison displays; no source-certain TeX defect found.

New repair:

- p61: source has `(Eingegangen am 13. 8. 1925.)`; current TeX omitted the parentheses and used an uncentered italic line. Patched to a centered parenthesized received-date line, matching local treatment of comparable received dates.

Build status: repaired cumulative compiled successfully in two LuaLaTeX passes after the p61 patch. The repaired received-date page appears on cumulative PDF page 295.

Source-quality caveat: all P30 queue dispositions use the best complete local IA/JP2-derived source, still approximately 400 ppi/native-detail class and below strict 650+ certification.
## 2026-06-24 - R124 post-web Local Codex delta wrapper for NASA/Web

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624.zip`

SHA256:

`44AEC971E09666E6CAC3C65B3D91CA7936D358A66622B6677F2BF8D740D435AD`

Size: 55,347,959 bytes. ZIP extraction tested, 48 files.

Purpose: give the current web/NASA session a single clean post-R124 upload object containing the local work that the incoming `Noether_R124_20260624.zip` did not yet carry in final form.

Contents:

- Unzipped P30 final repair folder: `Noether_R124plusP35P39_P30_AnchorQueueClosed_FootnoteFormulaDateRepair_20260624`.
- P10/P11/P12 current-base no-new-patch ZIPs, included as no-replay ledgers rather than new body patches.
- Copies of the R124 source queue, source-quality ledger, and closure ledger for baseline comparison.
- `README_FOR_NASA_WEB.md` and `03_status_ledgers/local_codex_post_R124_delta_summary.csv` explaining what is new, what is reference-only, and what should not be replayed.

Main P30 repair content in the wrapper:

- P30 printed pp. 46--47: restored full footnote 27.
- P30 printed p. 48: restored full footnote 28 and moved the marker to the Satz III statement.
- P30 printed pp. 53--54: corrected the Axiom IV display and contradiction chain, including `\rho_k` and the `p_1^{\rho_1+1}` start.
- P30 printed p. 61: corrected the centered received-date line.
- P30 flagged pages 36, 39, 42, 44, 47, 54, 59, 61: visual dispositions included, with no-patch traps where relevant.

Source-quality note: P30 still uses best-available local IA/GDZ witnesses at roughly 400 native-detail. The package labels enlarged crops as display enlargements, not new optical authority. This is a source-certain best-local repair, not a strict 650+ dense-math certification claim.

## 2026-06-24 - R124 post-web P09 dense hotspot no-patch package

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P09_p112_Hotspot_NoPatch_WebDrop_20260624.zip`

SHA256:

`79ACEEBF3B6A2970027B49B39DC02C82DB90CA264C9412EB01033ACF61A30FFB`

Size: 2,007,673 bytes. ZIP extraction tested, 7 files.

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP40_P09_RA56_RA85Survival_NoNewPatch_20260624\tex\cum_de_R124_plus_LocalCodex_P40Complete_20260624_REFERENCE_UNCHANGED.tex`

Result: no TeX patch. Paper 09 printed p. 112, GDZ canvas `00000118`, current TeX lines 6774--6785: the `f(z;a,\ldots,c)` display and the following coefficient display match the source structure and p. 112/p. 113 continuity.

Source-quality note: the source page staged locally is native 400 ppi. The labelled crop is a 2x readability enlargement, not a new optical 1000 ppi authority.

## 2026-06-24 - R124 post-web P10 dense hotspots no-patch package

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P10_DenseHotspots_NoPatch_WebDrop_20260624.zip`

SHA256:

`3254B587A79FD327D236705E8A1B2A97A1B369A4BC9E17A65E6338C3B37F4C67`

Size: 5,107,103 bytes. ZIP extraction tested, 11 files.

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP35P39_P10_RA57_CurrentBase_NoNewPatch_20260624\tex_slice\P10_currentbase_lines7647_7841.tex`

Result: no TeX patch. Paper 10 dense hotspot rows checked against GDZ printed pp. 536, 543, and 544: the functional equations (1)--(4), the rank-four determinant, the rank-four linear system, and the rank-two determinant/formula are present in the current base with source-faithful structure.

Source-quality note: the staged source pages used here are native 400 ppi. This package closes the listed dense-hotspot rows only; it is not a strict full-paper certification.

## 2026-06-24 - R124 post-web P12 dense hotspots no-patch package

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P12_DenseHotspots_NoPatch_WebDrop_20260624.zip`

SHA256:

`6EC29405DFD3DFD29CC4204D6CF24CEB9DC145762C863737DEA87BE3C94D890C`

Size: 9,758,393 bytes. ZIP extraction tested, 13 files.

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP35P39_P12_RA59_R122_CurrentBase_NoNewPatch_20260624\tex_slice\P12_currentbase_lines8050_8445.tex`

Result: no TeX patch. Paper 12 dense hotspot rows checked against GDZ printed pp. 37, 39, 40, and 41: the invariant-definition `J` display, formulas (2), (3), (4), (7), (8), and (9) match the source structures at the checked loci. The p. 40 witness also includes formulas (5) and (6) for continuity around (7).

Source-quality note: the staged source pages used here are native 400 ppi. The labelled crops are 2x readability enlargements from the best local witness, not higher optical authority. This package closes the listed dense-hotspot rows only; it is not a strict full-paper certification.

## 2026-06-24 - R124 post-web P04 pp. 140-145 no-patch source audit

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P04_pp140_145_SourceAudit_20260624.zip`

SHA256:

`D08366711D19E3648D70DB8FEBD4CD14FC7DA6696B6FB0A7517686B7A47DDB9A`

Size: 30,244,608 bytes. ZIP extraction tested, 15 files.

R124 queue row addressed:

`R120-Q-P04 | P04 | printed_page 140-145 | full-page audit excluding p152 exact locus`

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624\01_P30_repair_unzipped\tex\cum_de_R124_plus_P35_P36_P38_P39_P40_P30_footnote_repair_20260624.tex`

Result: no TeX patch. P04 printed pp. 140--145 were checked against the best staged Crelle 139 source cutout rendered at 1000 dpi. The checked loci include formulas (44)--(61), the Clebsch/Mertens/Study notes in the span, the p143 primed-p trap after the `\varphi'` display, and the p145 formula (59) Delta-alpha display.

No-patch traps recorded:

- p143: current `p^{\prime(...)}` represents the source primed-p notation after the `\varphi'` display; do not rewrite as a new symbol without a house-style decision.
- p145: formula (59) reads `(f)=\sum c\Delta^\alpha(\varphi)` and current TeX matches.

Source-quality note: these are 1000-dpi renders from the best staged source cutout PDF, not independent raw IA/JP2 authorities. OCR text was used only as a locator.

## 2026-06-24 - R124 post-web current Web-return wrapper

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_20260624.zip`

SHA256:

`C3003776FECFCC2BCC1B08955FD46CAB173F94FC5D491797C0A805A349DE4A31`

Size: 102,471,321 bytes. ZIP extraction tested, 8 files.

Purpose: one drag-and-drop wrapper for NASA/Web containing the main post-R124 Local Codex delta and the individual P04/P09/P10/P12 closure packages.

Included packages:

- `Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624.zip`
- `Noether_R124_PostWeb_P04_pp140_145_SourceAudit_20260624.zip`
- `Noether_R124_PostWeb_P09_p112_Hotspot_NoPatch_WebDrop_20260624.zip`
- `Noether_R124_PostWeb_P10_DenseHotspots_NoPatch_WebDrop_20260624.zip`
- `Noether_R124_PostWeb_P12_DenseHotspots_NoPatch_WebDrop_20260624.zip`

Use note: this wrapper does not add a new cumulative TeX beyond the P30 repaired cumulative already inside the main delta package. P04/P09/P10/P12 are no-patch audit closures.

## 2026-06-24 - R124 post-web P11 full-page best-available audit

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P11_FullPage_BestAvailableAudit_20260624.zip`

SHA256:

`C045DF586DAD7026605092DA08A739E8420DC86BF91AE4DE380EFA36982CB326`

Size: 15,866,364 bytes. ZIP extraction tested, 39 files.

R124 queue row addressed:

`R120-Q-P11 | P11 | full-page best-available audit`

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624\01_P30_repair_unzipped\tex\cum_de_R124_plus_P35_P36_P38_P39_P40_P30_footnote_repair_20260624.tex`

Result: one source-order TeX patch. On printed p. 228, the source gives

`\varphi_3(x)=\frac{w\cdot u}{v}`

while the active TeX had

`\varphi_3(x)=\frac{u\cdot w}{v}`.

The patched cumulative and P11 slice restore the printed order `w\cdot u`.

Page audit summary: printed pp. 221--229 were visually checked against the staged GDZ full-page images. Pages 221--227 and 229 required no patch. On p. 228, the strange repeated coefficient `a_2^3/a_3^2` in the footnote equation was confirmed as source-correct; only the `\varphi_3` product order was repaired.

Source-quality note: the best staged full-page authority is 400ppi GDZ IIIF. IA processed JP2 leaves for the same Math. Ann. 78 volume were downloaded and included as secondary witnesses, but they are also 400ppi/microfilm-derived. No 650ppi+ full-page P11 source was found in this pass, so this is a best-available closure, not a strict 650ppi certification.

## 2026-06-24 - R124 post-web P22 RA61-RA63 survival closure

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P22_RA61_RA62_RA63_SurvivalClosure_20260624.zip`

Purpose: verify that the older P22 RA61 no-patch audit and RA62/RA63 source-critical repairs survive in the newest R124 plus local P30/P11 cumulative base.

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P11_FullPage_BestAvailableAudit_20260624\03_tex\cum_de_R124_plus_P35_P36_P38_P39_P40_P30_P11_sourceorder_repair_20260624.tex`

Scope: Paper 22, printed pp. 53--79, `Bearbeitung von K. Hentzelt: zur Theorie der Polynomideale und Resultanten`, Math. Ann. 88 (1923), pp. 53--79.

Result: no new P22 TeX patch was applied. The RA61 checked/no-patch anchors remain valid, and the RA62/RA63 confirmed repairs are present in the current cumulative. In particular, the current base preserves the source-correct congruence signs in (21)--(22), the auxiliary `\mathfrak C` / `\zeta` families in (23), (24), (28), and (32), the Satz IX `\Nmod_{i-1}=(\Nmod^*_{i-1},\mathfrak C_{i-1})` correction, and the closing barred `\bar R^{(i)}(z,x)` specialization.

Package contents: current cumulative TeX, extracted P22 current-base span with line numbers, RA61/RA62/RA63 original ledgers, a new survival ledger, the older targeted 1000-dpi inspection crops, the older RA source PDF, and all 27 freshly downloaded GDZ full-page JPG witnesses for P22 printed pp. 53--79.

Source-quality note: the fresh GDZ full-page witnesses are the best local page authority found in this pass and are mixed 400/600 ppi. The older RA targeted crops are 1000-dpi inspection enlargements from a 360ppi embedded source PDF. Therefore this package is a source-aid/survival closure and should not be described as strict 650ppi page certification.

## 2026-06-24 - R124 post-web P29 RA71/GDZ400 survival closure

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P29_RA71_GDZ400_SurvivalClosure_20260624.zip`

Purpose: verify that the P29 RA71 source-header/footnote-counter repair survives in the newest R124 plus local P30/P11 cumulative base, and package the correct source witnesses so Web does not follow the old P29/P24 label confusion.

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P11_FullPage_BestAvailableAudit_20260624\03_tex\cum_de_R124_plus_P35_P36_P38_P39_P40_P30_P11_sourceorder_repair_20260624.tex`

Scope: Paper 29, printed pp. 28--35, `Der Endlichkeitssatz der Invarianten endlicher linearer Gruppen der Charakteristik p`, Nachr. v. d. Ges. d. Wiss. zu Göttingen 1926.

Result: no new P29 TeX patch was applied. The current base already has `\setcounter{footnote}{0}` before P29, the author line `Von Emmy Noether in Göttingen.`, and the Courant submission line in the opening block. The existing GDZ400 gross-gap audit also reports exact/high-fuzzy anchors for all eight source pages, so this is a survival/no-duplicate-work closure rather than symbol-level certification.

Package contents: current cumulative TeX, extracted P29 current-base span with line numbers, RA71 original ledgers/diff, gross-gap audit ledgers, all eight GDZ full-page source JPGs, the GDZ convenience PDF, and a trap note excluding the misnamed `noether_p29_ia_source_20260623` folder because that contains Math. Ann. 90 / P24 material, not P29.

Source-quality note: GDZ P29 full pages are native 400ppi. The 1200dpi crops are inspection enlargements from that 400ppi source. This package is therefore best-available survival/gross-gap closure, not strict 650ppi symbol certification.

## 2026-06-24 - R124 post-web current wrapper v2

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v2_with_P11_P22_P29_20260624.zip`

SHA256:

`6D71ADA0444ACFCE607DA6A91E014205D4B7C630A4DC6356537D0A6B36215D30`

Size: 211,343,727 bytes. ZIP extraction tested, 6 files.

Purpose: one drag-and-drop wrapper for Web/NASA containing the earlier R124 Local Codex return package plus the post-wrapper P11, P22, and P29 drops. This is a wrapper of ZIPs, not a replacement cumulative edition.

## 2026-06-24 - R124 post-web current wrapper v3 plus high queue

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v3_plusHighQueue_20260624.zip`

SHA256:

`404A0A14CB9B56EF9F5D54079EAE700F939326A544EEF087C9F541FA85084902`

Size: 445,937,010 bytes. ZIP extraction tested, 6 files.

Purpose: one higher-level drag-and-drop wrapper for Web/NASA that includes wrapper v2 plus the already-existing high-numbered R124 queue packages: `Noether_R124plus_LocalCodex_WebReturn_P40_P09_P20_20260624.zip`, `Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624.zip`, and `Noether_R124plusP40_P34_HotspotDisposition_NoNewPatch_20260624.zip`.

Use note: this remains a wrapper of ZIPs. It does not create a new cumulative edition by itself; the current cumulative TeX/PDF files live inside the component packages. It is intended to reduce Web-side bookkeeping after R124.

## 2026-06-24 - R124 post-web P37-P43 status sync and wrapper v4

Deliverables:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P37_P43_StatusSync_20260624.zip`

SHA256:

`7517091BE4E76C3CDCF6D27FFF937FF97055A5715DF2425F1FB7AF6861229736`

Size: 571,913 bytes. ZIP extraction tested, 20 files.

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v4_withHighQueueStatus_20260624.zip`

SHA256:

`81D8856CAE74FE50695629B63369D3CC2AE6587F69598FBBBB46A991B589B1E5`

Size: 446,642,801 bytes. ZIP extraction tested, 4 files.

Purpose: reconcile the old P37/P40-P43 status packages with the current R124 plus local Codex cumulative so Web does not replay already-absorbed patches or mistake old caveat packages for source certification.

Checked current base:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P11_FullPage_BestAvailableAudit_20260624\03_tex\cum_de_R124_plus_P35_P36_P38_P39_P40_P30_P11_sourceorder_repair_20260624.tex`

Current-base SHA256:

`DDAC5562FACCB8F72EA2B1E717C210E66CA840F49265A4085DD0DBD18C05C69C`

Findings:

- P37: RA08 restoration is present in the current base; do not duplicate it.
- P38/P39: post-R124 rebased repairs are already in the v3 wrapper.
- P40: post-R124 P40 complete package is already in the v3 wrapper; current repair uses best staged GDZ 400ppi, so it is repaired but not strict 650+ ppi recertified.
- P41/P42: only RA82 footnote-reset/boundary repairs are confirmed present; no local full source-certification package found in this pass.
- P43: current Paper 43 article is lines 20246--20708, with the received line at 20690. The following lines 20709--23695 are post-P43 corpus material, not Paper 43 itself.

Important packaging note: v4 is a wrapper containing v3 plus the new P37-P43 status sync. It adds no fresh TeX patch beyond v3; it adds current-base status, boundary ledgers, and anti-duplication instructions.

## 2026-06-24 - R124 post-web P41 source restoration

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P41_SourceRestoration_BestAvailable_20260624.zip`

SHA256:

`1E2C3F7ED490B268BC1E5E363F6AC3844D2C8C671052A22C80F04F010DDA24FE`

Size: 17,890,225 bytes. ZIP extraction tested. Supersedes the first P41 package hash from the same turn; this corrected package cleanly separates the P41/P42 boundary line break.

Current cumulative TeX added:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P41_SourceRestoration_BestAvailable_20260624\01_tex\cum_de_R124plus_localcodex_P41_source_restore_20260624.tex`

TeX SHA256:

`2536A9549E65BBCA30AE75F72053A4C0C62923C1A13B32EAB48FD6B9A7711AA4`

Compiled PDF:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P41_SourceRestoration_BestAvailable_20260624\06_build\cum_de_R124plus_localcodex_P41_source_restore_20260624.pdf`

PDF SHA256:

`13EEE948E251EA409AA298AC5A588C42EAE939EFEBFD3340584BE805B894EDA3`

LuaLaTeX status: two passes, exit 0; PDF length 457 pages.

Scope: Paper 41, `Der Hauptgeschlechtssatz für relativ-galoissche Zahlkörper`, Math. Ann. 108 (1933), printed pp. 411--419.

Action: replaced the smoothed/paraphrased current R124-local P41 segment with the source-structured P41 segment from `cum_de_R104.tex`. This restores source title punctuation, author/source block, 16 source-style footnotes, source-numbered paragraph structure, source-style displays via `\srcdisplay`, separate formulas `(1')`--`(5')`, and the p419 normierte zyklische Darstellung tail plus received line.

Source witness: local GDZ/IIIF full-resolution page images for printed pp. 411--419, included in the package. The GDZ IIIF metadata provides pixel dimensions but no native DPI field; this is the best local full-resolution witness, not strict 650+ ppi page certification. The local Springer DOI endpoint capture is explicitly marked non-authority because it returned HTML under a PDF filename.

Manual visual check performed: opened GDZ printed p419 and confirmed the suspicious source locus `u_E=e_{E,E}` and `u^f=\alpha=e_{E,E}e_{R,R^{f-1}}\cdots e_{R,R}` before preserving the R104 wording.

Package contents: compiled cumulative TeX/PDF, old current P41 segment, replacement R104 P41 segment, current-to-restored diff, audit CSV, source-quality note, source page map, raw GDZ page JPGs, source PDF witness, summary JSON, and SHA256 manifest.

Web handling note: this is a compiling source-restoration patch candidate and should be visually page-checked by Web against the included GDZ page images before being called globally certified.

## 2026-06-24 - R124 post-web current wrapper v5 plus P41

Deliverable:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v5_withP41_20260624.zip`

SHA256:

`D194EB94E3173E0ABB5590FD648FD55BA29BE6FB72B8FA38DBB2ED1979461FE5`

Size: 464,648,522 bytes. ZIP extraction tested.

Purpose: one drag-and-drop wrapper containing the prior current v4 wrapper plus the corrected `Noether_R124_PostWeb_P41_SourceRestoration_BestAvailable_20260624.zip`.

Use note: v5 is a wrapper of ZIPs. It preserves the earlier v4 high-queue/status context and adds the new P41 source-restoration package; it is under 500 MB.

## 2026-06-24 — R124 post-web P43 source restoration, best available 360ppi witness

Base used: Noether_R124_PostWeb_P41_SourceRestoration_BestAvailable_20260624/01_tex/cum_de_R124plus_localcodex_P41_source_restore_20260624.tex.

Confirmed problem: current R124-line P43 (Idealdifferentiation und Differente) was smoothed/compressed relative to the source-structured older reconstruction. The first source page visibly confirms the opening \varrho notation and editor/publisher source footnote; the current segment had mathematical/source drift including  in the opening ramification-exponent prose and no source footnotes.

Action taken: replaced the current P43 segment with the R104 source-structured P43 segment, preserving the post-P43 cumulative tail. Current segment replaced: 446 lines / 30,994 chars. Replacement segment: 814 lines / 88,121 chars. Restored 25 source footnotes, source-like display/tag structure, and the opening \varrho notation.

Source used: Noether_RA82_P39_P42_FootnoteResets_WebDrop_20260614/source/P43_no_fix_reference/p43_scan.pdf. pdfimages -list reports 2048 x 3322 embedded full-page images at 360ppi, so this is best-available, not 650ppi-certified. Better source should still supersede it if found.

Build result: LuaLaTeX two-pass cumulative compile succeeded; output PDF is 467 pages. Pass-2 scan found no fatal errors, emergency stops, undefined control sequences, unresolved refs, or label-rerun warnings.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P43_SourceRestoration_BestAvailable_20260624.zip
SHA256: 5269E1118EE29089D111070572CBAFCE254DDE187532E27E0DE476F2BF179BC2
Size: 10,286,068 bytes.

Current web wrapper: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v6_withP41_P43_20260624.zip
SHA256: E7F961681370E31213B1D310EB5EE3464D9495BA590E17BE105BF8D68B8BFD9D
Size: 475,076,609 bytes, under 500MB and extraction-tested.

## 2026-06-24 — R124 post-web P34 discriminant table source patch, best available 400dpi witness

Base used: Noether_R124_PostWeb_P43_SourceRestoration_BestAvailable_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_source_restore_20260624.tex.

Confirmed problem: Paper 34, section 25 `Diskriminanten`, around printed pp. 690-691, had a visibly structured source block flattened in the current cumulative. The source contains a product table for the matrix-ring basis arrangement, a determinant/cases display, a labelled `Folge`, separate displays for `D` and `D_red`, and italic theorem-style consequence statements. The current text reduced this to brief prose and two formulas.

Action taken: replaced the localized flattened block with a source-structured TeX reconstruction. The patch restores the product-table geometry, determinant/cases display, `Folge` label, separate discriminant displays, and italic source consequence statements. The row-brace labels were read as `l_1` and `l_2` from the best local source witness; Web should visually reconfirm them before final certification because the witness is below the preferred 650ppi threshold.

Source used: GDZ full-resolution JPGs from `Noether Multilingual/source_master_checks/P34_GDZ_MathZ30_1929_Hyperkomplexe_Darstellungstheorie/raw_fullres_jpg_p641_692`, specifically printed pp. 690-691. Local metadata reports roughly 400dpi. This is the best local witness found for this locus, not strict 650+ppi certification.

Build result: LuaLaTeX two-pass cumulative compile succeeded; output PDF is 467 pages. Rendered QA pages 345-346 were inspected, and the restored block appears on current PDF page 346.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P34_DiscriminantTable_SourcePatch_20260624.zip
SHA256: 0FDDEED29E14296BFD0744F7E6D35494972D704C64987C419E173CEAEF7425D8
Size: 7,584,714 bytes.

Current web wrapper: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v7_withP34_P41_P43_20260624.zip
SHA256: DAD3F49EF382DD07A8089569B21AAD38B13686D5BC262814823301C0BE1A059D
Size: 482,805,650 bytes, under 500MB and extraction-tested.

## 2026-06-24 — R124 post-web P36 header/source-line tiny fix, best available 360ppi witness

Base used: Noether_R124_PostWeb_P34_DiscriminantTable_SourcePatch_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_P34_tablepatch_20260624.tex.

Confirmed problem: Paper 36, `Idealdifferentiation und Differente`, had two small header-level source drifts. The journal line read `J. Ber. d. DMV39` without the source space, and the source author line begins `2. E. Noether, Göttingen: ...` while the current cumulative omitted the leading `2.`.

Action taken: patched only those two source-visible details. The existing emphasis on `Differentialquotient` and `Ideals` matched the source and was left unchanged.

Source used: Noether_Slavic_ZenodoDrive_Transfer_CurrentSources_20260623T1920Z/sources/paper36/Noether_Paper36_SOURCE_SCAN_FINAL_AUDITED.pdf. `pdfimages -list` reports a 2048 x 3322 embedded full-page image at 360ppi, so this is best local witness found, not strict 650+ppi certification. The accepted corrections are visually clear on the source page.

Build result: LuaLaTeX two-pass cumulative compile succeeded; output PDF is 467 pages. Rendered QA page 353 shows the patched P36 header.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P36_SourceTinyFix_20260624.zip
SHA256: 50AA1731FCEA909D01C3FA6D1090ABD1BDF68EC293AE01F8F07BA8386D0D21A4
Size: 5,703,176 bytes.

Current web wrapper: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v8_withP34_P36_P41_P43_20260624.zip
SHA256: 02E5FD715F4492ACD1300784A261BA7157F74C4974D072BB84FC89468F8CF158
Size: 488,655,677 bytes, under 500MB and extraction-tested.

## 2026-06-24 — R124 post-web P35 tail/source-citation fix, best available 360ppi witness

Base used: Noether_R124_PostWeb_P36_SourceTinyFix_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_P34_P36tinyfix_20260624.tex.

Confirmed problem 1: Paper 35 source citation line prints `Rec. Soc. Math. Moscou 36 (1929), S. 65--72` with the volume number plain. The current cumulative had `\textbf{36}`.

Confirmed problem 2: the current cumulative appended a non-source German received line, `Eingegangen am 11. November 1931`, and an editorial English abstract translated from the Russian summary. The P35 source pages do not show that received line or an English abstract. The source instead prints a Russian résumé and closes with `(Rec. Math. XXXVI:1; 1929).`

Action taken: removed the bolding from the citation volume number; removed the non-source received line and editorial English abstract; inserted the source closing line `(Rec. Math. XXXVI:1; 1929).` The Russian résumé remains an explicit open item, not a certified transcription.

Source used: Noether_Slavic_ZenodoDrive_Transfer_CurrentSources_20260623T1920Z/sources/paper35/Noether_Paper35_SOURCE_SCAN_FINAL_AUDITED.pdf, plus rendered source pages 1 and 8. `pdfimages -list` reports 2048 x 3322 embedded full-page images at 360ppi, so this is best local witness found, not strict 650+ppi certification. The accepted fixes are visually clear on source pages 1 and 8.

Build result: LuaLaTeX two-pass cumulative compile succeeded; output PDF is 467 pages. Rendered QA pages 348 and 352 show the citation and tail fixes.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P35_TailSourceFix_20260624.zip
SHA256: F3D8617E369A01416EC71B0F19885106333FFF3FE004B802E4AF88D7E20A055D
Size: 9,105,265 bytes.

Current web wrapper: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_LocalCodex_WebReturn_Current_v9_withP34_P35_P36_P41_P43_20260624.zip
SHA256: 8BFA536899383D7F47767ABD081B5276A2CB9EF17529B153240EEFB6689F8BFA
Size: 497,909,899 bytes, under 500MB and extraction-tested.

## 2026-06-24 — R124 post-web P02/P04/P06-P12 stale-fix survival audit, no new TeX patch

Base checked: Noether_R124_PostWeb_P35_TailSourceFix_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_P34_P36_P35tailfix_20260624.tex, i.e. the v9 cumulative state.

Purpose: old source-critical ledgers around P02/P04/P06-P12 were reopened as leads, not authority. I checked the concrete confirmed-fix rows against the current v9 cumulative to avoid replaying already-absorbed fixes into Web.

Result: no new TeX patch was needed in this pass. The following concrete fixes are already present in v9: P02 H_3 prose symbol distinction; P04 p152 §9 heading footnote; P06 sampled source-marker/left-numbering apparatus; P07/P08 source title/author and source-marker apparatus, including the P08 Omega note closure; P09 author line and Zermelo p. 484 correction; P10 author line, k_sigma definition, and F(t;vartheta_i) display; P11 author line, Omega_Gamma replacement, and final semicolon; P12 author line, f(x;dx), d delta x, barred-delta parentheticals, and the no-fix plain-delta formula (7) boundary.

Open caveat: this closes duplicate replay of the old confirmed-fix ledgers only. It does not certify full pages for P09-P12 or P04/P06-P08, because R124's own queue still correctly treats many full-page witnesses as below the preferred 650+ppi floor. Exact 1000dpi crop loci remain accepted; surrounding full-page audit remains best-effort unless better native sources appear.

## 2026-06-24 — R124 post-web P42 RA82 survival disposition, no new TeX patch

Base checked: Noether_R124_PostWeb_P35_TailSourceFix_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_P34_P36_P35tailfix_20260624.tex, i.e. the v9 cumulative state.

Purpose: R124's source queue still lists P42 as broadly open, and prior RA82 work had repaired only the article-boundary footnote reset. I extracted the current P42 block from v9 and compared it against the R104/RA82 reference block already staged in `_tmp_p42_compare`.

Result: no new TeX patch was needed. The current P42 block matches the R104/RA82 source-structured block except for harmless local boundary/provenance clearpage/comment differences after the P42 body. The RA82 local footnote reset should be treated as already absorbed and not replayed as a fresh patch.

Source/status caveat: this is a survival/disposition package, not dense source certification. The included P42 source witness is the local RA10 cutout, and prior provenance says it is below the 650dpi source-check floor. Keep P42 in the broader source-audit lane if a better Actualites/Hermann witness becomes available.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P42_RA82_SurvivalDisposition_20260624.zip
SHA256: 2F7105C1766F2EE28D82B80007D4C4ED3A4F21570F841F2E3EC1AE31C065A810
Size: 598,355 bytes.

## 2026-06-24 — R124 high-queue status after local patches, compact coordination drop

Purpose: after the R124 Web/NASA drop, the original `source_queue_R124.csv` still listed P34--P43 broadly open. Local work after R124 has since produced targeted patches or no-replay dispositions for P34, P35, P36, P41, P42, and P43, while older local packages already cover P37/P38/P39/P40 coordination. To prevent Web from replaying old patches or assuming no work happened, I made a compact status-only package.

Result: no new TeX patch. The package records the current status of P34--P43, points to the relevant local patch/disposition package for each paper, and keeps the source-quality caveat explicit. Most P34--P43 witnesses remain below strict 650+ dense-certification level, so this is coordination, not global source certification.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_HighQueue_StatusAfterLocalPatches_20260624.zip
SHA256: E3DBDAA46FFC860D889999D250D3E0A25BC64B15047F8D3B290F6E8C2AA5A717
Size: 5,022 bytes.

## 2026-06-24 — R124 post-web P11 source-order fix patch-only handback

Base checked: raw Web/NASA `Noether_R124_20260624.zip` cumulative versus current local v9 cumulative.

Confirmed status: R124 still contains the P11 printed p. 228 source-order drift `\varphi_3(x)=\frac{u\cdot w}{v}`. The current local v9 cumulative contains the corrected source-order reading `\varphi_3(x)=\frac{w\cdot u}{v}` from the earlier P11 best-available audit package.

Action taken: no new cumulative patch was authored in this pass, because the local current already carries the fix. I made a tiny patch-only package for Web/NASA with the R124 P11 slice, current v9 P11 slice, one-line patch, CSV ledger, and source-quality provenance pointer. No new source images were included; the earlier P11 audit package remains the source witness package and records the best staged full-page witness as GDZ/IA 400ppi, not strict 650+ certification.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P11_SourceOrderFix_PatchOnly_20260624.zip
SHA256: 31C2D2BC4AE1798085A6E4D3FDB6E1A2B2B2134FAAF4BAB5063360EBA8B9C0F7
Size: 21,652 bytes.

## 2026-06-24 — R124 post-web P09 exact-loci survival/no-patch drop

Base checked: raw Web/NASA `Noether_R124_20260624.zip` cumulative and current local v9 cumulative
`Noether_R124_PostWeb_P35_TailSourceFix_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_P34_P36_P35tailfix_20260624.tex`.

Purpose: package the known P09 exact-locus fixes and no-fix traps in a Web-readable form so they do not get replayed, reversed, or treated as unhandled work. This is deliberately an exact-locus survival package, not a full P09 certification.

Result: no new TeX patch. The two previously confirmed P09 fixes from the GDZ raw-source audit already survive in R124 and local v9: the printed author line `Von Emmy Noether in Erlangen.` and the Zermelo footnote page correction `Math. Ann. 75, S. 484 (1914).` The three no-fix traps also survive at the checked loci: the relation keeps the source-final `\xi_t` index, and the p. 125 module subscripts remain multiplicative dimension subscripts rather than comma-separated subscripts.

Source/evidence: the package includes the earlier staged 1000dpi labelled evidence crops for the exact P09 loci, the compact GDZ article witness PDF, the source CSVs, and P09 TeX slices from R124 and local v9. The separate P09 p. 112 dense-display no-patch package remains only best-available native ~400ppi and is not promoted here to strict 650/1000dpi certification.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P09_ExactLoci_Survival_NoPatch_20260624.zip
SHA256: BDBBE51B6C1D8CF58CAA50DA9D13D4D8D8F372364B7998B8E8ABEFD6BA522D05
Size: 6,832,761 bytes.

## 2026-06-24 — R124 post-web P10 brace source fix, compiled cumulative

Base checked: raw Web/NASA `Noether_R124_20260624.zip` cumulative and current local v9 cumulative
`Noether_R124_PostWeb_P35_TailSourceFix_20260624/01_tex/cum_de_R124plus_localcodex_P41_P43_P34_P36_P35tailfix_20260624.tex`.

Confirmed problem: the old P10 no-fix trap correctly protected the source's `x` in the rank-three exclusion formula, but the same 1000dpi labelled source crop also shows ordinary parentheses around the argument of `f`. R124 and local v9 had `f\{x\cdot(1\pm ic)\}`, which renders braces rather than the source's `f(x\cdot(1\pm ic))`.

Action taken: produced a new local cumulative TeX replacing only that one line with
`f(x\cdot(1\pm ic))=\Xreal(1+ic)=f(x)\cdot(1+i f(c)),`. The older P10 fixes for the author line, terminal `k_\sigma`, and `F(t;\vartheta_i)\cdot G(t;\vartheta_i)` are already present in R124/local v9 and are recorded in the package as survival/no-replay rows.

Source/evidence: `P10_p545_final_rank_three_x_not_r_and_parentheses_1000dpi_labelled.png`, plus the compact P10 GDZ source PDF and the prior P10 CSV ledgers. The full-page P10 GDZ/IA source remains below the preferred full-page 650dpi and dense-math 1000dpi floors, so the package certifies only the targeted crop loci, not full P10 page-by-page completion.

Build result: LuaLaTeX two-pass compile succeeded; output PDF is 467 pages.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P10_BraceSourceFix_20260624.zip
SHA256: 6EE1828E10C65A820B56193C0D81C49CE077564E5AE1DDF279FAADF564C62C9B
Size: 12,305,394 bytes.

## 2026-06-24 — R124 post-web P12 targeted fix survival/no-patch drop

Base checked: raw Web/NASA `Noether_R124_20260624.zip` cumulative and the current local cumulative after the P10 brace fix.

Purpose: R124 still lists Paper 12 as a complete full-page re-audit lane. The older local P12 dense-hotspot package used native 400ppi page witnesses and should not be treated as strict certification. This pass isolates the earlier targeted 1000ppi labelled P12 evidence crops and checks whether the associated fixes/traps survive in R124 and the current local cumulative.

Result: no new TeX patch. The P12 printed author line survives; the initial definition uses source `f(x;dx)`; the higher differential text uses `d\delta x`; the p. 40 formula (5) and after-formula (6) parentheticals use barred `\bdelta x`; and formula (9) remains source-correct plain `\delta x`, so the barred-delta repair has not been over-propagated.

Source/evidence: five targeted P12 evidence crops tagged 1000ppi, plus the prior P12 targeted ledgers and TeX slices from R124/current. This package certifies only those exact loci, not full Paper 12 page-by-page completion.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P12_TargetedFixSurvival_NoPatch_20260624.zip
SHA256: DA474438E69945547B29127DB16BF0795B5999F2528B1EF64ED539745AE093E4
Size: 7,819,790 bytes.

## 2026-06-24 — R124 post-web P19/P20 targeted fix survival/no-patch drop

Base checked: freshly extracted Web/NASA `Noether_R124_20260624.zip` cumulative and the current local cumulative after the P10 brace fix.

Purpose: prevent the web session from replaying or re-litigating old P19/P20 exact-locus corrections that are already present in R124 and still present in the current local cumulative. This is a targeted survival package, not a global P19/P20 page certification.

Result: no new TeX patch. The following exact loci survive:

- P19 p. 58 source-order cleanup after "Wegen": `\ideal Q\eqzero{\ideal P}`, then `\ideal P^\rho\eqzero{\ideal Q}`.
- P19 pp. 65--66 exponent-system correction: `\mathfrak C` uses `s_1,\ldots,s_\lambda`, `\mathfrak D` uses `t_1,\ldots,t_\mu`, and the continuation inequality is `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`.
- P20 p. 31 formula (13) no-fix trap: the display uses `\kappa,\lambda`, while nearby prose intentionally keeps `\mu,\nu`.

Source/evidence: four exact-locus 1000dpi labelled crops, prior local source ledgers, and R124/current TeX snippets. The available full-page P19/P20 sources are still best-available GDZ/IA-style page images around 400ppi, so this package certifies only the listed exact loci.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P19_P20_TargetedFixSurvival_NoPatch_20260624.zip
SHA256: 2FC153703110EE07C8D122C7696514DD8DB837F72572CC9B0EB535C3E79D7CB3
Size: 8,740,784 bytes.

## 2026-06-24 — R124 post-web P13-P18 existing survival-package index

Purpose: avoid duplicate work around Papers 13--18 after the R124 Web/NASA drop. The active R124 source queue does not list P13--P18 as immediate active full-page items, and local post-R124plusP40 survival/no-new-patch packages already exist for this band.

Action taken: created a tiny coordination package with a machine-readable index of the existing P13--P18 packages, including absolute local paths, sizes, SHA256 hashes, and interpretation. No source images or TeX patches were duplicated.

Interpretation: this is not global page-by-page certification for P13--P18. It is an index telling Web which existing packages to use if it needs those papers or detects a regression.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P13_P18_ExistingSurvivalIndex_NoNewPayload_20260624.zip
SHA256: FDE55000F5918D85A6AD2008D0C5D8D1FE6E16935E32B97D6C03BCD375A28FFA
Size: 2,254 bytes.

## 2026-06-24 — External `_noether_audit` harness disposition

Checked: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\_noether_audit\HARNESS_README.md`.

Disposition: useful only as a workflow/chunking reference, not as a current authority. The harness canonical TeX is `cum_de_R121.tex`, not the current R124-plus-local cumulative. It has 323 units over 23 papers and explicitly excludes or under-stages several papers that have since been handled or re-staged locally. It also includes many 400ppi pages, so it does not satisfy the strict 650/1000dpi rule except where better sources are separately available.

Action: do not ingest the harness output blindly. Any agent output based on this harness must be rebased against the R124 Web/NASA baseline plus local confirmed patches before being accepted.

## 2026-06-24 — R124 post-web P06-P08 targeted fix survival/no-patch drop

Base checked: freshly extracted Web/NASA `Noether_R124_20260624.zip` cumulative and the current local cumulative after the P10 brace fix.

Purpose: move the non-overlap audit lane backward below P09 and prevent stale replays of older P06/P07/P08 fixes. Prior packages had already established exact-locus repairs using 1000dpi crops; this pass checked that those exact loci survived in R124 and the current local cumulative.

Result: no new TeX patch. The following exact loci survive:

- P06 RA67 source-marker apparatus at printed pp. 161, 164, and 165: source-style `\srcfn{*)}`, `\srcfn{**)}`, and `\srcfn{***)}` markers remain in the current P06 block. Old ordinary-footnote warnings are stale for current P06.
- P07 printed title/author block and symbolic source notes survive, including the opening Weber note, section 1/2 notes, Weber II §58 note, Math. Ann. 76 note, and Satz III relative-invariants note.
- P08 source-backed formula `f[x,y,(zy)x+(xz)y]=(xy)^p f(x,y,z).` survives in R124/current; the accepted P08 title/source-note/operator/Omega loci also survive at the checked anchors.

Source/evidence: 20 exact-locus 1000dpi crops, prior source ledgers, and R124/current TeX snippets. This does not certify full page-by-page P06/P07/P08 completion.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P06_P08_TargetedFixSurvival_NoPatch_20260624.zip
SHA256: 9B33D963DE63845895ADD8945CCDC9C56ECDDCFE250AD38FCE547221790498FF
Size: 29,112,358 bytes.

## 2026-06-24 — R124 post-web P01-P05 status index

Purpose: orient the lower Noether band after the R124 Web/NASA baseline without duplicating existing source packages. R124 explicitly queues P04 pp. 140--145; P01/P02/P03/P05 have earlier survival/inheritance packages.

Action taken: created a tiny routing/status package listing the relevant P01--P05 packages, absolute paths, sizes, hashes, and caveats.

Status:

- P04: use `Noether_R124_PostWeb_P04_pp140_145_SourceAudit_20260624.zip`; it is a current post-R124 no-patch source audit with 1000dpi rendered witnesses from the best staged P04 cutout.
- P01/P02/P03/P05: existing R123+P08 survival packages preserve prior fixes/no-fix traps but are not fresh strict full-page certifications.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P01_P05_StatusIndex_20260624.zip
SHA256: 8DFDCAC672AF9AD4F5B0731A4CB22620D2E2008344082FD27B596B937DA46F8A
Size: 2,395 bytes.

## 2026-06-24 — R124 post-web P22/P29/P30 middle-queue status index

Purpose: orient the remaining middle R124 queue rows without duplicating existing heavy source/repair packages.

Action taken: created a tiny routing/status package for P22, P29, and P30 with absolute paths, sizes, hashes, package status, and remaining-scope caveats.

Status:

- P22: `Noether_R124_PostWeb_P22_RA61_RA62_RA63_SurvivalClosure_20260624.zip` shows RA61 no-patch anchors and RA62/RA63 repairs survive; includes mixed 400/600ppi GDZ witnesses; not strict full-page certification.
- P29: `Noether_R124_PostWeb_P29_RA71_GDZ400_SurvivalClosure_20260624.zip` shows the RA71 source-header/footnote-counter repair survives and gross-gap anchor audit found no page-scale omission; GDZ source is 400ppi; not strict full-page certification.
- P30: `Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624.zip` contains real post-R124 P30 repairs not in raw R124: footnotes 27/28, Axiom IV display, received-date parentheses, plus P10/P12 no-new-patch material. Source is best-available IA/JP2 400-ish; not strict 650+ certification.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P22_P29_P30_MiddleQueue_StatusIndex_20260624.zip
SHA256: 27E95CAF1839E939BC911F203BF4632B6ABC882C985B94D3FCC21CDFFE28A83C
Size: 2,648 bytes.

## 2026-06-24 — R124 post-web P34-P43 high-queue status index v2

Purpose: update the earlier P34--P43 high-queue coordination pointer with precise package hashes and later local package choices. This is an index only, not a duplicate source or cumulative bundle.

Action taken: created a row-per-paper routing CSV for P34--P43 with primary and secondary package paths, sizes, hashes, status, notes, and remaining-scope caveats.

Key interpretation:

- P34/P35/P36/P41/P43 have post-R124 patch/restoration packages.
- P38/P39 repairs are represented by the rebased P35/P36/P38/P39 bundle plus original source-repair packages.
- P40 should use the P40 complete webdrop rather than old appendix-only RA84 material.
- P37/P42 are survival/status dispositions.
- All broad high-fidelity full-page R124 rows remain open unless Web accepts the best-available lower-resolution package closure or a later complete 600+ PPI source pass exists.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P34_P43_HighQueue_StatusIndex_v2_20260624.zip
SHA256: 56EA25E1926BF676CF07D3EC58BDD3996EC0446D628A76D780FC085D36098FBC
Size: 3,467 bytes.

## 2026-06-24 — R124 post-web master queue map

Purpose: create a single top-level routing map for the R124 Web/NASA baseline and the local Codex post-R124 packages produced or identified so far. This is intended to reduce repeated Web confusion about which package applies to which paper band.

Action taken: created a small master map zip containing `R124_postweb_master_queue_map.csv`, with roles, package names, absolute paths, sizes, SHA256 hashes, and usage notes. The map covers:

- R124 baseline;
- P01--P05 status and P04 active source audit;
- P06--P08 targeted survival;
- P09, P10, P11, P12 exact fix/survival drops;
- P13--P18 existing package index;
- P19--P20 targeted survival;
- P22/P29/P30 middle queue;
- P34--P43 high queue;
- current local cumulative v9 and the smaller P10-brace-fix package containing the latest local TeX/PDF.

Important: this master map is not source evidence and does not close broad full-page certification rows by itself. It points Web to the relevant evidence/fix packages and preserves the lower-resolution caveats.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_MasterQueueMap_20260624.zip
SHA256: E220A181DAAC21A84C97B7B6D77DBEF1E5ABB3FB33040CCE957AE7A335324153
Size: 3,286 bytes.

## 2026-06-24 — IA/GDZ dump source-quality audit

Purpose: check the newly downloaded local Internet Archive JP2 zips and GDZ PDFs before treating them as high-resolution source upgrades for the R124 remaining queue.

Action taken: sampled local IA JP2 zips for Mathematische Annalen Bands 83, 85, 90, and 96; ran ImageMagick identify on extracted sample leaves; ran `pdfinfo` and `pdfimages -list` on GDZ `PPN235181684_0090.pdf` and `PPN235181684_0096.pdf`; packaged the tool outputs and a source-quality verdict ledger.

Verdict:

- IA JP2 raw images are useful source witnesses but sampled at roughly 2200--2300 px wide by 3370--3420 px tall, i.e. roughly 400-ish page scans, not a hidden 650+ dpi upgrade.
- GDZ Band 90 and Band 96 PDFs expose 400ppi embedded page images.
- These can support best-available source-certain repairs when visually unambiguous and no better source exists.
- They must not be used to claim strict 650+ dpi certification for broad unresolved rows.

Routing notes:

- Paper 30 / Band 96 remains best-available 400ppi from the staged sources unless a genuinely higher-resolution witness appears.
- Band 90 and Band 96 packages are source witnesses, but must be paper/page crosswalked before being used as paper-specific authority.
- Keep the old misnamed P29/P24 IA-source trap visible: do not rely on package names without checking the actual paper/page mapping.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_SourceQuality_IA_GDZ_DumpAudit_20260624.zip
SHA256: 0A2C55AFBF8879502189F95008B8E7DFD1E6B87264DC619095F5586A7EFBF339
Size: 26,456 bytes.

## 2026-06-24 — R124 post-web P13-P18 actual evidence bundle

Purpose: replace the earlier P13--P18 index-only coordination drop when Web needs the actual evidence packages. The prior index explicitly said not to upload it alone if the web session needed source evidence.

Action taken: created a one-file drag-drop bundle containing the five existing per-paper evidence/survival zips for Papers 13--18 plus a compact source-floor routing ledger. This does not introduce a new TeX patch; it packages existing evidence with clearer source-quality caveats.

Included evidence zips:

- `Noether_R124plusP40_P13_RA48_R122Survival_NoNewPatch_20260624.zip`
- `Noether_R124plusP40_P14_RA55_RA78Survival_NoNewPatch_20260624.zip`
- `Noether_R124plusP40_P15_P16_RA54_RA53_RA78Survival_NoNewPatch_20260624.zip`
- `Noether_R124plusP40_P17_RA52_RA77_RA94Survival_NoNewPatch_20260624.zip`
- `Noether_R124plusP40_P18_GDZ600_RA51Survival_NoNewPatch_20260624.zip`

Source-floor notes:

- P13 uses GDZ full-resolution IIIF JPEGs around 2296x3688 px for most pages; crop labels are readability render metadata, not new source detail.
- P14--P16 source ledgers report below-650 source floors; use as exact-locus survival/no-new-patch evidence.
- P17 and P18 use best-known local 600ppi routes, still below the strict 650+ rule.
- This bundle does not certify global page-by-page completion for P13--P18.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P13_P18_ActualEvidenceBundle_20260624.zip
SHA256: F51A0CB5D052C47B7622420271E833816C34A70850D375BE48F59405CD709402
Size: 61,693,938 bytes.

## 2026-06-24 — R124 post-web P09-P12 actual evidence/fix bundle

Purpose: bundle the actual local Codex evidence/fix zips for the active lower R124 queue band P09--P12. This is for Web drag-drop when the master map alone is not enough.

Action taken: created a one-file bundle containing eight compact post-R124 packages:

- `Noether_R124_PostWeb_P09_ExactLoci_Survival_NoPatch_20260624.zip`
- `Noether_R124_PostWeb_P09_p112_Hotspot_NoPatch_WebDrop_20260624.zip`
- `Noether_R124_PostWeb_P10_BraceSourceFix_20260624.zip`
- `Noether_R124_PostWeb_P10_DenseHotspots_NoPatch_WebDrop_20260624.zip`
- `Noether_R124_PostWeb_P11_SourceOrderFix_PatchOnly_20260624.zip`
- `Noether_R124_PostWeb_P11_FullPage_BestAvailableAudit_20260624.zip`
- `Noether_R124_PostWeb_P12_TargetedFixSurvival_NoPatch_20260624.zip`
- `Noether_R124_PostWeb_P12_DenseHotspots_NoPatch_WebDrop_20260624.zip`

Interpretation:

- P10 and P11 include actual source-confirmed TeX fixes/patch evidence.
- P09 and P12 are targeted survival/no-patch evidence, not broad full-page closure.
- Dense-hotspot packages preserve no-fix traps so Web does not spend cycles re-opening already checked loci.
- Broad full-page rows remain open unless independently closed by a compliant source pass.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P09_P12_ActualEvidenceBundle_20260624.zip
SHA256: BA6F925985A282383E41F0B59E3C34327CCD86DAFBD4928A08A33B62A4EAB159
Size: 59,724,146 bytes.

## 2026-06-24 — R124 post-web P01-P08 actual evidence bundle

Purpose: bundle actual local evidence zips for the lower Noether band P01--P08, replacing the need to upload the P01--P05 status index alone.

Action taken: created a one-file bundle containing:

- `Noether_R123plusP08_P01_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
- `Noether_R123plusP08_P02_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
- `Noether_R123plusP08_P03_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
- `Noether_R124_PostWeb_P04_pp140_145_SourceAudit_20260624.zip`
- `Noether_R123plusP08_P05_SurvivalAudit_Cumulative_WebDrop_20260624.zip`
- `Noether_R124_PostWeb_P06_P08_TargetedFixSurvival_NoPatch_20260624.zip`
- `Noether_R124_PostWeb_P02_P04_P06_P12_StaleFixSurvivalAudit_20260624.zip`

Interpretation:

- P04 is the current active R124 queue item in this band.
- P01/P02/P03/P05 are survival/inheritance evidence, not fresh strict full-page certification.
- P06--P08 targeted checks prevent stale replay of already accepted exact loci.
- The compact stale-fix audit is orientation only; actual evidence lives in the relevant per-paper zips.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P01_P08_ActualEvidenceBundle_20260624.zip
SHA256: EB8B5D7FFD3837D12950ADB782DD9F3E816A507D1DF5CD378E5142CDA9F52ABF
Size: 74,618,657 bytes.

## 2026-06-24 — R124 post-web P22/P29/P30 actual evidence bundle

Purpose: bundle actual local evidence/fix zips for the middle open R124 queue rows P22, P29, and P30. The previous middle-queue package was a status index only.

Action taken: created a one-file bundle containing:

- `Noether_R124_PostWeb_P22_RA61_RA62_RA63_SurvivalClosure_20260624.zip`
- `Noether_R124_PostWeb_P29_RA71_GDZ400_SurvivalClosure_20260624.zip`
- `Noether_R124_PostWeb_LocalCodex_Delta_P30_P10P12_20260624.zip`

Interpretation:

- P22 and P29 packages preserve survival/closure evidence for exact loci and prior repairs; their broad full-page queue rows remain open unless accepted by a best-available pass or superseded by higher source.
- P30 contains real post-R124 repairs: footnotes 27/28, Axiom IV display, and received-date parentheses. Its source is best-available IA/JP2 400-ish, not strict 650+ certification.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P22_P29_P30_ActualEvidenceBundle_20260624.zip
SHA256: 1A2FBCC0CB60C5ECEC4EBD672F8D4330991CA679D5D443F22EFC093E355DC518
Size: 148,321,449 bytes.

## 2026-06-24 — R124 post-web P34-P43 actual evidence bundle

Purpose: bundle actual local evidence/fix zips for the R124 high queue P34--P43. The prior `P34_P43_HighQueue_StatusIndex_v2` package was an index only.

Action taken: created a one-file bundle with thirteen unique payload zips. Shared packages are included once and mapped in the routing ledger, especially the `P35_P36_P38_P39_RebasedSourceRepairs` bundle.

Included payload classes:

- P34 discriminant/product-table source patch and hotspot no-patch disposition.
- P35 and P36 post-R124 source fixes.
- P37/P43 status sync.
- Shared P35/P36/P38/P39 rebased repair bundle.
- Original P38 and P39 source-repair evidence packages.
- P40 complete webdrop plus final body repair package.
- P41 and P43 source-structured restorations.
- P42 RA82 survival disposition.

Interpretation:

- This prevents replaying already made patches/restorations as missing.
- It does not prove the broad R124 high-fidelity full-page rows complete.
- Several source floors are best-available lower-resolution or 600ppi rather than strict 650+.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_P34_P43_ActualEvidenceBundle_20260624.zip
SHA256: F7759344A9BF031978F833C932F193E60E10E37133895E98149F552F43B02100
Size: 230,312,925 bytes.

## 2026-06-24 — R124 post-web master payload map v2

Purpose: replace the earlier master queue map as the current small control package after converting several pointer-only bands into actual payload bundles.

Action taken: created a tiny map zip with a README and `R124_postweb_master_payload_map_v2.csv`. It records upload order, role, paper band, absolute path, size, SHA256, web action, and caveat for:

- R124 baseline;
- IA/GDZ source-quality gate;
- P01--P08 actual evidence bundle;
- P09--P12 actual evidence/fix bundle;
- P13--P18 actual evidence bundle;
- P19--P20 targeted survival/no-patch package;
- P22/P29/P30 actual evidence bundle;
- P34--P43 actual evidence bundle;
- older master queue map as superseded history.

Interpretation: this is the current "what do I drag into Web?" control file. It is not source evidence by itself and does not close broad full-page certification rows.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostWeb_MasterPayloadMap_v2_20260624.zip
SHA256: 784737EACFB0CA889066ACC33CDE6A345A1263C1EB3836D0C61C7AD5AB7004C7
Size: 3,186 bytes.

## 2026-06-24 — R124 post-payload open-work register

Purpose: after creating actual payload bundles for the active R124 bands, record what remains genuinely open and what should not be replayed as missing.

Action taken: created a small register package containing:

- `R124_open_work_after_payload_bundles.csv`, one row per R124 queue item;
- `R124_payload_closure_summary.md`, a short human-readable closure/open-work note.

Main conclusions:

- No obvious pointer-only packaging gap remains for P01--P08, P09--P12, P13--P18, P19--P20, P22/P29/P30, or P34--P43.
- Broad R124 high-fidelity full-page rows remain open where the source floor is below strict 650+ or where no full sequential audit has been accepted.
- Exact-locus patches/no-fix traps are covered by payloads and should not be replayed.
- P30 remains active partial beyond the already repaired pp. 58--61 material.
- Tail/post-P43 authorial and bibliographic material remains a source reacquisition/manual verification lane.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124_PostPayload_OpenWorkRegister_20260624.zip
SHA256: 11B757115F63575F2865DFA86405B9ED99422BC6CBAE20F75C4CEF14D25AE278
Size: 4,548 bytes.

## 2026-06-24 — R124plus current cumulative integration audit

Purpose: after receiving the R124 web baseline and later local repair/audit payloads, produce a compact web-drop that answers a narrow question: which Local Codex repair/status signatures are actually visible in the current local cumulative TeX candidate?

Action taken:

- Copied the current local cumulative candidate into a new integration-audit package:
  `01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Re-checked signatures directly against that TeX, rather than relying on inherited compacted notes.
- Wrote `02_audit/current_cumulative_confirmed_patch_presence.csv` with paper, locus, expected signature, found/count/line status, and caveats.
- Wrote a short summary and pattern-search notes for the web session.

Key corrections to inherited notes:

- P10 is verified by `f(x\cdot(1\pm ic))` at current line 7851; the inherited `\left(x_1^\varrho,\ldots)`-style check was not the relevant P10 signature.
- P30 is verified with `(Eingegangen am 13. 8. 1925.)` at current line 15652; the inherited `25.10.1926` date was wrong for this P30 locus.
- P35 source tail `(Rec. Math. XXXVI:1; 1929).` is present at current line 18474; earlier absence was a bad pattern check.

Interpretation:

- This is an integration/presence audit, not a new source certification pass.
- P10, P11, P30, P34, P35, P36, P41, and P43 checked signatures are present in the copied candidate TeX.
- Some P30 source witnesses remain best-available below the strict 650+ ppi certification floor.
- If the web session has a newer baseline than R124, this package should be used as a cherry-pick/signature map rather than an automatic replacement.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624.zip
SHA256: 0CAC67FF8F1C684D2963EAB2ADAD8E5AD8EEB398BAD1ACB9C525B063E9FA0874
Size: 574,225 bytes.

## 2026-06-24 — P13--P18 survival integration audit

Purpose: continue the non-overlap Noether audit by checking whether the already-packaged P13--P18 exact-locus repairs/no-fix traps survive in the current local cumulative candidate.

Action taken:

- Extracted/read the nested evidence ledgers in `Noether_R124_PostWeb_P13_P18_ActualEvidenceBundle_20260624`.
- Checked the key survival signatures against the current local cumulative candidate:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Scanned the P13--P18 current-cumulative line window for obvious placeholder/scaffold markers including `TODO`, `FIXME`, `MISSING`, `PLACEHOLDER`, `OCR`, `??`, and the old non-source `Fortsetzung zu 17` scaffold string.
- Produced a compact web-drop with the current-candidate reference TeX, survival-anchor audit CSV, compact no-fix trap CSV, source-floor routing CSV, and summary.

Main findings:

- No new source-certain patch is proposed for P13--P18 in this pass.
- P13--P18 known exact-locus repairs and no-fix traps survive in the current candidate.
- The old P17 non-source scaffold label `Fortsetzung zu 17` is absent.
- The P13--P18 marker scan found no obvious placeholder/scaffold strings.

Interpretation:

- This package is a current-cumulative survival/integration audit, not strict page-by-page source certification.
- P17 and P18 use best-known 600ppi routes; P13--P16 evidence remains useful targeted evidence but below strict native 650+ certification in the source-floor ledgers.
- Web should use this to avoid replaying stale fixes/OCR false positives, while leaving broad full-page certification rows open unless a source-quality route is accepted.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P13_P18_SurvivalIntegrationAudit_20260624.zip
SHA256: 5D1B0D28326DAD6D3017FCE92CFA3AB0A789F53C09ABA3467F8CD93C91449E88
Size: 576,333 bytes.

## 2026-06-24 — P19--P20 survival integration audit

Purpose: continue the non-overlap Noether audit by checking whether the already-packaged P19--P20 exact-locus repairs and no-fix traps survive in the current local cumulative candidate after the R124 web drop.

Action taken:

- Read the P19--P20 targeted evidence package:
  `Noether_R124_PostWeb_P19_P20_TargetedFixSurvival_NoPatch_20260624`.
- Read the earlier IA400/source-upgrade survival package:
  `Noether_R124plusP40_P19_P20_IA400_RA50_RA49Survival_NoNewPatch_20260624`.
- Checked the current local cumulative candidate directly:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Scanned the current P19--P20 line window for obvious placeholder/scaffold markers: `TODO`, `FIXME`, `MISSING`, `PLACEHOLDER`, `OCR`, and `??`.
- Produced a compact web-drop with the current-candidate TeX reference, survival-anchor audit CSV, compact no-fix trap CSV, source-quality limits CSV, and summary.

Main findings:

- P19 printed p58 source order survives: `\ideal Q\eqzero{\ideal P}` followed by `\ideal P^\rho\eqzero{\ideal Q}`.
- P19 printed pp65--66 elementary-divisor systems survive with `s_1,\ldots,s_\lambda`, `t_1,\ldots,t_\mu`, and continuation inequality `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`.
- P20 formula (13) survives with displayed `\kappa,\lambda`.
- P20 adjacent prose correctly remains the prior no-fix trap with products `\varrho_\mu\sigma_\nu`.
- P20 closing location/date and received-date lines survive.
- No obvious placeholder/scaffold markers were found in the P19--P20 current-candidate window checked here.

Interpretation:

- No new TeX patch is proposed in this pass.
- This is a current-cumulative survival/integration audit, not full page-by-page source certification.
- Prior exact-locus 1000 dpi crops remain the authority for the listed repaired loci. Full-page P19/P20 cutouts are only 400 ppi, so broad dense-symbol reopening still needs a better source route or explicit best-available acceptance.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P19_P20_SurvivalIntegrationAudit_20260624.zip
SHA256: BB67166CFBC9FEB682BF9C72C7B06646AC434CBE623ECCDB00E4D459BE036E3B
Size: 573,803 bytes.

## 2026-06-24 — P09--P12 survival integration audit

Purpose: continue the lower non-overlap Noether lane after P13--P20 by checking the post-R124 P09--P12 evidence/fix packages against the current local cumulative candidate.

Action taken:

- Read the routing bundle:
  `Noether_R124_PostWeb_P09_P12_ActualEvidenceBundle_20260624`.
- Read the individual P09, P10, P11, and P12 evidence ledgers:
  `Noether_R124_PostWeb_P09_ExactLoci_Survival_NoPatch_20260624`,
  `Noether_R124_PostWeb_P10_BraceSourceFix_20260624`,
  `Noether_R124_PostWeb_P11_SourceOrderFix_PatchOnly_20260624`,
  and `Noether_R124_PostWeb_P12_TargetedFixSurvival_NoPatch_20260624`.
- Checked the current local cumulative candidate directly:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Searched the current candidate for bad old patterns such as `S. 434`, `\vartheta_{k_\nu}`, the unindexed `F(t;\vartheta)` factor, brace-form `f\{x\cdot(1\pm ic)\}`, reversed P11 product order, and `ddx`.
- Scanned the current P09--P12 line windows for obvious placeholder/scaffold markers.
- Produced a compact web-drop with the current TeX reference, survival-anchor audit CSV, no-fix trap CSV, bad-pattern absence CSV, source-quality limits CSV, and summary.

Main findings:

- P09 exact-locus rows survive: author line, `Math. Ann. 75, S. 484`, final `\xi_t`, and multiplicative module subscripts.
- P10 source-confirmed corrections survive: author line, terminal `k_\sigma`, indexed `F(t;\vartheta_i)`, and final formula `f(x\cdot(1\pm ic))`.
- P11 source-order correction survives: `\varphi_3(x)=\frac{w\cdot u}{v}`.
- P12 targeted rows survive: initial `f(x;dx)`, higher differentials `d^2x,d\delta x`, barred-delta parentheticals around formula (5)/(6), and plain `\delta x` in formula (9).
- The checked bad old patterns were absent.
- No obvious placeholder/scaffold markers were found in the current P09--P12 windows.

Interpretation:

- No new TeX patch is proposed in this pass because the current candidate already carries the source-supported P10/P11 patches and the P09/P12 survival/no-fix rows.
- This is an exact-locus/current-candidate integration audit, not full page-by-page certification.
- Several broad source routes in P09--P12 still sit below strict 650+ full-page certification, so broad page-level rows should remain open unless separately certified or explicitly accepted as best-available.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_P12_SurvivalIntegrationAudit_20260624.zip
SHA256: CB6E4CE0290ABE0DA024840952FDE653929A4FB5E13A1D1F3C7FE4C5907E1721
Size: 575,231 bytes.

## 2026-06-24 — P01--P08 survival integration audit

Purpose: continue the lower Noether lane after P09--P20 by checking the P01--P08 routing/evidence packages against the current local cumulative candidate.

Action taken:

- Read the lower-band routing bundle:
  `Noether_R124_PostWeb_P01_P08_ActualEvidenceBundle_20260624`.
- Read the P01--P05 status index and the P06--P08 exact-locus survival package.
- Read the P04 pp. 140--145 source-audit package, because P04 is the explicit active R124 row in this band.
- Read inherited P01, P02, P03, and P05 survival audit CSVs to distinguish inherited context from fresh certification.
- Checked the current local cumulative candidate directly:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Searched for stale/bad patterns, including old P02 bad table literals, P03 Faber leakage, and stale P08 `(xy)x` substitution regression.
- Scanned low-band current-candidate windows for obvious placeholder/scaffold markers.
- Produced a compact web-drop with current TeX reference, anchor audit CSV, bad-pattern absence CSV, source-quality limits CSV, provenance, and summary.

Main findings:

- No new TeX patch is proposed.
- P01, P02, P03, and P05 inherited survival anchors are visible in the current candidate, but remain inherited survival/context rows rather than fresh strict source certification.
- P04 pp. 140--145 no-patch source-audit anchors survive in the current candidate, including formula (44), the formula (49) k-chain, and formula (59) `(f)=\sum c\Delta^\alpha(\varphi)`.
- P06--P08 exact-locus rows survive in the current candidate, including P06 source-note apparatus, P07 symbolic source notes, and P08 `f[x,y,(zy)x+(xz)y]=(xy)^p f(x,y,z).`
- Checked stale bad patterns were absent.
- No obvious placeholder/scaffold markers were found in the checked low-band windows.

Interpretation:

- This package closes the current-candidate survival/integration sweep for P01--P20 as a routing/regression layer.
- It does not make a full corpus completion claim. P01--P08, especially the inherited P01/P02/P03/P05 rows, still need fresh strict source certification if the project wants every page proven under the 650+/1000+ dpi rule.

Package: C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P01_P08_SurvivalIntegrationAudit_20260624.zip
SHA256: 207F84510F0B5E059714F83BF68CC1B841E140B72C495B32E4C0380A176BCF75
Size: 574,298 bytes.

## 2026-06-24 — P21--P30 middle-band integration audit

Purpose: salvage and route the newest R124 middle-band evidence after the long web run, without replaying already-integrated repairs or pretending below-threshold source witnesses certify whole papers.

Action taken:

- Read the post-R124 P22/P29/P30 actual-evidence bundle and the P21/P23 better-source upgrade ledger.
- Checked the current local R124plus candidate directly:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Verified current-candidate anchors for the P22 RA61/RA62/RA63 survival rows, including the H/G/F congruences, `\mathfrak C_1` zeta family, `\widetilde{\mathfrak C}_1`, omega terms `x_i^\gamma\zeta_\nu`, the `\Nmod_{i-1}`/`\mathfrak C_{i-1}` line, and barred `\bar R^{(i)}(z,x)`.
- Verified current-candidate anchors for the P29 RA71 header/footnote-counter repair and noted the existing gross-gap locator audit.
- Verified current-candidate anchors for the P30 post-R124 fixes: expanded footnotes 27 and 28, Axiom IV display with `\mpideal_1^{\varrho_1+1}`, and the parenthesized received date.
- Scanned the current P21 and P23--P30 line ranges for obvious placeholder/scaffold markers.
- Copied the relevant prior ledgers into a new compact package and added a fresh routing CSV, source-quality limits CSV, open-scope register, bad-pattern absence CSV, and provenance note.

Main findings:

- P22 exact repairs and no-patch anchors survive in the current candidate. Do not replay those exact rows.
- P29 header/author/footnote-counter work survives. The misnamed `noether_p29_ia_source_20260623` remains a trap: it is P24 Math. Ann. 90 pp. 229--261, not P29.
- P30 footnote/formula/date repairs survive in the current candidate.
- P21 and P23 have improved GDZ native600 source sets, but this package does not newly certify them.
- P24--P28 are present in current TeX and have no obvious placeholder tokens, but no post-R124 source-critical audit is asserted here.

Interpretation:

- No new TeX patch is proposed in this pass because the source-supported P22/P29/P30 corrections checked here are already present in the current candidate.
- This is a web-routing/survival package, not full page-by-page certification.
- The source-quality caveat remains active: P21/P23 are 600 ppi; P22 is mixed 400/600 ppi; P29 is 400 ppi; P30 is 400-ish. Under the local rule, those support exact best-available repairs only, not strict 650+/1000+ certification unless the project explicitly accepts best-available witnesses.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P21_P30_MiddleBandIntegrationAudit_20260624.zip`

SHA256: 99A5F3DC45E4E3CBC8D3B927D6FDC45EA5046F91A0548C3FE79C81CA9309F398

Size: 584,985 bytes. Extract-tested; 16 files.

## 2026-06-24 — P31--P43 upper-band integration audit

Purpose: continue the post-R124 Noether survival/integration sweep after P21--P30 by routing the upper-band evidence and checking current-candidate anchors for known exact fixes/restorations.

Action taken:

- Inventoried the P31--P43 local packages, including P31/P32 gross-gap locator packages, P33 Bologna matrix/notation repair, the P34--P43 actual evidence bundle, the P34--P43 status index, P35/P36/P38/P39 rebased source repairs, P40 complete webdrop, and P41/P43 source restorations.
- Checked the current local R124plus candidate directly:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Verified current anchors for:
  - P33 fraktur group notation repair;
  - P34 discriminant/product-table restoration;
  - P35 variable/index repair and source tail `(Rec. Math. XXXVI:1; 1929).`;
  - P36 newer post-R124 tiny fix;
  - P38 rebased source repairs, including Sigma/Sylow wording, the `K=\Lambda_0>\cdots>\Omega` chain, Normenrestsymbol anchors, and `n^n`;
  - P39 title/author/principle/crossed-product repairs and the `\Gg^\ast` Hauptgeschlecht anchor;
  - P40 complete-payload presence;
  - P41 source-structured restoration anchors, including `relativ-zyklische und -abelsche`, `u_E=e_{E,E}`, and the received date;
  - P42 RA82 survival disposition/no-new-patch row;
  - P43 editor footnote and opening `\varrho` notation.
- Scanned P31--P43 current line ranges for obvious placeholder/scaffold tokens.
- Built a compact web-drop with the current TeX reference, copied provenance ledgers, a fresh survival-anchor CSV, source-quality limits CSV, open-scope register, bad-pattern absence CSV, and supersession/trap notes.

Main findings:

- No new TeX patch is proposed in this pass.
- P31 and P32 are gross-gap locator-covered only; they are not symbol-certified.
- P33, P34, P35, P36, P38, P39, P40, P41, and P43 all have current-candidate survival anchors for the relevant exact local repairs/restorations.
- P37 is only status-sync/no-new-patch context here.
- P42 is a survival disposition only; a fresh source audit needs the best Actualites/Hermann witness.
- Important supersession: an older P36 rebased context row says `DMV39`, but the newer post-R124 P36 tiny-fix package supersedes it. The current candidate correctly carries `J. Ber. d. DMV 39 (1930), S. 17` plus the leading `2. E. Noether, Goettingen:` source line according to that newer row.

Interpretation:

- This package is useful for preventing duplicate replay of exact fixes and for routing remaining work.
- It is not a full high-resolution certification package. Most source witnesses in this band are below the strict 650 ppi floor: P31/P32/P38/P39 are 600 ppi, P34/P40 are about 400 ppi, P35/P36/P43 include 360 ppi witnesses, and P41 has best-local GDZ/IIIF pages without strict 650+ certification.
- Broad high-fidelity rows for P31--P43 remain open unless the web session explicitly accepts best-available below-threshold witnesses or better sources are found.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P31_P43_UpperBandIntegrationAudit_20260624.zip`

SHA256: 9914652BEEB2564FDF70A345117AD4F9AE42E6AA56074DBFDB726537B57E75C2

Size: 610,316 bytes. Extract-tested; 39 files.

Correction / follow-up:

- After building this package, I caught that the line range treated as "P43" was too narrow for downstream routing. In the current web R124 and local R124plus TeX, P43 proper is followed by a long R101-derived post-P43 tail: Noether-Deuring, "Algebra der hyperkomplexen Groessen"; Kapferer/Noether material; bibliography; and lists.
- The earlier P31--P43 package remains useful for P31--P42 and the early P43 survival anchors, but it must not be read as tail certification.
- The tail is present in R124 and R124plus, but the text still contains obvious OCR/locator scars (`©`, malformed `\$` section markers, `\nrightarrow`, `zuoordnet`, `\ddot{a}quivalent`, mojibake labels such as `kuxf6rper`, duplicated phrases). It is therefore a critical audit/rebuild lane, not a clean canonical German base.
- R101 initially recorded this tail as provisional because page images were missing. Source has since been acquired:
  - Noether-Deuring collected pp. 711--763 cutout, best-accessible IA-derived source, about native360.
  - Kapferer/Noether Math. Ann. 97 pp. 559--567 GDZ raw/canvas witnesses.
  - Kapferer HADW fuller context cutout.
- No TeX patch is source-safe in this correction package because the Deuring witness remains below the 650+ rule; the correct action is page-by-page rebuild/check against best-available source, with certainty limits recorded.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P43Tail_R101Backfill_StatusCorrection_20260624.zip`

SHA256: E2A9B89BE0AABC6CFC2AEE01724F7AB54F886D1C1028C44866B7D5720A7B19BD

Size: 1,130,443 bytes. Extract-tested; 18 files.

## 2026-06-24 — P10/P11 compact source-fix web drop

Purpose: make the two concrete lower-band R124-to-local-R124plus source-fix differences easy for the web session to ingest without mining separate packages.

Action taken:

- Compared raw web R124:
  `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\cum_de_R124.tex`
  against the local R124plus current candidate:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Verified raw R124 still has:
  - P10 line 7832: `f\{x\cdot(1\pm ic)\}`
  - P11 line 8033: `\varphi_3(x)=\frac{u\cdot w}{v}`
- Verified the local R124plus candidate has:
  - P10 line 7851: `f(x\cdot(1\pm ic))`
  - P11 line 8052: `\varphi_3(x)=\frac{w\cdot u}{v}`
- Built a compact web-drop with both TeX baselines, a two-line minimal patch, machine-readable audit rows, a no-replay note, and the P10 1000 dpi source crop.

Findings:

- P10 is a source-certain exact-locus correction, backed by the labelled 1000 dpi crop `P10_p545_final_rank_three_x_not_r_and_parentheses_1000dpi_labelled.png`. This is safe to apply to raw R124 if the web branch still has braces.
- P11 is kept as conditional/best-available, not strict-certified. The prior source-order audit reports the best staged full-page witness as 400 ppi, below the local 650+ rule. Apply the one-line source-order correction only if accepting that prior best-available audit, or keep it as a recheck target if better source appears.
- Both corrected readings are already present in the local R124plus candidate, so do not replay into that file.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P10_P11_SourceFix_WebDrop_20260624.zip`

SHA256: EF03BE59416527EF5692E6A54608F52878CA4BD900D41C9218EEC50A2EEAD660

Size: 2,416,634 bytes. Extract-tested; 11 files.

## 2026-06-24 — P20 source completeness backfill, pp. 32--33

Purpose: continue the Paper 20 -> Paper 10 lane by checking whether P20 can be audited from the R124 staged source images.

Action taken:

- Opened the R124 staged P20 source images from:
  `Noether_R124_20260624/1/02_src/current/P20/`.
- Verified visually that staged source image `006_P20_source_p031_1000dpi.png` is printed p31 and ends mid-proof at display (14).
- Compared against the P20 bibliographic header `Math. Ann. 85 (1922), S. 26--33`.
- Checked the current R124plus TeX P20 range:
  `\section*{20...}` at line 12462 through before P21 at line 12693.
- Found that current TeX continues through printed pp. 32--33, including display (15), display (16), the Ostrowski conclusion, `Erlangen, August 1921`, and `(Eingegangen am 28. 8. 1921.)`.
- Located full IA Math. Ann. 85 source on disk:
  `C:\Users\Floris\Documents\Papors\OS\noet du,mp ia\Codex_IA_MA83_MA85_20260624\sim_mathematische-annalen_1922_85_jp2.zip`.
- Used `page_numbers.json` to map printed p26--p33 to IA leaves 35--42.
- Extracted missing leaves 41 and 42, converted them to PNG, and packaged them together with p31 as a boundary witness.

Findings:

- R124's P20 staged source folder is incomplete: it contains pp. 26--31 only, while the article runs pp. 26--33.
- The missing pp. 32--33 are now locally packaged.
- Gross visual check of pp. 32--33 found no obvious ending omission in current R124plus TeX.
- The extracted IA leaves are native400 (`2288x3372` / `2296x3372`), so this backfill closes a source-completeness gap but does not assert strict 650+/1000+ symbol certification.
- No TeX patch is proposed from this pass.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P20_SourceCompletenessBackfill_pp32_33_20260624.zip`

SHA256: 778AFBEF2006CC89CACA70995FB67217D0ABCB82D019E1B4257242A2F6997367

Size: 9,556,646 bytes. Extract-tested; 12 files.

## 2026-06-24 — Combined post-R124 web handoff bundle

Purpose: reduce coordination overhead for the web session by bundling the current local Codex post-R124 deltas into one drag-and-drop zip.

Contents:

- `Noether_R124plus_P10_P11_SourceFix_WebDrop_20260624.zip`
- `Noether_R124plus_P20_SourceCompletenessBackfill_pp32_33_20260624.zip`
- `Noether_R124plus_P43Tail_R101Backfill_StatusCorrection_20260624.zip`
- `README_FOR_WEB.md`
- `payload_manifest.csv`

Handling note:

- Baseline remains web `Noether_R124_20260624.zip` / `cum_de_R124.tex`.
- This bundle supplies deltas, not a new global certification.
- P10 is source-certain; P11 remains conditional/best-available; P20 is source-completeness backfill; P43-tail is a status/open-work correction.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_LocalCodex_Deltas_ForWeb_20260624.zip`

SHA256: 8F4F0B6C5B69BF61BFB672A5C200A4B8D7951B374BDC66972E5436CF7B211804

Size: 13,102,977 bytes. ZIP-open tested; 5 entries.

## 2026-06-24 — P09--P13 RA56--RA63 reconciliation against R124-plus

Purpose: continue the Paper 20 -> Paper 10 non-overlap lane by auditing older "complete" P09--P13 packages before letting web/pro replay them against current R124/R124-plus.

Action taken:

- Confirmed no newer German web baseline than R124 is present in the Noether Multilingual folder.
- Reopened the older lower-band packages:
  - `N_SYM_RA56_P09_complete_20260614.zip`
  - `N_SYM_RA57_P10_complete_dupcheck_20260615.zip`
  - `N_SYM_RA58_P11_complete_20260615.zip`
  - `N_SYM_RA59_P12_complete_20260615.zip`
  - `N_SYM_RA62_P13_p235_257_20260617.zip`
  - `N_SYM_RA63_P13fix_workspace_20260617.zip`
- Re-measured local source-master image dimensions for P09--P13:
  - P09 mixed 400/600 ppi.
  - P10 mixed 400/600 ppi.
  - P11 400 ppi only.
  - P12 400 ppi only.
  - P13 mixed 400/600 ppi.
- Checked concrete P11 RA58 confirmed-fix rows against raw R124 and the R124-plus current candidate:
  - `\Omega_\Gamma` is already present.
  - the source-visible `Von Emmy Noether in Göttingen` author line is already present.
  - the final theorem paragraph has the source semicolon, not the old colon.
- Checked representative P09/P13 structural anchors in R124-plus:
  - P09 tail has source-local markers and source-style display numbering.
  - P13 has source-style formula (20), source-local notes, and the `\lg(1+p'(x))` logarithmic example.

Findings:

- No new TeX patch is proposed from this reconciliation pass.
- The old RA56--RA63 wording "closed" is too strong under the current high-resolution rule where it rests on 400/600 ppi full-page witnesses.
- RA56--RA63 remain useful as structural/source-layout/localized-fix packages.
- P11 RA58 confirmed fixes and no-fix traps are safe to keep as already absorbed/reference material.
- Future P09--P13 dense-symbol fixes should use exact targeted 1000 dpi crops, or be explicitly marked best-available/not strict-certified if no better source exists.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_P13_RA56_RA63_Reconcile_20260624.zip`

SHA256: 049B0CAE65B52ED83E2D5FB4290FA150A1C20DA853F56A05ADEB3D2F24A9F01C

Size: 9,762 bytes. ZIP-open tested; 7 entries.

## 2026-06-24 — P14--P17 RA52--RA94 reconciliation against R124-plus

Purpose: continue the Paper 20 -> Paper 10 lane by auditing P14--P17 source-critical packages and later correction packages against current R124-plus.

Action taken:

- Extracted and inspected compact audit/provenance layers from:
  - `Noether_P17_RA52_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_P16_RA53_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_P15_RA54_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_P14_RA55_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_RA77_P17_FootnoteContinuity_WebDrop_20260614.zip`
  - `Noether_RA78_P14_P15_P16_FootnoteResets_WebDrop_20260614.zip`
  - `Noether_RA89_P14_P17_SourcePDF_NativeResolution_Amendment_WebDrop_20260614.zip`
  - `Noether_RA90_P14_P17_OfficialGDZ_SourceRoutes_WebDrop_20260614.zip`
  - `Noether_RA94_P17_SourceUnfaithfulContinuationScaffoldFix_WebDrop_20260614.zip`
- Checked concrete survival in:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.

Findings:

- No new TeX patch is proposed from this pass.
- P14 RA55 fixes survive:
  - `(z-c)`.
  - `\fra=\frp_1^{\,\rho_1}\cdots\frp_\sigma^{\,\rho_\sigma}`.
  - `\calA\calN^\rho` / `\calB\calN^\sigma`.
- P15 RA54 fixes survive:
  - Latin `x` index family in the normalization block.
  - Schur citation `Math. Ann. 71, S. 355`.
- P16 RA53 fix survives:
  - `aus $F$ und aus Formen aus $M$`, not `\Phi`.
- P17 RA52/RA77/RA94 fixes survive:
  - full source title including `Differential- und Differenzenausdrücken`.
  - explicit footnotemark/text 21 and 22 at formula (39).
  - no non-source `Fortsetzung zu 17` scaffold before section 5.
- RA78 P14/P15/P16 footnote resets are structurally present.
- RA89/RA90 source-quality caveat remains active:
  - P14/P15/P16 source PDFs are native max 360 ppi.
  - P17 source PDF is native 600 ppi.
  - official GDZ routes are 400/600 ppi.
  - therefore do not claim blanket native-1000 source certification for P14--P17.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P14_P17_RA52_RA94_Reconcile_20260624.zip`

SHA256: 678CC63B48F18DD546653EB46EAD6C8F05E60D6735193F1A01780BFDFD9063E2

Size: 10,873 bytes. ZIP-open tested; 12 entries.

## 2026-06-24 - R124plus P18-P20 Reconciliation Against RA49/RA50/RA51/RA87/R117

Scope:

- Reconciled P18--P20 older repair/backfill packages against the current R124-plus candidate:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Reviewed:
  - `Noether_P18_RA51_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_P19_RA50_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_P20_RA49_SourceCritical_Fix_WebDrop_20260614.zip`
  - `Noether_P18_P19_P20_OfficialSourceBackfill_WebDrop_20260614.zip`
  - `Noether_RA87_P20_ClearpageBoundary_WebDrop_20260614.zip`
  - `Noether_RA88_P09_P20_DenseHotspot_AidLedger_WebDrop_20260614.zip`
  - loose R117 P19 diffs: `P19_R116_to_R117.diff`, `P19_emphasis_geometry_R117.diff`, `P19_sec10_geometry_R117.diff`.

Findings:

- No new TeX patch is proposed from this pass.
- P18 RA51 fix survives: the resultant endpoint reads `R^{(n)}(x_n)\equiv 0(\mathfrak M)`, not equality.
- P19 RA50 congruence-order fix survives: `\ideal Q\eqzero{\ideal P}, \ideal P^\rho\eqzero{\ideal Q}`.
- P19 RA50 elementary-divisor fix survives: the source pattern is `s_1...\s_\lambda` and `t_1...\t_\mu`, with continuation `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`.
- P20 RA49 formula (13) fix survives: factor sums use `\varrho_\kappa` and `\sigma_\lambda`; following prose keeps product indices `\varrho_\mu\sigma_\nu`.
- P20 RA87 clearpage boundary survives before Paper 20.
- R117 P19 diffs are retained as provenance/reference. This pass does not promote a new hunk from them because the inspected current R124-plus anchors already carry the relevant material.

Source-quality caveat:

- P18 official full-page GDZ witness is 600 ppi.
- P19 official full-page GDZ witness is 400 ppi.
- P20 official full-page GDZ witness is 400/600 ppi.
- Therefore these official full-page witnesses are useful for page maps/provenance and limited comparison, but not blanket dense-symbol certification under the current 650/1000 dpi rule. The localized RA49/RA50/RA51 fixes remain acceptable where those packets supplied targeted 1000 dpi witnesses for the exact loci.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P18_P20_RA49_R118_Reconcile_20260624.zip`

SHA256: E07787858FB80F371C804125E601EB9EABBCAE37B19893B373E7DDC4404EAD0C

Size: 616,923 bytes. ZIP-open tested; 20 extracted files.

## 2026-06-24 - R124plus P30 pp. 26-35 Sequential Audit, Two Footnote Fixes

Scope:

- Continued from the current R124-plus local candidate:
  `Noether_R124plus_CurrentCumulative_IntegrationAudit_20260624/01_tex/cum_de_R124plus_localcodex_current_candidate_20260624.tex`.
- Audited Paper 30 printed pp. 26--35 against the complete local IA JP2-derived Paper 30 witness:
  `Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624/source_native_png/`.
- Source-quality caveat remains active: the witness is best-available and complete, but below the strict 650+ dpi / 1000 dpi dense-math rule. It is accepted for exact visible footnote-string fixes, not for blanket strict certification.

Confirmed fixes applied in the package TeX:

- P30 printed p. 27 Krull footnote: changed `Math. Ann. 92 (1924), S. 181--213, Satz I.` to source-visible `Math. Ann. 92 (1924), S. 181--218, Satz I.`
- P30 printed p. 32 footnote 10: changed `(4. Aufl., §173, II)` to source-visible `(4. Aufl., §173, III)`.

Open issue found and explicitly not patched in this small drop:

- P30 pp. 29--35 show broad notation-fidelity drift. The source repeatedly uses blackletter mathematical objects and source-specific module/ideal letters, while the current TeX often normalizes these to plain `R`, `T`, `M`, `O`, `C`, `G`, `W`, `K`, etc. This should be repaired as a dedicated P30 notation pass with scoped source anchors, not by broad replacement.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` on the patched cumulative succeeded with exit code 0.
- Output PDF length: 467 pages.
- Existing unresolved-reference warnings persisted; no fatal error was introduced.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P30_pp026_035_SequentialAudit_KrullDedekindFix_WebDrop_20260624.zip`

SHA256: AC9DF5D15404B6F07A251BD6EC9B2DBE6B4F101F017958B0D743908C40598C38

Size: 28,743,000 bytes. ZIP-open tested; 24 extracted files.

## 2026-06-24 - R124plus P30 pp. 29-35 Notation Repair

Scope:

- Continued from the P30 p27/p32 footnote-fix candidate:
  `Noether_R124plus_P30_pp026_035_SequentialAudit_KrullPageFix_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p27_p32_FootnoteFixes_20260624.tex`.
- Audited Paper 30 printed pp. 29--35 against the complete local IA JP2-derived Paper 30 witness:
  `Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624/source_native_png/`.
- Source-quality caveat remains active: this complete Paper 30 source is the best local complete witness available here, but it is below the strict 650+ dpi / 1000 dpi dense-math rule. It was used for directly visible notation repairs only, not for blanket Paper 30 certification.

Confirmed repairs applied in the package TeX:

- Restored the source-visible blackletter notation layer in P30 pp. 29--35 where the active cumulative had normalized many objects to plain letters: `\mR`, `\mT`, `\mM`, `\mN`, `\mU`, `\mC`, `\mO`, `\mS`, `\mA`, `\mB`, `\mK`.
- Corrected the Hilfssatz proof notation on p32: source `\mS`, `\sigma_i`, `\sigma_m`, and determinant display `\left|r_{ik}-\alpha e_{ik}\right|=0`.
- Restored the system/transitive-law notation on pp. 32--33, including source `\mS` rather than normalized `G`/`O`.
- Repaired Dedekind Folgerung I notation on pp. 33--34: source-style chain `\mC\mR_1,\mC\mR_2,\ldots,\mC\mR_\rho,\ldots` and ideals `\mc_1,\ldots,\mc_\rho`.
- Repaired Dedekind Folgerung II and §2 opening notation on pp. 34--35, including the source quotient notation `\mA/\mB` and chain `\mA_\nu`.
- Added preamble macro `\providecommand{\mc}{\mathfrak{c}}`, required by the restored lower-case fraktur c notation before Paper 30's local macro block.

Open caveat:

- The p35/p36 boundary in the Zusatzbemerkung is touched by this repair (`\overline{M}` and `\mC/\overline{\mC}`); p36 still needs direct audit before certifying the full paragraph.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` on the patched cumulative succeeded.
- Output PDF length: 467 pages.
- Existing unrelated unresolved-reference warnings persisted; no fatal error was introduced.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P30_pp029_035_NotationRepair_WebDrop_20260624.zip`

SHA256: E6E44926AAD0B506C95FF85773869C88D04106ABCC61A10762593B839737ED9C

Size: 29,927,687 bytes. ZIP-open tested; 21 extracted files.

## 2026-06-24 - R124plus P30 p35/p36 Zusatzbemerkung Boundary Fix

Scope:

- Continued from:
  `Noether_R124plus_P30_pp029_035_NotationRepair_WebDrop_20260624.zip`.
- Closed the explicit p35/p36 Zusatzbemerkung caveat left by the previous P30 notation repair.
- Source checked against:
  `Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624/source_native_png/P30_MA96_printed_p035_IA_leaf0040_native.png`
  and
  `Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624/source_native_png/P30_MA96_printed_p036_IA_leaf0041_native.png`.

Confirmed fix:

- Restored source module notation in the Zusatzbemerkung boundary paragraph:
  `\mA` and `\overline{\mA}`, not plain `M` / `\overline{M}`.
- Restored the source construction
  `n_1\xi_{k+1}+\cdots+n_k\xi_{2k}`.
- Restored the source replacement sentence:
  `\xi_{k+\lambda}` durch `\xi_\lambda`.
- Restored the final proof reference to `\overline{\mA}` and `\mA`.

Source-quality caveat:

- The complete Paper 30 IA JP2-derived witness remains below the strict 650+ dpi / 1000 dpi target. This repair is accepted because the affected boundary text is directly readable on the native p35/p36 images and was cross-checked with labelled readability crops derived from those pages.
- This is not a full Paper 30 certification.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` on the patched cumulative succeeded.
- Output PDF length: 467 pages.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P30_p035_036_ZusatzBoundaryFix_WebDrop_20260624.zip`

SHA256: D412D0DB2C6C5E1747515277D2C118CE67D962D8D2B96DF7C0F64A1D11EA23AC

Size: 18,399,411 bytes. ZIP-open tested; 15 extracted files.

## 2026-06-24 - R124plus P12 pp. 42-44 Tail Audit, No Patch

Scope:

- Returned to the stale P12 full-page re-audit row after the P30 notation repairs.
- Audited Paper 12 printed/source pp. 42--44 against the staged GDZ/IIIF source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P12_GDZ_original_pp037_044_IIIF_fullres_jpg/`.
- Compared against the current R124-plus cumulative candidate:
  `Noether_R124plus_P30_p035_036_ZusatzbemerkungBoundaryFix_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p035_036_zusatz_boundary_fix_20260624.tex`.

Disposition:

- No TeX patch proposed.
- p42 formulas (11)--(14) and the following `F_\rho(\delta u,du)` derivative display match the current TeX materially.
- p43 derivative equality, projective-invariant reduction paragraph, `\Psi_\rho(\delta x,dx)`, functions (8), Polarprozesse/Clebsch-Gordan passage, and equivalence conclusion match the current TeX materially.
- p44 final continuation, Reduktionssatz special case, `[Ω_2]` / `[Ω_p]` chain, constant-coefficient condition, and final Math. Annalen sentence match the current TeX materially.

Source-quality caveat:

- The staged P12 GDZ/IIIF witnesses are best-available here but approximately native 400 PPI.
- This package is therefore a best-available no-patch disposition, not strict 650+ PPI full-page certification.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P12_p042_044_BestAvailableNoPatch_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P09 pp. 103-105 Best-Available Audit, No Patch

Scope:

- Continued the non-overlap lower-band audit after the P12 tail no-patch package.
- Targeted Paper 09 printed/source pp. 103--105, the opening band of `Die allgemeinsten Bereiche aus ganzen transzendenten Zahlen`.
- Used current local TeX candidate:
  `Noether_R124plus_P30_p035_036_ZusatzbemerkungBoundaryFix_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p035_036_zusatz_boundary_fix_20260624.tex`.
- Source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P09_GDZ_original_pp103_128_IIIF_fullres_jpg/P09_GDZ_p103_canvas_00000109.jpg`
  through
  `P09_GDZ_p105_canvas_00000111.jpg`.

Disposition:

- No TeX patch proposed.
- p103: title, author line, opening abstract properties I--IV, Zermelo footnote `Math. Ann. 75, S. 484 (1914)`, algebraic-basis paragraph, and star/double-star/triple-star footnote content match the current TeX materially.
- p104: Basiseigenschaften 3)--5), Zermelo §3 footnote, non-isomorphism paragraph, property V, definition of Bereiche `\mathfrak H`, and result paragraphs a)--b) for Bereiche `\mathfrak H` match the current TeX materially.
- p104 suspicious prose trap checked: source reads `eineindeutig`; the current TeX already has `eineindeutig`, so no correction is needed.
- p105: continuation of result b), rational-basis `\Theta` definition, `[\\Theta]` condition, rational-ganze result paragraphs a)--b), analogy paragraph, and totality/classes sentence through `(\S 8)` match current TeX materially before the TeX enters §1.

Source-quality caveat:

- The staged P09 GDZ/IIIF witnesses for pp. 103--105 are native 400 PPI.
- This package is a best-available no-patch disposition for these pages, not a strict 650+ PPI certification or a full-paper closure.
- No temporary crop was retained or shipped; the one p104 readability crop used to check `eineindeutig` was deleted after inspection.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_p103_105_BestAvailableNoPatch_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P09 pp. 106-108 Weber Footnote Fix

Scope:

- Continued Paper 09 source-critical audit to printed/source pp. 106--108.
- Used current local TeX candidate:
  `Noether_R124plus_P30_p035_036_ZusatzbemerkungBoundaryFix_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p035_036_zusatz_boundary_fix_20260624.tex`.
- Source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P09_GDZ_original_pp103_128_IIIF_fullres_jpg/P09_GDZ_p106_canvas_00000112.jpg`
  through
  `P09_GDZ_p108_canvas_00000114.jpg`.

Confirmed repair:

- p106 Weber footnote: source prints `H. Weber, Lehrbuch der Algebra. Kleine Ausgabe § 96 und 97.`
- Current TeX had `Kleine Ausgabe §§ 96 und 97.`
- Patched to the source singular section sign.

No-patch dispositions:

- p106: §1 heading and proof text, `H`, `H'`, `\xi=f(\eta)`, §2 heading, and Weber footnote context otherwise match materially.
- p107: rational-functional display, definitions, and Weber footnotes `§ 97, 8`, `§ 20, 5`, and `§ 97, 4` match materially.
- p108: `a_k/z`, radical expressions, §3 heading, formula (1), and star/double-star/triple-star footnotes match materially for the visible p108 range.

Source-quality caveat:

- The staged P09 GDZ/IIIF witnesses for pp. 106--108 are native 400 PPI.
- The repair is accepted because the affected prose-footnote text is directly readable and not a dense mathematical region; this remains best-available, not strict full-page certification.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` completed successfully on the patched cumulative TeX.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_p106_108_WeberFootnoteFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P09 pp. 109-114 Best-Available Spot Audit, No New Patch

Scope:

- Continued Paper 09 source-critical audit after the p106 Weber-footnote fix.
- Targeted printed/source pp. 109--114, including the §4 construction around `\mathfrak M(\mathfrak H)`, the p112 coefficient display, the §4 summary, and the §5 opening formula cluster.
- Used current local TeX candidate:
  `Noether_R124plus_P09_p106_108_WeberFootnoteFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P09_p106_weber_footnote_fix_20260624.tex`.
- Source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P09_GDZ_original_pp103_128_IIIF_fullres_jpg/P09_GDZ_p109_canvas_00000115.jpg`
  through
  `P09_GDZ_p114_canvas_00000120.jpg`.

Disposition:

- No TeX patch proposed.
- p109--p110: formula/prose continuation around `F_\nu`, `C(\eta)`, and `G_{\nu\chi}(\eta)` matches materially at checked anchors.
- p111: rejected the tempting `\mathfrak M(\mathfrak H)` -> `\mathfrak M(H)` change. Source glyph and surrounding notation use the blackletter domain argument here; current TeX should remain unchanged.
- p112: rejected the tempting `z^\nu` -> `z^\chi` change. Source display reads `z^\nu+a z^{\nu-1}+\cdots+c=0`, matching current TeX and the earlier P09 p112 hotspot no-patch disposition.
- p113: summary occurrences of `\mathfrak M(\mathfrak H)` match the current blackletter-domain notation.
- p114: §5 opening `\mathfrak M(\mathfrak G)`, formula (1) with `\eta_i^\nu`, and formulas (2)--(3) with `\chi` match the current TeX at checked anchors.

Source-quality caveat:

- The staged P09 GDZ/IIIF witnesses for pp. 109--114 are native 400 PPI.
- This package is a best-available spot disposition and no-fix trap ledger, not strict 650+ PPI full-page certification.
- No fake-upscaled crops were retained or shipped.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_p109_114_BestAvailableNoPatch_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P09 pp. 115-118 Best-Available Spot Audit, No New Patch

Scope:

- Continued Paper 09 source-critical audit through printed/source pp. 115--118.
- Used current local TeX candidate:
  `Noether_R124plus_P09_p106_108_WeberFootnoteFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P09_p106_weber_footnote_fix_20260624.tex`.
- Source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P09_GDZ_original_pp103_128_IIIF_fullres_jpg/P09_GDZ_p115_canvas_00000121.jpg`
  through
  `P09_GDZ_p118_canvas_00000124.jpg`.

Disposition:

- No TeX patch proposed.
- p115: formula (4), formula (5), the `\nu>\chi\lambda` conclusion, `[H]` intersection result, and `K`, `\mathfrak K`, `\mathfrak L` primitive-element paragraph match current TeX at checked anchors.
- p116: §6 heading, rational-basis definition, `K` coefficient footnote, ordering footnote, Zermelo footnote, and `z=\varphi(\xi)` / `z=\psi(\vartheta)` transition match current TeX at checked anchors.
- p117: rational basis with Nebenbedingung, `\mathfrak N(\mathfrak G)`, `[ \Theta ]`, admissible system `\mathfrak S`, and the footnote contrasting `\eta,1/(2\sqrt{\eta})` with `\eta,1/\sqrt{\eta}` match current TeX at checked anchors.
- p118: Bemerkung and §7 transition, including the `\mathfrak S_1`, `\mathfrak S_2` decomposition and first §7 item/footnotes, match current TeX at checked anchors.

Source-quality caveat:

- The staged P09 GDZ/IIIF witnesses for pp. 115--118 are native 400 PPI.
- This package is a best-available spot disposition, not strict 650+ PPI full-page certification.
- No fake-upscaled crops were retained or shipped.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_p115_118_BestAvailableNoPatch_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P09 pp. 119-122 Best-Available Spot Audit, No New Patch

Scope:

- Continued Paper 09 source-critical audit through printed/source pp. 119--122.
- Used current local TeX candidate:
  `Noether_R124plus_P09_p106_108_WeberFootnoteFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P09_p106_weber_footnote_fix_20260624.tex`.
- Source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P09_GDZ_original_pp103_128_IIIF_fullres_jpg/P09_GDZ_p119_canvas_00000125.jpg`
  through
  `P09_GDZ_p122_canvas_00000128.jpg`.

Disposition:

- No TeX patch proposed.
- p119: §7 continuation, items 2 and 3, the `z=\varphi(\xi_1\cdots\xi_t)` relation, the `\Theta` rational-basis assertion, and formula (1) match current TeX at checked anchors. The known no-fix trap remains: source uses `\xi_t`, not `\xi_h`.
- p120: finite intermediate-field paragraph, `\Omega_0=(H), \Omega_1,\ldots,\Omega_\sigma`, primitive function `g_i(\vartheta)/h_i(\vartheta)`, `\xi_i=g_i(\vartheta)+\alpha_i h_i(\vartheta)`, formula (2), the irreducible equation for `y`, the transformed equation for `y_i`, formula (3), and formula (4) match current TeX at checked anchors.
- p121: formula (5), the blackletter coefficient field `\mathfrak K=(H;k_0(\vartheta)\cdots k_\nu(\vartheta))`, the Durchschnittskörper argument, formula (6), formula (7), and the rational-ganze Adjunktion conclusion match current TeX at checked anchors.
- p122: §8 heading, the Steinitz footnote attached to the heading, the isomorphism definition, `\mathfrak M(\mathfrak G)` / `\mathfrak M^*(\mathfrak G)`, and the `**` / `***` footnotes match current TeX at checked anchors.

Source-quality caveat:

- The staged P09 GDZ/IIIF witnesses for pp. 119--122 are native approximately 400 PPI.
- This package is a best-available spot disposition, not strict 650+ PPI full-page certification.
- No fake-upscaled crops were retained or shipped.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_p119_122_BestAvailableNoPatch_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P09 pp. 123-128 Omega Definition Fix

Scope:

- Completed the Paper 09 tail audit through printed/source pp. 123--128.
- Used current local TeX candidate:
  `Noether_R124plus_P09_p106_108_WeberFootnoteFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P09_p106_weber_footnote_fix_20260624.tex`.
- Source witnesses:
  `Noether_RA79_P09_P13_FootnoteResets_WebDrop_20260614/source/fullres_iiif/P09_GDZ_original_pp103_128_IIIF_fullres_jpg/P09_GDZ_p123_canvas_00000129.jpg`
  through
  `P09_GDZ_p128_canvas_00000134.jpg`.

Confirmed patch:

- p127, §10 definition block: the source uses capital Greek `\Omega` for the arbitrary body in both italic definition paragraphs.
- The local R124-plus candidate incorrectly used `\mathfrak R` in six positions:
  `Körpers`, `Größen aus`, and `Quotientenkörper` in the ordinary definition; the same three positions in the algebraically closed definition.
- Patched all six positions to `\Omega`.

No-patch dispositions:

- p123: §8 continuation around `\mathfrak M(\mathfrak G)`, `\mathfrak L(\mathfrak G)`, and the class-representative induction matches current TeX at checked anchors.
- p124: §8 summary, `\mathfrak R_i` / `\mathfrak R_i^*` class notation, §9 heading, formula (1), and footnotes match current TeX at checked anchors.
- p125: dense congruence block formulas (2)--(6), including `\chi_\nu`, `A(\eta)`, `\mathfrak M_{\nu\kappa+1}`, and the `a_0`, `a_1` vanishing argument, match current TeX at checked anchors.
- p126: `\sigma>\tau` argument, `\xi^\tau` case split, non-isomorphism conclusion, remark, self-subdomain example, and §10 opening/footnotes match current TeX at checked anchors.
- p128: characteristic-zero / characteristic-`p` result paragraph, final result wording, Erlangen date, and final footnote match current TeX at checked anchors.

Source-quality caveat:

- The staged P09 GDZ/IIIF witnesses for pp. 123--128 are native 400 PPI.
- The `\Omega` correction is accepted because the symbol is large and repeated in the source definition block.
- The dense p125 formula block remains best-available checked, not strict 1000 PPI final certification.
- No fake-upscaled crops were retained or shipped.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Final pass exit code 0; output PDF written, 467 pages.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P09_p123_128_OmegaDefinitionFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P10 p538 Integritätsbereich J-domain Fix

Scope:

- Continued from the local current candidate after the Paper 09 Omega repair / Paper 10 survival checkpoint.
- Audited Paper 10 printed/source pp. 536--538 against GDZ/IIIF raw page witnesses:
  `Noether Multilingual/source_master_checks/P10_GDZ_original_pp536_545_IIIF_fullres_jpg/P10_GDZ_MathAnn77_p536_canvas00000554.jpg`
  through
  `P10_GDZ_MathAnn77_p538_canvas00000556.jpg`.

Confirmed patch:

- p538, Integritätsbereich paragraph: the source uses fraktur `J` in four positions:
  `einen Integritätsbereich J`, `nicht zu J`, `aus J`, and `J'`.
- The local current candidate used `\Sdomain`, defined as `\mathfrak S`, at all four positions.
- Patched those four occurrences to the already-existing `\Jdom` macro, defined as `\mathfrak{J}`.

No-patch dispositions:

- p536 title/frontmatter, author line, functional equations (1)--(4), and opening footnote anchors survive in the current candidate.
- p537 opening paragraph, Nr. 1 opening, first displayed zero proof, and footnote anchors survive in the current candidate.
- p538 Dedekind footnote attached to the Integritätsbereich paragraph survives.

Source-quality note:

- p538 raw IIIF page is the best local authority located for this locus; dimensions in the local ledger are 3075 x 4812 pixels.
- The shipped p538 crop is a zoomed inspection aid from the raw IIIF image, not a fake native-resolution upgrade.
- The patch is accepted because the source glyph is large, repeated four times in the same paragraph, and disambiguated by the Integritätsbereich context.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Both passes exited 0.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P10_p538_JdomainFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P10 pp. 539-542 No-New-Patch Continuation

Scope:

- Continued Paper 10 from the patched p538 `\Jdom` cumulative candidate.
- Audited printed/source pp. 539--542 against raw GDZ/IIIF page witnesses:
  `P10_GDZ_MathAnn77_p539_canvas00000557.jpg` through
  `P10_GDZ_MathAnn77_p542_canvas00000560.jpg`.

Disposition:

- No new TeX patch proposed.

Checked anchors:

- p539: rational-basis paragraph, section-field `\Kfield(\vartheta)` setup, algebraic-basis paragraph, Zermelo footnote, and Steinitz footnote match the current candidate at checked anchors.
- p540: construction of corresponding basis `Z`, definition (a)--(d), the earlier `k_\sigma` repair, rational-function displays for (1)/(3), and the `H(\vartheta)` footnote match current TeX at checked anchors.
- p541: induction-proof contradiction setup, `H(\vartheta_0)` display, algebraically independent case, factorization `H(t;a_i(\vartheta))=F(t;\vartheta_i)G(t;\vartheta_i)`, transformed display `H(t;a_i(f(\vartheta)))=F(t;f(\vartheta))G(t;f(\vartheta))`, and surrounding prose match at checked anchors.
- p542: end of Nr. 3, abstract-field/prime-field conclusion, §4 opening, Hamel rank setup, two-equation display in `\alpha,\beta`, and linear-basis footnote match at checked anchors.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P10_p539_542_NoNewPatch_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P10 pp. 543-545 Display-Dot Fix and Tail Closure

Scope:

- Continued Paper 10 from the patched p538 `\Jdom` cumulative candidate.
- Audited printed/source pp. 543--545 against raw GDZ/IIIF page witnesses:
  `P10_GDZ_MathAnn77_p543_canvas00000561.jpg` through
  `P10_GDZ_MathAnn77_p545_canvas00000563.jpg`.

Confirmed patch:

- p544, rank-two displayed formula: the source reads
  `\varphi(z)=(\lambda_1x+\lambda_2y)+i\cdot(\mu_1x+\mu_2y)`.
- The current candidate had normalized this as `+i(\mu_1x+\mu_2y)`.
- Patched the cumulative TeX to restore the explicit source multiplication dot:
  `+i\cdot(\mu_1x+\mu_2y)`.

No-patch dispositions:

- p543: rank-three relation, determinant/rank-four setup, approximation system, and complex linear-combination display match current TeX at checked anchors.
- p544: sign-pair structure `Y\mp y`, the `c_4=0` / `c_3=0` cases, `f(iy)=i\cdot\Yreal`, and `(Y\mp y)=c\cdot(X-x)` match current TeX after the display-dot patch.
- p545: final rank-three exclusion, the two footnotes, and the Erlangen date match current TeX at checked anchors.
- p545 no-fix trap remains valid: the source uses the real variable `x` in the final example/footnote context, not `r`.

Source-quality note:

- The p543--p545 raw GDZ/IIIF images are the best local authority used for this pass.
- No fake-upscaled crops were used or retained; source page images are included as raw witnesses.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Both passes exited 0.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P10_p543_545_DisplayDotFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P12 pp. 37-41 Best-Available Page Audit

Scope:

- Audited Paper 12, `Invarianten beliebiger Differentialausdrücke`, source pp. 37--41.
- Used raw GDZ/IIIF full-page JPEGs from:
  `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\source_master_checks\P12_GDZ_original_pp037_044_IIIF_fullres_jpg`.
- Base TeX was the current local cumulative after the P10 p544 display-dot repair.

Disposition:

- No new German TeX patch proposed.

Checked anchors:

- p37: title/author/session line, opening definition, transformation display (1), invariant identity, source footnote.
- p38: projective-invariant paragraph, lower-case `betracht`, Christoffel/Ricci/Riemann/Lipschitz references, homogeneity footnote.
- p39: section I opening, displays (2), (3), and (4), including the barred-variation series and the `\Omega_\rho` alternating terms.
- p40: Riemann Ansatz paragraph, displays (5), (6), and (7), first-order homogeneity exception, linear-form footnote, covariant derivative setup.
- p41: display (8), cogredient-argument paragraph, homogeneity claim, section II opening, displays (9), (10), and start of (11).

Source-quality note:

- The P12 raw GDZ/IIIF witnesses are 2296 x 3688 px and locally recorded as best available.
- This is not strict 650+ ppi certification; no fake-upscaled crops were used.
- The audit is useful to retire this stale queue item from the current web lane, but should remain supersedable if a genuinely higher-resolution witness appears.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P12_p037_041_BestAvailablePageAudit_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P20 pp. 32-33 Field-Symbol / Delta Fix

Scope:

- Strengthened the earlier P20 source-completeness backfill for printed pp. 32--33.
- Used the IA JP2-derived native400 page witnesses from:
  `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P20_SourceCompletenessBackfill_pp32_33_20260624\02_source_missing_pages`.
- Base TeX was the current local cumulative after the P10 p544 display-dot repair.

Confirmed patches:

- P20 p33: replaced `\Omega` by source-visible `\frK` in the finite algebraic number-field definition and its prime-ideal phrase.
- P20 p33: replaced `\Omega` by source-visible `\frK` in the sentence saying `\mathfrak r=(P_1,P_2,\ldots)` is divisible by only finitely many prime ideals from that field.
- P20 p33: replaced common-denominator `\Lambda` by source-visible `\Delta` in the final paragraph.

No-patch/source-continuity checks:

- P20 p32: display (15), converse/factorization paragraph, the condition (15) sentence, `S(Z,u)=\sum\Phi_\lambda(Z)U_\lambda`, and display (16) were checked as context for the p33 repairs.
- P20 p33: the Ostrowski paragraph, `\bar E(x)` display, `R(\Gamma,u)` display, irreducibility modulo `\mathfrak p` conclusion, Erlangen date, and received date were checked.

Source-quality note:

- The available p32--p33 witnesses are native about 400 ppi, not strict 650+ ppi.
- The p33 glyphs for `\frK` and `\Delta` are visually source-certain in the best available witness.
- Native crops are included for navigation/readability only; no fake-upscaled crops were created or used as authority.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Second pass produced a PDF with no fatal errors and no undefined-control-sequence errors; inherited font warnings remain.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P20_p032_033_FieldSymbol_DeltaFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P19 pp. 58-60 / 65-66 Footnote Separator Fix

Scope:

- Audited Paper 19, `Idealtheorie in Ringbereichen`, printed pp. 58--60 and 65--66.
- Used local IA JP2 source pages from:
  `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP40_P19_P20_IA400_RA50_RA49Survival_NoNewPatch_20260624\source\P19\ia_jp2`.
- Base TeX was the current local cumulative after the P20 p33 field-symbol / Delta repair.

Confirmed patch:

- P19 p59, footnote 44: changed the two bracketed-component separators from commas to source-visible semicolons:
  `[(x^3,y);(y^3,x)]` and `[(xy,x^3,y^3,x+y^3);(xy,x^3,y^3,y+x^2)]`.
- Motivation: the commas inside each ideal remain generator separators; the source visibly uses semicolons between the two bracketed components.

Checked with no new patch:

- p58: the known hot formula order survives as `\ideal Q\eqzero{\ideal P}`, then `\ideal P^\rho\eqzero{\ideal Q}`; surrounding paragraph and footnote boundary checked.
- p59: displayed `B`, `P`, `Q`, and `R` ideal examples checked aside from the footnote separator repair.
- p60: displayed `S`, `M`, `D`, `B`, and `P` examples, congruences, and footnote 46 checked.
- p65: elementary-divisor systems and vertical-bar notation checked.
- p66: continuation inequality, one-sided-class footnote 51, matrix examples, closing date, and received date checked.

Source-quality note:

- The witnesses are best-available local IA400 JP2 pages converted to PNG without scaling.
- This is not strict 650+ ppi certification; no fake-upscaled crops were used.
- Recheck if a genuinely higher-resolution witness appears.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Both passes exited 0.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P19_p058_060_p065_066_FootnoteSeparatorFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P19 pp. 61-64 Sigma Exponent Fix

Scope:

- Audited Paper 19, `Idealtheorie in Ringbereichen`, printed pp. 61--64.
- Used local IA JP2 source pages from:
  `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plusP40_P19_P20_IA400_RA50_RA49Survival_NoNewPatch_20260624\source\P19\ia_jp2`.
- Base TeX was the current local cumulative after the P19 p59 footnote-separator repair.

Confirmed patch:

- P19 p62: changed the composite-integer definition from
  `$g=p_1^{\nu_1}\cdots p_\nu^{\nu_\nu}$`
  to source-visible
  `$g=p_1^{\sigma_1}\cdots p_\nu^{\sigma_\nu}$`.
- Motivation: the source line visibly uses sigma exponents; `\nu` is the terminal index, not the exponent family.

Checked with no new patch:

- p61: even-number example, displayed `Q`/`B`/`P` ideal formulas, congruence prose, and decomposition continuation checked.
- p63: noncommutative-ring example, `T` residue-class double domain, section 12 heading, and Du Pasquier footnote checked.
- p64: module display, right/left ideal basis discussion, footnote 49, and transition to two-sided classes checked.

Source-quality note:

- The witnesses are best-available local IA400 JP2 pages converted to PNG without scaling.
- This is not strict 650+ ppi certification; no fake-upscaled crops were used.
- The p62 crop is included only as a locator/readability aid.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Both passes exited 0; compiled German cumulative PDF is 467 pages.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P19_p061_064_SigmaExponentFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P30 pp. 37-40 Footnote 17 / Ein-eindeutig Fix

Scope:

- Audited Paper 30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, printed pp. 37--40.
- Used local complete P30 MA96 source cutout:
  `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624`.
- Base TeX was the current local cumulative after the P19 p62 sigma-exponent repair.

Confirmed patches:

- P30 p39: changed `eineindeutig entsprechen` to source-visible `ein-eindeutig entsprechen`.
- P30 p40: restored omitted source footnote 17, `Vgl. dazu Anmerkung 6.`, after the sentence ending `neue Elemente von \overline M auffaßt`.

Checked with no new patch:

- p37: tail of §3 and transition material checked for continuity.
- p38: continuation of §3 checked for continuity.
- p39: §4 opening, footnote 15, and footnote 16 anchor checked at this level.
- p40: first/second isomorphism theorem opening and footnote 18 anchor checked at this level.

Source-quality note:

- The witnesses are best-available local IA JP2 pages and native PNG conversions, around native IA 400ppi.
- This is not strict 650+ ppi certification; no fake-upscaled crops were used.
- Recheck if a genuinely higher-resolution witness appears.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Both passes exited 0.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P30_p037_040_Footnote17_EinEindeutigFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus P30 pp. 41-44 Congruence Fix

Scope:

- Audited Paper 30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, printed pp. 41--44.
- Used local complete P30 MA96 source cutout:
  `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_P30_MA96_Complete_IA_JP2_SourceCutout_BestAvailable_20260624`.
- Base TeX was the current local cumulative after the P30 pp. 37--40 footnote 17 / `ein-eindeutig` repair.

Confirmed patch:

- P30 p41 / §4δ: restored the source-visible congruence marker in
  `\mv=\mo\mv=(\ma\mv,\mb\mv)\equiv0(\ma,\mb)`.
- Motivation: the source line reads `v = o v = (a v, b v) ≡ 0(a,b)`; the cumulative had flattened this relation to equality before `0(a,b)`.

Checked with no new patch:

- p42: direct-sum / lcm paragraph checked at this level. Current TeX uses project normalization for congruence notation; no source-certain local patch made.
- p43: §5 opening on prime and primary ideals checked at this level.
- p44: primary-ideal argument and footnotes 23--24 checked at this level.

Source-quality note:

- The witnesses are best-available local IA JP2 pages and native PNG conversions, around native IA 400-ish PPI.
- This is not strict 650+ PPI certification; no fake-upscaled crops were used.
- Recheck if a genuinely higher-resolution witness appears.

Compile check:

- `lualatex -interaction=nonstopmode -halt-on-error` run twice on the patched cumulative TeX.
- Both passes exited 0.

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624.zip`

## 2026-06-24 - R124plus consolidated post-R124 web drop

Built a compact consolidation package for the active web session after the `Noether_R124_20260624.zip` baseline:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_LocalCodex_PostR124_Consolidated_WebDrop_20260624.zip`

SHA256:

`EEA5CFD9241C2DD01A6D1BA5E2EBF4D278A7F8E55452AD64770EB276C277B2B3`

Purpose:

- Provide one drag-ready package with the latest local cumulative German TeX candidate after post-R124 Local Codex fixes.
- Include the raw `cum_de_R124.tex` baseline, the current candidate, the R124-to-current diff, the compiled PDF from the latest candidate, compile logs, a machine-readable fix/audit ledger, individual package inventories, queue-map CSV copies, and the post-R124 logbook excerpt.
- Avoid bulk source image duplication; individual image/evidence packages remain listed by path and checksum.

Important merge note:

- If web is still on raw R124, use the current cumulative candidate or apply the diff.
- If web has already integrated some Local Codex packages, do not replay individual patches blindly; use the ledger/diff to cherry-pick only missing source-confirmed changes.
- This package is an integration/merge aid, not a new full source-page certification.

## 2026-06-24 - R124plus P34 table patch survival in current candidate

Built:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P34_TablePatchSurvival_CurrentCandidate_NoNewPatch_20260624.zip`

SHA256:

`003385EF3875A2E850926F2CDB7F4A19900C3717C0D7937FAF953A4E5C6B5CE1`

Scope:

- Checked that the P34 discriminant/product-table repair from `Noether_R124_PostWeb_P34_DiscriminantTable_SourcePatch_20260624` survives in the latest current candidate after later P19/P20/P30 edits.
- Current candidate checked:
  `Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Result:

- No TeX patch.
- Restored source-style table block is present at current candidate lines 18197--18242.
- Old flattened block beginning `Für einen Matrizenring \sum c_{ik}P erhält man...` is absent.
- The current candidate has the product table, `l_1/l_2` row labels, trace determinant, `Folge`, and `D_{\rm red}=e` consequence anchors.

Source-quality caveat:

- This verifies survival of the existing source patch; it does not upgrade P34 to final certification.
- The staged source witness remains GDZ 400dpi. Treat row-brace geometry as needing higher-source confirmation if a better witness appears.

## 2026-06-24 - R124plus P35/P36/P38/P39 rebased repairs survive in current candidate

Built:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P35_P36_P38_P39_Survival_CurrentCandidate_NoNewPatch_20260624.zip`

Scope:

- Checked the current candidate after later P19/P20/P30/P34 edits for survival of the P35/P36/P38/P39 source-repaired anchors from `Noether_R124plusP40_P35_P36_P38_P39_RebasedSourceRepairs_20260624`.
- Current candidate checked:
  `Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Result:

- No new TeX patch.
- P35 corrected `G^*` cluster survives.
- P36 source Noether item text survives, including `Idealdifferentiation und Differente`, `E. Noether, Göttingen`, and italicized `Differentialquotient` / `Ideals`.
- P38 Lambda-chain `K=\Lambda_0>\cdots>\Lambda_r=\Omega`, Normenrestsymbol cluster, and Hasse footnote anchors survive.
- P39 author line is `Von Emmy Noether, Göttingen`; stale `Bryn Mawr` contamination is absent; `Prinzip` and crossed-product emphasis survive.

No-patch trap:

- P36 has a bibliographic wrapper line `J. Ber. d. DMV 39 (1930), S. 17`. The prior repair package wording suggested `DMV39`, but the visually checked source page is the source text/body, not that wrapper typography. No source-certain spacing patch made.

Source-quality caveat:

- This is a survival check of prior repairs, not final certification.
- Staged P35/P36/P38/P39 witnesses are best-available around 600 ppi or lower in places, below the strict 650+ / 1000 dense-math rule.

## 2026-06-24 - R124plus P10 p537 full-page supplement and p538 J-domain survival

Built:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P10_p537_FullPageSupplement_JdomainSurvival_NoNewPatch_20260624.zip`

Scope:

- Paper 10, printed p537, because the R124 queue still asked for p536--545 audit and the existing p538 package only explicitly claimed named anchors on p536--p538.
- Also checked that the p538 `\Jdom` repair survives in the current latest candidate.

Result:

- No new TeX patch.
- p537 visually checked against the best staged raw GDZ/IIIF source page:
  `Noether Multilingual/source_master_checks/P10_GDZ_original_pp536_545_IIIF_fullres_jpg/P10_GDZ_MathAnn77_p537_canvas00000555.jpg`.
- Current candidate matches the source-visible p537 content at the checked full-page level: Hamel setup paragraph, Nr. 1 opening, `f(0)=0`, zero proof, invertibility/eineindeutig statement, rational-operation statement, and page-bottom footnotes.
- p538 `\Jdom` repair survives: current candidate line 7702 has `\Jdom` for the Integritätsbereich / zu J / aus J / J' locus, and searches found no stale `\Sdomain` readings there.

Source-quality caveat:

- The p537 source is best-available raw GDZ/IIIF but below strict 650+ final-certification quality.
- This closes a practical stale-gap/no-patch audit slice, not final Paper 10 certification.
### 2026-06-24 -- P40 survival check against R124-plus current candidate

Compared the `\section*{40. ...}` span in the current R124-plus candidate
`Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`
against the P40-complete reference package
`Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624/tex/cum_de_R124_plus_LocalCodex_P40Complete_20260624.tex`.

Result: byte-identical P40 span. Both spans are 798 lines, 79,150 UTF-8 characters, SHA256
`7892DDA801F7D8667574B64B112E9F4AB50EAEDAB53D24BB2DFB13337DE61205`.

Packaged compact web-drop:
`Noether_R124plus_P40_GDZ400CompleteSurvival_NoNewPatch_20260624.zip`.
No new patch. Caveat remains: P40 source witness is GDZ about 400ppi, so this is survival of the best-available P40 repair, not final 650+ dpi certification.

### 2026-06-24 -- P04/P11 survival check against R124-plus current candidate

P04 pp. 140--145: normalized the old source-audit TeX anchor by stripping stale line-number prefixes and searched it in the latest R124-plus current candidate. Result: exact full-anchor survival. The normalized P04 anchor is 556 lines and SHA256 `BF2EBC3DBC01CAE3278A6F203EF722CFAD0FA2E4B2B7D440D49E7BFFA8A61E75` in both old audit anchor and current candidate.

P11 p228: checked the source-order correction in the latest R124-plus current candidate. Result: target fix survives. Current candidate contains `\varphi_3(x)=\frac{w\cdot u}{v}` and does not contain the stale reversed `\frac{u\cdot w}{v}` form. Full P11 span differs from the previous reference only by one trailing blank line, so disposition is "targeted fix survived / no new patch" rather than a broad P11 certification.

Packaged compact web-drop:
`Noether_R124plus_P04_P11_SurvivalResults_NoNewPatch_20260624.zip`.

### 2026-06-24 -- P09/P12 survival check against R124-plus current candidate

P09: compared the full `\section*{9. ...}` span in the latest current candidate against
`Noether_R124plus_P09_p123_128_OmegaDefinitionFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P09_p127_omega_definition_fix_20260624.tex`.
Result: byte-identical full P09 span. Current and reference SHA256 both `A49DD7667CED14181EA24073FAB84220B031F8C00858291EE9F6E9430F01E3E4`. The p127 omega-definition block has six `\Omega` occurrences and no `\mathfrak R` / frak-R macro residue.

P12: compared the full `\section*{12. ...}` span in the latest current candidate against
`Noether_R124plus_P12_p037_041_BestAvailablePageAudit_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_UNCHANGED_after_P12_p037_041_audit_20260624.tex`.
Result: byte-identical full P12 span. Current and reference SHA256 both `7381953BB0D159AA7B3D35314CBAC53C0EA0C9A940467706395C3E90FF23ADF2`. The p042--044 tail anchor from the no-patch package survives after stripping old `% source_current_line_####:` wrapper prefixes.

Packaged compact web-drop:
`Noether_R124plus_P09_P12_SurvivalResults_NoNewPatch_20260624.zip`.

### 2026-06-24 -- P19/P20 survival check against R124-plus current candidate

P19: extracted from centered title `Idealtheorie in Ringbereichen` through the P20 boundary because this paper does not use a standard `\section*{19...}` marker in the current cumulative. Compared against
`Noether_R124plus_P19_p061_064_SigmaExponentFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P19_p062_sigma_exponent_fix_20260624.tex`.
Result: byte-identical full P19 span. SHA256 `205B7E0CB377FE4C3D5505E3D6210919D4DA15A49A0300228110A2B72B966C50`. Confirmed survival of p59 semicolon ideal-pair fix and p62 sigma-exponent fix; stale comma-pair and nu-exponent forms absent.

P20: extracted section 20 through section 21 and compared against
`Noether_R124plus_P20_p032_033_FieldSymbol_DeltaFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P20_p033_field_delta_fix_20260624.tex`.
Result: byte-identical full P20 span. SHA256 `117A113271ABE70E1E3A8FEE5AA7F51F6B08F2E117F58BD38F79CF31782C40B5`.

Packaged compact web-drop:
`Noether_R124plus_P19_P20_SurvivalResults_NoNewPatch_20260624.zip`.

### 2026-06-24 -- P13/P18 latest-current anchor rerun disposition

Reran the existing P13--P18 survival anchors against the latest R124-plus current candidate
`Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

The raw machine rerun reported eight `REGRESSION_missing` rows. Manual inspection showed zero real regressions:

- P14/P15/P16 footnote-reset rows survive; the old expected signatures were natural-language placeholders, not literal TeX.
- P14 `\calA\calN^\rho` / `\calB\calN^\sigma` survives with normal inline math delimiters.
- P15 Schur citation survives with `\emph{Math. Ann.}` markup.
- P16 Omega-process anchor survives as `$\\Omega$-Prozeß`.
- P17 basis anchor survives as separated inline math `$\\xi_1^2$, $\\xi_2^2$`.
- The old P18 title check is stale. Current P18 in this lane is the one-page Hentzelt conference note; its title and resultant-congruence anchors survive.

No new TeX patch. Packaged compact web-drop:
`Noether_R124plus_P13_P18_LatestCandidateAnchorRerun_NoNewPatch_20260624.zip`.

Source-quality caveat carried forward: this is an anchor-survival reconciliation, not new page-by-page certification. Prior P13--P18 source ledgers include below-650ppi floors for parts of P14--P17, and P18's staged GDZ/JDMV witness is about 600ppi, just below the strict 650ppi rule but still the best staged witness for that one-page note.

### 2026-06-24 -- P01/P08 latest-current body-span survival

Compared the existing P01--P08 survival-integration reference candidate
`Noether_R124plus_P01_P08_SurvivalIntegrationAudit_20260624/01_tex_reference/cum_de_R124plus_localcodex_current_candidate_REFERENCE_20260624.tex`
against the latest R124-plus current candidate
`Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Extraction scope: visible P01 title through the `\clearpage` immediately before P09.

Result: byte-identical full P01--P08 body span. Span length 5951 lines, 398972 UTF-8 bytes, SHA256
`465FF39E2EB7760CC420B7E1E5FFBC2409CADB56AFE98691F841A8CC29667710`.

No new TeX patch. Packaged compact web-drop:
`Noether_R124plus_P01_P08_LatestCandidateSpanSurvival_NoNewPatch_20260624.zip`.

Source-quality caveat carried forward: this is span-survival/routing, not fresh page-by-page certification. P01/P02/P03/P05 remain inherited survival/context rows. P04 and P06--P08 have stronger targeted exact-locus evidence in prior 1000 dpi packages.

### 2026-06-24 -- P21/P30 latest-current middle-band disposition

Compared the existing P21--P30 middle-band integration reference candidate
`Noether_R124plus_P21_P30_MiddleBandIntegrationAudit_20260624/01_tex_reference/cum_de_R124plus_localcodex_current_candidate_REFERENCE_20260624.tex`
against the latest R124-plus current candidate
`Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Results:

- P21--P29 body span is byte-identical. Span length 1757 lines, SHA256 `C134B846E76C8CE91BA4EB63C400B8F37DD5913D66C8923B0B3588ED27E33497`.
- P30 differs intentionally. The latest current candidate supersedes the older middle-band reference with later P30 repairs, including the printed p41 congruence correction from `Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624`.
- No new TeX patch from this disposition package.

Packaged compact web-drop:
`Noether_R124plus_P21_P30_LatestCandidateMiddleBandDisposition_NoNewPatch_20260624.zip`.

Open-scope caveat carried forward: P21/P23 are source-upgrade-only; P24--P28 are still open; P22/P29/P30 retain full-page/source-quality caveats from the copied middle-band register. P30 latest repairs use best local IA JP2/native PNG around 400-ish ppi, below strict 650+ certification.

### 2026-06-24 -- P31/P43 latest-current upper-band survival

Compared the existing P31--P43 upper-band integration reference candidate
`Noether_R124plus_P31_P43_UpperBandIntegrationAudit_20260624/01_tex_reference/cum_de_R124plus_localcodex_current_candidate_REFERENCE_20260624.tex`
against the latest R124-plus current candidate
`Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Extraction scope: P31 section start through just before the collected-volume tail `\section*{Einleitung}`.

Result: byte-identical P31--P43 span. Span length 5438 lines, SHA256
`A4BA2C7DBFC443E0ABA06511C6D1F8AB72E990EDC6D66329284B0D607EC78F2E`.

No new TeX patch. Packaged compact web-drop:
`Noether_R124plus_P31_P43_LatestCandidateUpperBandSurvival_NoNewPatch_20260624.zip`.

Open-scope caveat carried forward: this is survival/routing, not full page-by-page symbol certification. P31/P32 remain locator-only; P37 status-sync-only; P42 weak-source; P43 local source about 360 ppi; all other upper-band caveats in the copied open-scope and source-quality registers remain binding.

### 2026-06-24 -- P33 R124 targeted 1200 dpi source audit

Checked Paper 33 against the staged 1200 dpi P33 source witnesses from
`Noether_P33_Bologna_MatrixNotationRepair_R123plusP08P30_20260624/source_witnesses/inspection_crops/`.

Source witnesses opened/used:

- `P33_p071_title_opening_and_footnotes_1200dpi.png`
- `P33_p072_operator_group_and_matrix_1200dpi.png`
- `P33_p073_diagonal_matrix_and_closing_1200dpi.png`

Result:

- R124 already has the source-confirmed `$\mathfrak{G}$` group symbol in the opening paragraph of P33.
- R124 and the latest local R124-plus candidate have text-identical P33 spans.
- The p072 lower/block triangular matrix and p073 diagonal `C_i` matrix are represented in editable `pmatrix` form; no TeX patch applied.

Packaged compact web-drop:
`Noether_R124_P33_1200dpi_TargetedSourceAudit_NoNewPatch_20260624.zip`.

Scope caveat: this is a targeted high-resolution source audit over the available 1200 dpi crops, not a full raw-page P33 certification. The staged P33 witnesses are crops, not a complete high-resolution page-image set.

### 2026-06-24 -- Failed Web/Pro thinking salvage: P19, P33, P37, P42

Parsed the failed Web/Pro transcript at
`C:\Users\Floris\.codex\attachments\4db82ca9-bcbd-4064-acff-4c9925dee0f7\pasted-text.txt`
and extracted only the actionable material into a compact web-drop:
`Noether_R124_FailedWebThinking_Salvage_P19_P33_P37_P42_20260624.zip`.

Useful salvage:

- P19 p. 62 has a confirmed patch package:
  `Noether_R124plus_P19_p061_064_SigmaExponentFix_WebDrop_20260624.zip`.
  The source-visible formula is
  `$g=p_1^{\sigma_1}\cdots p_\nu^{\sigma_\nu}$`, not the erroneous
  `$g=p_1^{\nu_1}\cdots p_\nu^{\nu_\nu}$`.
- The P19 package contains the newest local candidate TeX identified by the
  failed transcript:
  `cum_de_R124plus_localcodex_current_candidate_P19_p062_sigma_exponent_fix_20260624.tex`.
- P33 remains no-new-patch from the targeted 1200 dpi audit; R124 already has
  the checked fraktur-G and matrix loci.
- P37 RA08 restoration is already absorbed; do not replay it unless a later
  cumulative regresses.
- P42 RA82 footnote reset is absorbed, but P42 is still not source-certified.
  The RA10/P42 material and transcript snippets are locator/candidate material
  only, below the 650 ppi source-check floor.

No free-floating failed-transcript text was promoted as an edit. The package
includes ledgers, the extracted current P19 candidate TeX, P19 audit files, key
transcript excerpts, and the relevant small evidence zips.

### 2026-06-25 -- R124plus P11 p221 front-matter comma fix

Continued the non-overlap P20-to-P10 Noether audit lane with Paper 11,
`Gleichungen mit vorgeschriebener Gruppe`.

Base TeX:
`Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Source checked:

- `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\source_master_checks\P11_GDZ_original_pp221_229_IIIF_fullres_jpg\P11_GDZ_pp221_canvas000225_fullres.jpg`
- `P11_GDZ_pp226_canvas000230_fullres.jpg`
- `P11_GDZ_pp228_canvas000232_fullres.jpg`

Confirmed fix:

- P11 printed p. 221 source title page has a separate `Von` line and author line
  `Emmy Noether in Göttingen,` with a comma. The current cumulative normalized this as
  `Von Emmy Noether in Göttingen.`. Patched the local candidate to the source-style
  two-line form while retaining the project bibliographic line.

Checked no-patch anchors:

- P11 printed p. 226 formula (11) has plain `G_k/H_k`, not primed forms; current TeX matches.
- P11 printed p. 226 formula (12), singular displays, and theorem paragraph match at checked anchors.
- P11 printed p. 228 Vierergruppe basis display keeps source order
  `\varphi_3(x)=w\cdot u/v`; current TeX already matches.

Package produced:
`Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625.zip`.

Compile status: patched cumulative compiled successfully with LuaLaTeX, 467 pages.

Source-quality caveat: the GDZ/IIIF witnesses are the best staged local P11 source images but are about 400 ppi. This is a source-certain front-matter correction and targeted anchor audit, not full strict 650+ ppi P11 certification.
## 2026-06-25 - Failed Web Thinking Salvage: R124plus P42 Apparatus Audit

Scope:

- Parsed the failed Web thinking transcript at `C:\Users\Floris\.codex\attachments\4db82ca9-bcbd-4064-acff-4c9925dee0f7\pasted-text.txt`.
- Treated the transcript as untrusted status, not as a patch.
- Extracted the useful signal into a small web-drop package:
  `Noether_R124plus_FailedWebThinking_Salvage_P42_ApparatusAudit_20260625.zip`.

Findings:

- The failed run did not produce a safe TeX patch.
- Its broad claim that current P42 was badly compressed was overcalled against the current local base: the post-P11 current P42 segment and the local `FINAL_AUDITED` German P42 slice differ only by BOM/comment/blank-line level material.
- It did surface a concrete audit target: the local P42 source OCR exposes source notes 1--12, while the current/final P42 TeX has only three explicit `\footnote` tokens. This needs visual apparatus/footnote audit against the source witness before any patch.
- RA82 remains a boundary/footnote-counter repair only and must not be treated as dense P42 certification.

Package contents:

- Current-vs-final P42 TeX segment comparison.
- Source PDF/text witness for P42.
- P42 source-footnote/apparatus candidate ledger.
- Failed-Web finding disposition ledger.
- Recovered R124 source queue rows from the transcript.
- Full failed transcript copy for provenance.

Source-quality caveat:

- The available P42 source PDF embeds 2048x3322 page images at 360ppi. It is the best staged local witness seen in this salvage pass, but it is not strict 650+ppi certification. Any accepted mathematical or apparatus fix must be visually confirmed; replace with a better Actualites/Hermann witness if found.

## 2026-06-25 - R124plus P10 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the later P11 front-matter patch disturbed the already source-adjudicated Paper 10 fixes.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Reference P10 tail-fix candidate:
  `Noether_R124plus_P10_p543_545_DisplayDotFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P10_p544_display_dot_fix_20260624.tex`.

Result:

- No new German TeX patch.
- The entire P10 span in the current post-P11 cumulative is byte-identical to the patched P10 p544 display-dot candidate.
- This proves the later P11 edit did not regress P10.

Survived anchors:

- p538 `\Jdom` fraktur-J Integritätsbereich repair survives; old `\Sdomain` drift absent in P10.
- p540 `k_\sigma` terminal-index repair survives; bad `k_\nu` pattern absent in P10.
- p541 `F(t;\vartheta_i)\cdot G(t;\vartheta_i)` repair survives; bad plain-`\vartheta` factorization absent.
- p544 rank-two display keeps source explicit `i\cdot(\mu_1x+\mu_2y)`.
- p545 no-fix trap survives: final example uses real variable `x`, not `r`.

Package:

- `Noether_R124plus_P10_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh high-resolution source certification. The P10 source witnesses remain the best staged GDZ/IIIF sources from the prior P10 packages and are below the strict 650+ppi floor. The accepted fixes were source-certain in their prior packages; this drop only proves they are still present in the latest cumulative.

## 2026-06-25 - R124plus P09 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the later P11 front-matter patch disturbed the already source-adjudicated Paper 09 p127 Omega repair.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Reference P09 Omega candidate:
  `Noether_R124plus_P09_p123_128_OmegaDefinitionFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P09_p127_omega_definition_fix_20260624.tex`.

Result:

- No new German TeX patch.
- The entire P09 span in the current post-P11 cumulative is byte-identical to the patched P09 p127 Omega candidate.
- This proves the later P11 edit did not regress P09.

Survived anchors:

- The p127 definition block has six source-intended `\Omega` occurrences.
- The p127 definition block has zero `\mathfrak R` occurrences.
- Broad Paper 09 `\mathfrak R` counts are not defects; `\mathfrak R` is legitimate elsewhere in the paper. The defect was only the p127 two-definition block.

Package:

- `Noether_R124plus_P09_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh high-resolution source certification. The P09 source witnesses remain the best staged GDZ/IIIF sources from the prior P09 package and are about native 400ppi, below the strict 650+ppi floor. The accepted Omega fix was source-certain in the prior package because the six symbols are repeated, large, and unambiguous; this drop only proves the fix is still present in the latest cumulative.

## 2026-06-25 - R124plus P12 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the later P11 front-matter patch disturbed the already source-adjudicated Paper 12 fixes and no-fix traps.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Reference P12 full-span candidate:
  `Noether_R124plus_P12_p037_041_BestAvailablePageAudit_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_UNCHANGED_after_P12_p037_041_audit_20260624.tex`.
- Cross-reference P12 span:
  `Noether_R124plus_P09_P12_SurvivalResults_NoNewPatch_20260624/tex_anchors/current_candidate_P12_span.tex`.

Result:

- No new German TeX patch.
- The complete P12 span in the current post-P11 cumulative is byte-identical to both prior P12 references.
- This proves the later P11 edit did not regress P12.

Survived anchors:

- Source author line `Von Emmy Noether in Göttingen.` survives.
- Opening definition keeps source `f(x;dx)` exactly once.
- Higher-differential anchors include two `d\delta x` occurrences.
- Barred-delta parenthetical loci include three `\bdelta x` occurrences.
- Source-numbered displays `(11)`, `(12)`, and `(14)` survive as `\srcnumdisplay` displays; old raw `\tag{...}` drift is absent.
- Formula (11) retains the source-confirmed comma, not semicolon; no semicolon appears in the formula (11) block.

Package:

- `Noether_R124plus_P12_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh high-resolution source certification. The complete P12 page witnesses staged locally are best-available GDZ/IIIF images at about native 400ppi, below the strict 650+ floor. Earlier exact repair loci have targeted labelled 1000ppi crops, and the relevant ledgers are copied into the package.

## 2026-06-25 - R124plus P13-P18 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the later P11 front-matter patch disturbed the existing P13--P18 anchor rerun/disposition package.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Prior P13--P18 anchor-rerun base:
  `Noether_R124plus_P30_p041_044_CongruenceFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P30_p041_044_congruence_fix_20260624.tex`.

Result:

- No new German TeX patch.
- The complete current block from `\section*{13. Invariante Variationsprobleme}` through the boundary before Paper 19 is byte-identical to the prior anchor-rerun base.
- This proves the prior P13--P18 manual dispositions still carry forward after the P11 edit.

Survived anchors:

- P13 dedication and cited-footnote anchors survive.
- P14 `mod. (z-c)` and factorization anchors survive.
- P15 Schur citation/order no-fix traps survive.
- P16 `\Omega`-Prozeß and index-pattern anchors survive.
- P17 old non-source `Fortsetzung zu 17` scaffold remains absent.
- P18 is confirmed as the Hentzelt conference note in this current lane; the stale old-title check must not be revived. Its resultant congruence anchor survives in source-style current form `\equiv 0(\mathfrak M)`.

Package:

- `Noether_R124plus_P13_P18_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh source-page certification. It contains no image payload. Prior source evidence and caveats remain in the copied P13--P18 anchor-rerun ledgers.

## 2026-06-25 - R124plus P19-P20 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the latest post-P11 cumulative still carries the P19 and P20 source-critical repairs that were previously packaged.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- P19 reference:
  `Noether_R124plus_P19_p061_064_SigmaExponentFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P19_p062_sigma_exponent_fix_20260624.tex`.
- P20 reference:
  `Noether_R124plus_P20_p032_033_FieldSymbol_DeltaFix_WebDrop_20260624/tex/cum_de_R124plus_localcodex_current_candidate_P20_p033_field_delta_fix_20260624.tex`.

Result:

- No new German TeX patch.
- Current P19 span is byte-identical to the P19 sigma-exponent reference candidate.
- Current P20 span is byte-identical to the P20 field/Delta reference candidate.

Survived anchors:

- P19 p. 62 composite-number example keeps the source-confirmed `g=p_1^{\sigma_1}\cdots p_\nu^{\sigma_\nu}`.
- The stale bad P19 `g=p_1^{\nu_1}\cdots p_\nu^{\nu_\nu}` reading is absent.
- The P19 ideal-pair semicolon anchor survives as `\ideal P_0=\ideal D=(g); \ideal P=(g\cdot p)` across inline math chunks.
- P20 Delta/field-symbol repairs survive by whole-span identity and anchor count.

Package:

- `Noether_R124plus_P19_P20_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh source-page certification. Prior source-quality caveats remain binding: P19 sigma source is IA/JP2 best-available around native 400ppi; P20 pp. 32--33 source is best-available native 400ppi.

## 2026-06-25 - R124plus P01-P08 Post-P11 Body Survival / Boundary-Only Difference

Scope:

- Checked whether the latest post-P11 cumulative disturbed the P01--P08 lower block.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Reference body span:
  `Noether_R124plus_P01_P08_LatestCandidateSpanSurvival_NoNewPatch_20260624/tex_anchors/P01_P08_latest_candidate_body_span.tex`.

Result:

- No new German TeX patch.
- The P01--P08 body is byte-identical to the prior P01--P08 span after stripping the current trailing P09 boundary reset and normalizing only final blank lines.
- The raw current extraction through the P09 boundary differs only by tail blank-line convention plus the expected boundary lines:
  `\clearpage` and `\setcounter{footnote}{0}`.

Survived anchors:

- P01, P02, P03, P05, P07, and P08 title/source anchors survive.
- P08 substitution anchor `f[x,y,(zy)x+(xz)y]=(xy)^p f(x,y,z).` survives.
- P08 Omega block anchor survives.
- No `TODO`, `MISSING`, or `PLACEHOLDER` markers occur in the tail-normalized P01--P08 body.

Package:

- `Noether_R124plus_P01_P08_PostP11BodySurvival_BoundaryOnlyDiff_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh page-by-page source certification. P01/P02/P03/P05 remain inherited/context rows. P04 and P06--P08 retain stronger targeted exact-locus evidence from prior packages; copied source-quality ledgers remain binding.

## 2026-06-25 - R124plus P21-P30 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the latest post-P11 cumulative disturbed the P21--P30 middle band.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Reference span:
  `Noether_R124plus_P21_P30_LatestCandidateMiddleBandDisposition_NoNewPatch_20260624/tex_anchors/P21_P30_latest_candidate_span.tex`.

Result:

- No new German TeX patch.
- The current post-P11 P21--P30 span is byte-identical to the prior latest-candidate P21--P30 span.
- The P30 latest congruence repair survives at the checked anchor.

Open-scope register carried forward:

- P21 and P23 are source-upgrade/indexed-only lanes with native600 witnesses staged, not strict 650+ certification.
- P24--P28 remain open for real source audit.
- P22, P29, and P30 exact repairs survive, but broad page-level certification caveats remain.
- P30 latest repairs use best local IA/JP2/native PNG around 400-ish ppi, below strict 650+.

Package:

- `Noether_R124plus_P21_P30_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh source-page certification. It contains no image payload; copied ledgers retain the source-quality caveats and open-work rows.

## 2026-06-25 - R124plus P31-P43 Post-P11 Survival / No-New-Patch Check

Scope:

- Checked whether the latest post-P11 cumulative disturbed the P31--P43 upper band.
- Current post-P11 base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Reference span:
  `Noether_R124plus_P31_P43_LatestCandidateUpperBandSurvival_NoNewPatch_20260624/tex_anchors/P31_P43_latest_candidate_span.tex`.

Result:

- No new German TeX patch.
- The current post-P11 P31--P43 span is byte-identical to the prior latest-candidate P31--P43 upper-band span.

Open-scope register carried forward:

- P31/P32 remain locator-only.
- P37 is status-sync-only.
- P42 remains weak-source and needs real apparatus/source audit when a better witness is found.
- P43 local source is about 360ppi and still needs better source or exact-symbol micro-audit.
- All other upper-band caveats in the copied open-scope/source-quality registers remain binding.

Package:

- `Noether_R124plus_P31_P43_PostP11Survival_NoNewPatch_20260625.zip`.

Source-quality caveat:

- This package is a regression/survival proof, not a fresh source-page certification. It contains no image payload.

## 2026-06-25 - R124plus P26-P28 / P27 q-p Glyph Fix Candidate

Scope:

- Continued the open P24--P28 band after the post-P11 survival checks.
- Selected P26--P28 because clean one-page GDZ source witnesses are staged in:
  `Noether_P26_P28_GDZ600_GrossGapAnchorAudit_R123plusP08P30_20260624`.
- Current base:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.

Result:

- One narrow German TeX candidate patch for P27.
- P26 and P28 received spot checks against selected source pages and no patch.
- The prior P26--P28 OCR-anchor audit remains gross-gap evidence only.

Confirmed P27 source-fidelity issue:

- Current TeX over-frakturized the Hilbert-number ideal letters in P27.
- Source page `P27_GDZ_printed101_canvas000358_full.jpg` visibly prints plain italic `q` and `p` in the relevant formula/prose loci:
  `Primärideale q`, `Primideals p`, `q, q/p, q/p^2, ...`, and `q/p^i` to `q/p^{i-1}`.
- Candidate patch replaces the four `\mathfrak q` / `\mathfrak p` loci in P27 with plain `q` / `p`.

Build check:

- Patched cumulative compiled successfully twice with XeLaTeX.
- `pdflatex` is the wrong engine for this cumulative because it uses `fontspec`; that failed engine attempt is not part of the package evidence.
- Rendered text check located P27 on patched cumulative PDF page 271 and confirmed the plain `q/p` output.

Source-quality caveat:

- The selected GDZ source pages report 600ppi, below the strict 650+ source-checking floor.
- This package claims a narrow, visually clear glyph-style correction and one-page gross-gap spot-check evidence, not broad strict page-level certification.

Package:

- `Noether_R124plus_P26_P28_P27_qpGlyphFix_WebDrop_20260625.zip`.

## 2026-06-25 - R124plus P25 p119 Galois-Field Overbar Fix

Scope:

- Continued the open P24--P28 band from the latest post-P11 cumulative:
  `Noether_R124plus_P11_p221_FrontMatterCommaFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P11_p221_frontmatter_comma_fix_20260625.tex`.
- Audited Paper 25 against the staged GDZ/JDMV33 source package:
  `Noether_P25_RA70_SourceHeader_FootnotePlacement_WebDrop_20260614/source/Noether_P25_GDZ_JDMV33_1924_LOG_0016_pp116_120.pdf`.
- Used the local raw full-resolution page images under:
  `Noether Multilingual/source_master_checks/P25_GDZ_JDMV33_1924_Eliminationstheorie_Idealtheorie/raw_fullres_jpg_structure_p116_120`.

Confirmed source-fidelity issue:

- Paper 25 printed p119, section III.
- Current TeX read `zum Galoisschen Körper $\mathfrak R$ inbezug auf`.
- The source line visibly prints a bar over the fraktur R.
- Candidate patch changes this to `zum Galoisschen Körper $\overline{\mathfrak R}$ inbezug auf`.

No-fix traps recorded:

- P25 p116 title/occasion/author/footnote placement is correct in the current RA70-style header; the Slavic final slice is outdated/wrong for that locus.
- P25 p118 congruence display should remain source-style `\equiv 0\,(\mathfrak a)`, not modernized to `\pmod{\mathfrak a}`.
- P25 title keeps the final period, which is present in the source.

Build check:

- Patched cumulative compiled successfully twice with XeLaTeX.
- Rendered QA page around cumulative PDF p268 shows the barred fraktur R in the corrected line.

Source-quality caveat:

- The staged GDZ/JDMV33 source images report 600ppi, below the user's strict 650+ full-page checking floor.
- This package claims only a narrow, visually clear glyph correction at a large printed symbol, not broad strict page-level certification for Paper 25.

Failed Web salvage note:

- The latest failed Web thinking transcript yielded no safe direct TeX patch.
- Its useful P42 signal remains the already separated P42 apparatus/footnote locator package:
  `Noether_R124plus_FailedWebThinking_Salvage_P42_ApparatusAudit_20260625.zip`.

Package:

- `Noether_R124plus_P25_p119_GaloisFieldOverbarFix_WebDrop_20260625.zip`.

## 2026-06-25 - R124plus P25/P27 Merged Fixes Rollup

Reason:

- The P25 overbar package and the P27 q/p glyph package were sibling cumulative candidates made from the same post-P11 base.
- Accepting either one alone would risk losing the other local fix.

Action:

- Used the P27 q/p glyph candidate as the merge base:
  `Noether_R124plus_P26_P28_P27_qpGlyphFix_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P27_qp_glyph_fix_20260625.tex`.
- Applied the P25 p119 barred-fraktur-R correction onto that candidate.
- Produced merged cumulative:
  `Noether_R124plus_P25_P27_MergedFixes_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P25_P27_merged_fixes_20260625.tex`.

Merged fixes now present:

- P25 p119: `zum Galoisschen Körper $\overline{\mathfrak R}$ inbezug auf`.
- P27 p101: plain italic `q/p` style in the four Hilbert-number loci, not over-frakturized `\mathfrak q/\mathfrak p`.

Build check:

- Merged cumulative compiled successfully twice with XeLaTeX.
- QA renders included for cumulative PDF pages 268--271.

Source-quality caveat:

- Both P25 and P27 source witnesses are 600ppi best-staged local sources, below the strict 650+ full-page floor.
- This rollup is a safe merge of the two narrow local fixes, not broad page-level certification.

Package:

- `Noether_R124plus_P25_P27_MergedFixes_WebDrop_20260625.zip`.

Continuation baseline:

- Use the merged P25/P27 candidate, not either sibling package alone, for subsequent local/web integration.

## 2026-06-25 - R124plus P26/P28 One-Page Audit / No New Patch

Scope:

- Continued the P24--P28 open band using the merged P25/P27 baseline:
  `Noether_R124plus_P25_P27_MergedFixes_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P25_P27_merged_fixes_20260625.tex`.
- Audited the remaining one-page short abstracts P26 and P28 against the selected GDZ source pages:
  `Noether_P26_P27_P28_CleanShortAbstractSources_WebDrop_20260614/sources/P26/P26_GDZ_printed102_canvas000367_full.jpg`;
  `Noether_P26_P27_P28_CleanShortAbstractSources_WebDrop_20260614/sources/P28/P28_GDZ_printed144_canvas000401_full.jpg`.

Result:

- No German TeX patch for P26.
- No German TeX patch for P28.
- Current P26 and P28 segments match the Noether items on the selected source pages.

No-fix/context traps:

- P26 source p102 contains neighboring Prüfer and Behnke/meeting material; this is not part of P26 Noether.
- P28 source p144 contains neighboring topology/Hasse/Schmidt material; this is not part of P28 Noether.
- Do not expand P26/P28 to include the other talks on the same printed pages.

Source-quality caveat:

- P26 and P28 selected GDZ pages report 600ppi, below the strict 650+ full-page floor.
- This is a best-available one-page audit/no-new-patch package, not strict 650+ certification.

Package:

- `Noether_R124plus_P26_P28_OnePageAudit_NoNewPatch_WebDrop_20260625.zip`.

## 2026-06-25 - P24 Source-Quality Check Before Long-Paper Audit

Scope:

- Before starting a long source-critical P24 pass, checked whether the newer local Math. Ann. 90 IA/OS downloads improve on the staged GDZ P24 source.

Sources checked:

- GDZ staged P24 raw images:
  `Noether Multilingual/source_master_checks/P24_GDZ_MathAnn90_1923_Eliminationstheorie/raw_fullres_jpg_p229_261`.
- Newer IA dump:
  `C:\Users\Floris\Documents\Papors\OS\noet du,mp ia\sim_mathematische-annalen_1923_90_jp2.zip`;
  `C:\Users\Floris\Documents\Papors\OS\noet du,mp ia\sim_mathematische-annalen_1923_90.pdf`.
- GDZ/OS PDF:
  `C:\Users\Floris\Documents\Papors\OS\PPN235181684_0090.pdf`.

Result:

- GDZ P24 raw images report 400ppi.
- IA Math. Ann. 90 PDF and JP2 set are also 400ppi.
- GDZ/OS `PPN235181684_0090.pdf` is also 400ppi.
- No local P24 source witness above 400ppi is currently staged.

Decision:

- Do not label P24 strict 650+ certified from current sources.
- P24 can proceed only as a best-available 400ppi audit unless a better Math. Ann. 90 witness is acquired.

Artifact:

- `Noether_P24_SourceQualityStatus_20260625.md`.
## 2026-06-25 - R124plus P24 p233 best-available source fix (`x_1,\ldots,x_{i-1}`)

Continued the Noether German source-critical audit from the merged P25/P27 cumulative baseline:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P25_P27_MergedFixes_WebDrop_20260625\tex\cum_de_R124plus_localcodex_current_candidate_P25_P27_merged_fixes_20260625.tex`

Targeted Paper 24, printed p. 233, section `3. Bezeichnung`.

Confirmed source mismatch:

- Current TeX had: `die von $x_i,\ldots,x_{i-1}$ frei sind`.
- Best local source page visibly reads: `die von $x_1,\ldots,x_{i-1}$ frei sind`.
- Applied copied-cumulative fix: `die von $x_1,\ldots,x_{i-1}$ frei sind`.

Source witness:

`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\source_master_checks\P24_GDZ_MathAnn90_1923_Eliminationstheorie\raw_fullres_jpg_p229_261\Noether_P24_GDZ_MathAnn90_p233_canvas000237_fullres.jpg`

Source-quality caveat:

- The staged GDZ page image is 1968 x 3096 at 400 ppi.
- Local IA JP2/PDF and GDZ PDF checks remain 400 ppi.
- Springer DOI/PDF endpoint `https://link.springer.com/content/pdf/10.1007/BF01455443.pdf` was probed, but returned a small HTML response rather than a usable PDF in this environment.
- Therefore this is a best-available, below-650-floor fix at a visually clear locus, not strict full P24 certification.

Spot-checked surrounding p233 anchors:

- Section 4 opening and formula (2) around Grundideale: no new patch.
- Section 5 opening with Linearform in `x_1,\ldots,x_{i-1}`: no new patch.

Build:

- XeLaTeX compiled the patched cumulative successfully in two clean passes.
- Pass 2 had no fatal errors, emergency stops, or undefined-reference warnings; remaining messages are inherited font/inputenc warnings.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P24_p233_xoneFix_BestAvailable400_WebDrop_20260625.zip`

## 2026-06-25 - R125 failed web-thinking salvage for P42 / RA10

User supplied a failed web-thinking transcript:

`C:\Users\Floris\.codex\attachments\4db82ca9-bcbd-4064-acff-4c9925dee0f7\pasted-text.txt`

Salvage result:

- The failed web run did not produce a completed R125 repair.
- The useful portion was a Paper 42 / RA10 trail.
- It rediscovered `Noether_RA10_scan_P40_P43_apparatus_20260605.zip` as the relevant source/apparatus package.
- It confirmed the RA10/RA84 guardrail: RA10 apparatus restoration is not full inline body resynchronization for Papers 40-43.
- It flagged P42 as needing source-page-level work, especially body compression, missing/short apparatus placement, footnote sequence 1-12, and source notation distinctions for orders/ideals.
- It made visual claims about P42 page-level problems, but did not finish a rebuild; all such claims are treated as leads only, not accepted fixes.

No TeX patch was applied from this failed run.

Created web-drop package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R125_WebFailedThinking2_P42_Salvage_WebDrop_20260625.zip`

Package contents include:

- latest local Codex cumulative candidate before this salvage;
- RA10 prior package;
- RA84 placement-audit package;
- P42 RA10 source cutout and OCR locator;
- line-numbered useful transcript excerpts;
- `web_failed_salvage_findings.csv`;
- `p42_next_action_ledger_from_failed_web.csv`.

Decision:

- Do not mark P42 closed.
- Use the package as a source-navigation and audit handoff only.
- Any future P42 changes must be verified directly against source pages and recorded as reversible TeX diffs plus CSV/logbook entries.

## 2026-06-25 - R124plus P24 p234 formula (3) highest elementary divisor fix

Continued from the current local cumulative candidate:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P24_p233_xoneFix_BestAvailable400_WebDrop_20260625\tex\cum_de_R124plus_localcodex_current_candidate_P24_p233_xone_fix_20260625.tex`

Target:

- Paper 24, printed p. 234.
- Formula (3), first entry of the `\mathfrak M_{i-1}` row in section 5.

Confirmed source mismatch:

- Current TeX had: `E_0^{(i)}\zeta_0`.
- Best local source visibly reads: `E^{(i)}\zeta_0`, followed by `E_1^{(i)}\zeta_1`.
- The following source prose also calls `E^{(i)}` the highest elementary divisor, confirming that the first term is deliberately unscripted.

Applied copied-cumulative fix:

- `E_0^{(i)}\zeta_0` -> `E^{(i)}\zeta_0`.

Source witness:

`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\source_master_checks\P24_GDZ_MathAnn90_1923_Eliminationstheorie\raw_fullres_jpg_p229_261\Noether_P24_GDZ_MathAnn90_p234_canvas000238_fullres.jpg`

Source-quality caveat:

- The staged GDZ p234 image is 2106 x 3190 at 400 ppi.
- This is below the preferred 650+ full-page source floor.
- Prior local checks showed the IA Math. Ann. 90 PDF/JP2 and the GDZ PDF are also 400 ppi.
- This is therefore a best-available, below-floor fix at a visually clear locus, not strict full-page P24 certification.

Build:

- XeLaTeX compiled the patched cumulative successfully in two passes.
- Pass 2 had no fatal errors, emergency stops, undefined-reference warnings, overfull boxes, or underfull boxes.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P24_p234_ElementarteilerEzeroFix_BestAvailable400_WebDrop_20260625.zip`

## 2026-06-25 - R124plus P13 p235--238 best-available no-patch audit

Continued the non-overlap P20-to-P10 Noether audit lane in Paper 13,
`Invariante Variationsprobleme`, using the latest local cumulative candidate after
the P24 p234 fix:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P24_p234_ElementarteilerEzeroFix_BestAvailable400_WebDrop_20260625\tex\cum_de_R124plus_localcodex_current_candidate_P24_p234_elementarteiler_E_fix_20260625.tex`

Scope:

- Paper 13, printed/source pp. 235--238.
- Current TeX line window roughly 8471--8585.

Source witnesses:

- `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\source_master_checks\P13_GDZ_original_pp235_257_IIIF_fullres_jpg\P13_GDZ_orig_p235_canvas241_fullres.jpg`
- `P13_GDZ_orig_p236_canvas242_fullres.jpg`
- `P13_GDZ_orig_p237_canvas243_fullres.jpg`
- `P13_GDZ_orig_p238_canvas244_fullres.jpg`

Source-quality caveat:

- These staged GDZ/IIIF pages are 2296 x 3688 at 400 ppi.
- This is below the strict native 650+ source preference.
- Therefore this package is best-available visual audit evidence, not strict
  native-650 certification. The included zoom PNGs are readability aids derived
  from the 400 ppi source and are labelled as such.

Dispositions:

- p235: title/dedication/author/presented-by line and footnotes 1--2 checked.
  No patch. Current reader scaffolding includes article number/publication
  metadata; source body title itself is unnumbered, but this was treated as
  project scaffolding rather than a body transcription defect.
- p236: section heading and group-definition prose checked. No patch.
- p237: invariant-function display and formulas (1)--(2) checked. No patch.
- p238: `Div A` display and formulas (3)--(6) checked. No patch.

No-fix trap:

- Formula (6) on p238 visibly prints `=\delta f -` before the line break and
  begins the next line with the negative derivative term. The current TeX
  preserves this source-visible structure; do not flatten or redesign it as a
  correction without a separate house-style decision.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P13_p235_238_BestAvailableNoPatch_WebDrop_20260625.zip`
## 2026-06-25 - R124plus P13 pp. 239-242 Formula (13) Semicolon Fix

Scope:

- Audited Paper 13 printed/source pp. 239--242 against staged GDZ/IIIF full-page witnesses.
- Continued from current local cumulative candidate:
  `Noether_R124plus_P24_p234_ElementarteilerEzeroFix_BestAvailable400_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P24_p234_elementarteiler_E_fix_20260625.tex`.

Confirmed patch:

- p242, formula (13): source prints a semicolon before the ellipsis after `Div B^{(1)}`.
- Patched `\Div B^{(1)},\ldots` to `\Div B^{(1)};\ldots`.

Checked anchors with no further patch:

- p239: theorem II, footnotes 1--4, mixed-group paragraph, variational-problem transition, Weierstrass relation, and relativity example.
- p240: relativity continuation, relative-invariance paragraph, Section 2 heading, transformation display, footnotes 1--3.
- p241: infinitesimal transformation prose and formulas (7)--(12).
- p242: finite-group specialization prose, `B` / `\bar\delta u` display, formula (13), infinite-group opening, footnotes 1--2, and arbitrary-function display start.

Source quality caveat:

- Local P13 pp. 239--242 witnesses are 2296 x 3688, 400 PPI.
- This is below the strict 650+ native floor, so this is best-available checking rather than strict final certification.
- The p242 punctuation patch is accepted because the semicolon is large, isolated, and plainly visible.
- No fake-upscaled crops were retained or shipped.

Failed web transcript extraction:

- The failed 106-minute web run yielded no source-certified TeX patch.
- Useful material was P42/RA10 orientation only and is already isolated in `Noether_R125_WebFailedThinking2_P42_Salvage_PLUS_CurrentP24p234_WebDrop_20260625.zip`.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P13_p239_242_Formula13PunctuationFix_BestAvailable400_WebDrop_20260625.zip`

## 2026-06-25 - R124plus P13 pp. 243-246 Dx / Example / Footnote Source Fixes

Scope:

- Audited Paper 13 printed/source pp. 243--246 against staged GDZ/IIIF full-page witnesses.
- Continued from current local cumulative candidate:
  `Noether_R124plus_P13_p239_242_Formula13PunctuationFix_BestAvailable400_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P13_p242_formula13_semicolon_fix_20260625.tex`.
- Read the failed 106-minute web-thinking transcript as coordination context only. It yielded no source-certified TeX patch; its useful content was that R124/P19/P42/RA10 status should remain visible.

Confirmed patches:

- p244: restored source punctuation and product notation in `Setzt man also: \(\D x=\frac{1}{f}\cdot(A-B)\)`.
- p245: corrected the worked-example denominator in `\D x` from `u'` to source-visible `u'^2`.
- p246: restored source-visible product dot in `u''\cdot u'`.
- p246: restored the semicolon between `u'=\mathrm{const.}` and `u'^2=\mathrm{const.}`.
- p246 footnote 2: corrected the first-integral statement from the erroneous `u''u'^{\lambda-1}=\mathrm{const.}` to source-visible `u'^\lambda=\mathrm{const.}`; also restored the product dot in the following derivative identity.

Checked anchors with no further patch:

- p243: formulas (14)--(16), partial-integration identity, and surrounding prose.
- p244: formula (17) checked at visible loci after the `Setzt man also` repair.
- p245: lower \(f^*\) display checked at visible locus.

Source quality caveat:

- Local P13 pp. 243--246 witnesses are 2296 x 3688, 400 PPI.
- This is below the strict 650+ native floor, so this is best-available checking rather than strict final certification.
- The accepted fixes are large/isolated enough to be source-certain from the staged 400 PPI witnesses.
- No fake-upscaled crops were retained or shipped.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P13_p243_246_DxDotExampleFootnoteFix_BestAvailable400_WebDrop_20260625.zip`

## 2026-06-25 - Failed Web Thinking 3 Salvage: P42 / RA10

Scope:

- Read the newly attached failed web-thinking transcript ending in `Thinking failed`.
- Extracted only the useful non-certified material for Paper 42.
- Built a compact web-drop package so the web session can use the recovered RA10 source trail without treating the crashed reconstruction as a patch.

Useful salvage:

- The failed transcript reconfirmed that R124 still treats P42 as an open source-audit target.
- It located `Noether_RA10_scan_P40_P43_apparatus_20260605.zip`.
- Extracted RA10 P42 source scan, RA10 German P41/P42 TeX candidate, and RA10 German supplement/apparatus TeX.
- Preserved line-numbered transcript excerpts around RA10 scope, P42 segment printout, OCR/source-render notes, notation/crop notes, and final precrash formula notes.

Non-promoted / caveats:

- No cumulative German TeX patch was made from the crashed run.
- The transcript's P42 reconstruction was not finished, compiled, or checked.
- RA10 is useful as a candidate/locator layer but is not itself proof of complete inline body source fidelity.
- `pdfimages -list` on the extracted P42 scan reports main embedded page images at 2048 x 3322, 360 PPI; this is best-available lower-resolution witness material, not strict 650+ certification.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_WebFailedThinking3_P42_RA10_Salvage_WebDrop_20260625.zip`

## 2026-06-25 - R124plus P13 pp. 247-250 Commons DjVu Source Fixes

Scope:

- Continued Paper 13, `Invariante Variationsprobleme`, printed/source pp. 247--250.
- Used a better Wikimedia Commons DjVu-derived page-image witness instead of the earlier staged 400 PPI GDZ/IIIF pages.
- Local DjVu decoding was unavailable, so pages were fetched through Commons `thumb.php` at width 3984.
- Continued from current local candidate:
  `Noether_R124plus_P13_p243_246_DxDotExampleFootnoteFix_BestAvailable400_WebDrop_20260625/tex/cum_de_R124plus_localcodex_current_candidate_P13_p244_p245_p246_sourcefixes_20260625.tex`.

Source quality:

- Full page witnesses for pp. 247--250 are 3984 x 5592 pixels.
- Image metadata reports 72/undefined units; do not claim native 650+ PPI certification.
- This is higher-detail best-available source checking and supersedes the previous 400 PPI witness for these four pages.
- No fake-upscaled crops were used or retained.

Confirmed patches:

- p247: restored source dash before `Die infinitesimalen Transformationen...`.
- p247: restored semicolons in the simultaneous system:
  `dx_i/dt = Delta x_i;` and `du_i/dt = Delta u_i;`.
- p248: restored product dot in `Div(f \cdot Delta x)=0`.
- p248: restored product dot in formula (18), `x_i=y_i+t\cdot g_i(y)`.
- p250: corrected the Klein dependency formula so the derivative is `partial g^{mu nu}/partial w^sigma` multiplied by `R_{mu tau}`, rather than differentiating the product.
- p250: restored source semicolon after the product-differentiation display ending `=0;`.
- p250: corrected both occurrences of the `partial R^*` denominator to source `g^{mu nu}_{sigma}`.
- p250: restored product dot after `1/R^*` in the `Delta w^sigma` formula.
- p250: restored source-visible `partial v / partial x` in the second `delta f(y,v,...)` display and recorded it as a source oddity/no-fix trap.

No-fix traps:

- p247 initial condition remains `u_i=v`, source-visible; do not silently change to `v_i`.
- p250 `partial v / partial x` in the `y,v` display may look wrong mathematically, but is source-visible in the Commons witness; do not normalize to `partial v / partial y` without a better witness.

Build:

- XeLaTeX two-pass compile succeeded.
- Output PDF length: 469 pages.
- Final log check found no fatal errors, rerun warnings, undefined references, or over/underfull hbox matches.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P13_p247_250_CommonsDjVu_SourceFixes_WebDrop_20260625.zip`
## 2026-06-25 -- Web-failed-thinking salvage 4 for P37/P42, no TeX promotion

Package: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_WebFailedThinking4_P37_P42_Salvage_WebDrop_20260625.zip`

Input: failed web-thinking transcript `C:\Users\Floris\.codex\attachments\4db82ca9-bcbd-4064-acff-4c9925dee0f7\pasted-text.txt`.

Salvaged useful material only. No cumulative TeX patch was made because the web run crashed before a finished, compiled, source-checked repair.

Safe findings:

- P37 remains an open source-audit lane in the R124 queue.
- P37 prior RA08 package was recovered/packaged, including `p37_scan.pdf` and `p37_de.tex` as a candidate layer.
- P42 remains an open source-audit lane in the R124 queue.
- P42 prior RA10 package was recovered/packaged, including the 11-page `p42_scan.pdf`, `N41_42_DE.tex`, and `ra10_supp_de.tex`.
- RA82/RA10 guardrails were preserved: article-boundary footnote resets and apparatus restoration are not dense source certification.
- The failed run's useful P42 leads are now recorded as leads only: possible compressed body, footnotes 1--12, source-sensitive order/ideal typography, `o`/`\mathfrak o` ambiguity, crossed-product notation, and formula checks around source pp. 4--6.

Do-not-promote rule:

- RA08/RA10 candidate TeX may be compared against the scans, but must not be merged into the current cumulative unless every affected passage is visually checked against the best available source.
- P42 source is best-local but below the preferred 650+ PPI floor; if a stronger Actualites/Hermann witness appears, supersede the RA10 cutout.

## 2026-06-25 -- R124plus P13 pp. 255-257 Commons DjVu source audit

Scope:

- Continued Paper 13, `Invariante Variationsprobleme`, printed/source pp. 255--257.
- Used Wikimedia Commons DjVu-derived page images fetched at width 3984 px.
- Continued from the locally patched R124+ cumulative after the pp. 251--254 package.

Source quality:

- Retained full page witnesses for pp. 255--257 are 3984 x 5592 pixels.
- Image metadata does not certify native PPI, so this is recorded as higher-detail best-available Commons witness material, not native PPI-certified raw source.
- The generated p258/page24 fetch was byte-identical to p257/page23 and was excluded as generated noise.
- Blank p257 middle/bottom crops were excluded; the p257 top crop contains all remaining page text and the final footnote.

Confirmed patch:

- p256: in the displayed Lie differential-equation expansion, removed the extra inserted second `\sum_i` before `\partial f/\partial u_i' u_i'` in the coefficient of `p'(x)`. The printed source has no second visible summation sign there.

Checked with no patch:

- p255: displacement group formulas, energy-relation paragraph, footnote, and start of the infinite-group example.
- p257: final Hilbert/Klein paragraph and footnote, including the `Jhrber. d. d. Math. Vereinig.` citation wording.

Build:

- XeLaTeX two-pass compile succeeded.
- Output PDF length: 469 pages.

Package:

`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P13_p255_257_CommonsDjVu_SourceFix_WebDrop_20260625.zip`
## 2026-06-25 - Failed web-thinking 106m49s salvage, P42 RA82 only

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_WebFailedThinking5_106m_P42_RA82_Salvage_WebDrop_20260625.zip`

SHA256:
`98F2B35A3A6C0C724CB41025B0694736E0D73236EF9EB16C754A745DC35A9D31`

Input transcript:
`C:\Users\Floris\.codex\attachments\4db82ca9-bcbd-4064-acff-4c9925dee0f7\pasted-text.txt`

Disposition: no TeX patch. The failed web run did not produce a source-certified repair. It was working from a stale R124/P19-era 467-page candidate, so its base/page-count assumptions are not current after later local work.

Useful salvage: the failed run rediscovered the P42/RA82 lane and confirmed the same constraints as the prior local survival package: P42 has an 11-page RA10/Actualites source cutout with embedded 2048 x 3322 images at 360 ppi; RA82 only inserted article-boundary footnote resets before Papers 39--42; P42 remains a survival/disposition lane needing a fresh source audit or a better Actualites/Hermann witness before dense source certification.

Action for future P42 work: do not import any claimed exact P42 reconstruction from the failed transcript. Use it only for source/provenance routing and notation hazard reminders.

## 2026-06-25 - R124plus P12 pp. 41-44 GDZ best-available audit, no TeX patch

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P12_p041_044_GDZ_NoPatch_WebDrop_20260625.zip`

SHA256:
`520CF21BC7B80B46CD09836FD90201A3AD79D224409E416CD0DAE32308FFABC3`

Scope: Paper 12, `Invarianten beliebiger Differentialausdruecke`, printed/source pp. 41--44.

Source: GDZ/Jahresbericht 1918 IIIF canvases `00000045`--`00000048`, mapped to printed pp. 41--44. Full-page images are 2296 x 3688 px and are therefore below the strict 650+/1000+ source-certification preference; this is a best-available pass only.

Disposition: no TeX patch. Checked anchors include formula (8), formulas (9)--(14), the derivative identity after (14), the Reduktionssatz proof, the flatness criterion involving `[\Omega_2],[\Omega_3],...`, the affine subgroup paragraph, the final quadratic / p-dimensional forms paragraph, and the Math. Annalen notice. No source-certain correction was found.

Build: XeLaTeX two-pass compile succeeded; current PDF length 469 pages.

## 2026-06-25 - R124plus P14 pp. 182-185 source fixes, p183/p185

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P14_p183_185_SourceFix_WebDrop_20260625.zip`

SHA256:
`766E233649F788F492FF72BC4EAA57A1B725D597258DBBEE7438943A8E1DB032`

Scope: Paper 14, `Die arithmetische Theorie der algebraischen Funktionen einer Veraenderlichen in ihrer Beziehung`, printed pp. 182--185.

Base TeX: current local cumulative after the P12 pp. 41--44 audit,
`Noether_R124plus_P12_p041_044_GDZ_Audit_WebDrop_20260625\tex\cum_de_R124plus_localcodex_current_candidate_P12_p041_044_gdz_audit_20260625.tex`.

Source: staged P14 GDZ/JDMV cutout and full-page 650 dpi inspection renders from `Noether_P14_Targeted_Source_Audit_Witnesses_20260613.zip`. Prior RA55 documentation records the embedded source as 360 ppi, so the included 1000-view crops are inspection enlargements, not new optical detail. They are used as best-staged visual authority for this pass.

Confirmed patches:

- p183: Hurwitz footnote corrected from expanded `\emph{Math. Ann.} Bd. 28.` to source `\emph{Ann.} Bd. 28.`.
- p185: Steinitz/Kronecker root symbol corrected from Greek `\xi` to source Latin `j` throughout the construction: `j`, `f(j)`, `\varphi(j)`, `K(j), K(j'), ..., K(j^{(n-1)})`.

Checked with no patch:

- p182: displayed title/provenance/opening footnotes and start of the Inhaltsverzeichnis; do not replace the printed title with the longer bibliographic title.
- p183: Inhaltsverzeichnis items 3--8 and the opening of section 1 except for the corrected Hurwitz footnote.
- p184: Hensel MZ 4 footnote, Brill--Noether consecutive singular-point footnote, D.--W. JfM 92 citation, and M. Noether Ann. 37 continuation.
- p185: section 2 heading, base-field definitions, D.--W./Hensel and Steinitz footnote anchors, except for the corrected `j` root-symbol passage.

Build: XeLaTeX two-pass compile succeeded; current PDF length 469 pages; log scan found no fatal errors, emergency stops, undefined control sequences, LaTeX/package errors, rerun warnings, overfull boxes, or underfull boxes.

## 2026-06-25 - R124plus P14 pp. 190-194 GDZ600 source fix, p190 singular wording

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P14_p190_194_GDZ600_SourceFix_WebDrop_20260625.zip`

SHA256:
`C50B3F54503E5F42EB4E125B20391F5153E2F1528B26261B8F4A7DE2C7FA3A02`

Scope: Paper 14, printed/source pp. 190--194.

Base TeX: current local cumulative after the P14 p186--189 source-fix package,
`Noether_R124plus_P14_p186_189_SourceFix_WebDrop_20260625\tex\cum_de_R124plus_localcodex_current_candidate_P14_p186_189_sourcefix_20260625.tex`.

Source: official GDZ IIIF full-page JPGs from the RA90 route ledger, PPN `PPN37721857X_0028`, canvases `00000194`--`00000198`, printed pp. 190--194. RA90 records these pages as sample 600 ppi, so they remain below the preferred 650+ floor but are better than the older 360 ppi cutout and are the best institutional source currently staged.

Confirmed patch:

- p190: restored source-visible singular `bei den algebraischen Funktion zu Sätzen`; the previous TeX had silently regularized this to plural `Funktionen`.

Checked with no patch:

- p190: older RA55 `mod. (z-c)` line survives; `Primideal` first-degree sentence, `\Delta(\delta)`, `F'(\delta)`, and D.--W. footnote anchors checked.
- p191: continuation of the arithmetical point definition, `F'(\vartheta)=\frf\cdot\frD`, `(\partial F/\partial z)=\frf\cdot\fra`, `Doppelpunktsideal`, and section 4 opening checked.
- p192: Hensel--Landsberg paragraph, `\mathfrak q_i=\frp_i^{\ell_i}`, terminating series `v=c_0+\cdots-v_\sigma\pi^\sigma`, footnotes, and section 5 opening checked.
- p193: birational-transformation setup, `g_1/g_2` equations, reused Brill--Noether footnote marker, and `Normalkurve der \varphi` paragraph start checked.
- p194: continuation of the `Normalkurve der \varphi` paragraph, section 6 heading, singular-point definition, Aronhold/Hensel reference, and Brill--Noether 8th-section footnote checked.

No-fix trap recorded:

- p191 source prints `(\partial F/\partial z)=\frf\cdot\fra` inline after `entsprechend:` while current TeX displays the same formula. This was not promoted as a mathematical/source-text correction in this package; the content and adjacent prose are aligned.

Build: XeLaTeX two-pass compile succeeded; current PDF length 469 pages; log scan found no fatal errors, emergency stops, undefined control sequences, LaTeX/package errors, rerun warnings, overfull boxes, or underfull boxes.

## 2026-06-25 - R124plus P14 pp. 186-189 source fixes plus failed R125/P42 salvage leads

Package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R124plus_P14_p186_189_SourceFix_WebDrop_20260625.zip`

Tiny salvage-only package:
`C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_WebFailed_R125_P42_SalvageOnly_20260625.zip`

Scope: Paper 14, printed/source pp. 186--189, continuing the same P14 source pass from the p183--185 package.

Base TeX: current local cumulative after the P14 p183--185 source-fix package,
`Noether_R124plus_P14_p183_185_SourceFix_WebDrop_20260625\tex\cum_de_R124plus_localcodex_current_candidate_P14_p183_185_sourcefix_20260625.tex`.

Source: staged P14 GDZ/JDMV cutout and full-page inspection renders from `Noether_P14_Targeted_Source_Audit_Witnesses_20260613.zip`. The full-page images used here are labelled 650 dpi in that witness package; prior local source-quality notes still record the native embedded source around 360 ppi, so the 1000-view crops are inspection enlargements, not new optical detail.

Confirmed patches:

- p187: restored the coefficient family `a_n` and `a_n^{(i)}` in the linear-form reduction proof. The previous TeX collapsed this to `a_1` / unindexed `a^{(i)}`.
- p188: restored the Hilbert module-basis footnote notation from the source: `\xi_1,\ldots,\xi_\rho,\eta`, `\eta^n`, `a_i(\xi)\eta^{n-i}`, substitution `\eta^{n-i}=x_i`, and ideals in `\rho` variables. The previous TeX had normalized these to an `x_{r+1}`/`X_i` notation that is not the source.

Checked with no patch:

- p186: `K(z)`, gcd form `ma+nb`, module definition over `\frS`, and the Dedekind/Hilbert/Kronecker footnote anchors.
- p189: formulas `F'(\delta)=\frf\cdot\frD`, `\Delta(\delta)=R^2D`, `R^2=Norm \frf`, and the Dedekind/Zahlbericht footnotes. No change; this is also consistent with the earlier RA55 no-fix trap.

Failed web transcript salvage:

- The 106m49s failed web transcript was re-read. It contains useful P42/R125 routing leads but no source-certified TeX patch.
- Included under `web_failed_R125_salvage/`: a short markdown note, `salvage_leads.csv`, and selected transcript lines.
- Do not promote the failed transcript as a P42 reconstruction. Treat it only as a warning to inspect the RA10/P42 apparatus, footnotes, fraktur/roman order-and-ideal typography, and `\operatorname{Sp}(\mathfrak c)` note 9 against the source.

Build: XeLaTeX two-pass compile succeeded; current PDF length 469 pages; log scan found no fatal errors, emergency stops, undefined control sequences, LaTeX/package errors, rerun warnings, overfull boxes, or underfull boxes.

## 2026-06-25 - R125 Web Drop Rebase: Local Codex P13/P14 Fixes

Newest web drop ingested: `C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Noether Multilingual\Noether_R125_20260625.zip`, SHA256 `70C2CE5656209AC47A45C00FFBF8FC5FE03F257C41134F7262EAC8A747E280CB`.

R125 is now treated as the active web baseline and as authoritative for the Paper 42 rebuild. The older local P42 salvage package remains superseded and was not promoted.

Rebuilt the P11 post-P14 survival package after fixing a brittle CRLF-only anchor check. New package: `Noether_R124plus_P11_PostP14FullPageAuditSurvival_NoNewPatch_20260625.zip`, SHA256 `0677CCBFE0E3BFD7276141B81431D6FDE1C610D0CD691828623460DC4EADBE3A`; 17/17 checks pass; P11 span is identical to the prior source-audited p221 reference.

Compared R125 against local accepted anchors. R125 already carries P11, P19 sigma-exponent, and P42. R125 did not contain local post-split source-confirmed P13/P14 fixes.

Created R125-based web-return candidate: `Noether_R125_LocalCodex_Rebase_P13_P14_WebReturn_20260625.zip`, SHA256 `3D79FD2D4B98CD9DF84574BB71B0C78C272BC49A5F6CD9765576429A38DFA0F4`. It starts from `cum_de_R125.tex`, applies only the source-confirmed P13 p256 and P14 pp183-203 fixes, includes diff/ledgers/evidence, and compiled with XeLaTeX in two passes. Anchor checks: 0 failed.

Applied in R125 rebase:
- P13 p256: remove inserted second `\sum_i` in the Lie differential-equation coefficient.
- P14 p183: `Ann. Bd. 28.` not expanded `Math. Ann. Bd. 28.`
- P14 p185: Latin `j` root symbol in the Steinitz/Kronecker paragraph, not Greek `\xi`.
- P14 p187: restore `a_n`, `a_n^{(i)}` coefficient-family notation.
- P14 p188: restore Hilbert footnote variables `\xi_1,\ldots,\xi_\rho,\eta`, `\eta^n`, `a_i(\xi)\eta^{n-i}`, `\eta^{n-i}=x_i`.
- P14 p190: source singular `bei den algebraischen Funktion zu Sätzen`.
- P14 p196: `gewöhnliche vielfache Punkte`.
- P14 p202: Latin `l` in `Primzahl l`, `l`-te Wurzeln, and `l`-te Potenzreste.

Source caveat preserved: P13 p255-end uses high-detail Commons DjVu without native PPI certification; P14 pp190-203 use best-staged official GDZ about 600ppi; P14 pp183-189 fixes rely on visually unambiguous source loci, with inspection magnification not treated as new optical resolution.

## 2026-06-25 - R125 P10/P11/P12 Queue Disposition Package

Created `Noether_R125_LocalCodex_P10_P12_QueueDisposition_WebDrop_20260625.zip`, SHA256 `BD87EA79E41E10A6007D5D5A8F326F93E39870508FAED63D0FD72A8CEC449DF0`.

Purpose: compact web-drag package for the R125 source queue rows P10, P11, and P12. It introduces no new TeX patch. It uses the current `R125 + Local Codex P13/P14` candidate as anchor and records local source-audit evidence that should prevent blind redo of those rows.

Disposition:
- P10 pp536-545: local best-available GDZ/IIIF page audits exist; p538 `\Jdom` and p544 explicit `i\cdot` fixes survive in current candidate; remaining pages have no-patch dispositions. Source caveat: raw GDZ/IIIF best staged, below strict 650+ floor.
- P11 pp221-229: local best-available full-page audit and clean post-P14 survival package exist; p221 author comma and p228 `\varphi_3=w\cdot u/v` source order survive. Source caveat: about 400ppi; reopen if better witness appears.
- P12 pp37-44: local best-available GDZ page audits exist and record no source-certain patches at checked anchors; current candidate contains expected P12 display/final anchors. Source caveat: GDZ 2296x3688 below strict 650+ floor.

Package has 49 expanded files, 0 failed anchor checks, ZIP-open tested. Recommended web queue status for P10/P11/P12: close or downgrade to reopen only if genuinely higher-resolution witnesses appear.

## 2026-06-25 - R125 P04/P09 Queue Disposition Package

Created `Noether_R125_LocalCodex_P04_P09_QueueDisposition_WebDrop_20260625.zip`, SHA256 `735BD83814184BF7797E918994B5B7ADBC71D1944BF0C6E8C540CFEEDC57FDBF`.

Purpose: compact web-drag package for the R125 source queue rows P04 and P09. It introduces no new TeX patch. It uses the current `R125 + Local Codex P13/P14` candidate as anchor and records local source-audit evidence that should prevent blind redo of those rows.

Disposition:
- P04 pp140-145: local best-available page audit exists and recorded no source-certain corrections. Hard displays on pp143 and 145 had targeted 1000dpi crop support. Current candidate still contains the audited formula anchors, including tags (44) and (59).
- P09 pp103-128: local page-band audits exist. Source-confirmed p106 Weber-footnote repair (`Kleine Ausgabe § 96 und 97`, not `§§ 96 und 97`) and p127 Omega-definition repair survive in the current candidate. The remaining page bands record no source-certain patches.

Source caveat: P09 mostly remains best-available lower-resolution GDZ native witness work, around 400ppi, so reopen only if a genuinely better source witness appears. P04 has stronger exact-crop support for the hard loci. Package has 28 expanded files, 0 failed anchor checks, ZIP-open tested. Recommended web queue status for P04/P09: close or downgrade to reopen only if genuinely higher-resolution witnesses appear.

## 2026-06-25 - R125 P31-P43 Upper-Band Reconcile Package

Created `Noether_R125_LocalCodex_P31_P43_UpperBand_Reconcile_WebDrop_20260625.zip`, SHA256 `AC96092EAC0BDF0C8D034054E7E6C5E5FCF2BA15AC846FA8CBF6B51188F4DC78`.

Purpose: compact web-drag reconciliation package for the R125 high-band source queue rows P31-P43. It introduces no new TeX patch.

Findings:
- P31-P41 in the current `R125 + Local Codex P13/P14` candidate are normalized-identical to the latest local upper-band candidate. Byte hashes differ only by serialization/newline style.
- P43 is likewise normalized-identical to the latest local P43 restoration.
- P42 intentionally differs: R125 contains the newer complete Paper 42 source rebuild and supersedes the older local P42/RA82 survival state.

Web instruction encoded in package: keep R125 P42; do not reapply older local P42 salvage. Do not blindly redo known P33/P34/P35/P36/P38/P39/P40/P41/P43 targeted repairs; residual open work is broad certification/source-quality work where the status CSV says so, not replaying already-surviving fixes.

Package has 23 expanded files, 0 failed required checks, ZIP-open tested.

## 2026-06-25 - R125 P21-P30 Middle-Band Reconcile Package

Created `Noether_R125_LocalCodex_P21_P30_MiddleBand_Reconcile_WebDrop_20260625.zip`, SHA256 `B8EDED3EA3F5CA9DFAC92CB6B5AC29C270C9916F1E15D949B356E9316F9661D3`.

Purpose: compact web-drag reconciliation package for the R125 middle-band source queue rows P21-P30. It introduces no new TeX patch. The current `R125 + Local Codex P13/P14` candidate was compared against an older local P21-P30 reference and the meaningful differences were source-disposed.

Findings:
- P24 printed p233: the source has `x_1,\ldots,x_{i-1}`; the older local `x_i,\ldots,x_{i-1}` variant is wrong. Checked against `PPN235181684_0090.pdf` rendered at 650 dpi.
- P24 printed p234, formula (3): the source has `E^{(i)}\zeta_0`; the older local `E_0^{(i)}\zeta_0` variant is wrong. Checked against `PPN235181684_0090.pdf` rendered at 650 dpi.
- P25 printed p119: R125 retains the later local source-confirmed `\overline{\mathfrak R}` fix from the P25/P27 merge package.
- P27 Hilbertsche Anzahlen: R125 retains the later local source-confirmed plain italic `q`, `p`, `q/p`, `q/p^2` fix from the P27 q/p glyph package.

Web instruction encoded in package: do not regress R125 to the older P21-P30 reference for these four loci. The older middle-band reference is stale where it conflicts with the newer local source-confirmed P25/P27 packages and the direct P24 source render. Package has 30 expanded files, 0 failed anchor checks, ZIP-open tested.

## 2026-06-25 - Consolidated Post-R125 LocalCodex Web-Drop Bundle

Created `Noether_R125_LocalCodex_PostR125_All_WebDrops_Bundle_20260625.zip`, SHA256 `279640F36E41CD6B97734346DE9638D89BE229699E326599842C455956335BFC`.

Purpose: one drag-friendly bundle for the web session containing all LocalCodex packages made after the web `Noether_R125_20260625` drop. This prevents the web session from assuming R125 has all subsequent local work.

Included sub-zips:
- `Noether_R125_LocalCodex_Rebase_P13_P14_WebReturn_20260625.zip`
- `Noether_R124plus_P11_PostP14FullPageAuditSurvival_NoNewPatch_20260625.zip`
- `Noether_R125_LocalCodex_P10_P12_QueueDisposition_WebDrop_20260625.zip`
- `Noether_R125_LocalCodex_P04_P09_QueueDisposition_WebDrop_20260625.zip`
- `Noether_R125_LocalCodex_P31_P43_UpperBand_Reconcile_WebDrop_20260625.zip`
- `Noether_R125_LocalCodex_P21_P30_MiddleBand_Reconcile_WebDrop_20260625.zip`

Important distinction preserved in the bundle: only the P13/P14 package proposes an R125-based TeX patch candidate; the other packages are queue-disposition, source-quality caveat, and anti-regression evidence. The bundle also includes the current candidate TeX anchor and an R125 source-queue status CSV after local work. ZIP-open tested: 12 expanded files.

## 2026-06-25 - R125 Tail p713-p714 Noether-Deuring Definition Repair

Created `Noether_R125_LocalCodex_Tail_p713_p714_DefinitionRepair_WebDrop_20260625.zip`, SHA256 `B8AC9980F5BE923C54B17C9B105C83D31F7BA01BD2DE16901BDEDD64CB35702F`.

Purpose: first narrow source-confirmed repair of the visibly corrupted post-P43 Noether-Deuring tail. This starts from the current R125 + P13/P14 candidate and patches only collected pp. 713-714, using the best local Noether-Deuring page images from the R101 source backfill.

Confirmed fixes:
- p713: corrected the opening ring sentence and literal `\$ 1` heading.
- p713: replaced `©`/`Ty` direct-representation corruption with source-style `\mathfrak D` and `\mathsf T_n`.
- p714: rebuilt the reziprok ringhomomorph definition, including `cd -> d^* c^*` and `c+d -> c^*+d^*`.
- p714: corrected reciprocal display letters while preserving the source-marked reciprocal arrow.
- p714: corrected the representation-class paragraph: `\mathfrak D`, `\mathfrak D'`, `zuordnet`, and `äquivalent`.
- p714: corrected the direct representation module heading.

Source caveat: source is native about 360ppi, below the strict 650+ floor, but these loci are visually unambiguous. This package does not certify p715 onward or the Kapferer/bibliography tail. XeLaTeX passed twice; patched cumulative PDF is 469 pages. ZIP-open tested: 15 expanded files.

## 2026-06-25 - R125 Tail p713-p715 Noether-Deuring Definition Repair

Created `Noether_R125_LocalCodex_Tail_p713_p715_DefinitionRepair_WebDrop_20260625.zip`, SHA256 `79B9B40F685A385C07051BD1544279E48D455F32930A3252A518606BDD8F9E15`.

Purpose: superseding narrow source-confirmed repair package for the visibly corrupted post-P43 Noether-Deuring tail. This starts from the current R125 + LocalCodex P13/P14 candidate, carries forward the p713-p714 repair package, and extends the repair through collected p715. The p713-p714 package is now superseded by this one.

Confirmed fixes carried forward from p713-p714:
- p713: corrected the opening ring sentence and literal `\$ 1` heading.
- p713: replaced `©`/`Ty` direct-representation corruption with source-style `\mathfrak D` and `\mathsf T_n`.
- p714: rebuilt the reziprok ringhomomorph definition, including `cd -> d^* c^*` and `c+d -> c^*+d^*`.
- p714: corrected reciprocal display letters while preserving the source-marked reciprocal arrow.
- p714: corrected the representation-class paragraph: `\mathfrak D`, `\mathfrak D'`, `zuordnet`, and `äquivalent`.
- p714: corrected the direct representation module heading.

New p715 fixes:
- normalized source-style d.D.M./r.D.M. definitions and displays;
- corrected `\overline{\mathbb D}` and `\overline{\mathbb Q}` to source symbol `\overline{\mathfrak D}`;
- fixed the basis sentence to source-style `Basis \(x_1,\ldots,x_n\) von \(\mathfrak M\)`;
- reflowed the `(c+d)` and `cd` displays using source-aligned environments;
- corrected `\mathsf T^*` and `\mathsf T_n` styling plus several punctuation/spacing issues.

Source caveat: the available Noether-Deuring page images are native about 360ppi, below the strict 650+ floor. These particular fixes were only accepted where visually unambiguous against the best local witness. No strict page-level certification is asserted for p713-p715 or for the remaining tail. XeLaTeX passed twice; patched cumulative PDF is 469 pages. ZIP-open tested: 15 expanded files.

## 2026-06-25 - R125 Tail p713-p716 Noether-Deuring Definition Repair

Created `Noether_R125_LocalCodex_Tail_p713_p716_DefinitionRepair_WebDrop_20260625.zip`, SHA256 `4E72E54E7AB56182A3015E55107F4BF6753A8E641E4EA9827DE5D729621E9F4E`.

Purpose: superseding narrow source-confirmed repair package for the Noether-Deuring tail. This starts from the current R125 + LocalCodex P13/P14 candidate, carries forward p713-p715, and extends through collected p716.

New p716 fixes:
- corrected source-visible fraktur/ring symbols in the closing paragraph of §4: `\mathfrak{o}`, `\mathfrak M`, `\mathsf T`, and `x_\nu`;
- rebuilt the change-of-basis computation from the source, replacing the damaged `(x, ..., x_n)` / `y_p` OCR line with the aligned \(P^{-1}CP\) display;
- restored `\mathfrak M` and `\mathfrak{o}` in the immediate conclusion about all bases of the module;
- corrected the start of the proof of item 2: \(n\), \(\mathsf T\)-Rechtsmodul, \(\mathfrak{o}\)-Linksmodul, \(\mathfrak{o},\mathsf T\)-Doppelmodul;
- corrected the module arithmetic line where `\sum x \tau_i` had lost its subscript and the source displays had been flattened.

Source caveat: the available Noether-Deuring p716 image is native about 360ppi, below the strict 650+ floor. The accepted p716 fixes are visually unambiguous on the best local witness, but this is not strict page-level certification. XeLaTeX passed twice; patched cumulative PDF is 469 pages. ZIP-open tested: 16 expanded files. This package supersedes both p713-p714 and p713-p715 tail repair packages.

## 2026-06-25 - R125 Tail p713-p717 Noether-Deuring Definition Repair

Created `Noether_R125_LocalCodex_Tail_p713_p717_DefinitionRepair_WebDrop_20260625.zip`, SHA256 `C01B42A55313985CBD9C0331C248B4E8B50CAC101797EF7D55C582B02728E6BD`.

Purpose: superseding narrow source-confirmed repair package for the Noether-Deuring tail. This starts from the current R125 + LocalCodex P13/P14 candidate, carries forward p713-p716, and extends through collected p717.

New p717 fixes:
- corrected the reciprocal module continuation from `© in T*` / plain `o` to source-style \(\mathfrak{o}\), \(\mathsf T^*\), and \(C\);
- rebuilt the column-vector display for the reciprocal representation matrix assignment;
- corrected the §5 heading from literal `\$ 5` to `§ 5`;
- rebuilt the opening coefficient-extension paragraph, replacing `o = cıP`, `2`, `dg`, `D`, `De`, and `0g` with source-style \(\mathfrak{o}=c_1\mathsf P+\cdots+c_n\mathsf P\), \(\Omega\), and \(\mathfrak{o}_\Omega\);
- rebuilt the formal-sum module-definition display and multiplication rule;
- restored the basis-independence sentence for \(\mathfrak{o}_\Omega\).

Source caveat: the available Noether-Deuring p717 image is native about 360ppi, below the strict 650+ floor. The accepted p717 fixes are visually unambiguous on the best local witness, but this is not strict page-level certification. XeLaTeX passed twice; patched cumulative PDF is 469 pages. ZIP-open tested: 17 expanded files. This package supersedes p713-p716.

## 2026-06-25 - R125 Tail p713-p719 Noether-Deuring Definition Repair

Created `Noether_R125_LocalCodex_Tail_p713_p719_DefinitionRepair_WebDrop_20260625.zip`, SHA256 `722A2E5A91C4982AE52CCEE549D5615B95E3FF08A620D570425BFD99D1B8CE04`.

Purpose: superseding source-confirmed repair package for the Noether-Deuring tail. This starts from the current R125 + LocalCodex P13/P14 candidate, carries forward p713-p717, and extends through collected pp. 718-719.

New p718-p719 fixes:
- rebuilt §6 from the source with \(\mathfrak Z\), \(\mathfrak Z_\Omega/\mathfrak C\), \(e_\nu\), \(Z_i\), and \(\Theta_i\), replacing `\beta_\Omega`, `\mathbb G`, and `\Im_\Omega` drift;
- rebuilt §7 first/second-kind field statements, correcting the target field/unit sentence and the primitive-element comparison paragraph;
- rebuilt §8 Zerfällungskörper from OCR garbage (`3`, `37/C`, `J''`, `PCT'C 2`, `¢`) to \(\mathfrak Z\), \(\Gamma\), \(\Omega\), and \(\mathfrak Z_\Gamma/\mathfrak C\);
- rebuilt §9 \(\Theta_i\), \(S_i=\Theta_i\Theta_1^{-1}\), \(Z_1\to Z_i\);
- rebuilt §10 Galois group paragraph and §11 theorem opening with \(\mathfrak Z\), \(Z\), \(\Gamma\), \(\mathfrak H\), and \(\mathfrak G\);
- replaced the malformed nested itemize/enumerate pair with the source two-item formulation.

Source caveat: the available Noether-Deuring pp. 718-719 images are native about 360ppi, below the strict 650+ floor. The accepted fixes are visually unambiguous on the best local witness, but this is not strict page-level certification. XeLaTeX passed twice; patched cumulative PDF is 469 pages. ZIP-open tested: 19 expanded files. This package supersedes p713-p717.

## 2026-06-25 - R125 LocalCodex Tail p713-p721 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p721_DefinitionRepair_WebDrop_20260625.zip`

Base: `Noether_R125_LocalCodex_Tail_p713_p719_DefinitionRepair_WebDrop_20260625`.

Scope: extended the Noether-Deuring collected tail repair from p713-p719 through p720-p721, starting from the p713-p719 cumulative candidate. The newest web transcript was inspected; it did not contain a newer packaged cumulative, so it was treated as context rather than an authority over this tail package.

Source: `Noether_R101_All_Page_Images_WebDrop_20260623`, Noether-Deuring collected native360 PNG witnesses for pp. 720-721. This is best available locally, below the strict 650ppi rule; therefore the patch is restricted to visually unambiguous OCR/symbol/layout damage and is not a page-complete micro-certification.

Confirmed repairs:

- p720: rebuilt Hilfssatz statement and proof block; corrected `\mathcal L`/OCR symbols to source `\Sigma`, `\mathsf T`, `\Theta_1`, `\mathfrak T`, `\mathfrak Z_\Omega/\mathfrak C`, `E_\nu`, `e_\nu^{(i)}`, `\sigma_\nu`, and source display punctuation.
- p721: replaced damaged Pandoc enumerate scaffold with source-style paragraph 2; corrected `\mathfrak Z=e_1\mathsf Z+\cdots+e_n\mathsf Z`, the `\ne` relation, invariant `E_1` proof, §12 heading with math `e_i`, and the basis display `\mathfrak Z=z_1\mathsf P+\cdots+z_n\mathsf P`.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages; page count changed because p721 scaffold was compacted into source-style paragraphs.

Open: p722 onward remains OCR-damaged and must continue page-by-page from source. Later tail bad-token scan still sees artifacts such as `\mathfrak{Z}_{\mathsf{Z}}` in unpatched later loci.

## 2026-06-25 - R125 LocalCodex Tail p713-p722 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p722_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p721 web drop plus continued p722 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p722, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p722 repairs:

- Rebuilt the end of §12: `e_j=\sum_\nu\varrho_\nu^{(j)}z_\nu`, the two inverse-basis equations, and the inverse `\zeta`/`\varrho` matrices.
- Restored `§ 13. Der allgemeine Fortsetzungssatz`, the source chain `\mathsf P\subseteq\mathfrak S\subseteq\mathfrak T\subseteq\mathfrak Z`, the finite-rank `\mathfrak S`-module proof, and the theorem statement ending `läßt sich ... erweitern`.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p723 onward remains visibly OCR-damaged and should continue sequentially.

## 2026-06-25 - R125 LocalCodex Tail p713-p723 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p723_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p722 web drop plus continued p723 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p723, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p723 repairs:

- Rebuilt the continuation of the general Fortsetzungssatz proof: displays for `\mathfrak S_\Omega`, `\mathfrak T_\Omega\cdot E`, the degree inequality, `\sum[\mathfrak T_\Omega\cdot E_\nu:\Omega]=st`, and the `\mathfrak T_\Omega E_\nu` conclusion.
- Rebuilt the transition to Kapitel III and §14, the group-ring definition, radical theorem, and first ideal calculation for `\mathfrak a=\mathsf P(a_1+\cdots+a_h)`.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p724 onward remains visibly OCR-damaged and should continue sequentially.

## 2026-06-25 - R125 LocalCodex Tail p713-p724 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p724_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p723 web drop plus continued p724 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p724, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p724 repairs:

- Restored the nilpotence calculation, corrected the abelian converse statement, and rebuilt the opening of §15.
- Rebuilt the abelian group-ring representation-count proof through the cyclic-product argument, the `\Theta_i` character paragraph, and the Hauptcharakter computation through `x_i=x_j`.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p725 onward remains open; next page begins the second Hauptcharakter calculation and must be source-checked before patching.

## 2026-06-25 - R125 LocalCodex Tail p713-p725 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p725_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p724 web drop plus continued p725 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p725, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p725 repairs:

- Restored the second Hauptcharakter calculation display with source punctuation: `E=E^2=x^2(\sum a_i)^2=x^2h\sum a_i=xhE.`
- Corrected the branch condition from `h\equiv0(p)` to source `h\not\equiv0(p)`, and corrected the order symbol from `\mathfrak v` to source `\mathfrak o`.
- Restored the combined `x=1/h, E=(1/h)(a_1+\cdots+a_h)` display.
- Corrected the character-relation sum from a bad bold-r index to `\sum_\nu \Theta_i a_\nu`.
- Corrected the bottom Galois-theory line to source `\Theta_i\Theta_1^{-1}` and source `Z` rather than `\Theta_t` / `\mathbb Z` drift.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p726 onward remains visibly OCR-damaged and should continue sequentially; p726 continues §17.

## 2026-06-25 - R125 LocalCodex Tail p713-p726 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p726_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p725 web drop plus continued p726 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p726, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p726 repairs:

- Corrected §17 group notation: the homomorphisms form the group `\mathsf A`, isomorphic to `\mathfrak A`.
- Corrected `z_{\it v}` / `h_{\it v}` drift to source `z_\nu`, `h_\nu`, `\varrho_\nu` notation, and fixed the product display where one exponent was `t` instead of source `i`.
- Restored the source definitions of Invariantenbereich and Invariantengruppe with the `\mathfrak B` / `\mathsf B` distinction.
- Repaired the Hauptsatz sentence from OCR `so da \beta` to source `so daß`.
- Replaced a nested list scaffold with the two source numbered assertions.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p727 onward remains visibly OCR-damaged. p727 starts in the middle of the proof after p726's hyphenated `um-`; do not trust the current p727 paragraph without visual source checking.

## 2026-06-25 - R125 LocalCodex Tail p713-p727 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p727_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p726 web drop plus continued p727 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p727, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p727 repairs:

- Continued proof part 1 from p726's page-break hyphen and restored `\mathsf B` as the group of extensions, with degree comparison `\mathfrak o[\mathfrak B']` over `\mathfrak o[\mathfrak B]`.
- Rebuilt proof part 2, treating elements `a` of `\mathfrak A` as homomorphisms of `\mathsf A`.
- Rebuilt the homomorphism-product / group-product display as editable TeX, including the source labels.
- Corrected the cyclic subgroup argument from false `\mathfrak A` indices to source `\mathfrak Z`, index `h`, and conclusion `\mathfrak Z=e,\ a=b`.
- Replaced nested list scaffolding with source `a)`, `b)`, `a')`, `b')` translation statements preserving the `\mathfrak B` / `\mathsf B` roles.
- Restored the final character-relation display and closing sentence of §17.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p728 onward remains visibly OCR-damaged. p728 begins Kapitel IV / §18 and current TeX already shows damaged group/module notation.

## 2026-06-25 - R125 LocalCodex Tail p713-p728 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p728_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p727 web drop plus continued p728 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p728, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p728 repairs:

- Rebuilt the opening of Kapitel IV / §18 using `\mathsf K`, `\mathsf P`, and automorphism group `\mathfrak G`.
- Corrected the module setup `\mathfrak M=x_1\mathsf P+\cdots+x_n\mathsf P` and extended module `\mathfrak M_{\mathsf K}`.
- Corrected the invariant-domain sentence from false `\mathfrak B` to source `\mathfrak G`.
- Restored the theorem statement for `\mathfrak C=z_1\mathsf K+\cdots+z_r\mathsf K` and conclusion `\mathfrak C=\mathfrak c_{\mathsf K}`.
- Repaired the proof Vorbemerkung through the basis-extension sentence, preserving `\mathfrak c`, `\mathfrak C`, `\mathfrak M`, `\mathfrak c_{\mathsf K}`, and the two basis representations of `c`.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p729 onward remains visibly OCR-damaged. p729 continues the Vorbemerkung proof and begins step 2.

## 2026-06-25 - R125 LocalCodex Tail p713-p729 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p729_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p728 web drop plus continued p729 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p729, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p729 repairs:

- Closed the §18 Vorbemerkung with the source coefficient-identification sentence and `c=\sum y_i\varrho_i` display.
- Rebuilt step 2 of the lemma proof, including the basis construction for `\mathfrak C`, `\mathfrak c=z_1\mathsf P+\cdots+z_r\mathsf P`, and `\mathfrak C=\mathfrak c_{\mathsf K}`.
- Restored the `x_i=z_i-\sum x_j\varkappa_j^{(i)}` display and the proof that the `z_i` belong to `\mathfrak M`.
- Restored equations `(1)`, `(2)`, `(3)`, the coefficient comparison, and `\gamma\cdot z_i=z_i`.
- Converted §19 from plain text to a subsection heading and restored the opening `\mathfrak S=x_1\mathsf P+\cdots+x_n\mathsf P` plus the `\mathsf K`/`\mathsf P` center statement.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p730 onward remains visibly OCR-damaged. p730 starts Satz 1 and proof of §19.

## 2026-06-25 - R125 LocalCodex Tail p713-p730 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p730_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p729 web drop plus continued p730 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p730, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p730 repairs:

- Restored Satz 1 as `\mathfrak S_{\mathsf K}` zweiseitig einfach.
- Rebuilt proof part 1: ideal `\mathfrak a`, inner automorphism `\varkappa^{-1}\mathfrak a\varkappa=\bar{\mathfrak a}`, and `\mathsf K`-rank argument.
- Rebuilt proof part 2: Hilfssatz application `\mathfrak a=\mathfrak A_{\mathsf K}` and the two ideal-inclusion displays.
- Corrected the transition to irreducible reciprocal representations of `\mathfrak S` in `\mathsf K`.
- Restored the reciprocal module `\mathfrak M=\mathsf K\cdot y_1+\cdots+\mathsf K\cdot y_r`, commuting law, and `\mathfrak S_{\mathsf K}` action definition.
- Restored equation `(1)`, the target implication, and the linear-dependence relation for `s_j` at the page bottom.

Compile: XeLaTeX pass 1 and pass 2 exit 0. PDF has 468 pages.

Open: p731 onward remains visibly OCR-damaged. p731 continues the coefficient argument after equation (1), and the current TeX contains a repeated English garbage sentence beginning `Wegen des Assoziativally series...`.

## 2026-06-25 - R125 LocalCodex Tail p713-p731 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p731_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p730 web drop plus continued p731 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p731, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p731 repairs:

- Corrected the coefficient relation after equation (1) to source-visible `\rho_i^{(j)}` and `\mathsf P`.
- Rebuilt the long expansion proving `\sum_i s_i(\varkappa_i m)=0`, including the source side-note labels `Wegen Moduleigenschaft` and `Wegen des Assoziativgesetzes`.
- Removed the corrupt English repetition beginning `Wegen des Assoziativally series...` from the active cumulative TeX.
- Restored the `\mathfrak S_{\mathsf K}`-module associativity proof for `s\varkappa\cdot(s'\varkappa' m)`.
- Corrected the two commutation relations from bold OCR artefacts to source-style `\varkappa\cdot s'=s'\cdot\varkappa` and `s'\cdot(\varkappa\cdot m)=\varkappa\cdot(s'\cdot m)`.
- Normalized visible p731 `\mathfrak S_{\mathsf K}`, `\mathfrak M`, and `\mathsf K` notation.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p732 onward remains uninspected in this tail pass. The immediate continuation begins Satz 2 and the current TeX still shows visible placeholder/OCR damage such as `©`, `Sx`, and `G` in the first p732 lines.

## 2026-06-25 - R125 LocalCodex Tail p713-p732 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p732_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p731 web drop plus continued p732 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p732, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p732 repairs:

- Rebuilt Satz 2: unique irreducible reciprocal representation class of `\mathfrak S` in `\mathsf K`, generated by a simple left ideal of `\mathfrak S_{\mathsf K}`.
- Corrected the degree argument, `n=rt`, the quotient `t`, and `t^2` as the rank of `\mathfrak S_{\mathsf K}` over the automorphism field of its simple ideals.
- Restored the commutative specialization and Satz 3: `\mathfrak S` is the center of `\mathfrak S_{\mathsf K}`.
- Restored the proof paragraph, including `\mathfrak r\mathfrak S=\mathfrak S\mathfrak r`.
- Restored §20 heading, `\mathfrak K=y_1\mathsf P+\cdots+y_m\mathsf P`, and the opening `Z`/`\mathfrak K_Z` setup.
- Removed visible p732 placeholder damage in the repaired span, including `©`, `Sx`, `G`, `¢`, `#2`, `Sl`, `€`, `£`, and `®z`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p733 onward remains uninspected in this tail pass. The immediate continuation starts after the bottom `\mathfrak K_Z` display and current TeX begins with `und für Ze` plus malformed `Z_{\widehat{\mathtt N}}`/`y_i\xi_j` notation.

## 2026-06-25 - R125 LocalCodex Tail p713-p733 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p733_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p732 web drop plus continued p733 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p733, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p733 repairs:

- Restored the `Z_{\mathfrak K}` display and `y_i\xi_j=\xi_jy_i`.
- Rebuilt the `\mathfrak K_Z` setup and Satz 1: the center of `\mathfrak K_\Omega` is `\Omega`.
- Rebuilt Satz 2 and its ideal proof for two-sided simplicity of `\mathfrak K_\Omega`.
- Restored Satz 3: `\mathfrak K_\Omega=\sum\Omega c_{ik}` and `m=t^2`.
- Restored the absolute component number definition and the `Zerfällungskörper` definition with source footnote.
- Restored the Satz 4 statement about the automorphism field of right ideals of `\mathfrak K_Z`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p734 onward remains uninspected in this tail pass. The immediate continuation starts the proof of Satz 4 and current TeX contains malformed `\mathfrak A_7`, `\Re_7`, and `\Sigma \mathfrak T c_{ik}` notation.

## 2026-06-25 - R125 LocalCodex Tail p713-p734 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p734_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p733 web drop plus continued p734 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p734, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p734 repairs:

- Rebuilt Satz 4 proof parts 1 and 2, replacing broken Markdown/OCR list scaffolding.
- Restored `\mathfrak K_Z`, `\mathfrak K_\Omega`, `\mathfrak T`, `\mathfrak T_\Omega`, `Z`, and `\Omega` coefficient displays.
- Restored the rank argument proving `\mathfrak T=Z` and the converse count of the `c_{ik}`.
- Rebuilt Satz 5 and its converse for the irreducible representation `\mathfrak Z` and maximal commutative subfields of `\mathfrak K_r`.
- Restored proof part 1, including `n/t`, `r^*\leq r`, and `n\leq n^*=r^*t\leq rt=n`.
- Restored proof part 2, including the `\mathfrak T` automorphism field, right ideal `\mathfrak r`, and maximality contradiction with `\overline{\mathfrak T}`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p735 onward remains uninspected in this tail pass. The immediate continuation begins with Satz 6/Satz 7 and current TeX contains malformed `\&`, `S\},`, `fl`, `©ı`, and related symbols.

## 2026-06-25 - R125 LocalCodex Tail p713-p735 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p735_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p734 web drop plus continued p735 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p735, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p735 repairs:

- Restored Satz 6 and moved its source footnote back into the theorem statement.
- Rebuilt Satz 7 on isomorphisms of simple subrings of `\mathfrak K_r`, including the `\tau^{-1}\sigma_1\tau=\sigma_2` display.
- Restored the proof using `\Sigma`, `\mathfrak S_1`, `\mathfrak S_2`, and reciprocal representation classes.
- Restored Satz 8 on the galois group `\mathfrak G` and inner automorphisms of `\mathfrak K`.
- Restored Satz 9 and the start of the quaternion theorem proof through the p735 split word `Iso-`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p736 onward remains uninspected in this tail pass. The immediate continuation begins after the split word `Iso-` and current TeX contains malformed `ö+>`, `j* ER`, and quaternion-basis notation.

## 2026-06-25 - R125 LocalCodex Tail p713-p736 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p736_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p735 web drop plus continued p736 source inspection.

Source: Noether-Deuring collected native360 PNG witness for p736, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p736 repairs:

- Continued the quaternion proof from the p735 split word, restoring the isomorphism `i\mapsto -i` and the conjugacy relation `j^{*-1}ij^*=-i`.
- Rebuilt the centralizer/quaternion-basis passage with `\mathfrak Z_1(j^*)`, `\mathfrak K=R+Ri+Rj^*+Rij^*`, the four conjugation identities, `j^{*2}=-m^2`, and the normalized units `1,i,j,k=ij`.
- Restored Satz 10, including the Wedderburn statement that every finite skew field is commutative.
- Rebuilt the Satz 10 proof around `\mathfrak K^*`, `\mathfrak Z^*`, the maximal subfield `\mathsf M`, `M=NL`, and the counting contradiction.
- Restored the §21 heading and opening Galois-theory paragraph, including the isomorphism `\overline G=\mathfrak K^*/\mathsf P^*` and the subgroup `\mathfrak H^*` corresponding to `H`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p737 onward remains uninspected in this tail pass. The immediate continuation begins Satz 11 and the current TeX has broken `©`, `&`, `\mathfrak`, and itemize/enumerate scaffolding in the Hauptsatz block.

## 2026-06-25 - R125 LocalCodex Tail p713-p738 Definition Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p738_DefinitionRepair_WebDrop_20260625.zip`

Base: frozen p713-p736 web drop plus continued p737-p738 source inspection. The p737 page runs into p738, so this package repairs the complete Satz 11 proof unit through `w.z.b.w.` rather than leaving a page-turn fragment.

Source: Noether-Deuring collected native360 PNG witnesses for p737 and p738, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p737-p738 repairs:

- Rebuilt Satz 11 statement with the correct correspondence between closed subgroups `H` of `G` and fields `\mathfrak S` between `\mathsf P` and `\mathfrak K`.
- Removed broken Markdown list scaffolding and restored the three substatements plus the proof reductions, including the `3'` reformulation.
- Corrected the subgroup/field notation in the proof: `\mathfrak H^*`, `\mathfrak S^*/\mathsf P^*`, `\mathfrak H^*/\mathsf P^*`, and the centralizer/invariant-field language.
- Restored the auxiliary reciprocal field `K`, the inclusions `\mathsf P\subseteq\mathfrak S\subseteq\mathfrak T\subseteq\mathfrak K` and `K\subseteq\mathfrak S_K\subseteq\mathfrak T_K\subseteq\mathfrak K_K`.
- Rebuilt the representation-extension argument: decompositions of `\mathfrak S_K` and `\mathfrak T_K`, the rank inequalities, `\mathfrak T_K E_\nu=K e_1^{(\nu)}+\cdots+K e_s^{(\nu)}`, and the distinguishing equations `e_i^{(\nu)2}=e_i^{(\nu)}` and `e_i^{(\nu)}e_j^{(\nu)}=0`.
- Restored the final invariant-group conclusion using `\mathfrak K`, `\mathfrak S`, `\mathfrak T`, and `s=1`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: p739 onward remains uninspected in this tail pass. The immediate continuation begins Kapitel V, §22, and the current TeX still shows likely symbol drift in the factor-system chapter (`\Re`, `\mathfrak L`, matrix-ring notation, and source page p739/p740 displays).

## 2026-06-25 - R125 LocalCodex Tail p713-p740 Section 22 Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p740_Section22Repair_WebDrop_20260625.zip`

Base: frozen p713-p738 web drop plus source inspection of collected p739 and the upper p740 continuation. This package repairs §22 completely; it does not certify the §23 opening on lower p740, which continues to p741.

Source: Noether-Deuring collected native360 PNG witnesses for p739 and p740, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed §22 repairs:

- Rebuilt Kapitel V / §22 opening with source-consistent `\mathfrak K_r`, `\mathfrak L_s`, `\mathfrak M`, and `\mathsf P` notation.
- Restored the direct-product definitions and commutativity identities for `\mathfrak K_r\times\mathfrak L_s`.
- Rebuilt the class argument for `\{\mathfrak K\}`, `\{\mathfrak L\}`, the class product, and the group `\mathscr K`.
- Restored the inverse-class argument `\{\mathfrak K\}^{-1}=\{\overline{\mathfrak K}\}` and the simple-left-ideal rank proof for `\mathfrak K\times\overline{\mathfrak K}`.
- Restored the definition of an `einfacher Körper` and the theorem that every `\mathfrak K` is a direct product of simple subfields.
- Rebuilt the proof with `\mathfrak K^{(1)}`, `\mathfrak S`, `\mathfrak S_\lambda`, `t^2` instead of the OCR-drifted `\iota^2`, and the final inner-automorphism formulas with `\lambda` and `\mu`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF remains 468 pages.

Open: §23 starts on lower p740 and continues on p741; current TeX for §23 is still uninspected in this pass and shows likely notation drift around `Z`, `\Gamma`, `\mathfrak l_i`, and factor-system symbols.

## 2026-06-25 - R125 LocalCodex Tail p713-p742 Section 23 Start Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p742_Section23Start_WebDrop_20260625.zip`

Base: frozen p713-p740 §22 web drop plus source inspection of the §23 opening on lower p740 through p742. This package repairs the first coherent factor-system construction through the associated-factor-system paragraph.

Source: Noether-Deuring collected native360 PNG witnesses for p740, p741, and p742, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed §23-start repairs:

- Rebuilt the §23 assumptions with `\mathsf P`, `\mathfrak K`, `Z`, `\mathfrak Z`, and `\Gamma` instead of OCR-drifted `\Re`, `\Im`, `\beta`, and `\Omega_\tau`.
- Restored the decomposition of `\mathfrak K_{r\Gamma}` into simple left ideals `\mathfrak l_i=\mathfrak K_{r\Gamma}e_i`.
- Corrected the Galois-group action and conjugacy formulas `S(z)=z`, `S(\mathfrak l_j)=\mathfrak l_i`, and `S(i)=k` when `S(Z_i)=Z_k`.
- Rebuilt the `Z_i,Z_k` compositum construction, the barred ideals `\bar{\mathfrak l}_i`, `\bar{\mathfrak l}_k`, and the matrix-unit expansions.
- Restored the pseudomatrix-unit definitions for `p_{ik}`, including `p_{ik}=c_{ik}^{(ik)}\gamma_{ik}`, the transported `p_{\nu\mu}` formulas, and the two matrix-unit relation lines.
- Rebuilt the factor-system relations `p_{ij}p_{1k}=0`, `p_{ij}p_{jk}=\alpha_{ik}^{(j)}p_{ik}`, the conjugacy law for `\alpha`, and the associated-system transformation formula with the `\delta` quotient.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF is now 467 pages after removing malformed scaffolding and compacting the repaired displays.

Open: The continuation after the associated-factor-system paragraph, beginning with the independence of the class from the chosen representation, remains uninspected in this pass and continues toward §24.

## 2026-06-25 - R125 LocalCodex Tail p713-p746 Section 24 / Satz 2 Start Repair

Package: `Noether_R125_LocalCodex_Tail_p713_p746_Section24Satz2Start_WebDrop_20260625.zip`

Base: frozen p713-p742 §23-start web drop plus source inspection of collected p743-p746. This package continues the factor-system tail through the start of Satz 3 / Brauer proof.

Source: Noether-Deuring collected native360 PNG witnesses for p743, p744, p745, and p746, best available locally but below 650ppi. Repairs are restricted to visually unambiguous source-visible damage.

Confirmed p743-p746 repairs:

- Rebuilt the class-independence paragraph after associated factor systems, including `\mathfrak Z`, `\mathfrak K_r`, `\mathfrak G`-invariance, `p'_{ik}=\lambda^{-1}p_{ik}\lambda`, and the unchanged factor-system conclusion.
- Restored §24 and Satz 1 with source-consistent `\mathfrak K`, `\mathfrak S`, center `\mathsf P`, and `\mathscr K_Z` notation.
- Restored the Hilfsbetrachtung decompositions of `\mathfrak K_r`, `\mathsf P_m`, `\mathfrak K_{rm}`, and the `A_\Gamma` decompositions (1) and (2).
- Rebuilt the Hilfssatz statement/proof with `\mathfrak z`, `\mathfrak q_i`, `e_i^*`, `s_i`, `t_i`, `\xi`, `\xi^*`, `\lambda`, and `\mu`.
- Restored the `r_{ik}` construction, factor-system relation, and arbitrary-decomposition Satz.
- Rebuilt Satz 2 with the product factor-system statement, proof obligations, diagonal ideal `A_1`, automorphism field `\mathfrak M`, and the trivial-factor-system argument producing `\Omega`.
- Restored the opening of Satz 3 / Brauer proof through the source-visible p746 bridge identity beginning `Aus ... folgt`.

Build: XeLaTeX pass 1 and pass 2 both exit 0; cumulative German PDF is 467 pages.

Open: p747 onward remains uninspected in this pass. Immediate continuation should audit the exact `\xi` / `\alpha` quotient formulas and the rest of Satz 3 / Schur proof material against source before promotion.

## 2026-06-25 - R125+ P17 RA52/RA77/RA94 Survival and Anchor Audit

Package: `Noether_R125plus_P17_RA52_RA77_RA94_Survival_AnchorAudit_20260625.zip`

Base checked: latest local R125+ cumulative after the web R125 drop and Local Codex tail repairs through collected p746.

Purpose: prevent the web session from replaying stale Paper 17 fixes after R125. This was a survival/coordination audit, not a new page-by-page source certification.

Confirmed against the current R125+ TeX:

- RA52/RA77 p25 source footnote 21 survives at the equality ending `=r^{\sigma\rho}b_\rho`, with explicit `\footnotemark[21]` and `\footnotetext[21]`.
- RA52/RA77 p25 source footnote 22 survives at formula (39), with explicit `\footnotemark[22]` and `\footnotetext[22]`.
- RA94's removal of the non-source `Fortsetzung zu 17` scaffold still survives; the marker is absent.
- No new TeX patch was made.

Structural warning for web: the current cumulative has P17, P18, and P19 bodies present, but no top-level `\section*{17...}`, `\section*{18...}`, or `\section*{19...}` anchors. P20 resumes normal section anchoring. Treat this as cumulative navigation/metadata cleanup, not missing source text and not an authorial-source defect.

Source-quality caveat: P17 full-page source is best-known 600 ppi, below the strict 650+ floor. The p25 fixes are backed by a prior 1000 dpi targeted witness; the p11 scaffold check by a 650 dpi targeted witness. Do not claim full P17 page-by-page certification from this package.

## 2026-06-25 - R125+ P14-P16 RA53/RA54/RA55/RA78 Survival and Anchor Audit

Package: `Noether_R125plus_P14_P16_RA53_RA55_RA78_Survival_AnchorAudit_20260625.zip`

Base checked: latest local R125+ cumulative after the web R125 drop and Local Codex tail repairs through collected p746.

Purpose: prevent stale replay of the older P14-P16 source-critical packages after R125. This was a survival/coordination audit, not a new page-by-page source certification.

Confirmed against the current R125+ TeX:

- P14 RA55 fixes survive: `mod. (z-c)` at the line-factorization locus; `\rho_1...\rho_\sigma` ideal factorization; `\rho/\sigma` polygon exponents.
- P15 RA54 fixes survive: Latin `x` index family in the normalization block; Schur citation `S. 355 (1912)`.
- P16 RA53 fix survives: `linear zusammensetzen aus $F$ und aus Formen aus $M$`.
- P15 and P16 have local footnote resets plus normal top-level `\section*` anchors.
- No new TeX patch was made.

Structural warning for web: P14 body is present and begins after a local footnote reset, but the top-level `\section*{14...}` project anchor from RA78 is absent in the current R125+ cumulative. Treat this as cumulative navigation/metadata cleanup, not missing source body and not a mathematical source defect.

Source-quality caveat: prior P14-P16 source PDFs were reported as native 360 ppi, with 1000 dpi inspection enlargements from those embedded images for exact repair loci. Do not claim blanket 650+ certification from this package.

## 2026-06-25 - R125+ Local Codex Post-R125 Web-Drop Bundle v2

Package: `Noether_R125_LocalCodex_PostR125_All_WebDrops_Bundle_v2_20260625.zip`

Purpose: provide one current drag-drop package for the web session after later Local Codex work continued beyond the earlier post-R125 bundle. The previous bundle did not include the later tail repair through collected p746 or the P14-P17 survival/anchor audits.

Contents included:

- Latest tail fix-bearing package through collected p746: `Noether_R125_LocalCodex_Tail_p713_p746_Section24Satz2Start_WebDrop_20260625.zip`.
- Current German cumulative candidate from that tail package.
- P14-P16 survival/anchor audit package.
- P17 survival/anchor audit package.
- Earlier post-R125 queue/context zips for P04/P09, P10-P12, P13/P14 rebase, P21-P30, P31-P43, and the older P11 post-P14 survival package.
- Existing queue/status CSVs from the first post-R125 bundle plus a hand-written v2 index describing trust/order/use.

Action guidance recorded for web:

- Use the p746 cumulative TeX as the latest Local Codex German candidate.
- Do not replay older tail incrementals; p746 supersedes them.
- Treat P14-P17 survival packages as coordination guards, not new source certification.
- Treat missing P14 and P17-P19 top-level `\section*` anchors as navigation/metadata cleanup, not missing source body.

Source-quality caveat: p713-p746 tail repairs use best-local native360 Noether-Deuring witnesses. They are source-visible and compile-clean but below the strict high-resolution certification floor. Recheck p713 onward if a higher-resolution witness becomes available.

## 2026-06-25 - R125+ Local Codex Tail p747-p748 Brauer/Schur Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p748_BrauerSchurRepair_WebDrop_20260625.zip`

Base: `Noether_R125_LocalCodex_Tail_p713_p746_Section24Satz2Start_WebDrop_20260625.zip`.

Source: Noether-Deuring collected native360 PNG witnesses for collected pp. 747 and 748:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`

These are best local witnesses but below the 650+ certification floor. Repairs are limited to source-visible OCR/provisional transcription damage.

Confirmed repairs:

- Corrected the p747 product relation to use \(p_{jk}\xi_{jk}^{(\lambda)}\) in the middle factor.
- Restored the associated-factor quotient \(\alpha_{ik}^{(j)}=\xi_{ik}^{(\lambda)}/(\xi_{ij}^{(\lambda)}\xi_{jk}^{(\lambda)})\).
- Rebuilt the \(\delta_{\nu\mu}\) product and quotient argument through the conclusion that the order of \(\{\mathfrak R\}\) divides \(n\), and hence \(\lambda\) divides \(t\) for \(\mathfrak Z\) maximal commutative.
- Rebuilt the Schur second proof and the representation of \(p_{ik}\) by regular matrices \(P_{ik}\), including the basis display, conjugacy relation \(S(P_{ik})=P_{\nu\mu}\), and homomorphy display.
- Rebuilt Satz 4 with the Sylow subgroup proof, the degree equations, the \(\lambda\equiv0\pmod {p^\alpha}\) conclusion, and the Brauer footnote.
- Rebuilt Satz 5 statement and proof opening through \(\{\mathfrak R\}=\prod_i\{\mathfrak R^{(i)}\}\).

Build: XeLaTeX pass 1 and pass 2 exit 0; German cumulative PDF remains 467 pages.

Open: p749 onward remains uninspected in this pass and still contains provisional/OCR-derived material.

## 2026-06-25 - R125+ Local Codex Tail p747-p749 Brauer/Schur + §25 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p749_BrauerSchurSection25Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p748-only package.  The cumulative German TeX was patched through source p749 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`

Source-quality caveat: these are native 360 ppi IA-derived page images, the best local witnesses staged for this tail.  This remains below the 650 ppi project threshold, so the package is a best-available repair drop, not a strict-certification claim.

Confirmed repairs:

- p747-p748: carried forward the Brauer/Schur repair, including the corrected \(p_{ij}\xi_{ij}^{(\lambda)}\cdot p_{jk}\xi_{jk}^{(\lambda)}\) product, the quotient formula for \(\alpha_{ik}^{(j)}\), the \(\delta\)-product argument, the Schur matrix proof, Satz 4, and the opening of Satz 5.
- p749: restored the closing Satz 5 proof through the product equation \(\prod_i p_i^{\varrho_i}=\prod_i p_i^{\sigma_i}\cdot m\), the source-visible inequality pair \(\sigma_i\le\varrho_i\) in prose and \(\sigma_i\ge\varrho_i\) in display, and the equality/direct-product conclusion.
- p749: restored the §25 heading, its source footnote `Einfachere Begründung von § 27 an.`, and the opening normal-representation setup through \(H_S=\Theta_E^{-1}\Theta_{S^{-1}}\).

Open: p750 onward remains open.  If a higher-resolution witness appears, pp. 747-749 should receive a strict recertification pass.

## 2026-06-25 - R125+ Local Codex Tail p747-p750 §25 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p750_BrauerSchurSection25Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p749 package.  The cumulative German TeX was patched through source p750 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Rejected source lead:

- `C:\Users\Floris\Documents\Papors\OS\noet du,mp ia\sim_mathematische-annalen_1927_96_jp2.zip` was checked at leaf0755/page 750 and rejected for this tail; the page is W. Hurewicz, not the Deuring/Noether material.

Confirmed p750 repairs:

- Corrected \(u_T\) as an \(\mathfrak R_r\)-element because it is \(\mathfrak G\)-invariant; the previous TeX had the wrong invariant object.
- Rebuilt the \(H_T\) calculation for \(\mathfrak Z\)-elements through \(z u_T=u_T H_T(z)\).
- Corrected the linear-independence statement from \(\beta\) to \(\mathfrak Z\).
- Corrected the final relation from `aus 3` to \(a_{R,T}\ne0\) aus \(\mathfrak Z\).

Open: p751 onward remains open.

## 2026-06-25 - R125+ Local Codex Tail p747-p751 §25 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p751_BrauerSchurSection25Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p750 package.  The cumulative German TeX was patched through source p751 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p751 repairs:

- Rebuilt the opening \(u_Ru_T\) product chain as one source-style aligned display.
- Corrected \(\Re_r\) to \(\mathfrak R_r\) where the source names the ring.
- Corrected \(r_S\neq0\) being chosen from \(\beta\) to being chosen from \(\mathfrak Z\).
- Restored source labels (1), (2), (I), (II), and (III) without generated enumerate scaffolding.
- Restored the missing prime in the associated large factor system \(\alpha^{(A)\prime}_{BC}\).
- Corrected `3-Basis` to \(\mathfrak Z\)-Basis.
- Corrected display (II) from \(k_{S_1}u_S,\ldots,k_{S_1}u_S\) to \(k_{S_1}u_S,\ldots,k_{S_n}u_S\).

Open: p752 onward remains open.  The p752 paragraph already visible in the candidate contains suspicious \(\Im\)/group-symbol damage, but it was not patched in this pass because p752 needs to be opened against source first.

## 2026-06-25 - R125+ Local Codex Tail p747-p752 §25 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p752_BrauerSchurSection25Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p751 package.  The cumulative German TeX was patched through source p752 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p752 repairs:

- Restored the group/field notation in the opening matrix-representation paragraph: \(\mathfrak R_r\), \(\mathfrak Z/P\), \(\mathfrak G^*\), \(\mathfrak Z^*\), and \(\mathfrak G\).
- Rebuilt the non-homomorphy sentence and calculation so `nicht` is prose and the display ends with \(u_Su_T\mapsto A_TA_S^T\).
- Corrected \(\mathfrak R_T\) to \(\mathfrak R_r\), restored display (IV), and corrected the endpoint from \(k_S\) to \(k_{S_n}\).
- Corrected the basis-change prose from \(k\)-basis to \(h\)-basis and from k-to-k transformation to k-to-h transformation.
- Restored the source relation \((kz)u_S=(ku_S)z^S\) with \(k\in\mathfrak R_r\), \(z\in\mathfrak Z\).
- Rebuilt the general two-item definition of a twisted representation of \(\mathfrak G^*\) in \(\mathfrak Z\), including the \(\mathfrak Z\)-matrix item.
- Corrected `3-Rechtsmodul` to \(\mathfrak Z\)-Rechtsmodul at the bottom of the page.

Open: p753 onward remains open.  The p753 continuation begins immediately after the displayed \(\mathfrak M=x_1\mathfrak Z+\cdots+x_m\mathfrak Z\) line and should be opened against source before patching.

## 2026-06-25 - R125+ Local Codex Tail p747-p753 §26 Start Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p753_BrauerSchurSection26StartRepair_WebDrop_20260625.zip`

Status: supersedes the p747-p752 package.  The cumulative German TeX was patched through source p753 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`
- `Noether_Deuring_collected_p753_seq43.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p753 repairs:

- Corrected the continuation to \(\mathfrak G^*\)-Rechtsmodul and \(\mathfrak R_r\)-Rechtsmodul.
- Restored \(\mathfrak R_r\), \(\mathfrak Z\), and \(\mathfrak R\) notation through the M.Z. §18/rank argument.
- Corrected the S. 22 rank formulas from \(\beta\)/`\equiv` damage to source equalities involving \(\mathfrak Z\), \(\mathfrak R_r\), and \(\mathfrak r\).
- Corrected the §26 opening from a false \(A_S^{-1}\) into a footnote marker on \(S\mapsto A_S\), and restored the Speiser footnote.
- Corrected the Speiser footnote formula to \(A_TA_S^T=A_{ST}\cdot a_{S,T}^{-1}\).
- Rebuilt the two given representations as the source-style two-line display.

Open: p754 onward remains open.  The Kronecker-product paragraph begins immediately after the p753 two-line representation display and should be opened against source before patching.

## 2026-06-25 - R125+ Local Codex Tail p747-p754 §26/§27 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p754_BrauerSchurSection26_27Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p753 package.  The cumulative German TeX was patched through source p754 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`
- `Noether_Deuring_collected_p753_seq43.png`
- `Noether_Deuring_collected_p754_seq44.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p754 repairs:

- Corrected the Kronecker-product claim from \(\mathfrak S/\mathfrak N_r\) damage to \(\mathfrak G/\mathfrak R_r\).
- Restored the proof setup display for \(S\mapsto A_S\times B_S\), \(T\mapsto A_T\times B_T\).
- Corrected matrix-unit notation \(d_{\mu\nu}\), \(\mathfrak R_r\), and \(\mathfrak L_s\).
- Corrected the new matrix units from a false minus to \(c_{ik}d_{\mu\nu}=d_{\mu\nu}c_{ik}\).
- Restored the direct product of matrix rings over \(\mathfrak Z\) and fixed the final multiplier to \(a_{S,T}^{-1}b_{S,T}^{-1}\).
- Corrected the §27 heading/opening and Satz 1 from \(\Re_\tau\), \(\beta\), and \(\Im\) damage to \(\mathfrak R_r\), \(\mathfrak Z\), and \(\mathfrak G\).
- Restored the visible start of Definition 1: \(\mathfrak G=\{E,S,\ldots,T\}\), \(\mathfrak R_r=\mathfrak Z u_E+\cdots+\mathfrak Z u_T\), and the small factor systems in \(\mathfrak Z\).

Open: p755 onward remains open.  The next page continues Definition 2 after the words `Gesamtheit der regulären`.

## 2026-06-25 - R125+ Local Codex Tail p747-p755 §27 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p755_BrauerSchurSection27Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p754 package.  The cumulative German TeX was patched through source p755 and rebuilt successfully with XeLaTeX; the rebuilt PDF remains 467 pages.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`
- `Noether_Deuring_collected_p753_seq43.png`
- `Noether_Deuring_collected_p754_seq44.png`
- `Noether_Deuring_collected_p755_seq45.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p755 repairs:

- Rebuilt Definition 2 continuation with \(\mathfrak R_r\), \(\mathfrak Z\), \(\mathfrak G\), \(\mathfrak G^*\), \(\mathfrak T^*\), and \(\mathfrak Z^*\).
- Rebuilt items 1 and 2 of the proof as source-style numbered prose instead of generated enumerate scaffolding.
- Restored the direct-sum display \(\mathfrak M=\{\mathfrak Z u_E,\ldots,\mathfrak Z u_T\}\) and the proof that it equals \(\mathfrak R_r\).
- Corrected item 3’s associativity law to use \(a_{S,T}^{R^{-1}}\).
- Removed a catastrophic repeated \(\mathfrak Z^*\) garbage line and replaced it with the source sentence that \(a_{S,T}\in\mathfrak Z^*\), hence in \(\mathfrak Z\) and nonzero.
- Rebuilt the item 3 associativity calculation as a single aligned display.
- Restored the visible start of item 4 through \(\mathfrak M=\mathfrak Z u_E+\cdots+\mathfrak Z u_T\) and the defining relations.

Open: p756 onward remains open.  The next page continues item 4 after the defining relations and should be opened against source before patching.

## 2026-06-25 - R125+ Local Codex Tail p747-p756 §27 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p756_BrauerSchurSection27Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p755 package.  The cumulative German TeX was patched through source p756 and rebuilt successfully with XeLaTeX.  `pdfinfo` reports 466 pages for the rebuilt PDF.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`
- `Noether_Deuring_collected_p753_seq43.png`
- `Noether_Deuring_collected_p754_seq44.png`
- `Noether_Deuring_collected_p755_seq45.png`
- `Noether_Deuring_collected_p756_seq46.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p756 repairs:

- Restored the item 4 continuation after the defining relations, including the parenthetical associativity-condition sentence and the two source subconditions.
- Restored Umkehrsatz 2 with \(\mathfrak Z\cdot\mathfrak G\), \(P\) as center, and the R. Brauer parenthetical.
- Rebuilt Hilfssatz 1 and its proof with \(w=\sum c_{\lambda_S}u_S\), coefficient comparison, and conclusion \(w\in\mathfrak Z\).
- Rebuilt Hilfssatz 2 with the \(\mathfrak Z\)-Doppelmodul statement, the isomorphism with \(\mathfrak Z u_S\), and the proof via \(a=u_Sw\).
- Rebuilt Hilfssatz 3 with \(\mathfrak Z\cdot\mathfrak G\), \(\mathfrak M=\sum\mathfrak A_{S_i}\), and the conclusion that the summands are identical with \(\mathfrak Z u_{S_i}\).
- Restored Hilfssatz 4's ring/subring statement: \(\mathfrak Z\)-containing rings from \(\mathfrak Z\cdot\mathfrak G\) are two-sided simple, and \(\mathfrak Z\)-containing subrings correspond to subgroups of \(\mathfrak G\).
- Rebuilt the start of the Hilfssatz 4 proof through the bottom of p756.

Open: p757 onward remains open.  It continues immediately after `... \(\mathfrak Z\)-Doppelmodul und`.

## 2026-06-25 - R125+ Local Codex Tail p747-p757 §27/§28 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p757_BrauerSchurSection27_28Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p756 package.  The cumulative German TeX was patched through source p757 and rebuilt successfully with XeLaTeX.  `pdfinfo` reports 466 pages for the rebuilt PDF.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`
- `Noether_Deuring_collected_p753_seq43.png`
- `Noether_Deuring_collected_p754_seq44.png`
- `Noether_Deuring_collected_p755_seq45.png`
- `Noether_Deuring_collected_p756_seq46.png`
- `Noether_Deuring_collected_p757_seq47.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p757 repairs:

- Closed the Hilfssatz 4 proof continuation with \(\mathfrak o\), \(\mathfrak Z\), and \(\mathfrak H\) notation restored.
- Rebuilt Hilfssatz 5 and its proof: \(P\) is the center of \(\mathfrak Z\cdot\mathfrak G\), with \(wu_S=u_Sw^S\) and \(w\in P\).
- Rebuilt Bemerkung 1, including the infinite algebraic Galois-field case and the finite-sum description \(\sum u_{S_i}\cdot c_{S_i}\).
- Rebuilt Bemerkung 2, including the crossed matrix representation and the index \(t\) of \(\mathfrak R\).
- Rebuilt the source-style §28 opening display for \(\mathfrak R_r=\mathfrak Z\cdot\mathfrak G\), the overlined crossed product, and the product setup.
- Restored the Behauptung \(\tilde c_{S,T}=\tilde a_{S,T}\tilde b_{S,T}\).
- Restored Satz 1's statement with \(\mathfrak I\), \(\mathfrak R_{rs}=\mathfrak R_r\times P_s\), and \(\mathfrak R_r\).

Open: p758 onward remains open.  It begins with the Hilfssatz 1 proof body after `Der Beweis folgt aus den folgenden Hilfssätzen.`

## 2026-06-25 - R125+ Local Codex Tail p747-p758 §28 Repair

Package: `Noether_R125_LocalCodex_Tail_p747_p758_BrauerSchurSection28Repair_WebDrop_20260625.zip`

Status: supersedes the p747-p757 package.  The cumulative German TeX was patched through source p758 and rebuilt successfully with XeLaTeX.  `pdfinfo` reports 466 pages for the rebuilt PDF.

Source witnesses:

- `Noether_Deuring_collected_p747_seq37.png`
- `Noether_Deuring_collected_p748_seq38.png`
- `Noether_Deuring_collected_p749_seq39.png`
- `Noether_Deuring_collected_p750_seq40.png`
- `Noether_Deuring_collected_p751_seq41.png`
- `Noether_Deuring_collected_p752_seq42.png`
- `Noether_Deuring_collected_p753_seq43.png`
- `Noether_Deuring_collected_p754_seq44.png`
- `Noether_Deuring_collected_p755_seq45.png`
- `Noether_Deuring_collected_p756_seq46.png`
- `Noether_Deuring_collected_p757_seq47.png`
- `Noether_Deuring_collected_p758_seq48.png`

Source-quality caveat: these are native 360 ppi IA-derived collected-volume page images, below the 650 ppi project threshold.  This package is a best-available repair drop, not strict certification.

Confirmed p758 repairs:

- Rebuilt Hilfssatz 1 with \(\mathfrak R_{rs}\), \(\mathfrak R_r\), \(\mathfrak Z\cdot\mathfrak G\), \(\mathfrak b\), and \(P_s\).
- Rebuilt Hilfssatz 2 with \(\mathfrak o\), \(\mathfrak l=\mathfrak o e_1\), and \(e_1\mathfrak o e_1\).
- Rebuilt Hilfssatz 3 with \(P_s=\sum_1^s c_{ik}P\), \(\mathfrak b=c_{11}P+\cdots+c_{s1}P\), and \(\mathfrak R_r c_{11}\).
- Rebuilt the step 2 decomposition of \(\mathfrak R_r\times\overline{\mathfrak R}_r\) into link ideals of absolute length \(n\).
- Rebuilt step 3 and the Satz 2 statement, including \(\mathfrak A=\widetilde{\mathfrak Z}\cdot\widetilde{\mathfrak G}\), the \(e_1u_S\bar u_Se_1\) representatives, and \(\tilde b_{S,T}=\bar b_{S,T}e_1\).

Open: p759 onward remains open.  It begins with the proof of Satz 2 after `Beweis. Es wird e_1 Einselement des Rings ...`.
## 2026-06-25 - R125+ local tail repair p759

- Continued the R125-based Deuring/Noether tail package from the previous p747-p758 web drop and created the p747-p759 candidate package.
- Source authority used: `Noether_Deuring_collected_p759_seq49.png`, a native 360 ppi IA-derived collected-volume page image. This is still below the project strict 650 ppi threshold, so the result remains best-available repair work rather than strict high-resolution certification.
- Rebuilt the p759 continuation of §28 from source: Satz 2 proof opening; footnote 1; Hilfssatz 1 including footnote 2; Hilfssatz 2; Hilfssatz 3; item 4 product formula for associated classes; item 5 on \(\{a\}^t\) and irreducible crossed representation degree \(t\); and item 6 through the correspondence of unit classes.
- Compiled `cum_de_R125_plus_localcodex_tail_p713_p759_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages.
- Preserved the p747-p758 baseline as `provenance/pre_p759_patch_p747_p758_candidate.tex` and `.pdf`, and generated `audit/p758_to_p759_tail_repair.diff`.
- Added `audit/p759_confirmed_fixes.csv`, updated `audit/source_quality.csv`, and moved the open continuation marker to p760 onward.

## 2026-06-25 - R125+ local tail repair p760

- Continued the R125-based Deuring/Noether tail package from p747-p759 and created the p747-p760 candidate package.
- Source authority used: `Noether_Deuring_collected_p760_seq50.png`, a native 360 ppi IA-derived collected-volume page image. This is still below the project strict 650 ppi threshold, so the result remains best-available repair work rather than strict high-resolution certification.
- Rebuilt p760 from source: the §28 closing sentence; §29 heading and setup; definition of the Hauptgeschlecht im Minimalen; the §29 Satz and proof; the §30 opening; Satz 1; the normierte Darstellung definition; and Hilfssatz 1 statement.
- Compiled `cum_de_R125_plus_localcodex_tail_p713_p760_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages.
- Preserved the p747-p759 baseline as `provenance/pre_p760_patch_p747_p759_candidate.tex` and `.pdf`, and generated `audit/p759_to_p760_tail_repair.diff`.
- Added `audit/p760_confirmed_fixes.csv`, updated `audit/source_quality.csv`, and moved the open continuation marker to p761 onward.

## 2026-06-25 - R125+ local tail repair p761

- Continued the R125-based Deuring/Noether tail package from p747-p760 and created the p747-p761 candidate package.
- Source authority used: `Noether_Deuring_collected_p761_seq51.png`, a native 360 ppi IA-derived collected-volume page image. This is still below the project strict 650 ppi threshold, so the result remains best-available repair work rather than strict high-resolution certification.
- Rebuilt p761 from source: Hilfssatz 1 proof; Hilfssatz 2 and proof; Hilfssatz 3 statement and proof; the normed factor-system multiplication display; the \(v=uc\) transformation calculation; the \(aN(c)\) class conclusion; Satz 2 statement; and the first line of its proof through the p761 page boundary.
- Compiled `cum_de_R125_plus_localcodex_tail_p713_p761_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages.
- Preserved the p747-p760 baseline as `provenance/pre_p761_patch_p747_p760_candidate.tex` and `.pdf`, and generated `audit/p760_to_p761_tail_repair.diff`.
- Added `audit/p761_confirmed_fixes.csv`, updated `audit/source_quality.csv`, and moved the open continuation marker to p762 onward.

## 2026-06-25 - R125+ local tail repair p762

- Continued the R125-based Deuring/Noether tail package from p747-p761 and created the p747-p762 candidate package.
- Source authority used: `Noether_Deuring_collected_p762_seq52.png`, a native 360 ppi IA-derived collected-volume page image. This is still below the project strict 650 ppi threshold, so the result remains best-available repair work rather than strict high-resolution certification.
- Rebuilt p762 from source: close of Satz 2 proof; the Hauptgeschlecht/Geschlechtergruppe remark; §31 opening; finite-field application; quaternion application and normal form; and the opening of “Bemerkung zu 1” through the source-page cutoff.
- Compiled `cum_de_R125_plus_localcodex_tail_p713_p762_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages.
- Preserved the p747-p761 baseline as `provenance/pre_p762_patch_p747_p761_candidate.tex` and `.pdf`, and generated `audit/p761_to_p762_tail_repair.diff`.
- Added `audit/p762_confirmed_fixes.csv`, updated `audit/source_quality.csv`, and moved the open continuation marker to p763 onward.

## 2026-06-25 - R125+ local tail repair p763

- Continued the R125-based Deuring/Noether tail package from p747-p762 and created the p747-p763 candidate package.
- Source authority used: `Noether_Deuring_collected_p763_seq53.png`, a native 360 ppi IA-derived collected-volume page image. This is still below the project strict 650 ppi threshold, so the result remains best-available repair work rather than strict high-resolution certification.
- Rebuilt p763 from source: closed “Bemerkung zu 1”; rebuilt application 3 for \(p\)-adic \(P\) and cyclic \(\mathfrak Z\); corrected \(P^*/N\mathfrak Z^*\cong\mathfrak G\); rebuilt “Bemerkung zu 3”; and restored the final two facts plus closing sentence of the Deuring/Noether note.
- Compiled `cum_de_R125_plus_localcodex_tail_p713_p763_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages.
- Preserved the p747-p762 baseline as `provenance/pre_p763_patch_p747_p762_candidate.tex` and `.pdf`, and generated `audit/p762_to_p763_tail_repair.diff`.
- Added `audit/p763_confirmed_fixes.csv`, updated `audit/source_quality.csv`, and recorded the boundary: the following Kapferer/Noether paper remains outside this source-witness span.

## 2026-06-25 - R125+ Kapferer/Noether p559 repair

- Took the R125 cumulative plus the local Codex p747-p763 Deuring/Noether tail repairs as the baseline and began the next paper: H. Kapferer, with a supplement jointly with E. Noether, `Notwendige und hinreichende Multiplizitaetsbedingungen zum Noetherschen Fundamentalsatz der algebraischen Funktionen`, Math. Ann. 97 (1927), pp. 559-567.
- Source authority used: `Kapferer_Noether_MathAnn97_canvas00000565_full.jpg`, the best staged local GDZ raw page image for p559, approximately 400 dpi. Earlier checking found a HADW/MATH lead weaker at about 240 dpi. This is therefore best-available repair work, not strict 650+ dpi certification.
- Rebuilt p559 from source: title/byline/supplement/source metadata; opening paragraph and footnotes 1-3; Satz Ia; and the opening of Satz Ib through the definitions of \(\mathfrak q\), \(\mathfrak q_i\), the \(s\) zeroes, and \(x=\alpha_i,\ y=\beta_i\).
- Compiled `cum_de_R125_plus_localcodex_tail_plus_kapferer_p559_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages and the second compile log has no fatal errors or warnings of the project-relevant kinds checked.
- Preserved the pre-Kapferer p747-p763 baseline as `provenance/pre_kapferer_p559_patch_p747_p763_candidate.tex` and `.pdf`, and generated `audit/p763_to_kapferer_p559_repair.diff`.
- Added `audit/kapferer_p559_confirmed_fixes.csv`, updated `audit/source_quality.csv`, and moved the active Kapferer/Noether continuation marker to Math. Ann. p560 / GDZ canvas 566 onward.

## 2026-06-25 - R126+ Kapferer/Noether p559-p560 rebase

- Detected new web drop `Noether_R126_20260625.zip`. R126 integrated the local Deuring/Noether tail repairs through collected pp. 747-763 and explicitly left Kapferer/post-763 material as the next non-duplicate tranche.
- Rebasing decision: the earlier R125-based Kapferer p559 package remains superseded by an R126-based package, because web R126 is now the active baseline.
- Source authority used for Kapferer/Noether: GDZ raw full-page images `Kapferer_Noether_MathAnn97_canvas00000565_full.jpg` and `Kapferer_Noether_MathAnn97_canvas00000566_full.jpg`, approximately 400 dpi. This remains below the project 650 ppi strict-certification threshold but is the best staged local source; HADW/MATH lead checked weaker at about 240 dpi.
- Rebuilt Kapferer/Noether source pp. 559-560 against R126: title/byline/source metadata; opening paragraph and notes 1-4; Satz Ia; Satz Ib; simultaneous congruences; Max Noether historical paragraph; \(K=\lambda\cdot\varphi+\mu\cdot\psi\); Reduktion footnote; sufficient condition paragraph; and \(K\equiv0(\mathfrak p^\varrho)\) special-case conclusion.
- Compiled `cum_de_R126_plus_localcodex_kapferer_p559_p560_candidate_20260625.tex` twice with XeLaTeX; resulting PDF reports 466 pages and the second compile log has no fatal errors or warnings in the checked classes.
- Preserved untouched R126 as `provenance/pre_kapferer_p559_p560_patch_cum_de_R126.tex` and `.pdf`, generated `audit/R126_to_kapferer_p559_p560_repair.diff`, and kept the original `Noether_R126_20260625.zip` in provenance for web-session lineage.

## 2026-06-25 - R126 Kapferer/Noether p559-p561 local repair package

- Baseline: newest web drop `Noether_R126_20260625.zip` / `cum_de_R126.tex`.
- Continued from local R126 p559-p560 repair and source-checked Math. Ann. 97 p561 against GDZ raw full-page witness `Kapferer_Noether_MathAnn97_canvas00000567_full.jpg`.
- Source-quality caveat: GDZ witness is the best local staged image but only approximately 400 dpi; below the 650 ppi strict floor. No low-resolution crop was used for certification.
- Confirmed p561 fixes: restored Satz II statement, multiplicity sum, footnote 7, displayed system (1), corrected first-row exponent from OCR `y^{(g_2)}` to source `y^{(g_1)}`, and restored recurrence prose through the end of p561.
- Built active candidate `tex/cum_de_R126_plus_localcodex_kapferer_p559_p561_candidate_20260625.tex`; XeLaTeX pass 1 and pass 2 both succeeded. Pass 2 log scan found no fatal errors, emergency stops, undefined controls, rerun warnings, overfull/underfull boxes, or missing-character reports.
- Next open Kapferer page: Math. Ann. p562 / GDZ canvas 568. Later Kapferer text remains provisional/OCR-derived until source-audited.

## 2026-06-25 - R126 Kapferer/Noether p562 local repair package

- Continued from the p559-p561 local candidate and source-checked Math. Ann. 97 p562 against GDZ raw full-page witness `Kapferer_Noether_MathAnn97_canvas00000568_full.jpg`.
- Source-quality caveat: best local staged witness remains approximately 400 dpi, below the 650 ppi strict floor. No low-resolution crop was used as source authority.
- Confirmed p562 fixes: restored Hilfssatz I; restored formula (2) as a tagged display instead of a bogus enumerate item; rebuilt display (3); corrected recurrence targets to `x\cdot K_2`, `x\cdot K_3`, ..., `x\cdot K_{r+1}`; corrected OCR `K_8` to source `K_3`; restored Hilfssatz II and footnote 8 through the p562 page boundary.
- A temporary 4x enlargement from the same GDZ pixels was used only to read display (3) subscripts; it is not treated as high-resolution certification.
- Built active candidate `tex/cum_de_R126_plus_localcodex_kapferer_p559_p562_candidate_20260625.tex`; XeLaTeX pass 1 and pass 2 both succeeded. Pass 2 log scan found no fatal errors, emergency stops, undefined controls, rerun warnings, overfull/underfull boxes, or missing-character reports.
- Next open Kapferer page: Math. Ann. p563 / GDZ canvas 569. The continuation sentence after `gemäß` remains open for p563 rather than guessed across the page turn.

## 2026-06-25 - R126 Kapferer/Noether p563 local repair package

- Continued from the p559-p562 local candidate and source-checked Math. Ann. 97 p563 against GDZ raw full-page witness `Kapferer_Noether_MathAnn97_canvas00000569_full.jpg`.
- Source-quality caveat: best local staged witness remains approximately 400 dpi, below the 650 ppi strict floor.
- Confirmed p563 fixes: closed the p562 Hilfssatz II continuation; restored `q^{(t+1)}`, `K_{t+1}\equiv0(q^{(t+1)})`, and the `t`-fold proof; restored Zusatz I/II with footnotes 9-10; restored `\rho`, Bertini's formula reference, the example `\varphi=x^3+y^4; \psi=x^2+y^3`; rebuilt Satz III with `\varphi,\psi,K` notation and source multiplicity condition.
- Built active candidate `tex/cum_de_R126_plus_localcodex_kapferer_p559_p563_candidate_20260625.tex`; XeLaTeX pass 1 and pass 2 both succeeded. Pass 2 log scan found no fatal errors, emergency stops, undefined controls, rerun warnings, overfull/underfull boxes, or missing-character reports.
- Next open Kapferer page: Math. Ann. p564 / GDZ canvas 570.

## 2026-06-25 - R126 Kapferer/Noether p564 local repair package

- Continued from the p559-p563 local candidate and source-checked Math. Ann. 97 p564 against GDZ raw full-page witness `Kapferer_Noether_MathAnn97_canvas00000570_full.jpg`.
- Source-quality caveat: best local staged witness remains approximately 400 dpi, below the 650 ppi strict floor.
- Confirmed p564 fixes: restored the differentiation-based comment on Satz III, Kapferer 1923 footnote, formula for `A'`, the homogeneous three-variable Zusatz with Ostrowski footnote, the E. Noether appendix heading and footnote, and the opening paragraph on full residue systems modulo `q` and `\mu` as ideal length.
- Built active candidate `tex/cum_de_R126_plus_localcodex_kapferer_p559_p564_candidate_20260625.tex`; XeLaTeX pass 1 and pass 2 both succeeded. Pass 2 log scan found no fatal errors, emergency stops, undefined controls, rerun warnings, overfull/underfull boxes, or missing-character reports.
- Next open Kapferer page: Math. Ann. p565 / GDZ canvas 571. The final p564 sentence continues at p565.

## 2026-06-25 - R126 Kapferer/Noether p565 local repair package

- Continued from the p559-p564 local candidate and source-checked Math. Ann. 97 p565 against GDZ raw full-page witness `Kapferer_Noether_MathAnn97_canvas00000571_full.jpg`.
- Source-quality caveat: best local staged witness remains approximately 400 dpi, below the 650 ppi strict floor.
- Confirmed p565 fixes: restored the p564 continuation and footnote 14; restored Satz IV's full residue system list; restored relations (4) and (5); restored proof skeleton for (4)/(5), including the noncongruence `g_i(0,y):y^{(g_i)}\not\equiv0(y)` and common-factor observation `f_i=d_i(y)\bar f_i`, `g_i=d_i(y)\bar g_i`.
- Built active candidate `tex/cum_de_R126_plus_localcodex_kapferer_p559_p565_candidate_20260625.tex`; XeLaTeX pass 1 and pass 2 both succeeded. Pass 2 log scan found no fatal errors, emergency stops, undefined controls, rerun warnings, overfull/underfull boxes, or missing-character reports.
- Next open Kapferer page: Math. Ann. p566 / GDZ canvas 572; p565 ends mid-sentence at `für jedes`.
## 2026-06-25 12:20 - R126 Kapferer/Noether Math. Ann. 97 pp. 566-567 completed from best staged GDZ witnesses

- Checked for newer Rob/web Noether drops before continuing. No `R127`/newer drop was staged locally; current authority remains `Noether_R126_20260625.zip`.
- Continued the R126 Kapferer/Noether repair package from p559-p565 to the article end, using:
  - `Kapferer_Noether_MathAnn97_canvas00000572_full.jpg` for Math. Ann. 97 p566.
  - `Kapferer_Noether_MathAnn97_canvas00000573_full.jpg` for Math. Ann. 97 p567.
- Source-quality caveat remains loud: these are the best staged local GDZ raw full-page witnesses, approximately 400 dpi, below the 650+ dpi strict-certification floor. They are acceptable as best-available repairs, not strict recertification.
- Replaced the inherited R126 OCR tail beginning at `\(\sigma \geq \varrho\)` through the received date. Confirmed repairs include:
  - plain source \(q^{(i)}\) restored where OCR drift had changed it to \(\mathfrak q^{(i)}\);
  - product \(P=\prod((x-\gamma_j)+u(y-\delta_j))^{\tau_j}\) and \(G(x,y)\) construction restored;
  - identities for \(h_iF(y)G\) and \(h_ix\) restored;
  - proof of (5) restored;
  - Bemerkung I, relation (6), and footnotes 15-16 restored as TeX rather than orphaned OCR numbered lines;
  - Zusatz I restored as \(q:x^t=q^{(t+1)}\), with \(q:x^{t-1}=q^{(t)}\);
  - Bemerkung II restored, including \((K,q^{(i)})=(h_iy^\lambda,q^{(i)})\), \(y^{(g_i)-\lambda}K\equiv0(q^{(i)})\), and \(\lambda=(K)\);
  - received date restored.
- Active candidate:
  - `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R126_LocalCodex_KapfererNoether_MathAnn97_p559_p567_Complete_WebDrop_20260625\tex\cum_de_R126_plus_localcodex_kapferer_p559_p567_complete_candidate_20260625.tex`
- XeLaTeX run twice; second-pass log showed no fatal errors, emergency stops, undefined control sequences, rerun warnings, overfull/underfull boxes, duplicate destinations, or missing-character reports. PDF page count remains 466.
- Package status: Kapferer/Noether Math. Ann. 97 pp. 559-567 are now covered pagewise in the local candidate. Remaining caveat is source resolution only.

## 2026-06-25 12:31 - R126 + Kapferer complete candidate, P20 absolute irreducibility bar repair

- Checked for a newer local Rob/Noether drop after the user mentioned one. No newer Noether production ZIP after `Noether_R126_20260625.zip` was found in the Noether lane, Edge dump, recent attachments, or recent `Papors` sweep. Fresh activity existed in SGA/Weber/repo bookkeeping, not a Noether R127/R128 baseline.
- Baseline for this P20 drop: `cum_de_R126_plus_localcodex_kapferer_p559_p567_complete_candidate_20260625.tex`, so the new output carries forward the already completed Kapferer/Noether Math. Ann. 97 pp. 559-567 repair.
- Source authority used for P20: staged GDZ full-page witnesses for Math. Ann. 85 printed pp. 32-33:
  - `P20_seq007_printed32_canvas00000042_full.jpg`, 3093x4773, staged as 600 ppi.
  - `P20_seq008_printed33_canvas00000043_full.jpg`, 3058x4943, staged as 600 ppi.
- Source-quality caveat: these are best staged witnesses for the loci, but 600 ppi is below the project's stricter 650 ppi preference. I limited changes to visually obvious bar/dot omissions and did not treat the pass as global P20 certification.
- Confirmed and applied four source-visible P20 fixes:
  - p32: `solcher speziellen $H(x)$ oder allgemeinen $H(x,y)$` -> `solcher speziellen $\bar H(x)$ oder allgemeinen $\bar H(x,y)$`.
  - p32: `Graderniedrigung von $H(x)$` -> `Graderniedrigung von $\bar H(x)$`.
  - p33: `Zerfallen von $E(x)$ beziehungsweise $E(x,y)$` -> `Zerfallen von $\bar E(x)$ beziehungsweise $\bar E(x,y)$`.
  - p33: `kann $E(x)$ durch $\Delta\bar E(x)$ ersetzt werden` -> `kann $\bar E(x)$ durch $\Delta\cdot\bar E(x)$ ersetzt werden`.
- Recorded a map issue: the local P20 `paper_tex_map.json` ended P20 at line 12673, but the actual TeX continues through line 12693 before Paper 21 starts at line 12696. The text was not omitted; the map was short.
- Active package:
  - `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Noether_R126_LocalCodex_P20_AbsoluteIrreduzibilitaet_BarRepair_WebDrop_20260625`
- Active candidate:
  - `tex/cum_de_R126_plus_localcodex_kapferer_p559_p567_plus_P20_barrepair_candidate_20260625.tex`
- XeLaTeX run twice; PDF page count remains 466. Fatal/error scan clean.

## 2026-06-25 12:55 - R126/Post-R126 rollup and P17/P18 survival checks

- User reported a new Rob-side thing. I rescanned the Noether lane, Edge dump, downloads, recent attachments, and broader `Papors` activity. The newest Noether baseline visible locally remains `Noether_R126_20260625.zip`; no `R127`, `R128`, or Rob-named newer Noether ZIP is staged.
- Read the R126 README/workbook/source-policy and the `07_prov` local tail layer. R126 itself already integrated Local Codex pp. 747-753 and extended the Deuring/Noether tail through p763 from best-available 360 ppi pages. Its open queue still treats pp711-746 and Kapferer/post-763 as work, but my local post-R126 candidate has since completed Kapferer/Noether Math. Ann. 97 pp. 559-567 and added the P20 bar repair.
- Reverified older targeted repairs in the active local cumulative:
  - P18 RA51: resultant display endpoint remains `R^{(n)}(x_n)\equiv 0(\mathfrak M)`.
  - P17 RA52: footnote markers/bodies 21 and 22 in formula (39) remain present.
  - P17 RA94: bogus centered `Fortsetzung zu 17...` scaffold remains absent.
  - P17 formula (40) no-fix anchors remain present.
  - P20 bar/dot repairs remain present.
- Created compact rollup package folder `Noether_R126_LocalCodex_PostR126_Rollup_P17_P18_Status_WebDrop_20260625` containing the active cumulative TeX/PDF, R126 queue/closure context, Kapferer and P20 fix ledgers, and new machine-readable survival/status CSVs. No bulk source-image dump was included.

## 2026-06-25 13:00 - P14/P15/P16 survival audit against current post-R126 cumulative

- User reported a new Rob-side thing. I rescanned the Noether lane and found no newer Noether baseline beyond `Noether_R126_20260625.zip`. Fresh live activity exists in the Weber audit lane, so I kept it separate and did not fold Weber material into Noether.
- Read prior source-critical ledgers:
  - P16 `Noether_P16_RA53_SourceCritical_Fix_WebDrop_20260614`
  - P15 `Noether_P15_RA54_SourceCritical_Fix_WebDrop_20260614`
  - P14 `Noether_P14_RA55_SourceCritical_Fix_WebDrop_20260614`
- Checked the current active cumulative `cum_de_R126_plus_Kapferer559_567_plus_P20_barrepair_current_20260625.tex` for survival of the earlier RA repairs and no-fix anchors. No new TeX patch was made.
- Confirmed current survival:
  - P16 RA53: the critical line reads `linear zusammensetzen aus $F$ und aus Formen aus $M$`; `\Omega`-Prozess, identity-in-`x,y`, identity-in-`\xi`, and `Berichtigungen` anchors are present.
  - P15 RA54: the Latin `x` index family in `\xi_{x_1,n-1}` survives, the `(n,n-1)\not\equiv0\pmod p` anchor is present, and Schur remains `S. 355`.
  - P14 RA55: `mod. ((z-c))` survives, the `\rho_1...\rho_\sigma` ideal factorization survives, and the polygon exponents remain `\calA\calN^\rho` / `\calB\calN^\sigma`.
- Source-quality caveat: these are survival checks of prior fixes. The RA53/RA54/RA55 source witnesses are useful best-available prior witnesses but do not give a fresh 650+ ppi global recertification of Papers 14-16.
- Created compact package folder `Noether_R126_LocalCodex_P14_P15_P16_SurvivalAudit_WebDrop_20260625` with active cumulative TeX/PDF, prior RA ledgers, and the new survival/source-quality CSVs.

## 2026-06-25 13:20 - P10/P11/P12/P13 survival and queue disposition updated to R126

- Continued the backward non-overlap audit from P14-P16 into P10-P13.
- Read and reused the older local evidence packages instead of duplicating work:
  - `Noether_R125_LocalCodex_P10_P12_QueueDisposition_WebDrop_20260625`
  - `Noether_R125_LocalCodex_Rebase_P13_P14_WebReturn_20260625`
  - `Noether_P09_P10_P11_RA56_SourceCritical_Fix_WebDrop_20260614`
  - `Noether_P12_P13_GDZ_RA48_SourceCritical_Fix_WebDrop_20260614`
- Checked the active R126+Kapferer+P20 cumulative for survival of the older P10-P13 anchors. No new TeX patch was made.
- Confirmed in the active current TeX:
  - P10: author line, `\Jdom`, `k_\sigma`, `F(t;\vartheta_i)`, and explicit `i\cdot` display-dot survive.
  - P11: author comma, `\Omega_\Gamma`, `\varphi_3(x)=w\cdot u/v`, and final semicolon survive. A later lowercase `\mathfrak l_\Gamma` occurs in the Deuring tail and is not the old P11 `\mathfrak L_\Gamma` defect.
  - P12: section/front-matter, `f(x;dx)`, `d\delta x`, and `\bdelta x` anchors survive.
  - P13: Klein dedication, author line, `endgiltige`, Lie `Grundlagen` citation note, `x_\kappa`, dense Klein/Einstein formula anchors, and p256 no-second-summation fix survive.
- Source-quality caveat: this is a current-cumulative survival/queue-disposition pass. It does not replace the need for higher-resolution recheck if better witnesses appear, especially P11.
- Created compact package folder `Noether_R126_LocalCodex_P10_P13_SurvivalQueueDisposition_WebDrop_20260625` with current cumulative TeX/PDF, prior ledgers, and new R126 survival/source-quality CSVs.

## 2026-06-25 13:55 - P09 survival and queue disposition updated to R126

- Continued the backward non-overlap audit below P10 into P09, using the active cumulative `cum_de_R126_plus_Kapferer559_567_plus_P20_barrepair_current_20260625.tex`.
- Source status: staged P09 source remains GDZ Math. Ann. 77 pp. 103-128 with mixed native 400/600 ppi full-page witnesses. Existing targeted crops for the known hard loci are 1000 dpi. This pass is therefore exact-locus survival / queue disposition, not strict full-page 650+ certification.
- Visually reopened the targeted P09 source witnesses:
  - p103 front matter confirms the printed author line `Von / Emmy Noether in Erlangen`.
  - p103 Zermelo footnote confirms `Math. Ann. 75, S. 484 (1914)`.
  - p119 indexed-relation crop confirms the classification line uses `z=\varphi(\xi_1\cdots\xi_t)`; current R126 keeps this at lines 7155-7156.
  - p119 full-page context also confirms a separate later induction sentence legitimately uses compact `z=\varphi(\xi)`, so that is a no-patch trap rather than a regression.
  - p125 formula crops confirm the multiplicative module subscripts `\mathfrak M_{\nu\kappa}`, `\mathfrak M_{\nu\kappa+1}`, and `\mathfrak M_{2\nu\kappa}`.
  - p127 context confirms the source uses capital Greek `\Omega` for the arbitrary field in the definition paragraphs; current R126 keeps the prior Omega fix.
- No new TeX patch was made. The suspicious p119 `z=\varphi(\xi)` hit was resolved by source context as a separate correct sentence.
- Created compact package folder `Noether_R126_LocalCodex_P09_SurvivalQueueDisposition_WebDrop_20260625` with current cumulative TeX/PDF, extracted P09 span, targeted 1000-dpi witnesses, prior ledgers, and new R126 survival/source-quality CSVs.

## 2026-06-25 14:25 - P08 Omega-process repair on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit below P09 into P08, using a staged copy of the active cumulative `cum_de_R126_plus_Kapferer559_567_plus_P20_barrepair_current_20260625.tex`.
- Read the older P08 targeted audit drop and witness manifest from `Noether_Source_Files_Addendum_20260616`.
- Verified at 1000 dpi:
  - p97 source has `\lambda_1=(zy)`, so current `f[x,y,(zy)x+(xz)y]=(xy)^p f(x,y,z)` is correct and the old `(xy)x` defect remains fixed.
  - p98 source has the operator in `\lambda`, so current `\partial/\partial\lambda` is correct and the old first-argument defect remains fixed.
  - p100 source has the Omega differential equation with a middle equality and the `*)` source marker at the displayed equation.
- Applied one source-certain P08 patch in the staged cumulative:
  - Restored the middle equality in the Omega equation:
    `\Delta(\partial_x,\partial_y,\partial_z)h(x,y,z)=(\partial_x\partial_y\partial_z)h(x,y,z)=0`.
  - Moved the already-present note body from a later `\NoetherSrcNote` into source-style `\srcfnmark{*)}` / `\srcfntext{*)}` attached to the displayed Omega equation.
- No other P08 TeX changes were made. P08 p93-p96 source-note markers already survive via `\NoetherSrcNote` or explicit `\srcfnmark/\srcfntext`.
- XeLaTeX run twice on the patched cumulative; output PDF has 466 pages and no fatal errors/emergency stops/undefined-control-sequence failures.
- Created package folder `Noether_R126_LocalCodex_P08_OmegaRepair_WebDrop_20260625` with patched cumulative TeX/PDF/log, exact diff, P08 span extract, prior P08 ledgers, 1000-dpi source witnesses, and machine-readable dispositions.
- Scope caveat: this is an exact-locus P08 repair/survival package, not a fresh line-by-line global P08 certification.

## 2026-06-25 15:05 - P07 targeted survival audit on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit below P08 into P07, using the P08-patched current cumulative `cum_de_R126_plus_Kapferer559_567_plus_P20_barrepair_plus_P08_omega_current_20260625.tex`.
- Read the older P07 targeted request ledger `fe0737df1c925edf_p07_fix_requests_and_dispositions.csv` and witness manifest `6428092ab50e4904_p07_witness_manifest.csv`.
- Located current P07 at TeX lines 5831-5945. All six old `fix_requested` rows concern visible symbolic footnote markers. The current cumulative already uses `\NoetherSrcNote{*)}{...}` / `\NoetherSrcNote{**)}{...}` at those loci; this macro renders explicit symbolic, unnumbered source notes, not ordinary numbered footnotes.
- Reconfirmed the two no-fix formula traps:
  - p90 Galois resolvent display remains unchanged.
  - p91 Weber derivative correction formula remains unchanged.
- Generated a new 1000dpi p91 crop from the GDZ article PDF because the previous labelled p91 witness was only 650dpi and the derivative block is formula-dense. Temporary 120dpi page-map preview and full-page render were removed from the deliverable.
- No TeX change was made. Package folder: `Noether_R126_LocalCodex_P07_SurvivalAudit_WebDrop_20260625`.
- Scope caveat: this is a targeted survival audit of old P07 requests, not a full fresh glyph-by-glyph certification of all P07 prose.

## 2026-06-25 15:40 - P06 targeted survival audit on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit into Paper 06, using the P08-patched current cumulative `cum_de_R126_plus_Kapferer559_567_plus_P20_barrepair_plus_P08_omega_current_20260625.tex`.
- Important numbering note: current Paper 5 begins at line 4510; Paper 06, `Körper und Systeme rationaler Funktionen`, begins at line 4551 and ends at line 5825.
- Current P06 span has 0 ordinary `\footnote` calls, 34 `\srcfn` calls, 1 `\srcfnmark`, 1 `\srcfntext`, and 0 `\NoetherSrcNote` calls.
- Re-read the prior P06 request/source-marker/symbol ledgers from the Noether source addendum, including RA45, RA46, RA47, RA49, and RA67 checks.
- Confirmed the known RA67 source-marker repairs survived in the current cumulative. Confirmed representative RA45/RA46/RA47/RA49 hard anchors survived, including the p191 formulas, p193-p195 evidence anchors, p196 final identity, and the Mertens source-note apparatus.
- Reopened the p196 source witness at 650dpi for the date/final-example trap. The source reads `Erlangen, Mai 1914.`; no date patch is warranted. The earlier `23. Juli 1915` suspicion is cross-context and should not be propagated.
- No TeX change was made. Package folder: `Noether_R126_LocalCodex_P06_SurvivalAudit_WebDrop_20260625`.
- Scope caveat: this is a targeted survival audit of old P06 hard loci and source-note repairs, not a fresh glyph-by-glyph certification of every P06 line.

## 2026-06-25 16:05 - P05 targeted survival audit on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit below P06 into Paper 05, `Rationale Funktionenkörper`.
- Checked current P05 span at TeX lines 4510-4547 in the P08-patched cumulative.
- Read the prior RA42 P05 source-audit request and the RA80 P02-P05 footnote-reset ledger from the Noether source addendum.
- Visually reopened the P05 650dpi labelled hard-locus witnesses for source pp. 316, 318, and 319. The p316 footnote crop confirms source footnotes 1 and 2; the p318 display crop confirms the linear form display and source note; the p319 crop confirms the closing paragraph and `je n Polynomen` trap.
- Confirmed the old P05 defect is closed in the current cumulative: the title note is present as `\srcfn{1)}` and the Steinitz note is present as `\srcfn{2)}`. The old inherited-footnote-numbering issue is no longer active.
- No TeX change was made. Package folder: `Noether_R126_LocalCodex_P05_SurvivalAudit_WebDrop_20260625`.
- Scope caveat: local P05 GDZ raw-page metadata says 600ppi, while the exact hard-locus crops are labelled 650dpi. This is a targeted queue-closure/survival pass, not a fresh line-by-line P05 certification.

## 2026-06-25 16:25 - P04 RA64 survival audit on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit below P05 into Paper 04, `Zur Invariantentheorie der Formen von n Variabeln`.
- Read the prior RA64 source-critical fix package and no-new-patch traps.
- Located the RA64 hard anchor in the current P08-patched cumulative at line 4477: `\section*{\S\ 9. Formenreihen. Reduktionss\"atze\srcfn{*)}{...}.}`.
- Opened the full p152 source page at 1000dpi. It confirms both the heading star after `Reduktionssätze` and the `*)` note text `Vgl. die entsprechenden Betrachtungen im ternären Gebiete. Diss. §§ 1--3.`. It also confirms the following `**)` note structure.
- Important witness-quality note: the older labelled `P04_p152_heading_footnote_text_1000dpi_labelled.png` crop is poorly aimed and does not show the note body clearly. The full 1000dpi p152 page is the authority for this pass.
- Confirmed the RA64 no-patch traps survive in current TeX: p148 plain RHS products, p149 source-order special case, and p151 `q_{n-\sigma-\lambda},p_{\tau-\lambda}`.
- Corrected the package boundary after catching an overbroad extraction: the true current P04 span is lines 3560-4500, not lines 461-4500. The old broad span file was removed from the package before rebuilding.
- No TeX change was made. Package folder: `Noether_R126_LocalCodex_P04_RA64SurvivalAudit_WebDrop_20260625`.
- Scope caveat: this is a targeted RA64 survival audit, not a fresh full certification of the long P04 paper.

## 2026-06-25 17:05 - P03 RA57 survival audit on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit below P04 into Paper 03, `Zur Invariantentheorie der Formen von n Variabeln`.
- Important source-status correction: the old web note saying Paper 03 standalone source was not staged is stale. Local staged material includes the GDZ article PDF, four raw full-resolution GDZ page JPGs for printed pp. 101-104, and targeted 1000dpi inspection crops.
- Located current P03 span at TeX lines 3524-3557 in the P08-patched current cumulative.
- Reopened source witnesses:
  - p101 1000dpi witness confirms source title `Variabeln` and author line `Von Emmy Noether in Erlangen`.
  - p102 1000dpi witness confirms the symbolic product/Faltungen no-patch trap.
  - p103 raw GDZ page confirms formula (2) ends with `\rho=\sum_i\rho_i\le n`.
  - p104 1000dpi witness confirms the Noether ending/shared-page boundary before the Faber article.
- Found and fixed a witness-package problem, not a TeX problem: the older labelled p103 witness crop did not show the final `\rho\le n` line clearly enough, despite its manifest. Generated a fresh enlarged 1000dpi crop from raw GDZ p103 for that exact line.
- Confirmed the three RA57 fixes survive in current TeX: title `Variabeln`, author line present, and formula (2) `\rho_i\le n` line present.
- No TeX change was made. Package folder: `Noether_R126_LocalCodex_P03_RA57SurvivalAudit_WebDrop_20260625`.
- Scope caveat: best staged raw GDZ pages are native 600ppi, so this is targeted RA57 survival with 1000dpi enlarged hard-locus crops, not a fresh full P03 final certification under a native 650ppi source.

## 2026-06-25 17:40 - P02 RA65/RA80 survival audit on current R126/Post-R126 cumulative

- Continued the backward non-overlap audit below P03 into Paper 02, `Uber die Bildung des Formensystems der ternaren biquadratischen Form`.
- Located current P02 span at TeX lines 474-3523 in the P08-patched current cumulative.
- Confirmed the RA80 footnote reset survives: `\setcounter{footnote}{0}` is present immediately before P02 at line 461, and P03 resets again after P02 at line 3520.
- Re-read the prior P02 RA65/RA80 ledgers: final consolidation, table propagation, nu/v checks, no-patch traps, environment balance, tag inventory, and footnote-reset ledger.
- Rechecked targeted hard anchors:
  - p66 `L_j` / `L_j^2` contexts remain source-distinct no-patch traps.
  - p91 Table I row 21 keeps `(KH^3u)^6`.
  - p92 Table II rows 20-23 keep the RA65 exponent/operator corrections.
- Source-quality note: exact hard-locus table/body witnesses are 1000dpi labelled crops, with 650dpi full-page p91/p92 context renders. Embedded PNG metadata reports 72dpi on generated images, so the package records render intent plus pixel dimensions rather than trusting the tag.
- No TeX change was made. Package folder: `Noether_R126_LocalCodex_P02_RA65_RA80SurvivalAudit_WebDrop_20260625`.
- Scope caveat: this is a targeted RA65/RA80 survival audit of stale P02 questions, not a fresh full certification of all P02 prose, equations, notes, and two large tables.

## 2026-06-25 18:20 - P01 source recheck and cumulative repair

- Continued below P02 into Paper 01, `Uber die Bildung des Formensystems der ternaren biquadratischen Form`.
- Compared the active R126/Post-R126 cumulative against the locally available `Noether_Paper01_German_FINAL_AUDITED_slice.tex`, the RA14 scanfix, and the P01 source PDF.
- Rendered all four P01 source pages at 650dpi and created 1000dpi crops for the dense p177/p178 module/table anchors.
- Found two source-confirmed current cumulative defects and patched them in a new cumulative copy:
  - Removed the invented `Von Emmy Noether.` author line and restored source order: title, journal citation, then `(Auszug aus der Dissertation der Verfasserin.)`.
  - Changed table label `bzw. durch` to source `resp. durch`.
- Found that the local file named `Noether_Paper01_German_FINAL_AUDITED_slice.tex` is unsafe to copy wholesale: it has useful heading order, but it wrongly changes source `\nu(s)` to `\nu^{(s)}` and source `u_\varrho^2` to `u_\sigma^2`, and it uses a vertical-rule table format not visible in the source.
- Reconfirmed no-patch anchors from the 1000dpi crops: current source-correct `\nu(s)=(ss'u)^4...`, `u_\varrho^2`, module `(\varrho,t)`, and Pascal formula dot products.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages, and the second log grep found no fatal errors, emergency stops, undefined-control-sequence hits, undefined-reference warnings, or rerun warnings.
- Package folder: `Noether_R126_LocalCodex_P01_SourceRecheck_WebDrop_20260625`.

## 2026-06-25 19:05 - P30 GDZ0096 source-map package and source-quality correction

- Resumed the active Noether audit after the Weber/Rob interruption and returned to Paper 30, `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`.
- Used the local GDZ full-volume source `C:\Users\Floris\Documents\Papors\OS\PPN235181684_0096.pdf` as the best currently staged P30 witness.
- Built a fresh article cutout directly from the full volume: full-volume PDF pages 31--66, corresponding to printed pp. 26--61.
- Verified the cutout has 36 pages and visually spot-checked the opening page and final tail crop. The opening page shows the title/author and footnote start; the final crop shows the ending paragraph and `(Eingegangen am 13. 8. 1925.)`.
- Important source-quality correction: `pdfimages` reports the GDZ embedded images as 400 x 400 ppi CCITT. This package therefore does not claim strict 650-native certification. The 650dpi full-page witnesses and 1000dpi crops are rendered zoom aids from the best available 400ppi local source layer.
- Generated labelled 650dpi full-page context PNGs for printed p. 26 and pp. 58--61.
- Generated four labelled 1000dpi zoom crops for the dense/harder p. 58--61 tail.
- Recorded machine-readable ledgers:
  - `audit/p30_gdz0096_source_page_map.csv`
  - `audit/p30_source_quality_verdict.csv`
  - `audit/p30_target_crop_manifest.csv`
  - `audit/p30_visual_dispositions_and_no_patch_traps.csv`
  - `audit/p30_summary.json`
- No TeX patch was made in this P30 source-map package. The earlier RA72 opening/header/footnote-reset repair survives in the current local cumulative anchor; P30 begins at line 14456 and P31 begins at line 15663.
- Package folder: `Noether_R126_LocalCodex_P30_GDZ0096_SourceMap_WebDrop_20260625`.
- Next action: continue P30 sequential source-critical audit against this cutout, while still preferring a true 650+ native source if one appears.

## 2026-06-25 19:25 - P30 targeted tail audit, printed pp. 58--61

- Started actual P30 source-critical audit from the newly cut GDZ0096 article source, focusing first on printed pp. 58--61 because R126/R124 marked that tail as a recently repaired/hot area.
- `pdftotext` on the article cutout produced no usable text for pp. 58--61, so OCR was not used as evidence. The check was visual against labelled 1000dpi rendered crops and the 650dpi p61 full-page context.
- Checked p58 anchors around the `Doppelkettensatz -> Kompositionsreihe` proof, the `G_i/A_i` chains, and footnote 34; no TeX patch warranted.
- Checked p59 anchors around assumptions `\alpha`--`\varepsilon`, `2\alpha`, and the quotient-bar isomorphisms `G|B \simeq A|M` and `G|A \simeq B|M`; no TeX patch warranted. Notation note: the vertical quotient bar is source notation, so the current TeX `|` convention is correct here.
- Checked p60 anchors around the `(A,B,H)|(B,H)` isomorphism block, `C=[A,(B,H)]`, the `2\gamma` construction through `H`, and the `2\delta` opening; no TeX patch warranted.
- Checked p61 anchors around the `2\varepsilon` closing block, quotient chain in `G|C`, `eineindeutigen Entsprechens`, final equivalence sentence, and `(Eingegangen am 13. 8. 1925.)`; no TeX patch warranted.
- Recorded `audit/p30_tail_pp58_61_visual_audit.csv` in the P30 package folder.
- Caveat: this is a targeted hot-tail audit, not full P30 global certification. Best native local source remains 400ppi; rendered crops are zoom aids.

## 2026-06-25 21:18 - P11 full-page re-audit, pp. 221--229

- After the Weber/Rob B139 delta was packaged, resumed the Noether non-overlap lane and selected P11 because `source_queue_R126.csv` explicitly leaves P11 pp. 221--229 for complete full-page re-audit, excluding already accepted 1000ppi exact loci.
- Used the best staged P11 source witnesses:
  - article PDF `P11_GDZ_article_LOG_0015_pp221_229.pdf`;
  - raw GDZ IIIF full-resolution page JPGs for printed pp. 221--229;
  - existing exact-locus 1000ppi crops from the earlier P11 GDZ audit.
- Opened and visually checked every P11 source page pp. 221--229 against the current local cumulative TeX span lines 07869--08070.
- Confirmed survival of the old hot loci:
  - source-visible title/author handling;
  - `\Omega_\Gamma` in the invariant-field block;
  - formula (11) has plain `G_k`, not `G'_k`;
  - the Tschirnhaus footnote keeps the source-visible coefficients, including the suspicious repeated `a_2^3/a_3^2`;
  - final theorem punctuation and `Göttingen, Juli 1916.` closing survive.
- Found no new source-certain TeX patch. The current cumulative TeX/PDF anchors are unchanged by this P11 pass.
- Recorded:
  - `audit/P11_fullpage_reaudit_R126_20260625.csv`;
  - `audit/P11_source_quality_verdict_20260625.csv`;
  - `audit/P11_summary_20260625.json`.
- Caveat: this is a visual full-page re-audit against the best local GDZ page images, not an independent OCR/symbol-level machine certification. The 1000ppi crops are zoom witnesses from the raw GDZ source, not separate native 1000ppi scans.

## 2026-06-25 21:35 - P12 full-page re-audit, pp. 37--44

- Continued the R126 source queue to Paper 12, `Invarianten beliebiger Differentialausdruecke`, printed pp. 37--44.
- Used the best staged P12 full-page witnesses: GDZ raw JPGs for pp. 37--44 at 2296 x 3688 px, plus the earlier labelled 1000ppi exact-locus crops for the known hard P12 spots.
- Re-read the prior P12 ledgers before touching the TeX, especially the old traps around formula (9), which must remain plain `\delta x`, and the p40 barred-delta repairs, which must not be propagated blindly.
- Confirmed that the current cumulative already contains the earlier source-backed P12 fixes:
  - original author line and initial `f(x;dx)`;
  - `d\delta x` higher-differential loci;
  - barred-delta parentheticals around formulas (5)--(7);
  - formula (9) plain `\delta x` no-fix trap;
  - final Math. Annalen notice.
- Found one new source-certain prose defect and patched it in the package cumulative:
  - printed p. 43 / current line around 08443: `aller analytischer Transformationen` -> source `aller analytischen Transformationen`.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages.
- Recorded:
  - `audit/P12_fullpage_reaudit_R126_20260625.csv`;
  - `audit/P12_confirmed_fixes_R126_localcodex_20260625.csv`;
  - `audit/P12_source_quality_verdict_20260625.csv`;
  - `audit/P12_summary_20260625.json`.
- Package folder: `Noether_R126_LocalCodex_P12_FullPageReaudit_WebDrop_20260625`.
- Caveat: the full-page GDZ JPGs are best local page-continuity witnesses but below native 650ppi. Dense math exactness is only asserted at the bundled 1000ppi exact-locus witnesses.

## 2026-06-25 22:05 - P22 p53 title/author/editor footnote anchor fix

- Picked up Paper 22, `Zur Theorie der Polynomideale und Resultanten`, because `source_queue_R126.csv` still leaves P22 open for best-effort lower-resolution audit after the older RA61--RA63 survival package.
- Used the best staged P22 source witness for printed p. 53: GDZ full-page JPG `P22_printed_p053_GDZ_PPN235181684_0088_seq000057_400x400ppi.jpg`.
- Source-quality caveat: this page witness is 400 x 400 ppi, not strict 650+ native. It is sufficient for the large title/author/editor-footnote anchor but does not certify dense P22 mathematics.
- Found one source-certain layout/anchor defect in the current cumulative:
  - current TeX made `Bearbeitung von K. Hentzelt` part of the section title and put Noether's long editorial footnote after the opening theorem block;
  - source has title `Zur Theorie der Polynomideale und Resultanten`, then `Von`, `Kurt Hentzelt dagger`, and `Bearbeitet von Emmy Noether in Goettingen` with the footnote marker there.
- Patched the cumulative copy by restoring the source title/author/editor block and moving the existing footnote text to the source-visible editor line.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages. Final log grep shows no fatal errors, emergency stops, undefined-reference warnings, or rerun warnings, only existing package/font warnings.
- Package folder: `Noether_R126_LocalCodex_P22_p053_TitleFootnoteAnchor_WebDrop_20260625`.

## 2026-06-25 22:20 - P22 pp. 55--58 bounded varrho notation repair

- Continued Paper 22 after the p53 package and checked printed p54--p58 against the best staged GDZ full-page witnesses.
- p54: theorem tail, explanatory paragraphs, and footnotes 2--4 match the current TeX well enough for this pass; no patch made.
- p55--p58: found a source-certain notation defect in the elementary-divisor/rank block. The source uses the curly rho/varrho form for the rank/index variable, while the current TeX used plain `\rho`.
- Applied a bounded correction only over the visually checked p55--p58 block, changing the relevant plain `\rho` tokens to `\varrho` in the rank sentence, matrix/formula (1), formula (3), formula (5)/(6) discussion, Satz III opening, and formula (8) setup.
- Did not propagate the replacement to all of P22. Later `\rho` loci remain for page-by-page verification before promotion.
- Source-quality caveat remains: pp. 55--57 are 400ppi GDZ witnesses; p58 is 600ppi. These are best staged witnesses and sufficient for visible varrho/rho distinction in the checked block, but not strict 650+ native certification.
- XeLaTeX compiled the superseding cumulative twice; output PDF has 466 pages.
- Superseding package folder: `Noether_R126_LocalCodex_P22_p053_p055_058_TitleVarrhoFix_WebDrop_20260625`.

## 2026-06-25 22:45 - P22 varrho repair extended through p61 / Satz V

- Continued the same P22 notation lane through printed pp. 59--61.
- Verified against GDZ p59--p61 that the source continues to use the curly rho/varrho form in Satz III and Satz V notation: determinant rank, `a_\varrho`, `g_{\varrho+1}`, `e_\varrho`, `r_\varrho`, `s_\varrho`, products through `\varrho`, and the end of Satz V.
- Extended the bounded TeX repair through the end of Satz V, stopping before § 3 / `Ideale aus Polynomen`.
- The package now supersedes both earlier P22 web drops from this turn.
- Source-quality caveat remains: p59 is 600ppi; pp. 60--61 are 400ppi. These are best staged witnesses, sufficient for visible varrho/rho correction but not strict 650+ native page certification.
- Superseding package folder: `Noether_R126_LocalCodex_P22_p053_p055_061_TitleVarrhoFix_WebDrop_20260625`.

## 2026-06-25 23:35 - P22 pp. 64--69 RA62 reaudit / source-certain p64 and p69 repairs

- Continued Paper 22 from the previous P22 cumulative, using staged GDZ full-page witnesses plus the older RA targeted inspection crops.
- Source-quality caveat: P22 pp. 64--69 are still best-available rather than uniformly native 650+ ppi. GDZ full pages are 600ppi for pp. 64 and 66 and 400ppi for pp. 65, 67, 68, and 69; RA crops are 1000dpi inspection enlargements from a 360ppi embedded source. This is best-effort source control, not strict native high-resolution certification.
- p64: found and patched a source-certain opening-notation error. Source reads `Potenzprodukten xi_i`, `F(x)=sum a_i^{(i)} xi_i`, and `unter a_i^{(i)}`; current TeX had `xi_lambda` / `a_lambda^{(i)}` at this locus.
- p65--p68: checked the RA62 sensitive formula lane. Earlier repairs for formulas (21)--(29), `\mathfrak C_1`, `\mathfrak C_{i-1}`, `\zeta`, and the `\omega` family were already present; no new patches.
- p69: found and patched source-certain formula/prose defects:
  - restored paired coefficient subscripts `c_{\alpha\lambda}`, `c_{\beta\tau}`, `d_{\gamma\lambda}` in the independence display and follow-up prose;
  - changed the displayed `H(x)`, `G(x)`, and `F(x)` relations from equals signs to source-visible congruence signs modulo `\mathfrak C_i`.
- Created cleanly named cumulative TeX and compiled twice with XeLaTeX; output PDF has 466 pages. Final pass has only pre-existing font warnings.
- Package folder: `Noether_R126_LocalCodex_P22_p064_069_RA62Reaudit_WebDrop_20260625`.
## 2026-06-25 -- R126 P22 pp70-79 tail reaudit

Package in progress: `Noether_R126_LocalCodex_P22_p070_079_TailReaudit_WebDrop_20260625`.

Base cumulative: `Noether_R126_LocalCodex_P22_p064_069_RA62Reaudit_WebDrop_20260625`.

Source policy note: P22 pp70 and 79 have 600ppi GDZ full-page witnesses; pp71-78 have 400ppi GDZ full-page witnesses. These are the best available local witnesses for this tail and are explicitly below the 650ppi certification preference. Targeted 1000dpi inspection enlargements exist for p72 and p79, but they are enlargements from lower-native source, not independent native 1000ppi witnesses.

Results:

- p70-p75 visually checked against GDZ page witnesses; no patch.
- p76 patched source-certain formula (35): source defines `x_i=-v_1x_1-\cdots-v_{i-1}x_{i-1}+z_i`; current TeX had the substitution reversed as `z_i=...+x_i`.
- p76 patched source-certain index letters after (35): source uses `u_{i\kappa}`, `w_{i\kappa}=u_{i\kappa}-v_\kappa`, and more generally `u_{i+\lambda,\kappa}`, not flattened Latin `k/h`.
- p77 patched source-certain missing family subscripts in the explicit `H^{(i)}(z,x)` product: barred coordinates carry lambda subscripts, matching exponent `\alpha_\lambda`.
- p78 patched source-certain formula (36): `\bar R^{(i)}(z,x)` product carries nu-indexed barred coordinates and exponent `\lambda_\nu`; current TeX reused the previous `\alpha_\lambda` and omitted coordinate subscripts.
- p79 checked full page plus targeted inspection enlargement for the barred `\bar R^{(i)}(z,x)` specialization sentence; current TeX already correct.

Compile: updated German cumulative compiled twice with XeLaTeX to 466 pages. Final log has ordinary font warnings only and no fatal errors, emergency stops, undefined control sequences, or unresolved-reference warnings.
## 2026-06-25 - R126 queue reconciliation P09-P12/P22
- Built `Noether_R126_LocalCodex_QueueReconciliation_P09_P12_P22_WebDrop_20260625.zip`.
- SHA256: `6F6F4FF4B3FFE4A4A99E4A9B8CF1A58490F84C7432A09253257383EA1826E7DC`.
- Purpose: prevent the web session from treating stale `source_queue_R126.csv` rows as blind-open work after local packages already handled or downgraded them.
- Main finding: P09 and P10 are not fresh blind-open rows; both have best-available local page-band audits plus R126 survival packages. Reopen them only for concrete regressions or genuinely better native source, not for duplicate replay.
- P11 and P12 have R126 full-page re-audit packages. P12 has one confirmed p43 fix, `analytischer` -> `analytischen`, in the local cumulative.
- P22 now has fresh R126 fixes/checks for p53, p55--61, p64--79; p62--63 remain represented by older RA62 survival evidence rather than a fresh p62--63 pass in this turn. Status should therefore be downgraded/integrated, not blindly restarted.
- Recommended next nonduplicate work recorded in the package: tail pp711--746 and p764 onward, actual P29, P30 remaining pages, and the high queue P34/P35/P36/P37/P38/P40/P41/P43.

## 2026-06-25 - R126 P29 source-status survival check

- Built `Noether_R126_LocalCodex_P29_GDZ400_SurvivalStatus_WebDrop_20260625.zip`.
- SHA256: `3DCD948D6BAB1C72475C95C195FBA0192AB6204546B991DC7D8DFADFB708C6C2`.
- Purpose: prevent Paper 29 from being audited against the wrong staged source. The misnamed `noether_p29_ia_source_20260623` / Math. Ann. 90 pp. 229--261 package is actually Paper 24 and must not be used for Paper 29.
- Actual P29 witness staged: GDZ-style full pages p28--35 at best-available 400ppi. This is below the preferred 650+ native threshold, but is the correct work-level witness.
- No TeX patch was made. The current R126 cumulative already preserves the previously important RA71/header/footnote survival fixes.
- Continuation: reopen P29 only for a concrete source mismatch or if a better native source appears.

## 2026-06-25 - R126 P30 IA JP2 source-status package

- Built `Noether_R126_LocalCodex_P30_MA96_IAJP2_SourceStatus_WebDrop_20260625.zip`.
- SHA256: `8302E672012229E67ECDE2918F71CBBB05712B63C950D657E840A1C5B87B9C42`.
- Paper: `Abstrakter Aufbau der Idealtheorie in algebraischen Zahl- und Funktionenkörpern`, Math. Ann. 96 (1927), pp. 26--61.
- Staged authority: IA volume `sim_mathematische-annalen_1927_96_jp2.zip`, leaves 31--66, mapped to printed pp. 26--61 and IA PDF pp. 32--67.
- Source-quality verdict: 2208 x 3372 page images at recorded 400ppi. Cleaner than local `PPN235181684_0096.pdf`, but still below strict 650+ native certification. Treat as `best_available_below_650_IA400`.
- Boundary checked: p26 opens Paper 30; p61 ends with `(Eingegangen am 13. 8. 1925.)`.

## 2026-06-25 - R126 P30 pp26--32 source-fix package

- Built `Noether_R126_LocalCodex_P30_p026_032_SourceFix_WebDrop_20260625.zip`.
- Base: R126 German cumulative.
- Source witness: IA JP2-derived native PNGs for printed pp. 26--32, 2208 x 3372 at recorded 400ppi. This is best available locally and better than the local 1-bit volume PDF, but remains below preferred 650+ native source.
- Confirmed and patched source-visible defects:
  - p26 footnote marker moved before the colon in `die folgenden^1):`;
  - p27 Krull citation range corrected from `S. 181--218` to source `S. 181--213`;
  - p29--p30 Latin/Greek element-convention sentence restored as a parenthetical;
  - p30 module basis endpoint corrected from `\mu_n` to source `\mu_r`;
  - p31 finite-sum basis representation corrected to `r_1\mu_1+\cdots+r_k\mu_k`;
  - p31 missing source footnote 8 restored, together with the final clause `was beides an dieser Stelle zum erstenmal benutzt wird`;
  - p31 transitivity basis indices corrected to `\rho`, `\sigma`, and product index `k`;
  - p31--p32 chain notation corrected from `\mathfrak U_\mu` / `\mathfrak U_n` to source `\mathfrak A_\mu` / `\mathfrak A_n` in the checked continuation.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages. Existing corpus font/package warnings remain; no fatal errors.
- Continuation: P30 printed p33 onward remains open for source-critical audit against the staged IA400 source unless a better native witness is found.

## 2026-06-25 - R126 P30 pp33--35 source-fix package

- Built `Noether_R126_LocalCodex_P30_p033_035_SourceFix_WebDrop_20260625.zip`.
- Base: the local P30 p26--32 patched cumulative, so this package's cumulative TeX includes the earlier p26--32 fixes.
- Source witness: IA JP2-derived native PNGs for printed pp. 33--35, 2208 x 3372 at recorded 400ppi. This remains best-available below the preferred 650+ native threshold.
- Confirmed and patched source-visible defects:
  - p33 Dedekindsche Folgerung I exponent/running-index notation corrected from a mixed `\rho`/`\nu`/`r` scheme to source `\sigma`, `\tau`, and `\rho<\tau`;
  - p33 comparison equation corrected to `(c\beta^\rho)^\tau-c^{\tau-\rho}(c\beta^\tau)^\rho=0`;
  - p34 Dedekindsche Folgerung II corrected to source `\sigma\ge1`, `m=c\beta^\sigma`, `n=c\beta^{\sigma-1}`, and `m^2/n=c\beta^{\sigma+1}`;
  - p35 Modulsatz proof congruence direction restored from reversed/current `B mod A` wording to source `A\equiv0(B)`, `A_\lambda\equiv0(B_\lambda)`, `a_\lambda\equiv0(b_\lambda)`;
  - p35 minimal-length argument restored to source index `i` and source congruence form `\beta-\alpha\equiv0(B)`, `\not\equiv0(A)`;
  - p35 chain-index notation restored to source `A_r`, `a_{r1},...,a_{rk}`, row index `\lambda`, and stabilization index `\mu`.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages.
- Continuation: P30 printed p36 onward remains open.

## 2026-06-25 - R126 P30 pp36--42 source-fix package

- Built `Noether_R126_LocalCodex_P30_p036_042_SourceFix_WebDrop_20260625.zip`.
- Base: the local P30 p26--35 patched cumulative, so this package's cumulative TeX includes all earlier P30 Local Codex fixes.
- Source witness: IA JP2-derived native PNGs for printed pp. 36--42, 2208 x 3372 at recorded 400ppi. This remains best-available below the preferred 650+ native threshold.
- Confirmed and patched source-visible defects:
  - p39 footnote 16 restored to source `vgl. Anmerkung 9)`;
  - p40 footnote 17 restored to source `Vgl. dazu Anmerkung 9)`.
- Checked without patch: printed pp. 36--38 and 41--42 were reviewed against the same source witness. Congruence typography differences on pp. 41--42 were recorded as no-patch style differences, not promoted to semantic rewrites.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages.
- Continuation: P30 printed p43 onward remains open.

## 2026-06-25 - R126 P30 pp43--49 source-fix package

- Built `Noether_R126_LocalCodex_P30_p043_049_SourceFix_WebDrop_20260625.zip`.
- Base: the local P30 p26--42 patched cumulative, so this package's cumulative TeX includes all earlier P30 Local Codex fixes.
- Source witness: IA JP2-derived native PNGs for printed pp. 43--49, 2208 x 3372 at recorded 400ppi. This remains best-available below the preferred 650+ native threshold.
- Confirmed and patched source-visible defects:
  - p43 product in the proof of primality corrected from `a^x b^\lambda=(ab)^x` to source `a^x b^x=(ab)^x`;
  - p46 footnote 26 restored to the source's explicit quasi-lexicographic notation using `A_n`, `A_m`, `B_n`, `a_i`, and `b_i`;
  - p49 footnote 29 restored the omitted final example: the system of all even integers;
  - p49 Satz IV proof block restored from the source, including the exponent product and the explicit primary-component comparison/divisibility argument.
- Checked without patch: printed pp. 44--45 and 47--48 were reviewed against the same source witness with no additional confirmed semantic repair promoted.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages.
- Continuation: P30 printed p50 onward remains open.

## 2026-06-25 - R126 P30 pp50--52 source-fix package

- Built `Noether_R126_LocalCodex_P30_p050_052_SourceFix_WebDrop_20260625.zip`.
- Base: the local P30 p26--49 patched cumulative, so this package's cumulative TeX includes all earlier P30 Local Codex fixes.
- Source witness: IA JP2-derived native PNGs for printed pp. 50--52, 2208 x 3372 at recorded 400ppi. This remains best-available below the preferred 650+ native threshold.
- Confirmed and patched source-visible defects:
  - p50 restored the Hilfssatz label, Zusatz, and the full source proof that prim and teilerfremd coincide, including the `q:p` primary quotient and the general ideal `t` criterion;
  - p51 corrected the Hilfssatz 1 consequence from the false `c \ne c t` to source `c^\rho \ne c^{\rho+1}`;
  - p51 restored the determinant/coefficient conclusion `e^n+b_1e^{n-1}+\cdots+b_n=0` with `b_i \equiv 0 (b)`;
  - pp51--52 rebuilt the exponent-two primary-ideal proof with source `o c`, `o n`, `\gamma=b/c`, and the correct four relations, including `n \equiv 0(p)`;
  - p52 rebuilt Hilfssatz 3 with the source `\sigma/\lambda` second formulation and the `o c^\sigma` induction display.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages.
- Continuation: P30 printed p53 onward remains open.

## 2026-06-25 - R126 P30 pp53--55 source-fix package

- Built `Noether_R126_LocalCodex_P30_p053_055_SourceFix_WebDrop_20260625.zip`.
- Base: the local P30 p26--52 patched cumulative, so this package's cumulative TeX includes all earlier P30 Local Codex fixes.
- Source witness: IA JP2-derived native PNGs for printed pp. 53--55, 2208 x 3372 at recorded 400ppi. This remains best-available below the preferred 650+ native threshold.
- Confirmed and patched source-visible defects:
  - p53 corrected the Axiom III proof congruences from the reversed current version to source `o \not\equiv 0(o^2)` and `o^2 \equiv 0(o^2)`;
  - pp53--54 restored missing shortest-representation and product-divisor detail in the Axiom IV / Axioms I-II proof;
  - p54 rebuilt the Hauptidealring proof with source `o c`, `p^\sigma=(o c^\sigma,p^\rho)`, quotient-ring bars, and direct-sum calculation;
  - p55 restored the final Vorbemerkung equality, the correct `\tau_i=t_i/a` module-basis setup, and the source form of the general solution to `A X=o`.
- XeLaTeX compiled the patched cumulative twice; output PDF has 466 pages.
- Continuation: P30 printed p56 onward remains open.

## 2026-06-25 - R126 P30 pp56--61 source-fix package

- Built `Noether_R126_LocalCodex_P30_p056_061_SourceFix_WebDrop_20260625.zip`.
- Base: the local P30 p26--55 patched cumulative, so this package's cumulative TeX includes all earlier P30 Local Codex fixes.
- Source witness: IA JP2-derived native PNGs for printed pp. 56--61, 2208 x 3372 at recorded 400ppi. This remains best-available below the preferred 650+ native threshold.
- Confirmed and patched source-visible defects:
  - p56 restored the missing proof sentence in 6 alpha;
  - p56 restored the 6 beta parenthetical `(endlicher R-Modul)` and the full uniqueness proof;
  - p56 corrected 6 gamma from erroneous `o n` to source `o eta`, restored the nonintegral-element parenthetical and the missing quotient derivation, and corrected the divisibility condition to no power of `ab` through `c`;
  - p56 restored the sentence explaining that `eta` differs from `b/c` only by a unit from `R`;
  - p57 restored the omitted converse paragraph after Folgerung 8;
  - p57 replaced the placeholder footnote 32 with source `Vgl. Anm. 19).`;
  - p57 rebuilt item 9 with the finite-order example and barred quotient-ring notation;
  - p57 expanded footnote 33 to the source text on generalized Abelian groups, Hauptreihe, and group-theory terminology.
- Checked without patch: printed pp. 58--61 were opened visually against the same source witness with no additional confirmed semantic repair promoted.
- XeLaTeX compiled the patched cumulative twice; output PDF has 467 pages.
- Paper 30 local audit status: printed pp. 26--61 have now been locally source-audited against the staged IA400 witness and the cumulative TeX carries all confirmed Local Codex fixes through the end of the paper. Source quality remains below the preferred 650+ native threshold, so this is source-critical best-available, not a high-resolution final certification.

## 2026-06-25 - R126 P10/P30 queue reconciliation

- Built `Noether_R126_LocalCodex_P10_P30_QueueReconciliation_WebDrop_20260625.zip`.
- Purpose: prevent duplicate web work from stale `source_queue_R126.csv` rows.
- P30 disposition: close the R126 P30 queue row at best-available IA400 level because the Local Codex P30 repair chain now covers printed pp. 26--61 through the end of the paper. Reopen only if a better source witness appears or a concrete new defect is found.
- P10 disposition: do not treat the R126 P10 row as a fresh target. Prior Local Codex P10 packages audited pp. 536--545 against best-available GDZ/raw-IIIF witnesses, and the R126 P10--P13 survival package confirms that the important repaired anchors remain present in the current cumulative (`\Jdom`, `k_\sigma`, `F(t;\vartheta_i)`, explicit `i\cdot`). Reopen only if a better source witness appears or a concrete new defect is found.
- Source-quality caveat: P10 and P30 are best-available source work below the preferred 650+ full-page threshold, not 650+ final certifications.
- Next non-overlap recommendation: move to P09 remaining full-page material rather than spending another pass on P10 without a new source or defect.

## 2026-06-25 - R126 tail/Kapferer queue reconciliation

- Built `Noether_R126_LocalCodex_Tail_Kapferer_QueueReconciliation_WebDrop_20260625.zip`.
- Purpose: reconcile the R126 workbook tail queue against later Local Codex packages already present locally.
- Disposition:
  - collected pp. 711--712 are Deuring-note title/table-of-contents front matter; source witnesses were found in the R101 all-page image drop and bundled for web disposition;
  - collected pp. 713--746 are covered by `Noether_R125_LocalCodex_Tail_p713_p746_Section24Satz2Start_WebDrop_20260625.zip`;
  - collected pp. 747--763 are covered by `Noether_R125_LocalCodex_Tail_p747_p763_BrauerSchurSection31Repair_WebDrop_20260625.zip`;
  - Kapferer/Noether Math. Ann. 97 source pp. 559--567, corresponding to collected/post-tail material beginning at p. 764, are covered by `Noether_R126_LocalCodex_KapfererNoether_MathAnn97_p559_p567_Complete_WebDrop_20260625.zip`.
- Source-quality caveat: Deuring tail witnesses are native about 360ppi; Kapferer witnesses are best-staged GDZ about 400dpi. These are best-available repairs, not strict 650+ certifications.
- Still open: verify whether any post-Kapferer collected-volume bibliography/end matter after the p559--567 article should be included; otherwise move to actual P29 or the high-fidelity P34/P35/P36/P37/P38/P40/P41/P43 source rows.

## 2026-06-25 - R126 high-queue P34/P43 signature reconciliation

- Built `Noether_R126_LocalCodex_HighQueue_P34_P43_SignatureReconciliation_WebDrop_20260625.zip`.
- Purpose: prevent stale P34--P43 high-queue rows from causing duplicate web repair work when exact post-R124 fixes already survive in R126.
- No cumulative TeX change was made in this package.
- Checked R126 signatures:
  - P34 title footnote and the restored discriminant/product-table block survive, including `D_{\rm red}=e`;
  - P35 tail closing line survives as `(Rec. Math. XXXVI:1; 1929).`;
  - P36 DMV spacing and author-line fixes survive;
  - P41 source-style display apparatus survives, including `(1')`--`(5')`, `normierte zyklische Darstellung`, and `u_E=e_{E,E}`;
  - P43 source-restored opening and footnote apparatus survive, including editor/source note 1 and later footnotes 12, 13, 13a.
- Disposition: do not replay those exact items as missing in R126; reopen only for a better source witness, a concrete new defect, or a full page-by-page certification pass.
- Source-quality caveat: these are survival/signature checks against the current R126 cumulative, not strict 650+ source certifications.
## 2026-06-25 — R126 Local Codex Paper 42 targeted source-order fix

Package: `Noether_R126_LocalCodex_P42_SpTildeOrderFix_WebDrop_20260625.zip`.

Context: after the R126 queue-disposition update, Paper 42 remained one of the least safely closed high-queue items because previous web/agent work on it was locator-only and the complete available source is below the preferred 650 ppi threshold. I rechecked the active R126 Paper 42 slice against the local RA10 source cutout. Source file: `Noether Multilingual\N_RA10_20260605\01_scan\p42_scan.pdf`, 11 pages, native embedded page images 2048x3322 at 360 ppi. No better downloadable scan was found in the quick online/source search pass, so this remains `best_available_below650`, not strict source certification.

Confirmed source-fidelity fix: source p685 / source PDF page 7 prints the Satz 1 trace ideal order as `Sp(\widetilde a a)`. R126 had three corresponding occurrences as `Sp(a\widetilde a)` in the proof and following remark. Since this is a source-critical edition, I patched the package cumulative copy to the printed order in all three locations and compiled it with `xelatex` to 466 pages. `pdflatex` was rejected as the wrong engine because this cumulative loads `fontspec`.

No-fix traps recorded for web: footnote (1) OCR misreads the Hasse citation ending, but visual source supports R126 `(zit. H.)`; do not globally replace the earlier plain product `a\widetilde a` in the Satz 2 remark, because source p684 prints that order; the final quaternion example is content-correct although R126 sets the two bracketed orders as displays while the source is inline.

Result: one reversible TeX fix, page-level disposition ledger for source pp679-689, targeted 1000-dpi readability crops for the patched locus, and patched cumulative TeX/PDF included. Goal remains active; this does not certify all of Paper 42 at strict 650+ native resolution.

## 2026-06-25 - R127 failed web ZIP salvage / Paper 35 trace replay

Package: `Noether_R127_Recovered_Cumulative_P35Trace_WebDrop_20260625.zip`.

Context: the locally downloaded `Noether_R127_20260625.zip` was effectively empty: it contained only small documentation/scaffold files and no cumulative `cum_de_R127.tex`/PDF, despite its package contents note promising those artifacts. The attached failed web thinking trace showed that a real `cum_de_R127.tex` had been built and compiled in `/mnt/data/R127_work/build`, so I replayed the trace locally rather than treating the tiny ZIP as authoritative.

Base used: the same post-R126 local cumulative anchor identified in the trace, namely `Noether_R126_LocalCodex_P04_RA64SurvivalAudit_WebDrop_20260625/tex_anchor/cum_de_R126_plus_Kapferer559_567_plus_P20_barrepair_plus_P08_omega_current_20260625.tex`.

Recovered work: replayed the explicit Paper 35 patch sequence from the trace. This converts Paper 35 inline footnotes to source-style endnote apparatus, restores/repositions the Russian resume and `Rec. Math. XXXVI:1; 1929` line, preserves/restores source fraktur maximal-region notation, applies the trace's P35 formula/layout/emphasis repairs, and regenerates `P35_R126current_to_R127.diff`.

Validation: local MiKTeX XeLaTeX compiled the recovered cumulative twice. `pdfinfo` reports 467 pages. The build log scan found no fatal errors, emergency stops, undefined control sequences, missing-character warnings, overfull boxes, or underfull boxes.

Caveat: this is a trace-replay salvage package, not a new independent source re-audit of all Paper 35. The prior P35 MathNet600 source-repair package is included as provenance/context; any strict integration should compare the P35 delta against source before final certification.

## 2026-06-25 - R127 P10 queue reconciliation / no-new-patch survival drop

Package: `Noether_R127_LocalCodex_P10_QueueReconciliation_NoNewPatch_WebDrop_20260625.zip`.

Context: after recovering the broken R127 cumulative from the failed web trace, I checked whether the lingering R127 source queue row for Paper 10 should trigger another web pass. Paper 10 remains a best-available lower-resolution source lane: the staged authority is the local GDZ article PDF plus GDZ IIIF raw full-page images in `Noether Multilingual\source_master_checks`, with page dimensions recorded in `P10_GDZ_original_pp536_545_image_dimensions.csv`. These full-page witnesses are mixed roughly 400ppi, below the preferred 650ppi floor, so this is not a fresh 650+ page-by-page certification.

Result: no TeX patch. The Paper 10 slice in the recovered R127 cumulative is byte/hash-identical to the R126 Paper 10 slice, and the six prior source-repaired/high-risk anchors survive in R127: the source-visible author line, `\Jdom` on p538, terminal `k_\sigma` on p540, `F(t;\vartheta_i)\cdot G(t;\vartheta_i)` on p541, explicit `i\cdot` on p544, and the final `f(x\cdot(1\pm ic))` line on p545. I bundled the current R127 cumulative TeX, the R127/R126 P10 slices, the R127 survival CSV, source-quality caveat CSV, source witness dimensions/paths, and the prior P10 page-disposition ledgers.

Instruction carried forward: do not redo P10 merely because `source_queue_R127.csv` still has a lower-resolution row. Keep the source-quality caveat open, and reopen only if a better native 600/650+ witness appears, a concrete source-vs-TeX defect is found, or the P10 section changes in a later cumulative. Next non-overlap work should move to other still-live queue rows, especially P09/P11/P12 if not already superseded by newer web output.

## 2026-06-25 - R127 P09 queue reconciliation / no-new-patch survival drop

Package: `Noether_R127_LocalCodex_P09_QueueReconciliation_NoNewPatch_WebDrop_20260625.zip`.

Context: after the R127 salvage and the P10 R127 reconciliation, I inspected the still-live `source_queue_R127.csv` row for Paper 09. P09 already had a substantial R126 Local Codex survival package with targeted 1000dpi crops for exact loci, but the queue row remained noisy because surrounding full pages are lower-resolution GDZ witnesses. I therefore checked whether the recovered R127 cumulative changed the Paper 09 section.

Result: no TeX patch. The Paper 09 section in recovered R127 is hash-identical to the Paper 09 section in R126. The R127 survival ledger confirms the previously accepted exact-locus repairs/no-fix traps still survive: p103 author line, p103 Zermelo `S. 484` citation with stale `S. 434` absent, p119 `z=\varphi(\xi_1\cdots\xi_t)`, p125 module subscripts `\mathfrak M_{\nu\kappa}`, `\mathfrak M_{\nu\kappa+1}`, `\mathfrak M_{2\nu\kappa}`, and p127 capital-Greek `\Omega` definition with old fraktur-R definition reading absent.

Source-quality caveat: this is exact-locus survival, not a fresh full-page strict certification. The prior package's targeted 1000dpi witness crops close only the named loci; full-page P09 witnesses remain mixed approximately 400/600ppi and below the preferred 650ppi floor. The prior R126 P09 targeted-witness package is bundled in the R127 package as context.

Instruction carried forward: do not redo P09 merely because the old lower-resolution queue row persists. Reopen only if a better native 600/650+ full-page witness appears, a concrete source-vs-TeX defect is found, or a later cumulative changes the P09 section.

## 2026-06-25 - R127 P11/P12 queue reconciliation / bad prior P12 fix rejected

Package: `Noether_R127_LocalCodex_P11_P12_QueueReconciliation_P12BadPriorFixRejected_WebDrop_20260625.zip`.

Context: after the recovered R127 cumulative was available, I checked the lingering P11/P12 queue against the prior R126 spans and the source-specific traps already discovered locally. The R127 P11 and P12 sections are hash-identical to their R126 counterparts, so no new TeX patch was made.

P11 survival anchors: source-style author/front matter and comma handling survive, including the `Von / Emmy Noether in Göttingen,` line; the mathematical anchors checked in earlier passes also survive (`\Omega_\Gamma`, plain `G_k(x)`, `\varphi_3(x)=\frac{w\cdot u}{v}`, and final semicolon punctuation).

P12 survival anchors: the opening differential expression line, `d\delta x`, and `\bdelta x` survive. I also rejected a bad earlier Local Codex attempted fix from `aller analytischer Transformationen` to `aller analytischen Transformationen` at the final-paragraph locus. Visual inspection of the best staged GDZ/raw source image supports the R127 reading `aller analytischer Transformationen` there. A labelled crop of that exact locus is included in the package. Important caveat: P12 also has an earlier, different sentence with legitimate `aller analytischen Transformationen`; do not apply grep-only replacement rules.

Source-quality caveat: P11/P12 staged GDZ witnesses are best-available lower-resolution images, below the preferred 650ppi strict certification floor. This package is a queue/survival/no-fix-trap reconciliation, not a full strict source certification.

Instruction carried forward: do not replay the old P12 `analytischen` fix. Reopen P11/P12 only if a better native 650+ witness appears, a concrete new source-vs-TeX defect is found, or a later cumulative changes either section.

## 2026-06-25 - R127 REBUILT fixed web ZIP intake comparison

Package: `Noether_R127_REBUILT_LocalCodex_IntakeComparison_WebDrop_20260625.zip`.

Context: Web replaced the tiny broken `Noether_R127_20260625.zip` with `Noether_R127_REBUILT_20260625.zip` in the Noether Multilingual folder. The rebuilt archive is real: 52,004,966 bytes, 85 entries, SHA256 `0F2E740924671F0C32E66524BC887DC8567B5CF3D9C0D920ACFE8AFCBB218497`. It contains cumulative German TeX/PDF, a compileable Paper 35 slice, source witness PDF, native page images, crops, ledgers, logs, and diff files.

Verdict: use `Noether_R127_REBUILT_20260625.zip` as the live R127 authority. It supersedes the emergency Local Codex salvage package for normal handoff use. The salvage package should be kept only as provenance for the broken-ZIP incident.

Comparison result: the rebuilt R127 cumulative differs from the emergency salvage cumulative overall, and its Paper 35 standalone slice is stronger/longer than the salvage slice. However, the rebuilt R127 P09, P10, P11, and P12 sections are byte/hash-identical to the local R127 spans used for the P09/P10/P11-P12 queue-reconciliation drops. Therefore those three Local Codex drops remain valid and do not require rebasing.

Instruction carried forward: if giving Web the latest state, give it the rebuilt Web R127 package plus the three still-valid Local Codex drops (`P09`, `P10`, `P11_P12`). Do not give the emergency salvage as the preferred R127 base unless provenance for the broken ZIP is specifically requested.

## 2026-06-25 - R127 P12 best-available full-page disposition / no new patch

Package: `Noether_R127_LocalCodex_P12_BestAvailableFullPageDisposition_NoNewPatch_WebDrop_20260625.zip`.

Context: R127 `source_queue_R127.csv` still lists Paper 12 as a best-effort lower-resolution full-page audit lane for printed pp. 37--44, excluding already accepted exact 1000ppi loci. I reconciled this row against the live rebuilt R127 cumulative and the existing page-level source audit packages for P12 pp. 37--41 and pp. 41--44.

Result: no TeX patch. The current rebuilt R127 Paper 12 section is hash-identical to the previously audited P12 span from `Noether_R124plus_P09_P12_SurvivalResults_NoNewPatch_20260624` and to the P12 section in the later `Noether_R124plus_P12_p041_044_GDZ_Audit_WebDrop_20260625` candidate cumulative. The eight printed pages pp. 37--44 therefore inherit the earlier page/locus no-patch dispositions without rebasing edits.

Evidence packaged: current R127 P12 TeX section; combined page/locus disposition ledger; span hash rebase checks; combined no-fix traps; prior audit ledgers; source-quality caveat; source image inventory; and the eight best-available staged GDZ IIIF full-page JPG witnesses (`2296x3688` px).

Source-quality caveat: these GDZ full-page witnesses are best-available local source images but not strict native 650+ppi witnesses. This closes duplicate/current-queue noise at best-available level, not final strict certification. Dense exact loci remain governed by the earlier 1000dpi crop packages where applicable.

Important no-fix trap carried forward: do not replay the bad P12 final-paragraph `analytischer` -> `analytischen` change. Source supports final `aller analytischer Transformationen`; the earlier `aller analytischen Transformationen` occurrence is a distinct legitimate locus.

Instruction carried forward: treat R127 P12 as best-available full-page disposition/no-new-patch. Reopen only if a better native 650+ full-page witness appears, a concrete new defect is found, or the P12 section changes in a later cumulative.

## 2026-06-25 - R127 P11 best-available full-page disposition / no new patch

Package: `Noether_R127_LocalCodex_P11_BestAvailableFullPageDisposition_NoNewPatch_WebDrop_20260625.zip`.

Context: after closing the R127 P12 queue row at best-available level, I moved one paper backward to P11. R127 `source_queue_R127.csv` still lists Paper 11 as a lower-resolution best-effort full-page audit lane for printed pp. 221--229, excluding accepted exact 1000ppi loci. I reconciled this queue row against the live rebuilt R127 cumulative and the existing P11 full-page/page-locus audit ledgers.

Result: no new TeX patch. The live rebuilt R127 Paper 11 section already contains the source-confirmed P11 repairs from the earlier chain: source-style front matter `Von` / `Emmy Noether in Göttingen,`; 25 occurrences of `\Omega_\Gamma` and zero stale `\mathfrak L_\Gamma`; plain `G_k/H_k` in formula (11), no false prime; source-order `\varphi_3(x)=\frac{w\cdot u}{v}`; and final theorem semicolon before `ihre Mannigfaltigkeit`. All 12 local survival checks pass.

Evidence packaged: current R127 P11 TeX section; R127 survival checks; rebased page/locus full-page disposition ledger for printed pp. 221--229; combined no-fix traps; prior confirmed-fix ledgers; source-quality caveat; source image inventory; nine GDZ full-page JPGs; nine IA processed JP2 secondary witness leaves; and five targeted 1000dpi crop witnesses for exact dense/disputed loci.

Source-quality caveat: the primary GDZ full-page JPGs are roughly 1850--2000 px wide, and the IA JP2 leaves are roughly 2264--2288 by 3420 px. Prior source-quality notes treat both as about the 400ppi lane. This is best-available source work, not strict native 650+ full-page certification. Targeted 1000dpi crops certify only the named exact loci, not the whole paper.

Important no-fix traps carried forward: do not replace `\Omega_\Gamma` with stale `\mathfrak L_\Gamma`; do not introduce primes in formula (11) `G_k/H_k`; do not normalize the Tschirnhaus footnote coefficients; do not silently rewrite the original P11 `Zahlkörper \Omega` body text to the later erratum form without explicit editorial apparatus.

Instruction carried forward: treat R127 P11 as best-available full-page disposition/no-new-patch. Reopen only if a better native 650+ full-page witness appears, a concrete new source-vs-TeX defect is found, or the P11 section changes in a later cumulative.

## 2026-06-25 - R127 P10 best-available full-page disposition / no new patch

Package: `Noether_R127_LocalCodex_P10_BestAvailableFullPageDisposition_NoNewPatch_WebDrop_20260625.zip`.

Context: after Web replaced the broken tiny R127 archive with the fixed 52 MB `Noether_R127_REBUILT_20260625.zip`, I rebased Paper 10 against that live rebuilt cumulative rather than the emergency salvage. This checks whether the earlier P10 source-critical work still survives in the fixed R127 package.

Result: no new TeX patch. The fresh Paper 10 extraction from rebuilt R127 is 199 lines, cumulative lines 7669--7867, SHA256 `F9B71360A9AC0EFCE3EBA38762FC364C9CE81961651125DC01574E42681C3276`. It is identical to the R127 P10 section already inspected before the archive fix.

Survival checks: R127 P10 has 16 `\srcfn` source-local footnote markers; `\Jdom` is present at the integrality-domain locus and stale `\Sdomain` is absent; definition (d) keeps terminal `k_\sigma` and no stale `k_\nu`; the p541 display keeps `F(t;\vartheta_i)\cdot G(t;\vartheta_i)`; the final rank-three argument keeps both `i\cdot` occurrences; and the closing date `Erlangen, 30. Oktober 1915.` survives.

Important comparator note: do not overwrite R127 P10 with the older `R124plusP35P39` current-base slice. That slice is useful provenance, but it predates at least the R127 `\Jdom` correction and differs from the live R127 text.

Evidence packaged: current R127 P10 TeX section; survival checks; no-fix trap ledger; best-available full-page disposition; source-quality caveat; image inventory; complete GDZ full-page P10 context set; targeted 1000dpi crop witnesses for p536, p540, p541, and p545; best-available 600dpi p538/p540 supplements; GDZ article PDF cutout; and copied prior source-audit ledgers.

Source-quality caveat: complete full-page P10 context is mixed 400/600 ppi, so this closes duplicate/current-queue noise at best-available level rather than strict native 650+ certification. Exact difficult loci use 1000dpi crops where available; p538/p540 are supplemented by 600dpi witnesses because that is the best local material found for those exact loci.

Instruction carried forward: treat R127 P10 as best-available full-page disposition/no-new-patch. Reopen only if a better native 650+ full-page witness appears, a concrete new defect is found, or a later cumulative changes the P10 section.

## 2026-06-25 - R127 P09 best-available full-page disposition / no new patch

Package: `Noether_R127_LocalCodex_P09_BestAvailableFullPageDisposition_NoNewPatch_WebDrop_20260625.zip`.

Context: after closing P10--P12 against the fixed rebuilt R127 archive, I handled the remaining adjacent R127 lower-resolution Paper 09 queue row in the same direct web-drop format. This uses `Noether_R127_REBUILT_20260625.zip` as the live authority and extracts the current Paper 09 section from that cumulative.

Result: no new TeX patch. The fresh Paper 09 extraction from rebuilt R127 is 1332 lines, cumulative lines 6337--7668, SHA256 `6DF980BB84559A842D3F2FE21769B3A35BDB4B848DE52E7DDF6449F469DC0BED`.

Survival checks: all 10 R127 checks pass. P09 has 43 `\srcfn` source-local notes; the source-visible author line `Emmy Noether in Erlangen` survives; the Zermelo citation has `S. 484` and stale `S. 434` is absent; the Weber footnote has `Kleine Ausgabe § 96 und 97` and stale `§§ 96` is absent; the p112 coefficient-display hotspot anchors survive at best-available no-patch level; the p119 `\xi_t` no-fix trap survives with no `\xi_h` replacement; the p125 multiplicative module subscripts survive with no comma-subscript rewrite; the p127 `\Omega` definition repair survives; and a guarded stale-marker scan found no TODO/FIXME/MISSING/PLACEHOLDER/UNCLEAR-style hazards in the P09 slice.

Evidence packaged: current R127 P09 TeX section; survival checks; no-fix trap ledger; best-available full-page disposition; source-quality caveat; image inventory; complete GDZ full-page P09 context set; targeted 1000dpi crop witnesses for p103, p119, and p125; GDZ article PDF cutout; and copied prior source-audit ledgers including p106, p112, and p127 dispositions.

Source-quality caveat: complete full-page P09 context is mixed 400/600 ppi, so this closes duplicate/current-queue noise at best-available level rather than strict native 650+ certification. Exact accepted loci use 1000dpi crops where available; p106/p112/p127 remain best-available lower-resolution dispositions with explicit caveats.

Instruction carried forward: treat R127 P09 as best-available full-page disposition/no-new-patch. Reopen only if a better native 650+ full-page witness appears, a concrete new defect is found, or a later cumulative changes the P09 section.

## 2026-06-25 - R127 P19/P20 best-available survival audit / no new patch

Package: `Noether_R127_LocalCodex_P19_P20_BestAvailableSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: after Web fixed the broken R127 archive, I checked the rebuilt R127 cumulative against the older Local Codex P19/P20 repair history rather than assuming the prior repairs survived. This package uses `Noether_R127_REBUILT_20260625.zip` as the live authority and extracts the current P19/P20 spans from `cum_de_R127.tex`.

Result: no new TeX patch. The known high-risk repairs already survive in rebuilt R127. P19 keeps the source-supported sigma exponent display `g=p_1^{\sigma_1}\cdots p_\nu^{\sigma_\nu}`, the p058 congruence order with `\ideal Q\eqzero{\ideal P}` before `\ideal P^\rho\eqzero{\ideal Q}`, and the p065--p066 elementary-divisor tail including `s_\lambda`, `t_\mu`, and `r_\nu=s_1\le s_2\le\cdots\le s_\lambda\le r_\nu`. P20 keeps the clear page boundary after P19, the source-supported formula tag `(12)`, formula (13) with `\varrho_\kappa` and `\sigma_\lambda`, the legitimate nearby prose `\varrho_\mu\sigma_\nu`, and the p33 `\frK` / `\Delta` loci with no capital `\Lambda` token in the P20 span.

Evidence packaged: R127 cumulative German TeX/PDF authority copy; separate P19, P20, and combined P19/P20 TeX spans; survival-check CSV; no-fix trap CSV; best-available disposition CSV; IA article cutout PDFs for P19 and P20; four exact 1000dpi labelled evidence crops for P19 p058, P19 p065, P19 p066, and P20 p031; two best-available 600ppi GDZ P20 p032/p033 full-page supplements; and prior ledgers from the P19/P20 IA source upgrade, targeted survival package, and P20 bar-repair package.

Source-quality caveat: this closes the R127 survival/queue-ambiguity lane, not strict final page-by-page certification. P19/P20 article-level witnesses are in the best-available 400ppi lane, and the P20 p032/p033 supplements are 600ppi. The exact 1000dpi crops are inspection enlargements for named loci, not proof of native optical detail beyond the underlying lower-resolution sources.

Instruction carried forward: treat R127 P19/P20 as best-available survival/no-new-patch. Do not replay the stale P19 p058 order reversal, stale P19 nu-exponent substitution, stale P20 `(12')` tag, stale P20 formula (13) mu/nu replacement in the display, or stale P20 `\Omega`/`\Lambda` changes at the p33 field/discriminant loci. Reopen only if a better native 650+ witness appears, a concrete new source-vs-TeX defect is found, or a later cumulative changes the P19/P20 spans.

## 2026-06-25 - R127 P17/P18 best-available survival audit / no new patch

Package: `Noether_R127_LocalCodex_P17_P18_BestAvailableSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: the earlier post-R126 P17/P18 rollup was made before Web fixed the R127 package, so it still stated that no R127/R128 Noether drop was locally present. I rebased the P17/P18 survival checks onto `Noether_R127_REBUILT_20260625.zip` directly.

Result: no new TeX patch. The known P17/P18 high-risk repairs already survive in rebuilt R127. P17 keeps the title `Moduln in nichtkommutativen Bereichen, insbesondere aus Differential- und Differenzenausdrücken`, both formula (39) source footnotes 21 and 22, the formula (39) relation ending `=a_\sigma`, and the formula (40) assignment order `b_\rho\sim r_{\rho\sigma}a_\sigma; a_\sigma\sim r^{\sigma\rho}b_\rho`. The old source-unfaithful `Fortsetzung`/continuation scaffold remains absent. P18 keeps the source-visible conference session/chair/title material and the RA51 resultant correction `R^{(n)}(x_n)\equiv 0(\mathfrak M)`, with the following P19 block separated by `\clearpage` and footnote reset.

Evidence packaged: R127 cumulative German TeX/PDF authority copy; separate P17, P18, and combined P17/P18 TeX spans; R127 survival-check CSV; no-fix trap CSV; best-available disposition CSV; P17 full source PDF and printed p25 PDF slice; P17 formula (39)/footnotes 21--22 labelled 1000dpi crop; P17 section-transition labelled 650dpi crop; P18 GDZ600 one-page JPG/PDF witness; and copied prior RA52, RA77, RA94, and RA51 ledgers.

Source-quality caveat: this is a targeted survival/rebase package, not strict full-paper certification. Prior P17 source summaries describe the full source PDF as about 600ppi, with targeted 1000dpi and 650dpi inspection crops for the known problem loci. P18 uses a 600ppi GDZ one-page witness as a best-available exception. Reopen if a better native 650+ source appears, a concrete source-vs-TeX defect is found, or a later cumulative changes the P17/P18 spans.

Instruction carried forward: do not remove P17 footnotes 21/22, do not swap formula (40) assignments, do not reinsert an artificial continuation scaffold before P17 section 5, and do not change P18 `\equiv0(\mathfrak M)` back to equality. Do not claim P17/P18 are globally page-by-page certified from this package alone.

## 2026-06-25 - R127 P14/P15/P16 best-available survival audit / no new patch

Package: `Noether_R127_LocalCodex_P14_P15_P16_BestAvailableSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: the earlier P14--P16 survival package was built on the post-R126 local cumulative, before the fixed Web R127 rebuild was available. I rebased the known RA55/RA54/RA53/RA78 survival anchors directly onto `Noether_R127_REBUILT_20260625.zip`.

Result: no new TeX patch. All R127 survival checks pass. P14 keeps the title, the source-correct `mod. \((z-c)\)` locus, `\mathfrak q_i=\frp_i^{\,\ell_i}`, the \(v=c_0+c_1\pi+\cdots+c_{\sigma-1}\pi^{\sigma-1}-v_\sigma\pi^\sigma\) line, the \(g_1/g_2\) relations, `\omega_i=\frac{G_i(z,\delta)}{R(z)}`, `\psi(z,s)=A(z,s)f(z,s)+B(z,s)\varphi(z,s)`, the \(\fra\) factorization with \(\rho_i\), and polygon exponents \(\rho,\sigma\). The old `z-\alpha` reading is absent. P15 keeps the \(\xi_{x_i,n-1}\) index product, the \((n,n-1)\not\equiv0\pmod p\) condition, and the Schur citation `Math. Ann. 71, S. 355 (1912)`; stale `S. 555` is absent. P16 keeps the `\Omega`-Prozess phrase, both `[identisch in ...]` bracket anchors, the `linear zusammensetzen aus $F$ und aus Formen aus $M$` correction, and `Berichtigungen.`; the stale `$\\Phi$` reading at that locus is absent.

Evidence packaged: R127 cumulative German TeX/PDF authority copy; separate P14, P15, P16, and combined P14--P16 TeX spans; R127 survival-check CSV; no-fix trap CSV; best-available disposition CSV; high-value labelled crops from the older RA55/RA54/RA53 packages and later P14 GDZ source-fix packages; and copied prior RA53, RA54, RA55, RA78, and P14-GDZ ledgers.

Source-quality caveat: this is targeted R127 survival/anti-regression work, not strict page-by-page certification. Older RA53/RA54/RA55 packages report lower native source resolution, typically around 360ppi, with 1000dpi inspection enlargements for exact loci. Later P14 p183--203 packages add 600ppi GDZ witnesses/crops. This package includes high-value crops and ledgers only, not the full-page image bulk.

Instruction carried forward: do not replay P14 `z-\alpha`, P14 \(e_i\)/wrong exponent-family substitutions, P14 polygon exponent \(\nu,\nu'\) substitutions, P15 Schur `S. 555`, or P16 `\Phi` in the linear-composition sentence. Reopen only if a better native 650+ witness appears, a concrete new source-vs-TeX defect is found, or a later cumulative changes the P14--P16 spans.

## 2026-06-25 - R127 P13 best-available survival audit / no new patch

Package: `Noether_R127_LocalCodex_P13_BestAvailableSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: after Web fixed the broken tiny R127 archive, I rebased the full Paper 13 (`Invariante Variationsprobleme`) local source-critical chain onto `Noether_R127_REBUILT_20260625.zip` rather than replaying stale patches against an older cumulative.

Result: no new TeX patch. All 23 P13 R127 survival checks pass. The rebuilt R127 P13 span is cumulative lines 8473--9086. R127 keeps the source title/front-matter repairs, `endgiltige`, the Lie `Grundlagen` citation note, the \(x_\kappa\)/\(\lambda\) derivative index correction, formula (13) punctuation, the explicit product dots in \(\D x\), \(u''\cdot u'\), \(\Div(f\cdot\D x)\), \(\D w^\sigma\), and the Klein relativity footnote corrections. It also keeps the p250 source-visible oddity `\delta f(y,v,\partial v/\partial x,\ldots)\,dy` at line 8911. The nearby `\partial v/\partial y` occurrences at lines 8902 and 8941 are different ordinary contexts and are not the p250 oddity locus.

Evidence packaged: R127 cumulative German TeX/PDF authority copy; P13 TeX span; survival-check CSV; manual visual-confirmation CSV for the p250 oddity, Klein semicolon, and unbarred \(B-\Gamma\); no-fix trap CSV; best-available disposition CSV; high-value labelled crops from the P13 p235--257 prior packages; prior source-fix/no-fix/source-quality ledgers; and a logbook snapshot.

Source-quality caveat: this is targeted survival/anti-regression work, not strict page-by-page certification. P13 pp. 235--246 use best-available GDZ/IIIF witnesses tagged about 400ppi with inspection crops; pp. 247--257 use higher-detail Commons DjVu-derived images at 3984x5592 px, but metadata does not certify native PPI. Do not claim native 650+ certification for P13 from this package alone.

Instruction carried forward: do not normalize the p250 display's `\partial v/\partial x` back to `\partial v/\partial y` without a stronger source; do not replay the stale comma at formula (13), stale missing product dots, stale Klein derivative denominator, stale missing `\D w` product dot, stale barred/unbarred \(B-\Gamma\) substitutions, or stale p256 second-sum insertion. Reopen only if a better native 650+ witness appears, a concrete new source-vs-TeX defect is found, or a later cumulative changes the P13 span.

## 2026-06-25 - R127 P22 source-restoration patch / P21 and P23 survival checks

Package: `Noether_R127_LocalCodex_P22_SourceRestorationPatch_WebDrop_20260625.zip`.

Context: Web replaced the broken tiny R127 archive with `Noether_R127_REBUILT_20260625.zip` (about 50 MB). I treated that rebuilt R127 as the live authority and checked the next non-overlap lane around P21--P23. P21 and P23 retained their known survival anchors, but P22 had regressed to the old flattened Hentzelt title/front-matter shape and plain-rho rank block, while the later local P22 repair chain already contained source-backed restorations through the P22 tail.

Result: patched TeX produced. I replaced only the P22 span in rebuilt R127 with the latest locally source-restored P22 span from `cum_de_R126_plus_localcodex_P12_plus_P22_p053_p061_plus_P22_p064_p069_plus_P22_p070_p079_tailfix_20260625.tex`, leaving P21, P23, and all other R127 material unchanged. The patched cumulative is `tex/cum_de_R127_plus_localcodex_P22_source_restoration_patch_20260625.tex` in the package and compiles successfully with XeLaTeX to 467 pages.

Confirmed R127 P22 restorations: source-style title/front matter restored (`Zur Theorie der Polynomideale und Resultanten`, `Von`, `Kurt Hentzelt \dagger`, editor line `Bearbeitet von Emmy Noether in Göttingen`); the long Hentzelt note is anchored to the editor/front-matter line rather than to the theorem paragraph; the rank/determinant divisor block uses `\varrho`; the previously audited P22 pp. 64--79 repairs are restored, including `\mathfrak C_i`/`\zeta` auxiliary modules, paired coefficient subscripts, congruence signs, formula (35), the `\kappa`/`\lambda` distinctions, formula (36), and the barred-\(R\) specialization paragraph.

No-patch survival checks: P21 keeps the Riemann/Lipschitz curvature-form anchor, the Lipschitz `J. f. Math. 82 (1876)` citation, `Artikel IV, 1 II, p. 447`, and `h^{(1)}(dx,\delta x)`. P23 keeps the footnote reset and the RA60 correction `f(x,d x)=g(y,d y)`, and stale `\varphi(y,dy)` remains absent.

Evidence packaged: R127 authority TeX/PDF copy; patched cumulative TeX/PDF/log; P22 before/after TeX spans; P21/P23 no-patch spans; before-vs-after diff; 19/19 survival/patch-check CSV; source-quality ledger; confirmed-fix CSV; no-fix trap CSV; prior P22 ledgers from the p053 title, p055--p061 varrho, RA62, p064--p069 re-audit, RA63, and p070--p079 tail packages; and best-available P22 source witnesses/crops.

Source-quality caveat: this is a concrete R127 restoration patch, not final native-650 page-by-page certification. P22 source support is mixed: several full-page witnesses are 400/600ppi, while many exact loci use 1000dpi inspection crops from lower-native sources. Use it as best-available source-backed repair unless a stronger native 650+ witness appears.

Instruction carried forward: use the patched R127 cumulative rather than the rebuilt R127 P22 span. Do not replay the old flattened Hentzelt title, theorem-attached long Hentzelt note, plain-rho rank block, or stale P22 auxiliary-module/tail readings. Reopen only if a better native 650+ source appears, a concrete new source-vs-TeX defect is found, or a later cumulative changes the P22 span.

## 2026-06-25 - R127+P22 P30 source-restoration patch

Package: `Noether_R127_LocalCodex_P30_SourceRestorationPatch_WebDrop_20260625.zip`.

Context: after Web rebuilt R127 and the local P22 restoration patch was made, I checked Paper 30 against the complete Local Codex P30 source-fix chain. The R127+P22 base still differed from the final locally repaired P30 span for printed pp. 26--61. The final P30 span has 1245 lines, compared with 1207 lines in the R127+P22 base P30 span, with 182 additions and 144 removals in the before/after diff.

Result: patched TeX produced. I replaced only the P30 span in the R127+P22 patched cumulative with `P30_patched_span_sourcefix_p026_061.tex`, leaving all other R127+P22 material unchanged. The output cumulative is `tex/cum_de_R127_plus_localcodex_P22_P30_sourcefix_20260625.tex`. XeLaTeX pass 1 and pass 2 both succeeded locally; the compiled German cumulative PDF has 468 pages. The R127 P30 survival/patch checks pass 10/10.

Confirmed P30 restoration families: Krull citation page range; module-basis endpoints; missing p031 clause and footnote context; Dedekind Folgerung exponent notation; congruence direction; footnote note-number corrections; restored proof blocks on pp. 49--55; and p056--p061 local-ideal/divisibility repairs, including the source-style `\mc^\varrho\ne\mc^{\varrho+1}` condition and the final "no power of ab" argument.

Evidence packaged: R127+P22 authority-before-P30 TeX/PDF; patched cumulative TeX; P30 before/after TeX spans; before-vs-after diff; P30 confirmed-fix ledger rollup; survival-check CSV; span hash/boundary CSV; included-prior-ledger index; compact IA/GDZ/RA72 source PDFs; p026 1200dpi crops; source-quality ledger; and provenance files copied from the P30 source upgrade chain. The large 99 MB native image witness PDF is referenced rather than duplicated.

Source-quality caveat: this is a source-backed restoration patch, not strict native-650 full-page certification. Much of the complete P30 full-page source work is best-available IA/GDZ around 400ppi, with targeted 1200dpi inspection crops for exact p026 loci. Reopen if a better native 650+ full-page P30 witness appears, a concrete source-vs-TeX defect is found, or a later cumulative changes the P30 span.

Instruction carried forward: use the R127+P22+P30 patched cumulative as the current German base for Web integration. Do not replay the older R127 P30 span or the stale P30 readings corrected in the chunked p026--p061 local source-fix chain.

## 2026-06-25 - R127+P22+P30 P37 GDZ source-restoration patch

Package: `Noether_R127_LocalCodex_P37_SourceRestorationPatch_WebDrop_20260625.zip`.

Context: continuing from the R127+P22+P30 patched cumulative, I checked Paper 37 against the prior GDZ source-fix package `Noether_R126_LocalCodex_P37_GDZSourceFix_WebDrop_20260625`. The current P37 span still differed from the GDZ-fixed P37 reference slice. The before/after diff shows 11 additions and 9 removals, all tied to the earlier P37 confirmed-fix ledger.

Result: patched TeX produced. I replaced only the P37 span in `cum_de_R127_plus_localcodex_P22_P30_sourcefix_20260625.tex` with the GDZ source-fixed P37 span `p37_R126_gdzfixed_slice_after.tex`, leaving all other R127+P22+P30 material unchanged. The output cumulative is `tex/cum_de_R127_plus_localcodex_P22_P30_P37_sourcefix_20260625.tex`. XeLaTeX pass 1 and pass 2 both succeeded locally; the compiled German cumulative PDF has 468 pages. The R127 P37 survival/patch checks pass 9/9.

Confirmed P37 restorations carried forward: p147 Deuring footnote quotient-style factors corrected to source multiplication products; p148 `(einseitigen)` restored; p148 section-opening base order corrected from uppercase `\frakO` to lowercase `\frako`; p149 `(isomorphen)` restored; p150 `(rationalen)` restored; p150 determinant punctuation restored to source semicolon; p151 footnote 10 `(K_\frakp)_P` subscript corrected to plain `P`; p152 explanatory prime line corrected from indexed `\frakp_i`, `\mathfrak P_i` to generic `\frakp`, `\mathfrak P`; and the P38 footnote reset after P37 was carried forward.

Evidence packaged: R127+P22+P30 authority-before-P37 TeX/PDF; patched cumulative TeX/PDF; P37 before/after TeX spans; before-vs-after diff; carried-forward confirmed-fix and no-fix-trap ledgers; patch survival checks; span hash/boundary CSV; prior P37 source-quality/build ledgers; GDZ full-page witnesses for printed pp. 147--152; readability crops; and GDZ IIIF manifest.

Source-quality caveat: the P37 authority is the GDZ IIIF full-page image set, estimated in the prior package at about 666--668 ppi horizontally and 627--628 ppi vertically. This is the highest-resolution witness found in that pass and is very near but not perfectly above the 650 floor in both dimensions. The included crops are readability enlargements of native GDZ crops, not independent higher-native evidence. Treat this as a targeted source-backed patch for the recorded P37 loci, not blanket final certification of all P37.

Instruction carried forward: use the R127+P22+P30+P37 patched cumulative as the current German base for Web integration. Do not replay the older quotient-style Deuring factors, unparenthesized source parentheticals, uppercase `\frakO` opening, indexed generic prime prose, or missing P38 footnote reset.

## 2026-06-25 - R127+P22+P30+P37 P42 Sp-tilde source-order patch

Package: `Noether_R127_LocalCodex_P42_SpTildeOrderFix_WebDrop_20260625.zip`.

Context: continuing from the R127+P22+P30+P37 patched cumulative, I checked Paper 42 against the prior local source-order package `Noether_R126_LocalCodex_P42_SpTildeOrderFix_WebDrop_20260625`. The current P42 span still differed from the source-order-fixed slice by the known three `Sp` product-order readings.

Result: patched TeX produced. I replaced only the P42 span in `cum_de_R127_plus_localcodex_P22_P30_P37_sourcefix_20260625.tex` with the P42 source-order-fixed span `P42_R126_LocalCodex_SpTildeOrderFix_slice.tex`, leaving all other R127+P22+P30+P37 material unchanged. The output cumulative is `tex/cum_de_R127_plus_localcodex_P22_P30_P37_P42_sourcefix_20260625.tex`. XeLaTeX pass 1 and pass 2 both succeeded locally; the compiled German cumulative PDF has 468 pages. The R127 P42 survival/patch checks pass 4/4.

Confirmed P42 restoration carried forward: source page 685 / source PDF page 7 prints the trace ideal in the Satz 1 proof and following remark as `Sp(\widetilde a a)`. The current base still had three corresponding occurrences as `Sp(a\widetilde a)`. The package changes only those three loci and keeps the no-fix trap that earlier plain `a\widetilde a` contexts must not be globally rewritten.

Evidence packaged: R127+P22+P30+P37 authority-before-P42 TeX/PDF; patched cumulative TeX/PDF; P42 before/after TeX spans; before-vs-after diff; carried-forward confirmed-fix and no-fix-trap ledgers; patch survival checks; span hash/boundary CSV; prior P42 logbook snapshot/README; compact RA10 source PDF; and the targeted 1000dpi crop/microcrop for the source-order locus.

Source-quality caveat: this is a best-available surgical source-critical patch, not strict native-650 full-paper certification. The available local source cutout embeds page images at 2048 x 3322, recorded as 360 ppi. The 1000dpi crop is a readability enlargement of the source locus and does not create higher native optical evidence. Reopen if a better native 650+ Paper 42 witness appears, a concrete source-vs-TeX defect is found, or a later cumulative changes the P42 span.

Instruction carried forward: use the R127+P22+P30+P37+P42 patched cumulative as the current German base for Web integration. Do not replay the stale `Sp(a\widetilde a)` readings at the three source p685 trace-order loci, and do not perform a global `a\widetilde a` replacement elsewhere.

## 2026-06-25 - R127+P22+P30+P37+P42 P41/P43 source-restoration survival check

Package: `Noether_R127_LocalCodex_P41_P43_SourceRestorationSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: after closing the P42 patch, I rechecked the prior P41/P43 source-restored reference slices from `Noether_R126_LocalCodex_P41_P43_SourceRestorationSurvival_NoNewPatch_WebDrop_20260625` against the current cumulative `cum_de_R127_plus_localcodex_P22_P30_P37_P42_sourcefix_20260625.tex`.

Result: no new patch. P41 matches its source-restored reference slice exactly. P43 also matches its source-restored reference slice exactly when compared as the paper-length slice; the current cumulative contains later appended material after P43, so that later material is excluded from the P43 paper comparison.

Evidence packaged: current cumulative TeX/PDF authority, current paper-length P41/P43 slices, prior P41/P43 source-restored reference slices, zero-byte diff files for both comparisons, and a machine-readable survival disposition CSV.

Instruction carried forward: do not replay older P41/P43 fixes against this cumulative. The prior source-restoration edits survive in the current R127+local base.

## 2026-06-25 - R127+P22+P30+P37+P42 P35/P36/P38 disposition

Package: `Noether_R127_LocalCodex_P35_P36_P38_Disposition_P38NoPatch_P35P36Review_WebDrop_20260625.zip`.

Context: I compared older LocalCodex P35/P36/P38 reference slices against the current R127+P22+P30+P37+P42 cumulative. This was a stale-reference audit, not a fresh source-image pass.

Result: no cumulative patch. P38 matches the prior source-repaired section reference exactly, so its earlier repair survives. P35 and P36 differ from the older reference slices, but the diffs are not safe to apply blindly. In P35, the current R127 section contains additional source apparatus and Russian summary material that the older shorter reference would delete. In P36, the mismatch is a small bibliographic/numbering disagreement that needs source review before any correction.

Evidence packaged: current cumulative TeX/PDF authority, current P35/P36/P38 section slices, older prior reference slices, comparison diffs, per-paper comparison CSV, and action-disposition CSV.

Instruction carried forward: treat P38 as survived/no patch. Do not apply the older P35/P36 prior reference slices as replacements; if Web wants to settle those, it should review against the best source witness directly.

## 2026-06-25 - R127+P22+P30+P37+P42 P05/P06/P07/P08 survival check

Package: `Noether_R127_LocalCodex_P05_P08_SourceRepairSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: after the fixed Web R127 rebuild and the local P22/P30/P37/P42 cumulative patches, I rechecked P05--P08 against the locally audited R126+P08Omega anchor cumulative. The first attempted comparison used old audit span files that included line-number prefixes; I discarded that noisy comparison and redid the check from the actual TeX anchor.

Result: no new patch. P05, P06, P07, and P08 all match the locally audited anchor spans exactly in the current R127+P22+P30+P37+P42 cumulative. In particular, the P08 p100 Omega-process repair survives: the source-visible middle equality and the `*)` note marker/body placement remain present.

Evidence packaged: current cumulative TeX/PDF authority, current P05--P08 spans, reference P05--P08 spans from the R126+P08Omega anchor, four zero-byte diff files, action-disposition CSV, clean survival-comparison CSV, prior source-quality/repair ledgers, source PDFs, and targeted P05 650dpi, P06 650+/1000dpi, P07 1000dpi, and P08 1000dpi source witnesses.

Source-quality caveat: this is targeted survival/anti-regression work, not a fresh glyph-by-glyph global certification of P05--P08. The included witnesses document the earlier source-critical loci and source-quality caveats.

Instruction carried forward: do not replay older P05--P08 fixes against this cumulative. The prior P05--P08 source/audit edits survive in the current R127+local base.

## 2026-06-25 - R127+P22+P30+P37+P42 P01 source repair and P02/P03/P04 survival check

Package: `Noether_R127_LocalCodex_P01_SourceRepair_P02_P04Survival_WebDrop_20260625.zip`.

Context: after closing P05--P08, I checked the remaining early-paper R126-era packages P01--P04 against the current R127+P22+P30+P37+P42 cumulative. P02, P03, and P04 matched their locally audited R126+P08Omega anchor spans exactly. P01 did not: the fixed R127 base still contained an invented `Von Emmy Noether.` heading line and the stale `bzw. durch` table reading.

Result: patched TeX produced. I applied only the two source-confirmed P01 repairs: restored the source heading order (title, journal citation, then `(Auszug aus der Dissertation der Verfasserin.)`, with no author line) and changed the Faltung table row from `bzw. durch` to source `resp. durch`. The output cumulative is `tex/cum_de_R127_plus_localcodex_P01_P22_P30_P37_P42_sourcefix_20260625.tex`. XeLaTeX pass 1 and pass 2 both succeeded locally; the compiled German cumulative PDF has 468 pages. The P01/P02/P03/P04 package checks pass 7/7.

Evidence packaged: R127+P22+P30+P37+P42 authority-before-P01 TeX; patched cumulative TeX/PDF/log; P01 before/after TeX spans; P01 before-vs-after diff; P01--P04 action-disposition CSV; P01--P04 patch/survival checks; clean comparison CSV and zero-byte P02/P03/P04 diffs; prior source-quality/repair ledgers; P01 source PDF plus 650dpi heading/page witnesses and 1000dpi dense math/table crops; and targeted P02--P04 source witnesses/source PDFs from their earlier survival passes.

Source-quality caveat: P01 patch loci are backed by the prior source recheck package with 650dpi page witnesses and 1000dpi dense table/math crops. P02--P04 are targeted survival/anti-regression checks, not fresh glyph-by-glyph global certifications.

Instruction carried forward: use the R127+P01+P22+P30+P37+P42 patched cumulative as the current German base for Web integration. Do not reinsert the P01 author line or change `resp. durch` back to `bzw. durch`. Do not replay older P02--P04 fixes against this cumulative; their prior source/audit edits survive.

## 2026-06-25 - R127+P01+P22+P30+P37+P42 P24/P25/P27/P29/P30 middle-band current survival reconciliation

Package: `Noether_R127_LocalCodex_P24_P30_MiddleBandCurrentSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: after confirming the fixed Web R127 rebuild (`Noether_R127_REBUILT_20260625.zip`, SHA256 `0F2E740924671F0C32E66524BC887DC8567B5CF3D9C0D920ACFE8AFCBB218497`) and applying the local P01/P22/P30/P37/P42 patches, I reconciled the current P24--P30 middle band against the prior middle-band guardrail package `Noether_R125_LocalCodex_P21_P30_MiddleBand_Reconcile_WebDrop_20260625`, the P29 GDZ400 survival package, and the P30 source-restoration package.

Result: no new TeX patch. The current cumulative already preserves the known source-confirmed middle-band readings: P24 has `x_1,\ldots,x_{i-1}` and `E^{(i)}\zeta_0`; P25 has `\overline{\mathfrak R}` at the Galois-field line; P27 has plain italic `q`, `p`, `q/p`, not fraktur; P29 still has the prior source-header/footnote-reset survival state and no placeholder markers; and P30 still has the source-restored anchors from the Paper 30 repair chain, including the corrected Krull citation, module-basis endpoint, restored p031 clause, p043 exponent product, p049 even-integers example, and p051 power-chain condition.

Evidence packaged: current cumulative TeX authority, current P24--P30 span, machine-readable survival checks, no-patch disposition CSV, fixed-R127 payload check, prior middle-band trap ledgers, P29/P30 source-quality ledgers, P30 confirmed-fix rollup, and compact targeted source witnesses for the P24/P25/P27 trap loci.

Source-quality caveat: this is an anti-regression/current-survival package, not a new blanket page-by-page certification. P24 trap loci use 650dpi source witnesses; P25/P27 staged source evidence is 600ppi and therefore below the strict 650 floor but visually clear for the narrow glyph/overbar fixes; P29 and P30 current best staged sources are about 400ppi and must remain labeled best-available-below-650 until a better source appears.

Instruction carried forward: use `cum_de_R127_plus_localcodex_P01_P22_P30_P37_P42_sourcefix_20260625.tex` as the current German base. Do not regress P24 to `x_i,\ldots,x_{i-1}` or `E_0^{(i)}\zeta_0`; do not remove the P25 overbar; do not frakturize P27 `q/p`; do not use the misnamed `noether_p29_ia_source_20260623` folder as P29 source, because it is Paper 24 material; and do not replay stale P30 readings such as `S. 181--218`.

## 2026-06-25 - R127+P01+P22+P30+P37+P42 P31/P32/P33/P34 upper-band current survival reconciliation

Package: `Noether_R127_LocalCodex_P31_P34_UpperBandCurrentSurvival_NoNewPatch_WebDrop_20260625.zip`.

Context: continuing from the same current cumulative, I checked the P31--P34 upper-band status against the prior upper-band reconciliation package `Noether_R125_LocalCodex_P31_P43_UpperBand_Reconcile_WebDrop_20260625` and its carried R124plus upper-band ledgers. I used the old package only as a survival/trap ledger, not as a line-number authority, because the current R127+local cumulative has shifted line numbers.

Result: no new TeX patch. The current P31 and P32 spans have titles present and no obvious TODO/MISSING placeholders, but remain locator/gross-gap-only rather than symbol-certified. P33 preserves the targeted fraktur-group repair (`\mathfrak{G}` rather than plain `G`). P34 preserves the targeted discriminant/product-table repair, including `l_1`, `l_2`, and `D_{\rm red}=e`.

Evidence packaged: current cumulative TeX authority, current P31--P34 span with line numbers, current survival checks, no-patch disposition CSV, and prior upper-band ledgers for web instruction, source-quality limits, open-scope register, and supersession/trap notes.

Source-quality caveat: this package does not perform a new source-image pass. P31/P32 remain gross-gap locator evidence only; P33 is a narrow targeted repair survival; P34's table/discriminant repair survives, but broad P34 full-page high-fidelity certification remains open.

Instruction carried forward: do not replay P31/P32 as missing from locator rows alone; do not revert P33 to plain `G`; do not redo the P34 discriminant/product-table patch as if absent. The residual work for this band is broad source certification only, not reapplying already-surviving exact repairs.

## 2026-06-25 - R127 LocalCodex queue reconciliation index for Web

Package: `Noether_R127_LocalCodex_CurrentQueueReconciliation_Index_WebDrop_20260625.zip`.

Context: after confirming the fixed 50 MB Web R127 rebuild and producing the P24--P30 and P31--P34 current-survival drops, I prepared a compact index so the Web session can see which R127 source-queue rows have already been addressed by local packages and which remain genuinely open.

Result: no TeX patch. The index maps R127 queue rows to current LocalCodex packages/statuses and distinguishes patched, no-patch best-available disposition, no-patch survival, stale-reference disposition, and still-open broad-audit lanes. It includes the current German cumulative TeX only as the current continuation base, not as a new edition fork.

Main routing decisions recorded: P09--P12 have best-available full-page disposition packages but are not strict native-650 certification; P22/P30/P37/P42 are source-restoration/targeted patch lanes already applied into the current cumulative; P24--P30 and P31--P34 are current-survival no-patch lanes; P35/P36 require direct source review rather than stale-reference replacement; P38/P41/P43 survive; Tail/post-P43 remains genuinely open.

Instruction carried forward: Web should use the index as a routing sheet. Do not reopen a paper just because R127's original source queue still lists it; reopen only where the index says broad certification remains open, a better source appears, or a concrete source-vs-TeX defect is identified.

## 2026-06-25 - R127 fixed 50 MB zip verified; tail/Kapferer reconciliation no-patch drop

Package: `Noether_R127_LocalCodex_TailKapferer_Reconciliation_NoNewPatch_WebDrop_20260625.zip`.

Context: Web replaced the broken tiny `Noether_R127_20260625.zip` with `Noether_R127_REBUILT_20260625.zip`, a real 52,004,966 byte package. I verified that the fixed zip contains the cumulative German TeX/PDF, source queue, complete ledger, P35 slice, P35 source witnesses/crops, render checks, and provenance. SHA256: `0F2E740924671F0C32E66524BC887DC8567B5CF3D9C0D920ACFE8AFCBB218497`.

Result: no new TeX patch. I reconciled the current R127+LocalCodex cumulative (`cum_de_R127_plus_localcodex_P01_P22_P30_P37_P42_sourcefix_20260625.tex`) against the existing local tail/Kapferer packages. The Kapferer/Noether Math. Ann. 97 article span is byte-identical between the current cumulative and the complete Kapferer candidate. Section 39 (`Hyperkomplexe Systeme...`) is also byte-identical between the current cumulative and the older tail candidate.

Important anti-regression finding: the older broad `section 40 to Kapferer` tail candidate must not be applied wholesale to the current cumulative. It would regress the current source-backed P42 `Sp(\widetilde a a)` readings to stale `Sp(a\widetilde a)` readings and also carries broad formatting/provisional differences. Its confirmed-fix ledgers remain useful as source leads, but the candidate span is not a safe replacement layer on top of the current R127+local base.

Evidence packaged: current cumulative TeX, fixed-R127 README/source queue/ledger/TeX copy, span comparison CSV, R127 tail queue disposition CSV, no-patch reconciliation CSV, current/candidate span extracts, diffs, prior p713--p746/p747--p763/Kapferer source-quality and confirmed-fix ledgers, and logbook snapshot.

Source-quality caveat: this is a routing/reconciliation package, not a strict optical certification. The older Deuring tail witnesses are best-available native about 360ppi and the Kapferer witnesses are best-staged GDZ about 400dpi. Reopen only if a stronger source appears or a concrete source-vs-TeX defect is identified.

Instruction carried forward: use the current R127+P01+P22+P30+P37+P42 cumulative as the active German base. Do not replace the current Section 40/P42 material with the older p713--p763 candidate wholesale. Treat Kapferer as already present in the current cumulative unless Web discovers a concrete regression. The remaining tail question is limited to collected-volume post-Kapferer bibliography/end matter if the corpus wants that represented and source-audited.

## 2026-06-25 - R127 P09--P20 non-overlap lane status index after fixed Web zip

Package: `Noether_R127_LocalCodex_P09_P20_NonOverlapLane_StatusIndex_WebDrop_20260625.zip`.

Context: Web supplied the fixed 52,004,966 byte `Noether_R127_REBUILT_20260625.zip` after the earlier tiny broken zip. I verified the fixed zip again and built a compact P09--P20 routing package against the current LocalCodex cumulative `cum_de_R127_plus_localcodex_P01_P22_P30_P37_P42_sourcefix_20260625.tex`.

Result: no new TeX patch. The package consolidates the P09--P20 non-overlap lane as a Web-readable status index rather than another image batch. It records which LocalCodex Web-drop package covers each paper or paper group, the associated zip hash/size, source-quality caveats, and exact reopen rules.

Main routing decisions recorded: P09, P10, P11, and P12 have best-available full-page/no-patch dispositions; P12's prior bad fix remains rejected; P13 has 23 survival checks passing; P14--P16, P17--P18, and P19--P20 have best-available survival/no-patch dispositions. None of these rows should be treated as missing merely because an older queue or locator mentions them.

Source-quality caveat: this is a status/routing consolidation, not a fresh universal page-by-page 650+ dpi symbol certification. P09--P20 include mixed source quality; some loci have 1000dpi targeted crops, but several full-paper witnesses are best-available lower-native material. Reopen only for a concrete source-vs-current-TeX mismatch, a Web-side failing anchor, or a stronger raw source witness.

Instruction carried forward: Web should use this package to avoid replaying stale P09--P20 queue work. If it needs source images, use the named full LocalCodex packages; the compact index intentionally includes ledgers, summaries, and the current cumulative TeX but not bulk images.

## 2026-06-25 - R127 P21/P23 survival bridge with P22 patch context

Package: `Noether_R127_LocalCodex_P21_P23_SurvivalBridge_P22PatchContext_WebDrop_20260625.zip`.

Context: P21 and P23 were present as survival/no-patch spans inside the P22 source-restoration package, but not as a standalone Web-readable bridge. I extracted the status so Web does not treat P21/P23 as missing or redo them only because they sit beside patched P22.

Result: no new TeX patch. P21 remains no-patch survival only; known anchors survived rebuilt R127/current local base. P22 remains the patch-bearing item, already represented in the current cumulative. P23 remains no-patch survival only; the footnote reset and `f(x,d x)=g(y,d y)` state survive, while the stale `\varphi(y,dy)` reading remains absent.

Evidence packaged: P21 and P23 survival spans, P21/P22/P23 survival-and-patch CSV, no-fix trap CSV, P22 source-quality and confirmed-fix ledgers, P22 README context, current active cumulative TeX, and SHA256 manifest.

Source-quality caveat: P21/P23 evidence here is survival/anti-regression evidence, not a fresh global source-image certification. P22 carries its prior explicit mixed-source caveat.

Instruction carried forward: do not replay stale P21/P23 queue work. Reopen only for a concrete source-current mismatch or a stronger source witness. Do not revert P22 to R127's flattened title/note/rho-block structure.

## 2026-06-25 - P35 MathNet 600ppi source upgrade, no patch

Package: `Noether_R127_LocalCodex_P35_MathNet600_SourceUpgrade_NoPatch_WebDrop_20260625.zip`.

Context: the R127 P35/P36/P38 disposition left P35 as requiring source review because the old prior repaired P35 slice was shorter than current R127 and would remove source apparatus/Russian summary material. I searched online and found the MathNet full-text endpoint for P35 (`sm7340`).

Source found: `https://www.mathnet.ru/php/getFT.phtml?jrnid=sm&paperid=7340&what=fullt&option_lang=eng`. Downloaded file: `Noether_P35_MathNet_sm7340_fulltext.pdf`, SHA256 `48766CF7AC43D82A601ABE40F59E91A908731F5E30C7E9C5DD75EBA5185C03A2`. `pdfimages -list` reports eight embedded CCITT page images at nominal 600x600 ppi. This is an upgrade over the R127 P35 native 2048x3322 approximately-360ppi pages, though still below the strict 650+ preference.

Result: no new TeX patch. The MathNet PDF confirms that the Russian summary and closing `(Rec. Math. XXXVI:1; 1929)` are source-backed, so the current R127 P35 extra material is not hallucinated apparatus. The older shorter prior repaired P35 reference must not be applied wholesale.

Evidence packaged: MathNet 600ppi PDF, current P35 TeX span, stale prior P35 reference clearly labeled do-not-apply-wholesale, old/current diff and disposition ledgers, `pdfinfo`, `pdfimages -list`, a `pdftotext` tail locator for the Russian summary, source-upgrade verdict CSV, and logbook snapshot.

Source-quality caveat: this improves the P35 source witness and routing but does not certify every P35 symbol page-by-page. Use the MathNet PDF as the preferred staged source for future exact-symbol checks until a true 650+ native or raw image source is found.

## 2026-06-26 - R127 P34 table/Dred anti-regression, no patch

Package: `Noether_R127_LocalCodex_P34_TableDred_AntiRegression_NoNewPatch_WebDrop_20260626.zip`.

Context: after the fixed Web R127 rebuild, P34 remained in older source queues because the earlier P34 table/discriminant defect was severe. I checked the current R127+LocalCodex cumulative against the best staged GDZ/EuDML Math. Z. 30 (1929) page images for printed pp. 690--691.

Result: no new TeX patch. The current cumulative already preserves the repaired source-style matrix-ring product table, the discriminant determinant and two-case display, the Folge formulas including `D_{\rm red}=e`, and footnote 22 with the J. f. M. 157 reference. The exact checked current TeX block is packaged separately for Web.

Source-quality caveat: the best local/open P34 witness found here is optical about 400 ppi. The included crops are enlarged for readability and may carry PNG metadata near 1000 ppi, but they are not true 1000 ppi source authority. This package is therefore an anti-regression check for the known P34 defect cluster, not a complete 650+ ppi certification of all P34.

Instruction carried forward: do not replay the old missing-table fix as if it is still missing, and do not flatten the product table back into prose or scalar formulas. Reopen P34 only if Web finds a concrete source-current mismatch outside this checked cluster or a genuinely stronger source witness appears.

## 2026-06-26 - R127 tail bibliography/endmatter source fixes

Package: `Noether_R127_LocalCodex_TailBibliography_SourceFix_WebDrop_20260626.zip`.

Context: after reconciling R127 against local packages, the genuinely open tail item was not Deuring pp. 713--763 or the Kapferer/Noether Math. Ann. article, both of which already have repair packages. The remaining collected-volume tail was the post-Kapferer bibliography/endmatter. I checked the current cumulative against the R101 source-gap slice for source PDF pp. 787--791 / collected pp. 773--777.

Result: three source-confirmed cumulative TeX fixes were applied and compiled successfully. Bibliography item 34 now uses the source label `34:`; the Study book-review entry now has `E. Study, Einleitung ...`; and the Dedekind book line now reads `R. Fricke, E. N. Öystein Orne` without the extra comma after `E. N.`.

Source-quality caveat: `pdfimages` reports the endmatter pages as embedded 2048x3322 images at 360x360 ppi. I rendered the pages at 650 dpi for visual checking, but this does not upgrade the optical source. This is a source-confirmed endmatter patch, not strict 650+ optical certification of the whole tail.

Instruction carried forward: source PDF pp. 792--794 are publisher ads/backmatter and pp. 795--796 are blank/end leaves. Do not treat them as missing Noether mathematical text unless project policy explicitly decides to reproduce publisher ads.

## 2026-06-26 - R127 P40 prior-complete survival check, no patch

Package: `Noether_R127_LocalCodex_P40_PriorCompleteSurvives_NoNewPatch_WebDrop_20260626.zip`.

Context: P40 still appeared in older R127 queue material, but a full local source-repair package already existed from the R124 phase (`Noether_R124plus_LocalCodex_P40Complete_WebDrop_20260624`). I compared the Paper 40 span in the current active cumulative after tail-bibliography fixes against the final span from that prior P40Complete package.

Result: no new TeX patch. The current P40 span is byte-identical to the prior P40Complete span. Both extracted spans have SHA256 `A22D951A2062E30C571198AEF25EAEB90C382E3D1653A77C7C710C0964871B04`, and the span diff is empty.

Source-quality caveat: the prior P40 repair used the best staged local GDZ Math. Z. 37 source witness at about 400 ppi. That is below the standing 650+ ppi source-checking rule and below the 1000+ preference for dense mathematics. This package is therefore a survival/anti-regression routing check, not final strict high-resolution certification of every P40 symbol.

Instruction carried forward: do not replay old P40 diffs or treat P40 as missing merely because it is in an older queue. Reopen only if Web finds a concrete current-source mismatch or if a stronger source witness appears.

## 2026-06-26 - R127 current queue reconciliation index v2

Package: `Noether_R127_LocalCodex_CurrentQueueReconciliation_Index_v2_WebDrop_20260626.zip`.

Context: the original R127 queue still listed P34, P40, and tail material in a way that was stale after the later LocalCodex drops. I built a compact routing index against the fixed 52 MB `Noether_R127_REBUILT_20260625.zip` and the current cumulative `cum_de_R127_plus_localcodex_P01_P22_P30_P37_P42_tailbibliographyfix_20260626.tex`.

Result: no new TeX patch. The package gives Web a machine-readable status map separating source-confirmed integrated patches, no-patch survival/anti-regression checks, best-available lower-resolution dispositions, and genuinely separate global 650+ page-certification work.

Main updates recorded: P34's known product-table/discriminant/`D_{\rm red}=e` defect cluster is current and should not be replayed; P40's prior complete repair survives byte-identically; and the remaining tail bibliography/endmatter has three source-confirmed fixes already integrated. P35/P36 are explicitly marked as 600ppi best-staged source dispositions below the strict 650+ preference, and P41/P43 as survival checks rather than full global certification.

Instruction carried forward: Web should read `audit/R127_queue_to_localcodex_status_index_v2.csv` before acting on old source-queue rows. Do not confuse broad future page-by-page certification with a concrete missing-text or stale-diff repair.

## 2026-06-26 - R127 P04 pp. 140--145 GDZ600 source upgrade, no patch

Package: `Noether_R127_LocalCodex_P04_GDZ600_pp140_145_SourceUpgrade_NoNewPatch_WebDrop_20260626.zip`.

Context: the fixed 52 MB R127 rebuild still listed `R120-Q-P04` as an active source-comparison queue item for P04 printed pp. 140--145. The older RA40 witness images for this locus were small rendered pages and therefore not adequate as source authority under the current source-quality rule.

Source found and staged: GDZ IIIF raw page JPEGs for Crelle/JRAM 139, canvases `00000144`--`00000149`, corresponding to P04 printed pp. 140--145. The staged files are 3888x5649 with 600x600 ppi metadata. This is an upgrade over the old RA40 renders but still below the strict 650+ optical rule; the enlarged 1000-dpi-labelled crops are readability aids made from the 600 ppi source, not true 1000 ppi authority.

Result: no new TeX patch. The active cumulative already has the old critical P04 anchors right: formula (45) has the `\sigma\ge\tau` condition and the `\lambda=1,2,\ldots,\sigma,n-\tau` range; formula (46) has the corresponding `\tau,n-\sigma` range; p143 has the `\sigma\ge\tau` side condition and the prime on `p_{n-\tau-\beta}`; formula (57) has equality to `\Delta`; and formulas (59)--(61) are present at the checked anchors.

Instruction carried forward: do not replay stale P04 pp. 140--145 fixes against the current cumulative. Reopen only for a concrete source-current mismatch or if a genuinely stronger native 650+ source appears.

## 2026-06-26 - R127 current queue reconciliation index v3

Package: `Noether_R127_LocalCodex_CurrentQueueReconciliation_Index_v3_WebDrop_20260626.zip`.

Context: after the fixed 52 MB R127 rebuild was confirmed real, and after the P04 GDZ600 no-patch source-upgrade package was made, the previous queue reconciliation index needed one routing update so Web does not keep treating P04 pp. 140--145 as unresolved merely because it appears in the inherited R127 queue.

Result: no new TeX patch. The v3 index carries forward the current active cumulative after LocalCodex tail-bibliography fixes and updates the P04 row to point at `Noether_R127_LocalCodex_P04_GDZ600_pp140_145_SourceUpgrade_NoNewPatch_WebDrop_20260626.zip`.

Instruction carried forward: use the v3 queue index as the first routing file before acting on stale R127 queue rows. It is not a global page-by-page certification; it is a conflict-prevention and stale-diff prevention ledger.

## 2026-06-26 - General Noether source-library split v1

Packages:

- `Noether_GeneralSourceLibrary_v1_20260626_MANIFEST.zip`
- `Noether_GeneralSourceLibrary_v1_20260626_part01_core_collected_tail.zip`
- `Noether_GeneralSourceLibrary_v1_20260626_part02_ia_mathann_96.zip`
- `Noether_GeneralSourceLibrary_v1_20260626_part03_ia_mathann_83_85_90.zip`
- `Noether_GeneralSourceLibrary_v1_20260626_part04_targeted_recent.zip`

Context: the working-drop ZIPs were becoming too overloaded. The user asked for stable project-level source files under 500 MB each, so Web can use source witnesses from the project source area instead of being forced to re-upload or sort through many GB each turn.

Result: source witnesses are now split from working/audit drops. v1 includes the collected-volume source PDF, tail article/source cutouts, IA Mathematische Annalen host-volume witnesses for volumes 83, 85, 90, and 96, plus recent targeted witnesses such as P04 GDZ600 raw pages/crops and other source-only recent material. The source-library manifest records every included file with source path, byte size, SHA256, role, and notes.

Instruction carried forward: per-turn Web drops should stay small and current-TeX/audit focused. Durable source material should go into source-library chunks and be referenced by manifest. This source library is v1, not an exhaustive guarantee that every Noether source witness on disk has been deduplicated and packaged.
