# Codex Alpha task spec — Route-A F10 writeback candidate pass v1

Scope: use `INTERLANGUAGE_CONNECTION_FRAMEWORK_v4_3_ROUTE_A_REVIEW_20260705.zip` to convert route-A under-witnessed rows from review-only to candidate concept-shelf writeback where warranted.

## Inputs

1. `TAIL_ROUTE_A_FULL_TERM_ACTION_QUEUE_v3_20260705.csv`
2. `TAIL_ROUTE_A_FULL_WS_POLICY_v3_20260705.csv`
3. `TAIL_A_HIGH_VOLUME_WS_CURATED_TERM_WRITEBACK_QUEUE_v2.csv`
4. `ws_witness_backfill_v1_20260704.json`
5. Current production F10 audit / retrofit ledger.

## Allowed actions

- For rows with `term_action = candidate_F10_writeback_after_Noether_source_row_check`, inspect the source row context and confirm the German/source term instantiates the route-key concept.
- If confirmed, add a concept-shelf witness annotation to the term row:
  - `witness_writeback.level = concept_shelf`
  - `witness_writeback.source = ws_witness_backfill_v1`
  - `witness_writeback.concept = route_key`
  - `witness_writeback.west = true` where W support exists
  - `witness_writeback.south = true` where S support exists
  - `witness_writeback.boundary = source-family witness, concept-shelf, not bridge certification`
- Recompute F10 flags but preserve pre-writeback archaeology.

## Forbidden actions

- Do not change Interslavic prose.
- Do not promote terms to `reviewed_for_bridge_use`.
- Do not collapse support and competitor evidence.
- Do not bulk-write W1/W3/W5 rows.
- Do not use generated/draft material as target-language witness.

## Band interpretation

- W0: writeback candidate after source-row concept check.
- W1: support + competitor; leave for variant-policy review.
- W3: competitor-only; adverse channel / review packet only.
- W4: unclear; no action.
- W5: C2 windows only; context review first.

## Expected outputs

1. `F10_ROUTE_A_WRITEBACK_APPLIED_v1.json/csv` — only rows actually updated.
2. `F10_ROUTE_A_WRITEBACK_REJECTED_v1.json/csv` — source rows that failed concept check.
3. `F10_ROUTE_A_WRITEBACK_SUMMARY_v1.md` — before/after counts, branch-mass projection, and unchanged boundaries.
4. Updated F10 audit as a new version; do not overwrite frozen baselines.
