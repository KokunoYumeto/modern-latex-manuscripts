# Codex Alpha / Codex Beta / Fable routing plan v1

This plan treats Codex Alpha as the local production/merge instance, Codex Beta as the other-PC source-body producer, and Fable as the local synthesis/row-review layer. Floris gates external sending/publication only, not language decisions.

## Codex Alpha
Primary local production/coordination instance; owns production tree, corpus-wide patches, rendered outputs, and final merge discipline.

### Do now
- Consume NORMALIZATION_BATCH0_ORTHOGRAPHY patch only after regenerating it line-wide and idempotently on translations/ only; never patch renders/ directly.
- Consume NORMALIZATION_BATCH1_DRYRUN only as dry-run locator; apply only APPLY1 rows after TeX-aware line review and Latin/Cyrillic sync generation.
- Merge INTERLANGUAGE_CONCEPT_WEB_v2 as evidence map input, not as terminology authority.
- Maintain Source Use Policy categories on every merge: concept normalization, native witness, draft/generated consistency, adverse evidence, external review.
- Keep branch weighting states frozen by state label: baseline, row-reviewed writeback, candidate projection. Do not headline state-D projections.

### Do not
- Do not ask Floris to adjudicate languages.
- Do not push to git or publish; Floris only gates external sending/publication.
- Do not treat generated ISV/UK/RU TeX as W/S native witness evidence.

## Codex Beta
Other-PC source-body producer and source-canon coordination instance.

### Do now
- Export native source-body packages with a manifest that separates native_source_body, OCR/extracted witness, draft/generated, scaffold, and source-canon files.
- For each package include manifest.csv/json with sha256, file count, language hint, source_use_category, and extraction method.
- For CJK/Arabic/Romance/Persianate source bodies, emit KWIC windows with non-null concept_id, language, form, source_path, and context window.
- Do not label generated audit files as native-source-body; CJK SOURCE_BODIES.csv already had that defect once.

### Do not
- Do not emit candidate rows with null route_key/lang/form.
- Do not use generic stems for witness discovery without a math-genre filter.
- Do not promote bridge terms; source bodies feed evidence, not construction decisions.

## Fable
Local synthesis/review layer; validates row senses, rejects false positives, and writes human-readable coordination reports.

### Do now
- Read this concept web as the current cross-language map, then row-review the high-priority concepts and false-sense/adverse edges.
- Continue sense audits of source-body candidates before they enter C2 fill ledgers.
- Use the normalization action bands, not user questions, for Codex Alpha patch routing.
- Maintain the distinction between internal triangulation and external review.

### Do not
- Do not gate linguistic decisions on Floris; escalate to expert layer or mark human-authority-needed.
- Do not collapse support and adverse evidence into one scalar.
- Do not overwrite frozen baselines.

## Shared next high-value tasks
- **Concept-web v3 densification** — owner: Codex Alpha + ChatGPT; input: INTERLANGUAGE_CONCEPT_WEB_v2; output: marker table v4 with label/source_cue separation preserved.
- **CJK/Arabic sourcebody candidate merge** — owner: Fable; input: CJK lane table + Arabic sense-audited ledgers; output: C2 fill ledgers with confirmed/gap/rejected statuses.
- **Route A/C tail per-concept probes** — owner: ChatGPT or Codex Beta; input: TAIL_WITNESS_ROUTING_v1 routes A+C, distinctive stems only; output: row-reviewed KWIC candidates with concept_id/lang/form non-null.
- **Batch-0 and Batch-1 production-safe patch dry-run** — owner: Codex Alpha; input: patch proposals + validation conditions; output: translations-only diffs + Latin/Cyrillic sync check.
- **Noether-stratum specialist source intake** — owner: Codex Beta or Fable; input: NOETHER_STRATUM_SOURCE_INTAKE_PLAN; output: specialist source bodies for invariant-theory terms.
