# Release notes

This package is the current derived-artifact state after the unified marker automaton v6.2 and multilane framework v5 passes. It is intended to be pushed by Codex Alpha while token-constrained Fable sessions remain inactive.

## Included highlights

- Unified marker/evidence automaton v6.2.
- Multilane weighted framework v5.
- Interslavic State-C automaton reconciliation and State-C+W0 projection.
- Target-review decisions and cheap-review pass.
- Pan-Romance weighted automaton.
- Non-Slavic weighted automata for CJK, Arabic/RTL/Persianate, Turkic-frontier.
- Global math-register comparator, concept-history layer, predictive model, originating-reflections digest.
- Normalization patch proposals and Codex-safe apply specs.
- Source-body archive indexes for the large source dumps.

## Not included

The raw source bodies themselves are not embedded except as small derived packages already present inside selected zips. Use the source-archive manifest to attach or preserve large source-body packages separately.
