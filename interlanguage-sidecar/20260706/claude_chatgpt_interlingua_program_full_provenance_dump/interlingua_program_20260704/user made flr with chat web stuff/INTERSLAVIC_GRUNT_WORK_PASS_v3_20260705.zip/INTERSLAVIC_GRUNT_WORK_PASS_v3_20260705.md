# Interslavic grunt work pass v3

Generated 2026-07-05.

This pass continues the F10/weighted-automaton grunt work rather than summarizing it. It fixes the automaton row-identity issue, creates a current State C + W0 projection layer, and splits the remaining Route-A tail into concrete review/writeback queues.

## Included artifacts

| artifact                         | zip                                                                   | purpose                                                                                                                                                              |
|:---------------------------------|:----------------------------------------------------------------------|:---------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| State C + W0 automaton v3        | INTERSLAVIC_WEIGHTED_AUTOMATON_STATE_C_PLUS_W0_v3_20260705.zip        | Rebuilds current Interslavic weighted automaton with stable row_uid, State C canonical branch masses, W0 filtered candidate projection, duplicate-ID map, and edges. |
| W1 variant-policy packet         | INTERSLAVIC_W1_VARIANT_POLICY_PACKET_v1_20260705.zip                  | Batches 148 support+competitor Route-A rows into field/set/proof/variant-note policy queues; no bulk writeback.                                                      |
| W3/W4/W5 review/probe packet     | INTERSLAVIC_W3_W4_W5_REVIEW_AND_TARGETED_PROBE_PACKET_v1_20260705.zip | Routes ring, theorem, corollary, coefficient, equation, relation, direct sum into adverse/review/targeted-backfill queues.                                           |
| W5/W4 C2 context-backfill packet | INTERSLAVIC_W5_W4_C2_CONTEXT_BACKFILL_PACKET_v1_20260705.zip          | Extracts native W/S C2 context windows for W5 and W4 concepts and creates concept-level actions.                                                                     |

## Key numbers

- Current quotable State C: E=2341, W=223, S=239, D1=1.753704.
- W0 filtered projection after source-row context check: E=2341, W=333, S=348, D1=1.993192.
- W0 filtered rows: 182 term IDs; 110 rows add new W/S support in the projection.
- W0 held rows: 52.
- W1 rows split into variant policy: 148.
- W3/W4/W5 non-writeback rows: 111.
- W5/W4 C2 context packet: 71 windows over coefficient, equation, relation, direct sum, theorem, corollary.

## Boundary

No production text was changed. No term was certified. All support/competitor/adverse/gap/candidate channels remain separate.
