# Task note: mine/use the big dump outputs

Use `BIG_DUMP_CONCEPT_WEB_MINE_v1_20260705.csv` as the current mined concept worklist. Do not treat source-body hits as certification.

High-value next units:
1. For rows marked `P0 sense-audit trap`, pull KWIC windows and decide false-sense vs valid specialized sense.
2. For `P2_specialist_source_intake`, map to Noether-stratum source plan; do not fill from general shelves.
3. For rows with many source-body hit rows but no global attractor, add concept-history residual notes: why fragmented despite source coverage.
4. Codex Alpha should merge only rows with row-reviewed/witnessed statuses; Codex Beta should continue source-body harvesting and manifests.
5. Fable should turn `BIG_DUMP_MINING_WORKLIST` into review queues, not prose claims.
