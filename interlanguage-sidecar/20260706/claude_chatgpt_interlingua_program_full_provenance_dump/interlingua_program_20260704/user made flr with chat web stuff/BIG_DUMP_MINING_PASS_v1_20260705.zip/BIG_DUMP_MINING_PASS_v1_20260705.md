# Big dump / all-lanes mining pass v1
Generated 2026-07-05. Scope: interlingua program dump, source-anchor bundles, OtherPC source bodies, and language-family source-body zips. This is a mining/index/probe layer, not a certification layer.
## Archive inventory
- Archives indexed: **17**
- Source-file candidates: **13818**
- High-value artifact-name hits: **786**
- Source-hook lines sampled: **16136**
Top archives by text-like entries:
- `Interlanguage_NonSlavic_SourceAnchors_EXPANDED_20260705.zip` — entries 8555, text-like 7346, tags cjk;arabic_rtl;slavic;romance;program_artifact
- `Interlanguage_NonRU_UK_Slavic_SourceAnchors_EXPANDED_20260705.zip` — entries 1864, text-like 1838, tags cjk;arabic_rtl;slavic;romance;noether_source
- `Interlanguage_LaTeX_SourceBodies_Romance_ES_FR_20260704.zip` — entries 1526, text-like 1432, tags cjk;arabic_rtl;romance
- `Interlanguage_LaTeX_SourceBodies_Persian_RTL_Arabic_20260704.zip` — entries 1253, text-like 1240, tags arabic_rtl;romance
- `Interlanguage_LaTeX_SourceBodies_Slavic_Interslavic_Support_20260704.zip` — entries 1194, text-like 1194, tags cjk;arabic_rtl;slavic;noether_source
- `OtherPC_Noether_SourceCorpus_Provenance_20260705.zip` — entries 1363, text-like 543, tags cjk;arabic_rtl;slavic;romance;noether_source
- `interlingua_program_20260704.zip` — entries 408, text-like 316, tags cjk;arabic_rtl;slavic;romance;noether_source;program_artifact
- `OtherPC_OLP_Relation_Function_Support_20260705.zip` — entries 229, text-like 196, tags arabic_rtl;romance
- `Interlanguage_LaTeX_SourceBodies_CJK_ZH_JA_20260704.zip` — entries 196, text-like 170, tags cjk;arabic_rtl
- `interlingua_program_20260704_v3.zip` — entries 203, text-like 165, tags cjk;arabic_rtl;slavic;romance;noether_source;program_artifact

## Concept web mining result
- Concept rows after merge/regex-mining: **634**
- Trap/adverse rows: **13**
- Rows with >=5 source-body hit rows: **27**

### Priority distribution
- P0_blocking_sense_audit: 19
- P1_review_packet: 14
- P2_register_phrasebook: 40
- P2_specialist_source_intake: 41
- P3_global_baseline_column: 65
- P4_background_enrichment: 164
- unknown: 291

### History class distribution
- unknown: 290
- unclassified_history_needed: 79
- unclassified_or_mixed: 66
- historical_specialist_concept: 42
- greek_latin_internationalism: 36
- proof_prose_register: 26
- proof_discourse_operator: 24
- ordinary_metaphor_concept: 15
- compositional_algebra_construct: 15
- international_technical_root: 10
- trap_concept: 9
- eponymic_globalizable: 8
- trap_or_false_sense_concept: 4
- eponymic_anchor: 4
- ordinary_metaphor_abstraction: 3

### Global-register class distribution
- unknown: 290
- G5_source_intake_needed: 256
- G2_global_register_with_local_glosses: 28
- G3_regional_doublet_or_local_standard_required: 27
- G1_global_attractor_candidate: 21
- G4_trap_or_false_sense_review: 11
- not_in_global_probe: 1

## Highest-priority rows
- **covariant** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G1_global_attractor_candidate; langs=7; hits=3; risks=C2_pending_specialist_or_context;F14_trap_concept
- **modulus** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=4; hits=3; risks=C2_pending_specialist_or_context;F14_trap_concept;has_adverse_evidence;source_gap
- **contravariant** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G2_global_register_with_local_glosses; langs=5; hits=2; risks=C2_pending_specialist_or_context;F14_trap_concept;source_gap
- **absolutely complete system** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=3; hits=1; risks=C2_pending_specialist_or_context;F14_trap_concept;low_global_coverage;source_gap
- **form system** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=3; hits=1; risks=C2_pending_specialist_or_context;F14_trap_concept;low_global_coverage
- **ground form** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=8; hits=1; risks=C2_pending_specialist_or_context;F14_trap_concept;has_adverse_evidence;rejected_or_false_sense_in_lane;source_gap
- **relatively complete system** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=3; hits=1; risks=C2_pending_specialist_or_context;F14_trap_concept;low_global_coverage
- **binary form** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=3; hits=0; risks=C2_pending_specialist_or_context;F14_trap_concept;has_adverse_evidence;rejected_or_false_sense_in_lane;source_gap
- **complete system** — P0 sense-audit trap before any hit-count use; history=trap_concept; global=G4_trap_or_false_sense_review; langs=3; hits=0; risks=C2_pending_specialist_or_context;F14_trap_concept;has_adverse_evidence;rejected_or_false_sense_in_lane;source_gap
- **proof register: holds is valid** — P0 sense-audit trap before any hit-count use; history=trap_or_false_sense_concept; global=G4_trap_or_false_sense_review; langs=0; hits=0; risks=F14_trap_concept;has_adverse_evidence;low_global_coverage
- **proof register: however** — P0 sense-audit trap before any hit-count use; history=trap_or_false_sense_concept; global=G4_trap_or_false_sense_review; langs=0; hits=0; risks=F14_trap_concept;has_adverse_evidence;low_global_coverage
- **proof register: remain ostati** — P0 sense-audit trap before any hit-count use; history=trap_or_false_sense_concept; global=G4_trap_or_false_sense_review; langs=0; hits=0; risks=F14_trap_concept;has_adverse_evidence;low_global_coverage
- **proof register: series sequence red** — P0 sense-audit trap before any hit-count use; history=trap_or_false_sense_concept; global=G4_trap_or_false_sense_review; langs=0; hits=0; risks=F14_trap_concept;has_adverse_evidence;low_global_coverage
- **bordering operation** — review packet / authority or expert row; history=historical_specialist_concept; global=G5_source_intake_needed; langs=6; hits=0; risks=low_global_coverage;source_gap
- **completely reducible** — review packet / authority or expert row; history=unclassified_or_mixed; global=G3_regional_doublet_or_local_standard_required; langs=4; hits=0; risks=low_global_coverage
- **irreducible** — review packet / authority or expert row; history=unclassified_or_mixed; global=G5_source_intake_needed; langs=2; hits=0; risks=low_global_coverage
- **irreducible ideal** — review packet / authority or expert row; history=greek_latin_internationalism; global=G5_source_intake_needed; langs=8; hits=0; risks=low_global_coverage;many_form_families
- **irreducible representation** — review packet / authority or expert row; history=greek_latin_internationalism; global=G5_source_intake_needed; langs=1; hits=0; risks=low_global_coverage
- **reducible** — review packet / authority or expert row; history=unclassified_or_mixed; global=G5_source_intake_needed; langs=3; hits=0; risks=low_global_coverage
- **field** — review packet / authority or expert row; history=ordinary_metaphor_concept; global=G2_global_register_with_local_glosses; langs=29; hits=24; risks=high_competitor_channel;many_form_families
- **theorem** — review packet / authority or expert row; history=proof_prose_register; global=G2_global_register_with_local_glosses; langs=25; hits=21; risks=WS_competitor_only_one_branch;high_competitor_channel;many_form_families;variant_or_doublet_note
- **ring** — review packet / authority or expert row; history=ordinary_metaphor_concept; global=G3_regional_doublet_or_local_standard_required; langs=30; hits=20; risks=WS_competitor_only_both;high_competitor_channel;internal_variance;review_priority
- **matrix** — review packet / authority or expert row; history=greek_latin_internationalism; global=G2_global_register_with_local_glosses; langs=24; hits=15; risks=high_competitor_channel
- **set** — review packet / authority or expert row; history=ordinary_metaphor_concept; global=G3_regional_doublet_or_local_standard_required; langs=14; hits=7; risks=high_competitor_channel;many_form_families
- **corollary** — review packet / authority or expert row; history=proof_prose_register; global=G3_regional_doublet_or_local_standard_required; langs=14; hits=6; risks=WS_competitor_only_one_branch;high_competitor_channel;many_form_families;variant_or_doublet_note
- **quotient field** — review packet / authority or expert row; history=compositional_algebra_construct; global=G2_global_register_with_local_glosses; langs=10; hits=4; risks=WS_competitor_only_one_branch;high_competitor_channel;internal_variance;review_priority
- **center** — review packet / authority or expert row; history=ordinary_metaphor_concept; global=G3_regional_doublet_or_local_standard_required; langs=12; hits=2; risks=high_competitor_channel;many_form_families
- **division ring** — review packet / authority or expert row; history=unclassified_or_mixed; global=G3_regional_doublet_or_local_standard_required; langs=11; hits=2; risks=high_competitor_channel
- **noetherian** — review packet / authority or expert row; history=eponymic_globalizable; global=G3_regional_doublet_or_local_standard_required; langs=12; hits=2; risks=high_competitor_channel
- **division ring / body** — review packet / authority or expert row; history=ordinary_metaphor_concept; global=G3_regional_doublet_or_local_standard_required; langs=8; hits=0; risks=high_competitor_channel;many_form_families
- **extension (field)** — review packet / authority or expert row; history=unclassified_or_mixed; global=G3_regional_doublet_or_local_standard_required; langs=6; hits=0; risks=WS_competitor_only_one_branch;high_competitor_channel;many_form_families;variant_or_doublet_note
- **splitting field** — review packet / authority or expert row; history=compositional_algebra_construct; global=G3_regional_doublet_or_local_standard_required; langs=9; hits=0; risks=WS_competitor_only_one_branch;high_competitor_channel;many_form_families;variant_or_doublet_note
- **trace** — review packet / authority or expert row; history=ordinary_metaphor_concept; global=G3_regional_doublet_or_local_standard_required; langs=6; hits=0; risks=WS_competitor_only_one_branch;high_competitor_channel;many_form_families;variant_or_doublet_note
- **reduction** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G2_global_register_with_local_glosses; langs=5; hits=5; risks=C2_pending_specialist_or_context
- **invariant** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G1_global_attractor_candidate; langs=20; hits=4; risks=
- **invariant theory** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G2_global_register_with_local_glosses; langs=5; hits=2; risks=C2_pending_specialist_or_context
- **transvection** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G2_global_register_with_local_glosses; langs=5; hits=2; risks=C2_pending_specialist_or_context
- **resultant** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G5_source_intake_needed; langs=4; hits=1; risks=C2_pending_specialist_or_context;low_global_coverage
- **associated prime ideal** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G5_source_intake_needed; langs=6; hits=0; risks=low_global_coverage;source_gap
- **biquadratic form** — specialist source intake; do not fill from general shelves; history=historical_specialist_concept; global=G5_source_intake_needed; langs=3; hits=0; risks=C2_pending_specialist_or_context;low_global_coverage;source_gap

## Use policy
- This pass may update concept-web worklists and source-body routing. It may not promote terms, certify target-language usage, or apply text patches.
- Source-body probes are hooks unless a lane artifact already marks the row as row-reviewed/witnessed. Trap concepts require KWIC/sense audit first.
