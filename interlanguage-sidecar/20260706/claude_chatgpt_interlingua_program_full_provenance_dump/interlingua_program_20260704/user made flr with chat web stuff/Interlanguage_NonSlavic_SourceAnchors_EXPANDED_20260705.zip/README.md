# Expanded non-Slavic LaTeX source-anchor feed, 2026-07-05

This package consolidates the current non-Slavic/interlanguage source-anchor shelves into one directly usable Web/Pro and Zenodo-facing payload.

It contains actual file bodies extracted from existing source-body ZIPs, not only URLs or instructions. It is intended for language/register anchoring, terminology comparison, TeX style comparison, and source-corpus work for multilingual mathematical translation workflows.

## Included source buckets

- cjk_zh_ja: Chinese/Japanese/CJK source-body anchors and witnesses.
- rabic_persianate_rtl: Arabic, Persian/Farsi, and RTL-adjacent source-body anchors and witnesses.
- omance_es_fr: Spanish/French/Romance source-body anchors and witnesses.
- 
on_slavic_other: other non-Slavic source-body anchors recovered from the backup-dump feed.

## Counts

- Extracted files: 8551
- Unique file bodies by SHA256: 4496
- Original ZIP entries processed: 8551

See manifest.csv, language_counts.csv, and SHA256SUMS.txt.

## Conservative status

This is a source-anchor/register/style corpus only. It is not native-speaker review, accepted terminology, translation completion, source-fidelity certification, reader output, publication readiness, or a critical edition. PDFs, if present, are witnesses only; TeX-like source files remain the principal payload.
