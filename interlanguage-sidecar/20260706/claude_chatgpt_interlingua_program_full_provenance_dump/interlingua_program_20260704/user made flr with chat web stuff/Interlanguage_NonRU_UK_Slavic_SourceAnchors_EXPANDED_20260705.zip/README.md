# Expanded Non-Russian/Non-Ukrainian Slavic LaTeX Source Anchors

Built: 2026-07-05.

This package expands the earlier non-RU/UK Slavic source-anchor feed by pulling from all current Slavic-relevant source-body ZIPs in the repository, including recovered 
oether-slavic-source-canon payloads and source-link provenance payloads where paths indicate exact non-Russian/non-Ukrainian Slavic language-code segments or explicit Interslavic/Slavic-linguistics support.

Use: feed to Web/Pro sessions as a style/register/source-anchor corpus for Slavic and Interslavic/interlanguage work.

Classification: source-anchor/register/style corpus only. Not native review, not accepted terminology, not translation completion, not source-fidelity certification, not reader output, not publication readiness, and not a critical edition.

Russian and Ukrainian body paths are deliberately excluded. Separate RU/UK comparison feeds should be made separately.

Summary:
- total extracted files: 1860
- unique file bodies by SHA256: 1188
- duplicate bodies retained by path: 672
- extracted bytes before compression: 144399352
## Counts by language hint

- be: 139
- bg: 68
- bs: 125
- cnr: 13
- cs: 126
- dsb: 46
- hr: 134
- hsb: 4
- isv: 528
- mk: 56
- pl: 107
- sk: 78
- sl: 160
- slavic_linguistics_context: 54
- slavic_review_support: 120
- sr: 102
