# Interlanguage concept web v2 — all-language evidence map
Generated 2026-07-05. This is an evidence web, not a certification artifact. It merges the repaired master marker table, CJK and Arabic source-body candidates, Pan-Romance row-reviewed C2 candidates, Macedonian concept-shelf markers, normalization decisions, weighted scores, and tail routing.
## Summary
- Concepts: **343**
- Marker nodes: **1649**
- Graph nodes: **2034**
- Graph edges: **4947**
- Languages with marker rows: **27**
## Source-weight ladder
- `external_community_review`: 1.0
- `row_verified_native_witness`: 1.0
- `canonical_source_authority`: 0.9
- `adverse_competitor_or_collision`: 0.9
- `language_family_witness_candidate`: 0.75
- `native_sourcebody_internal`: 0.75
- `native_concept_shelf`: 0.75
- `ocr_or_mechanical_probe`: 0.5
- `merged_lane_spine`: 0.5
- `generated_internal_consistency`: 0.35
- `cross_lane_spine`: 0.2
- `draft_triangulation`: 0.15
- `model_or_schema`: 0.1
- `gap`: 0.0

These weights are permitted-use/evidence weights, not truth weights. Support and adverse channels are kept separate.
## Top worklist
| Concept | Priority | Band | Support | Adverse | Eff. families | Families | Next action |
|---|---:|---|---:|---:|---:|---|---|
| ring | 105 | A_review_now | 11.8 | 5.4 | 5.106 | Arabic;CJK;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic | row-review/adverse-evidence decision |
| quotient field | 74.0 | A_review_now | 4.75 | 1.8 | 2.811 | Bridge Slavic;East Slavic;South Slavic | row-review/adverse-evidence decision |
| field | 55 | D_background | 11.4 | 4.5 | 4.842 | Arabic;Bridge Slavic;CJK;Malay-Indonesian;Persianate;Romance;South Slavic | row-review/adverse-evidence decision |
| corollary | 53.0 | B_variant_or_backfill | 7.8 | 3.6 | 3.722 | Arabic;East Slavic;Malay-Indonesian;Persianate;Romance | row-review/adverse-evidence decision |
| set | 53.0 | D_background | 8.0 | 3.6 | 5.149 | Arabic;Bridge Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| prime ideal | 48.5 | D_background | 10.35 | 2.7 | 5.896 | Arabic;CJK;East Slavic;Malay-Indonesian;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| representation | 48.5 | D_background | 12.05 | 2.7 | 5.291 | Arabic;CJK;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic | row-review/adverse-evidence decision |
| theorem | 48.5 | B_variant_or_backfill | 10.55 | 2.7 | 4.521 | Arabic;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic | row-review/adverse-evidence decision |
| element | 44.0 | D_background | 11.0 | 1.8 | 4.379 | Arabic;Bridge Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| ground form | 44.0 | C_core_fill_or_source_intake | 5.0 | 1.8 | 3.553 | Arabic;Bridge Slavic;East Slavic;Persianate | row-review/adverse-evidence decision |
| matrix | 44.0 | D_background | 9.75 | 1.8 | 4.623 | Arabic;Bridge Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| proof | 44.0 | D_background | 11.4 | 1.8 | 4.526 | Arabic;Bridge Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| subset | 44.0 | D_background | 10.25 | 1.8 | 4.931 | Arabic;Bridge Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| determinant | 39.5 | C_core_fill_or_source_intake | 13.05 | 0.9 | 5.16 | Arabic;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| dimension | 39.5 | D_background | 10.8 | 0.9 | 4.445 | Arabic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| lemma | 39.5 | D_background | 13.5 | 0.9 | 6.107 | Arabic;Bridge Slavic;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| modulus | 39.5 | C_core_fill_or_source_intake | 4.9 | 0.9 | 2.087 | Arabic;Persianate;Romance | row-review/adverse-evidence decision |
| polynomial | 39.5 | C_core_fill_or_source_intake | 13.0 | 0.9 | 5.634 | Arabic;Bridge Slavic;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | row-review/adverse-evidence decision |
| assumption | 38 | D_background | 8.3 | 0 | 1.312 | Malay-Indonesian;Romance | C2 fill or source-intake |
| conversely | 38 | D_background | 4.4 | 0 | 1.0 | Romance | C2 fill or source-intake |
| exercise | 38 | D_background | 4.9 | 0 | 1.755 | Arabic;Romance | C2 fill or source-intake |
| exists | 38 | D_background | 4.4 | 0 | 1.0 | Romance | C2 fill or source-intake |
| factor | 38 | D_background | 5.9 | 0 | 1.895 | Arabic;Persianate;Romance | C2 fill or source-intake |
| for all | 38 | D_background | 4.4 | 0 | 1.0 | Romance | C2 fill or source-intake |
| formula | 38 | D_background | 5.9 | 0 | 1.384 | Malay-Indonesian;Romance | C2 fill or source-intake |
| identity | 38 | C_core_fill_or_source_intake | 5.4 | 0 | 1.417 | Malay-Indonesian;Romance | C2 fill or source-intake |
| if and only if | 38 | D_background | 4.4 | 0 | 1.0 | Romance | C2 fill or source-intake |
| problem | 38 | D_background | 6.4 | 0 | 1.822 | Arabic;Persianate;Romance | C2 fill or source-intake |
| proposition | 38 | C_core_fill_or_source_intake | 5.15 | 0 | 1.437 | Malay-Indonesian;Romance | C2 fill or source-intake |
| respectively | 38 | C_core_fill_or_source_intake | 4.4 | 0 | 1.0 | Romance | C2 fill or source-intake |
| resultant | 38 | C_core_fill_or_source_intake | 5.3 | 0 | 1.507 | Malay-Indonesian;Romance | C2 fill or source-intake |
| statement | 38 | D_background | 5.9 | 0 | 1.384 | Malay-Indonesian;Romance | C2 fill or source-intake |
| therefore | 38 | C_core_fill_or_source_intake | 4.9 | 0 | 1.0 | Romance | C2 fill or source-intake |
| algebra | 30 | D_background | 12.4 | 0 | 5.367 | Arabic;CJK;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | C2 fill or source-intake |
| basis | 30 | D_background | 13.25 | 0 | 5.049 | Arabic;Bridge Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | C2 fill or source-intake |
| coefficient | 30 | D_background | 8.05 | 0 | 3.87 | Arabic;East Slavic;Malay-Indonesian;Persianate;Romance | C2 fill or source-intake |
| covariant | 30 | C_core_fill_or_source_intake | 5.3 | 0 | 3.17 | Arabic;Malay-Indonesian;Persianate;Romance | C2 fill or source-intake |
| decomposition | 30 | D_background | 10.5 | 0 | 3.917 | Arabic;Bridge Slavic;East Slavic;Persianate;Romance | C2 fill or source-intake |
| definition | 30 | D_background | 12.55 | 0 | 5.016 | Arabic;East Slavic;Malay-Indonesian;Persianate;Romance;South Slavic;West Slavic | C2 fill or source-intake |
| direct sum | 30 | D_background | 6.5 | 0 | 4.079 | Arabic;Bridge Slavic;Persianate;Romance;South Slavic | C2 fill or source-intake |

## Coverage by marker language
- `en` (English): 212
- `fr` (French): 135
- `es` (Spanish): 134
- `de` (German): 111
- `isv` (Interslavic Latin): 93
- `ar` (Arabic): 79
- `uk` (Ukrainian): 64
- `fa` (Persian/Farsi): 62
- `ru` (Russian): 61
- `my_id` (Malay/Indonesian): 60
- `pt` (Portuguese): 52
- `ca` (Catalan): 51
- `it` (Italian): 51
- `gl` (Galician): 48
- `isv_cyr` (Interslavic Cyrillic): 45
- `ro` (Romanian): 42
- `cs` (Czech): 39
- `mk` (Macedonian): 39
- `pl` (Polish): 38
- `hr_sr` (Croatian/Serbian): 35
- `sl` (Slovenian): 33
- `sk` (Slovak): 30
- `rm` (Romansh): 30
- `ja` (Japanese): 29
- `zh_hans` (Chinese Simplified): 29
- `bg` (Bulgarian): 24
- `ko` (Korean): 23

## Polarity/source-category counts
### Polarity
- support: 1574
- competitor: 66
- adverse: 9
### Source category
- merged_lane_spine: 580
- canonical_source_authority: 323
- native_sourcebody_internal: 186
- native_concept_shelf: 176
- language_family_witness_candidate: 133
- generated_internal_consistency: 122
- adverse_competitor_or_collision: 75
- draft_triangulation: 42
- ocr_or_mechanical_probe: 12

## Immediate instructions to Codex Alpha, Codex Beta, and Fable
### Codex Alpha
Primary local production/coordination instance; owns production tree, corpus-wide patches, rendered outputs, and final merge discipline.

Do now:
- Consume NORMALIZATION_BATCH0_ORTHOGRAPHY patch only after regenerating it line-wide and idempotently on translations/ only; never patch renders/ directly.
- Consume NORMALIZATION_BATCH1_DRYRUN only as dry-run locator; apply only APPLY1 rows after TeX-aware line review and Latin/Cyrillic sync generation.
- Merge INTERLANGUAGE_CONCEPT_WEB_v2 as evidence map input, not as terminology authority.
- Maintain Source Use Policy categories on every merge: concept normalization, native witness, draft/generated consistency, adverse evidence, external review.
- Keep branch weighting states frozen by state label: baseline, row-reviewed writeback, candidate projection. Do not headline state-D projections.

Do not:
- Do not ask Floris to adjudicate languages.
- Do not push to git or publish; Floris only gates external sending/publication.
- Do not treat generated ISV/UK/RU TeX as W/S native witness evidence.

### Codex Beta
Other-PC source-body producer and source-canon coordination instance.

Do now:
- Export native source-body packages with a manifest that separates native_source_body, OCR/extracted witness, draft/generated, scaffold, and source-canon files.
- For each package include manifest.csv/json with sha256, file count, language hint, source_use_category, and extraction method.
- For CJK/Arabic/Romance/Persianate source bodies, emit KWIC windows with non-null concept_id, language, form, source_path, and context window.
- Do not label generated audit files as native-source-body; CJK SOURCE_BODIES.csv already had that defect once.

Do not:
- Do not emit candidate rows with null route_key/lang/form.
- Do not use generic stems for witness discovery without a math-genre filter.
- Do not promote bridge terms; source bodies feed evidence, not construction decisions.

### Fable
Local synthesis/review layer; validates row senses, rejects false positives, and writes human-readable coordination reports.

Do now:
- Read this concept web as the current cross-language map, then row-review the high-priority concepts and false-sense/adverse edges.
- Continue sense audits of source-body candidates before they enter C2 fill ledgers.
- Use the normalization action bands, not user questions, for Codex Alpha patch routing.
- Maintain the distinction between internal triangulation and external review.

Do not:
- Do not gate linguistic decisions on Floris; escalate to expert layer or mark human-authority-needed.
- Do not collapse support and adverse evidence into one scalar.
- Do not overwrite frozen baselines.

## File set
- `INTERLANGUAGE_CONCEPT_WEB_v2_20260705.json`: full graph.
- `INTERLANGUAGE_CONCEPT_WEB_CONCEPTS_v2_20260705.csv`: concept-level summary and weights.
- `INTERLANGUAGE_CONCEPT_WEB_MARKERS_v2_20260705.csv`: marker-level evidence rows.
- `INTERLANGUAGE_CONCEPT_WEB_EDGES_v2_20260705.csv`: graph edges.
- `INTERLANGUAGE_CONCEPT_WEB_MATRIX_v2_20260705.csv`: wide concept × language marker matrix.
- `INTERLANGUAGE_CONCEPT_WEB_WORKLIST_v2_20260705.csv`: sorted high-priority worklist.
- `CODEX_ALPHA_BETA_FABLE_ROUTING_PLAN_v1_20260705.json`: coordination instructions.
