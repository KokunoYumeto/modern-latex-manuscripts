# Interlanguage connection framework v4.2 — source-term concept-history expansion

This pass mines the Noether/Slavic source-term seed index into concept-history rows. It adds source-side concepts where German/Noether terms were previously unassigned. These rows are routing concepts, not target-language witnesses.

- **artifact**: interlanguage_source_term_expansion_v4_2
- **generated**: 2026-07-05
- **source_term_seed_rows**: 868
- **assigned_v4_1**: 798
- **assigned_v4_2**: 856
- **new_assignments_in_v4_2**: 58
- **remaining_unassigned**: 12
- **new_source_side_concept_rows_added**: 21
- **concept_rows_total_v4_2**: 659
## work_band_counts_v4_2
- P4_background_or_enrichment: 345
- P3_global_register_candidate: 106
- P2_proof_register_phrasebook: 76
- P2_specialist_history_sources: 71
- P0_sense_audit: 28
- P1_review_or_margin: 19
- P3_global_register_baseline: 14
## source_term_history_counts_v4_2
- international_technical_root: 265
- historical_specialist_concept: 164
- unclassified_history_needed: 147
- ordinary_metaphor_abstraction: 132
- operation_or_relation_schema: 78
- proof_discourse_operator: 41
- eponymic_anchor: 36
- trap_or_false_sense_concept: 5
- **boundary**: Source-side concepts are not language witnesses. They route concept-history and source-intake work.

## New source-side concept rows added
- choice postulate — proof_discourse_operator
- common zeros — ordinary_metaphor_abstraction
- component — international_technical_root
- conjugate denominator — operation_or_relation_schema
- coprime / relatively prime — operation_or_relation_schema
- divisor — international_technical_root
- exception — proof_discourse_operator
- finiteness — proof_discourse_operator
- line — ordinary_metaphor_abstraction
- multiplication — operation_or_relation_schema
- number domain — ordinary_metaphor_abstraction
- numerical determination — proof_discourse_operator
- omitted — proof_discourse_operator
- power sum — operation_or_relation_schema
- primary — international_technical_root
- proof closure — proof_discourse_operator
- ray class division — historical_specialist_concept
- side condition — proof_discourse_operator
- skew line — ordinary_metaphor_abstraction
- subtraction — operation_or_relation_schema
- transcendental number — international_technical_root
