# Interlanguage connection framework v4.3 — Route-A review/writeback layer

This package turns the route-A F10-1 tail from a broad routing ledger into actionable writeback bands. It does not edit production text and does not certify terms. It only says which under-witnessed term rows have enough curated concept-shelf evidence to proceed to row-source confirmation, and which rows must remain variant-sensitive, competitor-only, or targeted-probe work.

## Inputs exercised

- `TAIL_AC_REVIEW_BATCHES_v8_1`: 493 route-A term rows.
- `TAIL_ROUTE_AC_PRECOMPUTED_EVIDENCE_ASSIGNMENT_v8_1`: noisy source-body probes.
- `ws_witness_backfill_v1_20260704`: curated 20-source W/S shelf with support/competitor typing.
- `C2_CONTEXT_WINDOWS_v1_20260704`: curated W/S context windows.

## Main result

The full route-A policy pass covers all 493 route-A rows:

| Band | Meaning | Concepts | Rows |
|---|---|---:|---:|
| W0 | clean bulk candidate writeback after source-row concept check | 5 | 234 |
| W1 | support plus competitor; variant-policy/adverse channel required | 9 | 148 |
| W3 | competitor-only; review/adverse channel, no support writeback | 1 | 17 |
| W4 | unclear W/S hits | 2 | 13 |
| W5 | C2 windows exist but no W/S backfill row | 4 | 81 |

High-volume route-A concepts were reviewed separately. `ideal`, `basis`, `module`, and `group` have curated W/S support sufficient for candidate concept-shelf writeback after source-row confirmation. `field` remains variant-sensitive. `coefficient` needs context confirmation before writeback.

## Apply rule

Only W0 rows may move toward F10 concept-shelf writeback, and only after confirming the source term row actually instantiates the concept. W1 rows retain both support and competitor channels. W3 rows are adverse/review rows. W5 rows require context review first.

## Output files

- `TAIL_ROUTE_A_FULL_WS_POLICY_v3_20260705.csv/json/md`: all route-A concept policy bands.
- `TAIL_ROUTE_A_FULL_TERM_ACTION_QUEUE_v3_20260705.csv/json`: per-term action queue for all 493 rows.
- `TAIL_ROUTE_A_HIGH_VOLUME_WS_CURATED_CONCEPT_VERDICTS_v2.csv/json`: high-volume concept verdicts.
- `TAIL_A_HIGH_VOLUME_WS_CURATED_TERM_WRITEBACK_QUEUE_v2.csv/json`: high-volume term queue.
- `TAIL_A_HIGH_VOLUME_EVIDENCE_REVIEW_v1.csv/json`: noisy expanded-anchor evidence audit for six high-volume concepts.
- `TAIL_A_HIGH_VOLUME_FALSE_POSITIVE_LEDGER_v1.csv`: bad-genre / wrong-sense examples from expanded source-body probes.
