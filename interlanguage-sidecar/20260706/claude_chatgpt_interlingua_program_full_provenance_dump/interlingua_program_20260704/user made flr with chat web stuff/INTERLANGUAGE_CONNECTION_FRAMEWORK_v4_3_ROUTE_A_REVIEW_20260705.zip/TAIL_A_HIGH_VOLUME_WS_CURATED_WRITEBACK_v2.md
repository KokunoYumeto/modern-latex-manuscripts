# Tail A high-volume W/S-curated writeback pass v2

This pass corrects the noisy expanded-anchor review by grounding the top route-A concepts in the curated 20-source West/South shelf and C2 context windows. No term promotion, no wording change, no certification.

## Concept verdicts

| concept     |   route_A_term_rows | isv_choice   |   curated_ws_files | c2_context_langs                 | concept_verdict                                              | writeback_policy                                   |
|:------------|--------------------:|:-------------|-------------------:|:---------------------------------|:-------------------------------------------------------------|:---------------------------------------------------|
| ideal       |                 111 | ideal        |                 15 | bg | cs | hr | pl | sk | sl | sr | clean_support_in_west_and_south_from_curated_WS_shelf        | bulk_candidate_concept_shelf_writeback             |
| field       |                  63 | polje        |                 19 | bg | cs | hr | pl | sk | sl      | support_plus_competitor_in_W_and_S_variant_policy_required   | no_bulk_support_only_writeback_variant_sensitive   |
| basis       |                  63 | baza         |                 13 | bg                               | clean_support_in_west_and_south_from_curated_WS_shelf        | bulk_candidate_concept_shelf_writeback             |
| coefficient |                  60 |              |                  0 | bg | cs | pl | sk | sl           | support_in_c2_context_windows_W_and_S_but_no_ws_backfill_row | candidate_writeback_after_row_context_confirmation |
| module      |                  27 | modul        |                 13 | cs | hr | pl | sk | sl | sr      | clean_support_in_west_and_south_from_curated_WS_shelf        | bulk_candidate_concept_shelf_writeback             |
| group       |                  25 | grupa        |                 17 | bg | cs | hr | pl | sk | sl | sr | clean_support_in_west_and_south_from_curated_WS_shelf        | bulk_candidate_concept_shelf_writeback             |

## Operational result

- `ideal`, `basis`, `module`, and `group` are now suitable for a bulk **candidate** F10-1 writeback pass after confirming each term row really instantiates the concept.
- `coefficient` has usable C2 windows but needs row-context confirmation before bulk writeback.
- `field` is intentionally **not** a clean support writeback row: it is support+competitor and must remain variant-sensitive.

## Work orders

| actor         | task                                                                                                                                | input                                                     | guardrail                                                                   |
|:--------------|:------------------------------------------------------------------------------------------------------------------------------------|:----------------------------------------------------------|:----------------------------------------------------------------------------|
| Codex Alpha   | Route-A writeback candidate pass for ideal: attach W/S concept-shelf support to 111 rows after source-row concept check             | TAIL_A_HIGH_VOLUME_WS_CURATED_TERM_WRITEBACK_QUEUE_v2.csv | No term promotion; no text changes; support evidence is concept-shelf only. |
| Fable         | Prepare field variant-policy note: polje support vs těleso/ciało competitor in W branch; decide no-verdict packet or doublet policy | ws_witness_backfill_v1 + C2 windows                       | Do not collapse support+competitor to clean support.                        |
| Codex Alpha   | Route-A writeback candidate pass for basis: attach W/S concept-shelf support to 63 rows after source-row concept check              | TAIL_A_HIGH_VOLUME_WS_CURATED_TERM_WRITEBACK_QUEUE_v2.csv | No term promotion; no text changes; support evidence is concept-shelf only. |
| Fable/ChatGPT | Review coefficient C2 context windows and produce row-certified W/S support before bulk writeback                                   | C2_CONTEXT_WINDOWS_v1 + tail term queue                   | No bulk writeback until row windows are concept-specific.                   |
| Codex Alpha   | Route-A writeback candidate pass for module: attach W/S concept-shelf support to 27 rows after source-row concept check             | TAIL_A_HIGH_VOLUME_WS_CURATED_TERM_WRITEBACK_QUEUE_v2.csv | No term promotion; no text changes; support evidence is concept-shelf only. |
| Codex Alpha   | Route-A writeback candidate pass for group: attach W/S concept-shelf support to 25 rows after source-row concept check              | TAIL_A_HIGH_VOLUME_WS_CURATED_TERM_WRITEBACK_QUEUE_v2.csv | No term promotion; no text changes; support evidence is concept-shelf only. |