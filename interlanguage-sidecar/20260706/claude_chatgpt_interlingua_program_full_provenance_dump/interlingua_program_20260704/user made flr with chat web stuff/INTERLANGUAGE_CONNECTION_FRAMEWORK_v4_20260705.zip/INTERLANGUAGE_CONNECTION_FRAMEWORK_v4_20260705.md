# Interlanguage connection framework v4
2026-07-05. Integrated concept/history/global-register/weight/source-use framework. This is an evidence/routing layer only: no term is promoted or certified, and no production text is changed.

## Counts
- **concept_rows**: 638
- **marker_rows**: 1649
- **edge_rows**: 5987
- **proof_register_entries**: 532
- **source_term_seed_rows**: 871
- **worklist_rows**: 162

## What changed in this pass
- Merged the clean marker table, concept web, big-dump concept mine, concept-history prior, global-register probe, predictive model, CJK/Arabic/Pan-Romance sense-audited ledgers, proof-prose lexicon, F10 tail routing, and Noether source-term seed index into one framework.
- Added a source-term seed index from the Noether/Slavic term dataset so German source terms and ISV rows are visible as source-side history/provenance, not only language markers.
- Integrated the 532-entry proof-prose lexicon as its own register web rather than treating proof connectives as stopwords.
- Added a unified worklist: concept rows, R1 normalization decisions, F10 tail buckets, and specialist-source intake are now sorted together.

## Top priority concept rows
| concept | score | history | observed global class | risk flags | next action |
|---|---:|---|---|---|---|
| ring | 125.0 | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_re | WS_competitor_only_both;high_competitor_channel;internal_var | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| field | 123.5 | ordinary_metaphor_abstraction | G2_global_register_with_local_glosses | high_competitor_channel;many_form_families;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| theorem | 118.1 | proof_discourse_operator | G2_global_register_with_local_glosses | WS_competitor_only_one_branch;high_competitor_channel;many_f | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| matrix | 113.9 | international_technical_root | G2_global_register_with_local_glosses | high_competitor_channel;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| set | 112.8 | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_re | high_competitor_channel;many_form_families;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| corollary | 111.4 | proof_discourse_operator | G3_regional_doublet_or_local_standard_re | WS_competitor_only_one_branch;high_competitor_channel;many_f | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| division ring | 83.1 | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_re | high_competitor_channel;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| noetherian | 82.7 | eponymic_anchor | G3_regional_doublet_or_local_standard_re | high_competitor_channel;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| ground form | 80.4 | trap_or_false_sense_concept | G4_trap_or_false_sense_review | C2_pending_specialist_or_context;F14_trap_concept;adverse_ma | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| center | 80.1 | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_re | high_competitor_channel;many_form_families;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| splitting field | 78.4 | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_re | WS_competitor_only_one_branch;high_competitor_channel;many_f | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| division ring / body | 75.5 | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_re | high_competitor_channel;many_form_families;nan | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| modulus | 75.5 | trap_or_false_sense_concept | G4_trap_or_false_sense_review | C2_pending_specialist_or_context;F14_trap_concept;adverse_ma | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| quotient field | 73.9 | operation_or_relation_schema | G2_global_register_with_local_glosses | WS_competitor_only_one_branch;high_competitor_channel;intern | Assemble no-verdict review row with support/competitor/adverse channels and bran |
| extension (field) | 70.6 | operation_or_relation_schema | G3_regional_doublet_or_local_standard_re | WS_competitor_only_one_branch;high_competitor_channel;many_f | Assemble no-verdict review row with support/competitor/adverse channels and bran |

## Files
- `INTERLANGUAGE_CONNECTION_FRAMEWORK_v4_CONCEPTS_20260705.csv/json`: main concept table.
- `INTERLANGUAGE_CONNECTION_FRAMEWORK_v4_MARKERS_20260705.csv`: marker/evidence rows.
- `INTERLANGUAGE_CONNECTION_FRAMEWORK_v4_EDGES_20260705.csv`: graph edges.
- `PROOF_PROSE_REGISTER_WEB_v1_20260705.csv`: proof-prose register lexicon.
- `NOETHER_SOURCE_TERM_SEED_INDEX_v1_20260705.csv`: German/source-side seed terms from the Noether/Slavic term dataset.
- `INTERLANGUAGE_CONNECTION_FRAMEWORK_v4_WORKLIST_20260705.csv/json`: next-action queue.

## Non-negotiable boundary
Generated/draft/internal materials can suggest candidates, flag variance, and find context windows. They cannot certify target-language usage, promote a bridge form, or replace external authority review.