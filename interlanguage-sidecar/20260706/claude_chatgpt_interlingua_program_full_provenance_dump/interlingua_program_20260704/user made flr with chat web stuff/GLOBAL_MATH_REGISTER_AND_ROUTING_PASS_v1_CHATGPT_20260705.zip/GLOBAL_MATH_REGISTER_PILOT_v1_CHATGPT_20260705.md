# Global Mathematical Register Pilot v1

Generated: 2026-07-05

## Boundary

This is a weighted diagnostic layer over the existing interlanguage concept web. It does not certify, promote, or patch any term. It tests whether a concept has a plausible worldwide mathematical-register attractor, while keeping source categories, competitors, and false-sense traps separate.

## Result summary

| Class | Count |
| --- | ---: |
| `G5_source_intake_needed` | 256 |
| `G2_global_register_with_local_glosses` | 28 |
| `G3_regional_doublet_or_local_standard_required` | 27 |
| `G1_global_attractor_candidate` | 21 |
| `G4_trap_or_false_sense_review` | 11 |

## Interpretation

- The formula layer is already global; this pilot only scores prose/concept markers.

- The pilot finds a real but limited global-attractor set. It is strong for internationalized algebra terms and eponyms, weak for proof connectives, and actively dangerous for trap concepts such as `modulus`, `ground form`, `complete system`, and `binary form`.

- The correct product is not a full invented language. It is a controlled global mathematical register column used as a comparator: a zonal bridge earns its keep exactly where it beats the global attractor in marginal intelligibility.

## Top G1 global-attractor candidates

| Concept | Score | Dominant family | Blocks | D1 families | Risk |
| --- | ---: | --- | ---: | ---: | --- |
| polynomial | 87.6 | `INTL/POLY:polynomial` | 8 | 1.417 |  |
| group | 86.6 | `INTL/NATIVE:group` | 9 | 1.57 |  |
| ideal | 84.4 | `INTL:ideal` | 8 | 1.973 |  |
| module | 81.5 | `INTL/MIXED:module` | 8 | 2.213 |  |
| homomorphism | 81.0 | `INTL:homomorphism` | 7 | 1.483 |  |
| basis | 80.4 | `MIXED:basis` | 7 | 1.545 |  |
| isomorphism | 78.8 | `INTL:isomorphism` | 7 | 1.847 |  |
| invariant | 77.5 | `INTL/NATIVE:invariant` | 8 | 2.411 |  |
| determinant | 77.3 | `INTL/NATIVE:determinant` | 7 | 2.064 |  |
| vector | 75.0 | `INTL/NATIVE:vector` | 6 | 1.489 |  |
| kernel | 74.0 | `MIXED:kernel` | 6 | 1.778 |  |
| dimension | 72.9 | `INTL/NATIVE:dimension` | 6 | 1.948 |  |
| algebra | 71.3 | `GLOBAL:algebra` | 5 | 1.0 |  |
| definition | 70.1 | `MIXED:definition` | 7 | 3.708 |  |
| subgroup | 68.1 | `INTL/NATIVE:group` | 5 | 1.309 |  |
| vector space | 65.7 | `INTL/NATIVE:vector` | 4 | 1.32 |  |
| image | 64.2 | `MIXED:image` | 4 | 1.635 |  |
| coefficient | 63.6 | `INTL:coefficient` | 5 | 2.496 |  |
| function | 59.5 | `INTL/NATIVE:function` | 5 | 3.013 |  |
| finite | 54.1 | `MIXED:finite` | 4 | 2.578 |  |

## Regional/doublet-required examples

| Concept | Score | Dominant family | Blocks | Competitor ratio | Risk |
| --- | ---: | --- | ---: | ---: | --- |
| ring | 72.7 | `SPLIT:ring` | 8 | 0.374 | high_competitor_channel |
| corollary | 60.1 | `MIXED:corollary` | 7 | 0.365 | high_competitor_channel;many_form_families |
| set | 59.4 | `MIXED:set` | 7 | 0.396 | high_competitor_channel;many_form_families |
| noetherian | 50.3 | `INTL:noetherian` | 6 | 0.466 | high_competitor_channel |
| degree | 47.7 | `CYRILLIC:degree` | 3 | 0.0 |  |
| normal subgroup | 45.0 | `CYRILLIC:normal subgroup` | 3 | 0.0 |  |
| crossed product | 42.0 | `CYRILLIC:crossed product` | 2 | 0.0 | low_global_coverage |
| crossed representation | 42.0 | `CYRILLIC:crossed representation` | 2 | 0.0 | low_global_coverage |
| elementary divisor | 42.0 | `CYRILLIC:elementary divisor` | 3 | 0.0 | many_form_families |
| factor system | 42.0 | `CYRILLIC:factor system` | 2 | 0.0 | low_global_coverage |
| residue class | 42.0 | `CYRILLIC:residue class` | 3 | 0.0 | many_form_families |
| completely reducible | 40.6 | `CYRILLIC:completely reducible` | 2 | 0.0 | low_global_coverage |
| factor | 39.8 | `MIXED:quotient` | 3 | 0.0 | many_form_families |
| assumption | 39.0 | `LOCAL:hypothes` | 2 | 0.0 | low_global_coverage;many_form_families |
| rank | 38.5 | `GLOBAL:algebra` | 3 | 0.0 | many_form_families |

## F14 trap/sense-review rows

| Concept | Dominant family | Adverse ratio | Reason |
| --- | --- | ---: | --- |
| absolutely complete system | `TRAP_OR_SPECIAL:complete-system` | 0.0 | F14_trap_concept;low_global_coverage |
| binary form | `TRAP_OR_SPECIAL:binary-form` | 0.462 | F14_trap_concept;has_adverse_evidence |
| complete system | `TRAP_OR_SPECIAL:complete-system` | 0.462 | F14_trap_concept;has_adverse_evidence |
| contravariant | `SPECIAL:contravariant` | 0.0 |  |
| covariant | `SPECIAL:covariant` | 0.0 |  |
| form system | `ARABIC/PERSIAN:form system` | 0.0 | F14_trap_concept;low_global_coverage |
| ground form | `CYRILLIC:ground form` | 0.333 | F14_trap_concept;has_adverse_evidence |
| modulus | `INTL/MIXED:module` | 0.182 | F14_trap_concept;has_adverse_evidence |
| proof register: holds is valid | `` | 1.0 | has_adverse_evidence;low_global_coverage |
| proof register: however | `` | 1.0 | has_adverse_evidence;low_global_coverage |
| proof register: remain ostati | `` | 1.0 | has_adverse_evidence;low_global_coverage |
| proof register: series sequence red | `` | 1.0 | has_adverse_evidence;low_global_coverage |
| relatively complete system | `TRAP_OR_SPECIAL:complete-system` | 0.0 | F14_trap_concept;low_global_coverage |

## Useful-rigor weighting formalism

Use a typed evidence graph, not decorative automata theory. Nodes are concepts, markers, language blocks, source categories, and form families. Edges carry `(polarity, source_category, weight)` with polarity in `{support, competitor, adverse}`. Positive support and adverse evidence are not folded into a single scalar. The attractor score is only a triage score:

\[
\mathrm{Attractor}(c) = f(\text{block coverage},\text{dominant form-family share},\text{source-use quality}) - g(\text{competitor mass},\text{adverse mass}).
\]

Weighted automata become relevant only if the extraction process itself is modeled as paths through an evidence transducer. For current work, the graph/coverage model is enough.


## Next work

1. Re-run after East-column lemma normalization; current scores still inherit some phrase-cell contamination.

2. Treat G4 rows as a standing trap list: no mechanical hit accepted without KWIC sense window.

3. Use G1 rows as global-register candidate anchors and G3 rows as zonal-bridge justification rows.

4. Route A/C tail probes should use native lexeme families, not current Interslavic forms.
