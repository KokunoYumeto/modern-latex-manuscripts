# Codex Alpha / Codex Beta / Fable routing — global register and concept web

Generated: 2026-07-05.

## Operating boundary

The user is not the language adjudicator. Codex/Fable/ChatGPT should make bounded linguistic/evidence decisions inside the source-use policy. The user gates external sending, publication, GPU/model loads, and repository pushes.

## Codex Alpha

Role: production/merge instance.

1. Keep `INTERLINGUAL_MARKER_TABLE_v3_3` as the current global marker table until Fable's lemma normalization returns.
2. Do not apply batch-0 diff verbatim. Regenerate line-wide/idempotent, translations-only, TeX-aware, rebuild renders/Cyrillic siblings.
3. Treat batch-1 lexeme switches as dry-run only. Apply only rows marked candidate-after-review; keep `ręd`, `jednako`, and false-friend rows outside automatic replacement.
4. Merge `GLOBAL_MATH_REGISTER_PILOT_v1_CHATGPT` as a diagnostic column set, not as a term source.
5. Preserve three statuses: linked_to_concept, witnessed_for_branch, reviewed_for_bridge_use.

## Codex Beta

Role: source-body producer.

1. Send raw source bodies plus manifest hashes, not only ledgers.
2. For CJK/Arabic, keep native source-body files distinct from generated/audit files. `manifest.csv` is authoritative when package-internal labels disagree.
3. For trap concepts (`modulus`, `ground form`, `binary form`, `complete system`, covariant/contravariant), provide KWIC windows and subject-matter sense tags.
4. For global-register work, collect source bodies for the low-coverage G5 rows and Noether-specialist G4/G5 rows.

## Fable

Role: synthesis and row review.

1. Finish East-column lemma normalization, then rerun global-attractor measurement.
2. Review G1 global-attractor candidates for false positives caused by phrase cells or source-cue contamination.
3. Convert G3 rows into zonal-bridge justification rows: these are precisely where local/zonal forms beat global attractors.
4. Maintain F14 trap list in the atlas.
5. Keep global register as a comparator column, not as a scope change away from Interslavic/Slavic completion.

## ChatGPT

Role: weighted graph, probe queues, dry-run patch design.

1. Re-run `GLOBAL_MATH_REGISTER_PILOT` after lemma-normalization return.
2. Run route-A/C probes using native lexeme families and mandatory KWIC windows.
3. Keep support/competitor/adverse separate in every output.
