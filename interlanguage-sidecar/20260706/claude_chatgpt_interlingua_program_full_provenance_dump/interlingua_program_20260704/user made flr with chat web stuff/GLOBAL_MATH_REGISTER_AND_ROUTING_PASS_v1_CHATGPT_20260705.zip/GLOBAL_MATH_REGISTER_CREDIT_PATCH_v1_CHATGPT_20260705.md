# Global Mathematics Register — credit patch

Generated: 2026-07-05.

The standardized global mathematics-register idea should be credited as follows:

- **Originating project context:** the ChatGPT-5.5 Codex session that produced the initial Ukrainian, Russian, and Interslavic translation lane.
- **Human steering / preservation:** Floris surfaced the idea in the current interlanguage-program discussion and connected it to the weighted concept web.
- **Current operational form:** global register = an argmax/comparator column in the existing weighted interlanguage concept web, not a new language lane and not a term-promotion authority.

This patch is for provenance correction. It does not change the concept-web data or certify any global-register forms.
