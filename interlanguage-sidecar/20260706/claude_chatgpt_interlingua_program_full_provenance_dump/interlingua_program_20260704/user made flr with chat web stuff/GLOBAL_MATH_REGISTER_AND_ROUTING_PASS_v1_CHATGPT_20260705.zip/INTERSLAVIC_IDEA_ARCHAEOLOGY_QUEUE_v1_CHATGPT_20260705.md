# Interslavic idea-archaeology work queue

Generated: 2026-07-05.

Purpose: locate all iterations of the early Interslavic logbook / goal notes that contain the conceptual considerations behind the current access-gain, marginal-intelligibility, global-register, and weighted-witness machinery.

## Known anchor

The first mined logbook extraction produced 222 term decisions spanning Paper 01 to Paper 04 Section 5. It captured term choices and reasons but not necessarily every higher-level goal note.

## Search targets

1. `INTERSLAVIC_LOGBOOK.md` and all dated variants.
2. Sections named `Expanded Goal Note`, `Standing Principles`, `maintenance handoff`, `methodology`, `pilot`, `translation policy`, `reviewer-facing`, `voting machine`, `marginal intelligibility`, or `global`.
3. Early Ukrainian/Russian/Interslavic translation logs from the ChatGPT-5.5 Codex session that originated the global mathematics-register idea.
4. Any sidecar notes explaining why Interslavic was added after Ukrainian/Russian.

## Extraction schema

```json
{
  "source_file": "",
  "section": "",
  "date": "",
  "idea": "",
  "verbatim_short_quote": "",
  "clean_operational_form": "",
  "current_artifact_that_implements_it": "",
  "credit": "",
  "status": "confirmed | plausible | rejected | duplicate"
}
```

## Output wanted

`INTERSLAVIC_IDEA_ARCHAEOLOGY_v1.md/json`: idea provenance, not a new theory essay.
