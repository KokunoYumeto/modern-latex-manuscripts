# Concept-history layer — next pass spec

Task: attach a provenance-backed concept-history row to each master concept.

For each concept, record:
- concept_id / English label
- concept-history class: eponymic, Greek-Latin internationalism, ordinary-metaphor concept, proof-prose act, compositional algebra construct, historical specialist concept, trap concept, or symbol/noise
- source metaphor or semantic prototype, if known
- predicted globalizability: high / medium / low / low-until-context-verified
- observed global class from the attractor table
- residual: matches prior / unexpected global attractor / unexpected fragmentation / source-intake gap
- required next action

Rules:
- This is concept history, not term etymology. The unit is the mathematical object/operation/proof-act.
- Do not count a string hit when the concept is a known trap (`modulus`, `ground form`, `binary form`, `complete system`, etc.) unless a KWIC window proves the intended sense.
- Treat eponyms as expected global attractors; treat proof connectives as expected local/register forms.
- For ordinary metaphors (`ring`, `field`, `kernel`, `image`, `set`), map which metaphor each language family chose.
- Output a patch to the concept web, not a term-promotion list.
