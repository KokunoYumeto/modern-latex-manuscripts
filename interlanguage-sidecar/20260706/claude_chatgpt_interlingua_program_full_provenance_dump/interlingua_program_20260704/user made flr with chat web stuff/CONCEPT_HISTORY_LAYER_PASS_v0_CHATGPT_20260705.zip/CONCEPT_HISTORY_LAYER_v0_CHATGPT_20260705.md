# Concept-history layer v0 — pilot

This artifact adds a concept-history / semantic-origin layer above the marker table. It does not decide terms. It predicts where a concept should admit a global attractor, where it should fragment into regional metaphors, and where mechanical string hits should be treated as traps until a sense window proves the intended concept.

## Counts

### History classes

- unclassified_or_mixed: 66
- historical_specialist_concept: 41
- greek_latin_internationalism: 36
- proof_prose_register: 26
- ordinary_metaphor_concept: 15
- compositional_algebra_construct: 15
- trap_concept: 9
- eponymic_globalizable: 8

### Prediction residuals

- matches_fragmented_or_gap: 72
- needs_history_lookup: 66
- residual_check: 45
- matches_high_attractor: 18
- needs_component_review: 15

## Interpretation

- **Eponyms and Greek/Latin internationalisms** are the natural global-register candidates. They should feed the global-attractor baseline rather than force a zonal invention.
- **Ordinary metaphor concepts** are where the global register usually fails: each language maps the abstract concept onto a different everyday metaphor. `ring` is the model case.
- **Proof-prose/register acts** do not globalize well as nouns; they are the likely controlled-register layer.
- **Historical specialist concepts** need domain/era source intake before any global or zonal claim.
- **Trap concepts** require sense windows before a hit is counted at all.

## Pilot rows

| Concept | History class | Predicted | Observed | D1 | Note |
|---|---:|---:|---:|---:|---|
| ring | ordinary_metaphor_concept | low_to_medium | G3_regional_doublet_or_local_standard_required | 2.964 | Ordinary circular-object / enclosing-object metaphor, not a single technical coinage. Local languages choose different everyday metaphors: ring/circle/jewelry ring/circuit/annulus. |
| quotient field | compositional_algebra_construct | medium | G2_global_register_with_local_glosses | 2.447 | Compositional algebra term. It inherits term-family choices from both quotient/fraction and field/body; predict local word-order and branch competition. |
| corollary | proof_prose_register | low | G3_regional_doublet_or_local_standard_required | 4.538 | Latin scholastic term competes with native “consequence/conclusion” terms. Predict regional doublets. |
| theorem | proof_prose_register | low | G2_global_register_with_local_glosses | 4.009 | Greek internationalism competes with native proof-register nouns in West Slavic and other languages; global term exists but local proof prose may prefer native forms. |
| polynomial | greek_latin_internationalism | high | G1_global_attractor_candidate | 1.417 | Greek/Latin international math term; global attractor expected, with native calque exceptions such as Polish/Czech-type many-term forms. |
| binary form | trap_concept | low_until_context_verified | G4_trap_or_false_sense_review | 3.0 | Specialist invariant-theory object; mechanical “binary form” phrase may hit unrelated CS/Hebb/neural contexts. |
| complete system | trap_concept | low_until_context_verified | G4_trap_or_false_sense_review | 1.89 | Specialist invariant-theory phrase; generic complete systems in ODEs/logic are false positives. |
| ground form | trap_concept | low_until_context_verified | G4_trap_or_false_sense_review | 3.82 | Specialist invariant-theory source phrase; generic “basic/fundamental form” translations are false positives unless context proves the invariant-theory sense. |
| invariant theory | historical_specialist_concept | low_to_medium | G2_global_register_with_local_glosses | 1.342 | Historical discipline label; international root likely stable, but subterms from classical invariant theory need era-appropriate specialist sources. |
| modulus | trap_concept | low_until_context_verified | G4_trap_or_false_sense_review | 2.09 | Trap concept: modulus/modul/module/moduli are mechanically attractive but sense-divergent across algebra, invariant theory, absolute value, and module terminology. |
| resultant | historical_specialist_concept | low_to_medium | G5_source_intake_needed | 1.786 | Specialist algebra/invariant-theory term; Romance/international witness likely, but not guaranteed globally without specialist sources. |
| transvection | historical_specialist_concept | low_to_medium | G2_global_register_with_local_glosses | 2.872 | Specialist classical/invariant-theory term; predict source-intake need rather than global attractor. |
| vector space | compositional_algebra_construct | medium | G1_global_attractor_candidate | 1.32 | globality depends on components and word order |
| field | ordinary_metaphor_concept | low_to_medium | G2_global_register_with_local_glosses | 5.517 | Algebraic concept imported through several older metaphors: field/corps/body/těleso/polje/campo. Predict regional doublets despite strong mathematical stability. |
| group | greek_latin_internationalism | high | G1_global_attractor_candidate | 1.57 | international scientific root likely stable across many lanes |
| homomorphism | greek_latin_internationalism | high | G1_global_attractor_candidate | 1.483 | Greek morphism family; global conceptual family expected, though some languages use semantic calques for “structure-preserving map.” |
| ideal | greek_latin_internationalism | high | G1_global_attractor_candidate | 1.973 | international scientific root likely stable across many lanes |
| matrix | greek_latin_internationalism | high | G2_global_register_with_local_glosses | 1.68 | Latin/international mathematical object name; global attractor expected despite local script adaptation. |
| module | greek_latin_internationalism | high | G1_global_attractor_candidate | 2.213 | International algebraic term but collides historically/orthographically with modulus/modul families. Predict global attractor with trap control. |
| proof | proof_prose_register | low | G2_global_register_with_local_glosses | 8.63 | Proof is a proof-act word, not an international object term. Predict local native terms and low global attractor stability. |
| function | proof_prose_register | low | G1_global_attractor_candidate | 3.013 | International or semi-international in many registers, but a basic word with local standardized equivalents; global comparator useful but not decisive. |
| relation | proof_prose_register | low | G2_global_register_with_local_glosses | 1.251 | Basic logical word with local equivalents; concept not hard, term not globally unified. |
| set | ordinary_metaphor_concept | low_to_medium | G3_regional_doublet_or_local_standard_required | 4.027 | Basic logical/mathematical object with strong native terminology across languages; predict no single global term even though notation is universal. |
| artinian | eponymic_globalizable | high | G5_source_intake_needed | 2.73 | Eponymic adjective. Eponyms are expected to be strong global attractors, modulo orthography and suffix policy. |
| noetherian | eponymic_globalizable | high | G3_regional_doublet_or_local_standard_required | 2.206 | Eponymic adjective. Eponyms are expected to be among the strongest global attractors, modulo orthography and suffix policy. |

## Use in the workstream

Use this layer as a prior, not as a verdict. The weighting graph should compare the prior with observed form-family evidence. Large mismatches become work items: either the classification is wrong, the markers are dirty, or the concept really is historically unusual.
