# Task note: predictive concept model v1

Use `PREDICTIVE_INTERLANGUAGE_CONCEPT_MODEL_v1_20260705.csv/json` as the routing layer for next work. Do not treat it as authority.

Priority order:
1. P0 blocking sense-audit rows: KWIC windows before any support count.
2. P1 review packet rows: no-verdict review with support/competitor/adverse channels.
3. P2 specialist-source rows: invariant-theory/historical source intake, not general shelves.
4. P2 proof-register rows: phrasebook normalization; evaluate by consistency and branch transparency, not term cognacy.
5. P3 global-baseline rows: use as global comparator; zonal terms must beat the baseline by marginal intelligibility.
