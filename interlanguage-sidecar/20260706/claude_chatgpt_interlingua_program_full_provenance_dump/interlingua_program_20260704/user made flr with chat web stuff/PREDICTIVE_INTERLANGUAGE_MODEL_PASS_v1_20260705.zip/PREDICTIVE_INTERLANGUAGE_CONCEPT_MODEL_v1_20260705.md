# Predictive interlanguage concept model v1
Generated: 2026-07-05.
Boundary: predictive evidence-routing only; no term promotion, no certification, no text patching.
## Inputs
- `ORIGINATING_REFLECTIONS_DIGEST_20260705.json`
- `CONCEPT_HISTORY_MESH_PILOT_v1_20260705.json`
- `GLOBAL_MATH_REGISTER_PILOT_v1_CHATGPT_20260705.json`
- `INTERLINGUAL_MARKER_TABLE_v3_3_20260705.json`

## Counts
- Rows: **343**

### prediction_mode
- `history_lookup_needed`: 127
- `global_attractor_baseline`: 67
- `controlled_proof_register`: 42
- `specialist_source_intake`: 41
- `zonal_bridge_high_value`: 26
- `component_schema_review`: 21
- `sense_audit_blocker`: 19

### priority
- `P4_background_enrichment`: 164
- `P3_global_baseline_column`: 65
- `P2_specialist_source_intake`: 41
- `P2_register_phrasebook`: 40
- `P0_blocking_sense_audit`: 19
- `P1_review_packet`: 14

### history_class
- `unclassified_history_needed`: 127
- `international_technical_root`: 55
- `proof_discourse_operator`: 42
- `historical_specialist_concept`: 41
- `ordinary_metaphor_abstraction`: 26
- `operation_or_relation_schema`: 21
- `trap_or_false_sense_concept`: 19
- `eponymic_anchor`: 12

## Rulebook extracted from the originating-session reflections
### R1_formula_anchor_controlled_register
- Rule: Formulae constrain semantics; proof prose is a small controlled register rather than a general language.
- Predicts: proof_discourse_operator -> controlled proof phrasebook; term-level global attractor normally weak, register-level global standardization plausible.
- Shortlist evidence ranks: [3, 4]
### R2_transparent_compound_when_axis_matters
- Rule: When a theorem-level distinction depends on a term axis, prefer transparent compounds and log artificiality/review points.
- Predicts: ordinary_metaphor_abstraction and operation_or_relation_schema -> high zonal gain, possible global fragmentation.
- Shortlist evidence ranks: [1, 7, 10]
### R3_internationalism_when_already_mathematical
- Rule: Use international stems where they already carry mathematical precision; do not force native compounds solely for ideology.
- Predicts: international_technical_root and eponymic_anchor -> global attractor candidate unless blocked by false-sense/adverse evidence.
- Shortlist evidence ranks: [2, 5, 9]
### R4_cumulative_pressure_normalizes
- Rule: A cumulative term graph may retroactively overturn plausible early choices when stronger recurring patterns emerge.
- Predicts: rows with high internal variance or competitor_ratio -> normalization/review priority; keep revision trail.
- Shortlist evidence ranks: [5, 8, 10]
### R5_script_sidecar_not_independent_witness
- Rule: One authority-script register can generate script variants, but generated script variants require text-layer and visual audits and are not independent witnesses.
- Predicts: script-sensitive rows -> deterministic sidecar validation, not language-family support.
- Shortlist evidence ranks: [3, 6]
### R6_false_friend_trap_blocks_mechanical_hits
- Rule: Historical false friends, generic phrases, and homographs must be treated as adverse until KWIC windows prove the intended sense.
- Predicts: trap_or_false_sense_concept -> blocked_until_sense_audit regardless of superficial cross-language hits.
- Shortlist evidence ranks: []
### R7_authority_boundary
- Rule: AI output is candidate terminology, consistency maps, examples, and reviewable alternatives; authority belongs to communities/editors/named language experts.
- Predicts: any high-impact or dominance-sensitive row -> review packet / no unilateral promotion.
- Shortlist evidence ranks: [4, 8, 10]

## Top priority rows

### P0_blocking_sense_audit (19)
| concept | class | observed | score | residual | next action |
|---|---|---:|---:|---|---|
| modulus | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 48.0 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| ground form | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 43.4 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| complete system | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 31.1 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| binary form | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 19.4 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| proof register: holds is valid | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 0.0 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| proof register: however | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 0.0 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| proof register: remain ostati | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 0.0 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| proof register: series sequence red | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 0.0 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| covariant | trap_or_false_sense_concept | G1_global_attractor_candidate | 52.8 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| contravariant | trap_or_false_sense_concept | G2_global_register_with_local_glosses | 50.8 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| bordering operation | trap_or_false_sense_concept | G5_source_intake_needed | 43.2 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| absolutely complete system | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 41.6 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| form system | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 41.6 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| relatively complete system | trap_or_false_sense_concept | G4_trap_or_false_sense_review | 41.6 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| reducible | trap_or_false_sense_concept | G5_source_intake_needed | 41.6 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| completely reducible | trap_or_false_sense_concept | G3_regional_doublet_or_local_standard_required | 40.6 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| irreducible representation | trap_or_false_sense_concept | G5_source_intake_needed | 29.3 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| irreducible ideal | trap_or_false_sense_concept | G5_source_intake_needed | 25.7 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |
| irreducible | trap_or_false_sense_concept | G5_source_intake_needed | 24.5 | blocked_until_kwic_sense_review | Require KWIC sense windows before counting cognate/mechanical hits as support. |

### P1_review_packet (14)
| concept | class | observed | score | residual | next action |
|---|---|---:|---:|---|---|
| ring | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_required | 72.7 | prediction_matches_regional_split | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| set | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_required | 59.4 | prediction_matches_regional_split | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| splitting field | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_required | 36.5 | prediction_matches_regional_split | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| division ring | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_required | 28.5 | prediction_matches_regional_split | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| center | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_required | 27.1 | prediction_matches_regional_split | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| division ring / body | ordinary_metaphor_abstraction | G3_regional_doublet_or_local_standard_required | 26.4 | prediction_matches_regional_split | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| noetherian | eponymic_anchor | G3_regional_doublet_or_local_standard_required | 50.3 | partial_fragmentation_check_local_glosses | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| matrix | international_technical_root | G2_global_register_with_local_glosses | 69.4 | partial_fragmentation_check_local_glosses | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| field | ordinary_metaphor_abstraction | G2_global_register_with_local_glosses | 62.7 | zonal_margin_probe_needed | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| theorem | proof_discourse_operator | G2_global_register_with_local_glosses | 60.8 | predict_no_term_attractor_design_phrasebook | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| corollary | proof_discourse_operator | G3_regional_doublet_or_local_standard_required | 60.1 | predict_no_term_attractor_design_phrasebook | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| quotient field | operation_or_relation_schema | G2_global_register_with_local_glosses | 43.4 | component_decomposition_required | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| trace | operation_or_relation_schema | G3_regional_doublet_or_local_standard_required | 25.4 | component_decomposition_required | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |
| extension (field) | operation_or_relation_schema | G3_regional_doublet_or_local_standard_required | 22.9 | component_decomposition_required | Assemble no-verdict review row with support/competitor/adverse channels and branch weights. |

### P2_specialist_source_intake (41)
| concept | class | observed | score | residual | next action |
|---|---|---:|---:|---|---|
| invariant | historical_specialist_concept | G1_global_attractor_candidate | 77.5 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| invariant theory | historical_specialist_concept | G2_global_register_with_local_glosses | 60.4 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| resultant | historical_specialist_concept | G5_source_intake_needed | 51.8 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| ring without radical | historical_specialist_concept | G5_source_intake_needed | 51.7 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| reducent | historical_specialist_concept | G5_source_intake_needed | 51.6 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| general ideal theory | historical_specialist_concept | G5_source_intake_needed | 46.9 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| form | historical_specialist_concept | G5_source_intake_needed | 46.8 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| reduction | historical_specialist_concept | G2_global_register_with_local_glosses | 45.1 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| characteristic series | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| complete form sequence | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| double reduction | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| field of automorphisms | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| form sequence | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| initial form | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| multiplier domain | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| representation module | historical_specialist_concept | G5_source_intake_needed | 43.2 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| associated prime ideal | historical_specialist_concept | G5_source_intake_needed | 42.6 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| crossed product | historical_specialist_concept | G3_regional_doublet_or_local_standard_required | 42.0 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| crossed representation | historical_specialist_concept | G3_regional_doublet_or_local_standard_required | 42.0 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| elementary divisor | historical_specialist_concept | G3_regional_doublet_or_local_standard_required | 42.0 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| factor system | historical_specialist_concept | G3_regional_doublet_or_local_standard_required | 42.0 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| transformation quantities | historical_specialist_concept | G5_source_intake_needed | 42.0 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| biquadratic form | historical_specialist_concept | G5_source_intake_needed | 41.6 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| ternary form | historical_specialist_concept | G5_source_intake_needed | 41.6 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |
| prime function / primary function | historical_specialist_concept | G5_source_intake_needed | 40.5 | specialist_sources_required_do_not_general_shelf | Use era-appropriate specialist sources; do not fill from general algebra shelves. |

### P2_register_phrasebook (40)
| concept | class | observed | score | residual | next action |
|---|---|---:|---:|---|---|
| definition | proof_discourse_operator | G1_global_attractor_candidate | 70.1 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| lemma | proof_discourse_operator | G2_global_register_with_local_glosses | 65.7 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: case instance | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: corresponds | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: follows from | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: length | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: reg obći | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: reg odnovrěmenno | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: reg pytanje | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: reg rěšenje | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: reg sostojati | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: step | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: take vzeti | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: type | proof_discourse_operator | G5_source_intake_needed | 55.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof | proof_discourse_operator | G2_global_register_with_local_glosses | 52.4 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| problem | proof_discourse_operator | G2_global_register_with_local_glosses | 50.3 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| example | proof_discourse_operator | G2_global_register_with_local_glosses | 49.7 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: assumption noun | proof_discourse_operator | G5_source_intake_needed | 47.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: carry out | proof_discourse_operator | G5_source_intake_needed | 47.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: contrary | proof_discourse_operator | G5_source_intake_needed | 47.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: entirely | proof_discourse_operator | G5_source_intake_needed | 47.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proof register: reg imenno | proof_discourse_operator | G5_source_intake_needed | 47.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| basis theorem | proof_discourse_operator | G5_source_intake_needed | 43.6 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| proposition | proof_discourse_operator | G5_source_intake_needed | 41.7 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |
| assumption | proof_discourse_operator | G3_regional_doublet_or_local_standard_required | 39.0 | predict_no_term_attractor_design_phrasebook | Treat as controlled proof-register phrase; evaluate phrase consistency and branch transparency. |

### P3_global_baseline_column (65)
| concept | class | observed | score | residual | next action |
|---|---|---:|---:|---|---|
| polynomial | international_technical_root | G1_global_attractor_candidate | 87.6 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| ideal | international_technical_root | G1_global_attractor_candidate | 84.4 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| module | international_technical_root | G1_global_attractor_candidate | 81.5 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| homomorphism | international_technical_root | G1_global_attractor_candidate | 81.0 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| isomorphism | international_technical_root | G1_global_attractor_candidate | 78.8 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| determinant | international_technical_root | G1_global_attractor_candidate | 77.3 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| vector | international_technical_root | G1_global_attractor_candidate | 75.0 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| dimension | international_technical_root | G1_global_attractor_candidate | 72.9 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| algebra | international_technical_root | G1_global_attractor_candidate | 71.3 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| subgroup | international_technical_root | G1_global_attractor_candidate | 68.1 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| vector space | international_technical_root | G1_global_attractor_candidate | 65.7 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| coefficient | international_technical_root | G1_global_attractor_candidate | 63.6 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| function | international_technical_root | G1_global_attractor_candidate | 59.5 | prediction_matches_global_attractor | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| galois | eponymic_anchor | G5_source_intake_needed | 47.6 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| noetherian/noether | eponymic_anchor | G5_source_intake_needed | 43.6 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| dedekind mertens theorem | eponymic_anchor | G5_source_intake_needed | 43.2 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| artinian module | eponymic_anchor | G5_source_intake_needed | 42.0 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| noetherian module | eponymic_anchor | G5_source_intake_needed | 41.6 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| artinian | eponymic_anchor | G5_source_intake_needed | 33.2 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| galois group | eponymic_anchor | G5_source_intake_needed | 24.5 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| hilbert basis theorem | eponymic_anchor | G5_source_intake_needed | 24.5 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| hilbertsche behauptung | eponymic_anchor | G5_source_intake_needed | 0.0 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| tabellarisch durchgeführt | eponymic_anchor | G5_source_intake_needed | 0.0 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| tabelle | eponymic_anchor | G5_source_intake_needed | 0.0 | source_intake_or_marker_cleanup_needed | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |
| prime ideal | international_technical_root | G2_global_register_with_local_glosses | 68.6 | partial_fragmentation_check_local_glosses | Use as global comparator baseline; zonal form must show marginal intelligibility gain. |

## Ten mined reflection quotes used as methodology anchors
1. **2026-06-13T18:24Z — Paper19 Section11** (`term-selection-method`): “It builds a controlled register by keeping transparent compounds stable, recording where they are artificial, and exposing review points for a human authority.”
2. **2026-06-13T23:16Z — Paper22 §2** (`term-selection-method`): “The Interslavic lane shows a productive hybrid strategy: international stems for `modul`, `norma`, `determinant`, and `teorem`, but transparent Slavic compounds for `najmenše obče mnogokratno`, `največši obči dělitelj`, and `vzaimna prostota`.”
3. **2026-06-14T01:03Z — Paper22 §4** (`script-policy`): “Terms such as `sistem ostatkovyh klasov`, `sistem predstaviteljev`, and `izomorfija` are chosen under pressure from formulae, earlier project usage, and the need for Latin/Cyrillic dual-script readability.”
4. **2026-06-14T04:28Z — Paper22** (`review-protocol`): “Generalizable method note: for semi-constructed scientific languages, an AI system can use formula anchors, cumulative term logs, deterministic script conversion, and visual page audits to produce reviewable technical registers; the method should preserve uncertainty and invite human authority review at exactly the logged pressure points.”
5. **2026-06-14T11:27:39.561Z — Paper26** (`term-selection-method`): “This supports a broader methodology for semi-constructed language translation: use a cumulative term ledger, prefer transparent pan-family morphology where stable, permit internationalisms where they are already mathematical, and retroactively normalize earlier choices when the corpus reveals a stronger canonical term.”
6. **2026-06-14T12:54:39.205Z — Paper29** (`term-selection-method`): “This supports a general methodology for AI-assisted semi-constructed mathematical language: start from a source-of-truth script, maintain a machine-readable glossary, use deterministic alternate-script generation, log every term decision, and retroactively update earlier choices when a better canonical pattern emerges.”
7. **2026-06-24T02:31:11Z — Reflection on broader Slavic triangulation** (`term-selection-method`): “Generalizable methodology: build a typed terminology graph across related natural languages, select the constructed-language term by semantic role and cumulative coherence, then record all plausible alternatives with the evidence that would trigger a retroactive change.”
8. **2026-06-24T08:26Z — Paper34 section05** (`review-protocol`): “Publication note: the AI contribution is not merely producing text, but maintaining a reversible decision graph between source term, national-language witnesses, Interslavic target form, script conversion, and future reviewer flags.”
9. **2026-06-27T20:02:56.434Z — Paper39** (`term-selection-method`): “This suggests a generalizable method beyond Interslavic: collect canonical terms from neighboring natural languages, preserve international stems where they already carry mathematical precision, choose transparent family-wide morphology for structural relations, and keep every coined or semi-coined term review-visible with a rationale and revision trail.”
10. **2026-06-28T02:08:41Z — Paper42** (`review-protocol`): “This is one of the places where AI is useful not because it invents many new words, but because it can maintain a cumulative term graph across many dense papers and expose each responsibility-bearing choice for later human authority review.”
