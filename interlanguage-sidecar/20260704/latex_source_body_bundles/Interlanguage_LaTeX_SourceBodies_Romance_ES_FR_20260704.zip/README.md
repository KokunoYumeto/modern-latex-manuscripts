# Romance Spanish/French LaTeX source-body bundle

External/native or source-register Spanish/French mathematical LaTeX corpora for language-register baselines.

This bundle contains actual LaTeX/source-support file bodies, not just manifests. It is intended as a Web/Pro source-reference feed. Generated translation TeX, where present, is labelled as support material and is not native-source attestation.

File count: 1524
Uncompressed selected bytes: 33046153

See MANIFEST.csv for source archive/path provenance and per-file SHA256.
