# Persian/RTL/Arabic-script LaTeX source-body bundle

Persian/Farsi mathematical LaTeX, XePersian support, and Arabic-script render-review TeX support for RTL/register baselines.

This bundle contains actual LaTeX/source-support file bodies, not just manifests. It is intended as a Web/Pro source-reference feed. Generated translation TeX, where present, is labelled as support material and is not native-source attestation.

File count: 1251
Uncompressed selected bytes: 2850635

See MANIFEST.csv for source archive/path provenance and per-file SHA256.
