# R3 Paper01 Cumulative Arabic/Persianate Review Packet (20260629T154505Z)

Status: `review_packet_no_native_review_no_pilot`

## Purpose

This packet gathers the current Paper01 cumulative controlled Arabic, Persian/Farsi, and Persianate bridge drafts, plus adjacent review-only reducer drafts and non-erasure matrices, into one reviewer-facing folder.

## Review Roles

- `controlled_arabic_math_language`: review Arabic PDF; Arabic TeX; hard term table; Open Logic/AATA comparator rows. Decisions needed: form/formula separation; complete-system terminology; folding/reducer/double-reduction; classical invariant-theory register.
- `persian_farsi_math_language`: review Persian/Farsi PDF; Persian/Farsi TeX; hard term table; Open Logic/AATA comparator rows. Decisions needed: form/formula separation; complete-system terminology; taakhord/folding choices; ring/field/ideal seeds.
- `persianate_bridge_safety`: review Bridge PDF; bridge TeX; adjacent rejection matrix. Decisions needed: which terms must be removed from bridge; which bridge terms are only annotations; where bridge is misleading.
- `dari_tajik_review`: review Dari reducer PDF/TeX; Tajik reducer PDF/TeX; matrix rows; Open Logic/AATA seeds. Decisions needed: Dari vs Farsi divergence; Tajik Cyrillic terms; whether cumulative Dari/Tajik packet is safe to start.
- `urdu_kurdish_review`: review Urdu reducer PDF/TeX; Sorani reducer PDF/TeX; matrix rows; Open Logic/AATA seeds. Decisions needed: Urdu vs Hindi/Devanagari split; Sorani vs Kurmanji split; loan vs calque choices.

## Contents

- Manifest: `manifest.json`
- Risk terms: `risk_terms.json`
- Reviewer return template: `reviewer_return_template.json`
- Cumulative PDFs: `pdfs/controlled_arabic/`, `pdfs/persian_farsi/`, `pdfs/persianate_bridge/`
- Adjacent review PDFs: `pdfs/dari_afghan_persian/`, `pdfs/tajik_cyrillic/`, `pdfs/urdu_hindustani/`, `pdfs/kurdish_sorani/`
- Sources/TeX: `sources/`
- Non-erasure matrix: `matrix/`
- Beyond-Noether seed rows: `beyond_noether/`

## Boundary

- This is a review packet only.
- No terms are promoted.
- No native/domain review is complete.
- The Persianate bridge is not a living language and does not cover Dari, Tajik, Urdu/Hindustani, Pashto, Kurdish, Sindhi, Uyghur, or Turkic.
- Generated PDFs in this folder are local review outputs, not source evidence.
