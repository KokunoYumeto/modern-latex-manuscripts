# CJK Chinese/Japanese LaTeX source-body bundle

Chinese/CJK mathematical LaTeX source corpora and CJK support sources for register and typesetting baselines.

This bundle contains actual LaTeX/source-support file bodies, not just manifests. It is intended as a Web/Pro source-reference feed. Generated translation TeX, where present, is labelled as support material and is not native-source attestation.

File count: 194
Uncompressed selected bytes: 8331216

See MANIFEST.csv for source archive/path provenance and per-file SHA256.
