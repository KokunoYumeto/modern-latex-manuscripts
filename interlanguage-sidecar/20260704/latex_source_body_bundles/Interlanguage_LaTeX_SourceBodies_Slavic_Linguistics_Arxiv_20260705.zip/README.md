# Slavic / Interlanguage Linguistics arXiv Source Bodies, 2026-07-05

This bundle expands the arXiv source tarballs that were already present in the Slavic canonical-baseline witness folder and exposes their actual source bodies.

Scope: source files from arXiv papers about Slavic/interlanguage/computational-linguistic topics. These are useful baseline scholarly/linguistic source bodies for the interlanguage sidecar.

Conservative classification: this is **not** the missing native Czech/Polish/Slovak/South-Slavic mathematical TeX corpus. Most of these files are scholarly papers about Slavic/interlanguage topics, often written in English. They are source bodies and useful methodological/style evidence, but they do not certify native mathematical terminology for each target language.

Included extensions: `.tex`, `.ltx`, `.sty`, `.cls`, `.bib`, `.bst`, `.bbl`, `.dtx`, `.ins`, `.json`, `.md`, `.txt`.

See `MANIFEST_slavic_linguistics_arxiv_source_bodies_20260705.csv` for arXiv IDs, archive names, included paths, byte counts, hashes, and classification.
