# Slavic/Interslavic LaTeX source and generated-support bundle

Includes Czech source archives, Interslavic repositories, Slavic review-support TeX, and generated Noether Russian/Ukrainian/Interslavic support TeX. Generated Noether files are internal consistency support, not native-source attestation.

This bundle contains actual LaTeX/source-support file bodies, not just manifests. It is intended as a Web/Pro source-reference feed. Generated translation TeX, where present, is labelled as support material and is not native-source attestation.

File count: 1192
Uncompressed selected bytes: 20977282

See MANIFEST.csv for source archive/path provenance and per-file SHA256.
