# Interlanguage Backup-Dump Non-Slavic TeX Feed: arabic_persianate_rtl

Generated: 2026-07-05

Source root: C:\Users\Floris\Downloads\codex backup dump 7-4\$germanOut\sources\non_slavic_reference_corpus

This ZIP contains extracted TeX-family source files from the local backup-dump non-Slavic reference corpus. It excludes PDFs and giant whole-tree backup archives. Use it as source-style/register evidence for web/pro language work, not as translation completion or native approval.

Archives represented: 24
Extracted TeX-family files: 1831
Raw extracted bytes before ZIP compression: 7161815
Listing/extraction errors: 0

Classification: source-corpus/provenance support only; not native review, not accepted terminology, not translation completion, not source-fidelity certification, not publication readiness, not reader output, and not a critical edition.
