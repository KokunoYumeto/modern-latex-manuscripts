# Interlingual Marker Table v2 — weighted all-concept map

Generated 2026-07-04. This extends the 138-row marker table to the full current concept universe by adding ledger-only/source-intake concepts from the all-concept map; it keeps Fable’s [S]/[C] semantics and adds source weights, priority bands, main-source pointers, and adverse-evidence fields.

## Rollup
- **base_marker_v1_concepts**: 138
- **supplemental_concepts_added**: 64
- **C2_yes**: 70
- **review_priority**: 2
- **adverse_or_competitor_rows**: 23
- **Noether_corpus**: 49
- **source_intake_or_gap**: 106
- **priority_bands**: {'P0_authority_review': 2, 'P1_adverse_or_variant_policy': 21, 'P2_C2_fill': 27, 'P3_source_intake': 39, 'P3_specialist_source_intake': 31, 'P4_confirm_or_backfill': 82}

## Priority bands
| Band | Count | Meaning |
|---|---:|---|
| P0_authority_review | 2 | review packet / authority question; no verdict |
| P1_adverse_or_variant_policy | 21 | competitor, collision, or variant/doublet policy row |
| P2_C2_fill | 27 | C2 core row needing fill/gap/not-applicable work |
| P3_source_intake | 39 | ordinary source-intake/gap row |
| P3_specialist_source_intake | 31 | Noether/historical or low-source intake needed |
| P4_confirm_or_backfill | 82 | maintain; backfill source pointers when convenient |

## Top 30 work rows
| Rank | Concept | Stratum | Band | Action | Sensitivity | Weight | Support/Comp | Sources |
|---:|---|---|---|---|---|---:|---|---|
| 1 | ring | curriculum_algebra | P0_authority_review | review_priority | weight_sensitive | 17.633 | S=0 C=6 fill=23 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 2 | quotient field | curriculum_algebra | P0_authority_review | review_priority | weight_sensitive | 0.95 | S=0 C=2 fill=8 | COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; INTERLINGUAL_CONCEPT_LEDGER_20260704 |
| 3 | extension (field) |  | P1_adverse_or_variant_policy | variant_or_doublet_note | weight_sensitive | 1.34 | S=1 C=3 fill=5 | COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; WEIGHTED_INTELLIGIBILITY_SCORES_v3_2 |
| 4 | absolutely complete system | noether_corpus | P2_C2_fill | source_intake |  | 1.0 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 5 | binary form | noether_corpus | P2_C2_fill | source_intake |  | 1.767 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 6 | biquadratic form | noether_corpus | P2_C2_fill | source_intake |  | 1.267 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 7 | complete system | noether_corpus | P2_C2_fill | source_intake |  | 1.767 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 8 | contravariant | noether_corpus | P2_C2_fill | source_intake |  | 1.0 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 9 | form system | noether_corpus | P2_C2_fill | source_intake |  | 1.5 | S=0 C=0 fill=3 |  |
| 10 | modulus | noether_corpus | P2_C2_fill | source_intake |  | 1.0 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 11 | reduction | noether_corpus | P2_C2_fill | source_intake |  | 4.1 | S=0 C=0 fill=3 | INTERLINGUAL_CONCEPT_LEDGER_20260704.json; STRATIFIED_CORE_SPINE_PROPOSAL_202607 |
| 12 | relatively complete system | noether_corpus | P2_C2_fill | source_intake |  | 2.0 | S=0 C=0 fill=3 | INTERLINGUAL_CONCEPT_LEDGER_20260704.json; STRATIFIED_CORE_SPINE_PROPOSAL_202607 |
| 13 | system of forms | noether_corpus | P2_C2_fill | source_intake |  | 2.417 | S=0 C=0 fill=3 | INTERLINGUAL_CONCEPT_LEDGER_20260704.json; STRATIFIED_CORE_SPINE_PROPOSAL_202607 |
| 14 | ternary form | noether_corpus | P2_C2_fill | source_intake |  | 1.767 | S=0 C=0 fill=3 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 15 | invariant theory | noether_corpus | P2_C2_fill | source_intake |  | 1.8 | S=0 C=0 fill=3 | INTERLINGUAL_CONCEPT_LEDGER_20260704.json; STRATIFIED_CORE_SPINE_PROPOSAL_202607 |
| 16 | field | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 21.123 | S=4 C=5 fill=23 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 17 | decomposition identity | noether_corpus | P3_specialist_source_intake |  |  | 0.9 | S=0 C=0 fill=3 | INTERLINGUAL_CONCEPT_LEDGER_20260704.json |
| 18 | corollary | proof_grammar | P1_adverse_or_variant_policy | variant_or_doublet_note | stable | 11.13 | S=1 C=4 fill=13 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 19 | set | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 15.471 | S=5 C=4 fill=10 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 20 | division ring | algebra_invariant_theory | P1_adverse_or_variant_policy | confirm_current | stable | 2.5 | S=4 C=5 fill=11 | UNION_TERM_SPINE_v2_WITH_SLAVIC.json |
| 21 | resultant | noether_corpus | P2_C2_fill |  |  | 1.0 | S=0 C=0 fill=7 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 22 | transvection | noether_corpus | P2_C2_fill |  |  | 2.9 | S=0 C=0 fill=5 | INTERLINGUAL_CONCEPT_LEDGER_20260704.json; STRATIFIED_CORE_SPINE_PROPOSAL_202607 |
| 23 | prime ideal | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 11.046 | S=4 C=3 fill=19 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 24 | representation | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 17.803 | S=5 C=3 fill=22 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 25 | theorem | proof_grammar | P1_adverse_or_variant_policy | variant_or_doublet_note | stable | 16.145 | S=2 C=3 fill=21 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 26 | proposition | proof_grammar | P2_C2_fill | source_intake |  | 2.5 | S=0 C=0 fill=2 | STRATIFIED_CORE_SPINE_PROPOSAL_20260704.json; UNION_TERM_SPINE_v2_WITH_SLAVIC.js |
| 27 | element | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 16.133 | S=6 C=2 fill=10 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 28 | matrix | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 17.369 | S=3 C=2 fill=17 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 29 | proof | proof_grammar | P1_adverse_or_variant_policy | confirm_current | stable | 16.347 | S=5 C=2 fill=18 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |
| 30 | subset | curriculum_algebra | P1_adverse_or_variant_policy | confirm_current | stable | 12.08 | S=4 C=2 fill=10 | C2_CONTEXT_WINDOWS_v1_20260704.json; COMPARATIVE_TERM_ANALYSIS_v1_20260704.json; |

## Scoring boundary
- `[S]` means a source branch attests a cognate/supporting lexeme family for the current bridge form at concept-shelf level.
- `[C]` means the source branch attests a competitor lexeme; this is adverse evidence for family-centrality, not an error by itself.
- Empty cells are honest gaps, not zero evidence.
- `source_weight` and `priority_score` are work-order triage fields, not term decisions.
- `review_priority` rows remain no-verdict packets until community/external review.