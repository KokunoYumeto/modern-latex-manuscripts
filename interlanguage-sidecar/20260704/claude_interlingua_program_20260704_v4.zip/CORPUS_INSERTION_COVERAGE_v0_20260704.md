# Corpus Insertion Coverage — v0 (the completeness metric)

2026-07-04. Floris's bar: the COMPLETE corpus, every word inserted and correctly weighted. This artifact defines and measures the distance. Mechanical v0 (stem-matched): treat numbers as estimates with stated biases.

- Corpus: 265 dedup Latin-script TeX files; lexicon 11,907 content types / 142,136 tokens (stoplist-filtered).
- **Type coverage: 68.6%** (8,173/11,907) · **Token coverage: 93.8%** (133,384/142,136)
- Gap queue: 3,734 uncovered types, frequency-ordered (top 500 in json).

## Top 60 uncovered types (the front of the insertion grind)

-    11  tamže
-    11  ničto
-    11  polynomideale
-    11  const
-    11  imal
-    11  vodet
-    11  vybrati
-    11  jesmo
-    11  novih
-    11  wissensch
-    11  university
-    11  vezi
-    11  idenje
-    11  umenšila
-    11  izrekti
-    11  trudnosti
-    11  tracts
-    11  uvedenymi
-    11  dotyka
-    11  dakle
-    11  riemannovoj
-    10  izhodet
-    10  svojem
-    10  nepotrěbno
-    10  podmodul
-    10  numerovanju
-    10  nastati
-    10  ležeče
-    10  vstavjenje
-    10  naše
-    10  schur
-    10  veliko
-    10  respektivno
-    10  jesm
-    10  sprava
-    10  tekst
-    10  prethodi
-    10  menšej
-    10  svojoj
-    10  najdut
-    10  vzame
-    10  sili
-    10  ikakih
-    10  nedostaje
-    10  zadaču
-    10  bezvěstno
-    10  izčezly
-    10  dixmuiden
-    10  disertacija
-    10  spomenutyh
-    10  uvedenju
-    10  uspěl
-    10  zahlkörpern
-    10  podloženo
-    10  pomnoženjem
-    10  danymi
-    10  dobyva
-    10  časti
-    10  klajna
-    10  pascal