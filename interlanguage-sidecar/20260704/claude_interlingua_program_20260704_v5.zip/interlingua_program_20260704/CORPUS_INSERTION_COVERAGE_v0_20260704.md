# Corpus Insertion Coverage — v0 (the completeness metric)

2026-07-04. Floris's bar: the COMPLETE corpus, every word inserted and correctly weighted. This artifact defines and measures the distance. Mechanical v0 (stem-matched): treat numbers as estimates with stated biases.

- Corpus: 265 dedup Latin-script TeX files; lexicon 11,907 content types / 142,136 tokens (stoplist-filtered).
- **Type coverage: 72.9%** (8,682/11,907) · **Token coverage: 95.0%** (135,004/142,136)
- Gap queue: 3,225 uncovered types, frequency-ordered (top 500 in json).

## Top 60 uncovered types (the front of the insertion grind)

-    11  tamže
-    11  ničto
-    11  polynomideale
-    11  const
-    11  imal
-    11  jesmo
-    11  novih
-    11  wissensch
-    11  university
-    11  vezi
-    11  idenje
-    11  umenšila
-    11  trudnosti
-    11  tracts
-    11  uvedenymi
-    11  dotyka
-    10  svojem
-    10  vstavjenje
-    10  naše
-    10  schur
-    10  jesm
-    10  tekst
-    10  menšej
-    10  svojoj
-    10  najdut
-    10  vzame
-    10  sili
-    10  ikakih
-    10  nedostaje
-    10  zadaču
-    10  bezvěstno
-    10  izčezly
-    10  dixmuiden
-    10  spomenutyh
-    10  uvedenju
-    10  uspěl
-    10  zahlkörpern
-    10  pomnoženjem
-    10  danymi
-    10  časti
-    10  klajna
-    10  pascal
-    10  względom
-     9  putem
-     9  pregled
-     9  inducirajut
-     9  adično
-     9  deuring
-     9  zahlen
-     9  eine
-     9  raněje
-     9  hoču
-     9  mogl
-     9  potrebno
-     9  okolo
-     9  vyšu
-     9  danomu
-     9  pogled
-     9  uvagoj
-     9  ponjatijno