# Interlanguage / Interslavic source-anchor bundle

Built: 20260704

This ZIP is source material for the interlanguage / Interslavic / Slavic terminology construction work. It excludes generated translation output as source authority and includes downloaded source/control witnesses plus manifests.

Included:
- 01_non_ru_uk_slavic_baseline_pdf_sources: Czech, Polish, Slovak, Slovenian, Serbian, Croatian, Bulgarian PDF witnesses from the broad Slavic reference register.
- 02_underrepresented_slavic_belarusian_macedonian_sorbian_anchors: Belarusian, Macedonian, Sorbian source anchors from the underrepresented-branch register. Includes HTML/PDF captures where downloads resolved and manifest rows for failed sources.

Known gap:
- Macedonian UKIM n-ary algebra direct PDF returned 404 at fetch time; it remains listed in the manifest for follow-up.

Use:
- Feed this to Web/Pro as source-control context.
- Do not treat generated Interslavic/Ukrainian/Russian draft translations as independent native witnesses.
