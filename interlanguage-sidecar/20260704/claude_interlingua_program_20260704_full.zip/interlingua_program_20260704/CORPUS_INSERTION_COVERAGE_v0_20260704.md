# Corpus Insertion Coverage — v0 (the completeness metric)

2026-07-04. Floris's bar: the COMPLETE corpus, every word inserted and correctly weighted. This artifact defines and measures the distance. Mechanical v0 (stem-matched): treat numbers as estimates with stated biases.

- Corpus: 265 dedup Latin-script TeX files; lexicon 12,016 content types / 144,139 tokens (stoplist-filtered).
- **Type coverage: 57.5%** (6,905/12,016) · **Token coverage: 87.5%** (126,095/144,139)
- Gap queue: 5,111 uncovered types, frequency-ordered (top 500 in json).

## Top 60 uncovered types (the front of the insertion grind)

-    38  vyvedeny
-    37  neobhodno
-    36  ostaje
-    36  nastaje
-    36  sohranja
-    36  xiii
-    35  čiji
-    35  danogo
-    35  tymy
-    34  opira
-    34  odmah
-    34  paralelno
-    34  toga
-    34  tělu
-    34  sama
-    33  novo
-    33  čisto
-    33  rečeno
-    32  tuto
-    32  sovsěm
-    32  sposobom
-    32  stoji
-    31  annalen
-    31  nachr
-    31  raboty
-    31  izčeznuti
-    30  koli
-    30  naravno
-    30  dati
-    30  leme
-    30  každomu
-    29  nahodi
-    29  imeno
-    29  gdje
-    28  obhvača
-    28  obču
-    28  však
-    28  vobče
-    28  njega
-    28  vprašanje
-    28  zaměnoju
-    28  čego
-    28  musi
-    27  voobče
-    27  dodanjem
-    26  obojih
-    26  bazoju
-    26  prvoj
-    26  wiss
-    26  rabotě
-    26  cituje
-    26  taku
-    26  obrabotka
-    25  idut
-    25  nijedno
-    25  ukazati
-    25  sumi
-    25  dlugosti
-    25  vystupaje
-    25  macaulay