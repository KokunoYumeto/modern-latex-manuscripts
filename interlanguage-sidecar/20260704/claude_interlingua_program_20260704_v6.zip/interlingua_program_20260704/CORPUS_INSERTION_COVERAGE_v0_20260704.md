# Corpus Insertion Coverage — v0 (the completeness metric)

2026-07-04. Floris's bar: the COMPLETE corpus, every word inserted and correctly weighted. This artifact defines and measures the distance. Mechanical v0 (stem-matched): treat numbers as estimates with stated biases.

- Corpus: 265 dedup Latin-script TeX files; lexicon 11,907 content types / 142,136 tokens (stoplist-filtered).
- **Type coverage: 75.4%** (8,980/11,907) · **Token coverage: 95.7%** (136,039/142,136)
- Gap queue: 2,927 uncovered types, frequency-ordered (top 500 in json).

## Top 60 uncovered types (the front of the insertion grind)

-    11  tamže
-    11  polynomideale
-    11  const
-    11  imal
-    11  jesmo
-    11  wissensch
-    11  university
-    11  vezi
-    11  idenje
-    11  trudnosti
-    11  tracts
-    11  uvedenymi
-    11  dotyka
-    10  svojem
-    10  vstavjenje
-    10  schur
-    10  jesm
-    10  tekst
-    10  menšej
-    10  svojoj
-    10  najdut
-    10  vzame
-    10  sili
-    10  ikakih
-    10  bezvěstno
-    10  izčezly
-    10  dixmuiden
-    10  uvedenju
-    10  uspěl
-    10  zahlkörpern
-    10  pomnoženjem
-    10  danymi
-    10  pascal
-    10  względom
-     9  putem
-     9  deuring
-     9  zahlen
-     9  eine
-     9  potrebno
-     9  vyšu
-     9  danomu
-     9  pogled
-     9  uvagoj
-     9  ponjatijno
-     9  umrlimi
-     9  razprava
-     9  najsuščstvenej
-     9  lětu
-     9  doktoroval
-     9  napisana
-     9  idej
-     9  probojev
-     9  izgradžena
-     9  ponjatja
-     9  opisane
-     9  petimi
-     9  otsutstvuje
-     9  planovane
-     9  prěrabotky
-     9  podaju