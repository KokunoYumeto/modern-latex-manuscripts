# Corpus Insertion Coverage — v0 (the completeness metric)

2026-07-04. Floris's bar: the COMPLETE corpus, every word inserted and correctly weighted. This artifact defines and measures the distance. Mechanical v0 (stem-matched): treat numbers as estimates with stated biases.

- Corpus: 265 dedup Latin-script TeX files; lexicon 11,928 content types / 142,401 tokens (stoplist-filtered).
- **Type coverage: 67.0%** (7,991/11,928) · **Token coverage: 93.1%** (132,556/142,401)
- Gap queue: 3,937 uncovered types, frequency-ordered (top 500 in json).

## Top 60 uncovered types (the front of the insertion grind)

-    15  každoj
-    14  reine
-    14  systems
-    14  utvoriti
-    14  danej
-    14  uproščenje
-    14  měnjajuči
-    14  prěmo
-    14  fischer
-    14  zapisati
-    14  tolko
-    13  izloženje
-    13  waerden
-    13  navedene
-    13  takomu
-    13  nikaky
-    13  naměsto
-    13  vsude
-    13  beremo
-    13  moglo
-    13  distributivny
-    13  funktionen
-    13  odděliti
-    13  teraz
-    13  kojikoli
-    12  něčto
-    12  oktobra
-    12  dala
-    12  vzęti
-    12  razvijena
-    12  javno
-    12  pary
-    12  rolu
-    12  sostaji
-    12  njimi
-    12  važnosti
-    12  obščnosti
-    12  oběh
-    12  rěšeno
-    12  znamenatelje
-    12  iscrpava
-    12  study
-    12  privęzane
-    12  obščejše
-    12  schmeidler
-    12  loewy
-    12  našem
-    12  nosep
-    12  psevdomatričnyh
-    11  angew
-    11  početku
-    11  izrično
-    11  děje
-    11  zahlentheorie
-    11  slućaju
-    11  dohodi
-    11  zovut
-    11  podrobno
-    11  doslovno
-    11  koju