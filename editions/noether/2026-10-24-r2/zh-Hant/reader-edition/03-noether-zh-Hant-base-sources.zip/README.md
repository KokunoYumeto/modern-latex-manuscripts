# 埃米·諾特數學著作集：繁體字版

收錄第1—43篇論文、M. Deuring記錄的1929/30年冬季學期講義、H. Kapferer論文及與E. Noether合作的補充、書目和相關著作目錄。這是由簡體中文文本轉換繁簡字形的繁體字版，保留原有詞彙；未作臺灣、香港或澳門的區域語言本地化。

[完整可編輯LaTeX正文](02-noether-zh-Hant.tex)包含本版全部正文，無須另行拼接篇章。`reader.tex`與其內容相同；`cover.tex`為正文中已內嵌的版本說明。訂正版另附相應編者注。PDF書籤可導覽至全部43篇編號論文及後續部分。

## 排版

使用XeLaTeX；須安裝Microsoft JhengHei、Microsoft JhengHei Bold、Noto Serif、Noto Sans、Noto Sans Mono字型，以及導言區列出的fontspec、xeCJK、AMS、TikZ、hyperref等TeX套件。字型檔不隨包分發。

解壓縮後於該目錄執行下列命令，重複至書籤與引用穩定：

```sh
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error 02-noether-zh-Hant.tex
```

中文底本由AI翻譯。早期製作方為Manuscript Typesetting Project / OpenAI Codex（準確模型未能確定）；本版由AI製作的訂正與排版：OpenAI Codex——GPT-6 Astra，Ultra推理強度；Claude Opus 5.5（Anthropic），2026-10-26至2026-10-27（公式已與依Noether印刷頁面讀出的德文本文核對）。

[作者、出處與權利](RIGHTS.md)

`python build.py`執行XeLaTeX兩次，採用與所附PDF相同的固定排版時刻設定；PDF內部排版日期不是出版日期。使用引擎為XeTeX3.141592653-2.6-0.999998（MiKTeX26.5）。直接下載的LaTeX與ZIP內`02-noether-zh-Hant.tex`為同一檔案。

## 字形轉換方法、程式與分項署名

R9中文彙編及繁體字轉換程式：OpenAI Codex——GPT-5.6 Sol，Ultra推理強度，2026-08-12。

字形轉換採用opencc-python-reimplemented 0.1.7的s2t設定及固定正字規則；繁體字形式與簡體文本屬於同一個中文譯本。

本版AI訂正與排版：OpenAI Codex——GPT-6 Astra，Ultra推理強度，2026-10-23至2026-10-24；Claude Opus 5.5（Anthropic），2026-10-26至2026-10-27（公式已與依Noether印刷頁面讀出的德文本文核對）。

最初逐段翻譯的準確模型、推理設定及工作日期尚未確定；2026-06-12是早期彙編的版本日期。


[字形轉換方法、程式與分項署名](https://github.com/KokunoYumeto/modern-latex-manuscripts/blob/main/editions/noether/methods/chinese-script-2026-10-24-r2/README.zh-Hant.md)
