# Autoría y derechos

Traducción producida por IA. Correcciones y composición producidas por OpenAI Codex — GPT-6 Astra, esfuerzo Ultra. Se conservan los autores indicados en las obras, incluidos Emmy Noether, M. Deuring y sus coautores. No se atribuye al editor una traducción ni una revisión humana independiente.

El modelo y el esfuerzo exactos de la traducción heredada no se han podido establecer a partir de los registros conservados. Correcciones y composición producidas por IA: 23–24 de octubre de 2026; Claude Opus 5.5 (Anthropic), 26–27 de octubre de 2026, incluidas las fórmulas cotejadas con el texto alemán leído en las páginas impresas de Noether. Edición: 27 de octubre de 2026.

Las obras de Emmy Noether son de dominio público. En la medida en que el editor tenga derechos sobre la traducción, las correcciones y la composición producidas por IA, los dedica al dominio público con [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/deed.es). Las lecciones redactadas por M. Deuring, el trabajo de H. Kapferer y las contribuciones de los coautores nombrados conservan su propia situación jurídica.

[Objeciones de los titulares](https://github.com/KokunoYumeto/modern-latex-manuscripts/issues/new).
