# Emmy Noether — Obras matemáticas en español

Artículos 1–43, las lecciones de 1929/30 redactadas por M. Deuring, el trabajo de Kapferer y Noether con su suplemento, bibliografía y listas finales.

El LaTeX acumulativo descargable contiene todos los textos y preámbulos como código editable. El programa Python extrae los archivos nativos, los compila con XeLaTeX y reúne los PDF de los componentes en orden de lectura. No usa imágenes ni páginas PDF como transcripción. El ZIP conserva la estructura nativa, el mismo LaTeX acumulativo y el programa. Se necesitan Python 3, pypdf y los paquetes y fuentes indicados en los preámbulos. Los bytes del PDF pueden variar según las versiones de TeX y de las fuentes. La fecha interna fija de composición no es la fecha de publicación.

```text
python -m pip install pypdf
python build.py 02-noether-es-base.tex --output 01-noether-es-base.pdf
```

Programa de composición creado por IA: OpenAI Codex — GPT-6 Astra, Ultra, 24 de octubre de 2026.

Traducción producida por IA. Correcciones y composición producidas por OpenAI Codex — GPT-6 Astra, esfuerzo Ultra. Se conservan los autores indicados en las obras, incluidos Emmy Noether, M. Deuring y sus coautores. No se atribuye al editor una traducción ni una revisión humana independiente.

La traducción heredada la hizo principalmente GPT-5.6 Sol (OpenAI Codex, esfuerzo de razonamiento ultra), según el usuario. Correcciones y composición producidas por IA: 23–24 de octubre de 2026; Claude Opus 5.5 (Anthropic, esfuerzo max), 26–27 de octubre de 2026, incluidas las fórmulas cotejadas con el texto alemán leído en las páginas impresas de Noether. Edición: 27 de octubre de 2026.
