# Autoría y derechos

Traducción producida por IA. Correcciones y composición producidas por OpenAI Codex — GPT-6 Astra, esfuerzo Ultra. Se conservan los autores indicados en las obras, incluidos Emmy Noether, M. Deuring y sus coautores. No se atribuye al editor una traducción ni una revisión humana independiente.

El modelo y el esfuerzo exactos de la traducción heredada no se han podido establecer a partir de los registros conservados. Correcciones y composición producidas por IA: 23–24 de octubre de 2026; Claude Opus 5.5 (Anthropic), 26 de octubre de 2026. Edición: 26 de octubre de 2026.

Los derechos pertenecen a sus respectivos titulares. La distribución gratuita con fines no comerciales y puramente educativos se basa en la presunción del editor de que los titulares no se opondrían, no en un permiso establecido. El acceso libre no autoriza la publicación derivada. Los titulares pueden presentar una objeción mediante el enlace siguiente; el editor retirará el material afectado a petición. No se concede una nueva licencia ni una cesión al dominio público.

[Objeciones de los titulares](https://github.com/KokunoYumeto/modern-latex-manuscripts/issues/new).
