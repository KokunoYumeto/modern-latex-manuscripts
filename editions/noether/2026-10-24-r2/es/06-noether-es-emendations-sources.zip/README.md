# Emmy Noether — Obras matemáticas en español

Artículos 1–43, las lecciones de 1929/30 redactadas por M. Deuring, el trabajo de Kapferer y Noether con su suplemento, bibliografía y listas finales.

El LaTeX acumulativo descargable contiene todos los textos y preámbulos como código editable. El programa Python extrae los archivos nativos, los compila con XeLaTeX y reúne los PDF de los componentes en orden de lectura. No usa imágenes ni páginas PDF como transcripción. El ZIP conserva la estructura nativa, el mismo LaTeX acumulativo y el programa. Se necesitan Python 3, pypdf y los paquetes y fuentes indicados en los preámbulos. Los bytes del PDF pueden variar según las versiones de TeX y de las fuentes. La fecha interna fija de composición no es la fecha de publicación.

```text
python -m pip install pypdf
python build.py 05-noether-es-emendations.tex --output 04-noether-es-emendations.pdf
```

Programa de composición creado por IA: OpenAI Codex — GPT-6 Astra, Ultra, 24 de octubre de 2026.

Traducción producida por IA. Correcciones y composición producidas por OpenAI Codex — GPT-6 Astra, esfuerzo Ultra. Se conservan los autores indicados en las obras, incluidos Emmy Noether, M. Deuring y sus coautores. No se atribuye al editor una traducción ni una revisión humana independiente.

El modelo y el esfuerzo exactos de la traducción heredada no se han podido establecer a partir de los registros conservados. Correcciones y composición producidas por IA: 23–24 de octubre de 2026. Edición: 24 de octubre de 2026.
