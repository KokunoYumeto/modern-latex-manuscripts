# Emmy Noether — Các văn bản toán học bằng tiếng Việt

Nguồn hiện có gồm bản dịch ba trang của bài số 1. Đây không phải bản dịch đầy đủ toàn bộ tác phẩm.

Giữ nguyên cấu trúc thư mục khi giải nén. Chạy XeLaTeX hai lần cho mỗi tệp chính từ thư mục chứa tệp; các gói và phông chữ được ghi trong phần khai báo.

- `p01.tex`

[Tác giả và quyền](RIGHTS.md).
