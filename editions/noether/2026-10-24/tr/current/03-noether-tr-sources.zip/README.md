# Emmy Noether — Türkçe matematik metinleri

Mevcut kaynak 36 numaralı makaledir. Bu, bütün eserlerin tam çevirisi değildir.

Arşiv dizin yapısını koruyun. Ana dosyayı bulunduğu dizinde XeLaTeX ile iki kez derleyin; gerekli paket ve yazı tipleri önsözde belirtilmiştir.

- `p36_tr.tex`

[Yazarlık ve haklar](RIGHTS.md).
