# Emmy Noether — Obras matemáticas en español

Artículos 1–43, las lecciones de 1929/30 redactadas por M. Deuring, el trabajo de Kapferer y Noether con su suplemento, bibliografía y listas finales.

Compilar dos veces cada archivo principal con XeLaTeX desde su propio directorio, conservando la estructura del archivo. Los preámbulos indican los paquetes y las fuentes tipográficas necesarios.

- `noether.tex`

[Autoría y derechos](RIGHTS.md).
