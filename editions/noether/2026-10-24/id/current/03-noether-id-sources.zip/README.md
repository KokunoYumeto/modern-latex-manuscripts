# Emmy Noether — Sampel awal terjemahan bahasa Indonesia

Sumber yang tersedia mencakup makalah 36 dan bagian awal makalah 6. Ini bukan terjemahan lengkap seluruh karya.

Pertahankan struktur folder arsip. Jalankan XeLaTeX dua kali untuk setiap berkas utama dari foldernya. Paket dan font yang diperlukan tercantum pada preambule.

- `paper36/tranche_001_id_20260717/id/Noether_Paper36_Indonesian_SourceReconciled_v001.tex`
- `p06/id_t01_20260804/p06_id_t01.tex`

[Kepengarangan dan hak](RIGHTS.md).
