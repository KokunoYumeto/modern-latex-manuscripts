# SGA5 Find-Verify-Fix Workpass Method Snapshot

Created: 2026-06-25 by ChatGPT Codex 5.5 Extra High Effort Mode.

This is a compact workflow/methodology packet distilled from the live SGA5 source-audit workpass. It is intended for the workflow/replication DOI, not as a promoted SGA5 reader or critical edition.

## What This Preserves

- `scripts/sga5_audit_workflow.js`: the later find -> verify -> fix driver used after large swarm runs became rate-limit-bound.
- `scripts/patch_apply.py`: deterministic old-string/new-string patch gate; refuses missing or non-unique matches.
- `scripts/chunk_page.py` and `scripts/render_src.py`: source-render helpers for page chunks.
- `scripts/build_index.py`, `scripts/split_findings.py`, `scripts/consolidate.py`: index and log/consolidation helpers.
- `status_and_lessons/SWARM_SESSION_STATUS_20260624.md`: long-form session status and method evolution notes.
- `status_and_lessons/FINDINGS_consolidated_20260624.md`: consolidated correction ledger used as the verify-against base.
- `status_and_lessons/STATUS.md` and `SOURCE_AND_RESOLUTION.md`: source-quality and project-state notes.
- `status_and_lessons/sga5_index.csv/json`: machine-readable element index from the workpass snapshot.

## Workflow Lessons

- Raw parallel swarms were useful for discovery, but became server-rate-limit-bound and produced wasted agent runs when too many workflows ran concurrently.
- The safer pattern is one large workflow at a time: page-local discovery, independent verification, deterministic patch application, then a compile gate.
- OCR and source crops are witness/localization layers only. Source-page images and the compiled TeX diff remain the actual audit controls.
- A workpass can overtake packaged support ZIPs within hours; public records should describe these packets as snapshots unless a stable milestone is repackaged.
- Public archive labels must distinguish method/support, source-witnessed working drafts, source-audit candidates, and certified/critical editions.

## Explicit Caveat

This packet does not certify SGA5. The associated workpass was still a live source-audit branch: SGA5 remained incomplete/errorful, English synchronization was open, and remaining page ranges still required source comparison.


## 2026-06-25 refresh

CERT_LOG.md now records pp.1-58 page-locally certified, covering Expose I main text, Bibliographie, and Illusie Appendix §1, with p59 next. Agents/workflows remain finder layers, not certifiers. This package remains workflow/method evidence, not a promoted SGA5 reader or critical edition.

