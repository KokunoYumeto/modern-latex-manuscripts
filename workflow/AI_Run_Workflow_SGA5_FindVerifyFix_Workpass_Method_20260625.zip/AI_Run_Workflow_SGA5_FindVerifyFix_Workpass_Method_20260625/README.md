# SGA5 find-verify-fix workpass method snapshot

This is a compact workflow/methodology packet, not an SGA5 reader replacement and not SGA5 certification.

The controlling lesson is that OCR, agents, and workflow passes are useful finders, not certifiers. The current live manual certification log records SGA5 Expose I pp.1-72 page-locally certified through the end of Expose I; p73 starts Expose III in the curated local TeX. The broader workpass still reports wide repair coverage, but it remains repair evidence until independently packaged, validated, and synchronized.

Public quality claims should therefore say:

- SGA5 remains incomplete/errorful globally.
- The local TeX is a curated 10-expose selection, not the full 484-page source scan.
- Expose I pp.1-72 are the current page-local certification evidence.
- D001-D013 in Expose I are hand-verified perfect.
- English synchronization remains open.
- The cross-document exceptional-inverse notation choice `R^! f` vs `R f^!` remains an explicit normalization item.

Included material is intentionally small: logs, scorecards, source-resolution notes, indexes, and workflow scripts. Bulky source crops, rendered pages, and the full workpass TeX/PDF are excluded.
