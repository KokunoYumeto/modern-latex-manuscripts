"""Build a machine-readable index of the SGA5 workpass TeX:
every statement (thm/prop/def/lemma/cor/remark), every numbered formula (\tag),
every diagram (tikzcd/tikzpicture), and every section heading.
Output: sga5_index.csv (one row per element) + sga5_index.json (grouped) + a console summary.
Rerun any time the workpass changes; it reflects the current file.
"""
import csv, json, os, re

TEX = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623\sga5_fr_workpass.tex"
OUT = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623"

lines = open(TEX, encoding="utf-8").read().splitlines()

# exposé TeX-line ranges + printed-page ranges (from the book's Table des Matières)
# (tex_start, tex_end, expose, printed_start, printed_end)
EXPOSES = [
    (313, 1855, "I", 1, 72),
    (1856, 4160, "III", 73, 137),
    (4161, 6641, "IIIB", 138, 203),
    (6642, 8184, "V", 204, 250),
    (8185, 9044, "VI", 251, 281),
    (9045, 11543, "VII", 282, 350),
    (11544, 12195, "VIII", 351, 371),
    (12196, 13208, "X", 372, 406),
    (13209, 14201, "XII", 407, 441),
    (14202, 15266, "XV", 442, 480),
]

def expose_and_page(ln):
    for ts, te, name, ps, pe in EXPOSES:
        if ts <= ln <= te:
            frac = (ln - ts) / max(1, (te - ts))
            est = round(ps + frac * (pe - ps))
            return name, est
    return "?", ""

def clean(s):
    s = re.sub(r"\\(text|emph|normalfont|mathrm|operatorname)\b", "", s)
    s = s.replace("{", "").replace("}", "").replace("\\", "")
    return re.sub(r"\s+", " ", s).strip()

STMT_KIND = re.compile(r"(Th[ée]or[èe]me|Proposition|D[ée]finition|Lemme|Corollaire|Remarque[s]?|Scholie|Th\b|Cor\b|Prop\b|D[ée]f\b|Exemple[s]?|Notation[s]?|Sommaire|Introduction)", re.I)

rows = []
diagram_no = 0
for i, ln in enumerate(lines, 1):
    exp, pg = expose_and_page(i)
    # section headings
    m = re.search(r"\\(section\*?|chapter\*?|part\*?)\{(.+?)\}", ln)
    if m:
        rows.append({"kind": "section", "ref": "", "title": clean(m.group(2))[:90],
                     "expose": exp, "tex_line": i, "src_page_est": pg})
        continue
    # statements as subsection* headings  e.g. \subsection*{Proposition 1.3 ...}
    m = re.search(r"\\subsection\*?\{(.+?)\}", ln)
    if m:
        t = m.group(1)
        km = STMT_KIND.search(t)
        nm = re.search(r"(\d+(?:\.\d+)*)", t)
        rows.append({"kind": "statement", "ref": (nm.group(1) if nm else ""),
                     "title": clean(t)[:90], "expose": exp, "tex_line": i, "src_page_est": pg})
        continue
    # statements as environment  \begin{statement}{Théorème 4.4}
    m = re.search(r"\\begin\{statement\}\{(.+?)\}", ln)
    if m:
        t = m.group(1)
        nm = re.search(r"(\d+(?:\.\d+)*)", t)
        rows.append({"kind": "statement", "ref": (nm.group(1) if nm else ""),
                     "title": clean(t)[:90], "expose": exp, "tex_line": i, "src_page_est": pg})
        continue
    # numbered formulas
    for tm in re.finditer(r"\\tag\{([^}]*)\}", ln):
        rows.append({"kind": "equation", "ref": clean(tm.group(1))[:24], "title": "",
                     "expose": exp, "tex_line": i, "src_page_est": pg})
    # diagrams
    if re.search(r"\\begin\{tikzcd\}", ln):
        diagram_no += 1
        # nearest tag within +/- 3 lines
        ctx = "\n".join(lines[max(0, i-4):i+2])
        tg = re.search(r"\\tag\{([^}]*)\}", ctx)
        rows.append({"kind": "diagram", "ref": f"D{diagram_no:03d}",
                     "title": ("tag " + clean(tg.group(1)) if tg else "tikzcd"),
                     "expose": exp, "tex_line": i, "src_page_est": pg})
    elif re.search(r"\\begin\{tikzpicture\}", ln):
        diagram_no += 1
        rows.append({"kind": "diagram", "ref": f"D{diagram_no:03d}", "title": "tikzpicture",
                     "expose": exp, "tex_line": i, "src_page_est": pg})

rows.sort(key=lambda r: r["tex_line"])

cp = os.path.join(OUT, "sga5_index.csv")
with open(cp, "w", newline="", encoding="utf-8") as f:
    w = csv.DictWriter(f, fieldnames=["kind", "ref", "title", "expose", "tex_line", "src_page_est"])
    w.writeheader()
    w.writerows(rows)

grouped = {}
for r in rows:
    grouped.setdefault(r["expose"], {"sections": [], "statements": [], "equations": [], "diagrams": []})
    key = {"section": "sections", "statement": "statements", "equation": "equations", "diagram": "diagrams"}[r["kind"]]
    grouped[r["expose"]][key].append(r)
jp = os.path.join(OUT, "sga5_index.json")
json.dump({"source_tex": "sga5_fr_workpass.tex", "by_expose": grouped}, open(jp, "w", encoding="utf-8"), ensure_ascii=False, indent=1)

from collections import Counter
kc = Counter(r["kind"] for r in rows)
print("INDEX BUILT:", cp)
print("totals:", dict(kc), " grand total rows:", len(rows))
print("per exposé (statements / equations / diagrams):")
for ts, te, name, ps, pe in EXPOSES:
    g = grouped.get(name, {})
    print("  %-5s pp.%3d-%3d : %3d stmts, %3d eqns, %3d diagrams" % (
        name, ps, pe, len(g.get("statements", [])), len(g.get("equations", [])), len(g.get("diagrams", []))))
