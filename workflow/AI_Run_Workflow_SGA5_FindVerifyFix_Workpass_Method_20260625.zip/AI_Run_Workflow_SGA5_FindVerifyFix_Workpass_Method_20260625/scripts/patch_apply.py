"""Deterministic patch applier for the SGA5 workpass.
Reads a JSON list of {page, kind, old_string, new_string} and applies each as a
UNIQUE exact replacement in sga5_fr_workpass.tex. Dry-run by default; --commit writes
(with a .bak backup). A patch whose old_string is missing or non-unique is reported,
never guessed."""
import json, sys, shutil, io

TEX = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623\sga5_fr_workpass.tex"

def main():
    if len(sys.argv) < 2:
        print("usage: patch_apply.py <patches.json> [--commit]"); return
    patches_path = sys.argv[1]
    commit = "--commit" in sys.argv
    with io.open(patches_path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, dict):
        res = data.get("result", data)
        patches = res.get("allPatches") or data.get("allPatches") or []
    else:
        patches = data
    with io.open(TEX, encoding="utf-8") as f:
        text = f.read()
    work = text
    applied = notfound = ambig = skipped = 0
    rows = []
    for p in patches:
        old = p.get("old_string"); new = p.get("new_string")
        page = p.get("page"); kind = p.get("kind", "")
        if not old or new is None:
            skipped += 1; rows.append(("SKIP(no strings)", page, kind, "")); continue
        if old == new:
            skipped += 1; rows.append(("SKIP(no-op)", page, kind, "")); continue
        c = work.count(old)
        if c == 1:
            work = work.replace(old, new, 1); applied += 1
            rows.append(("OK", page, kind, old[:48].replace("\n", " ")))
        elif c == 0:
            notfound += 1; rows.append(("NOTFOUND", page, kind, old[:48].replace("\n", " ")))
        else:
            ambig += 1; rows.append(("AMBIGx%d" % c, page, kind, old[:48].replace("\n", " ")))
    for r in rows:
        print("%-15s p%-4s %-16s | %s" % (r[0], r[1], r[2], r[3]))
    print("\nSUMMARY: applied=%d notfound=%d ambiguous=%d skipped=%d of %d"
          % (applied, notfound, ambig, skipped, len(patches)))
    if commit and applied > 0:
        shutil.copy(TEX, TEX + ".bak")
        with io.open(TEX, "w", encoding="utf-8") as f:
            f.write(work)
        print("COMMITTED %d patches. Backup at %s.bak" % (applied, TEX))
    else:
        print("DRY RUN - no file written. Add --commit to apply.")

main()
