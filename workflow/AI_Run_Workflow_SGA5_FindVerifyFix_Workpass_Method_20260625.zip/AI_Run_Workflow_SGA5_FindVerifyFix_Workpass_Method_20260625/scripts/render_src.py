"""Render SGA5 source scan pages (and optional zoom crop) for the audit.
Usage:
  python render_src.py P [P ...]                 -> full page, 150 dpi
  python render_src.py P --dpi 400 --y0 0.04 --y1 0.30   -> band crop of one page
Source: scan, printed page number == pdf page index (verified).
"""
import sys, os
import fitz
from PIL import Image

SCAN = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\sga5_sga6_repair022_20260612\1\SGA5\cumulative\scans\sga5_src.pdf"
OUT = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623\_work\src"
os.makedirs(OUT, exist_ok=True)

args = sys.argv[1:]
pages, dpi = [], 150
y0 = y1 = None
i = 0
while i < len(args):
    a = args[i]
    if a == "--dpi": dpi = int(args[i+1]); i += 2
    elif a == "--y0": y0 = float(args[i+1]); i += 2
    elif a == "--y1": y1 = float(args[i+1]); i += 2
    else: pages.append(int(a)); i += 1

d = fitz.open(SCAN)
for p in pages:
    pg = d[p-1]
    if y0 is not None:
        r = pg.rect
        clip = fitz.Rect(r.x0, r.y0 + r.height*y0, r.x1, r.y0 + r.height*(y1 if y1 else 1.0))
        pm = pg.get_pixmap(dpi=dpi, colorspace=fitz.csGRAY, clip=clip)
        fp = os.path.join(OUT, f"p{p:03d}_crop.png")
    else:
        pm = pg.get_pixmap(dpi=dpi, colorspace=fitz.csGRAY)
        fp = os.path.join(OUT, f"p{p:03d}.png")
    pm.save(fp)
    im = Image.open(fp)
    cap = 1900 if y0 is None else 2500
    if im.width > cap:
        im = im.resize((cap, int(im.height*cap/im.width)), Image.LANCZOS)
        im.save(fp, optimize=True)
    print(fp, im.size)
