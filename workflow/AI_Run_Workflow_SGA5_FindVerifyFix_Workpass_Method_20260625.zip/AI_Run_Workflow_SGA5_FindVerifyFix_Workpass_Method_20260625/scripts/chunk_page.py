"""Render a PRINTED SGA5 page as overlapping high-dpi chunks for the audit.
Source = the complete Springer book; printed page = PDF page - 12 (PDF p13 == printed p1).
Usage:
  python chunk_page.py PRINTED [PRINTED ...]            # 3 chunks each (top/mid/bot)
  python chunk_page.py PRINTED --chunks N               # N chunks
  python chunk_page.py PRINTED --full                   # whole page, one image
Renders at 600 dpi then downsamples each chunk to <=2400px wide (legible, all native detail kept;
native scan is 2176px so this is near-native enlargement, the "zoom" with no real detail lost).
"""
import sys, os
import fitz
from PIL import Image

PDF = r"C:\Users\Floris\Documents\Papors\OS\SGA5 (1).pdf"
OFFSET = 12   # pdf_index = printed + OFFSET
OUT = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623\_work\src"
os.makedirs(OUT, exist_ok=True)

args = sys.argv[1:]
pages, nchunks, full = [], 3, False
i = 0
while i < len(args):
    a = args[i]
    if a == "--chunks": nchunks = int(args[i+1]); i += 2
    elif a == "--full": full = True; i += 1
    else: pages.append(int(a)); i += 1

d = fitz.open(PDF)
for printed in pages:
    pidx = printed + OFFSET - 1   # 0-based
    if pidx < 0 or pidx >= d.page_count:
        print(f"printed {printed}: out of range"); continue
    pg = d[pidx]
    pm = pg.get_pixmap(dpi=600, colorspace=fitz.csGRAY)
    full_im = Image.frombytes("L", (pm.width, pm.height), pm.samples)
    W, H = full_im.size
    if full:
        im = full_im
        if im.width > 2400: im = im.resize((2400, int(im.height*2400/im.width)), Image.LANCZOS)
        fp = os.path.join(OUT, f"p{printed:03d}_full.png")
        im.save(fp, optimize=True)
        print(fp, im.size); continue
    ov = int(H * 0.04)  # overlap so nothing falls on a seam
    band = H // nchunks
    names = ["top", "mid", "bot"] if nchunks == 3 else [f"c{k+1}" for k in range(nchunks)]
    for k in range(nchunks):
        y0 = max(0, k*band - ov)
        y1 = min(H, (k+1)*band + ov)
        ch = full_im.crop((0, y0, W, y1))
        if ch.width > 2400: ch = ch.resize((2400, int(ch.height*2400/ch.width)), Image.LANCZOS)
        fp = os.path.join(OUT, f"p{printed:03d}_{names[k] if k < len(names) else 'c'+str(k+1)}.png")
        ch.save(fp, optimize=True)
        print(fp, ch.size)
