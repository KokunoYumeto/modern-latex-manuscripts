// SGA5 source-fidelity audit — EFFICIENT verify-gated workflow.
// Usage:  Workflow({ scriptPath: "...\\_work\\sga5_audit_workflow.js", args: [102,103,...,151] })
//   args = array of PRINTED page numbers to audit (chunks must already exist in _work/src/).
// Returns { pagesAudited, cleanPages, accepted[], rejected[], typeB[], cosmetic[] }.
//   - accepted[] = fixes that PASSED adversarial verification → I write them to a patches JSON
//     and apply with patch_apply.py --commit + pdflatex (MY foreground, one shell call; no GPU).
// Design notes (why this is efficient AND safe):
//   * Agents only READ pre-rendered PNG scan chunks + Grep/Read the .tex → zero GPU, zero model-load
//     (respects the GPU-only no-background rule). Chunks p1-484 already rendered in _work/src/.
//   * pipeline(): each page flows audit -> verify independently, no barrier (max wall-clock overlap).
//   * Every candidate fix is independently re-checked by a SECOND agent that DEFAULTS TO REJECT,
//     so over-eager "fixes" are filtered before anything touches the file.
//   * Run ONE workflow at a time (rate-limit lesson). ~50 pages/run is a safe batch.

export const meta = {
  name: 'sga5-audit-batch',
  description: 'Audit a batch of SGA5 printed pages against the .tex (source-faithful), adversarially verify each candidate fix, return applied-ready patches',
  phases: [
    { title: 'Audit',  detail: 'one agent/page: read scan chunks, locate region in .tex, emit candidate fixes + typeB + cosmetic' },
    { title: 'Verify', detail: 'one agent/fix: adversarial re-check vs source, default REJECT' },
  ],
}

const BASE = String.raw`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623`
const SRC  = BASE + String.raw`\_work\src`
const TEX  = BASE + String.raw`\sga5_fr_workpass.tex`

// args may arrive as a JS array, a {pages:[...]} object, a number, or a JSON/comma string — coerce all.
function parsePages(a) {
  if (Array.isArray(a)) return a.map(Number).filter(Number.isFinite)
  if (a && typeof a === 'object' && Array.isArray(a.pages)) return a.pages.map(Number).filter(Number.isFinite)
  if (typeof a === 'number') return [a]
  if (typeof a === 'string') {
    const s = a.trim()
    try { const j = JSON.parse(s); if (Array.isArray(j)) return j.map(Number).filter(Number.isFinite) } catch (e) {}
    return s.split(/[^0-9]+/).map(Number).filter(Number.isFinite)
  }
  return []
}
const pages = parsePages(args)
const pad = n => String(n).padStart(3, '0')

const FIX_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    page: { type: 'integer' },
    clean: { type: 'boolean' },
    region_note: { type: 'string', description: 'what .tex lines / content this page maps to' },
    fixes: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      properties: {
        kind: { type: 'string' },
        old_string: { type: 'string' },
        new_string: { type: 'string' },
        evidence: { type: 'string' },
        confidence: { type: 'number' },
      },
      required: ['kind','old_string','new_string','evidence','confidence'],
    } },
    typeB: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      properties: { kind: { type: 'string' }, evidence: { type: 'string' } },
      required: ['evidence'],
    } },
    cosmetic: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      properties: { evidence: { type: 'string' } },
      required: ['evidence'],
    } },
  },
  required: ['page','clean','fixes','typeB','cosmetic'],
}

const VERDICT_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: { accept: { type: 'boolean' }, reason: { type: 'string' } },
  required: ['accept','reason'],
}

const auditPrompt = (n) => `You are a meticulous LaTeX/mathematics proof-checker auditing ONE printed page of SGA 5 (Lecture Notes in Math 589) against its LaTeX transcription, for SOURCE FIDELITY. A mathematician must be able to TRUST the transcription.

=== SOURCE (authoritative ground truth) ===
Read these three high-resolution scan chunks (top/middle/bottom of printed page ${n}):
  ${SRC}\\p${pad(n)}_top.png
  ${SRC}\\p${pad(n)}_mid.png
  ${SRC}\\p${pad(n)}_bot.png

=== TRANSCRIPTION ===
File: ${TEX}
Printed page numbers are NOT in the .tex. Locate this page's region: pick a distinctive phrase or formula you can read in the TOP chunk, Grep for it in the .tex, then Read ~50 lines around the match so you have the page's whole region.

=== TASK: compare scan vs .tex ELEMENT BY ELEMENT, in reading order ===
- prose: every word (dropped / added / wrong words)
- equations & formulas: every symbol
- symbols especially: subscripts/superscripts, bars (x̄ vs x), primes, lower-shriek f_! vs star f^* vs upper-shriek f^!, ⊗ vs ⊗^L (derived), Hom vs underlined RHom vs Hom_S
- diagrams: every node, every arrow direction, every arrow label
- numbering: theorem/prop/section/equation numbers; cross-references (e.g. "3.2.1", "SGA 4 XVIII 3.1.9.6")

Classify each difference:
  • type A (EMIT AS FIX): the .tex DEVIATES from the source in a way that changes mathematical/textual meaning — wrong symbol, dropped/added formula or word, wrong subscript/bar/prime, wrong arrow direction, wrong cross-ref number, wrong heading level.
  • type B (FLAG, DO NOT FIX): the SOURCE itself has an error/typo/inconsistency that the .tex faithfully reproduces. Report; don't change.
  • cosmetic (NOTE, DO NOT FIX): difference that does NOT change meaning — parentheses vs commas, ↦ vs ⤳, --→ vs →, citation "3.2.a" vs "3.2 a", an added/dropped article, an inserted "et" in a list, or a defensible spelling/accent normalization already in the .tex (Quand, exacte, accents on capitals, \\et, X_{\\et}). DO NOT emit these as fixes.

*** CRITICAL — do NOT propose reverting the editor's IMPROVEMENTS. *** type-A is ONLY for cases where the .tex is WORSE than the source. If the .tex differs because it CORRECTED an obvious source error (a missing subscript that symmetry/context demands, e.g. source "Rf_*A" but math needs "Rf_{2*}A"; a stray prime; a dropped shriek/bar the math requires) OR applied a UNIFORM standardization (consistently writing the base on the derived tensor, e.g. ⊗_X / ⊗_Y; accents on capitals; \\et), that is the INTENDED scholarly reading — classify it type-B ("source has X (error); .tex correctly reads Y") and DO NOT emit a type-A fix. LITMUS: would applying your fix make the math/text WRONG, or make the .tex match a source typo, or undo a reading that is consistent elsewhere in the .tex? If yes → it is NOT type-A. type-A is for the .tex MIS-reading the source (source "s", .tex "S"; source no-bar, .tex bar; dropped word; wrong arrow direction).

For each type-A fix:
  - kind: short tag ("symbol","prose","equation","diagram","label","xref")
  - old_string: an EXACT, VERBATIM, UNIQUE substring copied from the .tex (include backslashes/braces exactly; long enough to occur exactly once in the whole file)
  - new_string: the corrected string matching the source
  - evidence: "source shows X; .tex has Y" — specific
  - confidence: 0.0-1.0 (only emit fixes with confidence ≥ 0.6)

BE CONSERVATIVE. When unsure whether something is a real deviation vs a defensible standardization or cosmetic, classify it cosmetic/typeB, NOT a fix. Do NOT invent fixes to look productive — a CLEAN page is the expected, common result (the front region of this book is well-transcribed).

Return the structured object only: {page:${n}, clean (true iff zero type-A fixes), region_note, fixes:[...], typeB:[...], cosmetic:[...]}.`

const verifyPrompt = (n, fix) => `Adversarially verify ONE proposed correction to the SGA 5 LaTeX transcription. Your DEFAULT is to REJECT; accept only if clearly warranted.

Printed page ${n}. Source ground-truth scan chunks:
  ${SRC}\\p${pad(n)}_top.png
  ${SRC}\\p${pad(n)}_mid.png
  ${SRC}\\p${pad(n)}_bot.png
Transcription file: ${TEX}

Proposed type-A fix:
  old_string (current .tex): ${JSON.stringify(fix.old_string)}
  new_string (proposed):     ${JSON.stringify(fix.new_string)}
  claimed reason:            ${fix.evidence}

Run ALL of these checks:
  1. UNIQUENESS: Grep old_string in the .tex. It must occur EXACTLY ONCE. If 0 or >1 → REJECT.
  2. SOURCE SUPPORT: Read the relevant scan chunk(s). The source must actually show the new_string reading and NOT the old_string reading. If the source matches the CURRENT old_string, or is ambiguous/illegible → REJECT.
  3. NOT COSMETIC / NOT A STANDARDIZATION: if the change is merely cosmetic (parens/commas/arrows/citation format/article) or would undo a defensible edition standardization → REJECT.
  4. MEANING: it must correct a genuine mathematical or textual error.
  5. DIRECTION (most common false-accept): the fix must make the .tex MATCH a clear source reading the .tex got WRONG. REJECT if new_string would instead make the .tex match a source TYPO/error, revert the editor's correction of an obvious source mistake (missing subscript, stray prime, dropped shriek), or undo a UNIFORM standardization present elsewhere in the .tex (e.g. base subscript on ⊗_X/⊗_Y). When the source itself looks wrong and the .tex looks right, REJECT (that is type-B, not a fix).

Accept ONLY if 1-5 ALL pass. Return {accept: bool, reason: "<one sentence: which check decided it>"}.`

// ---- run: audit each page, then verify each candidate fix from that page ----
const results = await pipeline(
  pages,
  (n) => agent(auditPrompt(n), { label: `audit:p${n}`, phase: 'Audit', schema: FIX_SCHEMA }),
  (audit, n) => {
    if (!audit) return { page: n, audit: null, verified: [] }
    const fixes = audit.fixes || []
    if (!fixes.length) return { page: n, audit, verified: [] }
    return parallel(fixes.map(fx => () =>
      agent(verifyPrompt(n, fx), { label: `verify:p${n}`, phase: 'Verify', schema: VERDICT_SCHEMA })
        .then(v => ({ ...fx, page: n, accept: !!(v && v.accept), verifyReason: v ? v.reason : 'verifier died' }))
    )).then(vs => ({ page: n, audit, verified: vs.filter(Boolean) }))
  }
)

const flat = results.filter(Boolean)
const accepted = [], rejected = [], typeB = [], cosmetic = []
for (const r of flat) {
  const a = r.audit || {}
  for (const t of (a.typeB || []))    typeB.push({ page: r.page, ...t })
  for (const c of (a.cosmetic || [])) cosmetic.push({ page: r.page, ...c })
  for (const f of (r.verified || [])) {
    if (f.accept) accepted.push({ page: f.page, kind: f.kind, old_string: f.old_string, new_string: f.new_string, evidence: f.evidence, confidence: f.confidence })
    else rejected.push({ page: f.page, kind: f.kind, reason: f.verifyReason, evidence: f.evidence })
  }
}
log(`SGA5 audit: ${flat.length} pages | ${accepted.length} fixes ACCEPTED, ${rejected.length} rejected | ${typeB.length} typeB | ${cosmetic.length} cosmetic`)

return {
  pagesAudited: flat.length,
  cleanPages: flat.filter(r => r.audit && r.audit.clean).map(r => r.page).sort((a,b)=>a-b),
  accepted, rejected, typeB, cosmetic,
}
