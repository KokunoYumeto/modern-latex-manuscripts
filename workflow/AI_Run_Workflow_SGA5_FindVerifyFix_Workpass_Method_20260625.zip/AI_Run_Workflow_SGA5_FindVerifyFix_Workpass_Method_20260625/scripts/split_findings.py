"""Split the four swarm result files into one small flag file per printed page,
so each verify+patch agent can read just its own page's findings."""
import json, os, collections, io

BASE = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623\_work\swarm_results"
FILES = ["swarm_p075-124.json", "swarm_p125-174.json", "swarm_p175-224.json", "swarm_p225-274.json"]
OUT = os.path.join(BASE, "by_page")
os.makedirs(OUT, exist_ok=True)

bypage = collections.defaultdict(list)
for fn in FILES:
    with io.open(os.path.join(BASE, fn), encoding="utf-8") as fh:
        data = json.load(fh)
    res = data.get("result", data)
    for d in res.get("allDiscrepancies", []):
        bypage[d["page"]].append(d)

for page, ds in sorted(bypage.items()):
    with io.open(os.path.join(OUT, "p%03d.json" % page), "w", encoding="utf-8") as fh:
        json.dump(ds, fh, ensure_ascii=False, indent=1)

print("wrote %d per-page flag files to %s" % (len(bypage), OUT))
print("flagged pages:", sorted(bypage.keys()))
typeA = sum(1 for ds in bypage.values() for d in ds if d.get("type") == "A")
typeB = sum(1 for ds in bypage.values() for d in ds if d.get("type") == "B")
print("type A:", typeA, " type B:", typeB)
