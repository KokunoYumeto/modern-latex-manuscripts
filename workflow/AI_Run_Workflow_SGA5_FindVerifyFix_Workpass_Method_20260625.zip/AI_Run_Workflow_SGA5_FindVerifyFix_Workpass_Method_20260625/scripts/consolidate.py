"""Consolidate everything the swarm agents did into one clean per-page changelog,
so the careful page-by-page grind has a single source of truth for what was already fixed."""
import json, os, io, collections

BASE = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga5_full_audit_20260623"
SR = os.path.join(BASE, "_work", "swarm_results")
OUT = os.path.join(BASE, "FINDINGS_consolidated_20260624.md")

def load(path):
    try:
        with io.open(path, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        return None
    return d

def patches_of(d):
    if d is None: return []
    if isinstance(d, list): return d
    res = d.get("result", d)
    return res.get("allPatches") or d.get("allPatches") or []

# Applied patch sets (label, path) — these are exactly what was committed to workpass.tex
APPLIED = [
    ("POC", os.path.join(BASE, "_work", "poc_patches.json")),
    ("verify+patch p75-274", os.path.join(SR, "patches_vp_075-274.json")),
    ("fvp p275-374", os.path.join(SR, "patches_fvp_275-374.json")),
    ("fvp p375-484", os.path.join(SR, "patches_fvp_375-484.json")),
    ("re-run", os.path.join(SR, "patches_rerun.json")),
    ("heavy-QA p75-124", os.path.join(SR, "patches_heavyqa_075-124.json")),
]

bypage = collections.defaultdict(list)
total = 0
for label, path in APPLIED:
    for p in patches_of(load(path)):
        pg = p.get("page", 0)
        bypage[pg].append((label, p))
        total += 1

# Type-B (source errors flagged, NOT auto-fixed) + uncertain, gathered from all result files
typeB, uncertain = [], []
for fn in ["swarm_p075-124.json","swarm_p125-174.json","swarm_p175-224.json","swarm_p225-274.json",
           "patches_vp_075-274.json","patches_fvp_275-374.json","patches_fvp_375-484.json",
           "patches_rerun.json","patches_heavyqa_075-124.json"]:
    d = load(os.path.join(SR, fn))
    if d is None: continue
    res = d.get("result", d)
    for n in (res.get("typeBNotes") or []):
        typeB.append((n.get("page"), n.get("note","")))
    for n in (res.get("uncertainNotes") or []):
        uncertain.append((n.get("page"), n.get("note","")))
    for dd in (res.get("allDiscrepancies") or []):
        if dd.get("type") == "B":
            typeB.append((dd.get("page"), dd.get("reason", dd.get("loc",""))))
        elif dd.get("type") == "unresolvable":
            uncertain.append((dd.get("page"), dd.get("reason", dd.get("loc",""))))

def clip(s, n=160):
    s = (s or "").replace("\n", " ")
    return s if len(s) <= n else s[:n] + "..."

lines = []
lines.append("# SGA5 — consolidated changelog of swarm fixes (as of 2026-06-24)")
lines.append("")
lines.append(f"**{total} corrections applied** across {len(bypage)} pages (all committed to sga5_fr_workpass.tex; compiles, 307 pp).")
lines.append("")
lines.append("## Applied fixes, by printed page")
for pg in sorted(bypage):
    lines.append(f"\n### p{pg}")
    for label, p in bypage[pg]:
        kind = p.get("kind", "")
        ev = clip(p.get("evidence", ""))
        old = clip(p.get("old_string", ""), 90)
        new = clip(p.get("new_string", ""), 90)
        lines.append(f"- [{label}] **{kind}** (conf={p.get('confidence','?')})")
        lines.append(f"    - `{old}`  →  `{new}`")
        if ev: lines.append(f"    - _why:_ {ev}")

lines.append("\n## Source errors flagged (TYPE B — kept correct reading, NOT a transcription fix)")
for pg, note in sorted([t for t in typeB if t[0] is not None]):
    lines.append(f"- p{pg}: {clip(note)}")

lines.append("\n## Uncertain / needs human eye")
for pg, note in sorted([u for u in uncertain if u[0] is not None]):
    lines.append(f"- p{pg}: {clip(note)}")

with io.open(OUT, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print(f"WROTE {OUT}")
print(f"applied fixes: {total} across {len(bypage)} pages")
print(f"type-B flagged: {len(typeB)} ; uncertain: {len(uncertain)}")
print("pages with fixes:", ",".join(str(p) for p in sorted(bypage)))
