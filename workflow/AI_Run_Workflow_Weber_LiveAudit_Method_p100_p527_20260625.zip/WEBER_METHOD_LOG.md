# Weber audit — method log (what works, what fails, adjustments)

Running record for the vol1 (Band I) grind. Companion to `WEBER_CERT_LOG.md` (per-fix provenance).
Loop started 2026-06-25 via `/loop "do vol 1 - keep meticulous logs of what works and adjust"`.

## The loop (validated on p100–107)
Per batch: render pages (`chunk_page.py`, 500-dpi native, 2400px chunks) → `weber_audit_workflow.js`
(audit agent/page → adversarial verify/fix, default REJECT) → **I hand-verify every surviving fix
against the scan** → apply verified ones to B139 `weber_v1_ge.tex` → `pdflatex` gate (0 errors AND
page count not dropped) → log to `WEBER_CERT_LOG.md`. One workflow at a time (rate-limit rule).

## What WORKS
- **Agent recall is high** — on p100–107 the agents found every real drop I'd found by hand.
- **Verify stage filters most false positives** (uniqueness + source-support, default reject).
- **Compile gate + page-count check** catches silent breakage (the SGA5 swallowed-page lesson).
- **Discipline holds** — agents preserve 1890s orthography, route source-typos to type-B (don't
  revert the editor's corrections), call parens/punctuation cosmetic.

## What FAILS (why the hand-check is mandatory)
- **Audit agents hallucinate drops/collapses that aren't in the `.tex`** (p105 eq5: claimed a
  one-line collapse; the `.tex` already had the correct two-line form). The verifier caught all 4
  on p105 — but in batch 1 one phantom slipped through *accepted* (p1 determinant, a page with no
  scan). **Verifier reliability varies.**
- **Phantom pages** when args are mangled or scans missing → agents invent content. (Fixed.)

## Adjustments
- 2026-06-25 — fixed `parseArgs` (handle stringified `{volume,axis,pages}`), `pad(3)` chunk names,
  `texOf` v1/v2/v3 path (was `vol1`).
- 2026-06-25 — added **no-scan guard** to `chunks()` (agent must bail, not hallucinate, if PNGs unreadable).
- 2026-06-25 — added **"CONFIRM ABSENCE BEFORE CLAIMING A DROP"** rule to the audit prompt (grep the
  `.tex` to confirm content is truly absent before emitting a drop-fix). Targets the eq5-type
  hallucination; effect measured from p108 onward.
- Batch size: 3 → 5 → trying 6. Tune by review load (every accepted fix = an eye-read of the scan).

## Metrics
| batch | pages | agents | tokens | clean pages | real fixes applied | false-pos rejected | phantom slipped | compile |
|-------|-------|--------|--------|-------------|--------------------|--------------------|-----------------|---------|
| 1 | p100–102 | 13 | 456k | p101 | 4 (p100 det row + deriv block; p102 a′₁ + dropped eq) | 1 (caught by me) | 1 (p1 dup, harmless) | 357pp/0err |
| 2 | p103–107 | 10 | 336k | p103,104,107 | 1 (p106 "VII." label) | 4 (all p105, by verifier) | 0 | 357pp/0err |

## Open / global decisions
- **"Coëfficient" diaeresis** — source has it, `.tex` drops it throughout. Systematic → decide once
  for the whole work, do NOT patch per page.
- Volume identity: vol1 = Band I confirmed (running heads "Zweiter/Dritter Abschnitt" + content match).
- Cursor: vol1 audited through **p527** (BUCH III Galois, §159 cubic + §160 4-element-groups PATCHED [worked-examples]; rewrite-block bounded §148-156+§158; **HELD: §69, §138-numbering, §141, p466, §148–149, §153, §154, §155, §156, §158**); next batch **p528–533** (rendered). Page count **366**. **~81% of vol1 done.**
- **QUEUED end-of-vol1:** GLOBAL `\bgibt\b`→`giebt` sweep (~18 unaudited 'gibt' modernizations remain; line 20688 mixes both).

## Batch 72 (p522–527, run w9yte0sww) — 19 agents, 638k tok
- §159 Cubische Gleichungen / §160 Permutationsgruppen von 4 Elementen. **13 fixes PATCHED (0 typeB); 365→366pp.**
- §159-160 = condensed WORKED-EXAMPLES (like §144-147): dropped intermediate eqs/cycle-tables/derivations but Weber-structure intact → surgically patchable (NOT held). Restored cubic resolvent derivation (eq 6, v³/vv' expansions, §47 xref), 4-element-group cycle-product tables + conjugate-group paragraphs. Cycle-products derivation-checked.
- CONFIRMS the rewrite-block is bounded (§148-156 + §158); §157/§159/§160 patchable-faithful. Worked-example/computational sections in Buch III behave like Buch I/II — patch the dropped math, prose-paraphrase = cosmetic.

## Batch 71 (p516–521, run wmvlyv99v) — 12 agents, 436k tok
- §157-tail / §158 (Imprimitive Gruppen). **1 applied (§158 title); §158 body HELD.** 365pp.
- §158 title fixed ('Reduction imprimitiver Gleichungen'→'Imprimitive Gruppen'). Body wholesale rewrite (dropped eqs 2-6, the (α)/(β) matrices + ϰ_β proof, the transitive↔intransitive-Normaltheiler inversion proof) → held.
- §157 faithful confirmed (p516-top Kronecker/natürliche-Irrationalitäten). So the rewrite ALTERNATES §-by-§ (§157 faithful, §158 rewritten) — NOT a clean §148-156 boundary; must audit each §. Held block = §148-156 + §158.

## Batch 70 (p510–515, run w23msqvxa) — 11 agents, 396k tok
- §155-tail / §156 / §157. **1 applied (§157 p514 Θ_1→Θ_i); §156 HELD; §155 extended.** 365pp.
- §156 (Die Gruppe der Resolventen) HELD (condensation: Total/Partialresolvente defs paraphrased, §156-tail dropped 3 paragraphs, Normaltheiler footnote dropped).
- **MAJOR BOUNDARY FOUND: the GPT-rewrite block is §148–§156; §157 RESUMES FAITHFUL transcription** (p514 verbatim-faithful, only a Θ_1→Θ_i typo). Resume normal patch-loop at §157+. (Confirms batch-69's 'eq6-in-§157' was agent confusion, not a real cross-section shuffle.)
- so the Buch-III Galois-APPLICATIONS rewrite is BOUNDED §148-156 (held for re-transcription); the Galois-FOUNDATIONS rewrite was §139-149 earlier. Expect §157+ patchable like Buch I/II.

## Batch 69 (p504–509, run wpj6f97ng) — 12 agents, 439k tok
- §154-body / §155 (Reduction der Resolvente, Lagrange-Galois). **0 applied — §154-body & §155 HELD.** 365pp.
- §154-body hold extended to p502-507 (conjugate-groups varkappa→χ, dropped isomorph-derivation + 'gleichberechtigte Untergruppe' footnote).
- §155 HELD: pervasive rewrite — dropped opening paragraph, irreducibility proof (Φ(t)+refs), the Lagrange footnote, the ω=χ(ψ)/φ'(ψ) derivation; eqs renumbered; eq (6) content SHUFFLED into the .tex's §157. CROSS-SECTION content-shuffle ⇒ cannot patch piecemeal.
- CONFIRMS the whole §148-§157+ region is a uniform GPT rewrite/renumber/shuffle. Loop role here = identify+spec each section for ONE coherent re-transcription pass (held-list = the spec). Moving faster per held section now that the pattern is established.

## Batch 68 (p498–503, run w79k00pmc) — 14 agents, 475k tok
- §153-tail / §154 (Divisoren/Nebengruppen/conjugate groups). **§154 opening patched (7 fixes); §153-tail + §154-body HELD.** 365pp.
- §153 hold extended to p492–500 (p499 Satz 10 wholesale, p500 π² cyclic-square dropped).
- §154 = patchable opening (p501, 7 prose fixes) + wholesale body (p502-503: own item/eq-renumbering, χ→ϰ symbol-sub, dropped Cauchy Fundamentalsatz + distinctness proofs + Nebengruppe def + specieller Fall). Body held (its renumbering would collide if I re-transcribed only p502).
- **'isomorph' was a RED HERRING** — Weber prints 'isomorphe' (p501); NOT a modernization marker (§149 hold stands on other grounds). LESSON: verify a suspected 'modern term' vs a clean Weber page before treating it as a GPT-tell.
- **render-bug RECURRED (2nd time after batch 65)**: hold batch → no compile → forgot to render next → false-clean 58s batch. HARD RULE now: render next batch as its own step every turn, never via the compile.

## Batch 67 (p492–497, run wf5zz76cd) — 12 agents, 419k tok
- §153 (transpositions/cycles/even-odd/alternating group). **0 applied — §153 HELD as 6pp wholesale rewrite (incl. fabrication).** 365pp.
- §153 = the §148-149 case (≥3pp wholesale) not the §150/§152 case: p494 worked example DROPPED, p495 parity proof rewritten, p497 worked compositions dropped, p493 cyclic-def FABRICATED (foreign (a,b,c)(d,e)(f) content). Held for coherent re-transcription (spec in CERT_LOG).
- **2nd in-section fabrication** (after §152 p490): GPT invents plausible math (disjoint-cycle examples) NOT in Weber. Reinforces: read the scan; don't trust the .tex's Buch-III worked examples.
- agent's 6 clean 'surgical fixes' (defs/theorems p492/493/496) NOT applied — coherent re-transcription cleaner than half-patching around the held proofs/examples.

## Batch 66 (p486–491, run wcdlw97gk) — 9 agents, 322k tok
- §151 / §152 (functions of independent variables). **§152 FULLY RE-TRANSCRIBED; §151 + p491 clean.** 364→365pp.
- §152 was a GPT rewrite but re-transcribable (each page clear): opening restored (+ dropped Cauchy/Jordan/Netto footnote), p489 ψ_π group-proof re-transcribed, p490 items 2/3/4 + m=3 example re-transcribed.
- **NEW: the GPT draft FABRICATES content** — §152's p490 body in the .tex was an INVENTED ρ/Φ 'zu P gehörig' passage matching no Weber §152/153 text; Weber's p490 is items 2/3/4 + an m=3 example. LESSON: read the scan to see what Weber ACTUALLY says; the .tex isn't always paraphrase/drop, sometimes pure fabrication.
- decision criterion refined: a REWRITE section is re-transcribable when each page's content is clear+self-contained (§152, §150) → re-transcribe; multi-page+entangled (§148-149) → hold.
- m=3 example: relation glyph 'c' but math+context ⇒ α_0; transcribed α + noted.

## Batch 65 (p480–485, run wbl1rm3k1 [re-run]) — 10 agents, 358k tok
- §149-tail / §150 / §151-start. **§150 re-transcribed + 9th erratum; p480-481 held; p483-485 clean.** 363→364pp.
- §150 short enough to RE-TRANSCRIBE directly (vs §148-149 held): restored Weber's full opening + reducibility proof + transitiv/intransitiv def + Satz + dropped transitiv-verbunden paragraph. KEY: SHORT paraphrased section → re-transcribe; MULTI-PAGE wholesale-rewrite → hold.
- 9th Weber erratum (p482 Satz1 'transitiv oder intransitiv' swapped vs his own proof; GPT silent-fixed→reverted+flag, crop-confirmed). DERIVE-to-confirm: same-page proof gives reducible⟺intransitive ⇒ print's word-order is the error.
- §149 Galois-biography footnote (p481) added to §149 re-transcription spec.
- **PROCESS BUG (fixed)**: HOLD batches skip the compile → I skipped the render → next batch's agents bailed on missing scans → 6 false-clean pages in 53s (vs normal 250–580s). ALWAYS render next pages, even on holds. TELL: anomalously fast + all-clean batch = suspect missing scans.

## Batch 64 (p474–479, run wgv8yr40s) — 15 agents, 510k tok
- §148–149 Galois permutation-groups / Galois-group. **0 applied — §148–149 HELD as a major wholesale GPT-rewrite.** 363pp.
- DECISION: unlike §144–147 (sentence-paraphrase w/ Weber's eq-structure intact → patched individually), §148–149 is a GPT REWRITE combining EVERY hold-class at once: §138 item-renumbering + §141 paraphrase + p466 whole-unit drops + symbol-subs (δ→σ cont., θ→Φ) + MODERNIZATION ('isomorph', 'durch Umformulierung der Sätze'). Patching = Frankenstein → held for coherent re-transcription (full spec in CERT_LOG).
- the agent's 8 'surgical fixes' restore real drops but into a rewritten frame → declined to apply (would be redone). LESSON: the agent can't see a section is wholesale; IT'S MY CALL — when drops + numbering + paraphrase + symbol-subs + modern-terms ALL co-occur, hold the section, don't patch.
- big discrete drops for the re-transcription: §148 inverse-verification matrices (p474_bot), cyklische-Gruppe example+3 matrices & Abel'sche-Gruppen/Theiler paragraph (p476), §149 d-proof displays (5)(6)(7)+g'(t) (p479).

## Batch 63 (p468–473, run wggn01ych) — 42 agents, 1.27M tok (BIGGEST)
- §146–148 Galois substitutions/composition/permutation-groups. **~40 fixes (32 agent + 71-occurrence δ→σ scoped conversion + ~6 self-caught), 0/6 clean.** 363pp.
- **NEW whole-section symbol-sub: δ→σ** (§146–147; GPT misread Weber's substitution σ as δ). KEY METHOD: agent flagged only ~12/71 δ's AND one agent correctly REJECTED isolated δ→σ as consistency-breaking → the right tool is a SCOPED Python range-replace (lines 16807–16979), like §129 α→a / §133 x→π / §135 Θ→Φ. Verified by my own zoom-crop FIRST (mandatory for a 71-instance change). δ genuine nowhere in §146–147; scope ends where §148 switches to π.
- removed a spurious GPT draft artifact: `\subsection*{Schluss von §147}` heading (NOT in Weber) — watch for draft-inserted structural headings.
- self-caught > agent again: the 'd.h./also' commutative-law fix (agent REJECTED a botched version), the two intermediate-product equation members (crop-confirmed), 'diesen Uebergang', 'die jedes Element an seiner Stelle lässt'. Galois sections need MY eye on every line; agent is finder only.
- §148 intro pervasively paraphrased too — applied clear errors/drops (Π(m)=m! removal, perm bottom-row, Zusammensetzung), HELD finer equivalent-rewordings for the §148 coherent rework next batch (§148 continues p474+).

## Batch 62 (p462–467, run wc8sx00lk) — 27 agents, 876k tok
- §144–146 Galois (primitive/imprimitive Körper, Normalkörper, Galois-resolvente). **22 applied (21 agent + 1 self-caught), p466 HELD.** 362→363pp.
- Same Galois-paraphrase pattern: apply individual non-overlapping clause/sentence/display restorations (scan-verified), HOLD wholesale-paraphrased pages.
- **p466 = 4th HELD wholesale-paraphrase** (after §69, §138-numbering, §141): eq(6)/eq(7)/Gesammtheit/G(t) all collapsed. 7 typeB. Needs re-transcription.
- p463→464 page-break overlap: two agents' #11/#12 reconstructed the SAME 'Fahren wir so fort' paraphrase → rebuilt as ONE edit from both pages (established overlap rule). Corrected agent's paraphrased connector to print's 'und nach dem, was wir vorhin bewiesen haben'.
- **self-caught miss + verifier blind-spot**: agent dropped 'Denn nach 2)…N=Ω(ρ).' (p467); its p466 verifier wrongly flagged the p467 'Nun haben G(t)…' conclusion as 'added prose'. LESSON: agent page-verifiers blind to the FACING page mis-call page-break-spanning proofs as added/missing — check the next page before trusting an 'added prose' typeB.

## Batch 61 (p456–461, run wioa94pvs) — 32 agents, 945k tok
- §142–144 Galois primitive-element theorem. **26 applied (25 prose + §143 title), 0/6 clean.** 362pp held.
- Galois prose STILL pervasively paraphrased (like §141), BUT these 25 are INDIVIDUAL + NON-OVERLAPPING clause-restorations/rewordings
  (each scan-verified) → APPLIED, not held. KEY DISTINCTION: hold only when reconstructions OVERLAP/conflict or the def is wholesale-reworded
  (§141); apply individual non-overlapping ones. This is the right approach for the Galois-prose-paraphrase stretch.
- §143 title: .tex used running-header abbreviation ('Mehrfache Adjunction'); restored Weber's full heading. agent-rejected #459 was real (stale anchor).
- edition-divergence typeB (§142 Theorem-1 layout) — flag only.

## Batch 60 (p450–455, run wxqs8k1yo) — 26 agents, 851k tok
- §139–142 Galois foundations (Körper/Adjunction/Functionen in Ω). **16 applied, 0/6 clean; §141 reducibility-paraphrase HELD.** 361→362pp.
- Galois-foundations prose is HEAVILY smoothed/paraphrased by the GPT draft (dropped footnote, dropped paragraphs, condensed defs) —
  worst prose-fidelity stretch since Buch I. Restored many dropped clauses/sentences/symbols (a_0..a_m, Δ(a), §.40, Ω'', x,y,z, Fraktur 𝔍).
- **3rd HELD item: §141 reducibility-section paraphrase (p453-455)** — def + three-way-distinction + examples + §51-ref all PARAPHRASED, not
  just dropped; agent #15/#18 OVERLAP (two agents reconstructing the same p454→455 paragraph). Coherent whole-§141 rework needed.
  Separated the CLEAN localized dropped-clauses (Satz I-III, the lead-in paragraphs) from the paraphrase cluster and applied those.
- Fraktur complex-field 𝔍 (J, descender) not 𝔠 (C) — zoom-confirmed; Weber's field letters: ℜ rationals, 𝔍 complex.

## Batch 59 (p444–449, run ws01x0ag2) — 11 agents, 367k tok
- §138 end → BUCH III Galois theory / §139 Körperbegriff. **3 applied, 4 clean; §138 numbering held.**
- §139 (Zahlkörper def) dropped: (die vier Species), Dedekind citation, (corpus, corps) + final verb. Clean dropped-content fixes.
- #1/#2 (p444 \tag{10'}→10, \tag{7'}→7) = the §138 primed-numbering — folded into the HELD §138 rework (conf 0.6).
- **MILESTONE: entered Drittes Buch (Galois theory), §139, p449.** Buch II (number theory) done.

## Batch 58 (p438–443, run w29kz28l6) — 15 agents, 470k tok
- §137–138 cyclotomy → quadratic reciprocity / Legendre symbol. **6 applied, 2 clean; §138 numbering HELD.**
- ω→α (root var, eq 27-29) + ∏^α upper-index; cos(-φ) generic-angle (not local ρ); dropped clause; Formel (1): back-ref.
- ⏸ **2nd HELD item (after §69): §138 proposition-numbering** — print's flush-left 1.-9. result-numbers vs .tex's enumerate
  + eq-tags (9', 10, untagged-8). Cross-refs ('bleibt 8.', 'aus (4) und (9)') don't resolve in the .tex. Needs whole-§138
  (p441-443) numbering reconciliation — held, not piecemeal (agent flagged it partly-cosmetic; conf on the 8/9 tags was low 0.68-0.72).

## Batch 57 (p432–437, run w82nzlwfx) — 8 agents, 288k tok
- §137 index/discrete-log / Theilung des Winkels (trig multiplication, A_n/B_n recursion). **2 applied, 4/6 clean.**
- LIGHT batch (this computational §137 is mostly faithful): = → ≡ relation (eq 21); dropped range bound (eq 10).
- §137 Π/Σ abbreviated-range notation (v above, range in prose) → .tex \prod_{v=...}: agent classified cosmetic (consistent).

## Batch 56 (p426–431, run wof92qfrs) — 18 agents, 570k tok
- §136–137 Fermat's theorem / primitive congruence-roots. **12 applied (1 type-B erratum), 2 clean.**
- **4th whole-section symbol-sub this chapter: §136 Fermat a→α (×5)** (incl. the agent-rejected line — it rejected on bad-escaping
  uniqueness but it's part of the systematic). §137 also x→π + Weber pp_1 notation again.
- **8th Weber erratum:** p426 'a_0a_0'≡1 (mod m)' — m=1⇒mod 1 trivial, should be mod n; zoom-confirmed 'm'. Draft silently
  fixed→reverted+flagged. (CONTRAST batch 55 where derivation showed the agent's typeB was WRONG — here it's a real slip; always check.)
- eq-form fidelity: cleared-denom→fraction (eq 3, y-eq); = → ≡ + product form (γ). Weber writes fractions/products; draft 'simplifies'.

## Batch 55 (p420–425, run w2gk96itc) — 20 agents, 613k tok (most math-delicate)
- §135–136 Kronecker irreducibility / discriminant / quadratic Gauss sum. **14 applied, 0/6 clean.**
- **★ DERIVATION OVERTURNED an agent typeB:** .tex (n-1)²/4 vs print (n-1)/2 in the ∏R sign AND eq (14). Agent called print
  (n-1)/2 a Weber typo. Truth: SIGN (-1)^{(n-1)/2}=(-1)^{(n-1)²/4} (m≡m² mod 2) ⇒ print correct, equivalent, NOT a typo;
  eq (14) (-i) order-4 ⇒ (-i)^{(n-1)/2}≠(-i)^{(n-1)²/4} ⇒ .tex WRONG. Both → printed (n-1)/2, NO erratum. LESSON: before
  accepting a 'source typo' flag, check whether the two forms are equal in the relevant group (mod 2 for ±1, mod 4 for ±i).
- non-commutative factor order R=(r^ν-r^μ)… (sign matters, type-A); eq(10) Weber-form n^{(n-3)/2}√{…·n}; restored dropped
  displays/clauses/Π; footnote (drop 'Kronecker,' — the name is in the body text, not the printed footnote).
- \tag{\S\,133} inside \[ \] compiles fine (amsmath active).

## Batch 54 (p414–419, run wl6o7t14i) — 22 agents, 667k tok
- §133–135 cyclotomic polynomials X_n / irreducibility. **16 applied, 0/6 clean.**
- **.tex SWAPPED n↔μ between sections:** §133 used μ where Weber wrote n_1 (p414); §134 used n where Weber wrote μ_1,μ_2
  (p417). OPPOSITE directions — restore each to print's actual letter (don't assume a symbol-sub is one-directional).
- **§135 Θ→Φ SYSTEMATIC (×9):** .tex used Θ(x) for Weber's product function Φ(x); convert WHOLE section (scoped — §127 unit Θ
  untouched). 3rd whole-section symbol-sub this stretch (§129 α→a, §133 x→π, §135 Θ→Φ) — cyclotomy chapter is sub-heavy.
- n=pp'qq' (Weber's recursive prime-power notation) not p^π q^χ; restored 2 dropped sentences/clauses.

## Batch 53 (p408–413, run wazg1ukmi) — 19 agents, 590k tok
- §131–133 roots of unity / cyclotomy / φ(n) totient. **15 applied, 2 clean.**
- **§133 x→π SYSTEMATIC (Latin→Greek this time):** .tex used Latin x for Weber's Greek π prime-power exponents (n=p^π…);
  agent flagged only SOME — I converted ALL §133 (15296-15308 incl. the p^{π-1} derivation chain). + q→ϱ. Like §129 α→a but
  reverse: when the draft font-substitutes a whole section's symbol, convert the WHOLE section, not just agent-flagged lines.
- **.tex inserts SPURIOUS intermediate equality members** (r^{k+hn}=, r^{mx+ny}=) not in the print — match print's compact
  form; also (r^n)^h→r^{hn}, (r^μ)^h→r^{hμ} for consistency.
- minor: dropped 'ist', dropped Π product symbol, h→k.

## Batch 52 (p402–407, run w6tvxhpjy) — 40 agents, 1.2M tok (LARGEST)
- §129–131 CF root-approx worked example / rational roots / Gauss-form congruence-factoring. **~34 applied, 0/6 clean.** 361pp held.
- **DERIVED the whole cubic CF chain to verify coeffs:** x³-2x-2, x=a_i+1/x_{i+1} each step → confirmed print's -3x,-14x,46x
  (.tex had -11x ×2 + 43 wrong). 7th erratum: print SWAPS a_3/a_4 labels on rows 4/5 (root-interval derivation proves);
  .tex had silently un-swapped → reverted to print's swap + flagged.
- **§129 α→a UNIFIED** (resolving batch-51-vs-52 conflict): faithful = Latin a (print); scoped to §129 ONLY (§130 φ/ψ coeffs
  α,β + §131 unknowns α,β,γ,δ,ε are GENUINE Greek — untouched). Agent's 'editorial choice' rationale loses to match-the-print.
- **rejected agent fix was INCOMPLETE not wrong** (δ=-12 passage): reconstructed the full passage from scan. Big garbled passages = reconstruct whole.
- congruence math (γ→γ², 2β, 1∓1) zoom-verified; many dropped clauses/sentences (worked-example sections drop heavily).
- LEFT a meaning-neutral paraphrase (15118) — 40 agents didn't flag; same numbers/logic; don't rewrite every smoothing.

## Batch 51 (p396–401, run w2xlg9o6a) — 23 agents, 721k tok (BIGGEST)
- §126–129 Pell eqn / units Θ / Gauss forms / §129 CF root-approx. **17 applied, 0/6 clean** (heavily garbled). 360→361pp.
- **agent REJECT was a real fix** (Somit→und es nach (10)): verifier uniqueness-grep said 0 matches but line 14849 HAD
  it; my Grep confirmed, reinstated. (Verifier-grep unreliable — recurring.)
- **two-alphabet α→a (×3) zoom-confirmed:** §129 CF partial quotients are Latin a_i (Weber's CF convention), .tex used
  Greek α. SYSTEMATIC in §129 — expect more α→a on p402+ (CF expansion continues).
- **inverse-typeB: print typesetting DEFECT (doubled `==`) — do NOT reproduce.** p396 eq(8)/p398 examples print '= = -4';
  .tex single '=' kept. Distinguish: substantive value-typo→transcribe+flag; pure glyph defect (==)→keep clean.
- over-insertion again ('und' p398); many dropped clauses/sentences + a footnote. footnote inside \begin{center}\textit compiled fine.

## Batch 50 (p390–395, run wqp463rr2) — 15 agents, 473k tok
- §125–126 periodic-CF + WORKED EXAMPLES (D=29,116,37,136,…). **9 applied, 0/6 clean** (examples garbled like Buch I).
- **GPT OVER-INSERTION live again (×2 one batch):** 'folgt' (p391), 'reellen' (p391) added by the draft — REMOVE. The
  draft drops AND pads; audit both directions.
- **DERIVE the CF to adjudicate a /2:** .tex had (5+√29)/2=[10,2,1,1,2] (D=116) but a_0=10⇒value≈10.39=5+√29 (not /2≈5.19);
  reduced form {4,10,1}⇒ω=(10+√116)/2=5+√29 confirms. Compute a_0 from the leading CF term to catch wrong LHS.
- worked-examples drops: a whole lead-in sentence (p392), an inline period [1,5,1] (p393), '=' signs — examples need
  full line-by-line; many dropped connectives too. 0 clean pages.

## Batch 49 (p384–389, run wvyx2j90c) — 10 agents, 365k tok
- §123–125 reduced forms / periodic continued fractions. **4 applied (1 type-B erratum), 2 clean.**
- **6th Weber erratum (p385 ω'-ω=2y√d):** same silent-correction pattern — draft signed Weber's unsigned printed
  difference. Typo-not-convention tell: the very next clause ('ω'_n negativ') needs the minus. → 6 errata.
- mostly dropped prose connectives (also/und/etwa so) this batch — Buch II periodic-CF prose is lighter.

## Batch 48 (p378–383, run wrvlraqan) — 17 agents, 549k tok (densest)
- §122–123 reduced quadratic irrationals (computation-heavy). **11 applied (2 type-B errata), 2 clean.**
- **2 NEW Weber errata, both = draft SILENTLY CORRECTED Weber's print** (the recurring inverse-pattern): (4) p382 β-case
  dropped +η² [eq14 + parallel case prove it]; (5) p378 eq(11) α_1-for-α [matrix-inverse math proves plain α]. Both
  reverted to print + flagged. → 5 errata total (Q_0 p221, u' p334, 30° p357, +η² p382, α_1 p378).
- **two-alphabet (a vs α) IS LIVE here:** §123 uses Greek α)/β) for the γ-cases AND Latin a)/b) for figure/exception
  cases ON THE SAME PAGE — the .tex conflated. ZOOM every case-label. (#5/#6/#7 = the Greek ones; Latin a)/b) stay.)
- **DERIVE to adjudicate:** agent #1 (α→α_1) contradicted the matrix-inverse math (plain α). Re-derived → α is math-correct,
  so the print's α_1 is the TYPO → type-B (transcribe+flag), NOT a plain accept. Math-first, then transcribe.
- gibt→giebt now agent-recognized (file ratio 300:18); ~15 remain for the end-of-vol1 global pass.
- crop geometry: chunk 'bot' eqs sit ~y=0.70-0.78 of full page; budget several re-crops on dense pages.

## Batch 47 (p372–377, run w1k1heeek) — 10 agents, 332k tok
- §119–121 modular substitutions / continued-fraction equivalence. **3 edits (4 candidates), 3 clean.**
- **TWO AGENTS, IDENTICAL ANCHOR, CONFLICTING REWRITES = a page-break block** (like Budan-Fourier p301-302): #2 (p373)
  and #3 (p374) rewrote the same .tex lines differently because the printed block SPANS p373→p374. Resolved by reading
  BOTH scan pages + rebuilding the true sequence (restore dropped M M'⁻¹ display + 'woraus folgt:' + reorder surviving display).
  RULE: conflicting same-anchor candidates ⇒ pull both pages, reconstruct, NEVER apply either alone.
- nicht→den (dative object of 'vorangehend') — a 1-word misread that INVERTS meaning; eyeball negations.

## Batch 46 (p366–371, run wte5nvrjp) — 10 agents, 316k tok
- §118–119 indeterminate equations / modular equivalence. **6 applied (4 accepted + 2 don't-modernize), 3 clean.**
- **AGENT MIS-CLASSIFIED don't-modernize as cosmetic:** it called the .tex's giebt→gibt MODERNIZATION 'cosmetic, never
  type-A' — but the USER's rule is KEEP giebt. So any 'gibt' = a modernization to REVERT. Caught + fixed p368/p370.
  ⚠️ SYSTEMATIC (~18 more 'gibt' in later/unaudited .tex incl. 20688 mixing both) ⇒ GLOBAL sweep at end-of-vol1.
- another dropped citation footnote (Dedekind/Crelle Bd.83) — footnote-drops keep recurring in number-theory chapters.
- coeff subscript swap (m=α_1x_1+δx) — eyeball subscripts in compact congruence derivations.

## Batch 45 (p360–365, run w0a0kv2u4) — 13 agents, 425k tok
- §116–117 continued fractions / Näherungsbrüche. **7 applied, 4 clean.**
- **don't-modernize NOTATION too:** Q_n→∞ (n→∞) was the .tex MODERNIZING Weber's 'Q_n=∞ für n=∞' (he used =/für, not
  the limit-arrow). Restored. Watch for modern limit/arrow notation substituted for Weber's =∞/für.
- a_ν→a_r (continued-fraction TERMINAL index r vs running ν) — zoom-confirmed; heading -elung (matches body); rephrasings.

## Batch 44 (p354–359, run wgawfchk9) — 11 agents, 410k tok
- §112–115 trig cubic → number theory (Restsystem). **6 applied, 1 type-B erratum, 3 clean.**
- **3rd Weber erratum (30°/33°, p357):** same inverse-pattern as u' (batch 40) — .tex silently corrected Weber's typo;
  reverted to print + flag (NOT in Berichtigungen ⇒ uncorrected). Zoom-confirmed.
- **don't-modernize PROPER NAMES too:** Brigg'sche (not Briggs'sche), restored ×2.
- **DISTINCTION for source typos:** substantive (numbers/math: u', Q_0, 30°) → transcribe print + flag; trivial
  word-typesetting (p355 'odre'→'oder') → accept the .tex's silent correction. (Both still cert-flagged.)
- verifier 'g^m' grep-fail again (p356 λ existed at 13131) — trust my Grep.

## Batch 43 (p348–353, run woj8yjuii) — 12 agents, 398k tok
- §111–112 Gräffe root-squaring / trigonometric cubic. **4 applied, 2 clean, 1 skipped.**
- p348 Gräffe coeff array: used the array's MIRROR SYMMETRY (coeff palindrome) to confirm wrong subscripts (pos 2 a_0²→a_1²,
  pos 4 by mirror of pos 3). Symmetry as a cross-check for coefficient-array errors.
- **SKIP call: tg³φ vs tg φ³** (eqs 5,8) — value-equal exponent PLACEMENT; kept .tex's tg³φ (unambiguous field-norm) over
  print's older tg φ³ (renders ambiguously as tan(φ³)). Same class as the Σ-layout skip (batch 31).

## Batch 42 (p342–347, run wzi38i6co) — 9 agents, 319k tok
- §110–111 Bernoulli/Gräffe methods. **3 applied, 4 clean.**
- **KEY REFERENCE — Weber's Berichtigungen:** the .tex carries Weber's own published errata (line 20867–20872), exactly
  2 entries: p182 (X_m not X_n) and p347 ((2x²+1)² not (2x²-1)²); the .tex applied both. So:
  • Source-typo question ⇒ check the Berichtigungen first. Weber-corrected ⇒ corrected form is AUTHORITATIVE (keep).
    Not listed ⇒ uncorrected typo ⇒ transcribe the print + flag type-B.
  • VALIDATES batch-40 (u' NOT in errata → my revert+flag was right) and batch-14 (p182 x_m matches Weber's correction).
- p344 running-index α_n→α_m (zoom-confirmed); p347 plural -en.

## Batch 41 (p336–341, run w5b2kbewo) — 8 agents, 271k tok
- §109–110 approximation methods / Bernoulli. **2 applied, 4 clean.**
- Small: plural -n (Näherungsmethoden), a paraphrase restoring 'Werthpaar'. Descriptive/numerical §§ low density.

## Batch 40 (p330–335, run wb061zdbo) — 8 agents, 295k tok
- §108–109 numerical solution / Newton's approximation. **2 applied (1 a type-B erratum revert), 5 clean.**
- **Inverse erratum:** the .tex had SILENTLY CORRECTED a Weber arithmetic typo (printed u'=0,0164, math 0,00164 — .tex
  used 0,00164). Reverted to the printed 0,0164 + flagged type-B. **The transcribe-faithfully rule cuts BOTH ways: when
  the .tex is 'more correct' because GPT fixed a source typo, REVERT to the print + flag — don't keep the silent fix.**
  [2nd erratum: Q_0 p221 had the typo IN .tex; here the .tex had the correction.]
- Δ_x→Δ_α subscript (table header).

## Batch 39 (p324–329, run wn24os3y8) — 24 agents, 736k tok
- §107 Laguerre (cont.). **18 applied, 0 clean.** Dense.
- Continued the §107 SYSTEMATICS: \sum→S (Weber's sum-over-roots operator; ~7 instances across batches 38-39) and a new
  one Ω→Φ (the form Φ; .tex used Ω throughout §107). Both whole-section; later genuine Ω (continued fractions, Körper)
  left intact (scoped the grep to §107 line range — the discipline for systematic conversions).
- Recurring: dropped H-covariant factor (xη-ξy)²/(cx'+dy')² on H terms; dropped squares on load-bearing terms; phantom
  block + dropped display. §107 was heavily reworked across 38-39.

## Batch 38 (p318–323, run w5die8q32) — 15 agents, 479k tok
- §106–107 Rolle/Laguerre. **~10 applied, 4 clean.**
- **§107 \sum→S systematic:** Weber's sum-over-roots is the OPERATOR S (his §42 notation), not Σ. The .tex used \sum
  throughout §107; print + prose 'das Summenzeichen S' confirm S. Agent converted only eqs 4,7 → I did all (1–4,7).
  **New watch-class: \sum vs Weber's S operator — in root-sum contexts (Laguerre/§42-style) Weber writes S.**
- p323 also: phantom-block removal (eq 4), a dropped r²H covariant display (agent's rejected-on-uniqueness — I located
  + restored), a dropped (cx'+dy')² factor, eq renumbering (5/6/7). Rebuilt with \begin{equation}\tag (safe form),
  not the stray `\[ \tag \]` the .tex had.

## Batch 37 (p312–317, run wwhxovth2) — 10 agents, 346k tok
- §103 Klein's geometric comparison / §104 Laguerre upper bound. **4 applied, 0 rejected, 2 clean.**
- Small: dropped heading-author 'Klein's', dropped xref '(a. f. S.)', subscript f_n→f_{n-1}, 'in'→'im §4'.
- Descriptive/geometric §§ low density again; the f_{n-1} confirmed via the §4 definition block on the next page.

## Batch 36 (p306–311, run w1x9p9vuc) — 15 agents, 513k tok
- §101–102 Newton/Descartes/Jacobi criteria. **9 applied, 0 rejected, 2 clean.**
- Dropped content: Doppelreihe top row (p309), eq (2) 1st formula (p311), enumeration-caveat clause (p306). Sign
  inversion +,-,+→-,+,- and dropped coeff 3D (p311) — math-relevant, scan-confirmed.
- **OVER-INSERTION (rare):** .tex added 'Jacobi,' to a footnote starting 'Observatiunculae' (body already says 'hat
  Jacobi'). Same class as p242/p304 over-expansions — GPT draft occasionally ADDS plausible text.
- **don't-modernize:** 'aller reellen'→'aller reeller' (print's older strong genitive -er) — same class as Theil/giebt.

## Batch 35 (p300–305, run wa273i4qi) — 15 agents, 519k tok
- §99–100 Budan-Fourier theorem / Newton's rule. **~12 applied + 2 sign tables restored, 1 clean (p305).**
- **Restored 2 DROPPED SIGN TABLES** (p301-302, Budan-Fourier μ-gerade/μ-ungerade case analysis) the .tex collapsed
  into prose. Agent flagged them <0.6 ('can't reconstruct, spans page break') — but with BOTH scan pages I had every
  +/− entry and rebuilt confidently. **Lesson: an agent 'spans page break / can't reconstruct' flag is MINE to resolve —
  pull both pages and rebuild; don't accept the collapse as final.** Rendered as clean arrays.
- λ→𝔷 (Fraktur z=Zahl/count) systematic ×3; zoom-confirmed. p304 eq (6) garble + eq (4) self-contradiction (F_n=1 vs
  F_n=f_n²) + an over-expansion — computation §§ keep garbling.

## Batch 34 (p294–299, run w3c0efzrk) — 8 agents, 314k tok
- §94–98 fundamental theorem of algebra. **2 applied, 0 rejected, 5 clean.**
- Both small (eq-into-sentence period→comma + d.h. lowercase). §95–98 (the geometric FTA proof) transcribed well.
- Footnotes on p296 (Gauss 1799), p299 (Sturm) PRESENT in .tex — footnote-drop pattern NOT recurring in these §§.

## Batch 33 (p288–293, run w2jxi5lw0) — 13 agents, 427k tok
- §93–94 Charakteristikentheorie. **8 applied, 0 rejected, 3 clean.**
- **a→α systematic (×4):** intersection-point label is Greek α; .tex had Latin a. Zoom-confirmed (crop_src.py) —
  important because the doc legitimately uses Latin a for COUNTS ('Ist a die Anzahl der Punkte A') on the SAME spread.
  So a/α is a real two-alphabet distinction; ALWAYS zoom a-vs-α, never assume from context.
- p292 dropped eq member (= via eq (2)), p288 parens, p289 connective — small.

## Batch 32 (p282–287, run wqtorxz0i) — 23 agents, 734k tok
- §89–93 Hermite-form discriminant determinant + characteristic theory. **16 applied, 2 clean.** Dense — Buch II isn't
  uniformly clean; computation-heavy §§ still garble.
- **TWO systematic notation conversions:** h_{i,k}→H_{i,k} (p284 bilinear-form coeffs) and θ→Φ (p286 arbitrary function;
  θ would clash with the angle ϑ=\vartheta). Both whole-passage. Verifier rejected 1 cell of EACH on bad-grep
  uniqueness — my own grep confirmed they exist, applied. **Verifier grep escaping is unreliable; trust my Grep over the verifier's uniqueness-fail.**
- **Restored a dropped determinant-decomposition block** (p284): |f_k(x_i)|=|a_0-triangular|×|Vandermonde| + a_0^{2n-2}→a_0²
  coefficient fix. Math-verified (product²=a_0^{2n}Π²=a_0²D). +1 page (359→360).
- **eq (6) uniform-range check:** the 3 sums must share range 0..n-1 (the .tex had n-2, 0 on lines 2-3). Use the uniform
  structure of a multiline sum to catch per-line limit errors.

## Batch 31 (p276–281, run wf8ghhsen) — 6 agents, 211k tok
- §88 Säculargleichung. **0 applied — ALL 6 pages CLEAN.** First fully-clean batch.
- **Σ-notation boundary clarified:** p277 .tex `\sum_{i=1}^n` vs print `\sum_{1,n}^{i}` = LEFT (cosmetic). Distinct from
  p255/p259 where the .tex had bare `\sum_1^m` (index variable DROPPED → fixed). **Rule: fix when the index variable is
  LOST; leave when complete but in conventional layout** (accept minor doc-internal Σ-style variation as the result).
- Confirms Buch II has genuinely clean whole sections (GPT draft transcribed §88 well). Agent auto-scaled to 6.

## Batch 30 (p270–275, run wns0kdpad) — 12 agents, 413k tok
- §85–87 Sturm chains. **6 applied, 0 rejected, 3 clean.**
- **Fraktur label (1)→(ℜ):** the .tex digitized Weber's Fraktur chain name `ℜ` (Reihe) as `(1)`. The AGENT was internally
  inconsistent (read K on p272, R on p273) and the VERIFIER disagreed (R) → classic zoom-it situation. crop_src.py
  confirmed Fraktur ℜ. **Lesson: when agent vs verifier disagree on a glyph (esp. Fraktur K/R), ZOOM — don't average.**
- Did it as a systematic 5-instance label fix (eq tag + all in-text refs), one consistent letter.
- **New Fraktur watch-class:** Fraktur letters in parens used as labels get digitized to numbers (𝔯→'1'). Watch for stray
  '(1)/(2)' in-text refs that should be Fraktur names, esp. in the Galois chapters (Gruppe 𝔊, etc.).

## Batch 29 (p264–269, run wtx630oo8) — 7 agents, 244k tok
- §83–84. **1 applied, 0 rejected, 5 clean.**
- p264 = 2nd `\`-macro escape-corruption (`\nu`→newline+`u`; cf. p194 `\\eta`). These compile fine but render WRONG
  (silent). Ran sweep `\$\\(pi|mu|nu|rho|tau|chi|phi|psi),?\s*$` → 1 candidate ~line 19660 CHECKED = FALSE POSITIVE
  (legit line-wrapped list `$\psi,`⏎`\psi_1,`⏎`\ldots`). **Discriminator: a REAL corruption's next line starts with a
  non-macro fragment (p264 next line was `u$`); a legit wrap continues with `\macro`.** So the sweep is a triage, not
  a verdict — eyeball the next line.
- **New standing check: escape-corruptions are SILENT (0 compile errors, wrong glyph). The line-end-macro grep is a
  cheap periodic sweep — re-run each major section.**

## Batch 28 (p258–263, run w3kk5thy0) — 19 agents, 592k tok
- §81–83 quadratic forms / vanishing determinants. **13 applied, 0 rejected, 3 clean.**
- **Systematic `ξ`→`z` across §81** (10 instances): the .tex consistently mistranscribed Weber's Latin linear-form
  variable z as Greek ξ. Did the whole passage as ONE conversion.
- **Verifier signal worth noting:** it REJECTED a single ξ→z cell with reason 'needs uniform conversion, not a single
  line'. Treat that kind of rejection as 'DO the whole passage', not 'skip' — the verifier is flagging systematicity.
- Σ double-index (Σ_{1,k}^{r,s}) collapsed to Σ_1^k AGAIN (now p255, p259×2) — Weber's range-on-bottom/indices-on-top
  Σ is a recurring transcription loss; watch it in every quadratic-form sum.

## Batch 27 (p252–257, run wj6z5uigg) — 9 agents, 331k tok
- §79 Bezoutiante/Realität + §80 Trägheit (inertia of quadratic forms). **3 applied, 0 rejected, 3 clean.**
- All 3 small symbol/form fidelity fixes: dropped `±`, transposed eq (π+ν=n-1), Weber's double-index Σ_{1,m}^{i,k}.
  Buch II error profile = small single-symbol/form deviations (vs Buch I's dropped derivation blocks).
- Consistent rule on transposed equations (π+ν+1=n vs π+ν=n-1): MATCH the print = type-A faithfulness, NOT cosmetic
  (a transposition across '=' changes the literal form, unlike a commutative reorder which stays cosmetic).

## Batch 26 (p246–251, run wpkamn8yq) — 9 agents, 326k tok
- §78 biquadratic discussion. **3 applied, 0 rejected, 4 clean.**
- 2 more dropped §-end footnotes (Kronecker/Dyck, Clebsch/Faà di Bruno) — drop pattern continues (now
  p209, p210, p233×2, p250×2). The footnote-presence sweep is increasingly worth doing.
- `-I^2`→`-T^2`: caught by .tex-internal consistency (§66 (7) uses -T²) + zoom-clear scan. T/I confusion = another
  single-glyph misread class to watch in Buch II.

## Batch 25 (p240–245, run w7dhyhsih) — 8 agents, 272k tok
- §76–78 root reality / Sturm. **2 applied, 0 rejected, 4 clean.**
- **First clear OVER-EXPANSION:** p242 the .tex ADDED the full discriminant product where Weber printed only a
  representative factor `(x_1-x_2)²` (prose covers 'sämmtliche Wurzeldifferenzen'). So the GPT draft doesn't only
  drop — it occasionally 'helpfully' expands shorthand. Confirms the audit must (and does) flag .tex-content-not-
  on-page, both directions.
- Buch II staying low-density (4/6 clean), as expected for root/Galois theory vs the garbled invariant-theory Buch I.

## Batch 24 (p234–239, run wszgm639n) — 7 agents, 265k tok
- §75/76 end of Erstes Buch → 'Zweites Buch. Die Wurzeln' divider (p239). **1 applied, 0 rejected, 5 clean.**
- Density dropped sharply (5/6 clean) now that the invariant-theory/transformation chapters are done — expect
  lower fix-rates in Buch II (root/Galois theory). Agent auto-scaled DOWN to 7 (vs 30 in §71); the scaling
  tracks candidate density well, so token cost will fall through the cleaner chapters.
- p235 sign fix confirmed by math (next eq) + scan.

## Batch 23 (p228–233, run wv6xbxijm) — 20 agents, 611k tok
- §73 Bezoutiante + §74/75. **12 applied, 0 rejected, 3 clean (p230–232).**
- **Systematic `t`→`τ` across a whole table column** (E-table right factor column). Handled as ONE whole-column
  rewrite (12 cells) not 12 patches — the systematic-notation rule again. This auto-fixed the 2 cells the verifier
  rejected (one uniqueness-fail on its scoped old_string, one a_0/a_1 misread).
- **Verifier a_0/a_1 misread caught by row-pattern + zoom:** verifier claimed E_{1,3}=3a_0τ_0; the row pattern
  (3a_1 in E_{1,1},E_{1,2}) said 3a_1; crop_src.py zoom confirmed 3a_1. The f'(t)-coefficient structure of the
  column is a strong internal check — use structural patterns to overrule single-cell agent/verifier reads.
- 2 dropped §-end bibliographic footnotes restored (Cayley, Gordan). **Recurring pattern: §-end citation footnotes
  keep getting dropped (p209, p210, p233×2).** Candidate for a targeted footnote-presence sweep across vol1.

## Batch 22 (p222–227, run wxv40r1h5) — 16 agents, 523k tok
- §71 Cardano tail + §72 general transformation. **10 applied, 0 rejected, 3 clean (p225–227).**
- §72 is back to normal density (3 clean pages) after the §68–71 garbled stretch. §71's Cardano tail (p222)
  was still heavy — a big multi-equation derivation block badly garbled, restored from the scan + verified
  internally consistent.
- `\varrho` misread as `\Omega` (curly-rho → capital-omega): single systematic symbol, fixed at both occurrences.
- **agent restructure block (#5) matched the scan exactly AND was internally math-consistent — when BOTH hold,
  a big block restore is safe.** (Contrast §69, where the agent grafts were mutually inconsistent → held.) This
  is the discriminator for "restore vs hold" on big garbled blocks.

## Batch 21 (p216–221, run w1buniwck) — 30 agents, 915k tok (worst region, §70–71)
- §70 Hermite-satz + §71 cubic transformation. **20 applied, 1 Weber erratum flagged, 0 clean pages.**
- §71 (cubic) is computation-dense → many dropped/garbled coefficients (dropped `a_0^λ`, `a_0^{n-1}`,
  the whole `Q_0=…` RHS, the `Q_0` line; wrong exponents `x_1→x_1²`; `-tH`→`-2/3 H`).
- **Built `crop_src.py`** (the long-pending tight-zoom tool): renders a fractional page box at high dpi +
  upscales, for glyphs the width-capped chunks can't resolve. Used it to settle a 2/3-vs-2/9 denominator →
  confirmed Weber printed 2/3 (a genuine erratum; math demands 2/9, proven two ways).
- **Math cross-checks caught a real fork the agents missed:** agent #14 (`3Q_0=⅔H·Q_2-a_1f`) and #18
  (`Q_0=-⅔t_0H`) are mutually inconsistent ×3. Re-deriving independently (sum of eq (9); and matching eq (10)
  to 3·eq (9)) proved #14 right and Weber's printed `Q_0` wrong. **LESSON: on computation-dense pages, derive
  the relations yourself — agent fixes can each be plausible but mutually inconsistent.**
- **Half-made agent fix completed by me:** eq (5) — the agent fixed only the prose (`y_1-y_2`) and left the
  equation in general `i,k` form; I restored the print's specific `1,2` + plain fraction. Always cross-check the
  WHOLE display when the agent flags only its prose.
- θ→t was a systematic Greek→Latin (3 spots) — fixed together (whole-section consistency), per the batch-20 rule.

## Batch 20 (p210–215, run wgfxgnw5z) — 27 agents, 894k tok (worst region yet)
- §68–69 Tschirnhausen/Hermite transformation. **§68: 5 applied. §69: 10 HELD.**
- §68 (p210–211) was genuine same-edition garbling (dropped Hermite footnote; eqs (3),(4),(6),(9) all
  index-shifted or wrong-LHS) — verified + applied like any batch.
- **§69 (p213–215) is the first STRUCTURAL hold.** The .tex confused Weber's `Φ(τ,ξ)` with `H` (symbol
  collision) and dropped the `Φ_ν` expansions + a derivation block. The verify stage flagged it as a
  possible 'edition difference' and rejected the piecemeal Φ-graft. My read: confused transcription, not
  a different edition — but it needs a COHERENT whole-section rework, not loop patches. Flagged in cert log.
- **New rule: when a section shows a SYSTEMATIC notation collision (one symbol consistently standing in
  for another, with internal self-consistency), HOLD the whole section for a dedicated coherent pass — do
  NOT apply the agent's per-line grafts (they make a broken hybrid).** Same lesson as the SGA5 global-notation
  decisions: systematic = decide once, section-wide; never piecemeal.
- 27-agent auto-scale: the workflow scaled up because §68–69 had ~20+ candidates. High recall, but the §69
  structural issue is exactly what per-page agents can't resolve (no whole-section context). Reconfirms that
  whole-section human judgment is the gate, not the swarm.

## Batch 19 (p204–209, run w1agyukjg) — 17 agents, 549k tok (dense)
- §65–67 invariant theory: **11 applied, 0 rejected, p204 clean.** Dropped derivation block, weight
  exponent r^{2μ}, I→I' ×3, an inverted substitution (ξ'=λξ→ξ=λξ' + matching coeff exponents — both are
  consistent conventions, so I matched the print and moved both together), χ→ψ ×2, generator-list order,
  a dropped bibliography footnote.
- **Faint-scan lesson:** the p209 chunk renders were washed-out → I deferred the footnote, re-rendered the
  FULL page (clear), verified the 4 citations exactly, then applied. **New step: when a chunk is too faint
  to read, re-render `--full` before deciding — don't guess, don't silently drop.**

## Batch 18 (p198–203, run w97rvytee) — 9 agents, 325k tok
- **3 applied (p198 dropped Q^τ + dropped display; p203 discriminant exponent via homogeneity), 0 rejected,
  4 clean.** The p203 fix is a clean math-verified catch: D's two terms must share degree 6, so the .tex's
  −4a'_1a'_3³ (deg 4) → −4a'_1³a'_3³ (deg 6).

## Batch 17 (p192–197, run w6wwajy55) — 18 agents, 574k tok (densest yet)
- §62–63 cubic-form invariant theory: **10 applied, 2 rejected, p193 clean.** Heavy garbling — a `\\eta`
  LaTeX corruption, a garbled identische-Relationen equation (wrong primes+subscripts+structure), 2 dropped
  clauses, wrong exponents (α,β vs h,k), a fabricated 2-step λ−2α chain, a dropped D^{-1/6} exponent.
- Rejects: γ→σ (6th revert-the-editor; print's σ is a typo, the proof is about γ) + a "remove ist" skip.
- **Note:** dense invariant-theory pages need full math reasoning (verified the λ−2α equivalence via eq (3);
  confirmed D^{-1/6} via r⁶=−27/D) AND reading multiple chunks — the disputed equations straddled chunk
  boundaries, so I fetched p195_top / p197_bot in a 2nd pass before deciding.

## Batch 16 (p186–191, run wsm4x3nui) — 7 agents, 246k tok
- **1 applied (p188 dropped word "den"), 0 rejected, 5 clean.** §60 (covariants / Hessian) well-transcribed.
  The commutative-cosmetic rule is now firing in-agent (a_0 r^n vs r^n a_0 auto-classified cosmetic).

## Batch 15 (p180–185, run wkgrk0q50) — 10 agents, 354k tok
- **0 applied; p183/184 clean; all candidates cosmetic or revert-the-editor.** §57–59 (quadratic forms /
  functional determinant) is well-transcribed.
- Key reject: p185 `Φ'`→`Φ` — the .tex's Φ' (partial derivative = coeff of t in the Taylor expansion,
  parallel to F') is math-correct; the print dropped the prime. 5th revert-the-editor catch.
- Skipped as cosmetic: dummy summation-index name (i vs ν) and Σ-index placement (\sum_i vs \sum^i) —
  no math meaning; the .tex's consistent choices are defensible standardizations.

## Batch 14 (p174–179, run wh4r37hzt) — 10 agents, 343k tok
- **4 applied, 0 rejected, 3 clean.** Notable: a dropped section-divider heading (Fünfter Abschnitt /
  Lineare Transformation) — first dropped-heading catch in vol1; plus a dropped α_0 (caught via the
  .tex's own "vier Verhältnisse" internal inconsistency) and reversed transformation-coeff indices
  a_{ν,i}→a_{i,ν}.
- **New watch category:** Abschnitt section-divider headings sit between sections and are easy for the
  transcription to skip — check page tops at section boundaries.

## Batch 13 (p168–173, run w0h0vvsc5) — 8 agents, 281k tok
- **1 applied (p172 dropped ν-equation + "und"), 1 rejected (p172 s-subscript (n-1)→(n+1), 4th
  revert-the-editor catch), 5 clean.** §52 mixed a genuine drop and a source-typo-revert temptation on
  the SAME page — verify each candidate independently, even within one page.

## Batch 12 (p162–167, run wbi1e27lk) — 7 agents, 246k tok
- **0 applied, 1 rejected by me, 5 clean.** The reject (p162 "Endgleichung für z"→"x") is the 3rd
  revert-the-editor/inject-error catch (cf. batches 7, 11): eliminating x,y can't give an equation "für x";
  the §50 chain is x→y→z so the end-equation is in z (.tex correct). Agent's reasoning self-contradictory again.
- **Standing pattern:** in well-transcribed regions a large share of agent "accepted" candidates are
  attempts to revert correct .tex readings to source typos — caught by math/context, not by the verifier.

## Batch 11 (p156–161, run wokiihclr) — 9 agents, 318k tok
- **2 prose fixes applied (p160, p161), 1 rejected by me, 3 clean.** The reject (p158 eq (14), resultant
  degrees) was the hardest call so far: the agent's fix would have INJECTED a Weber error into the
  math-correct .tex. Settled by a concrete n=2/m=1 example (Σν=m, Σμ=n is the truth). The agent's own
  type-B note had the right reasoning while its fix contradicted it — classic "verify the MATH, not the agent."
- Found a paired Weber erratum: §49 (5) `nν+mμ` should be `mν+nμ` (same swap); the .tex reproduces it
  faithfully — left type-B (notes the .tex's eq14-corrected vs §49(5)-faithful internal inconsistency).

## Batch 10 (p150–155, run wxyrbtpam) — 8 agents, 270k tok
- **1 applied (p154 β−γ sign error −u+v→u−v), 1 rejected by me (revert-the-editor: p155 dropped a_4 — the
  quartic needs all 5 coeffs), 4 clean.** The sign error is a good catch (a real math error in the .tex);
  the a_4 reject is the familiar "keep the editor's completion of a source oversight" pattern (cf. Collectet, (19)/(20)).

## Batch 9 (p144–149, run wmbmrvo7l) — 9 agents, 305k tok
- Low-density: **2 small fixes (p144 dropped word "etwa", p148 dropped 0 in a tuple), 3 clean, 1 correctly
  rejected** (verifier kept the authentic ".tex etc."). §44–45 symmetric-functions text is well-transcribed.

## Batch 8 (p138–143, run wo4jo4wfi) — 16 agents, 519k tok
- §41–43 symmetric functions: **9 real fixes applied, 1 correctly rejected by the verifier, p138 clean.**
  Many dropped equation lines/terms (f_3 line, eq (4) first line, eq (11) long form, +A_{m-1}α) + a dropped
  Newton footnote + a `\Pi(n)`→`n!` notation modernization.
- **Verifier got one right** (rejected p140 x→n, keeping the .tex's correct "n") — inconsistent but not useless.
- Weber's factorial is `\Pi(n)`, not `n!`; the .tex sometimes modernizes it — watch for more. Orthography
  policy holding: fix lone spelling slips (sämtlich→sämmtlich), defer systematic modernizations (Theil/teil).

## Batch 7 (p132–137, run w0za37gy4) — 9 agents, 323k tok
- **0 fixes applied. 4 clean (p132/133/136/137). All 3 agent candidates REJECTED on review** — the
  strongest "hand-check is the gate" data point yet (the verifier passed all 3):
  - p134 ×2: agent escalated Weber's double-bar `≦` (= ≤) to `\gtreqless` (⋛); the .tex `\le` is correct
    (prose "innerhalb oder an der Grenze" + the math both say ≤). The agent even described it as ≦ but mislabeled it.
  - p135: revert-the-editor xref (print "(20),(21)" is an off-by-one source typo; .tex correct "(19),(20)" kept).
- **Adjustment applied:** rule added — Weber's `≦/≧` are leqq/geqq (cosmetic `\le/\ge`), never escalate to `\gtreqless`/3-way.
- **Verifier scorecard:** it has now passed false candidates I rejected in batches 1, 4, and 7; reliable
  filtering only in batch 2. The verify stage is a WEAK filter; my eye is the gate.

## Batch 6 (p126–131, run wtfu7alt6) — 16 agents, 561k tok (densest yet)
- §38–39 Fundamental-Theorem convergence proof: **10 real fixes, 0 rejected, p127 clean.** Highest-value
  batch — the math was garbled in consequential ways: systematic θ→Θ (×4), a `kleiner`↔`grösser`
  inequality-direction inversion, several dropped general terms, a mis-tagged eq (11) with a dropped
  equation, a dropped QED.
- **New adjustment/check:** an agent "restructure" patch un-tagged a display using `\begin{equation}`
  (which auto-numbers) where the doc convention is `\[…\]`. I corrected it on apply. RULE: inspect any
  agent restructure that adds/converts an equation environment for spurious auto-numbering.
- Dense proof pages → many interrelated fixes; 16 agents auto-spun (561k tok). Consider 4-page batches
  in proof-dense regions to cap review load.

## Batch 5 (p120–125, run wnbmmoci2) — 10 agents, 348k tok
- 4 real fixes, all single-symbol/variable misreads (p121 d→δ ×2; p123 spurious "=y+iz" removed; p124 γ→y localized); p120/122/125 clean, 0 rejected.
- **Pattern emerging:** this region's errors are Greek/Latin glyph confusions (d/δ, γ/y, and ε/ξ in batch 4)
  — the dominant vol1 failure mode is **single-glyph misreads, not big drops**. Cheap for agents to find,
  easy to eye-verify, but they MATTER (wrong variable). Verifier passed all 4 (correct this time).
- Cosmetic discipline held: kept "kann" (Weber typo "kan"→type-B), `≦`→`\le`.

## Batch 4 (p114–119, run w4kwfrqpa) — 12 agents, 386k tok
- 5 real fixes applied (p114 roots-of-unity ξ→ε ×3 + bogus-eq removal/restore; p118 xref (1)→(6)); p115/116/117 clean.
- **I rejected 1 the verifier passed:** p119 `Collected`→`Collectet` — agent tried to revert the editor's
  correction of Weber's misprint (and self-contradictorily flagged it type-B too). The "don't revert
  obvious-typo corrections" rule is already in the prompt; the agent still violated it → hand-check is the gate.
- p114 was the fix-dense page: one symbol misread (ε→ξ) propagated to 4 spots plus a fabricated equation —
  exactly the kind of cascading transcription error worth catching.

## Batch 3 (p108–113, run wahdj8vfy) — 13 agents, 440k tok
- Verifier accepted **ALL 8** candidates (0 rejected) → the **hand-check did all the filtering**: I
  applied 5 real, SKIPPED 2 as cosmetic (p111 `ci`↔`ic` commutative reorder), p110 clean.
- The **confirm-absence rule worked**: the p109 agent grepped for the dropped `√[2n]` equation,
  found none, and correctly flagged the drop (no false "it's there").
- **Adjustment applied (active from p114):** "commutative reordering is cosmetic, never type-A" rule
  added to the audit prompt — directly targets the p111 over-flags.
- **Observation:** verifier reliability is inconsistent (filtered 4/4 in batch 2, 0/8 here) — my eye
  is the real gate, not the verify stage. Dense pages (8 candidates/6 pp) → keep batches ≤6 in this region.
