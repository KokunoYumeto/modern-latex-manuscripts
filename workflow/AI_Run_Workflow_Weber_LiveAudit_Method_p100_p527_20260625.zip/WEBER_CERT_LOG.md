# Weber audit — certification log

Tracks every change applied to the canonical B139 `.tex` (under `…/02_cumulative/vN/ge/`),
with provenance. Method: agent finder (weber_audit_workflow.js) → I verify each fix by eye against
the 500-dpi scan → apply → pdflatex gate (0 errors AND page count not dropped).

## v1 (Band I) — weber_v1_ge.tex
Backup before first edit: `weber_v1_ge.tex.bak_pre_agentfix_20260625` (same dir).
State: **compiles 360 pp / 0 errors** (grew from 356 as dropped blocks/footnotes were restored).

### 2026-06-25 — p100 + p102 (agent run wzmu04tqc; each fix hand-verified vs scan)
APPLIED (4):
- **p100 eq (9) determinant** — restored the dropped `φ(α₂)` row (scan shows φ(x), φ(α₁), φ(α₂), …, φ(αₙ); .tex had only φ(α₁) then dots).
- **p100 derivation block** — restored the dropped *"wofür wir auch setzen können"* + three displays `[x,…]=f(x)/(x−αᵢ)·[…]` + *"und ebenso"* (the bridge from (10) to formula (11)).
- **p102** — `f₁(x)=a₀xⁿ⁻¹+a′₁xⁿ⁻²+⋯` (restored the dropped `a′₁xⁿ⁻²` term).
- **p102** — restored the dropped second equation `f(x)=(x−α)(x−β)f₂(x)` on the `f₁=(x−β)f₂` display line.

DEFERRED (not applied — need tight-crop zoom to settle):
- p100 "Nenner" — `x−α₁, x−α₂ … x−αₙ` vs .tex ellipsis `x−α₁,…,x−αₙ` (agent conf 0.8; minor).
- p102 — source "Coëfficient" diaeresis vs .tex "Coefficient": my hand-read flagged it, the agent read it as faithful. Sub-symbol mark; settle with a crop before any change.

p101: clean (verified).

### 2026-06-25 — p103–107 (agent run wdraz676o; each candidate verified by eye)
APPLIED (1):
- **p106** — restored the dropped theorem numeral **VII.** before "Sind die Coefficienten $a_0,\ldots,a_n$ und die Variable $x$ reell…" (set off like VI/VIII; .tex had it as a bare paragraph). Compiles **357 pp / 0 err** (unchanged).

NO FIX NEEDED: p103, p104, p107 clean. **p105 — agent proposed 4 fixes, verifier rejected ALL 4** as phantom (old_string 0 matches); I hand-confirmed eq (5) is already the correct two-line `split` form (the audit agent hallucinated a one-line collapse). p104 `a_2/x` is a source-print typo the .tex correctly carries as `a_2/x^2` (type-B, untouched).

SYSTEMATIC (deferred — global policy, decide once for the whole work, do NOT patch per page): source prints "Coëfficient" (diaeresis); the .tex has "Coefficient" throughout.

### 2026-06-25 — p108–113 (run wahdj8vfy; each candidate verified by eye)
APPLIED (5):
- **p108 sign-schema** — restored the printed single shared header `ξ−ε<ξ<ξ+ε` (was two x-headers) and the `f(x)` row labels (were bare `1. 2. 3. 4.`).
- **p109** — restored a DROPPED displayed equation `\sqrt[2n]{a}=\sqrt[2]{\sqrt[n]{a}},\ \sqrt[4n]{a}=\sqrt[2]{\sqrt[2n]{a}}\ldots` and fixed garbled radical indices (`√a,√[n]a,√[n]α / "für jedes α"` → `√[n]a,√[2]a,√a / "für jedes a"`).
- **p112** — restored dropped equation number **(2)** on the `a=r(cosφ+i sinφ), a'=…` display (was untagged; (1),(3) present).
- **p113** — prose `nicht mehr als n` → source `n und nicht mehr` (exactly n; more precise).
- **p113** — prose `Die beistehende Figur` → `Die beistehende Fig. 1` (explicit reference; the Fig. 1 tikz exists in the .tex).
Compiles **357 pp / 0 err** (unchanged).

SKIPPED as cosmetic (commutative reorder, no math change): p111 ×2 `(b-ci)`→`(b-ic)` in eq (9) and the fraction. `ci=ic`; print and .tex are both internally inconsistent on the order anyway. p110 clean.

### 2026-06-25 — p114–119 (run w4kwfrqpa; verified by eye)
APPLIED (5):
- **p114** roots of unity — `\xi_k`→`\varepsilon_k` (×3: eq (11), "Werth von ε_k", Moivre `ε_k=ε^k`); the print uses ε throughout, the .tex misread it as ξ.
- **p114** — removed a spurious tagged eq (12) `\xi_k^n=1` and restored the real eq (12) `x^n=1` (the .tex had demoted it to inline); dropped the spurious word "ihrer".
- **p118** — xref `cubischen Gleichung (1)`→`(6)` (print shows (6)).
Compiles **357 pp / 0 err**.

REJECTED by me (kept the .tex): p119 footnote `Collected`→`Collectet`. Weber misprinted "Collectet"; the .tex correctly has "Collected" (Cayley's real title) — a defensible editor correction of an obvious typo, so KEPT and flagged type-B (the agent self-contradictorily emitted it as both a fix and a type-B). p115, p116, p117 clean.

### 2026-06-25 — p120–125 (run wnbmmoci2; verified by eye)
APPLIED (4) — all single-symbol/variable misreads:
- **p121** `d`→`\delta` (×2) — the lower-bound proof's small quantity is δ in print; the .tex had Latin d.
- **p123** — removed `=y+iz` that was wrongly added to the FIRST "Variable $x$" (print has bare x there; `=y+iz` belongs only to the second occurrence "der Variablen x=y+iz").
- **p124** `(P,\gamma)/\gamma<\eta/\gamma>\eta` → `(P,y)/y<\eta/y>\eta` — the cut variable is y (print); γ is correctly used later for the minimum value, so this was a localized misread.
Compiles **357 pp / 0 err**. p120, p122, p125 clean; 0 rejected.
Source typos correctly KEPT (not reverted): p125 Weber "kan"→.tex correct "kann" (type-B); `≦` double-bar glyph → `\le` (cosmetic).

### 2026-06-25 — p126–131 (run wtfu7alt6; dense §38–39 proof; each verified by eye)
APPLIED (10):
- **p126** — restored dropped QED marker "w. z. b. w." after eq (18).
- **p128** eq (5) — restored dropped explicit term: `a<b_1\le b_2\le b_3\le\cdots\le b_{n-1}`.
- **p129** — `\beta_i`/`\rho_i` → `\beta_1`/`\rho_1` (print uses subscript 1).
- **p130** — SYSTEMATIC `\theta`→`\Theta` (capital, ×4: the `a'<a\Theta` chain, eq (14) `a\Theta^\nu`, "da Θ^ν", and the `\Theta=1-\omega/4Q` definition); the print uses capital Θ throughout this proof.
- **p130 "Differenzen"** — fixed a `kleiner`↔`grösser` DIRECTION INVERSION and restored two dropped displays (the differences `(1-a/4Q),(1-a'/4Q),…` and `\Theta=1-\omega/4Q`); the .tex had paraphrased to inline `a^(ν)/4Q … grösser … ω/4Q`.
- **p130 eq (11)** — restored the dropped equation `α'=α-af(α)/(2Qf'(α))` and moved the (11) tag onto it; the δ/h display it had wrongly tagged is now untagged `\[…\]` (NOT `\begin{equation}`, which would auto-number spuriously). Added the dropped general term to the `a'<a\Theta` chain.
- **p131** — `|f'(α^(r))|≥k`→`|f'(α)|>k` (print: plain α, strict >; matches the p129 bound); restored the dropped general term `a^(ν−1)−a^(ν)>(a^(ν−1))²/4Q` in the eq (13) chain (stacked).
Compiles **357 pp / 0 err**. p127 clean; 0 rejected. Type-B kept: p130 eq (12) print "u" typo → .tex correctly "a".

### 2026-06-25 — p132–137 (run w0za37gy4; verified by eye)
APPLIED (0). p132, p133, p136, p137 clean. No .tex change → gate stays **357 pp / 0 err**.
**ALL 3 agent candidates REJECTED on review** (the verifier had passed all 3 — hand-check was the only gate):
- **p134 eq (10) & eq (14)** — agent escalated Weber's double-bar `≦` to `\gtreqless` (⋛). REJECTED: the .tex `\le` is correct — the prose says "im Inneren oder an der Peripherie/Grenze von (ϱ)" (= ≤) and the math (bound holds inside the disk) confirms ≤. The agent's own description ("two bars over a < wedge") is ≦=≤, mislabeled. Cosmetic glyph; kept `\le`.
- **p135 xref `(19),(20)`→`(20),(21)`** — REJECTED: the .tex correctly points to the inequalities (which ARE (19),(20)); the print's "(20),(21)" is an off-by-one SOURCE typo the editor fixed. Kept the correction; flagged type-B.

### 2026-06-25 — p138–143 (run wo4jo4wfi; §41–43 symmetric functions; verified by eye)
APPLIED (9):
- **p139** `n!`→`\Pi(n)` (Weber's factorial notation, book-wide; the .tex had modernized it).
- **p140** `sämtlich`→`sämmtlich` (lone slip vs the .tex's own 34× "sämmtlich" + the print).
- **p141** eq (2) — restored printed form `f(x)/(x−α)=…+f(α)/(x−α)` (the .tex had folded f(α) into the LHS numerator).
- **p141** eq (3) — restored dropped line `f_3(α)=α³+a₁α²+a₂α+a₃`.
- **p141** eq (4) — restored dropped first line `S(f(x)/(x−α))=f'(x)`.
- **p141** `worin nach §4,(8):`→`worin [§4,(8)]:` (brackets, dropped "nach").
- **p142** — restored dropped Newton footnote ("Arithmetica universalis, edit. 's Gravesande, p. 592").
- **p143** eq (11) — restored the dropped LONG form + connecting prose "die sich nach (7) auch so darstellen lassen:" (the .tex had only the short unnumbered form, mislabeled (11)).
- **p143** eq (3) — restored dropped term `+A_{m-1}α`.
Compiles **358 pp / 0 err** (was 357; +1 from restored content; no page swallowed). p138 clean.
REJECTED (verifier got this right): p140 `x`→`n` — print "x" is a source typo (sign of a_n is (−1)^n, depends on n); .tex correctly "n". Type-B.

### 2026-06-25 — p144–149 (run wmbmrvo7l; verified by eye)
APPLIED (2): **p144** restored dropped word "etwa" ("in S etwa noch vorkommenden"); **p148** restored dropped explicit 0 in the order tuple `(1,0,0,\ldots,0)` (matches siblings (1,1,0…0)/(2,0,0…0)). Compiles **358 pp / 0 err**. p145, p146, p149 clean.
REJECTED (verifier got this right): p147 — agent wanted to delete the .tex's "etc.", but the verifier's zoom confirmed the .tex matches the page; kept.

### 2026-06-25 — p150–155 (run wxyrbtpam; verified by eye)
APPLIED (1): **p154** eq (10) `β−γ`: `-u+v`→`u−v` — a genuine SIGN error (print shows u−v; the (X+Y, X−Y) difference-pattern and the cubic case at .tex 5529 both confirm). Compiles **358 pp / 0 err**. p150–153 clean.
REJECTED by me (revert-the-editor): **p155** `a_0,a_1,a_2,a_3,a_4`→`a_0,a_1,a_2,a_3` — the general quartic eq (14) is `a_0x⁴+…+a_4` (5 coeffs); the print's list OMITS a_4 (source oversight), the .tex's complete `a_0…a_4` is correct. Kept; type-B.

### 2026-06-25 — p156–161 (run wokiihclr; verified by eye)
APPLIED (2): **p160** prose `unendlich vieler`→`unendlicher` Wurzeln; **p161** prose `gewisse Werthepaare`→`gewisse dieser Werthpaare` (dropped "dieser"). Compiles **358 pp / 0 err**. p156, p157, p159 clean.
REJECTED by me (would inject a Weber error into the correct .tex): **p158 eq (14)** `Σν=m,Σμ=n`→`Σν=n,Σμ=m`. MATH truth is `Σν=m, Σμ=n` (verified by concrete example: f deg n=2, φ deg m=1 → Res=a_0b_1²−a_1b_0b_1+a_2b_0², degree 1=m in the a's, 2=n in the b's). The .tex already has the correct form; the PRINT's eq (14) is a Weber error.
  **Paired Weber erratum (type-B, left faithful):** §49 eq (5) prints `nν+mμ` for the resultant's y-degree, but the math-correct form is `mν+nμ` (same m↔n swap as the print's eq (14)). The .tex reproduces the print's `nν+mμ` there — faithful to the source error; note this leaves the (corrected) eq (14) and §49 (5) mutually inconsistent in the .tex. Flagged, not silently changed.

### 2026-06-25 — p162–167 (run wbi1e27lk; verified by eye)
APPLIED (0). p163–167 clean; p162 effectively clean. No .tex change → gate stays **358 pp / 0 err**.
REJECTED by me: **p162** `Endgleichung für z`→`für x`. Eliminating x and y cannot yield an equation "für x" (an eliminated variable); the §50 elimination chain is x→y→z, so the end-equation is in **z** — the .tex is correct. The print's "x" (if that is the glyph; the agent's own reasoning was self-contradictory) is a Weber typo. Kept .tex "z"; type-B.

### 2026-06-25 — p168–173 (run w0h0vvsc5; verified by eye)
APPLIED (1): **p172** restored a dropped displayed equation `ν_0+ν_1+ν_2+⋯+ν_{n-1}=m` + the "und" connector (between the "…vorkommt," prose and the μ-equation; it restates eq (13)). Compiles **358 pp / 0 err**. p168–171, p173 clean.
REJECTED by me (revert-the-editor; 4th such): **p172** s-subscript `(n-1)`→`(n+1)` — eq (12)'s x-exponent uses (n-1), so eq (14)'s s-subscript must too; the print's "(n+1)" is an internal-inconsistency typo, the .tex's "(n-1)" is correct. Kept; type-B.

### 2026-06-25 — p174–179 (run wh4r37hzt; verified by eye)
APPLIED (4):
- **p175** restored dropped `α_0` in the ratio chain `α_0:α_1:α_2:α_3:α_4` (the .tex said "vier Verhältnisse" but listed only 4 quantities = 3 ratios; eq (2) has 5 params α_0..α_4).
- **p178** restored the dropped section divider `Fünfter Abschnitt. / Lineare Transformation.` (the .tex flowed straight into §55; the parallel "Sechster Abschnitt" was present in-file).
- **p179** ×2 transformation-coeff index order `a_{ν,i}`→`a_{i,ν}` (and primed): print shows i first, consistent with the single-function `a_i`; coeffs not symmetric.
Compiles **358 pp / 0 err**. p174, p176, p177 clean; 0 rejected.

### 2026-06-25 — p180–185 (run wkgrk0q50; verified by eye)
APPLIED (0). p183, p184 clean; p180/181/185 had only cosmetic/revert candidates. No .tex change → gate stays **358 pp / 0 err**.
- **p185 eq (2)** `Φ'(x'_i)`→`Φ(x'_i)`: REJECTED (revert-the-editor) — eq (2) is the coeff of t in `Φ(x'_i+tξ'_i)=Σξ'_iΦ'(x'_i)`, so Φ' (partial derivative) is REQUIRED, parallel to eq (1)'s F'. The .tex's Φ' is correct; the print's unprimed Φ is a dropped-prime typo. Type-B.
- **p180 eq (3)** `ξ_i u_i`→`ξ_ν u_ν` and **p181 eq (11)** over-Σ index: SKIPPED as cosmetic — dummy summation-index name/placement, no meaning change; the .tex's consistent `i`/`\sum_i` is a defensible standardization (cf. the agent's own "Σ-index placement is cosmetic" note on p185).
- **p182** `x_m`→`x_n`: rejected by verifier; keep-the-editor anyway (print's x_n is a typo, ψ is of m variables).

### 2026-06-25 — p186–191 (run wsm4x3nui; verified by eye)
APPLIED (1): **p188** restored dropped word "den" ("Wenn wir nach den §. 16, (4) die Function"). Compiles **358 pp / 0 err**. p186, p187, p189, p190, p191 clean; 0 rejected. (Agent correctly auto-classified a commutative reorder `a_0 r^n`/`r^n a_0` as cosmetic — the rule is firing in-agent now.)

### 2026-06-25 — p192–197 (run w6wwajy55; §62–63 cubic-form invariant theory; verified by eye + math)
Densest batch yet — 13 candidates, **10 APPLIED, 2 rejected, p193 clean**:
- **p194** fixed .tex corruption `\\eta`→`\eta` (doubled backslash rendered a line break + literal "eta").
- **p195** identische Relationen: garbled chained-primed `3a'_1A'_0+a'_0A'_1=…` → two clean unprimed identities `3a_3A_0+a_1A_2=a_2A_1, a_2A_0+3a_0A_2=a_1A_1`.
- **p196** `C`→`C'` ×3 (covariant in the normal-form variables); exponents `α,3β`→`h,3k`; restored dropped parenthetical "(da wir die numerischen Coefficienten … vorausgesetzt haben)".
- **p197** restored dropped clause "(weil eine symmetrische Function von zwei Grössen…)"; `λ−2α` fabricated 2-step chain → `\frac32(μ−ν+2β+2τ)`; `r durch D`→`D^{-1/6}`.
Compiles **358 pp / 0 err**.
REJECTED: **p197** `γ`→`σ` (6th revert-the-editor — the paragraph proves γ integral; the print's "σ" is a Weber typo, the .tex's γ correct; type-B). SKIPPED: **p192** remove "ist" (low value, removing a grammatical word).

### 2026-06-25 — p198–203 (run w97rvytee; verified by eye + math)
APPLIED (3): **p198** restored dropped leading `Q^τ` on the first "Summe der Form" (eq (8) correctly keeps it dropped since Q is primitive); **p198** restored dropped display `(-1)^α M x^{2(α+β)} y^β` (+ "dieses"→"dies"); **p203** eq (11) `D=…−4a'_1a'_3³`→`−4a'_1³a'_3³` (D is a degree-6 invariant; the .tex term was inhomogeneous degree 4). Compiles **358 pp / 0 err**. p199–202 clean; 0 rejected.

### 2026-06-25 — p204–209 (run w1agyukjg; §65–67 invariant theory; verified by eye + math)
Dense — 11 candidates, **11 APPLIED, 0 rejected, p204 clean**:
- **p205** restored dropped derivation block (`ψ_1=a'_1ξ²−a'_3η²=a_0[…]/(α−β)` + "Darin aber … cyklisch zu vertauschen. Man findet so").
- **p206** `I'=r^λ I`→`r^{2μ}` (weight; I is degree μ); `Function I`→`I'`; `I(a)=I(0,…).`→`I'(0,…),`; "Diese Function I … a'_1a'_3 und a'_2"→"und diese Function I … a'_2 und dem Product a'_1a'_3".
- **p207** inverted substitution `ξ'=λξ`→`ξ=λξ'` (+ matching coeff exponents `λ^{-2}a'_1,λ²a'_3`→`λ²a'_1,λ^{-2}a'_3`); `χ`→`ψ` in eq (5) + its prose (Weber distinguishes ψ(5) from χ(6)).
- **p208** generator list `A,D,B`→`A,B,D` (matches print + eq (3)).
- **p209** restored dropped bibliography footnote (Clebsch 1872 / Faà di Bruno 1881 / Gordan–Kerschensteiner 1885 / F. Meyer 1890–91) — verified against a full-page re-render (the chunk scans were too faint).
Compiles **358 pp / 0 err**.

### 2026-06-25 — p210–215 (run wgfxgnw5z; §68–69 Tschirnhausen/Hermite; SPLIT — §68 fixed, §69 HELD)
Worst-transcribed region so far (27 agents, 894k tok). **§68 (p210–211): 5 APPLIED. §69 (p213–215): 10 HELD (see flag). p212 cosmetic only.**
§68 applied (genuine same-edition garbling):
- **p210** restored dropped footnote (Hermite, *Sur quelques théorèmes d'algèbre…*, Comptes rendus, Paris 1859).
- **p211 eq (3)** wrong LHS `x^ν`→`f(t)/(t−x)`, ν→n indices, restored dropped `+t f_{n-2}(x)` term.
- **p211 eq (4)** f_ν array shifted by one: restored `f_0=a_0` row, corrected last row to degree n−1.
- **p211 eq (6)** S[f_ν] shifted: restored `S[f_0]=na_0`, added `S[f_2]` row.
- **p211 eq (9)** wrong general formula → explicit `F_0,…,F_{n-2}` array (the .tex formula gives wrong F_0 even after eq (4) is corrected).
Compiles **359 pp / 0 err** (footnote + restored rows = +1 page; no swallow).

⚠️ **§69 HELD — p212–216 (.tex 7748–7876) needs a DEDICATED COHERENT REWORK, not piecemeal:**
The .tex §69 systematically writes `H(τ,ξ)` for Weber's eq-(3) analytic function `Φ(τ,ξ)`, which COLLIDES with the print's *separate* `H(τ,ξ)` (eq (10), the τ_k-substituted symbolic form `=Στ_kΦ_k`). It also drops the `Φ_ν(ξ)` expansion lines and a derivation block (the `dt/dτ=r/(γτ+δ)²` formula + the subtraction step). The verify stage correctly REJECTED the single eq-(8) Φ-graft (would reference an undefined symbol / break consistency) and flagged a possible "edition difference"; my read is it's a confused transcription, not a different edition. Either way the 10 agent candidates are scoped Φ/H grafts that together make a broken hybrid. **FIX PLAN:** read all print §69 (p212–216) in one pass, then rework .tex 7748–7876 coherently — restore `Φ` for the eq-(3) function, keep `H` only for the eq-(10) symbolic form, restore the `Φ_ν` expansions + the dropped blocks. Do NOT apply the agent's 10 §69 candidates individually. (Edition cross-check available: BSB first-edition Band I scan on disk.)

### 2026-06-25 — p216–221 (run w1buniwck; §70 Hermite-satz + §71 cubic transformation; verified by eye + math)
Another worst-region (30 agents, 915k tok), 0 clean pages. **20 APPLIED, 1 Weber erratum flagged.**
§70 (p216–218):
- **p216** restored dropped `a_0^\lambda` (`a_0^λ P(y_1…y_n)=K(t,a)`); `Coefficienten von f'(t)`→`-\frac1n f'(t)`; coefficient list →`0, -\frac{n-1}{n}a_1…, -\frac1n a_{n-1}` (added 0, minus signs, removed spurious `(n-2)/n a_2`); `p_2…p_n`/`p_ν`→capital `P` (eq (3) + prose).
- **p217** display `\frac{f(t)}{t-x}`→`-\frac1n f'(t)` added (it's F(t,x)); eq (5) restored print's specific indices + plain fraction `y_1-y_2=(x_1-x_2)\frac{f(t)}{(t-x_1)(t-x_2)}` (.tex had general i,k + a `(…)_t` wrapper not in print) + matching prose; **systematic Greek→Latin** `θ_{ik}`→`t_{i,k}` (×3: prose, eq (6), eq (7)) — print uses Latin t for building blocks, capital Θ for their product; eq (7) also restored `a_0^{n-1}` on LHS.
- **p218** `C_ν=Q_ν/Θ`→`ΘC_ν=Q_ν` (print's form).
§71 cubic (p220–221):
- **p220** eq (5) 2nd group `\tfrac23a_1x²+\tfrac13a_2x+\tfrac13a_3`→`a_0x²+a_1x+\tfrac23a_2` (= F_1 from §68); Δ `-4(\tfrac13H)³-27(\tfrac1{27}Q)²`→`-\tfrac1{27}(4H³+Q²)` (print's compact form, connects to eq (7)).
- **p221** restored dropped `3Q_0=\tfrac23H(t_1,t_0)Q_2-a_1f(t_1,t_0)` (.tex had `Q_0=0`); `y_2-y_3` factor `(x_2+x_3+t)`→`(t_1-t_0x_1)`; `y_2²-y_3²` restored dropped `y_1` factor; sum formulas `Σx_1(x_2-x_3)`→`Σx_1²(x_2-x_3)` & `a_0²x_1²`→`a_0³x_1³` (.tex's first was identically 0); restored dropped `Q_0` line + fixed `Q_1`,`Q_2` (`-t`→`-t_0`); eq (10) `-tH(t)`→`-\tfrac23H(t)`.
Compiles **359 pp / 0 err** (no swallow).

⚠️ **WEBER ERRATUM (type-B, transcribed faithfully as printed):** p221 final `Q_0` line prints `-\tfrac23 t_0 H`, but the H-coefficient must be **2/9** — proven twice: (a) Weber's own `3Q_0=\tfrac23H·Q_2-a_1f` (same page) with `Q_2=-t_0` ⇒ `-\tfrac29 t_0H`; (b) matching eq (10) `(3a_0x+a_1)f=-\tfrac23H+yf'-3y²` against `3·`eq (9) ⇒ `3Q_0=-a_1f-\tfrac23H` ⇒ `2/9`. Weber's page is internally inconsistent; the printed `Q_0` (2/3) is the typo. Zoom-verified via new `crop_src.py` (glyph is unambiguously `3`). RESTORED AS PRINTED (2/3) + flagged; candidate for an editorial `[sic; 2/9]` footnote — user's call.

DEFERRED (equal-value, not yet scan-confirmed): p218 `\sqrt{\Delta}`→`\Theta\sqrt{D}` (=√Δ since Δ=DΘ²). REJECTED (w/ agent): p217 eq (6) i,k authentic; p219 ×3 (.tex already correct).

### 2026-06-25 — p222–227 (run wxv40r1h5; §71 Cardano tail + §72 general transformation; verified by eye + math)
**10 APPLIED, 0 rejected, p225–227 clean** (16 agents, 523k tok).
§71 Cardano (p222):
- eq (12)/(13) `\Omega`→`\varrho` (varrho misread as Omega) + eq (13) `Q(t)`→`Q`; eq (14) `\sqrt[3]{Q(t)}`→`\sqrt[3]{3\varrho f(t)}`; prose `Der`→`und der Ausdruck (10)`.
- **Restored a badly-garbled Cardano-derivation block** (§62 link): `.tex` had `ξ=-h^{-1}Q`, `f(t)=r³f(t)=η³+ξ³`, `(16) 3a_0x+a_1=A-(ξ+η)`, `A=q_0/2A_0³` → print's `ξ=-hϱ; f(t)=ξ³, f'=3ξ²ξ'; f(t)=-h³ϱ³, f'=3h³A_0ϱ²; y=hϱ∛(3ϱ)/3; 3a_0x+a_1=-hA_0∛(3ϱ)-1/(h∛(3ϱ)); (16)=A_0(k-h)∛(3ϱ); hA_0∛(3ϱ)=∛((-q_0+3ϱa_0)/2), kA_0∛(3ϱ)=∛((+q_0+3ϱa_0)/2)`. Internally math-consistent (`ξ=-hϱ⇒f=ξ³=-h³ϱ³`, `f'=3ξ²ξ'=3h³A_0ϱ²`, eq (14)⇒`y=hϱ∛(3ϱ)/3`).
- eq (17) Cardano formula `q,p`→Weber's `a_3,a_2` (depressed cubic `p=a_2,q=a_3`); added `(§35)` xref.
§72 (p223–224):
- **p223** eq (5) restored dropped `a_0` factor (`E_{r,0}=a_0t_{n-1-r}`, consistent w/ eq (9) at s=0); prose `E_{r,s}; diese sind…t.`→ relative clause `E_{r,s}, die…t sind.`
- **p224** prose `Wenn wir`→`und wenn wir` (dropped connective + de-capitalized).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p228–233 (run wv6xbxijm; §73 Bezoutiante + §74/75; verified by eye + math)
**12 APPLIED, 0 rejected, p230–232 clean** (20 agents, 611k tok).
- **§73 E-table (p228–229)** systematic `t`→`τ` in the entire RIGHT factor column (the bilinear φ(t)φ(τ) construction; left columns stay in t). Rewrote all 12 cells at once: row coeff = f'(t) coeff (4a_0,3a_1,2a_2,a_3) × τ_{3-s}. Agent caught 10; verifier wrongly rejected 2 (E_{3,2} uniqueness-fail on its scoped old_string; E_{1,3} misread as `3a_0` — zoom-confirmed `3a_1`, consistent with the row). Whole-column rewrite covers all.
- **§75 (p233)** restored two dropped footnotes: Cayley (on Tschirnhausen's Transformation, Phil. Trans. 1861, Math. Papers IV, Nr. 275) + Gordan (Math. Annalen Bd. 28, 1886).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p234–239 (run wszgm639n; §75/76 → 'Zweites Buch. Die Wurzeln'; verified by eye + math)
**1 APPLIED, 0 rejected, p234/236/237/238/239 clean** (7 agents, 265k tok). Mostly clean (end of Erstes Buch).
- **p235** `ξ=-\frac1{y+\sqrt c}`→`ξ=\frac1{y+\sqrt c}` (spurious minus; the next line `y=(1-ξ√c)/ξ` only follows from `+`; scan shows no minus, equals sign directly on the fraction bar).
Compiles **359 pp / 0 err**. (p239 = the 'Zweites Buch / Die Wurzeln' divider — new major part begins.)

### 2026-06-25 — p240–245 (run w7dhyhsih; §76–78 root reality/Sturm; verified by eye + math)
**2 APPLIED, 0 rejected, p240/241/243/245 clean** (8 agents, 272k tok).
- **p242** discriminant display: `.tex` OVER-EXPANDED Weber's prototype `(x_1-x_2)^2,` into the full product `(x_1-x_2)^2(x_1-x_3)^2⋯(x_{n-1}-x_n)^2,` — print shows only the single representative factor (full product described in prose 'Quadrate der sämmtlichen Wurzeldifferenzen'). Reverted to print. **(rare direction: .tex ADDED content, not dropped.)**
- **p244** prose `also sind alle drei Wurzeln reell`→`also alle drei Wurzeln reell` (dropped inserted `sind`; elliptical, parallel to 'also nur eine Wurzel … reell' above).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p246–251 (run wpkamn8yq; §78 biquadratic discussion; verified by eye + math)
**3 APPLIED, 0 rejected, p246–249 clean** (9 agents, 326k tok).
- **p250** restored two dropped footnotes: Kronecker (Monatsbericht Berliner Akad. 14 Feb 1878 + Dyck Katalog math. Modelle, München 1892, source of Fig. 5); Clebsch (Theorie der binären Formen §47) + Faà di Bruno (Walter, Leipzig 1881, §20, w/ Nöther's Zusatz).
- **p251** `-I^2`→`-T^2` in the covariant series `1, H, H²-16Af², -T²` (capital T misread as I; .tex's own §66 (7) at line 7534 uses -T²; scan p251_bot unambiguous T).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p252–257 (run wj6z5uigg; §79 Bezoutiante/Realität + §80 Trägheit; verified by eye + math)
**3 APPLIED, 0 rejected, p252/256/257 clean** (9 agents, 331k tok).
- **p253** restored dropped leading `\pm` on the Vandermonde determinant (`\pm|det|=∏(x_r-x_s)`; Vandermonde = product only up to sign).
- **p254** `π+ν+1=n`→`π+ν=n-1` (transposed +1; print's literal form).
- **p255** eq (2) `\sum_{1}^{m}`→`\sum_{1,m}^{i,k}` (Weber's double-index Σ: indices i,k on top, range 1..m below; .tex dropped the i,k labels).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p258–263 (run w3kk5thy0; §81–83 quadratic forms / vanishing determinants; verified by eye + math)
**13 APPLIED, 0 rejected, p261–263 clean** (19 agents, 592k tok).
- **§81 systematic `ξ`→`z`** (p258–259): the .tex rendered Weber's Latin linear forms `z_1,…,z_k`/`z_s` as `\xi` throughout — 10 instances (eq (2), the matrix prose, h-equation, y-system RHS ×3, the eq-(4)/(5) lead-in, eq-(6) lead-in). Converted the whole passage (incl. the cell the verifier rejected for wanting exactly this uniform conversion).
- **p259** eq (7) `\sum_{1}^{k}`→`\sum_{1,k}^{r,s}` (double-index Σ again); eq (6) `\varphi(…)',`→`\varphi(…);` (spurious prime + comma→semicolon).
- **p260** second-underdeterminant `A_{i,k}^{h,l}`→`A_{i,i'}^{k,k'}` (print's index convention).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p264–269 (run wtx630oo8; §83–84; verified by eye)
**1 APPLIED, 0 rejected, p265–269 clean** (7 agents, 244k tok). Very clean.
- **p264** .tex escape-corruption: `$\pi,\nu$` was split at a line-wrap into `$\pi,`⏎`u$` (the `\n` of `\nu` eaten as a newline → rendered 'π, u'). Restored `\nu`. **(2nd escape-corruption after p194's `\\eta`.)**
Compiles **359 pp / 0 err**. Sweep `\$\\(greek),?$` (unclosed macro at line-end) found 1 more candidate ~line 19660 (~p500) — flagged for when the audit reaches it.

### 2026-06-25 — p276–281 (run wf8ghhsen; §88 Säculargleichung; verified by eye)
**0 APPLIED — ALL SIX PAGES CLEAN** (6 agents, 211k tok). §88 (secular equation / Sturm) faithfully transcribed; only cosmetic diffs (Coëfficient diaeresis, ss/ß, spaced ellipses, footnote accent style acute-vs-grave, and a conventional `\sum_{i=1}^n` vs Weber's `\sum_{1,n}^{i}` layout — LEFT as complete-notation re-expression, NOT an info-loss like p255/p259's bare `\sum_1^m`). Gate unchanged **359 pp / 0 err** (no .tex change). Sturm footnotes on p279/p280 PRESENT in .tex (not dropped).

### 2026-06-25 — p270–275 (run wns0kdpad; §85–87 Sturm chains; verified by eye + zoom)
**6 APPLIED, 0 rejected, p270/271/275 clean** (12 agents, 413k tok).
- **Sturm-chain label**: the .tex rendered Weber's Fraktur chain name `(ℜ)` as the digit `(1)` throughout §86. Zoom-confirmed Fraktur **ℜ** (R for Reihe; agent was split K/R, verifier said R, my zoom + context = R). Fixed all 5 instances → `(\mathfrak R)`: eq (1) right-margin label (added, kept \tag{1}) + 4 in-text refs.
- **p274** prose `So ist P_n(x) … Grades, und`→`so dass P_n(x) … Grades ist, und` (restored subordinate clause + clause-final `ist`).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p282–287 (run wqtorxz0i; §89–93 Hermite form / discriminant determinant / characteristic theory; verified by eye + math)
**16 APPLIED, p282/287 clean** (23 agents, 734k tok). Dense again.
- **p283** eq (6): all three sums `\sum_{s=0}^{·}`→`\sum_{s=0}^{n-1}` (2nd was n-2, 3rd was 0; print uniform 0..n-1) + eq-end period→comma; `z=y`→`τ=t`; `Dies`→`und dies`; `so ergeben sich`→`so ergiebt sich`.
- **p284** systematic `h_{i,k}`→`H_{i,k}` (×3: H=ΣΣ def, prose, S-def) + prose `t_it_k`→`t_iτ_k` (bilinear §91(6)); **restored dropped determinant-decomposition block** (`(-1)^nf(α)/a_0·|f_k(x_i)|²` + `|a_0-triangular|×|Vandermonde|` + `a_0^{2n-2}D`→`a_0²D`; math: product²=a_0^{2n}Π²=a_0²D); `so wird Δ`→`Δ also`; `Δ_n(α)`→`Δ_n(α)=Δ`.
- **p285** cubic Kette `-H_{2,2},-(…)/a_0,-Δ`→`(1/a_0)H_{2,2},(1/a_0)(…),(1/a_0)Δ` (signs+factor); 'vier Functionen' 3rd/4th terms badly garbled → restored (incl. `-f(α)D`).
- **p286** systematic `θ`→`Φ` (×3: prose, dΦ, eq (2) `[φ,Φ]`) — Weber's arbitrary function is Φ (θ would clash with the angle ϑ).
Compiles **360 pp / 0 err** (was 359; +1 from restored p284 block).

### 2026-06-25 — p288–293 (run w2jxi5lw0; §93–94 Charakteristikentheorie; verified by eye + zoom)
**8 APPLIED, 0 rejected, p290/291/293 clean** (13 agents, 427k tok).
- **p289 systematic `a`→`α`** (×4: 'der Punkt α', 'ψ in α positiv/negativ', Fig 9 node) — the intersection-point label is Greek α (zoom-confirmed; matches φ/ψ style + Fig 9). NB the doc DOES use Latin a elsewhere (counts: 'Ist a die Anzahl', p288), so a/α is a real distinction — zoomed to be sure.
- **p292** eq (3) restored dropped third member `=ψ'(x)²+ψ'(y)²` (= φ'(x)²+φ'(y)² via eq (2)).
- **p288** parenthesized '(Im Falle der Fig. 8 ist sie gleich −1)'; **p289** prose `Es gilt`→`und es gilt`.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p294–299 (run w3c0efzrk; §94–98 fundamental theorem of algebra; verified by eye)
**2 APPLIED, 0 rejected, p295–299 clean** (8 agents, 314k tok). Mostly clean.
- **p294** eq (4) `k=A_ε.`→`k=A_ε,` + `D. h.`→`d. h.` (the equation flows into the 'd.h.' sentence; period+capital → comma+lowercase).
- Footnotes p296 (Gauss 1799 'Demonstratio nova'), p299 (Sturm) PRESENT in .tex (only accent/punct cosmetic diffs).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p300–305 (run wa273i4qi; §99–100 Budan-Fourier / Newton's rule; verified by eye + zoom)
**~12 APPLIED + restored 2 dropped sign tables, p305 clean** (15 agents, 519k tok). Dense (computation §§).
- **p303 systematic `λ`→`𝔷`** (×3: prose + 2 eqs) — the root-count is Fraktur 𝔷 (z for Zahl; zoom-confirmed; .tex had Greek λ). μ (multiplicity) correctly kept.
- **p301–302 RESTORED 2 dropped sign tables** (Budan-Fourier case analysis: '1. μ gerade' + '2. μ ungerade', each with a)/b) sub-cases and δ_1/δ_2 sign-rows) — the .tex had collapsed both into a prose paraphrase. Reconstructed from both scan pages (all +/− entries legible) + restored the 'Es geht also' conclusion.
- **p304** eq (4) `F_0=F_n=1`→`F_0=F=1` (the .tex's F_n=1 contradicted F_n=f_n² on the same line); eq (6) badly garbled → `f_ν F_ν'(x)=(n-ν-1)(F_ν f_{ν+1}+F_{ν+1}f_{ν-1})`; removed over-expansion clause 'bis auf positive Zahlenfactoren…Form.'.
- **p300** `unverändert`→`ungeändert` (Weber's word); **p301** `f^{(ν+μ)}(ξ)`→`(x)`; **p302** `Reihe`→`Reihen`.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p306–311 (run w1x9p9vuc; §101–102 Newton/Descartes/Jacobi criteria; verified by eye + zoom)
**9 APPLIED, 0 rejected, p307/308 clean** (15 agents, 513k tok).
- **p309** eq (4) restored dropped top row of the Doppelreihe (`a_0,…,a_n` over `A_0,…,A_n`; wrapped in gathered).
- **p311** sign sequence `+,-,+`→`-,+,-` (inverted); `D=A_1A_2-B²`→`3D=…` (dropped 3); eq (2) restored dropped 1st formula `y=(x-α)/(β-x)`; footnote removed over-inserted `Jacobi,`; connective `In der Reihe`→`und in der Reihe`.
- **p306** restored dropped 'lassen aber…nur zwei Fälle' enumeration-caveat clause + `Functionen f_ν`→`Functionen, etwa f_ν,`.
- **p310** `aller reellen Wurzeln`→`aller reeller Wurzeln` (don't-modernize: print's strong genitive `-er`).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p312–317 (run wwhxovth2; §103 Klein / §104 Laguerre; verified by eye + zoom)
**4 APPLIED, 0 rejected, p314/315 clean** (10 agents, 346k tok).
- **p312** §103 heading restored dropped author 'Klein's' (→ 'Klein's geometrische Vergleichung der verschiedenen Kriterien').
- **p313** restored dropped xref note 'Fig. 16 (a. f. S.)' (auf folgender Seite).
- **p316** Laguerre function list `f_0…f_n(x)`→`f_0…f_{n-1}(x)` (the §4 associated functions are f_0..f_{n-1}; f(x)=f_n(x) separate; confirmed by the p317 definition block).
- **p317** `in \S\,4`→`im \S\,4` (Weber's 'im §', dropped m).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p318–323 (run w5die8q32; §106–107 Rolle/Laguerre; verified by eye + math)
**~10 APPLIED, p318/319/321/322 clean** (15 agents, 479k tok).
- **§107 (p323) systematic `\sum`→`S`** (Weber's sum-over-roots operator; print + prose 'das Summenzeichen S' confirm; eqs 1–4,7 all S) — agent had only converted some.
- **p323 eq (3)** removed spurious `n` (numerator `f'(x)²-H(x)`, consistent w/ eq (2)); **eq (4)** fixed + removed a PHANTOM 'in der sinngemässen…' block; **eq (5/6)** numbered the `rx'=dx-by` system as (6); **restored dropped display `r²H(x,y)=H'(x',y')` + 'Hiernach'**; **eq (7)** S form + restored dropped factor `(cx'+dy')²` + retag (6→7).
- **p320** `Ausdrucks`→`Ausdruckes` (dropped genitive -e; Weber uses -es 4×); `c-fache Wurzel u.s.f.`→`c-fache etc.\ Wurzel`; Theorem XIV `f(x)=0`→`f(x)` (XIII has =0, XIV doesn't).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p324–329 (run wn24os3y8; §107 Laguerre cont.; verified by eye + math)
**18 APPLIED, 0 clean** (24 agents, 736k tok). Dense §107 continuation.
- **systematic `\sum`→`S`** (Weber's operator, §107): eq (8), the P display, p327 power-sums `S(α²),S(α),S(α²)/S(α),S[α(α-ξ')]` (agent had left several as \sum).
- **systematic `Ω`→`Φ`** (the form Φ=(Xy-Yx)²P-(Xη-Yξ)²): eq (9) + 3 prose — .tex used Ω throughout §107; later genuine Ω (continued fractions §116+, Körper §137) left intact (scoped to §107 line range).
- **eq (8)** restored dropped factor `(xη-ξy)²` on H (parallel to eq (7)); **squared term** `((Xη-Yξ)/(Xy-Yx))²=((ξβ-ηα)/(xβ-yα))²` (.tex dropped both ²); **restored dropped display `P=S(…)²`**.
- prose: `und (X_1,X_2)`, `Frage: wie ist…`, `und man erhält`, double-`aber`→single, `beiden anderen abhängt. Die`, `Quadratwurzel…haben kann` (singular), `(mit Laguerre)` restored.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p330–335 (run wb061zdbo; §108–109 numerical/Newton approximation; verified by eye + math)
**2 APPLIED, 1 type-B erratum, p330–333/335 clean** (8 agents, 295k tok). Mostly clean.
- **p334** worked-example table header `\Delta_x,\Delta'_x`→`\Delta_\alpha,\Delta'_\alpha` (print uses α-subscripts, per eqs (6)–(8)).
- ⚠️ **WEBER ERRATUM (type-B, restored to print):** p334 `u'` printed as `0,0164` but Weber's own sum `α+u+u'=1,76937` (α=1,7, u=0,06773) requires `0,00164`. The .tex had silently 'corrected' it to `0,00164`; per discipline I REVERTED to the printed `0,0164` + flagged (printed digit is a Weber arithmetic typo; consistent value 0,00164). [cf. Q_0 erratum p221.]
Compiles **360 pp / 0 err**.

### 2026-06-25 — p336–341 (run w5b2kbewo; §109–110 approximation/Bernoulli; verified by eye)
**2 APPLIED, 0 rejected, p337–339/341 clean** (8 agents, 271k tok). Mostly clean.
- **p336** `Näherungsmethode anwenden`→`Näherungsmethoden` (plural; print shows -en).
- **p340** restored dropped/paraphrased prose: `dem Intervall (α,β) angehörige Intervall, worin f(ξ)`→`Werthpaar in dem Intervall (α,β), wofür f(ξ)` (dropped 'Werthpaar', paraphrase).
Compiles **360 pp / 0 err**. (typeB: p336 eq tagged '(3)' duplicates an earlier (3) — printed-page numbering quirk, .tex faithfully reproduces it.)

### 2026-06-25 — p342–347 (run wzi38i6co; §110–111 Bernoulli/Gräffe; verified by eye + zoom)
**3 APPLIED, 0 rejected, p342/343/345/346 clean** (9 agents, 319k tok).
- **p344** rewritten eq (6): running index `α_n φ(α_n)`→`α_m φ(α_m)` on the last numerator AND denominator terms (kept inner `p-α_n`).
- **p347** `die vierte und achte Potenzen`→`die vierten und achten` (plural -en).
- **typeB (no change — Weber-corrected):** p347 print `(2x²-1)²` is a typo Weber fixed in his Berichtigungen; the .tex correctly has `(2x²+1)²`.
**BERICHTIGUNGEN reference:** the .tex carries Weber's published errata (line 20867–20872), only 2 entries: p182 (`X_m` not `X_n`) and p347 (`(2x²+1)²`). → confirms my p334 u'-revert (NOT in errata ⇒ uncorrected typo, transcribe + flag) and the batch-14 p182 x_m decision.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p348–353 (run woj8yjuii; §111–112 Gräffe / trig. cubic; verified by eye + math)
**4 APPLIED, 0 rejected, p349/353 clean** (12 agents, 398k tok).
- **p348** Gräffe-squared coeff array: pos 2 `4a_0²`→`4a_1²`, pos 4 `6a_2²-12a_3a_1`→`6a_3²-12a_2a_4` (confirmed by print + the array's mirror symmetry; pos 3 `6a_2²-12a_1a_3` was already correct).
- **p352** `λ=g^m/e^{m+n}`→`g^n`; `keine positive Wurzeln`→`Wurzel` (singular).
- **SKIPPED (cosmetic, value-equal):** p350/p351 eqs (5),(8) `\tg^3\varphi` vs print `tg φ³` — both = (tanφ)³; kept the .tex's unambiguous `tg³φ` (field-norm; `\tg\varphi^3` reads as tan(φ³) to a modern eye).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p354–359 (run wgawfchk9; §112–115 trig cubic → number theory; verified by eye + zoom)
**6 APPLIED, 1 type-B erratum, p355/358/359 clean** (11 agents, 410k tok).
- **p354** `a^m c^m`→`a^n c^m` (middle term of the λ chain); **p356** `λ=g^m/e^{n+m}`→`g^n` (recurring g-exponent error, cf. p352); **p356** `Decimale`→`Decimalen`.
- **p353+p357 `Briggs'schen`→`Brigg'schen`** (×2, don't-modernize: Weber consistently writes 'Brigg'sche'; the .tex modernized the name).
- ⚠️ **WEBER ERRATUM #3 (type-B, restored to print):** p357 'Nähe der Werthe 30°40'' — printed 30° is a typo for 33° (inconsistent w/ the computed θ=33°40' + bracket 33°41'/33°42'; NOT in Berichtigungen). The .tex had silently corrected to 33°40'; reverted to printed 30° + flag (zoom-confirmed). The genuine 33°40' (computed value, line 13168) kept.
- typeB (no change): p355 print 'odre' (trivial typesetting typo for 'oder'); .tex's 'oder' kept.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p360–365 (run w0a0kv2u4; §116–117 continued fractions; verified by eye + zoom)
**7 APPLIED, 0 rejected, p360/362/364/365 clean** (13 agents, 425k tok).
- **p361** §116 heading `Kettenbruchentwicklung`→`Kettenbruchentwickelung` (-elung; .tex body uses -elung); eq (8) final index `a_ν`→`a_r` (×2 lines; continued-fraction terminal index is r, not the running ν).
- **p363** `an. Wir können`→`an, und wir können`; `wobei`→`wo`; `die Gleichheit Q_{n-1}=Q_n`→`mit der oberen Grenze Q_n` (.tex rephrased the parallel construction).
- **don't-modernize:** `Q_n\to\infty\;(n\to\infty)`→`Q_n=\infty\;\text{für }n=\infty` (the .tex modernized Weber's '=∞ für n=∞' to limit-arrow notation).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p366–371 (run wte5nvrjp; §118–119 indeterminate eqns / modular equivalence; verified by eye)
**6 APPLIED, 0 rejected, p366/369/370 clean** (10 agents, 316k tok).
- **p367** `Da hier n=11`→`und da hier n=11`. **p368** `m=α_1x+δx_1`→`m=α_1x_1+δx` (subscripts swapped); solution block `x_1=x, x_2=x_1y_2, x_3=x_1y_3`→`x_1, x_2=xy_2, x_3=xy_3` (first term x_1 alone, multiplier plain x).
- **p371 DROPPED FOOTNOTE restored:** Dedekind, *Schreiben an Herrn Borchardt … elliptischen Modulfunctionen*, Crelle Bd. 83 (1877) — citation footnote after 'äquivalent', grep-confirmed absent from .tex.
- **don't-modernize (agent mis-classified as cosmetic):** p368/p370 `gibt`→`giebt` (×2). ⚠️ **SYSTEMATIC: .tex has ~18 more 'gibt' in later/unaudited sections (14256+, 17335+, …20688 which even mixes giebt/gibt on one line) — GLOBAL `\bgibt\b`→`giebt` sweep DEFERRED to end-of-vol1.**
Compiles **360 pp / 0 err**.

### 2026-06-25 — p372–377 (run w1k1heeek; §119–121 modular substitutions / CF-equivalence; verified by eye across the page-break)
**3 edits (4 candidates), 0 rejected, p372/375/377 clean** (10 agents, 332k tok).
- **p373/374 DROPPED matrix display + connective restored (page-break block, reconstructed from BOTH pages):** print runs M=(…), M'=(…) → 'Es ist dann auch' → **M M'⁻¹=(α,β;γ,δ)** → 'eine lineare Substitution, und' → (m,μ;n,ν)=(α,β;γ,δ)(m',μ';n',ν') → **'woraus folgt:'** → m=αm'+βn'. The .tex had dropped the M M'⁻¹ display + 'woraus folgt:' and mis-slotted the surviving display. Added the M=/M'= labels too (load-bearing — referenced in M M'⁻¹).
- **p376** prose `die Zahl der nicht übereinstimmenden`→`die Zahl der den übereinstimmenden` (nicht→den; 'den' is dative = the Theilnenner PRECEDING the agreeing ones; the .tex's 'nicht' inverted the meaning).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p378–383 (run wrvlraqan; §122–123 reduced quadratic irrationals; verified by eye + heavy zoom)
**11 APPLIED (2 type-B errata), p380/381 clean** (17 agents, 549k tok — densest batch yet).
- **p379** eq (14) `-c=-a_1γ²+…`→`-c=a_1γ²+…` (spurious minus; matches the +a_1/+2a_1 leading pattern of rows a,b; agent numeric-inversion confirmed).
- **p382** case labels Latin `a)/b)`→Greek `α)/β)` (×3: display + 'Im Falle α)' + 'Im Falle β)'; the §123 γ-cases are Greek, distinct from the Latin figure/exception cases a)/b) on the same page — the .tex conflated them); prose `nicht kleiner als`→`mindestens gleich`; reorder `entweder α=0, δ=0…`→`entweder: δ=0,…ξ_1=-ξ, α=0, das ist der Ausnahmefall b)`.
- **p383** `gibt`→`giebt` ×3 (14260/14278/14284 — 3 of the queued sweep, now in-batch).
- ⚠️ **WEBER ERRATUM #4 (type-B, p382):** β-case 'nach (14)' formula printed `(ξ±δ)²⋚1` — DROPS the `+η²` that eq (14) `(γξ+δ)²+γ²η²⋚1` carries (γ²=1) and that the parallel δ=±1 sub-case `(ξ±1)²+η²⋚1` keeps. Reverted the draft's silent re-correction `(ξ+δ)²+η²` → printed `(ξ±δ)²` (also +→± type-A) + flag.
- ⚠️ **WEBER ERRATUM #5 (type-B, p378):** eq (11) inverse printed `ω=(δω_1-β)/(-γω_1+α_1)` — the `α_1` is a typo for plain `α` (matrix inverse of [[α,β],[γ,δ]]; no α_1 exists here). Draft had silently corrected to `α`; reverted to printed `α_1` + flag (zoom-confirmed subscript).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p384–389 (run wvyx2j90c; §123–125 reduced forms / periodic CFs; verified by eye)
**4 APPLIED (1 type-B erratum), p386/389 clean** (10 agents, 365k tok).
- **p384** `so liegen die Bilder`→`so liegen also die Bilder`. **p387** `…wieder. Wenn die Periode`→`…wieder, also, wenn die Periode`. **p388** `Es genügt also,…bezeichnen:`→`und es genügt also,…bezeichnen, etwa so:` (dropped 'und'/'etwa so').
- ⚠️ **WEBER ERRATUM #6 (type-B, p385, §124):** the non-vanishing difference printed `ω'-ω=2y√d` (no minus) — but ω=x+y√d, ω'=x-y√d ⇒ ω'-ω=-2y√d, and the next clause 'wonach (4) zeigt, dass ω'_n negativ ist' REQUIRES the minus. Draft had silently signed it `-2y√d`; reverted to printed `2y√d` + flag.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p390–395 (run wqp463rr2; §125–126 periodic-CF worked examples D=29/116/37/136; verified by eye + math)
**9 APPLIED, 0 clean pages** (15 agents, 473k tok — worked-examples section garbled throughout).
- **p390** `Irrationalzahlen. Wenn`→`Irrationalzahlen, und wenn`; `gehören und also`→`gehören, und die also` (dropped 'die').
- **p391 GPT OVER-INSERTIONS:** `Daraus folgt also`→`Daraus also` (spurious 'folgt'); `von allen anderen reellen Zahlen`→`…anderen Zahlen` (spurious 'reellen'). Audit BOTH directions.
- **p392 DROPPED SENTENCE restored:** before 'Die grösste in √D…', the .tex dropped 'Wir bestimmen zunächst nach §. 125, 4. die sämmtlichen zu D gehörigen reducirten Zahlen.'; also `λ ist hier 5`→`=5` (dropped = sign).
- **p393** D=116 CF `\frac{5+√29}2=[10,2,1,1,2]`→`5+√29=[10,…]` (.tex wrongly added /2; {4,10,1}⇒ω=(10+√116)/2=5+√29, a_0=10 ✓; the D=29 CF (5+√29)/2=(5,5,5…) is separate + correct); restored dropped inline `[1,5,1]:` (D=37).
- **p394** `Die Kettenbruchperioden sind`→`und die Kettenbruchperioden`. **p395** `Mit Rücksicht auf`→`und also mit Rücksicht auf die Gleichung`.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p396–401 (run w2xlg9o6a; §126–129 Pell eqn / units / Gauss forms / CF root-approx; verified by eye + zoom)
**17 APPLIED, 0 clean pages** (23 agents, 721k tok — biggest batch; heavily garbled). **Page count 360→361** (restored dropped sentences/footnote legitimately grew the doc; 0 errors).
- **p396** `…ist. Aus`→`…ist; und aus`; `Nun folgt aus (6)`→`Nun folgt aber aus (6)`; `2c+b>√D, also`→`2c+b>√D [§. 125, (4)], also` (dropped xref); `so ist hiernach`→`so ist sie hiernach`.
- **p397** restored 2 dropped 'also der oberen/unteren Zeichen' clauses; restored a whole dropped sentence ('wo das Gleichheitszeichen…nur für n=1…ebenso wie in (12).'); `Somit ist also nach (10)`→`und es ist also nach (10)` (was agent-REJECTED on a bad-grep uniqueness fail — line 14849 had it; reinstated).
- **p398** `wachsen muss, und dass also`→`…muss, dass also` (over-inserted 'und').
- **p399** restored dropped clause 'Es ist also Θ_3 gleichfalls eine zu √D gehörige Einheit, und' + '(und folglich auch mehrerer)'.
- **p400** `liegen:`→`liegen, da diese Potenzen mit dem Exponenten ins Unendliche wachsen; also`; `Θ, gegen`→`Θ, was gegen`; `sein.`→`sein, was zu beweisen war.`; **restored dropped footnote** (Disq. ar. art. 183 ff., Dirichlet-Dedekind, Vorlesungen über Zahlentheorie. Vierte Auflage. §. 72 ff.).
- **p401 two-alphabet α→a** (×3, zoom-confirmed Latin a = CF partial quotients): `α_0 finden`, `x=α_0+1/x_1`, `α_1`; `je nachdem D…ist, und`→`(je nachdem D…ist) und`.
- typeB (NO change): p396 eq (8) + p398 examples print a doubled `==` (typesetting defect); .tex's single `=` kept (glyph glitch, not content).
Compiles **361 pp / 0 err**.

### 2026-06-25 — p402–407 (run w6tvxhpjy; §129–131 CF root-approx worked example / rational roots / Gauss-form factoring; verified by eye + math derivation)
**~34 APPLIED, 0 clean pages** (40 agents, 1.2M tok — LARGEST batch). 33 agent-accepted + rejected-reconstructed + §129 α→a unified.
- **p402 cubic CF chain (math-derived every row):** coeffs `3x³-x²-11x-1`→`-3x` (x=1+1/x₁ ⇒ 3x³-x²-3x-1), `9x³-22x²-11x-2`→`-14x`, `43x³`→`46x³`; restored dropped lead-in sentence (f₂ root), 4th CF group (a₀,a₁,a₂,a₃), CF terminal `,2,`; ⚠️ **WEBER ERRATUM #7 (type-B):** print SWAPS a₃/a₄ labels (a₄=1 on the 9x³ row whose root∈(2,3)⇒a₃=2; a₃=2 on the 46x³ row whose root∈(1,2)⇒a₄=1) — reproduced print's swap (the .tex had silently un-swapped them).
- **§129 α→a UNIFIED:** the .tex used Greek α for §129's CF partial quotients; print uses Latin a (matches batch 51 p401). Converted all §129 α→a (scoped — §130 φ/ψ coeffs α,β and §131 unknowns α,β,γ,δ,ε stay Greek).
- **p403/404** dropped Coefficienten clause; restored dropped ψ(x) display; `X`→`x_1` (substitution var); 3 dropped clauses.
- **p405** dropped sentence (Auswahl der erprobenden Zahlen), xref `(§. 50)`, footnote `etc.`, rewordings.
- **p406** congruences `γ`→`γ²`, `β≡±2,±1`→`±1,±2,±1`, `1+1`→`1∓1`; dropped clauses.
- **p407** `β≡-1(mod29)`→`2β≡-1(mod29)`; reconstructed the δ=-12 passage (rejected agent fix was incomplete — restored 'zur Folge hat, die aber nicht lösbar ist' + 'noch übrig'); `1. bis 5. sind befriedigt…verificiren ist`.
- typeB (NO change): doubled `==` print defect (kept clean `=`).
Compiles **361 pp / 0 err**.

### 2026-06-25 — p408–413 (run wazg1ukmi; §131–133 roots of unity / cyclotomy / φ(n) totient; verified by eye + zoom)
**15 APPLIED, p408/411 clean** (19 agents, 590k tok).
- **p409** `h,h'=h+μ`→`k,k'=k+μ` (symbol, matches eq (4)); `r^h=r^{h'}`→`r^k=r^{k+μ}`; `r^{k'}=r^{k+hn}=r^k(r^n)^h`→`r^{k'}=r^k r^{hn}` (.tex inserted a spurious middle member).
- **p410** dropped 'ist' (`oder n durch μ theilbar`); `r^μ=r^{mx+ny}=(r^m)^x(r^n)^y`→`r^μ=r^{mx} r^{ny}` (spurious member); `r^n=(r^μ)^h r^{μ'}`→`r^n=r^{hμ} r^{μ'}` (compact form per print).
- **p412 §133 x→π SYSTEMATIC:** the .tex used Latin x for the prime-power exponents (n=p^x p_1^{x_1}…); print uses Greek π. Converted ALL §133 exponents x→π (more than the agent flagged — incl. 15304's p^{π-1} chain, 15306, 15308); also `q`→`ϱ` (varrho, root of unity); restored 'd. h. also,' connective.
- **p413** restored dropped product symbol `Π`.
Compiles **361 pp / 0 err**.

### 2026-06-25 — p414–419 (run wl6o7t14i; §133–135 cyclotomic polynomials X_n / irreducibility; verified by eye + zoom)
**16 APPLIED, 0 clean pages** (22 agents, 667k tok).
- **SYMBOL SWAPS (.tex swapped n↔μ between sections):** p414 §133 `f_μ`→`f_{n_1}`, `für μ`→`für n_1` (Weber's index here is n_1); p417 §134 `n_1,n_2`→`μ_1,μ_2` (Weber's auxiliary divisor-products are μ).
- **p419 §135 Θ→Φ SYSTEMATIC (×9):** the .tex used Θ(x) for Weber's product function Φ(x)=φ(x)φ(x²)… (capital Φ, distinct from lowercase φ factor). Converted all §135 Θ→Φ (scoped — the §127 unit Θ stays). zoom-confirmed.
- **p416** `n=p^π q^χ`→`n=pp'qq'` (Weber's recursive notation, consistent w/ eq (9) pp'/p').
- **p415** restored dropped sentence 'worin sich das Productzeichen Π auf alle Theiler μ von n bezieht.'; **p418** restored dropped parenthetical '(da wir anderenfalls durch das Product der beiden Coefficienten dividiren würden)'.
Compiles **361 pp / 0 err**.

### 2026-06-25 — p420–425 (run w2gk96itc; §135–136 Kronecker irreducibility / DISCRIMINANT / quadratic Gauss sum; verified by eye + zoom + DERIVATION)
**14 APPLIED, 0 clean pages** (20 agents, 613k tok — most math-delicate yet). **NO new erratum** (agent's suspected typeB was a misdiagnosis).
- **GAUSS-SUM EXPONENT (n-1)/2 vs (n-1)²/4 — DERIVED, agent typeB REJECTED:** .tex had `(-1)^{(n-1)^2/4}` (∏R sign, p423) and `(-i)^{(n-1)^2/4}` (eq 14, p424); print has `(n-1)/2` in both. Agent flagged (n-1)/2 as a Weber typo (pair count is (n-1)²/4). BUT: for the SIGN (-1)^m=(-1)^{m²} (m≡m² mod 2) so (n-1)/2 is a VALID equivalent — NOT a typo; for eq (14) (-i) has order 4 so (-i)^{(n-1)/2}≠(-i)^{(n-1)²/4} → the .tex was WRONG. Both fixed to printed (n-1)/2 (type-A); print correct, NO erratum. (pair-count (n-1)²/4 at 15636 stays.)
- **p423** eq (12) `R=(r^μ-r^ν)(…)`→`(r^ν-r^μ)(…)` (1st-factor sign, non-commutative); eq (10) `n^{(n-2)/2}√{(-1)^{(n-1)/2}}`→`n^{(n-3)/2}√{(-1)^{(n-1)/2}·n}`; restored dropped `[r^ν-r^μ, ν<μ]` display; `n=1(mod4)`→`n≡1`,`n≡-1(mod4)`; `nach §.46`→`(§.46)`.
- **p422** restored dropped Π + clause + display after eq (6); restored dropped eq `∏(x-r)=∏(r-x)=X_n` + 'also' + (§.133).
- **p424** restored 2 dropped product-display RHS (`=r^{±(n²-1)/8}`).
- **p420** footnote `Kronecker, …$x^n-1$,`→`…$(x^n-1)$.` (drop name—it's in the body; add parens, period). **p421** `transcendente`→`transcendenter`. **p425** `enthält`→`erhält`.
Compiles **361 pp / 0 err**.

### 2026-06-25 — p426–431 (run wof92qfrs; §136–137 Fermat's theorem / primitive congruence-roots; verified by eye + zoom)
**12 APPLIED (1 type-B erratum #8), p428/431 clean** (18 agents, 570k tok).
- **§136 Fermat a→α SYSTEMATIC (×5):** the .tex used Latin a for Weber's base α in α^n≡α (eq 6,7 + 'für jede ganze Zahl α' + 'α=0,α=1' + '(α+1)^n≡α^n+1'). Converted all (incl. the agent-rejected line — same systematic).
- **p426** `a_0x+a_1`→`a_0x+a`; root `x≡-a_0'a_1`→`α≡-aa_0'`; eq (3) cleared-denom→fraction `(f(x)-f(α))/(x-α)=f_1(x)`.
- ⚠️ **WEBER ERRATUM #8 (type-B, p426):** m=1 base case prints `a_0a_0'≡1 (mod m)` — but m=1 ⇒ mod 1 trivial; should be mod n. Zoom-confirmed 'm'. Draft had silently 'corrected' to mod n; reverted to printed mod m + flag.
- **p429** `ay≡1-bx`→`y≡(1-bx)/a` (fraction form); `γ=γ^{ay+bx}`→`γ≡γ^{bx}γ^{ay}` (= → ≡, product).
- **p430 §137** `p^x…φ(p^x)…Grade p^x, p^{x-1}=p_1`→`pp_1…φ(pp_1)…p^π, p^{π-1}=p_1` (Weber pp_1 notation + x→π); `g^h`→`g^m`.
Compiles **361 pp / 0 err**.

### 2026-06-25 — p432–437 (run w82nzlwfx; §137 index / Theilung des Winkels / trig multiplication; verified by eye)
**2 APPLIED, p433/434/436/437 clean** (8 agents, 288k tok — section mostly clean).
- **p432** eq (21) `ind 1=0`→`ind 1≡0` (= → ≡ congruence, matches parallel 'ind(-1)≡(n-1)/2 (mod n-1)').
- **p435** eq (10) restored dropped range bound `0≦v≦(n+1)/2`.
Compiles **361 pp / 0 err**.

### 2026-06-25 — p438–443 (run w29kz28l6; §137–138 cyclotomy → quadratic reciprocity / Legendre symbol; verified by eye)
**6 APPLIED, p439/442 clean; §138 numbering #7–9 HELD** (15 agents, 470k tok).
- **p438** eq (27)/(28)/(29) `ω`→`α` (root variable) + product upper-index `∏^α` (eq 28,29).
- **p440** `cos(-ρ)=cosρ`→`cos(-φ)=cosφ` (Weber's generic-angle identity uses φ, not the local ρ); restored dropped clause 'wie sich aus der folgenden Zusammenstellung ergiebt, worin k eine nicht negative ganze Zahl bedeutet'.
- **p441** `die genaue Formel`→`die genaue Formel (1):`.
- ⏸ **HELD §138 numbering (#7/#8/#9):** print numbers the Legendre-symbol results flush-left 1.–9. ('8.' multiplicativity, '9.' reciprocity), but the .tex re-laid them as enumerate + eq-tags incl. primed/out-of-order (9', 10) and 'diese Formel' for '8.'. Cross-refs ('bleibt 8.', 'aus (4) und (9)') don't resolve. Systematic re-layout (cf §69) — needs a coherent §138-numbering rework (p441–443), NOT piecemeal. **NEW STANDING ITEM.**
Compiles **361 pp / 0 err**.

### 2026-06-25 — p444–449 (run ws01x0ag2; §138 end → BUCH III §139 Galois theory / Körperbegriff; verified by eye)
**3 APPLIED, p445/446/447/448 clean; §138 numbering #1/#2 HELD** (11 agents, 367k tok).
- **p449 §139** restored 3 dropped items in the Zahlkörper-definition paragraph: '(die vier Species)' after Rechenoperationen; the Dedekind citation '(Dirichlet-Dedekind, Vorlesungen über Zahlentheorie, 2. Aufl. 1871, §. 159)'; '(corpus, corps)' after Körper + sentence-final verb restored ('…zukommt, bedeutet.').
- ⏸ **p444 §138 numbering HELD (#1/#2):** `\tag{10'}`→`10`, `\tag{7'}`→`7` — same primed-numbering re-layout held in batch 58; folded into the §138-numbering rework.
- **Transition:** §138 (quadratic reciprocity) ends; **Drittes Buch: Algebraische Grössen / Dreizehnter Abschnitt: Die Galois'sche Theorie / §139 Der Körperbegriff** begins (p449).
Compiles **361 pp / 0 err**.

### 2026-06-25 — p450–455 (run wxqs8k1yo; §139–142 Galois foundations: Körper/Adjunction/Functionen in Ω; verified by eye)
**16 APPLIED, 0 clean pages; §141 reducibility-paraphrase HELD** (26 agents, 851k tok — heavily smoothed prose). **Page 361→362** (restored footnote + dropped paragraphs grew the doc; 0 errors).
- **p450** restored dropped footnote (Galois'schen Gleichungstheorie, Math. Ann. Bd 43); dropped clause '(da alle ganzen Zahlen durch Addition und Subtraction von Einern entstehen)'; '(rationalen und irrationalen)'.
- **p451** 'die Constanten'→'die constanten Coefficienten…etwa auf den der rationalen Zahlen' + restored dropped sentence 'Wir wollen hier nicht weiter die Beispiele häufen…'; 'enthält u. s. f.'; 'Körper Ω''' (dropped symbol).
- **p452** Fraktur `𝔠`→`𝔍` ×2 (complex field; print Fraktur J w/ descender, zoom-confirmed); §141 prose: restored `a_0,a_1…a_m`, dropped Δ(a) clause, §.40 cross-ref.
- **p453** restored 2 dropped paragraphs ('Sind die a nicht unabhängige…' + 'Wir können also…sprechen') before 'Wenn nun Ω…'.
- **p454** Satz I-III dropped clauses: 'der uns in der Folge…Dienste leisten wird'; '(d.h. eine in Ω enthaltene Grösse)'+'also'; proof-tail 'also müsste f'(x) durch f(x) theilbar…niedriger ist'; 'd.h. alle Coefficienten von F(x) müssen Null sein'; Variablen 'x,y,z…'.
- **p455 §142** restored '„über" Ω oder auch, wenn Zweifel…kurz, einen algebraischen Körper'.
- ⏸ **HELD §141 reducibility-section paraphrase (p453–455):** def (16461–63: 'Man spricht bisweilen…im Körper Ω', dropped 'Präcisirung'), three-way-distinction + x²-y²/x²-2y²/x²+y²+1 EXAMPLES (agent #15/#18 OVERLAP across p454→455), §51-reference ('Bei jenen Ausführungen…wegfällt'), 'linearer Factor x-α', 'aus allen Zahlen'. Pervasive paraphrase ⇒ coherent §141 rework. **3rd STANDING ITEM.**
Compiles **362 pp / 0 err**.

### 2026-06-25 — p456–461 (run wioa94pvs; §142–144 Galois: algebraic körper / primitive-element theorem / primitive & imprimitive Körper; verified by eye)
**26 APPLIED (25 prose-restorations + §143 full title), 0 clean pages** (32 agents, 945k tok). 362pp held.
- **Galois prose pervasively paraphrased** by the draft; restored ~25 dropped clauses/sentences + rewordings to Weber's exact wording, all individual + non-overlapping (verified page-by-page on scans). E.g. p456 'und bleiben also…Ω(α) stehen', 'weil…x=α nicht die Wurzel von zwei verschiedenen irreducibeln Gleichungen'; p458 the full Satz-1 induction proof + 'mit anderen Worten…Ω(α)'; p459 'nicht nur eine, sondern…deren Zahl gleich dem Grade'; p460 §142-Festsetzung xref, 'Es kann sein, dass diese Körper…wovon später Näheres'; p461 'n Grössen, eine aus jedem der conjugirten Körper', 'nach dem Theorem II, §.141'.
- **§143 section title** restored to Weber's full heading 'Gleichzeitige Adjunction mehrerer algebraischer Grössen' (the .tex had used the running-header abbreviation 'Mehrfache Adjunction').
- agent-rejected #459 ('nicht nur eine, sondern…') was a real fix (uniqueness-fail on a stale anchor) — reinstated.
- typeB (NO change): p457 §142-conclusion edition-divergence (.tex numbered Theorem 1 + proof vs print's inline c_0..c_{n-1} + eq (6)) — flagged.
### 2026-06-25 — p462–467 (run wc8sx00lk; §144–146 Galois: primitive/imprimitive Körper, Normalkörper, Galois'sche Resolvente; verified by eye)
**22 APPLIED (21 agent prose-restorations + 1 self-caught drop), 1 page HELD (p466)** (27 agents, 876k tok). 362→**363 pp** (growth from restored prose).
- §144–145 prose pervasively paraphrased; restored individual non-overlapping clauses/sentences/displays, all scan-verified. E.g. p462 the φ(Θ)=0 display + 'd. h. Φ(t) ist irreducibel' + 'jeder andere irreducibele Factor…Potenz von φ(t)' + §143,1-Satz ref + 'sogar so, dass die Coefficienten…rationale Zahlen sind'; p463 'deren Coefficienten Zahlen in Ω', 'worin Φ′(Θ) von Null verschieden ist', dropped 'Denn jede Zahl des Körpers Ω(Θ)…' paragraph, 'Aus dieser Definition…Wir wollen jetzt…imprimitiven Körper kennen lernen'; p464 the full Ω(β,γ)-induction (rebuilt across the p463→464 break, subsuming both agents' overlapping #11/#12), 'Wir können unsere Definition auch so fassen', 'In den Normalkörpern herrschen viel einfachere Gesetze…Galois verdankt'; p465 'dass nämlich…durch jede beliebige rational ausdrückbar ist', 'von der wir nur voraussetzen wollen', 'Ist Ω(α) ein Normalkörper, so ist er mit seiner Norm identisch'; p467 'd. h. N ist ein Normalkörper. w. z. b. w.', the 3-part formal Galois-resolvente definition.
- **self-caught miss**: agent (and its p466 verifier) missed the .tex drops 'Denn nach 2) ist N in Ω(ρ) enthalten…folglich ist N=Ω(ρ).' (p467_mid) — restored.
- **corrected an agent paraphrase**: p464 reconstruction's connector → print's 'und nach dem, was wir vorhin bewiesen haben' (agent wrote 'Wie wir bewiesen haben').
- **HELD p466** (Normalkörper/Galois-resolvent construction, .tex ~16784–16797): WHOLESALE paraphrase — eq (6) arrangements + Π(m) count dropped, eq (7) explicit forms collapsed to bare ρ,ρ′,ρ″, the Gesammtheit-invariance paragraph condensed to one sentence, the G(t)=∏(t−ρ) symmetric-function argument condensed. 7 typeB; needs coherent re-transcription (like §141). NOTE: the p466 verifier wrongly called the 'Nun haben G(t)…' conclusion 'added prose' — it is on p467 (proof spans the break), so #20 was applied.
### 2026-06-25 — p468–473 (run wggn01ych; §146–148 Galois: substitutions of a normal field / composition / permutation groups; verified by eye + zoom)
**~40 fixes (32 agent + δ→σ whole-section conversion + ~6 self-caught), 0 clean pages** (42 agents, 1.27M tok — biggest batch yet). 363pp held.
- **δ→σ WHOLE-SECTION symbol conversion** (§146–147, lines 16807–16979, 71 occurrences): the GPT draft systematically misread Weber's substitution symbol σ as δ. Confirmed by my own zoom-crop (p469 'Substitution σ_a ausführen') + multiple independent agent crops. The agents flagged only ~12 of the ~71 δ's, and one agent rightly REJECTED isolated δ→σ fixes as consistency-breaking — so a scoped Python range-replace was the right tool, not piecemeal. δ is genuine nowhere in §146–147 (all substitutions); scope ends at §148 (Permutationsgruppen → π).
- §146 prose: restored §141-II xref, the g[Θ_k(ρ)]=0 / g[Θ_k(ρ_h)]=0 displays, 'Uebereinstimmung halber…Θ_0(ρ)' + 'Also sind…verschieden. Wir können dies als Satz zusammenfassen', the ρ_k=Θ_hΘ_a(ρ)=Θ_k(ρ) chain, the ω=ψ(ρ_h) display, 'Man kann aber bei gegebenem σ_a…Also:'.
- §147 prose: the full 'Da wir…das erste oder das zweite Element beliebig wählen können…Wir haben daher:' paragraph; 'sogenannte associative Gesetz, das sich in folgendem Satz ausspricht'; the σσ'σ''σ'''… display; §146,3 xrefs. **Removed spurious draft artifact `\subsection*{Schluss von §147}`** (not in Weber). Restored 'Eigenschaften 1., 2., 3.' + Gesammtheit (was modernized to Gesamtheit).
- §148 (p473): corrected eq (6) perm bottom row (.tex had wrong 'b_iπ_a', print 'a_{b_i}'), removed spurious '=m!' from Π(m)=1·2·3⋯m (not in print), restored the Zusammensetzung-of-permutations sentences.
- **self-caught (agent missed)**: the 'd. h.'-placement + spurious 'also' in the commutative-law sentence (an agent had REJECTED a botched version — I did it right); the two intermediate-product members (σσ')σ''=(ρ,ρ_b)(ρ_b,ρ_c)=… and σ(σ'σ'')=(ρ,ρ_a)(ρ_a,ρ_c)=… that the .tex compressed (crop-confirmed); 'diesen Uebergang'; 'die jedes Element an seiner Stelle lässt'.
- HELD (for §148 coherent rework next batch when p474+ available): finer §148-intro equivalent-paraphrases ('Spalten vertauschen' vs 'die einzelnen Paare anders anordnen'; 'geschrieben werden' vs 'was mit (5) völlig gleichbedeutend ist').
### 2026-06-25 — p474–479 (run wgv8yr40s; §148–149 Galois: permutation groups / Galois'sche Gruppe; verified by eye)
**0 applied — §148–149 HELD as a major wholesale GPT-rewrite** (15 agents, 510k tok; agent emitted 8 'surgical' fixes + 6 typeB, all inside a rewritten frame). 363pp unchanged.
- **§148–149 (p474–479) is a pervasive GPT paraphrase/rewrite of Weber's two sections**, NOT a transcription — too entangled to patch piecemeal (it combines ALL prior hold-classes at once: §138-style item-renumbering + §141-style paraphrase + p466-style whole-unit drops + symbol-subs + MODERNIZATION). Held for coherent re-transcription. Spec for that pass:
  · §148 (p474–475): prose reworded throughout; the two untagged inverse-verification matrices π_aπ_a⁻¹=(0..m-1/0..m-1) & π_a⁻¹π_a=(a_0..a_{m-1}/a_0..a_{m-1}) DROPPED (p474_bot); eq (8) third member =π_aπ_bπ_c dropped; the π_c⁻¹=π_b⁻¹π_a⁻¹ sentence + 'π_0 ist sich selbst entgegengesetzt' clause dropped (p475_top); print's flush-left items 1.,2.,3. folded into prose (.tex keeps only the '3.' enumerate) = §138-class; Permutationsgruppe DEFINITION reworded; Q={π_0..π_{q-1}} renotated (print Q=π,π',π''…); closing 'Was zwischen diesen beiden extremen Fällen…folgenden Abschnitten beschäftigen' dropped (added non-Weber 'symmetrische Gruppe').
  · p476: the entire cyklische-Gruppe example + its 3 matrices DROPPED; the Abel'sche-Gruppen + Theiler/theilbar paragraph DROPPED.
  · §149 (p476–479): GPT REWRITE — modern term 'isomorph' + meta-comment 'durch Umformulierung der Sätze des §146'; δ→σ (substitution symbol, continuing the §146-147 sub) + θ→Φ (primitive-element function); eqs (1)(2) use θ(...) parens where print has Φ[...] brackets; Sätze a)–d) reformulated; the d)-proof paraphrased, dropping displays (5)(6)(7), the g'(t) product, the §146,2 xref, the 'Hierauf können wir…gehört zur Galois'schen Gruppe' passage.
- HELD-ITEM TALLY: §69, §138-numbering, §141, p466, **§148–149**.
Compiles **363 pp / 0 err** (nothing applied).

### 2026-06-25 — p480–485 (run wbl1rm3k1; §149-tail / §150 / §151-start Galois; verified by eye + zoom)
**§150 RE-TRANSCRIBED + 9th Weber erratum; p480–481 §149-tail HELD; p483–485 agent-clean** (10 agents, 358k tok). 363→**364 pp** (§150 expansion).
- **§150 (Transitive und intransitive Gruppen, p481–482) re-transcribed**: the .tex had condensed Weber's ~1.5-page §150 to ~24 lines — paraphrased opening ('erhält man ein einfaches Kennzeichen für Reducibilität' vs Weber 'können wir ein sehr einfaches Kennzeichen dafür herleiten, ob die Gleichung F(x)=0 reducibel oder irreducibel ist'); condensed reducibility proof (dropped the f(α')=0 display, the §149,a) ref, 'Es werden also…nur unter einander permutirt', the '=f(x)' + §149,b) ref); WRONG transitiv-def (.tex 'für je zwei Elemente' vs Weber 'wenigstens eine Permutation…ein beliebiges Element in ein beliebiges anderes'); DROPPED closing paragraph (transitiv verbunden / Systeme der Intransitivität). All restored to Weber. (Unlike §148–149 = held: §150 is short + agent-isolated → direct re-transcription right.)
- **9th Weber erratum (p482 Satz 1)**: Weber prints 'reducibel oder irreducibel, je nachdem ihre Galois'sche Gruppe **transitiv oder intransitiv** ist' = reducible↔transitive, CONTRADICTING his own same-page proof (reducible⟺intransitive; standard irreducible⟺transitive). GPT draft silently corrected to 'intransitiv oder transitiv'; reverted to Weber's printed wording + flagged (crop-confirmed). [Errata: Q_0 p221, u' p334, 30° p357, +η² p382, α_1 p378, ω'-ω p385, a_3/a_4 p402, mod m p426, **transitiv/intransitiv p482**.]
- §149-tail (p480–481) HELD (part of §148–149 hold). ADD TO §149 SPEC: dropped Galois-biography footnote at §149 end (p481, on '…muss folglich mit G(t) übereinstimmen ¹)' — Évariste Galois bio: Duell 1832, 1830 Férussac Bulletin note, Brief an Auguste Chevalier (Revue encyclopédique Sept 1832), Liouville 1846 Bd XI, Maser 1889 German ed., Serret/Betti/Jordan/Netto).
- p483–485 agent-clean (§151 Primitive und imprimitive Gruppen start).
- **PROCESS BUG**: first batch-65 run returned 6 false-clean pages in 53s — launched without rendering p480–485 (batch 64 was a HOLD → no compile → render skipped); agents bailed on missing scans. FIX/LESSON: render the next batch EVERY batch, incl. holds; an anomalously fast all-clean batch ⇒ suspect missing scans.
### 2026-06-25 — p486–491 (run wcdlw97gk; §151 / §152 Galois: permutation groups, functions of independent variables; verified by eye + zoom)
**§152 FULLY RE-TRANSCRIBED (incl. replacing GPT-fabricated content); §151 & p491 clean** (9 agents, 322k tok). 364→**365 pp**.
- §151 (p486–487) clean (Primitive und imprimitive Gruppen).
- **§152 (Wirkung der Permutationsgruppen auf Functionen von unabhängigen Veränderlichen, p488–490) fully re-transcribed**:
  · Opening (p488): restored 'Für ein tieferes Eindringen in die Algebra…Grundlage bilden' + the dropped Cauchy/Jordan/Netto footnote (Journal de l'École polytechn. 1815; Jordan, Traité 1870; Netto, Substitutionentheorie 1882); 'von einander unabhängiger Zeichen (Veränderliche)'; 'ganze rationale Function von ihnen…ψ'.
  · Body p489: re-transcribed the ψ=ψ_π proof (permutations leaving ψ fixed form a group) — the .tex had condensed it (dropped §44-ref, 'andere extreme Fall', the ψ_{π'}=ψ_{ππ'} chain).
  · Body p490: the .tex here was GPT-**FABRICATED** (a ρ/Φ 'zu P gehörig / Φ(t)=(t-ρ)…' passage matching NO Weber §152/§153 content). Replaced with Weber's actual p490 §152: items 2 (P_1=Pπ_1 ≅ P, via §148,2/3), 3 (group⊇identity), 4 (group⊇inverse), + the m=3 example.
- **m=3 example glyph**: print reads '2α_2 = c + α_1' but the stated invariance (only identity + 3-cycle (0,1,2/1,2,0) leave α_1−α_2 fixed) requires 2α_2 = α_0 + α_1; 'between the three roots α,α_1,α_2' rules out an external constant ⇒ transcribed as α (α_0); 'c' = alpha degraded at 500dpi (possible minor erratum, noted not counted).
- p491 clean (§153 start).
- **NEW LESSON: the GPT draft can FABRICATE content** (not just paraphrase/drop) — §152's ρ/Φ body was invented. Always READ the scan to see what Weber actually says before trusting/patching a rewritten section. And: a 'rewrite' section IS re-transcribable when each page's scan content is clear + self-contained (§152, §150); HOLD only when multi-page + entangled (§148-149).
### 2026-06-25 — p492–497 (run wf5zz76cd; §153 Galois: Zerlegung von Permutationen in Transpositionen und in Cyklen; verified by eye)
**0 applied — §153 HELD as a major 6-page wholesale rewrite (incl. fabrication)** (12 agents, 419k tok). 365pp.
- **§153 (p492–497) is a 6-page GPT rewrite/condensation/fabrication** of Weber's permutation-decomposition theory (transpositions, cycles, even/odd, alternating group); the .tex §153 (~85 lines for 6 Weber pages) covers the topics but is not source-faithful. Held for coherent re-transcription. Spec:
  · p492 opening: paraphrased — restore 'Wir haben schon im zweiten Abschnitt…Transpositionen…Nebeneinanderstellen…(0,1)…' + 'Eine Transposition, zweimal wiederholt, führt zur Identität…'.
  · p493: cyclic-permutation definition FABRICATED — the .tex inserted foreign '(a,b,c)(d,e)(f) / disjoint cycles commute' content; Weber's actual text = cyclic-def matrix (0,1,2…/1,2,3…0) + compact (0,1,2…m-1) notation + 'Dabei ist es gleichgültig…' + numbered Satz 3 (unique disjoint-cycle decomposition). Theorems 1 ('auf unendlich viele verschiedene Arten') & 2 (group with all (0,k) = symmetric + 'nach 1. …zusammensetzen') reworded/dropped.
  · p494: Weber's worked example (π_1,π_2,π_3 explicit two-row matrices) + eqs (1),(2),(3) of the cycle-construction algorithm ENTIRELY DROPPED.
  · p495 (running head 'Permutationen erster und zweiter Art'): the τπ cycle-count two-case derivation (case 1 γ=(1,2…a,a+1…b),τ=(1,a); case 2 γ,γ'; parity paragraph 'Wir haben damit den Satz') REWRITTEN to 2 sentences + μ≡m−ν (mod 2).
  · p496: dropped the identische/Einheitsgruppe definition.
  · p497: statements 6,7,8 + four worked cycle-composition proofs ((1,0,2)=…,(0,2,3)=…,(1,3,4)=…,(2,3,4)=…) DROPPED/condensed.
- **2nd in-section fabrication** (after §152 p490): the GPT draft invents plausible math (disjoint-cycle examples) not in Weber. The agent's 6 clean 'surgical fixes' (defs/theorems at p492/493/496) NOT applied — would leave a half-faithful section around the held proofs/examples.
- HELD-ITEM TALLY: §69, §138-numbering, §141, p466, §148–149, **§153**.
Compiles **365 pp / 0 err** (nothing applied).

### 2026-06-25 — p498–503 (run w79k00pmc; §153-tail / §154 Galois: Divisoren, Nebengruppen, conjugirte Gruppen; verified by eye)
**§154 opening PATCHED (7 fixes); §153-tail & §154-body HELD** (14 agents, 475k tok). 365pp.
- §153-tail (p498–500) folds into the §153 HOLD (now spans p492–500): p499 Satz 10 ('transitive Gruppe von n Ziffern mit dreigliedrigem Cyklus → alternirende oder imprimitiv') + proof wholesale-dropped (.tex one-liner, 'm Ziffern'); p500 the π² even/odd-n cyclic-square formulas dropped (agent #1, not applied → §153 spec).
- **§154 opening (p501) PATCHED (7 fixes)**: 'ausgeglichen oder wenigstens'; 'jetzt…irgend…gegebenen…von einander verschiedenen'; α_2 restored in Ω(ρ)=Ω(α,α_1,α_2…); '(nach §.146,149)…oder auch…verstehen'; 'wir wollen die Operationen von P (seien es nun Substitutionen von N oder Permutationen der α) mit…bezeichnen'; Theiler/Divisor def 'wenn also je zwei…wieder ein Element aus Q ergeben…die Gruppe Q' + footnote 'Auch Untergruppe genannt.'
- **§154 body (p502–503) HELD** (reworded/condensed rewrite): .tex renumbers items 1–7 + eqs ((6)→(10) drops (7)(8)(9)), uses χ for Weber's ϰ (varkappa), DROPS the coset-distinctness proof, the Nebengruppe definition, the two-cosets-disjoint proof, **Cauchy's Fundamentalsatz** attribution+statement, the 'specieller Fall' (element order | group order), and condenses the conjugate-group treatment. Re-transcribe with Weber's ϰ + numbering.
- **'isomorph' RED HERRING corrected**: Weber himself prints 'isomorphe' (p501) — NOT a GPT-modernization marker; the §149 'isomorph' flag was wrong (the §149 hold stands on its other grounds). LESSON: verify a suspected 'modern term' against a clean Weber page before treating it as a tell.
- **render-bug recurred (2nd time, as batch 65)**: §153 hold → no compile → I skipped rendering p498–503 → agents bailed → 6 false-clean pages in 58s; re-ran after rendering. HARD RULE: render next batch as a standalone step EVERY turn.
- HELD-ITEM TALLY: §69, §138-numbering, §141, p466, §148–149, §153(p492–500), **§154-body(p502–503)**.
### 2026-06-25 — p504–509 (run wpj6f97ng; §154-body / §155 Galois: Reduction der Resolvente, Lagrange-Galois; verified by eye)
**0 applied — §154-body & §155 HELD (both wholesale rewrites)** (12 agents, 439k tok). 365pp.
- §154-body HOLD extended to p502–507 (p504-506 conjugate-groups: varkappa→χ, dropped the π_1⁻¹Qπ_1-isomorph derivation + the 'gleichberechtigte Untergruppe' footnote + the transformation-rule proof; p507 item-7 transitive-group coset proof condensed [agent #1 folds in]).
- **§155 (Reduction der Galois'schen Resolvente durch Adjunction. Normaltheiler, p507–509) HELD** — pervasive rewrite/renumber: dropped opening 'allmähliche Reduction…durch Adjunction' paragraph + 'wie im vorigen Paragraphen'; theorem 1 condensed + its irreducibility proof (Φ(t), refs §154,5 / §149,b) dropped; **Lagrange footnote** (Réflexions sur la résolution…Berlin 1770/71, Oeuvres III; 'allgemeine Formulirung rührt von Galois her') dropped; the ω=χ(ψ)/φ'(ψ) derivation (eq 5) + 'Grössenreihen (3),(4)' paragraph dropped/paraphrased; eqs renumbered; the printed eq (6) g(t)=g(t,ψ)g(t,ψ_1)… is MISPLACED into the .tex's §157 (~line 17868) — cross-section content-shuffle. Agent #2–#6 fold into this spec.
- CONFIRMS: the whole §148–§157+ Galois-applications region is a uniform GPT rewrite/renumber/shuffle → held section-by-section for one coherent re-transcription pass.
- HELD-ITEM TALLY: §69, §138-numbering, §141, p466, §148–149, §153(p492–500), §154(p502–507), **§155(p507–509)**.
### 2026-06-25 — p510–515 (run w23msqvxa; §155-tail / §156 / §157 Galois; verified by eye + crop)
**1 applied (§157, p514); §156 HELD; §155 hold extended** (11 agents, 396k tok). 365pp.
- §155 hold extended to p510–511: dropped Normaltheiler footnote (Galois 'décomposition propre' → 'eigentliche/ausgezeichnete/invariante Untergruppen'), the §155 closing (Normaltheiler/einfache-Gruppe defs, item 5), the Ω''=Ω(ψ,ψ_1…) display, the 'Von besonderem Interesse…Normalkörper' conclusion.
- **§156 (Die Gruppe der Resolventen, p511–513) HELD** (condensation/paraphrase): Total/Partial-resolvente defs paraphrased (agent p512 ×3 restore the N=Ω(ψ,ψ_1…ψ_{j-1}) display + 'Normaltheiler von P' + §155/Satz4 refs); §156 opening (Hülfsgleichung→Resolvente, §155,2 ref, 'N mit Ω(ψ) identisch') paraphrased; §156 tail DROPPED 3 full paragraphs (rejected fix p513 — real but mid-sentence anchor).
- **MAJOR BOUNDARY: §157 (Aufgabe der Auflösung…, p513–515) RESUMES FAITHFUL transcription** — p514 is verbatim-faithful; only 1 fix: Θ_1→Θ_i subscript misread ('auch Θ_i(ρ_2)=ρ_3'), crop-confirmed (context ρ_i=Θ_i(ρ), g_1[Θ_i(t),ε]=0). **So the GPT-rewrite block is §148–§156; §157+ is patchable-faithful.** (Re-checks batch-69's 'eq(6) misplaced into §157' — §157 legitimately contains it; was agent confusion.)
- HELD-ITEM TALLY: §69, §138-numbering, §141, p466, §148–149, §153(p492–500), §154(p502–507), §155(p507–511), **§156(p511–513)**. [§148–156 = the GPT-rewrite block.]
### 2026-06-25 — p516–521 (run wmvlyv99v; §157-tail / §158 Imprimitive Gruppen; verified by eye + crop)
**1 applied (§158 title); §158 body HELD** (12 agents, 436k tok). 365pp.
- §157 tail (p516-top) faithful (Kronecker / natürliche Irrationalitäten) — confirms §157 faithful.
- **§158 (Imprimitive Gruppen, p516–520) HELD** (wholesale rewrite): TITLE fixed (.tex 'Reduction imprimitiver Gleichungen' → Weber 'Imprimitive Gruppen', crop-confirmed p516). Body held — opening paraphrased ('Wir machen von unseren allgemeinen Sätzen…§151…n=r·s…s Reihen von je r Gliedern'); eq (1) array δ→σ + missing tag; dropped eqs (2)-(6) (f(x)=∏f(x,y); ψ,ψ_1…; (ψ,ψ_i); Q,Qπ_i; Partialresolvente χ(u)=0); dropped the s-1 permutations + (α)/(β) matrices + ϰ_β=π_β⁻¹ϰπ_β proof + §151/§154,7 refs; dropped the transitive-group↔intransitive-Normaltheiler inversion proof (p520); Ω(y)→Ω(ψ) (p520).
- so the rewrite ALTERNATES section-by-section: §157 faithful, §158 rewritten — NOT a clean §148-156 boundary; must audit each §. Held block now §148–156 + §158.
- HELD-ITEM TALLY: §69, §138-numbering, §141, p466, §148–149, §153, §154, §155, §156, **§158**.
### 2026-06-25 — p522–527 (run w9yte0sww; §159 Cubische Gleichungen / §160 Permutationsgruppen von vier Elementen; verified by eye)
**13 fixes APPLIED (patched, not held); 0 typeB** (19 agents, 638k tok). 365→**366 pp**.
- §159–160 are condensed WORKED-EXAMPLE sections (like §144-147 / cyclotomy): the .tex dropped intermediate equations/derivations/cycle-tables but kept Weber's structure → surgically patchable (0 typeB). Applied:
  · §159 (cubic): eq (6) 2α_1/2α_2=a-α±√D/f'(α) + α_1±α_2 relations + 'Denn ausser sich selbst…Typus (1,2)' (p523); v³=α³+α_1³+α_2³+6αα_1α_2+3εA+3ε²A' (p524); vv'=α²+…−α_1α_2 expansion; [§.47,(8)] xref + a=α+α_1+α_2 display; 'also in dem Körper Ω' enthalten sind…' clause; eq (7) trailing ';'.
  · §160 (4-element groups): '(vgl. den Schluss von §.149)' + 24-perm phrasing; Transpositionspaare def '(0,1)(2,3)'; the alternating-group 'keine einzelne Transposition…' sentence; 'alle vorhandenen Theiler…(§.154,6.)' passage; the dreigliedriger-Cyklus proof table ((0,1,2)²=(0,2,1)…(0,3,2)²=(0,2,3)) + (0,1)(0,2)=(0,1,2) (p526); the (0,2)(0,1,2,3)=(0,3)(1,2)… verification table; P_1-conjugate-groups paragraph; P_2 second-cyklus paragraph (p527). All cycle-products derivation-checked.
- prose-paraphrase elsewhere (25 cosmetic notes) left as meaning-preserved (consistent w/ §144-147 worked-example policy).
- so §157, §159, §160 are patchable-faithful; the rewrite-block is §148–156 + §158.
Compiles **366 pp / 0 err**.

NOTE: these 4 were found by the agent workflow and independently matched my by-hand audit. The same
run also produced HALLUCINATED fixes on phantom no-scan pages (args bug, now fixed) — proof the agent
output must never be applied unverified. Every line above was confirmed by eye before applying.
