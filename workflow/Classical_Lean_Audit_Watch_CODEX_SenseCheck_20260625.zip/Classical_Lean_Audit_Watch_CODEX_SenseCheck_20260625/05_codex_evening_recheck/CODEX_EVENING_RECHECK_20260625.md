# Codex Evening Recheck — Classical Lean Watch

Date: 2026-06-25 Europe/Berlin.
Model/session disclosure for private workflow log: ChatGPT Codex 5.5 Extra High Effort Mode.

This is a watch/audit packet, not a DOI-ready proof corpus. It records small Lean formalization experiments attached to the classical-transcription project. It must not be described as author/work-level verification.

## Result

| File | Status | Build / axiom note |
|---|---|---|
| `AffineGroup.lean` | GREEN | Direct build exit 0. `ClassicalAudit.Jordan.card_aff` depends only on ordinary Mathlib axioms: `propext`, `Classical.choice`, `Quot.sound`. |
| `Steinitz.lean` | GREEN | Direct build exit 0. `ClassicalAudit.Steinitz.perfectRing_iff_frobenius_surjective` depends only on ordinary Mathlib axioms: `propext`, `Classical.choice`, `Quot.sound`. |
| `Weber.lean` | GREEN | Direct build exit 0. `ClassicalAudit.Weber.weber_cubic_roots` depends only on ordinary Mathlib axioms: `propext`, `Classical.choice`, `Quot.sound`. |
| `ClassicalBatch2.lean` | FAILED / QUARANTINE | Direct build exit 1. It includes a failed old Steinitz API attempt and prints `sorryAx`; do not promote this file. |
| `SplitZero.lean` | GREEN BUT SEPARATE | Direct build exit 0, but this belongs to a separate side-paper lane rather than the historical transcription/translation archive unless explicitly promoted separately. |

## Interpretation

`AffineGroup.lean`, `Steinitz.lean`, and `Weber.lean` rebuild directly under the local Lake/Mathlib project. The green status means only that the Lean snippets compile and their selected printed axioms are ordinary Mathlib/classical axioms. It does not mean the scanned source text, TeX transcription, or whole historical paper has been verified in Lean.

`ClassicalBatch2.lean` remains failed/sorry-tainted provenance and must stay out of any promoted module tree.

## Publication Rule

Keep this in the workflow/watch lane. Before any DOI/public proof claim, require a clean Lake module tree with no failed promoted files, `#print axioms` logs for every theorem, exact Lean/Mathlib toolchain metadata, source anchors into the transcribed TeX/public catalog, and a theorem map distinguishing historical source statement, normalized mathematical restatement, Lean theorem, and build status.
