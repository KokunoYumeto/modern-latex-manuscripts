# Codex Sense Check: Classical Lean Audit Watch, 2026-06-25

This is a local audit / web-review handoff package, not a DOI-ready formal proof corpus.

## Located material

- Original Claude watch folder: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Classical_Lean_Audit_Watch_20260625`
- Original ZIP: `C:\Users\Floris\Documents\Codex\2026-06-01\we-are-currently-doing-a-massive\Classical_Lean_Audit_Watch_20260625.zip`
- Original ZIP SHA256: `B4F633ED317B0DDFF910D1CDE8D1C3C6130D2257EC30CD97889A5B083A9F1DE0`
- Build root used for independent recheck: `C:\Users\Floris\Downloads\helix_extract\helix_frobenius-master`

## Independent recheck result

Codex re-ran `lake env lean` in the build root against the relevant files.

- `AffineGroup.lean`: exit 0. `#print axioms ClassicalAudit.Jordan.card_aff` reports ordinary Mathlib axioms only: `propext`, `Classical.choice`, `Quot.sound`.
- `Steinitz.lean`: exit 0. `#print axioms ClassicalAudit.Steinitz.perfectRing_iff_frobenius_surjective` reports ordinary Mathlib axioms only: `propext`, `Classical.choice`, `Quot.sound`.
- `Weber.lean`: exit 0. `#print axioms ClassicalAudit.Weber.weber_cubic_roots` reports ordinary Mathlib axioms only: `propext`, `Classical.choice`, `Quot.sound`.
- `ClassicalBatch2.lean`: exit 1. It contains a failed/old Steinitz API attempt and `sorryAx` in the axiom output. Treat as failed provenance only.
- `SplitZero.lean`: exit 0 in the independent recheck, but this is a separate side-paper lane rather than a transcription/translation deliverable, and the package does not include a `#print axioms` audit for it.

Full command output is in `CODEX_INDEPENDENT_RECHECK_20260625.txt`.

## Audit judgement

This is a credible seed for a formalization lane, not a publishable Lean corpus yet.

The strongest current content is three tiny green Lean files:

1. Jordan affine line group cardinality over `ZMod p`.
2. Steinitz perfect-ring / Frobenius-surjectivity bridge.
3. Weber cubic abstract polynomial identity.

The current risk is not Lean compilation for those three files; it is source positioning. A DOI/public claim would need to say exactly how each Lean theorem corresponds to the transcribed source theorem and whether it is a direct classical statement, a modern restatement, or a Mathlib bridge lemma inspired by the source.

## Requirements before DOI or public proof claim

- Clean project root with `lakefile`, `lean-toolchain`, `lake-manifest.json`, and all green modules in a coherent `ClassicalAudit/` namespace.
- No failed files in the public green module tree. Failed files such as `ClassicalBatch2.lean` may remain only under `failed_provenance/` with explicit warnings.
- `#print axioms` logs for every promoted theorem, including SplitZero if it is ever included.
- No `sorry`, no `admit`, no `sorryAx` in any promoted module/log.
- Source anchors to the actual public transcription corpus, not loose local folders. Use the GitHub public catalog, source TeX, and published source packets as the authority.
- A human-readable theorem map: source statement -> normalized mathematical statement -> Lean theorem name -> build/axiom status.
- Clear separation between the translation/transcription project and side-paper/original-math formalizations such as SplitZero.

## Suggested web/pro review task

Review the three green Lean theorems for source alignment, not for syntax. For each theorem, decide:

- Does this correspond to a theorem/claim actually present in the transcribed source corpus?
- Is it a direct formalization, a simplified/abstract restatement, or merely a related modern bridge lemma?
- What exact source file/page/section should be cited?
- Should it be promoted into a public Lean DOI later, kept as workflow evidence, or discarded as too weak/indirect?

Do not publish as a proof DOI until the source-alignment map exists.
