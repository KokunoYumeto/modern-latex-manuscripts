# SGA6 find -> verify -> fix audit harness

**Manuscript:** SGA 6 — *Théorie des intersections et théorème de Riemann–Roch* (Séminaire de Géométrie Algébrique du Bois Marie 1966–67, LNM 225; Berthelot, Grothendieck, Illusie, with Ferrand, Jouanolou, Jussila, Kleiman, Raynaud, Serre).

**Generated:** 2026-06-24
**Verdict:** **GO.** A mature, source-faithful French cumulative LaTeX edition already exists and is a sound basis to audit. Do NOT use the raw Kimi drops as the basis.

---

## Verdict in one line

Audit the existing **cumulative French `sga6_fr.tex`** (already through ~100 repair rounds, compiles to ~357 pp), with the **original scan `OS\sga6.pdf`** as ground truth. The Kimi drops are LOW QUALITY OCR and are used as *locator only*, never as the basis.

---

## Best transcription (the audit basis)

```
C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\SGA6_repair033_codex_display_labels_20260621\1\SGA6\cumulative\fr\sga6_fr.tex
```

- 18,882 lines, 1.23 MB, dated 2026-06-22 — the **newest and largest** cumulative FR source on disk.
- Quality: **real, high-grade source-faithful LaTeX.** Proper `\section*{Exposé ...}` structure, real theorem environments, correct internal SGA/EGA cross-references in Bourbaki style (`(I 2.2)`, `(I 4.16)`, `EGA III 6.9.8`), accented French prose, coherent mathematics. This is a reconstructed critical edition, not OCR sludge.
- Provenance: end of a long repair chain (repair001 → repair108). The package's audit policy already matches the SGA5 standard: *"ocr_used_as: locator_only; accepted_repairs_require_visual_source_check; minimum_source_check_dpi 650; dense_math/diagram 1000 dpi."*
- An English baseline exists in the same package (`cumulative/en/sga6_en_unsynced_baseline_repair108.tex`) but the **source-faithful audit lane is the FRENCH** source, as with SGA5.

### Why NOT the alternatives
- **Kimi drops** `Kimi\Kimi drop continued from batches 2 through 4\sga6\sga6_pages_*.tex` (001–702): per-50-page standalone `article` documents, raw OCR. The user's warning holds — usable only as a page locator, never as the basis.
- **Codex_Downloads** `sga_1_4_modern_typeset_sources` / `SGA_CLEAR_1_4`: these are **SGA 1–4 only** (arXiv re-editions of SGA1/2, Polo–Gille SGA3, Laszlo–Orgogozo SGA4). **No modern typeset SGA6 exists** — there is no public re-edition of SGA6. The cumulative FR tex above is the project's own reconstruction and is the best that exists.

---

## Source PDF and printed-page → PDF-page offset

**Source scan:** `C:\Users\Floris\Documents\Papors\OS\sga6.pdf` — **702 PDF pages.**

The offset is **NOT a single constant** (unlike SGA5's clean `printed = pdf − 12`). This particular scan drops a handful of pages in the back third, so the offset **shrinks from +7 to +2**. Use the piecewise table below (all anchors visually verified from rendered footers):

| printed | pdf | offset (pdf − printed) |
|--------:|----:|:----------------------:|
|   1     |   8 | +7 |
| 400     | 407 | +7 |
| 466     | 473 | +7  (end-to-end verified: footer reads "466") |
| 550     | 557 | +7 |
| 560     | 567 | +7 |
| 581     | 587 | +6 |
| 604     | 607 | +3 |
| 616     | 619 | +3 |
| 667     | 670 | +3 |
| 696     | 698 | +2 |

- **Exact `printed = pdf − 7` holds through printed page ~560.** That covers Exposés 0–XII fully and most of XIII.
- **For printed ≥ 561 the computed PDF page can be off by ±1** (the drift happens inside the late Exposés). The chunk script interpolates and prints its guess; **always confirm the printed number in the rendered footer**, or render by exact PDF page with `--pdf`.
- PDF page 8 = the first body page (Exposé 0, "Esquisse d'un programme", printed "1"). PDF pages 1–7 are the title page + introduction + table of contents (front matter).

---

## Page count and scope

- **Audit range: printed pages 1–696** (696 entries in the manifest). The body runs Exposé 0 through Exposé XIV; the index closes around printed p.699 (PDF ~701). Exposé XI was "Non rédigé" (never written).
- Exposé → printed-start map (from the volume's own table of contents):
  0 →1, App. RRR →20, I →56, II →160, III →190, IV →222, V →297, VI →365, VII →416, VIII →466, IX →498, X →519, XII →595, XIII →616, XIV →667.

---

## Files in this harness

```
_sga6_audit\
  HARNESS_README.md        <- this file
  audit_manifest.json      <- 696 page entries: {printed_page, pdf_page, pdf_offset, offset_confident,
                              tex_file, expose, tex_line_hint [start,end], kimi_locator_tex}
  _work\
    chunk_page.py          <- render a PRINTED page as overlapping 600-dpi chunks (piecewise offset baked in)
    src\                   <- chunk output lands here
```

### chunk_page.py usage
```
python chunk_page.py 466                 # printed p466 as top/mid/bot chunks
python chunk_page.py 466 --full --verify # whole page + a footer strip to read the printed number
python chunk_page.py 466 --chunks 4      # 4 chunks
python chunk_page.py --pdf 473           # render an exact PDF page (bypass the offset, for the drifted back region)
```
Renders at 600 dpi, downsampled to ≤2400 px wide (native scan ≈2176 px). Do NOT mass-render — render per page on demand during the find→verify→fix loop.

---

## KEY CAVEAT (read before trusting any chunk)

1. **Offset drifts in the back third.** Exactly +7 through printed ~560 (verified end-to-end at p466). Above 561 it can be ±1 — **always eyeball the printed number in the rendered footer** before mapping a finding to a tex line. The chunk script prints its printed→pdf guess; the `--verify` flag dumps the footer.
2. **The Kimi drops are NOT the basis.** They are OCR, low quality, locator only. The basis is the cumulative `sga6_fr.tex`.
3. **`tex_line_hint` is an Exposé-level span, not a per-page line.** The cumulative tex has no internal page anchors, so the manifest brackets each page to its Exposé's tex line range; locate the exact passage by content match within that span (the Kimi locator file in each entry helps narrow the OCR text).
4. **SGA6 is not yet globally page-by-page certified.** Prior repair notes flag Exposé XIII source pages ≥637 for wider compression review and a Theorem 1.11 continuation micro-audit. Treat the cumulative tex as a strong but not-final baseline.
