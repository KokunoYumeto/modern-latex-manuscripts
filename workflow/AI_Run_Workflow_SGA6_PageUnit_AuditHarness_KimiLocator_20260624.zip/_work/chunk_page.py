"""Render a PRINTED SGA6 page as overlapping high-dpi chunks for the find->verify->fix audit.

Source = the complete SGA6 scan  C:\\Users\\Floris\\Documents\\Papors\\OS\\sga6.pdf  (702 PDF pages).
SGA6 ("Theorie des intersections et theoreme de Riemann-Roch", LNM 225, Bois Marie 1966-67).

IMPORTANT - the printed->PDF offset is NOT constant in this scan.
This scan drops a handful of pages in the back third, so the offset shrinks from +7 to +2.
The offset below is a PIECEWISE table anchored on visually verified footers (see HARNESS_README.md):

    printed   pdf    offset
        1       8      +7
      400     407      +7
      550     557      +7
      560     567      +7
      581     587      +6
      604     607      +3
      616     619      +3
      667     670      +3
      696     698      +2

Because of the drift, for printed pages >= 561 the computed PDF page can be off by 1.
The script renders the computed page AND its +-1 neighbours' footers are easy to eyeball;
when in doubt use  --pdf N  to render an exact PDF page directly, or  --verify  to print the
footer-number guess.  ALWAYS confirm the printed number in the rendered footer before trusting a chunk.

Usage:
  python chunk_page.py PRINTED [PRINTED ...]      # 3 chunks each (top/mid/bot), printed-page input
  python chunk_page.py PRINTED --chunks N         # N chunks
  python chunk_page.py PRINTED --full             # whole page, one image
  python chunk_page.py --pdf PDFPAGE [...]        # render by exact 1-based PDF page (bypass offset)
  python chunk_page.py PRINTED --verify           # also dump the bottom footer strip to read the printed number

Renders at 600 dpi then downsamples each chunk to <=2400px wide (native scan ~2176px, so near-native).
"""
import sys, os
import fitz
from PIL import Image

PDF = r"C:\Users\Floris\Documents\Papors\OS\sga6.pdf"
OUT = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Kimi\_sga6_audit\_work\src"
os.makedirs(OUT, exist_ok=True)

# (printed_page, pdf_page) anchors, visually verified from rendered footers. PDF page is 1-based.
ANCHORS = [
    (1, 8), (400, 407), (550, 557), (560, 567),
    (581, 587), (604, 607), (616, 619), (667, 670), (696, 698),
]

def printed_to_pdf(printed):
    """Piecewise-linear (really piecewise-constant-offset) printed->pdf 1-based page map."""
    # below first anchor: use first anchor's offset
    if printed <= ANCHORS[0][0]:
        off = ANCHORS[0][1] - ANCHORS[0][0]
        return printed + off
    # within / above: find bracketing anchors and interpolate the offset
    for i in range(len(ANCHORS) - 1):
        p0, q0 = ANCHORS[i]
        p1, q1 = ANCHORS[i + 1]
        if p0 <= printed <= p1:
            # linear interpolation of pdf page, rounded
            frac = (printed - p0) / (p1 - p0) if p1 != p0 else 0
            return int(round(q0 + frac * (q1 - q0)))
    # above last anchor: extend last segment's slope
    p0, q0 = ANCHORS[-2]
    p1, q1 = ANCHORS[-1]
    slope = (q1 - q0) / (p1 - p0)
    return int(round(q1 + (printed - p1) * slope))

def render(d, pdf_page_1based, label, nchunks=3, full=False, verify=False):
    pidx = pdf_page_1based - 1
    if pidx < 0 or pidx >= d.page_count:
        print(f"{label}: pdf page {pdf_page_1based} out of range (1..{d.page_count})"); return
    pg = d[pidx]
    pm = pg.get_pixmap(dpi=600, colorspace=fitz.csGRAY)
    full_im = Image.frombytes("L", (pm.width, pm.height), pm.samples)
    W, H = full_im.size
    if verify:
        crop = full_im.crop((0, int(H * 0.86), W, int(H * 0.94)))
        if crop.width > 1600: crop = crop.resize((1600, int(crop.height * 1600 / crop.width)), Image.LANCZOS)
        fp = os.path.join(OUT, f"{label}_footer.png"); crop.save(fp, optimize=True)
        print("FOOTER", fp)
    if full:
        im = full_im
        if im.width > 2400: im = im.resize((2400, int(im.height * 2400 / im.width)), Image.LANCZOS)
        fp = os.path.join(OUT, f"{label}_full.png"); im.save(fp, optimize=True)
        print(fp, im.size); return
    ov = int(H * 0.04)
    band = H // nchunks
    names = ["top", "mid", "bot"] if nchunks == 3 else [f"c{k+1}" for k in range(nchunks)]
    for k in range(nchunks):
        y0 = max(0, k * band - ov)
        y1 = min(H, (k + 1) * band + ov)
        ch = full_im.crop((0, y0, W, y1))
        if ch.width > 2400: ch = ch.resize((2400, int(ch.height * 2400 / ch.width)), Image.LANCZOS)
        nm = names[k] if k < len(names) else f"c{k+1}"
        fp = os.path.join(OUT, f"{label}_{nm}.png")
        ch.save(fp, optimize=True)
        print(fp, ch.size)

def main():
    args = sys.argv[1:]
    pages, nchunks, full, verify, pdf_mode = [], 3, False, False, False
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--chunks": nchunks = int(args[i + 1]); i += 2
        elif a == "--full": full = True; i += 1
        elif a == "--verify": verify = True; i += 1
        elif a == "--pdf": pdf_mode = True; i += 1
        else: pages.append(int(a)); i += 1
    d = fitz.open(PDF)
    for p in pages:
        if pdf_mode:
            render(d, p, f"pdf{p:03d}", nchunks, full, verify)
        else:
            pdfp = printed_to_pdf(p)
            print(f"# printed {p} -> pdf {pdfp} (confirm footer; >=561 may be +-1)")
            render(d, pdfp, f"p{p:03d}", nchunks, full, verify)

if __name__ == "__main__":
    main()
