#!/usr/bin/env python3
"""Publish a new version of the standalone workflow replication record."""

from __future__ import annotations

import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests


ROOT = Path(__file__).resolve().parents[1]
ZENODO = ROOT / "zenodo"
BASE_URL = os.environ.get("ZENODO_BASE_URL", "https://zenodo.org").rstrip("/")
TOKEN_LOCATION = Path(r"LOCAL_USER_HOME\.codex\.sandbox\sandbox.log")
TOKEN_LINE = 12459
SOURCE_RECORD_ID = 20476520
CONCEPT_DOI = "10.5281/zenodo.20461174"
PACKET_DIR = ROOT / "release_candidates" / "workflow_replication_packet_20260530"
UPLOAD_FILES = [
    PACKET_DIR / "Project Workflow and Replication Notes.pdf",
    PACKET_DIR / "Workflow Replication Packet - Scripts, Tooling Notes, and Manifests.zip",
]
REQUEST_TIMEOUT = (30, 300)
UPLOAD_TIMEOUT = (30, 900)
TRANSIENT_STATUSES = {429, 500, 502, 503, 504}


def timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def recover_token() -> str:
    token = os.environ.get("ZENODO_ACCESS_TOKEN")
    if token:
        return token
    line = ""
    with TOKEN_LOCATION.open("r", encoding="utf-8", errors="ignore") as handle:
        for i, candidate in enumerate(handle, start=1):
            if i == TOKEN_LINE:
                line = candidate
                break
    regexes = [
        re.compile(r"(?i)ZENODO_ACCESS_TOKEN\s*[:=]\s*['\"]?([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)\"?zenodo[_-]?access[_-]?token\"?\s*[:=]\s*['\"]?([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)https?://(?:sandbox\.)?zenodo\.org/api/[^\s'\"<>]*access_token=([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)zenodo[^\r\n]{0,180}access[_-]?token[^\r\n]{0,40}['\":=\s]+([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)zenodo[^\r\n]{0,180}bearer\s+([A-Za-z0-9._~\-]{20,})"),
    ]
    for regex in regexes:
        match = regex.search(line)
        if match:
            return match.group(1)
    raise RuntimeError("Could not recover Zenodo token from the validated local token location.")


class Client:
    def __init__(self, token: str):
        self.token = token

    def headers(self, content_type: str | None = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.token}"}
        if content_type:
            headers["Content-Type"] = content_type
        return headers

    def request(self, method: str, path_or_url: str, *, payload=None, expected=(200, 201, 202, 204)):
        url = path_or_url if path_or_url.startswith("http") else f"{BASE_URL}{path_or_url}"
        response = None
        last_error: Exception | None = None
        for attempt in range(1, 6):
            try:
                response = requests.request(
                    method,
                    url,
                    headers=self.headers("application/json") if payload is not None else self.headers(),
                    json=payload,
                    timeout=REQUEST_TIMEOUT,
                )
                if response.status_code not in TRANSIENT_STATUSES:
                    break
                last_error = RuntimeError(f"HTTP {response.status_code}: {response.text[:1000]}")
            except (requests.Timeout, requests.ConnectionError) as exc:
                response = None
                last_error = exc
            if attempt < 5:
                time.sleep(min(90, 8 * attempt))
        if response is None:
            raise RuntimeError(f"Request failed on {method} {url}: {last_error}")
        if response.status_code not in expected:
            raise RuntimeError(f"HTTP {response.status_code} on {method} {url}\n{response.text[:4000]}")
        if response.text:
            return response.json()
        return None

    def put_file(self, bucket: str, path: Path):
        url = f"{bucket.rstrip('/')}/{quote(path.name)}"
        response = None
        for attempt in range(1, 6):
            with path.open("rb") as handle:
                try:
                    response = requests.put(
                        url,
                        headers=self.headers("application/octet-stream"),
                        data=handle,
                        timeout=UPLOAD_TIMEOUT,
                    )
                except (requests.Timeout, requests.ConnectionError) as exc:
                    if attempt == 5:
                        raise RuntimeError(f"Network error while uploading {path.name}: {exc}") from exc
                    time.sleep(10 * attempt)
                    continue
            if response.status_code not in TRANSIENT_STATUSES or attempt == 5:
                break
            time.sleep(10 * attempt)
        if response.status_code >= 400:
            raise RuntimeError(f"HTTP {response.status_code} while uploading {path.name}\n{response.text[:4000]}")
        return response.json()


def write_log(stage: str, data) -> Path:
    ZENODO.mkdir(parents=True, exist_ok=True)
    path = ZENODO / f"workflow_replication_record_{stage}_{timestamp()}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def build_metadata() -> dict:
    today = datetime.now(timezone.utc).date().isoformat()
    metadata = {
        "title": "AI-Assisted Modern LaTeX Manuscript Workflow and Replication Packet",
        "upload_type": "dataset",
        "publication_date": today,
        "creators": [{"name": "Manuscript Typesetting Project", "affiliation": "Independent"}],
        "description": (
            "<p>This record contains a public, reusable workflow note and a sanitized replication packet for an "
            "AI-assisted pipeline that modernizes public-domain mathematical manuscripts into source-checkable "
            "LaTeX, reader PDFs, translations, and archival release packages.</p>"
            "<p>The packet documents the current practical workflow: scan acquisition and indexing, chunking, "
            "TeX transcription, compilation, visual/text auditing, translation passes, Zenodo publication, GitHub "
            "mirroring, preservation of provenance artifacts, and current OCR/math-OCR experiments. The 2026-05-31 "
            "refresh adds the concrete local document-tooling notes used for public workflow packets: Pandoc, "
            "LibreOffice/soffice, Python pdf2image, and Poppler-compatible PDF rendering checks.</p>"
            "<p>The workflow is model-agnostic. It records the observed role of web LLM sessions, Codex-style "
            "local automation, Kimi-style large agent swarms, Claude Code-style local repair agents, Python/PyMuPDF "
            "tooling, TeX engines, GitHub, and the Zenodo API. OCR tools are described as witnesses only; mathematical "
            "fidelity still requires compilation, visual audit, and source checking against scans.</p>"
        ),
        "access_right": "open",
        "license": "cc-zero",
        "keywords": [
            "LaTeX",
            "digital preservation",
            "history of mathematics",
            "manuscript transcription",
            "OCR",
            "math OCR",
            "Pandoc",
            "LibreOffice",
            "Zenodo",
            "GitHub",
            "workflow",
            "public domain mathematics",
        ],
        "version": "2026-05-31 workflow packet with document tooling, OCR/tooling notes, and current publication workflow",
        "related_identifiers": [
            {
                "identifier": "https://github.com/KokunoYumeto/modern-latex-manuscripts",
                "relation": "isSupplementedBy",
                "scheme": "url",
            },
            {
                "identifier": "https://zenodo.org/records/20393488",
                "relation": "isSupplementTo",
                "scheme": "url",
            },
        ],
        "notes": (
            "Companion workflow record for the Modern LaTeX Editions of Public-Domain Mathematics Manuscripts archive. "
            "No private local paths or personal maintainer names are intentionally included."
        ),
    }
    text = json.dumps(metadata, ensure_ascii=False)
    if re.search(r"project maintainer|C:\\\\Users|/Users/project maintainer", text, flags=re.IGNORECASE):
        raise RuntimeError("Local personal identifier remains in workflow metadata.")
    return metadata


def delete_named_files(client: Client, draft_id: int, names: set[str]) -> list[dict]:
    files = client.request("GET", f"/api/deposit/depositions/{draft_id}/files") or []
    deleted = []
    for item in files:
        if item.get("filename") not in names:
            continue
        client.request("DELETE", f"/api/deposit/depositions/{draft_id}/files/{item['id']}", expected=(200, 202, 204))
        deleted.append({"filename": item.get("filename"), "id": item.get("id"), "filesize": item.get("filesize")})
    return deleted


def main() -> int:
    for path in UPLOAD_FILES:
        if not path.exists():
            raise FileNotFoundError(path)
    client = Client(recover_token())
    metadata = build_metadata()
    new_version = client.request("POST", f"/api/deposit/depositions/{SOURCE_RECORD_ID}/actions/newversion")
    write_log("newversion", new_version)
    draft_id = int(new_version["id"])
    print(f"[workflow] draft {draft_id} from {SOURCE_RECORD_ID}", flush=True)
    updated = client.request("PUT", f"/api/deposit/depositions/{draft_id}", payload={"metadata": metadata})
    write_log("metadata", updated)
    names = {path.name for path in UPLOAD_FILES}
    deleted = delete_named_files(client, draft_id, names)
    draft = client.request("GET", f"/api/deposit/depositions/{draft_id}")
    bucket = draft["links"]["bucket"]
    uploaded = []
    for path in UPLOAD_FILES:
        print(f"[workflow] upload {path.name} ({path.stat().st_size:,} bytes)", flush=True)
        uploaded.append(client.put_file(bucket, path))
    write_log("upload", {"draft_id": draft_id, "deleted": deleted, "uploaded": uploaded})
    print(f"[workflow] publishing draft {draft_id}", flush=True)
    try:
        published = client.request("POST", f"/api/deposit/depositions/{draft_id}/actions/publish")
        write_log("publish", published)
    except RuntimeError as exc:
        if "HTTP 504" not in str(exc) and "HTTP 404" not in str(exc):
            raise
        write_log("publish_transient", {"warning": "Publish endpoint returned a transient-looking error; verifying state.", "error": str(exc)})
    live = client.request("GET", f"/api/deposit/depositions/{draft_id}")
    write_log("live_verify", live)
    result = {
        "draft_id": draft_id,
        "record_id": live.get("id", draft_id),
        "doi": live.get("doi"),
        "conceptdoi": live.get("conceptdoi", CONCEPT_DOI),
        "html": live.get("links", {}).get("record_html") or live.get("links", {}).get("html"),
        "files": [item.get("filename") for item in live.get("files", [])],
    }
    result_path = write_log("result", result)
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
    print(f"RESULT_LOG {result_path}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
