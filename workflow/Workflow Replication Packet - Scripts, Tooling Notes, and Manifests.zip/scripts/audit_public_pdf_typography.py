from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter
from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import median

import fitz


PROJECT_ROOT = Path(__file__).resolve().parents[1]
RELEASE = PROJECT_ROOT / "release_candidates"
REPORTS = PROJECT_ROOT / "reports"
PUBLIC_PDF_CACHE = REPORTS / "public_pdf_surface_cache"


DEFAULT_RECORDS = {
    # The main landing record is curated directly on Zenodo, so its release
    # candidate cache may retain files that have since been demoted. Reuse the
    # current public-surface cache populated by Audit-PublicPdfSurface.py.
    "main": PUBLIC_PDF_CACHE / "20456732",
    "sga": RELEASE / "zenodo_satellite_sga_working_translation_public_current" / "upload",
    "ega": RELEASE / "zenodo_satellite_ega_working_translation_public_current" / "upload",
    "weber": RELEASE / "zenodo_author_weber_current" / "upload",
    "noether": RELEASE / "zenodo_author_noether_current" / "upload",
    "riemann": RELEASE / "zenodo_author_riemann_current" / "upload",
    "non_eu": RELEASE / "zenodo_satellite_non_european_multilingual_current" / "upload",
    "chinese": RELEASE / "zenodo_non_european_corpus_pages_current" / "chinese" / "upload",
    "indian_sanskrit": RELEASE / "zenodo_non_european_corpus_pages_current" / "indian" / "upload",
    "islamic_arabic": RELEASE / "zenodo_non_european_corpus_pages_current" / "islamic_arabic" / "upload",
    "historical_references": RELEASE / "zenodo_non_european_corpus_pages_current" / "historical_references" / "upload",
    "deligne": RELEASE / "zenodo_satellite_deligne_papers_translations" / "upload",
    "classical": RELEASE / "zenodo_satellite_classical_algebra_arithmetic_modern_latex_current" / "upload",
    "author_cluster": RELEASE / "zenodo_satellite_author_cluster_public_current_clean_surface" / "upload",
    "gauss": RELEASE / "zenodo_author_gauss_current" / "upload",
}


REFERENCE_PATTERNS = (
    "reference pdf",
    "french reference",
    "french original",
    "source pdf",
    "scan",
    "original source",
    "numdam",
    "reference scan",
    "combined original and reference",
)


@dataclass
class PageTypography:
    page: int
    text_chars: int
    span_count: int
    weighted_median_size: float | None
    p10_size: float | None
    p90_size: float | None
    max_size: float | None
    page_width: float
    page_height: float
    text_left: float | None
    text_top: float | None
    text_right: float | None
    text_bottom: float | None
    left_margin: float | None
    top_margin: float | None
    right_margin: float | None
    bottom_margin: float | None
    dominant_fonts: str


@dataclass
class PdfTypography:
    record: str
    filename: str
    path: str
    bytes: int
    pages: int
    class_hint: str
    text_pages: int
    total_text_chars: int
    median_body_size: float | None
    p10_body_size: float | None
    p90_body_size: float | None
    page_median_min: float | None
    page_median_max: float | None
    page_median_range: float | None
    page_size_set: str
    likely_scan_or_reference: bool
    warnings: list[str]
    page_details: list[PageTypography]


def weighted_quantile(values: list[tuple[float, int]], q: float) -> float | None:
    if not values:
        return None
    values = sorted(values, key=lambda item: item[0])
    total = sum(weight for _, weight in values)
    if total <= 0:
        return None
    threshold = total * q
    running = 0
    for value, weight in values:
        running += weight
        if running >= threshold:
            return value
    return values[-1][0]


def rounded(value: float | None) -> float | None:
    if value is None or math.isnan(value):
        return None
    return round(float(value), 2)


def page_span_data(page: fitz.Page) -> PageTypography:
    data = page.get_text("dict")
    sizes: list[tuple[float, int]] = []
    fonts: Counter[str] = Counter()
    boxes: list[fitz.Rect] = []
    chars = 0
    span_count = 0
    for block in data.get("blocks", []):
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "")
                clean_len = len(text.strip())
                if clean_len == 0:
                    continue
                size = float(span.get("size", 0.0))
                if size <= 0:
                    continue
                font = str(span.get("font", ""))
                bbox = fitz.Rect(span.get("bbox", [0, 0, 0, 0]))
                sizes.append((size, clean_len))
                fonts[font] += clean_len
                boxes.append(bbox)
                chars += clean_len
                span_count += 1
    rect = page.rect
    if boxes:
        union = boxes[0]
        for box in boxes[1:]:
            union |= box
        left, top, right, bottom = union.x0, union.y0, union.x1, union.y1
        margins = (left, top, rect.width - right, rect.height - bottom)
    else:
        left = top = right = bottom = None
        margins = (None, None, None, None)
    return PageTypography(
        page=page.number + 1,
        text_chars=chars,
        span_count=span_count,
        weighted_median_size=rounded(weighted_quantile(sizes, 0.5)),
        p10_size=rounded(weighted_quantile(sizes, 0.1)),
        p90_size=rounded(weighted_quantile(sizes, 0.9)),
        max_size=rounded(max((size for size, _ in sizes), default=float("nan"))) if sizes else None,
        page_width=round(rect.width, 2),
        page_height=round(rect.height, 2),
        text_left=rounded(left),
        text_top=rounded(top),
        text_right=rounded(right),
        text_bottom=rounded(bottom),
        left_margin=rounded(margins[0]),
        top_margin=rounded(margins[1]),
        right_margin=rounded(margins[2]),
        bottom_margin=rounded(margins[3]),
        dominant_fonts=", ".join(font for font, _ in fonts.most_common(3)),
    )


def audit_pdf(record: str, path: Path) -> PdfTypography:
    class_hint = "reference" if any(pattern in path.name.lower() for pattern in REFERENCE_PATTERNS) else "reader"
    warnings: list[str] = []
    page_details: list[PageTypography] = []
    with fitz.open(path) as doc:
        pages = doc.page_count
        for page in doc:
            page_details.append(page_span_data(page))
    text_pages = sum(1 for page in page_details if page.text_chars >= 80)
    total_text_chars = sum(page.text_chars for page in page_details)
    textish_pages = [page for page in page_details if page.text_chars >= 200 and page.weighted_median_size is not None]
    all_sizes: list[tuple[float, int]] = []
    for page in textish_pages:
        all_sizes.append((float(page.weighted_median_size or 0), max(page.text_chars, 1)))
    med = weighted_quantile(all_sizes, 0.5)
    p10 = weighted_quantile(all_sizes, 0.1)
    p90 = weighted_quantile(all_sizes, 0.9)
    page_medians = [float(page.weighted_median_size) for page in textish_pages if page.weighted_median_size is not None]
    page_min = min(page_medians) if page_medians else None
    page_max = max(page_medians) if page_medians else None
    page_range = (page_max - page_min) if page_min is not None and page_max is not None else None
    page_size_set = "; ".join(
        f"{w:g}x{h:g}"
        for w, h in sorted({(round(page.page_width), round(page.page_height)) for page in page_details})
    )
    likely_scan = class_hint == "reference" or (pages > 0 and text_pages / pages < 0.25)
    if med is not None and class_hint == "reader":
        if med < 8.5:
            warnings.append("body-font-small")
        if med > 12.5:
            warnings.append("body-font-large")
    if page_range is not None and page_range > 1.25 and class_hint == "reader":
        warnings.append("inconsistent-page-font-size")
    if p10 is not None and p90 is not None and (p90 - p10) > 2.2 and class_hint == "reader":
        warnings.append("wide-font-size-spread")
    if len({(round(page.page_width), round(page.page_height)) for page in page_details}) > 1:
        warnings.append("mixed-page-sizes")
    if class_hint == "reader" and text_pages == 0:
        warnings.append("no-extractable-text")
    return PdfTypography(
        record=record,
        filename=path.name,
        path=str(path),
        bytes=path.stat().st_size,
        pages=pages,
        class_hint=class_hint,
        text_pages=text_pages,
        total_text_chars=total_text_chars,
        median_body_size=rounded(med),
        p10_body_size=rounded(p10),
        p90_body_size=rounded(p90),
        page_median_min=rounded(page_min),
        page_median_max=rounded(page_max),
        page_median_range=rounded(page_range),
        page_size_set=page_size_set,
        likely_scan_or_reference=likely_scan,
        warnings=warnings,
        page_details=page_details,
    )


def record_dirs_from_args(names: list[str]) -> dict[str, Path]:
    if not names:
        return DEFAULT_RECORDS
    result = {}
    for name in names:
        if name in DEFAULT_RECORDS:
            result[name] = DEFAULT_RECORDS[name]
        else:
            path = Path(name)
            label = path.parent.name if path.name.lower() == "upload" else path.name
            result[label] = path
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("records", nargs="*", help="Record key or upload directory. Default audits all current public upload directories.")
    parser.add_argument("--out-stem", default="public_pdf_typography_audit")
    args = parser.parse_args()
    records = record_dirs_from_args(args.records)
    REPORTS.mkdir(parents=True, exist_ok=True)
    results: list[PdfTypography] = []
    for record, directory in records.items():
        if not directory.exists():
            continue
        for pdf in sorted(directory.glob("*.pdf"), key=lambda p: p.name.lower()):
            results.append(audit_pdf(record, pdf))
    json_path = REPORTS / f"{args.out_stem}.json"
    csv_path = REPORTS / f"{args.out_stem}.csv"
    json_path.write_text(
        json.dumps([asdict(item) for item in results], indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        fieldnames = [
            "record",
            "filename",
            "class_hint",
            "pages",
            "text_pages",
            "median_body_size",
            "p10_body_size",
            "p90_body_size",
            "page_median_min",
            "page_median_max",
            "page_median_range",
            "page_size_set",
            "likely_scan_or_reference",
            "warnings",
            "bytes",
            "path",
        ]
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for item in results:
            row = asdict(item)
            row["warnings"] = ";".join(item.warnings)
            row.pop("page_details", None)
            writer.writerow({key: row.get(key) for key in fieldnames})
    summary = {
        "pdfs": len(results),
        "reader_pdfs": sum(1 for item in results if item.class_hint == "reader"),
        "warned_reader_pdfs": [
            {
                "record": item.record,
                "filename": item.filename,
                "median_body_size": item.median_body_size,
                "page_median_range": item.page_median_range,
                "warnings": item.warnings,
            }
            for item in results
            if item.class_hint == "reader" and item.warnings
        ],
        "json": str(json_path),
        "csv": str(csv_path),
    }
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
