#!/usr/bin/env python3
"""Build chunked full-repository preservation ZIPs for Zenodo provenance."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE = Path.home() / "Documents" / "Papors" / "Chatnotes" / "CHat translates and clean"
CLAUDE_OUTPUTS = Path.home() / "Documents" / "CLAUDE PLEASE DONT DELETE WINDOWS 32" / "CLAUDE_OUTPUTS"
OUT = ROOT / "release_candidates" / "raw_source_archive_current"

CURRENT_SOURCE_ROOTS = [
    ("sga_translation_drops", BASE / "translations" / "SGA + translation"),
    ("weber_noether_translation_drops", BASE / "translations" / "Other Weber nother etc"),
    ("non_european_multilingual_drops", BASE / "translations" / "Kimi multil"),
    ("deligne_translation_drops", BASE / "translations" / "Deligne"),
    ("web_cleanup_drops", BASE / "Web ChatGPT (cleanup)"),
    ("multilingual_cleanup_drops", BASE / "cleanup multilingual"),
    ("non_european_originals_notes", BASE / "non eu"),
    ("cutup_papers_and_working_notes", BASE / "cutup papers etc"),
    ("claude_ega_and_audit_outputs", CLAUDE_OUTPUTS),
]

FULL_KIMI_ROOT = ("full_raw_kimi_working_folder", BASE / "Kimi")


def reset_dir(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = (ROOT / "release_candidates").resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def iter_source_files(roots: list[tuple[str, Path]]):
    for label, root in roots:
        if not root.exists():
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            parts_lower = {part.lower() for part in path.parts}
            if ".git" in parts_lower or "__pycache__" in parts_lower:
                continue
            try:
                size = path.stat().st_size
            except OSError:
                continue
            rel = path.relative_to(root).as_posix()
            archive_name = f"{label}/{rel}"
            yield {
                "label": label,
                "root": str(root),
                "path": path,
                "archive_name": archive_name,
                "bytes": size,
                "mtime": datetime.fromtimestamp(path.stat().st_mtime).isoformat(timespec="seconds"),
            }


def make_chunks(files: list[dict], max_bytes: int) -> list[list[dict]]:
    chunks: list[list[dict]] = []
    current: list[dict] = []
    current_size = 0
    for item in files:
        size = int(item["bytes"])
        if current and current_size + size > max_bytes:
            chunks.append(current)
            current = []
            current_size = 0
        current.append(item)
        current_size += size
    if current:
        chunks.append(current)
    return chunks


def build_readme(total_files: int, total_bytes: int, chunks: list[list[dict]], include_full_kimi: bool) -> str:
    roots_note = "The very large full raw transcription-working folder is included." if include_full_kimi else (
        "One very large raw transcription-working folder is not included in this current-source archive because it alone exceeds 50 GiB; "
        "it should be split into separate raw archive records if preserved wholesale."
    )
    return f"""# Full Repository Preservation Archive

Generated: {datetime.now().isoformat(timespec="seconds")}

This archive preserves the current local source packets and working inputs used by the manuscript transcription and translation project. These ZIPs are provenance/backstop files, not reader-facing editions. The public-facing records should be consulted first for organized PDFs, TeX, source/reference scans, and status descriptions.

Included material is stored under neutral folder labels rather than local absolute paths. The archive includes current SGA translation packets, Weber/Noether translation drops, non-European multilingual refinement drops, Deligne working drops, review/repair drops, multilingual repair drops, cut-up working notes, and EGA audit/translation output folders.

{roots_note}

Chunk count: {len(chunks)}
File count: {total_files}
Uncompressed source bytes: {total_bytes}

Use `99 Full Repository Preservation - Manifest.csv` for file-level provenance and checksums of the chunk ZIPs. The chunk ZIPs are intentionally inclusive: they may contain duplicated source packets, render checks, logs, and intermediate files, because their purpose is preservation and reproducibility rather than clean browsing.
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--include-full-kimi", action="store_true", help="Also include the enormous full raw transcription-working folder.")
    parser.add_argument("--max-gib", type=float, default=1.8, help="Approximate maximum uncompressed bytes per chunk.")
    args = parser.parse_args()

    roots = list(CURRENT_SOURCE_ROOTS)
    if args.include_full_kimi:
        roots.append(FULL_KIMI_ROOT)

    upload = OUT / "upload"
    reports = OUT / "reports"
    reset_dir(upload)
    reports.mkdir(parents=True, exist_ok=True)

    files = sorted(iter_source_files(roots), key=lambda item: (item["label"], item["archive_name"].lower()))
    max_bytes = int(args.max_gib * 1024**3)
    chunks = make_chunks(files, max_bytes)
    total_bytes = sum(int(item["bytes"]) for item in files)

    manifest_rows: list[dict] = []
    chunk_rows: list[dict] = []
    readme = build_readme(len(files), total_bytes, chunks, args.include_full_kimi)
    readme_path = upload / "99 Full Repository Preservation - README.txt"
    readme_path.write_text(readme, encoding="utf-8")

    for chunk_index, chunk in enumerate(chunks, start=1):
        zip_path = upload / f"99 Full Repository Preservation - Current Working Inputs - Part {chunk_index:02d} of {len(chunks):02d}.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
            zf.writestr("README.txt", readme)
            for item in chunk:
                zf.write(item["path"], item["archive_name"])
                manifest_rows.append(
                    {
                        "chunk": zip_path.name,
                        "archive_name": item["archive_name"],
                        "source_label": item["label"],
                        "bytes": item["bytes"],
                        "mtime": item["mtime"],
                    }
                )
        with zipfile.ZipFile(zip_path) as zf:
            bad = zf.testzip()
        if bad:
            raise RuntimeError(f"Bad ZIP member in {zip_path}: {bad}")
        chunk_rows.append(
            {
                "filename": zip_path.name,
                "bytes": zip_path.stat().st_size,
                "sha256": sha256(zip_path),
                "members": len(chunk) + 1,
            }
        )

    manifest_path = upload / "99 Full Repository Preservation - Manifest.csv"
    with manifest_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["chunk", "archive_name", "source_label", "bytes", "mtime"])
        writer.writeheader()
        writer.writerows(manifest_rows)

    summary = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "include_full_kimi": args.include_full_kimi,
        "source_roots": [{"label": label, "path": str(path), "exists": path.exists()} for label, path in roots],
        "total_files": len(files),
        "total_source_bytes": total_bytes,
        "chunks": chunk_rows,
        "readme": str(readme_path),
        "manifest": str(manifest_path),
    }
    summary_path = reports / "raw_source_archive_summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"upload": str(upload), "summary": str(summary_path), "chunks": len(chunks), "total_source_bytes": total_bytes}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
