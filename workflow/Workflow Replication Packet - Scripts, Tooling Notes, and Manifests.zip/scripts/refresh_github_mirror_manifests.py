from __future__ import annotations

import csv
import json
import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path

import fitz


ROOT = Path(__file__).resolve().parents[1]
MIRROR = ROOT / "github_mirror" / "modern-latex-manuscripts"
MANIFESTS = MIRROR / "manifests"

CURRENT_RECORDS = {
    "main": "https://zenodo.org/records/20393488",
    "ega": "https://zenodo.org/records/20414353",
    "sga": "https://zenodo.org/records/20410947",
    "non_european": "https://zenodo.org/records/20410957",
    "weber": "https://zenodo.org/records/20412153",
    "noether": "https://zenodo.org/records/20412587",
    "deligne": "https://zenodo.org/records/20410853",
    "classical": "https://zenodo.org/records/20414787",
    "author_cluster": "https://zenodo.org/records/20411006",
    "gauss": "https://zenodo.org/records/20410934",
    "riemann": "https://zenodo.org/records/20429778",
}

INTERNAL_PATTERNS = [
    re.compile(pattern, re.IGNORECASE)
    for pattern in [
        r"\bchatgpt\b",
        r"\bclaude\b",
        r"\bkimi\b",
        r"\bhandoff\b",
        r"\bcleanup\b",
        r"c:\\users\\",
        r"c:/users/",
        r"\blocal_user\b",
    ]
]


def rel(path: Path) -> str:
    return str(path.relative_to(MIRROR)).replace("\\", "/")


def ensure_mirror_path(path: Path) -> None:
    base = MIRROR.resolve()
    resolved = path.resolve()
    if resolved != base and base not in resolved.parents:
        raise RuntimeError(f"Refusing path outside mirror: {resolved}")


def drop_stale_manifests() -> list[str]:
    removed: list[str] = []
    for name in [
        "90 Classical Algebra and Arithmetic - Public Summary.json",
    ]:
        path = MANIFESTS / name
        if path.exists():
            ensure_mirror_path(path)
            path.unlink()
            removed.append(name)
    return removed


def iter_files() -> list[Path]:
    files: list[Path] = []
    for path in MIRROR.rglob("*"):
        if not path.is_file():
            continue
        if ".git" in path.parts:
            continue
        files.append(path)
    return sorted(files, key=lambda p: rel(p).lower())


def write_file_inventory(files: list[Path]) -> Path:
    path = MANIFESTS / "github_file_inventory.csv"
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["path", "bytes"])
        for item in files:
            writer.writerow([rel(item), item.stat().st_size])
    return path


def pdf_health(path: Path) -> dict[str, object]:
    entry: dict[str, object] = {
        "path": rel(path),
        "bytes": path.stat().st_size,
        "pages": None,
        "text_chars_first_3_pages": None,
        "first_page_blankish": None,
        "internal_note_flags": [],
        "error": None,
    }
    try:
        with fitz.open(path) as doc:
            entry["pages"] = doc.page_count
            text_chunks: list[str] = []
            for index in range(min(3, doc.page_count)):
                text_chunks.append(doc[index].get_text("text"))
            sample = "\n".join(text_chunks)
            entry["text_chars_first_3_pages"] = len(sample.strip())
            if doc.page_count:
                first = doc[0].get_text("text").strip()
                entry["first_page_blankish"] = len(first) < 50
            flags = sorted(
                {
                    pattern.pattern
                    for pattern in INTERNAL_PATTERNS
                    if pattern.search(sample)
                }
            )
            entry["internal_note_flags"] = flags
    except Exception as exc:  # pragma: no cover - this is an audit artifact.
        entry["error"] = f"{type(exc).__name__}: {exc}"
    return entry


def write_reader_pdf_health(reader_pdfs: list[Path]) -> tuple[Path, list[dict[str, object]]]:
    rows = [pdf_health(path) for path in reader_pdfs]
    path = MANIFESTS / "github_reader_pdf_health_audit_20260529.json"
    path.write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")
    return path, rows


def section_counts(reader_pdfs: list[Path]) -> dict[str, int]:
    counts: dict[str, int] = defaultdict(int)
    for path in reader_pdfs:
        try:
            section = path.relative_to(MIRROR / "reader-pdfs").parts[0]
        except ValueError:
            section = "unknown"
        counts[section] += 1
    return dict(sorted(counts.items()))


def write_summary(files: list[Path], reader_pdfs: list[Path], health: list[dict[str, object]], removed: list[str]) -> Path:
    counts = section_counts(reader_pdfs)
    total_bytes = sum(path.stat().st_size for path in files)
    flagged = [
        item
        for item in health
        if item.get("error") or item.get("internal_note_flags") or item.get("first_page_blankish")
    ]
    summary = {
        "generated": datetime.now().isoformat(timespec="seconds"),
        "file_count": len(files),
        "total_bytes": total_bytes,
        "reader_pdf_count": len(reader_pdfs),
        "reader_pdf_counts_by_section": counts,
        "current_records": CURRENT_RECORDS,
        "removed_stale_manifests": removed,
        "health_audit": "manifests/github_reader_pdf_health_audit_20260529.json",
        "file_inventory": "manifests/github_file_inventory.csv",
        "reader_health_flags": flagged,
        "cayley_public_policy": "Only repaired slice PDFs are front-facing; broad cumulative Cayley volume drafts are retained as source/artifact material.",
    }
    path = MANIFESTS / "github_refresh_summary.json"
    path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def write_public_surface_markdown(reader_pdfs: list[Path], health: list[dict[str, object]]) -> tuple[Path, Path]:
    counts = section_counts(reader_pdfs)
    lines = [
        "# Public PDF Surface Audit",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        "",
        "Reader PDF counts by section:",
        "",
    ]
    for section, count in counts.items():
        lines.append(f"- {section}: {count}")
    lines.extend(
        [
            "",
            "Cayley policy: the public reader shelf uses only repaired slice PDFs that render as real mathematical text. "
            "Broad cumulative Cayley draft volumes are preserved in source/artifact material rather than promoted as reader PDFs.",
            "",
            "Current public Zenodo records:",
            "",
        ]
    )
    for key, url in CURRENT_RECORDS.items():
        lines.append(f"- {key}: {url}")
    flagged = [
        item
        for item in health
        if item.get("error") or item.get("internal_note_flags") or item.get("first_page_blankish")
    ]
    lines.extend(["", "Reader PDF health flags:", ""])
    if flagged:
        for item in flagged[:50]:
            reasons = []
            if item.get("error"):
                reasons.append(f"error={item['error']}")
            if item.get("internal_note_flags"):
                reasons.append(f"internal_flags={item['internal_note_flags']}")
            if item.get("first_page_blankish"):
                reasons.append("first_page_blankish")
            lines.append(f"- `{item['path']}`: {', '.join(reasons)}")
        if len(flagged) > 50:
            lines.append(f"- ... {len(flagged) - 50} additional flagged PDFs in the JSON audit.")
    else:
        lines.append("- None from the lightweight local mirror health audit.")
    text = "\n".join(lines) + "\n"
    surface = MANIFESTS / "public_pdf_surface_audit_current.md"
    readability = MANIFESTS / "public_archive_readability_audit_current.md"
    coherence = MANIFESTS / "zenodo_public_record_coherence_audit_20260529.md"
    for path in [surface, readability, coherence]:
        path.write_text(text, encoding="utf-8")
    return surface, readability


def main() -> int:
    if not (MIRROR / ".git").exists():
        raise RuntimeError(f"GitHub mirror not found: {MIRROR}")
    MANIFESTS.mkdir(parents=True, exist_ok=True)
    removed = drop_stale_manifests()
    files = iter_files()
    reader_pdfs = sorted((MIRROR / "reader-pdfs").rglob("*.pdf"), key=lambda p: rel(p).lower())
    inventory = write_file_inventory(files)
    health_path, health = write_reader_pdf_health(reader_pdfs)
    summary = write_summary(files, reader_pdfs, health, removed)
    surface, readability = write_public_surface_markdown(reader_pdfs, health)
    print(
        json.dumps(
            {
                "inventory": rel(inventory),
                "health": rel(health_path),
                "summary": rel(summary),
                "surface_audit": rel(surface),
                "readability_audit": rel(readability),
                "reader_pdf_count": len(reader_pdfs),
                "removed_stale_manifests": removed,
            },
            indent=2,
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
