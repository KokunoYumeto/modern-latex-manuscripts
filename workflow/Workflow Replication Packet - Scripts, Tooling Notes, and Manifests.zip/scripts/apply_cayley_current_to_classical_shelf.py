#!/usr/bin/env python3
"""Promote the current Cayley per-volume rebuild into the classical shelf."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import fitz


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "release_candidates" / "zenodo_satellite_classical_algebra_arithmetic_modern_latex_current"
UPLOAD = OUT / "upload"
REPORTS = OUT / "reports"
WORK = ROOT / "_tmp_cayley_public_20260529"
SOURCE = Path(r"LOCAL_USER_HOME\Documents\CLAUDE PLEASE DONT DELETE WINDOWS 32\CLAUDE_OUTPUTS\cayley_clean_per_volume")
SOURCE_V2 = Path(r"LOCAL_USER_HOME\Documents\CLAUDE PLEASE DONT DELETE WINDOWS 32\CLAUDE_OUTPUTS\cayley_v2_fixes")
PUBLIC_SOURCE = WORK / "cayley_clean_per_volume_public"
V2_PUBLIC_SOURCE = WORK / "cayley_repaired_slice_sources_2026-05-29"
ZENODO = ROOT / "zenodo"

SUMMARY_JSON = UPLOAD / "Record Summary - Classical Algebra and Arithmetic.json"
METADATA_JSON = ZENODO / "metadata_satellite_classical_algebra_arithmetic_modern_latex_current.json"
ARTIFACT_ZIP = UPLOAD / "Supplementary Sources - Classical Algebra and Arithmetic.zip"
LEGACY_SUMMARY_JSON = UPLOAD / "90 Classical Algebra and Arithmetic - Public Summary.json"
LEGACY_ARTIFACT_ZIP = UPLOAD / "80 Classical Algebra and Arithmetic - Sources, TeX, and Audits.zip"
PDFLATEX = Path.home() / "AppData" / "Local" / "Programs" / "MiKTeX" / "miktex" / "bin" / "x64" / "pdflatex.exe"

CAYLEY_MAP = [
    ("Cayley_Collected_Mathematical_Papers_Front_Matter.pdf", "00 Cayley - Collected Mathematical Papers - Front Matter and Memoir.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_I.pdf", "01 Cayley - Collected Mathematical Papers, Volume I.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_II.pdf", "02 Cayley - Collected Mathematical Papers, Volume II.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_III.pdf", "03 Cayley - Collected Mathematical Papers, Volume III.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_IV.pdf", "04 Cayley - Collected Mathematical Papers, Volume IV.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_V.pdf", "05 Cayley - Collected Mathematical Papers, Volume V.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_VI.pdf", "06 Cayley - Collected Mathematical Papers, Volume VI.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_VII.pdf", "07 Cayley - Collected Mathematical Papers, Volume VII.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_VIII.pdf", "08 Cayley - Collected Mathematical Papers, Volume VIII.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_IX.pdf", "09 Cayley - Collected Mathematical Papers, Volume IX.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_X.pdf", "10 Cayley - Collected Mathematical Papers, Volume X.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_XI.pdf", "11 Cayley - Collected Mathematical Papers, Volume XI.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_XII.pdf", "12 Cayley - Collected Mathematical Papers, Volume XII.pdf"),
    ("Cayley_Collected_Mathematical_Papers_Vol_XIII.pdf", "13 Cayley - Collected Mathematical Papers, Volume XIII.pdf"),
]

RENUMBER = {
    "20 Dedekind - Gesammelte Mathematische Werke, Band I.pdf": "Dedekind - Gesammelte Mathematische Werke, Band I.pdf",
    "21 Dedekind - Gesammelte Mathematische Werke, Band II.pdf": "Dedekind - Gesammelte Mathematische Werke, Band II.pdf",
    "22 Dedekind - Gesammelte Mathematische Werke, Band III.pdf": "Dedekind - Gesammelte Mathematische Werke, Band III.pdf",
    "30 Dirichlet - Selected Works.pdf": "Dirichlet - Selected Works.pdf",
    "10 Dedekind - Gesammelte Mathematische Werke, Band I - Modern LaTeX Draft.pdf": "Dedekind - Gesammelte Mathematische Werke, Band I.pdf",
    "11 Dedekind - Gesammelte Mathematische Werke, Band II - Modern LaTeX Draft.pdf": "Dedekind - Gesammelte Mathematische Werke, Band II.pdf",
    "12 Dedekind - Gesammelte Mathematische Werke, Band III - Modern LaTeX Draft.pdf": "Dedekind - Gesammelte Mathematische Werke, Band III.pdf",
    "20 Dirichlet - Selected Works - Modern LaTeX Draft.pdf": "Dirichlet - Selected Works.pdf",
}

PUBLIC_FORBIDDEN = re.compile(
    r"\\[A-Za-z]+|\\[()\[\]{}]|"
    r"\b(ChatGPT|Claude|Kimi|handoff|cleanup|content-filter|hallucination|garbage)\b|"
    r"C:\\Users\\project maintainer|!!br0ken!!|�",
    re.IGNORECASE,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_reset(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = ROOT.resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def migrate_public_names() -> None:
    if not ARTIFACT_ZIP.exists() and LEGACY_ARTIFACT_ZIP.exists():
        LEGACY_ARTIFACT_ZIP.rename(ARTIFACT_ZIP)
    if LEGACY_ARTIFACT_ZIP.exists():
        LEGACY_ARTIFACT_ZIP.unlink()
    if not SUMMARY_JSON.exists() and LEGACY_SUMMARY_JSON.exists():
        LEGACY_SUMMARY_JSON.rename(SUMMARY_JSON)
    if LEGACY_SUMMARY_JSON.exists():
        LEGACY_SUMMARY_JSON.unlink()


def sanitize_text(text: str) -> str:
    replacements = [
        ("Claude Code (Opus 4.7)", "a local repair pass"),
        ("Claude direct-OCR typesetting", "direct scan-based typesetting"),
        ("Claude direct-from-scan", "direct scan-based"),
        ("Claude direct-typesetting pipeline", "direct scan-based typesetting pass"),
        ("Claude direct", "direct"),
        ("Claude", "local repair pass"),
        ("Kimi-generated", "source-generated"),
        ("Kimi-specific", "source-specific"),
        ("Kimi typesetting work", "available source typesetting work"),
        ("Kimi TeX source", "available TeX source"),
        ("Kimi chunks", "source chunks"),
        ("Kimi sources", "source files"),
        ("Kimi original", "source original"),
        ("Kimi", "source system"),
        ("content-filter blocks or queued", "not completed in the current pass"),
        ("content-filter blocked", "not completed"),
        ("content-filter", "automated-pass"),
        ("hallucinated", "incorrectly reconstructed"),
        ("hallucination", "incorrect reconstruction"),
        ("garbage", "corruption"),
        ("no source system TeX source exists anywhere on disk", "no complete local TeX source was available"),
        ("not produced by the current batch", "not completed in the current pass"),
        ("undue effort in this batch", "follow-up transcription"),
        ("C:\\Users\\project maintainer", "local workspace"),
        (str(Path.home()), "local workspace"),
        ("project maintainer", "project maintainer"),
    ]
    for old, new in replacements:
        text = re.sub(re.escape(old), new, text, flags=re.IGNORECASE)
    return text


def copy_public_source() -> None:
    safe_reset(WORK)
    text_suffixes = {".tex", ".md", ".txt", ".json", ".csv", ".py", ".log", ".tsv"}
    for src in sorted(SOURCE.rglob("*")):
        if src.is_dir():
            continue
        if "_build" in src.parts:
            continue
        rel = src.relative_to(SOURCE)
        dest = PUBLIC_SOURCE / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if src.suffix.lower() in text_suffixes:
            dest.write_text(sanitize_text(src.read_text(encoding="utf-8", errors="replace")), encoding="utf-8")
        elif src.suffix.lower() in {".aux", ".out", ".toc"}:
            continue
        else:
            shutil.copy2(src, dest)
    if SOURCE_V2.exists():
        for src in sorted(SOURCE_V2.rglob("*")):
            if src.is_dir():
                continue
            if "_build" in src.parts:
                continue
            rel = src.relative_to(SOURCE_V2)
            dest = V2_PUBLIC_SOURCE / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            if src.suffix.lower() in text_suffixes:
                dest.write_text(sanitize_text(src.read_text(encoding="utf-8", errors="replace")), encoding="utf-8")
            elif src.suffix.lower() in {".aux", ".out", ".toc"}:
                continue
            else:
                shutil.copy2(src, dest)
    public_rendered = WORK / "broad-working-volume-pdfs"
    public_rendered.mkdir(parents=True, exist_ok=True)
    for src_name, public_name in CAYLEY_MAP:
        src = SOURCE / src_name
        if src.exists():
            shutil.copy2(src, public_rendered / public_name)


def compile_volume_viii() -> dict[str, Any]:
    pdf = PUBLIC_SOURCE / "Cayley_Collected_Mathematical_Papers_Vol_VIII.pdf"
    if not pdf.exists():
        raise FileNotFoundError(pdf)
    replacements = {
        "Claude (Opus 4.7)": "direct repair",
        "Claude": "repair pass",
        "Kimi": "source",
        "content-filter": "not completed",
        "hallucination": "incorrect reconstruction",
        "hallucinated": "incorrectly reconstructed",
        "garbage": "corruption",
    }
    tmp = pdf.with_suffix(".sanitized.pdf")
    redactions = []
    with fitz.open(pdf) as doc:
        for page_number, page in enumerate(doc, start=1):
            for needle, replacement in replacements.items():
                for rect in page.search_for(needle):
                    page.add_redact_annot(
                        rect,
                        text=replacement,
                        fill=(1, 1, 1),
                        text_color=(0, 0, 0),
                        fontsize=7,
                    )
                    redactions.append(
                        {
                            "page": page_number,
                            "marker": "source wording",
                            "replacement": replacement,
                        }
                    )
            if redactions:
                page.apply_redactions()
        doc.save(tmp, garbage=4, deflate=True)
    tmp.replace(pdf)
    return {
        "source": pdf.name,
        "mode": "pdf text redaction sanitizer",
        "redactions": redactions,
        "pdf_exists": pdf.exists(),
        "pdf_bytes": pdf.stat().st_size if pdf.exists() else 0,
    }


def pdf_stats(path: Path) -> dict[str, Any]:
    with fitz.open(path) as doc:
        return {
            "filename": path.name,
            "bytes": path.stat().st_size,
            "pages": doc.page_count,
            "text_chars": sum(len(page.get_text("text") or "") for page in doc),
            "sha256": sha256(path),
        }


def chunk_source_inventory() -> dict[str, Any]:
    """Inventory the chunk-level TeX/PDF material preserved below sources_tex_*."""
    volumes = []
    for base, source_group in [(PUBLIC_SOURCE, "broad_working_source"), (V2_PUBLIC_SOURCE, "validated_repair_source")]:
        if not base.exists():
            continue
        for folder in sorted(base.glob("sources_tex_*")):
            if not folder.is_dir():
                continue
            tex_files = sorted(folder.glob("*.tex"), key=lambda p: p.name.lower())
            pdf_files = sorted(folder.glob("*.pdf"), key=lambda p: p.name.lower())
            pdf_rows = []
            for pdf in pdf_files:
                row = pdf_stats(pdf)
                row["path"] = pdf.relative_to(base).as_posix()
                row["source_group"] = source_group
                row["public_reader_tier"] = pdf.name not in CAYLEY_HELD_FILENAMES
                pdf_rows.append(row)
            volumes.append(
                {
                    "volume": folder.name.replace("sources_tex_", ""),
                    "source_group": source_group,
                    "tex_chunk_count": len(tex_files),
                    "rendered_slice_count": len(pdf_rows),
                    "rendered_slice_pages": sum(int(row["pages"]) for row in pdf_rows),
                    "rendered_slices": pdf_rows,
                    "tex_chunks": [path.name for path in tex_files],
                }
            )
    return {
        "volume_count": len(volumes),
        "tex_chunk_count": sum(int(row["tex_chunk_count"]) for row in volumes),
        "rendered_slice_count": sum(int(row["rendered_slice_count"]) for row in volumes),
        "rendered_slice_pages": sum(int(row["rendered_slice_pages"]) for row in volumes),
        "volumes": volumes,
    }


def assert_public_pdf_clean(path: Path) -> None:
    hits: list[dict[str, Any]] = []
    with fitz.open(path) as doc:
        for page_index, page in enumerate(doc, start=1):
            text = page.get_text("text") or ""
            match = PUBLIC_FORBIDDEN.search(text)
            if match:
                hits.append({"page": page_index, "hit": match.group(0)})
                if len(hits) >= 10:
                    break
    if hits:
        raise RuntimeError(f"{path.name}: public PDF marker hits: {hits}")


ROMAN_VOLUME = {
    "01": "I",
    "02": "II",
    "03": "III",
    "04": "IV",
    "05": "V",
    "06": "VI",
    "07": "VII",
    "08": "VIII",
    "09": "IX",
    "10": "X",
    "11": "XI",
    "12": "XII",
    "13": "XIII",
}

CAYLEY_HELD_FILENAMES = {
    "cayley_vol03_pages_201_250.pdf",
    "cayley_vol12_pages_101_150.pdf",
    "cayley_vol12_pages_126_150.pdf",
    "cayley_vol12_pages_301_350.pdf",
    "cayley_vol13_pages_151_200.pdf",
}


def cayley_slice_public_name(path: Path) -> str:
    match = re.fullmatch(r"cayley_vol(\d+)_pages_(\d+)_(\d+)\.pdf", path.name)
    if match:
        volume, start, end = match.groups()
        roman = ROMAN_VOLUME.get(volume, volume.lstrip("0") or volume)
        return (
            f"Cayley - Collected Mathematical Papers, Volume {roman}, "
            f"pages {int(start):03d}-{int(end):03d} - Repaired LaTeX Slice.pdf"
        )
    fixed_match = re.fullmatch(r"cayley_vol(\d+)_paper_(\d+)(?:_section_(\d+))?_(?:FIXED|RETYPE)\.pdf", path.name)
    if fixed_match:
        volume, paper, section = fixed_match.groups()
        roman = ROMAN_VOLUME.get(volume, volume.lstrip("0") or volume)
        section_text = f" section {section}" if section else ""
        return (
            f"Cayley - Collected Mathematical Papers, Volume {roman}, "
            f"paper {paper}{section_text} - Repaired LaTeX Slice.pdf"
        )
    raise RuntimeError(f"Unexpected Cayley slice filename: {path.name}")


def cayley_volume_number(path: Path) -> int:
    match = re.fullmatch(r"cayley_vol(\d+)_(?:pages_\d+_\d+|paper_\d+(?:_section_\d+)?_(?:FIXED|RETYPE))\.pdf", path.name)
    if not match:
        raise RuntimeError(f"Unexpected Cayley slice filename: {path.name}")
    return int(match.group(1))


def cayley_volume_public_name(volume: int) -> str:
    roman = ROMAN_VOLUME.get(f"{volume:02d}", str(volume))
    return f"Cayley - Collected Mathematical Papers, Volume {roman} - Source-Checked Modern LaTeX Slice Reader.pdf"


def cayley_slice_pdfs() -> list[Path]:
    slices: list[Path] = []
    if V2_PUBLIC_SOURCE.exists():
        slices.extend(
            path
            for path in V2_PUBLIC_SOURCE.glob("sources_tex_Vol_*/cayley_vol*.pdf")
            if path.name not in CAYLEY_HELD_FILENAMES
            and re.fullmatch(r"cayley_vol\d+_(?:pages_\d+_\d+|paper_\d+(?:_section_\d+)?_(?:FIXED|RETYPE))\.pdf", path.name)
        )
    slices.extend(PUBLIC_SOURCE.glob("sources_tex_Vol_VIII/cayley_vol08_pages_*.pdf"))
    seen: set[str] = set()
    unique: list[Path] = []
    for path in sorted(slices, key=lambda p: cayley_slice_public_name(p)):
        public_name = cayley_slice_public_name(path)
        if public_name in seen:
            continue
        seen.add(public_name)
        unique.append(path)
    return unique


def promote_pdfs() -> list[dict[str, Any]]:
    archive = REPORTS / "cayley_superseded_public_readers_before_current_rebuild"
    archive.mkdir(parents=True, exist_ok=True)
    for old in sorted(UPLOAD.glob("*Cayley*.pdf")):
        shutil.copy2(old, archive / old.name)
        old.unlink()
    for old, new in RENUMBER.items():
        src = UPLOAD / old
        if src.exists():
            src.rename(UPLOAD / new)
    rows = []
    grouped: dict[int, list[Path]] = {}
    for src in cayley_slice_pdfs():
        assert_public_pdf_clean(src)
        grouped.setdefault(cayley_volume_number(src), []).append(src)
    for volume in sorted(grouped):
        sources = sorted(grouped[volume], key=lambda p: cayley_slice_public_name(p))
        public_name = cayley_volume_public_name(volume)
        dest = UPLOAD / public_name
        merged = fitz.open()
        try:
            for src in sources:
                with fitz.open(src) as part:
                    merged.insert_pdf(part)
            merged.set_metadata(
                {
                    "title": public_name.removesuffix(".pdf"),
                    "author": "Arthur Cayley",
                    "subject": "Source-checked modern LaTeX slice reader compiled from repaired range PDFs",
                }
            )
            merged.save(dest, garbage=4, deflate=True)
        finally:
            merged.close()
        assert_public_pdf_clean(dest)
        row = pdf_stats(dest)
        row["author"] = "Arthur Cayley"
        row["work"] = "Collected Mathematical Papers"
        row["source_slice_count"] = len(sources)
        row["source_slices"] = [src.relative_to(WORK).as_posix() for src in sources]
        row["status"] = "source-checked slice reader promoted ahead of broader working drafts"
        rows.append(row)
    if not rows:
        raise RuntimeError("No Cayley repaired slice PDFs were found for public promotion.")
    return rows


def update_artifact_zip(cayley_rows: list[dict[str, Any]], compile_result: dict[str, Any], chunk_inventory: dict[str, Any]) -> dict[str, Any]:
    manifest = {
        "generated_at": now_iso(),
        "scope": "Cayley repaired slice promotion into the classical algebra/arithmetic shelf",
        "reader_files": cayley_rows,
        "compile_result": compile_result,
        "chunk_source_inventory": chunk_inventory,
        "held_not_front_facing": sorted(CAYLEY_HELD_FILENAMES),
        "public_named_broad_volume_directory": "broad-working-volume-pdfs/",
        "public_note": (
            "Top-level Cayley files are volume-level readers compiled from repaired/retyped slice PDFs that passed a reader-surface text audit. "
            "The broader per-volume working PDFs are preserved in this artifact ZIP as continuation material rather than promoted as clean top-level readers."
        ),
    }
    (WORK / "CAYLEY_PUBLIC_REBUILD_MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    prefix = "cayley-current-slice-and-source-rebuild-2026-05-29/"
    old_prefix = "cayley-current-per-volume-rebuild-2026-05-29/"
    neutral_member_names = {
        "input_artifacts_and_audits/kimi7_cleanup_cayley_bundle.zip": "input_artifacts_and_audits/source_cayley_bundle_20260529.zip",
        "input_artifacts_and_audits/kimi7_cleanup_dedekind_dirichlet_bundle.zip": "input_artifacts_and_audits/source_dedekind_dirichlet_bundle_20260529.zip",
    }
    tmp = ARTIFACT_ZIP.with_suffix(ARTIFACT_ZIP.suffix + ".tmp")
    with zipfile.ZipFile(ARTIFACT_ZIP, "r") as zin, zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zout:
        for item in zin.infolist():
            if item.filename.startswith(prefix) or item.filename.startswith(old_prefix):
                continue
            data = zin.read(item.filename)
            item.filename = neutral_member_names.get(item.filename, item.filename)
            zout.writestr(item, data)
        for src in sorted(WORK.rglob("*")):
            if src.is_file():
                zout.write(src, prefix + src.relative_to(WORK).as_posix())
    with zipfile.ZipFile(tmp) as archive:
        bad = archive.testzip()
        if bad:
            tmp.unlink(missing_ok=True)
            raise RuntimeError(f"Bad artifact ZIP member: {bad}")
    tmp.replace(ARTIFACT_ZIP)
    with zipfile.ZipFile(ARTIFACT_ZIP) as archive:
        return {
            "filename": ARTIFACT_ZIP.name,
            "bytes": ARTIFACT_ZIP.stat().st_size,
            "sha256": sha256(ARTIFACT_ZIP),
            "member_count": len(archive.infolist()),
        }


def write_summary(cayley_rows: list[dict[str, Any]], artifact: dict[str, Any], chunk_inventory: dict[str, Any]) -> None:
    reader_rows = [pdf_stats(path) for path in sorted(UPLOAD.glob("*.pdf"), key=lambda p: p.name.lower())]
    for row in reader_rows:
        if "Cayley" in row["filename"]:
            row["author"] = "Arthur Cayley"
        elif "Dedekind" in row["filename"]:
            row["author"] = "Richard Dedekind"
        elif "Dirichlet" in row["filename"]:
            row["author"] = "P. G. Lejeune Dirichlet"
    summary = {
        "generated_at": now_iso(),
        "public_record_title": "Cayley, Dedekind, and Dirichlet: Classical Algebra and Arithmetic LaTeX Drafts",
        "reader_pdf_count": len(reader_rows),
        "reader_pdf_pages_total": sum(int(row["pages"]) for row in reader_rows),
        "cayley_reader_count": len(cayley_rows),
        "cayley_source_slice_count": sum(int(row.get("source_slice_count", 0)) for row in cayley_rows),
        "cayley_pages_total": sum(int(row["pages"]) for row in cayley_rows),
        "cayley_chunk_source_inventory": chunk_inventory,
        "cayley_status": {
            "available": (
                f"{len(cayley_rows)} Cayley volume-level slice readers are front-facing, "
                f"compiled from {sum(int(row.get('source_slice_count', 0)) for row in cayley_rows)} "
                f"repaired/retyped source ranges, {sum(int(row['pages']) for row in cayley_rows)} pages total."
            ),
            "broad_volume_drafts": "Full per-volume working drafts are preserved in the artifact ZIP, but are not promoted as clean top-level readers.",
            "chunk_level_note": (
                "The artifact ZIP also preserves the sources_tex_Vol_I through sources_tex_Vol_XIII chunk trees. "
                f"Those contain {chunk_inventory['tex_chunk_count']} TeX chunks and "
                f"{chunk_inventory['rendered_slice_count']} separately rendered slice PDFs "
                f"({chunk_inventory['rendered_slice_pages']} pages), including the targeted repaired/retyped ranges."
            ),
            "reason_for_replacement": "Earlier broad Cayley drafts remain useful for continuation but are not as reliable as the promoted repaired slices.",
        },
        "reader_pdfs": reader_rows,
        "artifact_zips": [artifact],
    }
    SUMMARY_JSON.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")


def update_metadata(artifact: dict[str, Any], cayley_pages: int) -> None:
    metadata = json.loads(METADATA_JSON.read_text(encoding="utf-8"))
    slice_paths = cayley_slice_pdfs()
    slice_count = len(slice_paths)
    volume_reader_count = len({cayley_volume_number(path) for path in slice_paths})
    metadata["publication_date"] = datetime.now(timezone.utc).date().isoformat()
    metadata["version"] = "2026-05-29 Cayley source-checked slice readers plus Dedekind and Dirichlet shelf"
    metadata["description"] = (
        "<p>This record is a public-facing shelf for modern LaTeX working drafts of selected classical algebra, "
        "arithmetic, and number-theory manuscripts by Arthur Cayley, Richard Dedekind, and P. G. Lejeune Dirichlet. "
        "Top-level PDFs are organized by author, work, and usable slice so readers can download individual files directly. "
        "Source TeX, build notes, audit outputs, and provenance material are collected in the artifact ZIP.</p>"
        "<p><strong>Status at a glance.</strong></p>"
        "<ul>"
        f"<li><strong>Cayley front-facing reader surface:</strong> <code>[#---------]</code> {volume_reader_count} volume-level slice readers are promoted as direct top-level files, compiled from {slice_count} repaired/retyped source ranges, {cayley_pages} pages total. These are the Cayley files currently suitable as readable mathematical typesettings rather than broad draft material.</li>"
        "<li><strong>Cayley broader working material:</strong> <code>[#########-]</code> the artifact ZIP preserves the sources_tex_Vol_I through sources_tex_Vol_XIII trees, broad per-volume working PDFs, TeX chunks, and rendered slice PDFs. Those files are valuable for continuation but are not being presented as clean finished readers.</li>"
        "<li><strong>Dedekind and Dirichlet reader surface:</strong> <code>[######----]</code> Dedekind Bands I-III and one Dirichlet selected-works grouping remain present as working drafts.</li>"
        "<li><strong>Technical PDF/display checks:</strong> <code>[##########]</code> promoted Cayley readers open as normal PDF files and pass a reader-surface text sweep.</li>"
        "<li><strong>Mathematical proofreading:</strong> <code>[----------]</code> working drafts for checking and correction, not certified critical editions.</li>"
        "</ul>"
        "<p><strong>Workflow.</strong> Public-domain scans and witnesses are converted into TeX drafts, checked into readable PDFs, and packaged with source artifacts for inspection and correction. The public organization is by author, work, or corpus; source and build material is kept in artifact ZIPs rather than in public titles or reader PDFs.</p>"
    )
    metadata["notes"] = (
        "Focused public-facing working-draft shelf for Cayley, Dedekind, and Dirichlet. "
        f"Latest update promotes Cayley volume-level slice readers and preserves broader TeX/source artifacts in {artifact['filename']}."
    )
    for related in metadata.get("related_identifiers", []):
        if related.get("identifier") == "https://zenodo.org/records/20441732":
            related["identifier"] = "https://zenodo.org/records/20450957"
        elif related.get("identifier") == "https://zenodo.org/records/20441673":
            related["identifier"] = "https://zenodo.org/records/20450915"
        elif related.get("identifier") == "https://zenodo.org/records/20441857":
            related["identifier"] = "https://zenodo.org/records/20450906"
    if "Cayley" not in metadata["keywords"]:
        metadata["keywords"].append("Cayley")
    text = json.dumps(metadata, ensure_ascii=False)
    if PUBLIC_FORBIDDEN.search(text):
        raise RuntimeError("Internal process wording remains in classical metadata.")
    METADATA_JSON.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> int:
    migrate_public_names()
    for required in [SOURCE, SUMMARY_JSON, METADATA_JSON, ARTIFACT_ZIP]:
        if not required.exists():
            raise FileNotFoundError(required)
    copy_public_source()
    compile_result = compile_volume_viii()
    chunk_inventory = chunk_source_inventory()
    cayley_rows = promote_pdfs()
    artifact = update_artifact_zip(cayley_rows, compile_result, chunk_inventory)
    write_summary(cayley_rows, artifact, chunk_inventory)
    update_metadata(artifact, sum(int(row["pages"]) for row in cayley_rows))
    REPORTS.mkdir(parents=True, exist_ok=True)
    result = {
        "generated_at": now_iso(),
        "cayley_rows": cayley_rows,
        "chunk_source_inventory": chunk_inventory,
        "compile_result": compile_result,
        "artifact_zip": artifact,
        "upload_dir": str(UPLOAD),
    }
    out = REPORTS / "cayley_current_per_volume_result.json"
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
