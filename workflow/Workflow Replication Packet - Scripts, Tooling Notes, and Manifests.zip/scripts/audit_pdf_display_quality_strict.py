#!/usr/bin/env python3
"""Strict display-PDF QC for release staging.

This is deliberately conservative. It does not decide mathematical correctness;
it catches public-release blockers such as invalid PDFs, black/blank rendered
pages, raw TeX/JSON text dumps, and inherited visual-review flags.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import statistics
import subprocess
from datetime import datetime, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def run(cmd: list[str], timeout: int = 120) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        errors="replace",
        check=False,
        timeout=timeout,
    )


def pdf_pages(path: Path) -> int:
    proc = run(["pdfinfo", str(path)], timeout=60)
    if proc.returncode != 0:
        return 0
    match = re.search(r"^Pages:\s+(\d+)", proc.stdout, flags=re.MULTILINE)
    return int(match.group(1)) if match else 0


def sample_pages(page_count: int, target: int = 25) -> list[int]:
    if page_count <= 0:
        return []
    if page_count <= target:
        return list(range(1, page_count + 1))
    pages: set[int] = set()
    pages.update(range(1, min(6, page_count + 1)))
    pages.update(range(max(1, page_count - 4), page_count + 1))
    for i in range(target):
        pos = 1 + round(i * (page_count - 1) / max(1, target - 1))
        pages.add(max(1, min(page_count, pos)))
    return sorted(pages)


def text_metrics(path: Path, out_text: Path) -> dict[str, object]:
    proc = run(["pdftotext", "-enc", "UTF-8", str(path), "-"], timeout=240)
    text = proc.stdout if proc.returncode == 0 else ""
    out_text.parent.mkdir(parents=True, exist_ok=True)
    out_text.write_text(text, encoding="utf-8", errors="replace")

    no_space = re.sub(r"\s+", "", text)
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    lengths = [len(line) for line in lines]
    first = text[:10000]
    first_stripped = first.lstrip()
    brace_quote_count = first.count("{") + first.count("}") + first.count('"')
    jsonish = (
        (first_stripped.startswith("{") or first_stripped.startswith("["))
        and brace_quote_count > 80
        and any(token in first for token in ['"pages"', '"text"', '"metadata"', '"content"', '"chunks"'])
    )
    texish = any(token in text[:20000] for token in ["\\documentclass", "\\begin{document}", "\\usepackage", "\\section{"])
    median_line = statistics.median(lengths) if lengths else 0
    short_line_ratio = sum(1 for n in lengths if n <= 8) / len(lengths) if lengths else 1.0
    return {
        "pdftotext_ok": proc.returncode == 0,
        "chars_no_space": len(no_space),
        "line_count": len(lines),
        "median_line_length": round(float(median_line), 2),
        "short_line_ratio_le8": round(short_line_ratio, 4),
        "looks_like_json_dump": jsonish,
        "looks_like_tex_dump": texish,
        "text_extract_file": str(out_text),
    }


def parse_float(value: str) -> float:
    try:
        return float(value.strip())
    except Exception:
        return 0.0


def image_metric(path: Path, args: list[str], timeout: int = 60) -> str:
    proc = run(["magick", str(path), *args, "info:"], timeout=timeout)
    return proc.stdout.strip() if proc.returncode == 0 else ""


def render_page(pdf: Path, page: int, dest: Path) -> bool:
    dest.parent.mkdir(parents=True, exist_ok=True)
    proc = run(["mutool", "draw", "-q", "-r", "90", "-o", str(dest), str(pdf), str(page)], timeout=120)
    return proc.returncode == 0 and dest.exists() and dest.stat().st_size > 0


def page_visual_metrics(png: Path) -> dict[str, object]:
    dims = image_metric(png, ["-format", "%w,%h"])
    width = height = 0
    if "," in dims:
        try:
            width, height = [int(x) for x in dims.split(",", 1)]
        except Exception:
            width = height = 0
    mean = parse_float(image_metric(png, ["-colorspace", "Gray", "-format", "%[fx:mean]"]))
    sd = parse_float(image_metric(png, ["-colorspace", "Gray", "-format", "%[fx:standard_deviation]"]))
    black = parse_float(
        image_metric(png, ["-colorspace", "Gray", "-threshold", "98%", "-format", "%[fx:1-mean]"])
    )
    trim = image_metric(png, ["-colorspace", "Gray", "-fuzz", "5%", "-trim", "-format", "%@"])
    trim_w = trim_h = trim_x = trim_y = 0
    m = re.match(r"(\d+)x(\d+)\+(-?\d+)\+(-?\d+)", trim)
    if m:
        trim_w, trim_h, trim_x, trim_y = [int(g) for g in m.groups()]
    full_area = max(1, width * height)
    trim_area_fraction = (trim_w * trim_h) / full_area if trim_w and trim_h else 0.0
    return {
        "png": str(png),
        "width": width,
        "height": height,
        "mean_gray": round(mean, 5),
        "stddev_gray": round(sd, 5),
        "black_fraction": round(black, 5),
        "trim_box": trim,
        "trim_x": trim_x,
        "trim_y": trim_y,
        "trim_area_fraction": round(trim_area_fraction, 5),
        "blankish": black < 0.0015 and trim_area_fraction < 0.02,
        "dark_or_inverted": black > 0.75 or mean < 0.35,
    }


def contact_sheet(pngs: list[Path], out: Path) -> bool:
    if not pngs:
        return False
    list_file = out.with_suffix(".txt")
    list_file.write_text("\n".join(str(p) for p in pngs) + "\n", encoding="utf-8")
    proc = run(
        [
            "magick",
            "montage",
            "@" + str(list_file),
            "-thumbnail",
            "260x360",
            "-background",
            "white",
            "-geometry",
            "260x360+8+8",
            "-tile",
            "5x",
            str(out),
        ],
        timeout=240,
    )
    return proc.returncode == 0 and out.exists()


def read_prior_flags(path: Path | None) -> dict[str, str]:
    if not path or not path.exists():
        return {}
    out: dict[str, str] = {}
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            slug = row.get("slug") or re.sub(r"^pdf__|\.pdf$", "", row.get("pdf", ""))
            if slug and row.get("flags"):
                out[slug] = row.get("flags", "")
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pdf-root", required=True)
    parser.add_argument("--out-root", required=True)
    parser.add_argument("--glob", default="*.pdf")
    parser.add_argument("--prior-audit-csv")
    parser.add_argument("--label", default="pdf_display_quality")
    parser.add_argument("--sample-target", type=int, default=25)
    ns = parser.parse_args()

    pdf_root = Path(ns.pdf_root)
    out_root = Path(ns.out_root)
    samples_root = out_root / "sample_pages"
    text_root = out_root / "extracted_text"
    out_root.mkdir(parents=True, exist_ok=True)
    prior_flags = read_prior_flags(Path(ns.prior_audit_csv) if ns.prior_audit_csv else None)

    required = ["pdfinfo", "pdftotext", "mutool", "magick"]
    missing = [tool for tool in required if not shutil.which(tool)]
    if missing:
        raise SystemExit("missing required tools: " + ", ".join(missing))

    rows: list[dict[str, object]] = []
    page_rows: list[dict[str, object]] = []
    for pdf in sorted(pdf_root.glob(ns.glob)):
        slug = re.sub(r"^pdf__|_COMBINED$|\.pdf$", "", pdf.name)
        page_count = pdf_pages(pdf)
        text = text_metrics(pdf, text_root / f"{slug}.txt")
        samples = sample_pages(page_count, ns.sample_target)
        pngs: list[Path] = []
        metrics: list[dict[str, object]] = []
        render_failures = 0
        for page in samples:
            png = samples_root / slug / f"page_{page:05d}.png"
            if render_page(pdf, page, png):
                pngs.append(png)
                metric = page_visual_metrics(png)
                metric.update({"slug": slug, "pdf": pdf.name, "page": page})
                metrics.append(metric)
                page_rows.append(metric)
            else:
                render_failures += 1
        contact = samples_root / slug / f"contact__{slug}.jpg"
        contact_ok = contact_sheet(pngs, contact)

        blank_count = sum(1 for m in metrics if m.get("blankish"))
        dark_count = sum(1 for m in metrics if m.get("dark_or_inverted"))
        black_values = [float(m["black_fraction"]) for m in metrics] or [0.0]
        trim_values = [float(m["trim_area_fraction"]) for m in metrics if not m.get("blankish")] or [0.0]
        flags: list[str] = []
        if page_count <= 0:
            flags.append("invalid_or_unreadable_pdf")
        if render_failures:
            flags.append(f"render_failures:{render_failures}")
        if text["looks_like_json_dump"]:
            flags.append("text_looks_like_json_dump")
        if text["looks_like_tex_dump"]:
            flags.append("text_looks_like_tex_dump")
        if dark_count:
            flags.append(f"dark_or_inverted_sample_pages:{dark_count}")
        if samples and blank_count / len(samples) > 0.35:
            flags.append(f"many_blank_sample_pages:{blank_count}/{len(samples)}")
        if page_count and int(text["chars_no_space"]) / page_count < 120:
            flags.append("very_low_extracted_text_density")
        if statistics.median(trim_values) < 0.08 and statistics.median(black_values) < 0.006:
            flags.append("sampled_content_extremely_small")
        if prior_flags.get(slug):
            flags.append("prior_visual_review_flag:" + prior_flags[slug])

        verdict = "clean_candidate" if not flags else "hold_for_repair_or_review"
        rows.append(
            {
                "pdf": pdf.name,
                "slug": slug,
                "bytes": pdf.stat().st_size,
                "pages": page_count,
                "sample_pages": ";".join(str(p) for p in samples),
                "sample_count": len(samples),
                "render_failures": render_failures,
                "blankish_sample_pages": blank_count,
                "dark_or_inverted_sample_pages": dark_count,
                "median_black_fraction": round(statistics.median(black_values), 5),
                "median_trim_area_fraction": round(statistics.median(trim_values), 5),
                **text,
                "contact_sheet": str(contact) if contact_ok else "",
                "flags": ";".join(flags),
                "verdict": verdict,
            }
        )

    fieldnames = [
        "pdf",
        "slug",
        "bytes",
        "pages",
        "sample_pages",
        "sample_count",
        "render_failures",
        "blankish_sample_pages",
        "dark_or_inverted_sample_pages",
        "median_black_fraction",
        "median_trim_area_fraction",
        "pdftotext_ok",
        "chars_no_space",
        "line_count",
        "median_line_length",
        "short_line_ratio_le8",
        "looks_like_json_dump",
        "looks_like_tex_dump",
        "text_extract_file",
        "contact_sheet",
        "flags",
        "verdict",
    ]
    audit_csv = out_root / f"{ns.label}.csv"
    with audit_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    page_csv = out_root / f"{ns.label}_sample_page_metrics.csv"
    page_fields = [
        "slug",
        "pdf",
        "page",
        "png",
        "width",
        "height",
        "mean_gray",
        "stddev_gray",
        "black_fraction",
        "trim_box",
        "trim_x",
        "trim_y",
        "trim_area_fraction",
        "blankish",
        "dark_or_inverted",
    ]
    with page_csv.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=page_fields)
        writer.writeheader()
        writer.writerows(page_rows)

    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "pdf_root": str(pdf_root),
        "audit_csv": str(audit_csv),
        "page_metrics_csv": str(page_csv),
        "pdf_count": len(rows),
        "clean_candidate_count": sum(1 for r in rows if r["verdict"] == "clean_candidate"),
        "hold_count": sum(1 for r in rows if r["verdict"] != "clean_candidate"),
        "hold_slugs": [r["slug"] for r in rows if r["verdict"] != "clean_candidate"],
    }
    (out_root / f"{ns.label}_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
