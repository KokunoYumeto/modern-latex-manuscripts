#!/usr/bin/env python3
"""Audit current public Zenodo records for reader-facing archive quality.

This is intentionally conservative: it does not mutate Zenodo. It fetches the
public record JSON, scans metadata and file lists for stale/internal wording,
and writes a compact report that can guide description/name cleanup.
"""

from __future__ import annotations

import json
import re
from datetime import datetime
from html import unescape
from pathlib import Path
from typing import Any

import requests


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORTS = PROJECT_ROOT / "reports"

RECORDS = {
    "main": 20456732,
    "ega": 20454552,
    "sga": 20455791,
    "non_european_consolidated": 20455873,
    "chinese": 20435670,
    "indian_sanskrit": 20435677,
    "islamic_arabic": 20435687,
    "historical_references": 20435690,
    "weber": 20455748,
    "noether": 20455701,
    "riemann": 20434317,
    "gauss": 20454309,
    "deligne": 20453551,
    "classical_algebra_arithmetic": 20454226,
    "additional_author_cluster": 20442003,
}

BAD_PATTERNS = [
    r"\bKimi\b",
    r"\bkimi\b",
    r"\bChatGPT\b",
    r"\bOpenAI\b",
    r"\bClaude\b",
    r"\bLLM\b",
    r"\blanguage model\b",
    r"\bhandoff\b",
    r"\bcleanup\b",
    r"\bbatch[_ -]?\d+",
    r"\bnewly added\b",
    r"\bnew[_ -]?only\b",
    r"\bredo\b",
    r"\bdrop\b",
    r"\bLOCAL_USER\b",
    r"C:\\Users\\",
    r"C:/Users/",
    r"\bTODO\b",
    r"\bstub\b",
    r"\bshit\b",
    r"\bfuck\b",
]

STALE_RECORDS = {
    "20415918": "older EGA record; current EGA is 20419105",
    "20416682": "older EGA record; current EGA is 20419105",
    "20416798": "older EGA record; current EGA is 20419105",
    "20416974": "older EGA record; current EGA is 20419105",
    "20415860": "older SGA record; current SGA is 20419350",
    "20417172": "older SGA record; current SGA is 20419350",
    "20418863": "older SGA record; current SGA is 20419350",
    "20418993": "older SGA record; current SGA is 20419350",
    "20419222": "older SGA record with process-note reader covers; current SGA is 20419350",
    "20415659": "older non-European consolidated record; current record is 20419356",
    "20418877": "older non-European consolidated record with process-note reader covers; current record is 20419356",
    "20415752": "older Chinese mathematical classics record; current record is 20419428",
    "20415755": "older Indian/Sanskrit mathematical classics record; current record is 20419441",
    "20415770": "older Islamic/Arabic mathematical texts record; current record is 20419446",
    "20415777": "older historical reference texts record; current record is 20419448",
    "20421647": "previous Chinese focused slice; current record is 20435670",
    "20421650": "previous Indian/Sanskrit focused slice; current record is 20435677",
    "20421656": "previous Islamic/Arabic focused slice; current record is 20435687",
    "20421657": "previous historical reference slice; current record is 20435690",
    "20416135": "older Weber record; current Weber is 20418861",
    "20416137": "older Noether record; current Noether is 20418862",
    "20416544": "older author-cluster record; current author cluster is 20416839",
    "20415432": "older author-cluster record; current author cluster is 20416839",
    "20416739": "older author-cluster record; current author cluster is 20416839",
    "20432146": "older EGA record; current EGA is 20434859",
    "20432263": "older SGA record; current SGA is 20455791",
    "20434868": "previous SGA record; current SGA is 20455791",
    "20436795": "previous SGA record; current SGA is 20455791",
    "20432922": "older non-European consolidated record; current record is 20455873",
    "20431945": "older Weber record; current Weber is 20436635",
    "20431948": "older Noether record; current Noether is 20436637",
    "20431305": "older Riemann record; current Riemann is 20434317",
    "20430709": "older main landing version; current main is 20436971",
    "20415117": "older main landing version; current main is 20436971",
}


def strip_html(value: str) -> str:
    value = re.sub(r"<[^>]+>", " ", value)
    value = unescape(value)
    value = re.sub(r"\s+", " ", value).strip()
    return value


def fetch_record(record_id: int) -> dict[str, Any]:
    url = f"https://zenodo.org/api/records/{record_id}"
    response = requests.get(url, timeout=60)
    response.raise_for_status()
    return response.json()


def find_hits(text: str) -> list[str]:
    hits: list[str] = []
    for pattern in BAD_PATTERNS:
        if re.search(pattern, text):
            hits.append(pattern)
    for rec_id, meaning in STALE_RECORDS.items():
        if rec_id in text:
            hits.append(f"stale:{rec_id} ({meaning})")
    return hits


def file_role(name: str) -> str:
    lower = name.lower()
    if lower.endswith(".pdf"):
        if lower.startswith(("00 ", "01 ", "02 ", "03 ", "04 ", "05 ", "06 ", "07 ", "08 ", "09 ", "10 ", "11 ", "12 ", "13 ", "14 ", "15 ", "16 ", "17 ", "20 ", "21 ", "22 ", "23 ", "24 ", "25 ", "26 ", "27 ", "28 ", "29 ", "30 ", "31 ", "32 ")):
            return "reader/reference PDF"
        return "PDF"
    if lower.endswith(".zip"):
        return "artifact/source ZIP"
    if lower.endswith((".json", ".md", ".txt", ".csv")):
        return "manifest/status"
    return "other"


def audit_record(label: str, record: dict[str, Any]) -> dict[str, Any]:
    md = record.get("metadata", {})
    files = record.get("files", [])
    title = md.get("title", "")
    description = md.get("description", "")
    notes = md.get("notes", "")
    keywords = " ".join(md.get("keywords", []) or [])
    metadata_text = "\n".join([title, strip_html(description), notes, keywords])

    file_rows = []
    file_hits = []
    for item in files:
        key = item.get("key") or item.get("filename") or ""
        size = int(item.get("size") or item.get("filesize") or 0)
        role = file_role(key)
        hits = find_hits(key)
        if hits:
            file_hits.append({"file": key, "hits": hits})
        file_rows.append({"key": key, "size": size, "role": role})

    pdf_count = sum(1 for f in file_rows if f["key"].lower().endswith(".pdf"))
    zip_count = sum(1 for f in file_rows if f["key"].lower().endswith(".zip"))
    top_pdf_count = sum(1 for f in file_rows if f["key"].lower().endswith(".pdf") and re.match(r"^\d\d ", f["key"]))
    total_mb = round(sum(f["size"] for f in file_rows) / 1024 / 1024, 2)
    metadata_hits = find_hits(metadata_text)
    title_quality = "ok"
    if any(term in title.lower() for term in ["kimi", "cleanup", "batch", "handoff", "drop"]):
        title_quality = "internal"
    elif len(title) > 180:
        title_quality = "long"

    return {
        "label": label,
        "id": record.get("id"),
        "doi": record.get("doi"),
        "url": record.get("links", {}).get("self_html") or f"https://zenodo.org/records/{record.get('id')}",
        "title": title,
        "version": md.get("version", ""),
        "file_count": len(file_rows),
        "pdf_count": pdf_count,
        "top_pdf_count": top_pdf_count,
        "zip_count": zip_count,
        "total_mb": total_mb,
        "metadata_hits": metadata_hits,
        "file_hits": file_hits,
        "title_quality": title_quality,
        "first_files": [f["key"] for f in file_rows[:8]],
        "files": file_rows,
    }


def main() -> int:
    REPORTS.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    audits = []
    for label, record_id in RECORDS.items():
        audits.append(audit_record(label, fetch_record(record_id)))

    json_path = REPORTS / f"public_archive_readability_audit_{stamp}.json"
    json_path.write_text(json.dumps(audits, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = [
        "# Public Archive Readability Audit",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        "",
        "## Summary",
        "",
        "| Label | Record | Files | PDFs | ZIPs | MB | Metadata Flags | File Flags |",
        "|---|---:|---:|---:|---:|---:|---|---|",
    ]
    for audit in audits:
        meta_flags = ", ".join(audit["metadata_hits"]) if audit["metadata_hits"] else "none"
        file_flags = str(len(audit["file_hits"])) if audit["file_hits"] else "0"
        lines.append(
            f"| {audit['label']} | [{audit['id']}]({audit['url']}) | {audit['file_count']} | "
            f"{audit['pdf_count']} | {audit['zip_count']} | {audit['total_mb']} | {meta_flags} | {file_flags} |"
        )

    flagged = [a for a in audits if a["metadata_hits"] or a["file_hits"]]
    lines.extend(["", "## Flagged Details", ""])
    if not flagged:
        lines.append("No public metadata or filename flags found for the configured internal/stale patterns.")
    else:
        for audit in flagged:
            lines.append(f"### {audit['label']} ({audit['id']})")
            if audit["metadata_hits"]:
                lines.append("- Metadata flags: " + ", ".join(audit["metadata_hits"]))
            if audit["file_hits"]:
                for hit in audit["file_hits"][:30]:
                    lines.append(f"- File flag: `{hit['file']}` -> {', '.join(hit['hits'])}")
                if len(audit["file_hits"]) > 30:
                    lines.append(f"- Additional file flags omitted: {len(audit['file_hits']) - 30}")
            lines.append("")

    lines.extend(["## First Files", ""])
    for audit in audits:
        lines.append(f"### {audit['label']} ({audit['id']})")
        for key in audit["first_files"]:
            lines.append(f"- `{key}`")
        lines.append("")

    md_path = REPORTS / f"public_archive_readability_audit_{stamp}.md"
    md_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")

    print(json.dumps({"json": str(json_path), "markdown": str(md_path), "records": len(audits), "flagged_records": len(flagged)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())



