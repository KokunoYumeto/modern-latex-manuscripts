#!/usr/bin/env python3
"""Stage a Deligne-specific Zenodo satellite record.

The record is intentionally self-contained: 90 original-language/typeset paper
PDFs are exposed as individual top-level files, while English translations,
TeX/source, reports, render checks, and prior batch ZIPs are kept in one
artifact ZIP. A combined English-ready PDF is exposed at top level so the
translation work is visible without exceeding Zenodo's practical file limit.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
PAPORS = Path.home() / "Documents" / "Papors"
SOURCE_ROOT = PAPORS / "Chatnotes" / "CHat translates and clean"
DELIGNBE = SOURCE_ROOT / "Delignbe"
TRANS = SOURCE_ROOT / "translations" / "Deligne"
OUT_ROOT = PROJECT_ROOT / "release_candidates" / "zenodo_satellite_deligne_papers_translations"
UPLOAD = OUT_ROOT / "upload"
REPORTS = OUT_ROOT / "reports"
STAGING = OUT_ROOT / "staging"
ARTIFACT_STAGE = STAGING / "deligne_artifacts"
ZENODO = PROJECT_ROOT / "zenodo"

ORIGINAL_001_029 = TRANS / "deligne_batch06_first29_cleanup_and_translation_package" / "cleaned_original_language_pdfs_001_029"
ORIGINAL_030_090 = DELIGNBE / "del 2 and 3 cleanup" / "stable_recombined_paper_pdfs_30_90"
MUTOOL = Path.home() / "AppData" / "Local" / "Microsoft" / "WinGet" / "Packages" / "ArtifexSoftware.mutool_Microsoft.Winget.Source_8wekyb3d8bbwe" / "mupdf-1.23.0-windows" / "mutool.exe"

MAIN_CONCEPT_DOI = "10.5281/zenodo.20393488"
MAIN_RECORD_URL = "https://zenodo.org/records/20441732"


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def reset_dir(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = (PROJECT_ROOT / "release_candidates").resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fields is None:
        fields = sorted({key for row in rows for key in row})
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def copy_file(src: Path, dest: Path) -> Path:
    if not src.exists():
        raise FileNotFoundError(src)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    return dest


def assert_zip_ok(path: Path) -> None:
    with zipfile.ZipFile(path, "r") as zf:
        bad = zf.testzip()
    if bad:
        raise RuntimeError(f"Bad zip member in {path}: {bad}")


def zip_dir(src_dir: Path, dest_zip: Path) -> Path:
    dest_zip.parent.mkdir(parents=True, exist_ok=True)
    if dest_zip.exists():
        dest_zip.unlink()
    with zipfile.ZipFile(dest_zip, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for path in sorted(src_dir.rglob("*"), key=lambda p: str(p).lower()):
            if path.is_file():
                zf.write(path, str(path.relative_to(src_dir)).replace("\\", "/"))
    assert_zip_ok(dest_zip)
    return dest_zip


def safe_name(text: str, max_len: int = 135) -> str:
    text = text.replace("œ", "oe").replace("é", "e").replace("è", "e").replace("à", "a")
    text = text.replace("ç", "c").replace("ô", "o").replace("û", "u").replace("î", "i")
    text = re.sub(r"[^A-Za-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_").lower()
    return text[:max_len].strip("_")


def public_title_from_stem(stem: str, max_len: int = 30) -> tuple[int | None, str]:
    match = re.match(r"^(\d{1,2})[_ -](.+)$", stem)
    number = int(match.group(1)) if match else None
    title = match.group(2) if match else stem
    title = title.replace("_", " ").replace("  ", " ")
    title = title.replace("Kaehler", "Kahler")
    title = re.sub(r"\s+", " ", title).strip(" .-_")
    if len(title) > max_len:
        title = title[:max_len].rstrip(" ,;:-_.")
    return number, title


def public_pdf_dest(src: Path, prefix: str) -> str:
    stem = src.stem
    number, title = public_title_from_stem(stem)
    suffix = "Original.pdf" if prefix == "original_language" else "Working.pdf"
    if number is not None:
        return f"10-{number:03d} Deligne - {title} - {suffix}"
    return f"10 Deligne - {title} - {suffix}"


def collect_original_papers() -> list[Path]:
    files = []
    for root in [ORIGINAL_001_029, ORIGINAL_030_090]:
        if not root.exists():
            raise FileNotFoundError(root)
        files.extend(sorted(root.glob("*.pdf"), key=lambda p: p.name.lower()))
    return sorted(files, key=lambda p: p.name.lower())


def collect_unique_english_pdfs() -> list[Path]:
    # Prefer paths in the nested "Deligne" cumulative tree where present, since
    # that is the freshest batch-12 view; fall back to the root translation tree.
    candidate_roots = [
        TRANS / "Deligne",
        TRANS,
    ]
    include_re = re.compile(
        r"(completed_translations_pdf|completed_translations[\\/]+pdf|working_full_translations|english_originals_already_in_english_pdf)",
        re.IGNORECASE,
    )
    by_name: dict[str, Path] = {}
    for root in candidate_roots:
        if not root.exists():
            continue
        for pdf in root.rglob("*.pdf"):
            if not include_re.search(str(pdf)):
                continue
            old = by_name.get(pdf.name)
            if old is None:
                by_name[pdf.name] = pdf
                continue
            # Prefer the duplicate with the newest timestamp; if tied, the larger
            # one usually preserves more metadata/text.
            if (pdf.stat().st_mtime, pdf.stat().st_size) > (old.stat().st_mtime, old.stat().st_size):
                by_name[pdf.name] = pdf
    return sorted(by_name.values(), key=lambda p: p.name.lower())


def collect_unique_english_tex() -> list[Path]:
    include_re = re.compile(
        r"(completed_translations_tex|completed_translations[\\/]+tex|working_full_translations|working_literal_english_layer|literal_working_draft)",
        re.IGNORECASE,
    )
    by_rel: dict[str, Path] = {}
    for root in [TRANS / "Deligne", TRANS]:
        if not root.exists():
            continue
        for tex in root.rglob("*.tex"):
            if include_re.search(str(tex)):
                key = tex.name
                old = by_rel.get(key)
                if old is None or (tex.stat().st_mtime, tex.stat().st_size) > (old.stat().st_mtime, old.stat().st_size):
                    by_rel[key] = tex
    return sorted(by_rel.values(), key=lambda p: p.name.lower())


def maybe_copy_tree(src: Path, dest: Path, patterns: set[str] | None = None) -> None:
    if not src.exists():
        return
    if src.is_file():
        copy_file(src, dest / src.name)
        return
    for path in sorted(src.rglob("*"), key=lambda p: str(p).lower()):
        if not path.is_file():
            continue
        if patterns and path.suffix.lower() not in patterns:
            continue
        rel = path.relative_to(src)
        copy_file(path, dest / rel)


def merge_english_pdf(english_pdfs: list[Path], dest: Path) -> None:
    if not english_pdfs:
        return
    if not MUTOOL.exists():
        raise FileNotFoundError(f"mutool not found at {MUTOOL}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        dest.unlink()
    args = [str(MUTOOL), "merge", "-o", str(dest), *[str(p) for p in english_pdfs]]
    subprocess.run(args, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)


def stage_artifacts(english_pdfs: list[Path], english_tex: list[Path]) -> Path:
    for path in english_pdfs:
        copy_file(path, ARTIFACT_STAGE / "english_ready_individual_pdfs" / path.name)
    for path in english_tex:
        copy_file(path, ARTIFACT_STAGE / "english_translation_tex" / path.name)

    for root in [
        TRANS / "reports",
        TRANS / "Deligne" / "reports",
        TRANS / "deligne_batch06_first29_cleanup_and_translation_package" / "reports",
        TRANS / "Deligne" / "deligne_translation_batch12" / "reports",
        DELIGNBE / "1" / "logs",
        DELIGNBE / "del 3rd with 1st 29 papers" / "deligne_kimi_papers_001_029_recombined_qc" / "reports",
    ]:
        maybe_copy_tree(root, ARTIFACT_STAGE / "reports" / safe_name(root.name or "reports"), {".csv", ".json", ".jsonl", ".md", ".txt", ".log"})

    for root, dest_name in [
        (DELIGNBE / "del 3rd with 1st 29 papers" / "deligne_kimi_papers_001_029_recombined_qc" / "source_tex", "source_tex_papers_001_029"),
        (DELIGNBE / "del 2 and 3 cleanup" / "source_tex_cleaned_pass2", "source_tex_papers_030_090"),
        (TRANS / "source", "translation_source_extracts"),
    ]:
        maybe_copy_tree(root, ARTIFACT_STAGE / dest_name, {".tex", ".txt", ".md", ".csv", ".json", ".log"})

    for root in [
        DELIGNBE / "1" / "pdf_letters",
        DELIGNBE / "del 2 and 3 cleanup" / "stable_recombined_letter_pdfs",
    ]:
        maybe_copy_tree(root, ARTIFACT_STAGE / "letters_reference_pdfs", {".pdf"})

    # Preserve compact historical batch packages, avoiding exact duplicate "(1)" files.
    seen_hashes: set[str] = set()
    for root in [TRANS, DELIGNBE]:
        if not root.exists():
            continue
        for zip_path in sorted(root.rglob("*.zip"), key=lambda p: str(p).lower()):
            digest = sha256(zip_path)
            if digest in seen_hashes:
                continue
            seen_hashes.add(digest)
            copy_file(zip_path, ARTIFACT_STAGE / "prior_batch_zip_packages" / zip_path.name)

    return zip_dir(ARTIFACT_STAGE, UPLOAD / "90 Deligne - TeX Sources, Translation PDFs, Reports, and Provenance.zip")


def upload_manifest() -> list[dict[str, Any]]:
    rows = []
    for path in sorted(UPLOAD.iterdir(), key=lambda p: p.name.lower()):
        if path.is_file():
            rows.append({"filename": path.name, "bytes": path.stat().st_size, "sha256": sha256(path), "path": str(path)})
    write_csv(REPORTS / "deligne_satellite_upload_manifest.csv", rows, ["filename", "bytes", "sha256", "path"])
    write_text(REPORTS / "deligne_satellite_upload_files.txt", "\n".join(row["path"] for row in rows) + "\n")
    return rows


def write_metadata(summary: dict[str, Any]) -> Path:
    description = f"""
<p>Dedicated Deligne record for the Modern LaTeX Editions of Public-Domain Mathematics Manuscripts project. This page is separate from the main corpus so that Deligne material can be cited, revised, or removed independently without disturbing the rest of the archive.</p>
<p>The top-level files are reader-facing: one combined English translation draft PDF, followed by 90 individually downloadable original-language reference PDFs with human-readable paper titles. The artifact ZIP contains the individual English PDFs, TeX/source files, reports, render checks where present, letters/reference PDFs, and compact provenance packages used to build this release.</p>
<p><strong>Status at a glance.</strong> <code>[##########] 90/90</code> original-language paper PDFs staged; <code>[#####-----] {summary["english_ready_pdf_count"]}/90</code> English-ready or working-English PDFs found locally; <code>[#####-----] 43 complete English-ready, 2 working full translations, 1 partial, 44 not started or rough-only</code> according to the current local status reports. These are working scholarly transcriptions and translation drafts, not proofed critical editions.</p>
<p><strong>Workflow provenance:</strong> public scans and source witnesses are converted into TeX by automated transcription systems, checked and organized locally, then packaged here with source artifacts so readers can inspect, correct, and reuse the work. The public organization is by paper and work status, not by internal run name.</p>
"""
    metadata = {
        "title": "Pierre Deligne Papers: Modern LaTeX Drafts and English Translation Drafts",
        "upload_type": "dataset",
        "publication_date": "2026-05-27",
        "version": "2026-05-27 clean public Deligne record",
        "description": description,
        "creators": [{"name": "Manuscript Typesetting Project", "affiliation": "Independent"}],
        "access_right": "open",
        "license": "cc0-1.0",
        "keywords": [
            "Deligne",
            "LaTeX",
            "algebraic geometry",
            "Hodge theory",
            "Weil conjectures",
            "translation",
            "mathematics",
            "typesetting",
            "OCR",
        ],
        "related_identifiers": [
            {"identifier": MAIN_CONCEPT_DOI, "relation": "isPartOf", "scheme": "doi"},
            {"identifier": MAIN_RECORD_URL, "relation": "isReferencedBy", "scheme": "url"},
        ],
        "notes": "Standalone Deligne record linked to the main public manuscript corpus. Top-level PDFs are reader-facing; source TeX, individual English PDFs, and provenance material are in the artifact ZIP. Released as CC0/public-domain dedication to the extent possible.",
    }
    path = ZENODO / "metadata_satellite_deligne_papers_translations.json"
    write_json(path, metadata)
    return path


def main() -> int:
    reset_dir(OUT_ROOT)
    UPLOAD.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    ARTIFACT_STAGE.mkdir(parents=True, exist_ok=True)

    original_pdfs = collect_original_papers()
    english_pdfs = collect_unique_english_pdfs()
    english_tex = collect_unique_english_tex()

    if len(original_pdfs) != 90:
        raise RuntimeError(f"Expected 90 Deligne original paper PDFs, found {len(original_pdfs)}")

    top_rows = []
    for src in original_pdfs:
        dest_name = public_pdf_dest(src, "original_language")
        dest = copy_file(src, UPLOAD / dest_name)
        _, title = public_title_from_stem(src.stem)
        top_rows.append({"kind": "original_language", "source_file": src.name, "title": title, "filename": dest.name, "bytes": dest.stat().st_size})

    for src in english_pdfs:
        copy_file(src, ARTIFACT_STAGE / "english_ready_individual_pdfs" / src.name)
    combined_english = UPLOAD / "00 Deligne - English Translation Drafts Combined.pdf"
    merge_english_pdf(english_pdfs, combined_english)
    top_rows.append({"kind": "combined_english_ready", "source": "merged from individual English PDFs", "filename": combined_english.name, "bytes": combined_english.stat().st_size})

    artifact = stage_artifacts(english_pdfs, english_tex)

    summary = {
        "generated_at": now_iso(),
        "original_paper_pdf_count": len(original_pdfs),
        "english_ready_pdf_count": len(english_pdfs),
        "english_tex_count": len(english_tex),
        "top_level_files_before_metadata": len([p for p in UPLOAD.iterdir() if p.is_file()]),
        "artifact_zip": artifact.name,
        "top_level_pdfs": top_rows,
        "source_note": "Absolute local working paths are omitted from the public summary; see local build reports for machine-specific provenance.",
    }
    write_json(REPORTS / "deligne_satellite_summary.json", summary)
    copy_file(REPORTS / "deligne_satellite_summary.json", UPLOAD / "99 Deligne - Public Summary.json")
    metadata_path = write_metadata(summary)
    rows = upload_manifest()
    final = {"upload": str(UPLOAD), "metadata": str(metadata_path), "upload_file_count": len(rows), "summary": summary}
    write_json(OUT_ROOT / "deligne_satellite_staging_result.json", final)
    print(json.dumps(final, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

