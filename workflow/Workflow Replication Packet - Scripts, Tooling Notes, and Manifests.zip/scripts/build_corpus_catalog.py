from __future__ import annotations

import csv
import json
import re
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
INVENTORY = PROJECT_ROOT / "inventory"
CATALOG = PROJECT_ROOT / "catalog"


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def text_sample(path: Path, max_bytes: int = 2_000_000) -> str:
    try:
        with path.open("rb") as handle:
            data = handle.read(max_bytes)
        return data.decode("utf-8", errors="ignore")
    except OSError:
        return ""


def clean_latex_text(value: str) -> str:
    value = re.sub(r"\\[a-zA-Z]+", "", value)
    value = value.replace("{", "").replace("}", "")
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def first_latex_command(sample: str, command: str) -> str:
    match = re.search(r"\\" + re.escape(command) + r"(?:\[[^\]]*\])?\{([^{}]{1,500})\}", sample, re.S)
    if not match:
        return ""
    return clean_latex_text(match.group(1))


def classify_kind(row: dict[str, str]) -> str:
    ext = row.get("extension", "").lower()
    path = row.get("full_path", "").lower()
    if "texlive" in path or "miktex" in path or "\\texmf" in path or "/texmf" in path:
        return "tooling"
    if ext == ".pdf":
        return "pdf"
    if ext == ".tex":
        return "tex"
    if ext in {".png", ".tif", ".tiff", ".jpg", ".jpeg", ".djvu"}:
        return "scan_or_image"
    if ext in {".zip", ".rar", ".7z", ".tar", ".gz", ".tgz"}:
        return "archive"
    if ext in {".txt", ".md", ".csv", ".json", ".jsonl"}:
        return "text_or_metadata"
    if ext in {".aux", ".log", ".out", ".toc", ".fls", ".fdb_latexmk"}:
        return "latex_build_artifact"
    if ext in {".exe", ".dll", ".bat", ".ps1", ".sh", ".pl", ".pm", ".py", ".lua", ".tcl"}:
        return "tooling"
    return "other"


def rights_status(row: dict[str, str]) -> tuple[str, str]:
    full = row.get("full_path", "")
    rel = row.get("relative_path", "")
    corpus = row.get("corpus", "")
    path = f"{full} {rel} {corpus}".lower()
    ext = row.get("extension", "").lower()

    if (
        "deligne" in path
        or "delignbe" in path
        or "kimi_agent_swarm_del" in path
        or "agent swarm stoef\\del" in path
        or "agent swarm stoef/del" in path
        or "kimi_agent_convert_papers_to_latex" in path
    ):
        return "hold", "deligne_material_user_excluded"

    collected_terms = [
        "schur",
        "gesammelte",
        "abhandlungen",
        "collected",
        "collected_papers",
        "frobenius",
        "oka_collected",
    ]
    if any(term in path for term in collected_terms):
        if ext == ".pdf":
            return "hold", "possible_copyrighted_collected_volume_pdf"
        if ext in {".zip", ".rar", ".7z"}:
            return "needs_review", "possible_collected_volume_bundle"
        return "needs_review", "possible_collected_volume_derivative_or_scan"

    if classify_kind(row) == "tooling":
        return "skip", "tooling_not_release_content"
    if classify_kind(row) == "latex_build_artifact":
        return "skip", "latex_build_artifact"
    return "candidate", "rights_review_required_before_upload"


def release_role(row: dict[str, str], tex_root: bool = False) -> str:
    kind = classify_kind(row)
    if kind == "pdf":
        return "public_pdf_or_scan_pdf_candidate"
    if kind == "tex":
        return "latex_source_candidate" if tex_root else "latex_component"
    if kind == "scan_or_image":
        return "source_scan_or_page_image"
    if kind == "archive":
        return "source_or_work_package_archive"
    if kind == "text_or_metadata":
        return "metadata_translation_or_notes"
    return kind


def pdf_pages(path: Path) -> tuple[str, str]:
    try:
        result = subprocess.run(
            ["pdfinfo", str(path)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=20,
            encoding="utf-8",
            errors="replace",
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return "", f"pdfinfo_failed: {exc}"
    if result.returncode != 0:
        message = result.stderr.strip().splitlines()
        return "", "pdfinfo_failed: " + (message[0] if message else f"exit {result.returncode}")
    for line in result.stdout.splitlines():
        if line.lower().startswith("pages:"):
            return line.split(":", 1)[1].strip(), "ok"
    return "", "pdfinfo_no_pages"


def tex_root_info(row: dict[str, str]) -> dict[str, object] | None:
    path = Path(row["full_path"])
    sample = text_sample(path)
    if not sample:
        return None
    has_documentclass = bool(re.search(r"\\documentclass(?:\[[^\]]*\])?\{", sample))
    has_begin_document = "\\begin{document}" in sample
    has_input = bool(re.search(r"\\(?:input|include)\{", sample))
    if not (has_documentclass or has_begin_document):
        return None

    status, reason = rights_status(row)
    score = 0
    score += 3 if has_documentclass else 0
    score += 3 if has_begin_document else 0
    score += 1 if first_latex_command(sample, "title") else 0
    score -= 2 if classify_kind(row) == "tooling" else 0

    return {
        "scope": row.get("scope", ""),
        "corpus": row.get("corpus", ""),
        "full_path": row.get("full_path", ""),
        "relative_path": row.get("relative_path", ""),
        "bytes": row.get("bytes", ""),
        "sha256": row.get("sha256", ""),
        "has_documentclass": has_documentclass,
        "has_begin_document": has_begin_document,
        "has_input_or_include": has_input,
        "root_score": score,
        "title_guess": first_latex_command(sample, "title"),
        "author_guess": first_latex_command(sample, "author"),
        "rights_status": status,
        "rights_reason": reason,
        "file_kind": classify_kind(row),
        "release_role": release_role(row, tex_root=True),
    }


def main() -> int:
    CATALOG.mkdir(parents=True, exist_ok=True)
    rows = []
    for name in ["source_files.csv", "copied_files.csv", "extracted_files.csv"]:
        for row in read_csv(INVENTORY / name):
            row = dict(row)
            row["inventory_file"] = name
            rows.append(row)

    working_rows = [row for row in rows if row.get("scope") in {"source_copy", "archives_extracted"}]
    all_catalog_rows: list[dict[str, object]] = []
    for row in working_rows:
        status, reason = rights_status(row)
        all_catalog_rows.append(
            {
                "scope": row.get("scope", ""),
                "corpus": row.get("corpus", ""),
                "full_path": row.get("full_path", ""),
                "relative_path": row.get("relative_path", ""),
                "extension": row.get("extension", ""),
                "bytes": row.get("bytes", ""),
                "sha256": row.get("sha256", ""),
                "hash_status": row.get("hash_status", ""),
                "file_kind": classify_kind(row),
                "release_role": release_role(row),
                "rights_status": status,
                "rights_reason": reason,
            }
        )

    catalog_fields = [
        "scope",
        "corpus",
        "full_path",
        "relative_path",
        "extension",
        "bytes",
        "sha256",
        "hash_status",
        "file_kind",
        "release_role",
        "rights_status",
        "rights_reason",
    ]
    write_csv(CATALOG / "all_working_files_catalog.csv", all_catalog_rows, catalog_fields)

    by_hash: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        sha = row.get("sha256", "")
        if sha and row.get("hash_status") == "hashed":
            by_hash[sha].append(row)

    duplicate_rows: list[dict[str, object]] = []
    duplicate_group_id = 0
    for sha, group in sorted(by_hash.items(), key=lambda item: (-len(item[1]), item[0])):
        if len(group) < 2:
            continue
        duplicate_group_id += 1
        scopes = sorted({item.get("scope", "") for item in group})
        corpora = sorted({item.get("corpus", "") for item in group})
        extensions = sorted({item.get("extension", "") or "[none]" for item in group})
        sample_paths = " | ".join(item.get("full_path", "") for item in group[:12])
        duplicate_rows.append(
            {
                "duplicate_group_id": duplicate_group_id,
                "sha256": sha,
                "count": len(group),
                "bytes_each": group[0].get("bytes", ""),
                "scopes": "; ".join(scopes),
                "corpora": "; ".join(corpora),
                "extensions": "; ".join(extensions),
                "sample_paths": sample_paths,
            }
        )
    write_csv(
        CATALOG / "duplicate_hash_groups.csv",
        duplicate_rows,
        [
            "duplicate_group_id",
            "sha256",
            "count",
            "bytes_each",
            "scopes",
            "corpora",
            "extensions",
            "sample_paths",
        ],
    )

    pdf_rows: list[dict[str, object]] = []
    for row in working_rows:
        if row.get("extension", "").lower() != ".pdf":
            continue
        status, reason = rights_status(row)
        pages, page_status = pdf_pages(Path(row["full_path"]))
        pdf_rows.append(
            {
                "scope": row.get("scope", ""),
                "corpus": row.get("corpus", ""),
                "full_path": row.get("full_path", ""),
                "relative_path": row.get("relative_path", ""),
                "bytes": row.get("bytes", ""),
                "pages": pages,
                "page_status": page_status,
                "sha256": row.get("sha256", ""),
                "rights_status": status,
                "rights_reason": reason,
                "release_role": release_role(row),
            }
        )
    write_csv(
        CATALOG / "pdf_catalog.csv",
        pdf_rows,
        [
            "scope",
            "corpus",
            "full_path",
            "relative_path",
            "bytes",
            "pages",
            "page_status",
            "sha256",
            "rights_status",
            "rights_reason",
            "release_role",
        ],
    )

    tex_rows: list[dict[str, object]] = []
    for row in working_rows:
        if row.get("extension", "").lower() != ".tex":
            continue
        info = tex_root_info(row)
        if info:
            tex_rows.append(info)
    tex_rows.sort(key=lambda item: (-int(item["root_score"]), str(item["rights_status"]), str(item["full_path"])))
    write_csv(
        CATALOG / "tex_roots.csv",
        tex_rows,
        [
            "scope",
            "corpus",
            "full_path",
            "relative_path",
            "bytes",
            "sha256",
            "has_documentclass",
            "has_begin_document",
            "has_input_or_include",
            "root_score",
            "title_guess",
            "author_guess",
            "rights_status",
            "rights_reason",
            "file_kind",
            "release_role",
        ],
    )

    release_seed = [
        row
        for row in all_catalog_rows
        if row["rights_status"] in {"candidate", "needs_review"}
        and row["file_kind"] in {"pdf", "tex", "scan_or_image", "archive", "text_or_metadata"}
    ]
    write_csv(CATALOG / "release_candidate_seed.csv", release_seed, catalog_fields)

    status_counts = Counter(row["rights_status"] for row in all_catalog_rows)
    kind_counts = Counter(row["file_kind"] for row in all_catalog_rows)
    release_counts = Counter(row["release_role"] for row in all_catalog_rows)
    summary = {
        "generated_at": datetime.now().isoformat(),
        "project_root": str(PROJECT_ROOT),
        "working_file_rows": len(working_rows),
        "duplicate_hash_groups": len(duplicate_rows),
        "pdf_rows": len(pdf_rows),
        "tex_root_candidates": len(tex_rows),
        "release_seed_rows": len(release_seed),
        "rights_status_counts": dict(status_counts),
        "file_kind_counts": dict(kind_counts),
        "release_role_counts": dict(release_counts),
    }
    (CATALOG / "catalog_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    readme = f"""# Corpus Catalog

Generated: {summary['generated_at']}

This catalog is built from the copied source trees and extracted archive contents.

- all_working_files_catalog.csv: classified working files with rights-review seed labels.
- duplicate_hash_groups.csv: exact duplicate groups by SHA-256.
- pdf_catalog.csv: PDF inventory with page counts from pdfinfo where available.
- tex_roots.csv: likely standalone LaTeX roots.
- release_candidate_seed.csv: first-pass material that may belong in a public release after review.
- catalog_summary.json: aggregate counts.

Rights labels are conservative triage labels, not legal determinations.
"""
    (CATALOG / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
