#!/usr/bin/env python3
"""Stage a public-facing EGA Zenodo record.

The staged record is organized for readers rather than for internal workflow:
top-level PDFs are the current English working draft and coherent French
original/reference volumes; source TeX and provenance notes are in ZIP
artifacts.
"""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from datetime import date, datetime
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUT = PROJECT_ROOT / "release_candidates" / "zenodo_satellite_ega_working_translation_public_current"
ZENODO = PROJECT_ROOT / "zenodo"
EGA_REPO = Path.home() / "Downloads" / "EGA" / "ryankeleti_ega"
NUMDAM_EGA = Path.home() / "Downloads" / "EGA" / "NUMDAM" / "PMIHES_EGA"
NUMDAM_ROOT = Path.home() / "Downloads" / "EGA" / "NUMDAM"
MAIN_CONCEPT_DOI = "10.5281/zenodo.20393488"
MAIN_RECORD_URL = "https://zenodo.org/records/20441732"
EGA_PDF = EGA_REPO / "book.pdf"
if not EGA_PDF.exists():
    EGA_PDF = EGA_REPO / "pdfs" / "book.pdf"


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def reset_dir(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = (PROJECT_ROOT / "release_candidates").resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def copy_file(src: Path, dest: Path) -> Path:
    if not src.exists():
        raise FileNotFoundError(src)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    return dest


def run_text(args: list[str], timeout: int = 120) -> str:
    proc = subprocess.run(args, capture_output=True, text=True, errors="replace", check=False, timeout=timeout)
    return proc.stdout if proc.returncode == 0 else ""


def pdf_pages(path: Path) -> int:
    out = run_text(["pdfinfo", str(path)], timeout=60)
    m = re.search(r"^Pages:\s+(\d+)", out, flags=re.M)
    return int(m.group(1)) if m else 0


def zip_dir(src: Path, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        dest.unlink()
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for path in sorted(src.rglob("*"), key=lambda p: str(p).lower()):
            if path.is_file():
                zf.write(path, str(path.relative_to(src)).replace("\\", "/"))
    with zipfile.ZipFile(dest, "r") as zf:
        bad = zf.testzip()
    if bad:
        raise RuntimeError(f"Bad zip member in {dest}: {bad}")
    return dest


def file_row(path: Path, role: str) -> dict[str, Any]:
    return {
        "filename": path.name,
        "role": role,
        "pages": pdf_pages(path) if path.suffix.lower() == ".pdf" else "",
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def copy_source_tree(dest: Path) -> None:
    allowed_suffixes = {".tex", ".bib", ".md", ".yml", ".sh", ".py", ".txt", ".sty"}
    allowed_names = {"Makefile", "CONTRIBUTORS"}
    for src in sorted(EGA_REPO.rglob("*"), key=lambda p: str(p).lower()):
        if src.is_dir():
            continue
        rel = src.relative_to(EGA_REPO)
        parts = set(rel.parts)
        if ".git" in parts:
            continue
        if src.name.endswith(".bak") or src.suffix.lower() in {".aux", ".log", ".out", ".toc", ".blg", ".bbl"}:
            continue
        if src.name.startswith("codex_") or src.name.startswith("ega_book_") or src.name == "texput.log":
            continue
        if rel.parts and rel.parts[0] == "pdfs" and src.suffix.lower() == ".pdf":
            continue
        if src.suffix.lower() in allowed_suffixes or src.name in allowed_names:
            copy_file(src, dest / rel)


def main() -> int:
    reset_dir(OUT)
    upload = OUT / "upload"
    work = OUT / "work"
    reports = OUT / "reports"
    upload.mkdir(parents=True, exist_ok=True)
    work.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)

    rows: list[dict[str, Any]] = []

    top_files = [
        (EGA_PDF, "00 EGA - English Translation Working Draft.pdf", "Current compiled English translation working draft, including community base material, local EGA 0_IV continuation, and current EGA IV main-text continuation"),
        (NUMDAM_EGA / "EGA_I_PMIHES_tome4_1960.pdf", "10 EGA I - French Original (NUMDAM PMIHES 4, 1960).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_II_PMIHES_tome8_1961.pdf", "11 EGA II - French Original (NUMDAM PMIHES 8, 1961).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_III-1_PMIHES_tome11_1961.pdf", "12 EGA III Part 1 - French Original (NUMDAM PMIHES 11, 1961).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_III-2_PMIHES_tome17_1963.pdf", "13 EGA III Part 2 - French Original (NUMDAM PMIHES 17, 1963).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_IV-1_PMIHES_tome20_1964.pdf", "14 EGA IV Part 1 - French Original (NUMDAM PMIHES 20, 1964).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_IV-2_PMIHES_tome24_1965.pdf", "15 EGA IV Part 2 - French Original (NUMDAM PMIHES 24, 1965).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_IV-3_PMIHES_tome28_1966.pdf", "16 EGA IV Part 3 - French Original (NUMDAM PMIHES 28, 1966).pdf", "French original/reference PDF from NUMDAM"),
        (NUMDAM_EGA / "EGA_IV-4_PMIHES_tome32_1967.pdf", "17 EGA IV Part 4 - French Original (NUMDAM PMIHES 32, 1967).pdf", "French original/reference PDF from NUMDAM"),
    ]
    for src, name, role in top_files:
        rows.append(file_row(copy_file(src, upload / name), role))

    new_tex = work / "ega_0_iv_translation_tex_supplement"
    new_tex.mkdir(parents=True, exist_ok=True)
    for name in ["ega0.tex", "preamble.tex"]:
        copy_file(EGA_REPO / name, new_tex / name)
    for section in ["15", "16", "17", "18", "19", "20", "21", "22", "23"]:
        copy_file(EGA_REPO / "ega0" / f"ega0-{section}.tex", new_tex / "ega0" / f"ega0-{section}.tex")
    new_tex_readme = """# EGA 0_IV translation TeX supplement

This ZIP contains the local continuation files for EGA 0_IV sections 15 through
23, plus the integration file `ega0.tex` and the current preamble needed by the
build.

Status:
- Sections 15 through 23 are substantial working translations.

These are machine-assisted working drafts for checking and continuation, not
proofread critical editions.
"""
    write_text(new_tex / "README.md", new_tex_readme)
    rows.append(file_row(zip_dir(new_tex, upload / "80 EGA - EGA 0 IV Translation TeX Supplement.zip"), "EGA 0_IV sections 15-23 translation TeX supplement"))

    ega4_tex = work / "ega_iv_translation_tex_supplement"
    ega4_tex.mkdir(parents=True, exist_ok=True)
    for name in ["ega4.tex", "preamble.tex"]:
        copy_file(EGA_REPO / name, ega4_tex / name)
    for section in ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21"]:
        copy_file(EGA_REPO / "ega4" / f"ega4-{section}.tex", ega4_tex / "ega4" / f"ega4-{section}.tex")
    ega4_tex_readme = """# EGA IV main-text translation TeX supplement

This ZIP contains the local continuation files for the EGA IV main text.

Status:
- EGA IV sections 1 through 21 are present as substantive working translations
  in the current TeX tree.

These are machine-assisted working drafts for checking and continuation, not
proofread critical editions.
"""
    write_text(ega4_tex / "README.md", ega4_tex_readme)
    rows.append(file_row(zip_dir(ega4_tex, upload / "82 EGA - EGA IV Main Text Translation TeX Supplement.zip"), "EGA IV sections 1-21 translation TeX supplement"))

    full_artifacts = work / "full_ega_artifacts"
    source_tree = full_artifacts / "english_translation_tex_tree"
    copy_source_tree(source_tree)
    copy_file(EGA_PDF, full_artifacts / "compiled_pdf" / "EGA - English Translation Working Draft.pdf")
    for src, name, _role in top_files[1:]:
        copy_file(src, full_artifacts / "french_originals_numdam" / name)
    if (NUMDAM_ROOT / "INDEX.md").exists():
        inventory = (NUMDAM_ROOT / "INDEX.md").read_text(encoding="utf-8", errors="replace")
        inventory = inventory.replace(
            "- SGA volumes — Springer Lecture Notes in Mathematics (not NUMDAM; some on other archives)",
            "- SGA volumes — separate reference sources, not part of the NUMDAM EGA download set",
        )
        write_text(full_artifacts / "source_notes" / "NUMDAM inventory.md", inventory)
    artifact_readme = """# EGA full source and artifact package

This ZIP is the working source package behind the top-level EGA files.

Contents:
- `english_translation_tex_tree/`: current TeX tree based on the public
  `ryankeleti/ega` community translation repository, with local continuation
  files for EGA 0_IV and EGA IV included.
- `compiled_pdf/`: the current compiled English working-draft PDF.
- `french_originals_numdam/`: NUMDAM PMIHES French original/reference PDFs
  for EGA I, II, III.1, III.2, and IV.1 through IV.4.
- `source_notes/`: local inventory/provenance notes for the NUMDAM downloads.

Build note:
The current PDF was built with pdflatex from the TeX tree after incorporating
local EGA 0_IV and EGA IV continuation work. The build completes, but the
upstream/incomplete EGA tree still has many undefined internal cross-references
because EGA III, EGA IV, and parts of the preliminaries remain unfinished.

Licensing/provenance note:
The original French EGA papers are public mathematical literature from PMIHES
and are included here as source/reference witnesses. The English TeX tree is
derived from the public community translation repository and local continuation
work; upstream contributor credits are preserved in the source tree.
"""
    write_text(full_artifacts / "README.md", artifact_readme)
    rows.append(file_row(zip_dir(full_artifacts, upload / "81 EGA - Full TeX Source, French Originals, and Build Artifacts.zip"), "full TeX source, French originals, compiled PDF, and source notes"))

    public_readme = """# Elements de Geometrie Algebrique (EGA): French originals and English translation working draft

This record is a public working package for EGA in the Modern LaTeX Editions of
Public-Domain Mathematics Manuscripts project.

## What is here

- One top-level English translation working-draft PDF.
- Eight top-level French original/reference PDFs from NUMDAM/PMIHES: EGA I,
  EGA II, EGA III parts 1-2, and EGA IV parts 1-4.
- A ZIP containing the EGA 0_IV sections 15 through 23 translation TeX supplement.
- A ZIP containing the current EGA IV main-text translation TeX supplement:
  sections 1 through 21 as substantive working translations.
- A full artifact ZIP containing the current TeX tree, the compiled English
  PDF, the French originals, and source/provenance notes.

## Status at a glance

- French originals from NUMDAM: `[##########]` 8/8 EGA PMIHES volumes present.
- English translation reader: `[####------]` useful working draft; EGA I and
  EGA II are present from the community translation base, with additional EGA
  0_IV and EGA IV material added locally.
- EGA 0_IV local continuation: `[##########]` sections 15 through 23 are present
  as substantive working translations.
- EGA IV local continuation: `[##########]` sections 1 through 21 are present
  as substantive working translations.
- Current quality note: this release refreshes the compiled reader after the
  latest EGA IV continuation edits, including newer section 12 and 13 material.
- Whole EGA completion against the long-term goal: `[#####-----]` the project is
  still far from a complete translated/proofread edition, especially for EGA
  III and later preliminaries.
- Proofreading/final edition status: `[----------]` working draft for checking
  and continuation, not a certified critical edition.

## Provenance

The French source/reference PDFs are from NUMDAM PMIHES. The English TeX tree is
based on the public `ryankeleti/ega` community translation project, with local
continuation work added for EGA 0_IV and EGA IV from the French source PDFs. The broader
workflow uses review sessions to choose and check work, local archive tooling to
download, index, package, and publish, and machine-assisted
transcription/translation passes to produce TeX for human and model review.
"""
    write_text(upload / "90 EGA - README and Status.md", public_readme)

    summary = {
        "generated_at": now_iso(),
        "public_title": "Elements de Geometrie Algebrique (EGA): French Originals and English Translation Working Draft",
        "top_level_files": rows,
        "coverage": {
            "french_originals": "8/8 NUMDAM PMIHES EGA volumes included as top-level PDFs.",
            "english_translation_pdf": f"{pdf_pages(EGA_PDF)}-page working draft compiled locally.",
            "new_ega_0_iv": "Substantive local continuation sections: 15 through 23.",
            "new_ega_iv": "Substantive local continuation sections: IV.1 through IV.21, refreshed after the latest section 12 and 13 continuation edits.",
            "remaining_gaps": "EGA 0_III sections 12-13 are still stubs; EGA III remains substantially incomplete; cross-references, theorem numbering, and mathematical proofreading still need sustained review.",
        },
    }
    write_json(upload / "91 EGA - Public Summary.json", summary)
    write_json(reports / "ega_public_summary.json", summary)

    manifest = []
    for path in sorted(upload.iterdir(), key=lambda p: p.name.lower()):
        if path.is_file():
            manifest.append(file_row(path, "upload file"))
    write_json(reports / "upload_manifest.json", manifest)

    description = (
        "<p>Public EGA record for the Modern LaTeX Editions of Public-Domain Mathematics Manuscripts project. "
        "This page collects coherent French original/reference PDFs for EGA and a current English translation working draft, with TeX/source artifacts in ZIP files.</p>"
        "<p><strong>Human-readable contents.</strong> The top-level files begin with the English working-draft reader, followed by the eight NUMDAM/PMIHES French original/reference PDFs: EGA I, EGA II, EGA III parts 1-2, and EGA IV parts 1-4. "
        "The ZIP artifacts contain the EGA 0_IV sections 15 through 23 translation TeX supplement, the current EGA IV main-text translation supplement, and the full current TeX/source package.</p>"
        "<p><strong>Status at a glance.</strong></p>"
        "<ul>"
        "<li>French originals from NUMDAM: <code>[##########]</code> 8/8 EGA PMIHES volumes present.</li>"
        "<li>English translation reader: <code>[####------]</code> useful working draft; EGA I and EGA II are present from the community translation base, with additional EGA 0_IV and EGA IV material added locally.</li>"
        "<li>EGA 0_IV local continuation: <code>[##########]</code> sections 15 through 23 are present as substantive working translations.</li>"
        "<li>EGA IV local continuation: <code>[##########]</code> sections 1 through 21 are present as substantive working translations.</li>"
        "<li>Current quality note: this release refreshes the compiled reader after the latest EGA IV continuation edits, including newer section 12 and 13 material.</li>"
        "<li>Whole EGA completion against the long-term goal: <code>[#####-----]</code> still far from a complete translated and proofread edition, especially for EGA III and later preliminaries.</li>"
        "<li>Proofreading/final edition status: <code>[----------]</code> working draft for checking and continuation, not a certified critical edition.</li>"
        "</ul>"
        "<p><strong>Provenance.</strong> The French source/reference PDFs are from NUMDAM PMIHES. The English TeX tree is based on the public <code>ryankeleti/ega</code> community translation project, with local continuation work added for EGA 0_IV and EGA IV from the French source PDFs. "
        "The broader workflow uses review sessions to choose and check work, local archive tooling to download, index, package, and publish, and machine-assisted transcription/translation passes to produce TeX for human and model review.</p>"
    )
    metadata = {
        "title": "Elements de Geometrie Algebrique (EGA): French Originals and English Translation Working Draft",
        "upload_type": "dataset",
        "publication_date": date.today().isoformat(),
        "version": f"2026-05-29 {pdf_pages(EGA_PDF)}-page EGA working reader with EGA 0_IV sections 15-23 and EGA IV sections 1-21",
        "description": description,
        "creators": [
            {"name": "Grothendieck, Alexander"},
            {"name": "Dieudonne, Jean"},
            {"name": "EGA Community Translation Project"},
            {"name": "Modern LaTeX Editions Project", "affiliation": "Independent"},
        ],
        "access_right": "open",
        "license": "cc0-1.0",
        "keywords": [
            "EGA",
            "Elements de Geometrie Algebrique",
            "Grothendieck",
            "Dieudonne",
            "algebraic geometry",
            "LaTeX",
            "translation",
            "NUMDAM",
            "PMIHES",
            "mathematics",
            "public domain",
            "CC0",
        ],
        "related_identifiers": [
            {"identifier": MAIN_CONCEPT_DOI, "relation": "isPartOf", "scheme": "doi"},
            {"identifier": MAIN_RECORD_URL, "relation": "isReferencedBy", "scheme": "url"},
            {"identifier": "https://github.com/KokunoYumeto/modern-latex-manuscripts", "relation": "references", "scheme": "url"},
            {"identifier": "https://github.com/ryankeleti/ega", "relation": "references", "scheme": "url"},
            {"identifier": "https://www.numdam.org/", "relation": "references", "scheme": "url"},
        ],
        "notes": "Current public-facing EGA record, organized as reader PDFs first and source/artifact ZIPs later.",
    }
    metadata_path = ZENODO / "metadata_satellite_ega_working_translation_public_current.json"
    write_json(metadata_path, metadata)

    print(json.dumps({"upload": str(upload), "metadata": str(metadata_path), "files": len(list(upload.iterdir()))}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


