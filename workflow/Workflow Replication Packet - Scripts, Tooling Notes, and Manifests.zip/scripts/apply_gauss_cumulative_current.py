#!/usr/bin/env python3
"""Promote the current Gauss cumulative rebuild from the local repair outputs."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import fitz
from pypdf import PdfReader, PdfWriter


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "release_candidates" / "zenodo_author_gauss_current"
UPLOAD = OUT / "upload"
REPORTS = OUT / "reports"
WORK = OUT / "staging" / "gauss_public_rebuild_20260529"
ZENODO = ROOT / "zenodo"

CLAUDE_OUT = Path(r"LOCAL_USER_HOME\Documents\CLAUDE PLEASE DONT DELETE WINDOWS 32\CLAUDE_OUTPUTS")
FIX_SOURCE = CLAUDE_OUT / "gauss_v2_fixes"
FIX_PUBLIC = WORK / "gauss_repair_sources_public"
CUMULATIVE_PUBLIC = WORK / "gauss_cumulative_public"

SUMMARY_JSON = UPLOAD / "90 Carl Friedrich Gauss - Public Summary.json"
METADATA_JSON = ZENODO / "metadata_author_gauss_current.json"
ARTIFACT_ZIP = UPLOAD / "80 Carl Friedrich Gauss - TeX Sources, Component PDFs, and Audits.zip"

PDFLATEX = Path.home() / "AppData" / "Local" / "Programs" / "MiKTeX" / "miktex" / "bin" / "x64" / "pdflatex.exe"

KIMI_ROOTS = [
    Path.home() / "Documents" / "Papors" / "Chatnotes" / "CHat translates and clean" / "Kimi" / "kimi 7" / "kimi 7" / "latex_typesetting",
    Path.home() / "Documents" / "Papors" / "Chatnotes" / "CHat translates and clean" / "Kimi" / "more kimi 5-26-812" / "latex_typesetting",
]

BAND_DIRS = {
    "Band_I": ["25_Gauss_Werke_Band01", "Gauss_Werke_Band01"],
    "Band_I_Alt": ["24_Gauss_Werke_Band01_alt", "Gauss_Werke_Band01_alt"],
    "Band_II": ["Gauss_Werke_Band02", "16_Gauss_Werke_Band02"],
    "Band_III": ["Gauss_Werke_Band03", "17_Gauss_Werke_Band03"],
    "Band_VI": ["Gauss_Werke_Band06", "20_Gauss_Werke_Band06"],
    "Band_VII": ["Gauss_Werke_Band07", "21_Gauss_Werke_Band07"],
    "Band_XI_Part_I": ["Gauss_Werke_Band11_Abt1", "22_Gauss_Werke_Band11_Abt1"],
    "Einzel": ["Gauss_Werke_Einzel", "23_Gauss_Werke_Einzel"],
}

V2_FIX_MAP = {
    "Band_I": ["disq_arith_art_165_RETYPE", "disq_arith_arts_43_49_MISSING_FILL"],
    "Band_I_Alt": ["band_i_alternate_EXPANDED"],
    "Band_II": ["gauss_band_II_quadratic_reciprocity_RETYPE", "gauss_band_II_seeber_identity_RETYPE"],
    "Band_III": ["gauss_band_III_AGM_FIXED"],
    "Band_VI": ["band_vi_ch_8_RETYPE", "band_vi_ch_10_RETYPE", "band_vi_ch_11_RETYPE", "band_vi_ch_13_RETYPE"],
    "Band_VII": ["band_vii_ch_8_RETYPE", "band_vii_arts_145_146_FILL", "band_vii_art_78_trig_FILL"],
    "Band_XI_Part_I": ["band_xi_pt_i_RECOVERED"],
    "Einzel": [],
}

PUBLIC_NAMES = {
    "Band_I": "00 Carl Friedrich Gauss - Werke, Band I - Modern LaTeX Working Edition.pdf",
    "Band_I_Alt": "01 Carl Friedrich Gauss - Werke, Band I - Alternate Modern LaTeX Working Edition.pdf",
    "Band_II": "02 Carl Friedrich Gauss - Werke, Band II - Modern LaTeX Working Edition.pdf",
    "Band_III": "03 Carl Friedrich Gauss - Werke, Band III - Modern LaTeX Working Edition.pdf",
    "Band_VI": "04 Carl Friedrich Gauss - Werke, Band VI - Modern LaTeX Working Edition.pdf",
    "Band_VII": "05 Carl Friedrich Gauss - Werke, Band VII - Modern LaTeX Working Edition.pdf",
    "Band_XI_Part_I": "06 Carl Friedrich Gauss - Werke, Band XI Part I - Modern LaTeX Working Edition.pdf",
    "Einzel": "07 Carl Friedrich Gauss - Individual Papers - Modern LaTeX Working Edition.pdf",
}

PUBLIC_FORBIDDEN = re.compile(
    r"\b(ChatGPT|Claude|Kimi|handoff|cleanup|content-filter|hallucination|garbage)\b|"
    r"C:\\Users\\project maintainer|!!br0ken!!|�|\\begin\{|\\end\{",
    re.IGNORECASE,
)


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def safe_reset(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = OUT.resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sanitize_text(text: str) -> str:
    replacements = [
        (r"Kimi-7 typeset version", "earlier typeset draft"),
        (r"Kimi v1 typeset corpus", "earlier typeset draft"),
        (r"Kimi v1 typesetting", "earlier typesetting"),
        (r"Kimi v1 file", "earlier source file"),
        (r"Kimi version", "earlier source draft"),
        (r"Kimi typesetting", "earlier typesetting"),
        (r"Kimi typeset version", "earlier typeset draft"),
        (r"Kimi typeset corpus", "earlier typeset draft"),
        (r"Kimi TeX", "earlier TeX"),
        (r"Kimi-Fassung", "fruehere Fassung"),
        (r"Kimi-Lauf", "frueheren OCR-Lauf"),
        (r"Kimi", "earlier source draft"),
        (r"Claude Code (Opus 4.7)", "a local repair pass"),
        (r"Claude direct", "direct"),
        (r"Claude", "local repair pass"),
        (r"content-filter", "automated-pass"),
        (r"hallucinated", "incorrect"),
        (r"hallucination", "incorrect reconstruction"),
        (r"garbage", "corruption"),
        (r"raw-OCR", "uncorrected OCR"),
        (r"raw OCR", "uncorrected OCR"),
        (r"C:\\Users\\project maintainer", "local workspace"),
        (str(Path.home()), "local workspace"),
        ("project maintainer", "project maintainer"),
    ]
    for old, new in replacements:
        text = re.sub(re.escape(old), new, text, flags=re.IGNORECASE)
    return text


def copy_sanitized_tree() -> None:
    safe_reset(WORK)
    FIX_PUBLIC.mkdir(parents=True, exist_ok=True)
    text_suffixes = {".tex", ".md", ".txt", ".json", ".csv", ".py", ".log"}
    for src in sorted(FIX_SOURCE.rglob("*")):
        if src.is_dir():
            continue
        rel = src.relative_to(FIX_SOURCE)
        dest = FIX_PUBLIC / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if src.suffix.lower() in text_suffixes:
            dest.write_text(sanitize_text(src.read_text(encoding="utf-8", errors="replace")), encoding="utf-8")
        elif src.suffix.lower() in {".aux", ".out", ".toc"}:
            continue
        else:
            shutil.copy2(src, dest)


def compile_fix_sources() -> list[dict[str, Any]]:
    if not PDFLATEX.exists():
        raise FileNotFoundError(PDFLATEX)
    compiled: list[dict[str, Any]] = []
    prefixes = [prefix for values in V2_FIX_MAP.values() for prefix in values]
    for prefix in prefixes:
        tex = FIX_PUBLIC / f"{prefix}.tex"
        if not tex.exists():
            raise FileNotFoundError(tex)
        for aux in [tex.with_suffix(suffix) for suffix in [".aux", ".log", ".out", ".toc", ".pdf"]]:
            aux.unlink(missing_ok=True)
        proc = subprocess.run(
            [str(PDFLATEX), "-interaction=nonstopmode", "-halt-on-error", tex.name],
            cwd=FIX_PUBLIC,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        pdf = tex.with_suffix(".pdf")
        compiled.append(
            {
                "source": tex.name,
                "returncode": proc.returncode,
                "pdf_exists": pdf.exists(),
                "pdf_bytes": pdf.stat().st_size if pdf.exists() else 0,
                "stdout_tail": proc.stdout[-2500:],
                "stderr_tail": proc.stderr[-1200:],
            }
        )
        if proc.returncode != 0 or not pdf.exists() or pdf.stat().st_size == 0:
            raise RuntimeError(f"Failed to compile {tex}: {proc.stdout[-4000:]}\n{proc.stderr[-2000:]}")
    return compiled


def find_band_source(candidates: list[str]) -> Path | None:
    for root in KIMI_ROOTS:
        for candidate in candidates:
            path = root / candidate
            if path.exists():
                return path
    return None


def collect_pdfs(band_label: str) -> list[Path]:
    source = find_band_source(BAND_DIRS[band_label])
    pdfs: list[Path] = []
    if source:
        pdfs.extend(sorted(source.glob("*.pdf"), key=lambda p: p.name.lower()))
    for fix_prefix in V2_FIX_MAP[band_label]:
        pdf = FIX_PUBLIC / f"{fix_prefix}.pdf"
        if not pdf.exists():
            raise FileNotFoundError(pdf)
        pdfs.append(pdf)
    return pdfs


def build_band(band_label: str) -> dict[str, Any]:
    pdfs = collect_pdfs(band_label)
    if not pdfs:
        raise RuntimeError(f"No PDFs for {band_label}")
    CUMULATIVE_PUBLIC.mkdir(parents=True, exist_ok=True)
    out_pdf = CUMULATIVE_PUBLIC / f"Gauss_Werke_{band_label}.pdf"
    writer = PdfWriter()
    cursor = 0
    components = []
    for pdf in pdfs:
        reader = PdfReader(str(pdf))
        for page in reader.pages:
            writer.add_page(page)
        writer.add_outline_item(pdf.stem, cursor)
        components.append({"file": str(pdf), "pages": len(reader.pages), "bytes": pdf.stat().st_size})
        cursor += len(reader.pages)
    with out_pdf.open("wb") as handle:
        writer.write(handle)
    return {"band": band_label, "pdf": out_pdf, "pages": cursor, "components": components}


def pdf_stats(path: Path) -> dict[str, Any]:
    with fitz.open(path) as doc:
        return {
            "filename": path.name,
            "bytes": path.stat().st_size,
            "pages": doc.page_count,
            "text_chars": sum(len(page.get_text("text") or "") for page in doc),
            "sha256": sha256(path),
        }


def assert_public_pdf_clean(path: Path) -> None:
    hits: list[dict[str, Any]] = []
    with fitz.open(path) as doc:
        for page_index, page in enumerate(doc, start=1):
            text = page.get_text("text") or ""
            match = PUBLIC_FORBIDDEN.search(text)
            if match:
                hits.append({"page": page_index, "hit": match.group(0)})
                if len(hits) >= 10:
                    break
    if hits:
        raise RuntimeError(f"{path.name}: public PDF marker hits: {hits}")


def promote_readers(build_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    by_band = {row["band"]: row for row in build_rows}
    for old in UPLOAD.glob("*Carl Friedrich Gauss*.pdf"):
        old.unlink()
    for band, public_name in PUBLIC_NAMES.items():
        source_pdf = Path(by_band[band]["pdf"])
        assert_public_pdf_clean(source_pdf)
        dest = UPLOAD / public_name
        shutil.copy2(source_pdf, dest)
        stat = pdf_stats(dest)
        stat["role"] = "reader PDF"
        rows.append(stat)
    return rows


def update_artifact_zip(compiled: list[dict[str, Any]], build_rows: list[dict[str, Any]]) -> dict[str, Any]:
    manifest = {
        "generated_at": now_iso(),
        "scope": "Gauss current cumulative rebuild from locally repaired sources",
        "compiled_fix_sources": compiled,
        "cumulative_bands": [
            {key: value for key, value in row.items() if key != "pdf"} | {"pdf": Path(row["pdf"]).name}
            for row in build_rows
        ],
        "public_note": "Corrected sections are appended to the relevant band readers as source-checkable repair supplements.",
    }
    (WORK / "GAUSS_PUBLIC_REBUILD_MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    prefix = "gauss-current-cumulative-rebuild-2026-05-30/"
    tmp = ARTIFACT_ZIP.with_suffix(ARTIFACT_ZIP.suffix + ".tmp")
    with zipfile.ZipFile(ARTIFACT_ZIP, "r") as zin, zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as zout:
        for item in zin.infolist():
            if item.filename.startswith("gauss-current-cumulative-rebuild-"):
                continue
            zout.writestr(item, zin.read(item.filename))
        for src in sorted(WORK.rglob("*")):
            if src.is_file():
                zout.write(src, prefix + src.relative_to(WORK).as_posix())
    with zipfile.ZipFile(tmp) as archive:
        bad = archive.testzip()
        if bad:
            tmp.unlink(missing_ok=True)
            raise RuntimeError(f"Bad artifact ZIP member: {bad}")
    tmp.replace(ARTIFACT_ZIP)
    return {
        "filename": ARTIFACT_ZIP.name,
        "bytes": ARTIFACT_ZIP.stat().st_size,
        "sha256": sha256(ARTIFACT_ZIP),
        "member_count": len(zipfile.ZipFile(ARTIFACT_ZIP).infolist()),
    }


def update_summary(reader_rows: list[dict[str, Any]], artifact: dict[str, Any]) -> None:
    total_pages = sum(int(row["pages"]) for row in reader_rows)
    summary = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "author": "Carl Friedrich Gauss",
        "record_role": "author record for selected Gauss Werke modern LaTeX working drafts",
        "top_level_files": reader_rows
        + [
            {
                "filename": artifact["filename"],
                "role": "source TeX, component PDFs, compile outputs, and audit artifact ZIP",
                "pages": "",
                "bytes": artifact["bytes"],
                "sha256": artifact["sha256"],
            }
        ],
        "coverage": {
            "front_facing_readers": "Eight reader PDFs: Werke Bands I, I alternate, II, III, VI, VII, XI Part I, and an individual-papers grouping.",
            "current_reader_pages_total": total_pages,
            "status": "Current cumulative rebuild incorporates the latest local repair pass: Disquisitiones Arithmeticae fills, Band I alternate expansion, Band II quadratic reciprocity and Seeber identity repairs, Band III AGM repairs, Band VI chapters 8, 10, 11, and 13 repairs, Band VII chapter and article repairs, and Band XI Part I recovery.",
            "not_yet_front_facing": "Other Gauss volumes and chapters remain in source/provenance or repair queues until they can be assembled into usable readers.",
        },
        "latest_rebuild": {
            "date": datetime.now().date().isoformat(),
            "pages_total": total_pages,
            "files": [{k: row[k] for k in ["filename", "pages", "bytes", "sha256"]} for row in reader_rows],
        },
    }
    SUMMARY_JSON.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")


def update_metadata(total_pages: int) -> None:
    metadata = json.loads(METADATA_JSON.read_text(encoding="utf-8"))
    metadata["publication_date"] = datetime.now(timezone.utc).date().isoformat()
    metadata["version"] = "2026-05-30 Gauss current cumulative repair rebuild"
    metadata["description"] = (
        "<p>Author record for Carl Friedrich Gauss in the Modern LaTeX Editions of Mathematics Manuscripts project. "
        "This page presents selected <em>Werke</em> volumes and an individual-papers grouping as modern LaTeX working reader PDFs, with source TeX, component PDFs, compile outputs, and audit reports preserved in a source artifact ZIP.</p>"
        "<p><strong>Status at a glance.</strong></p>"
        "<ul>"
        f"<li><strong>Reader PDFs:</strong> <code>[########--]</code> eight front-facing readers are present, totaling {total_pages} pages: Werke Bands I, I alternate, II, III, VI, VII, XI Part I, and an individual-papers grouping.</li>"
        "<li><strong>Current repair incorporation:</strong> <code>[#########-]</code> the latest cumulative rebuild includes repaired and source-checkable supplements for Disquisitiones Arithmeticae gaps, Band I alternate expansion, Band II quadratic reciprocity and Seeber material, Band III AGM formulas, Band VI chapters 8/10/11/13, Band VII chapter/article repairs, and Band XI Part I recovered material.</li>"
        "<li><strong>Source artifacts:</strong> <code>[########--]</code> TeX sources, component PDFs, compile logs, source-page images where available, and audit reports are preserved in the artifact ZIP for inspection and continuation.</li>"
        "<li><strong>Proofreading state:</strong> <code>[###-------]</code> machine-assisted working drafts needing source comparison, theorem/reference checking, and mathematical proofreading.</li>"
        "</ul>"
        "<p><strong>Use of this record.</strong> The top-level PDFs are intended for direct reading and download. The ZIP file is for reconstruction, repair, and provenance. Other Gauss material remains in the wider project corpus until it can be assembled into similarly usable readers.</p>"
    )
    metadata["notes"] = (
        "Clean author-facing Gauss record. Latest update rebuilds the cumulative readers with the current repair supplements "
        "and preserves source/provenance material in a ZIP artifact."
    )
    text = json.dumps(metadata, ensure_ascii=False)
    if PUBLIC_FORBIDDEN.search(text):
        raise RuntimeError("Internal process wording remains in Gauss metadata.")
    METADATA_JSON.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")


def main() -> int:
    for required in [FIX_SOURCE, ARTIFACT_ZIP, SUMMARY_JSON, METADATA_JSON]:
        if not required.exists():
            raise FileNotFoundError(required)
    copy_sanitized_tree()
    compiled = compile_fix_sources()
    build_rows = [build_band(band) for band in BAND_DIRS]
    reader_rows = promote_readers(build_rows)
    artifact = update_artifact_zip(compiled, build_rows)
    update_summary(reader_rows, artifact)
    update_metadata(sum(int(row["pages"]) for row in reader_rows))
    REPORTS.mkdir(parents=True, exist_ok=True)
    result = {
        "generated_at": now_iso(),
        "reader_pdfs": reader_rows,
        "artifact_zip": artifact,
        "upload_dir": str(UPLOAD),
    }
    out = REPORTS / "gauss_current_cumulative_rebuild_result.json"
    out.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
