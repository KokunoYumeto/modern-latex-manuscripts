#!/usr/bin/env python3
"""Audit current public Zenodo PDF files for basic reader-surface health.

This script is intentionally non-mutating. It downloads public top-level PDFs
from the current Zenodo record map into a local cache, runs pdfinfo, samples
text from the first few pages, and writes a compact report. Low extracted text
is not automatically a failure because some reference PDFs may be image based;
it is flagged for human review.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORTS = PROJECT_ROOT / "reports"
CACHE = REPORTS / "public_pdf_surface_cache"

RECORDS = {
    "main": 20456732,
    "ega": 20454552,
    "sga": 20455791,
    "non_european_consolidated": 20455873,
    "chinese": 20435670,
    "indian_sanskrit": 20435677,
    "islamic_arabic": 20435687,
    "historical_references": 20435690,
    "weber": 20455748,
    "noether": 20455701,
    "riemann": 20434317,
    "gauss": 20454309,
    "deligne": 20453551,
    "classical_algebra_arithmetic": 20454226,
    "additional_author_cluster": 20442003,
}

EXPECTED_IMAGE_SCAN_PDFS = {
    (20455791, "49 SGA 5 - French Reference PDF.pdf"),
    (20455791, "50 SGA 6 - French Reference PDF.pdf"),
    (20455791, "51 SGA 7 Tome 1 - French Reference PDF.pdf"),
    (20455791, "52 SGA 7 Tome 2 - French Reference PDF.pdf"),
}


def safe_name(name: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*]+', "_", name)
    return cleaned[:180]


def request_with_retries(url: str, *, stream: bool = False, timeout: int = 60) -> requests.Response:
    last: Exception | None = None
    for attempt in range(8):
        try:
            response = requests.get(url, stream=stream, timeout=timeout)
            if response.status_code == 429:
                wait = int(response.headers.get("Retry-After") or min(90, 10 * (attempt + 1)))
                response.close()
                time.sleep(wait)
                continue
            response.raise_for_status()
            return response
        except requests.RequestException as exc:
            last = exc
            time.sleep(min(90, 5 * (attempt + 1)))
    if last:
        raise last
    raise RuntimeError(f"Request failed after retries: {url}")


def fetch_record(record_id: int) -> dict[str, Any]:
    url = f"https://zenodo.org/api/records/{record_id}"
    response = request_with_retries(url, timeout=60)
    return response.json()


def download_file(url: str, dest: Path, expected_size: int) -> None:
    if dest.exists() and dest.stat().st_size == expected_size:
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with request_with_retries(url, stream=True, timeout=120) as response:
        response.raise_for_status()
        with tmp.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    handle.write(chunk)
    if tmp.stat().st_size != expected_size:
        raise RuntimeError(f"Downloaded size mismatch for {dest.name}: {tmp.stat().st_size} != {expected_size}")
    tmp.replace(dest)


def run(args: list[str], timeout: int = 60) -> tuple[int, str, str]:
    proc = subprocess.run(args, capture_output=True, text=True, errors="replace", timeout=timeout)
    return proc.returncode, proc.stdout, proc.stderr


def pdfinfo(path: Path) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="pdfsurf_") as tmpdir:
        short = Path(tmpdir) / "x.pdf"
        shutil.copy2(path, short)
        code, out, err = run(["pdfinfo", str(short)], timeout=90)
    pages = 0
    encrypted = False
    if code == 0:
        m = re.search(r"^Pages:\s+(\d+)", out, flags=re.M)
        pages = int(m.group(1)) if m else 0
        encrypted = bool(re.search(r"^Encrypted:\s+yes", out, flags=re.M | re.I))
    return {"ok": code == 0, "pages": pages, "encrypted": encrypted, "stderr": err.strip()[:500]}


def sample_text(path: Path, pages: int) -> dict[str, Any]:
    if pages <= 0:
        return {"chars": 0, "words": 0, "sample_pages": 0, "ok": False}
    last = min(3, pages)
    with tempfile.TemporaryDirectory(prefix="pdfsurf_") as tmpdir:
        short = Path(tmpdir) / "x.pdf"
        shutil.copy2(path, short)
        code, out, err = run(["pdftotext", "-f", "1", "-l", str(last), "-layout", str(short), "-"], timeout=120)
    text = re.sub(r"\s+", " ", out).strip()
    words = re.findall(r"\w+", text, flags=re.UNICODE)
    return {
        "ok": code == 0,
        "chars": len(text),
        "words": len(words),
        "sample_pages": last,
        "stderr": err.strip()[:500],
    }


def file_download_url(record_id: int, filename: str) -> str:
    return f"https://zenodo.org/api/records/{record_id}/files/{quote(filename)}/content"


def main() -> int:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    REPORTS.mkdir(parents=True, exist_ok=True)
    results: list[dict[str, Any]] = []

    for label, record_id in RECORDS.items():
        record = fetch_record(record_id)
        for file_info in record.get("files", []):
            filename = file_info.get("key") or file_info.get("filename") or ""
            if not filename.lower().endswith(".pdf"):
                continue
            size = int(file_info.get("size") or 0)
            cache_path = CACHE / str(record_id) / safe_name(filename)
            item = {
                "label": label,
                "record_id": record_id,
                "filename": filename,
                "bytes": size,
                "downloaded": False,
                "pdfinfo": {},
                "text_sample": {},
                "flags": [],
            }
            try:
                download_file(file_download_url(record_id, filename), cache_path, size)
                item["downloaded"] = True
                info = pdfinfo(cache_path)
                sample = sample_text(cache_path, int(info.get("pages") or 0))
                item["pdfinfo"] = info
                item["text_sample"] = sample
                if not info["ok"]:
                    item["flags"].append("pdfinfo_failed")
                if int(info.get("pages") or 0) <= 0:
                    item["flags"].append("zero_pages")
                if info.get("encrypted"):
                    item["flags"].append("encrypted")
                if sample.get("ok") is False:
                    item["flags"].append("text_extract_failed")
                if int(sample.get("chars") or 0) < 80 and (record_id, filename) not in EXPECTED_IMAGE_SCAN_PDFS:
                    item["flags"].append("low_text_sample")
                if int(sample.get("chars") or 0) < 80 and (record_id, filename) in EXPECTED_IMAGE_SCAN_PDFS:
                    item["note"] = "Expected image-based reference scan; low embedded text is not treated as a defect."
            except Exception as exc:  # noqa: BLE001 - audit should record failures and continue.
                item["flags"].append("download_or_audit_error")
                item["error"] = str(exc)[:800]
            results.append(item)

    json_path = REPORTS / f"public_pdf_surface_audit_{stamp}.json"
    md_path = REPORTS / f"public_pdf_surface_audit_{stamp}.md"
    json_path.write_text(json.dumps(results, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    flagged = [item for item in results if item["flags"]]
    lines = [
        "# Public PDF Surface Audit",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        "",
        f"PDFs checked: {len(results)}",
        f"Flagged for review: {len(flagged)}",
        "",
        "| Record | PDF files | Flagged |",
        "|---|---:|---:|",
    ]
    for label, record_id in RECORDS.items():
        subset = [item for item in results if item["record_id"] == record_id]
        bad = [item for item in subset if item["flags"]]
        lines.append(f"| {label} [{record_id}](https://zenodo.org/records/{record_id}) | {len(subset)} | {len(bad)} |")
    lines.extend(["", "## Flagged Files", ""])
    if not flagged:
        lines.append("No PDF surface flags found.")
    else:
        for item in flagged:
            flags = ", ".join(item["flags"])
            pages = item.get("pdfinfo", {}).get("pages", "")
            chars = item.get("text_sample", {}).get("chars", "")
            lines.append(f"- `{item['filename']}` ({item['record_id']}): {flags}; pages={pages}; sampled_chars={chars}")
    md_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")

    print(json.dumps({"json": str(json_path), "markdown": str(md_path), "pdfs": len(results), "flagged": len(flagged)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())



