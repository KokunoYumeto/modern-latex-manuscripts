#!/usr/bin/env python3
"""Audit public reader PDFs for visible process or translator-note leakage.

The archive can keep raw provenance in artifact ZIPs, but top-level PDFs should
read like public editions/reference files. This audit samples early PDF pages
and flags visible process language such as tool names, handoff notes, render
checks, or modern translator-note covers.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import time
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import quote

import requests


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPORTS = PROJECT_ROOT / "reports"
CACHE = REPORTS / "public_pdf_process_note_cache"

RECORDS = {
    "main": 20456732,
    "ega": 20454552,
    "sga": 20455791,
    "non_european_consolidated": 20455873,
    "chinese": 20435670,
    "indian_sanskrit": 20435677,
    "islamic_arabic": 20435687,
    "historical_references": 20435690,
    "weber": 20455748,
    "noether": 20455701,
    "riemann": 20434317,
    "gauss": 20454309,
    "deligne": 20453551,
    "classical_algebra_arithmetic": 20454226,
    "additional_author_cluster": 20442003,
}

PROCESS_PATTERNS = [
    r"\bChatGPT\b",
    r"\bOpenAI\b",
    r"\bClaude\b",
    r"\bKimi\b",
    r"\bLLM\b",
    r"\blarge language model\b",
    r"\blanguage model\b",
    r"\bAI[- ]generated\b",
    r"\bAI[- ]assisted\b",
    r"\bmachine[- ]assisted\b",
    r"\bagent[- ]swarm\b",
    r"\bweb session\b",
    r"\bhandoff packet\b",
    r"\brender check\b",
    r"\bworklog\b",
    r"\bAbout this file\b",
    r"\bTranslator'?s note\b",
    r"\bTranslation note\b",
]


def safe_name(name: str) -> str:
    cleaned = re.sub(r'[<>:"/\\|?*]+', "_", name)
    return cleaned[:120]


def request_with_retries(url: str, *, stream: bool = False, timeout: int = 60) -> requests.Response:
    last: Exception | None = None
    for attempt in range(8):
        try:
            response = requests.get(url, stream=stream, timeout=timeout)
            if response.status_code == 429:
                wait = int(response.headers.get("Retry-After") or min(90, 10 * (attempt + 1)))
                response.close()
                time.sleep(wait)
                continue
            response.raise_for_status()
            return response
        except requests.RequestException as exc:
            last = exc
            time.sleep(min(90, 5 * (attempt + 1)))
    if last:
        raise last
    raise RuntimeError(f"Request failed after retries: {url}")


def fetch_record(record_id: int) -> dict[str, Any]:
    response = request_with_retries(f"https://zenodo.org/api/records/{record_id}", timeout=60)
    return response.json()


def file_download_url(record_id: int, filename: str) -> str:
    return f"https://zenodo.org/api/records/{record_id}/files/{quote(filename)}/content"


def download_file(url: str, dest: Path, expected_size: int) -> None:
    if dest.exists() and dest.stat().st_size == expected_size:
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    with request_with_retries(url, stream=True, timeout=180) as response:
        response.raise_for_status()
        with tmp.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    handle.write(chunk)
    if tmp.stat().st_size != expected_size:
        raise RuntimeError(f"Downloaded size mismatch for {dest.name}: {tmp.stat().st_size} != {expected_size}")
    tmp.replace(dest)


def extract_text_short_path(path: Path, pages: int = 10) -> str:
    # Poppler on Windows can stumble on long paths; copy to a tiny temp name.
    with tempfile.TemporaryDirectory(prefix="pdfnote_") as tmpdir:
        short = Path(tmpdir) / "x.pdf"
        shutil.copy2(path, short)
        proc = subprocess.run(
            ["pdftotext", "-f", "1", "-l", str(pages), "-layout", str(short), "-"],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=180,
        )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip()[:500] or f"pdftotext exited {proc.returncode}")
    return proc.stdout


def process_hits(text: str) -> list[dict[str, str]]:
    hits: list[dict[str, str]] = []
    for pattern in PROCESS_PATTERNS:
        match = re.search(pattern, text, flags=re.I)
        if not match:
            continue
        start = max(0, match.start() - 80)
        end = min(len(text), match.end() + 120)
        context = re.sub(r"\s+", " ", text[start:end]).strip()
        hits.append({"pattern": pattern, "context": context})
    return hits


def main() -> int:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    REPORTS.mkdir(parents=True, exist_ok=True)
    rows: list[dict[str, Any]] = []
    for label, record_id in RECORDS.items():
        record = fetch_record(record_id)
        for file_info in record.get("files", []):
            filename = file_info.get("key") or file_info.get("filename") or ""
            if not filename.lower().endswith(".pdf"):
                continue
            size = int(file_info.get("size") or 0)
            cache_path = CACHE / str(record_id) / safe_name(filename)
            row: dict[str, Any] = {
                "label": label,
                "record_id": record_id,
                "filename": filename,
                "bytes": size,
                "hits": [],
            }
            try:
                download_file(file_download_url(record_id, filename), cache_path, size)
                text = extract_text_short_path(cache_path)
                row["hits"] = process_hits(text)
            except Exception as exc:  # noqa: BLE001 - audit records and continues.
                row["error"] = str(exc)[:800]
            rows.append(row)

    flagged = [row for row in rows if row.get("hits") or row.get("error")]
    json_path = REPORTS / f"public_pdf_process_note_audit_{stamp}.json"
    md_path = REPORTS / f"public_pdf_process_note_audit_{stamp}.md"
    json_path.write_text(json.dumps(rows, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    lines = [
        "# Public PDF Process-Note Audit",
        "",
        f"Generated: {datetime.now().isoformat(timespec='seconds')}",
        "",
        f"PDFs checked: {len(rows)}",
        f"Flagged for review: {len(flagged)}",
        "",
    ]
    if flagged:
        for row in flagged:
            lines.append(f"- `{row['filename']}` ({row['record_id']}, {row['label']})")
            if row.get("error"):
                lines.append(f"  - extract error: {row['error']}")
            for hit in row.get("hits", []):
                lines.append(f"  - `{hit['pattern']}`: {hit['context']}")
    else:
        lines.append("No process-note patterns found in sampled public PDFs.")
    md_path.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")

    print(json.dumps({"json": str(json_path), "markdown": str(md_path), "pdfs": len(rows), "flagged": len(flagged)}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())



