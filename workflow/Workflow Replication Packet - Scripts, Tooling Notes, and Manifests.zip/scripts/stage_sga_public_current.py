#!/usr/bin/env python3
"""Stage the latest SGA public translation packet for Zenodo."""

from __future__ import annotations

import hashlib
import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from datetime import date, datetime
from pathlib import Path, PurePosixPath
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
TRANSLATIONS = (
    Path.home()
    / "Documents"
    / "Papors"
    / "Chatnotes"
    / "CHat translates and clean"
    / "translations"
    / "SGA + translation"
)
OUT = PROJECT_ROOT / "release_candidates" / "zenodo_satellite_sga_working_translation_public_current"
ZENODO = PROJECT_ROOT / "zenodo"
MAIN_CONCEPT_DOI = "10.5281/zenodo.20393488"
MAIN_RECORD_URL = "https://zenodo.org/records/20441732"
TYPESSET_SGA = Path.home() / "Downloads" / "EGA" / "Typeset-EGA-SGA" / "SGA"
SGA_HANDOFF = Path.home() / "Downloads" / "SGA" / "SGA_TRANSLATION_HANDOFF_1_7_CURRENT" / "run_20260527_090910"


def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def reset_dir(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = (PROJECT_ROOT / "release_candidates").resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def pdf_pages(path: Path) -> int | None:
    """Return page count, copying to a short temp path if Poppler hits MAX_PATH."""
    def run(candidate: Path) -> int | None:
        proc = subprocess.run(
            ["pdfinfo", str(candidate)],
            capture_output=True,
            text=True,
            errors="replace",
            timeout=60,
            check=False,
        )
        if proc.returncode != 0:
            return None
        match = re.search(r"(?m)^Pages:\s+(\d+)\s*$", proc.stdout)
        return int(match.group(1)) if match else None

    pages = run(path)
    if pages is not None:
        return pages
    with tempfile.TemporaryDirectory(prefix="sga_pdfinfo_") as temp_dir:
        short = Path(temp_dir) / "check.pdf"
        shutil.copy2(path, short)
        pages = run(short)
    if pages is not None:
        return pages
    try:
        import fitz

        with fitz.open(path) as doc:
            return int(doc.page_count)
    except Exception:
        return None


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def copy_member(zf: zipfile.ZipFile, member: str, dest: Path) -> Path:
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zf.open(member) as src, dest.open("wb") as dst:
        shutil.copyfileobj(src, dst)
    return dest


def copy_file(src: Path, dest: Path) -> Path:
    if not src.exists():
        raise FileNotFoundError(src)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    return dest


def sanitize_public_text(text: str) -> str:
    text = re.sub(
        r"SGA\s*6\s*--\s*Batch\s*029",
        "SGA 6 -- Working Draft, Opening Through Expose I",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"SGA\s*6\s*--\s*Batch\s*030",
        "SGA 6 -- Working Draft, Expose I Continuation Through Expose V",
        text,
        flags=re.I,
    )
    replacements = {
        "handoff": "source package",
        "Handoff": "Source package",
        "HANDOFF": "SOURCE PACKAGE",
        "BATCH_016": "EXPOSE_IV_10_14",
        "batch_016": "expose_iv_10_14",
        "Kimi": "source-transcription",
        "kimi": "source-transcription",
        str(Path.home()): "local workspace",
        "C:\\Users\\project maintainer": "local workspace",
        "project maintainer": "project maintainer",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"(?i)\bbatch[ _-]?\d+\b", "translation segment", text)
    text = re.sub(r"(?i)\bthis\s+batch\b", "this translation segment", text)
    text = re.sub(r"(?i)\bthe\s+next\s+batch\b", "the next translation segment", text)
    text = re.sub(r"(?i)\bnext\s+batch\b", "next translation segment", text)
    text = re.sub(r"(?i)\bpreceding\s+delivery\b", "preceding translation segment", text)
    text = re.sub(r"(?i)\bcontinuation\s+(?:anchor|marker)\b", "continuation point", text)
    text = re.sub(r"(?i)\bfresh-only\s+package\b", "source package", text)
    text = re.sub(r"(?i)\bcleanup\b", "editorial review", text)
    text = re.sub(r"(?i)\bclean-up\b", "editorial review", text)
    text = re.sub(r"(?i)\btranslator(?:'s)?\s+note\b", "editorial note", text)
    text = re.sub(r"(?i)\bChatGPT\b", "the translation workflow", text)
    text = re.sub(r"(?i)\bClaude\b", "the translation workflow", text)
    text = re.sub(r"(?i)\bCodex\b", "the archive workflow", text)
    text = re.sub(r"(?im)^SGA 5\s*[–-]\s*translation segment\s*$", "SGA 5 -- Completion Working Draft", text)
    text = re.sub(r"(?im)^Working English LaTeX translation,?\s*translation segment\s*$", "Working English LaTeX translation", text)
    text = re.sub(r"(?i)Working English LaTeX translation,?\s*translation segment", "Working English LaTeX translation", text)
    text = re.sub(r"(?i)\\title\{SGA 5\s*[–-]\s*translation segment\}", r"\\title{SGA 5 -- Completion Working Draft}", text)
    text = re.sub(r"(?i)source block used for this translation segment\.?", "", text)
    text = re.sub(r"(?i)\btranslation segment\b", "working draft section", text)
    text = re.sub(r"(?i)SGA 4 Translation Project\s*(?:--|–|-)\s*working draft section", "SGA 4 -- Working Draft", text)
    text = re.sub(r"(?i)SGA 5\s*(?:--|–|-)\s*working draft section(?:,\s*continuation)?", "SGA 5 -- Working Draft", text)
    text = re.sub(r"(?im)^SGA 5\s*[–-]\s*working draft section(?:,\s*continuation)?\s*$", "SGA 5 -- Working Draft", text)
    return text


def public_member_name(name: str, root: str) -> str:
    parts = list(Path(name).parts)
    if parts and parts[0].lower().startswith("sga_batch"):
        parts[0] = root
    elif parts:
        parts = [root, *parts]
    else:
        parts = [root]
    cleaned = []
    for part in parts:
        lower = part.lower()
        if lower.startswith("batch_016"):
            cleaned.append("expose_iv_sections_10_to_14")
        elif re.match(r"batch[_-]?\d+", lower):
            cleaned.append("translation_segment_sources")
        elif "handoff" in lower:
            cleaned.append(part.replace("handoff", "source_package").replace("HANDOFF", "SOURCE_PACKAGE"))
        else:
            public_part = part.replace("BATCH_016", "EXPOSE_IV_10_14").replace("batch_016", "expose_iv_10_14")
            public_part = re.sub(r"(?i)BATCH[_-]?\d+", "translation_segment", public_part)
            public_part = re.sub(r"(?i)batch[_-]?\d+", "translation_segment", public_part)
            cleaned.append(public_part)
    return Path(*cleaned).as_posix()


def copy_public_zip(src_zip: Path, dest_zip: Path, root: str) -> Path:
    text_suffixes = {".tex", ".md", ".csv", ".json", ".txt", ".log"}
    dest_zip.parent.mkdir(parents=True, exist_ok=True)
    if dest_zip.exists():
        dest_zip.unlink()
    used_names: set[str] = set()

    def unique_name(public_name: str) -> str:
        if public_name not in used_names:
            used_names.add(public_name)
            return public_name
        path = PurePosixPath(public_name)
        parent = "" if str(path.parent) == "." else f"{path.parent.as_posix()}/"
        suffix = path.suffix
        stem = path.name[: -len(suffix)] if suffix else path.name
        index = 2
        while True:
            candidate = f"{parent}{stem}_{index}{suffix}"
            if candidate not in used_names:
                used_names.add(candidate)
                return candidate
            index += 1

    with zipfile.ZipFile(src_zip, "r") as src, zipfile.ZipFile(dest_zip, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as dst:
        for info in src.infolist():
            if info.is_dir():
                continue
            public_name = unique_name(public_member_name(info.filename, root))
            if Path(info.filename).suffix.lower() in text_suffixes:
                text = src.read(info).decode("utf-8", errors="replace")
                text = strip_public_reader_notes(sanitize_public_text(text))
                dst.writestr(public_name, text)
            else:
                dst.writestr(public_name, src.read(info))
    with zipfile.ZipFile(dest_zip, "r") as zf:
        bad = zf.testzip()
    if bad:
        raise RuntimeError(f"Bad public ZIP member: {bad}")
    return dest_zip


def latest_sga_zip() -> Path:
    zips = sorted(TRANSLATIONS.glob("sga_translation_batch_*_cumulative*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not zips:
        raise FileNotFoundError(f"No SGA cumulative ZIP found in {TRANSLATIONS}")
    return zips[0]


def sga_fresh_zips() -> list[Path]:
    zips = sorted(TRANSLATIONS.glob("sga_translation_batch_*_new_only*.zip"), key=lambda p: p.name.lower())
    bundle_zips = sorted(TRANSLATIONS.glob("sga_translation_batch_*_bundle*.zip"), key=lambda p: p.name.lower())
    return [*zips, *bundle_zips]


def find_fresh_zip(name_fragment: str) -> Path | None:
    fragment = name_fragment.lower()
    matches = [path for path in sga_fresh_zips() if fragment in path.name.lower()]
    if not matches:
        return None
    return sorted(matches, key=lambda p: p.stat().st_mtime, reverse=True)[0]


def batch_number(path: Path) -> int | None:
    match = re.search(r"batch[_-]?(\d+)", path.name, flags=re.I)
    return int(match.group(1)) if match else None


def find_member(zf: zipfile.ZipFile, suffix: str) -> str:
    matches = [name for name in zf.namelist() if name.endswith(suffix)]
    if not matches:
        raise FileNotFoundError(suffix)
    return sorted(matches, key=len)[0]


def run_pdfunite(inputs: list[Path], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    merge_key = "|".join(str(path) for path in [*inputs, output])
    work = OUT / "staging" / "pdfunite" / f"sga_pdfunite_{hashlib.md5(merge_key.encode('utf-8')).hexdigest()[:12]}"
    reset_dir(work)
    short_inputs: list[Path] = []
    for idx, src in enumerate(inputs):
        short = work / f"part_{idx:03d}.pdf"
        shutil.copy2(src, short)
        short_inputs.append(short)
    short_output = work / "merged.pdf"
    proc = subprocess.run(
        ["pdfunite", *[str(path) for path in short_inputs], str(short_output)],
        capture_output=True,
        text=True,
        errors="replace",
        check=False,
        timeout=240,
    )
    if proc.returncode == 0 and short_output.exists():
        shutil.copy2(short_output, output)
    shutil.rmtree(work, ignore_errors=True)
    if proc.returncode != 0 or not output.exists():
        raise RuntimeError(f"pdfunite failed for {output}: {proc.stderr or proc.stdout}")


def normalize_public_reader_layout(text: str, source_hint: str = "") -> str:
    """Normalize obvious public-reader layout drift in newly delivered SGA TeX.

    Some source packets used extarticle at 13pt/14pt while adjacent packets used
    ordinary 12pt article.  The content is kept intact; this only makes the
    public checking readers visually continuous.
    """
    if not re.search(r"SGA\s*[1-6]|SGA[1-6]|batch[_-]0(?:2[6-9]|3[0-9])", source_hint, re.I):
        return text
    text = re.sub(
        r"\\documentclass(?:\[[^\]]*\])?\{(?:extarticle|article)\}",
        r"\\documentclass[12pt]{article}",
        text,
        count=1,
        flags=re.I,
    )
    text = re.sub(r"\\geometry\{[^{}]*\}\s*", "", text)
    if re.search(r"\\usepackage(?:\[[^\]]*\])?\{geometry\}", text):
        text = re.sub(
            r"\\usepackage(?:\[[^\]]*\])?\{geometry\}",
            r"\\usepackage[margin=1in]{geometry}",
            text,
            count=1,
        )
    else:
        text = re.sub(
            r"(\\documentclass(?:\[[^\]]*\])?\{[^}]+\}\s*)",
            r"\1\\usepackage[margin=1in]{geometry}\n",
            text,
            count=1,
        )
    return text


def compile_tex_text(text: str, dest: Path, source_hint: str = "") -> Path:
    text = strip_public_reader_notes(sanitize_public_text(text))
    text = normalize_public_reader_layout(text, source_hint)
    tmp_key = hashlib.md5(str(dest).encode("utf-8")).hexdigest()[:12]
    tmp = OUT / "staging" / f"compile_{tmp_key}"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True, exist_ok=True)
    tex = tmp / "reader.tex"
    tex.write_text(text, encoding="utf-8")
    for _ in range(2):
        proc = subprocess.run(
            ["xelatex", "-interaction=nonstopmode", "-halt-on-error", tex.name],
            cwd=tmp,
            capture_output=True,
            text=True,
            errors="replace",
            timeout=900,
            check=False,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"xelatex failed for {dest}: {proc.stdout[-2000:]}\n{proc.stderr[-2000:]}")
    pdf = tmp / "reader.pdf"
    if not pdf.exists():
        raise RuntimeError(f"xelatex did not produce {pdf}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(pdf, dest)
    return dest


def compile_clean_existing_sga_tex(zf: zipfile.ZipFile, tex_suffix: str, dest: Path) -> Path:
    member = find_member(zf, tex_suffix)
    text = zf.read(member).decode("utf-8", errors="replace")
    text = re.sub(
        r"% Batch 006 repair patch:.*?\n% The prior package accidentally included.*?\n",
        "",
        text,
        flags=re.S,
    )
    text = re.sub(
        r"\\begin\{quote\}\s*Consolidated from the jcreinhold LLM-generated Markdown snapshot\s*included in the handoff packet\. Not mathematically proofed in this\s*batch\.\s*\\end\{quote\}\s*",
        "",
        text,
        flags=re.S,
    )
    text = text.replace("Consolidated from the per-Exposé ledger deltas appended at the foot of each translation file.", "")
    text = text.replace("Consolidated from the per-Exposé ledger deltas appended at the foot of each translation file.", "")
    text = text.replace(r"\setmainfont{FreeSerif}[Scale=MatchLowercase]", r"\setmainfont{DejaVu Serif}[Scale=MatchLowercase]")
    text = text.replace(r"\setsansfont{Noto Sans}[Scale=MatchLowercase]", r"\setsansfont{DejaVu Sans}[Scale=MatchLowercase]")
    text = text.replace(r"\setmonofont{FreeSerif}[Scale=MatchLowercase]", r"\setmonofont{DejaVu Sans Mono}[Scale=MatchLowercase]")
    text = text.replace(r"\setmathfont{STIX Math}", r"\setmathfont{Cambria Math}")
    return compile_tex_text(text, dest, tex_suffix)


def compile_clean_fresh_sga_tex(zf: zipfile.ZipFile, pdf_suffix: str, dest: Path) -> Path:
    tex_suffix = re.sub(r"\.pdf$", ".tex", pdf_suffix, flags=re.I)
    member = find_member(zf, tex_suffix)
    text = zf.read(member).decode("utf-8", errors="replace")
    return compile_tex_text(text, dest, pdf_suffix)


def compile_clean_tex_parts(zf: zipfile.ZipFile, tex_suffixes: list[str], dest: Path, stem: str) -> Path:
    parts: list[Path] = []
    for index, suffix in enumerate(tex_suffixes):
        part_dest = OUT / "staging" / "compiled_parts" / stem / f"part_{index:03d}.pdf"
        parts.append(compile_clean_existing_sga_tex(zf, suffix, part_dest))
    run_pdfunite(parts, dest)
    return dest


def build_cover_pdf(title: str, subtitle: str, body: str, dest: Path) -> Path:
    tex = rf"""\documentclass[11pt]{{article}}
\usepackage[margin=1in]{{geometry}}
\usepackage{{lmodern}}
\usepackage[T1]{{fontenc}}
\usepackage{{microtype}}
\usepackage{{hyperref}}
\begin{{document}}
\thispagestyle{{empty}}
\begin{{center}}
\vspace*{{1.2in}}
{{\LARGE\bfseries {title}\par}}
\vspace{{0.3in}}
{{\large {subtitle}\par}}
\vspace{{0.5in}}
\begin{{minipage}}{{0.78\linewidth}}
{body}
\end{{minipage}}
\end{{center}}
\end{{document}}
"""
    return compile_tex_text(tex, dest)


def strip_public_reader_notes(text: str) -> str:
    """Remove process/editorial translator-note prose from reader PDFs only."""
    text = re.sub(
        r"\s*\\begin\{center\}\s*\\rule\{[^}]+\}\{[^}]+\}\\\\\[[^\]]+\]\s*\\emph\{Continuation (?:anchor|point):.*?\\end\{center\}\s*",
        "\n\n",
        text,
        flags=re.I | re.S,
    )
    text = re.sub(
        r"\s*\\emph\{\{\[\}\s*Translator(?:'s)?\s+note:.*?\{\]\}\}\s*",
        "\n\n",
        text,
        flags=re.I | re.S,
    )
    text = re.sub(
        r"\s*\{\[\}\s*Translator(?:'s)?\s+note:.*?\{\]\}\s*",
        "\n\n",
        text,
        flags=re.I | re.S,
    )
    text = re.sub(
        r"\s*\\begin\{quote\}\s*\\textbf\{Translator\s+note\.?\}.*?\\end\{quote\}\s*",
        "\n\n",
        text,
        flags=re.I | re.S,
    )
    text = re.sub(
        r"\s*\\footnote\{\s*TRANSLATOR\s+NOTE:.*?\}\s*",
        "",
        text,
        flags=re.I | re.S,
    )
    text = re.sub(
        r"\\footnote\{\\emph\{Translator's note:\}\s*",
        r"\\footnote{",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"a translator note at the\s+head of Expos[eé] XIV recalls it",
        "the opening note of Expose XIV recalls it",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"Flag the SGA-era usage in a translator note on first occurrence per\s+Expos[eé]\.",
        "Flag the SGA-era usage at first occurrence per Expose.",
        text,
        flags=re.I,
    )
    text = text.replace("A future cleanup pass may de-duplicate", "A future editorial pass may de-duplicate")
    text = re.sub(
        r"marked with a translator note rather than silently fixed",
        "left visibly flagged rather than silently fixed",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"Translator keeps quotation",
        "Quotation preserved",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"\{\[\}\^\{\}TRANSLATOR-NOTE-[^{}]+?\{\]\}",
        "",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"translators of individual Expos[eé]s; every translator must consult it",
        "editors of individual Exposes; the glossary should be consulted",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"The translator should pin the convention",
        "The convention should be pinned",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"translator reads each block; do not silently",
        "each block is read; do not silently",
        text,
        flags=re.I,
    )
    text = re.sub(
        r"\\texttt\{\\textless\{\}!-\\/-\\ TRANSLATOR\\ NOTE:\\ \.\.\.\\ -\\/-\\textgreater\{\}\}",
        r"\\texttt{\\textless{}!-\\/-\\ EDITORIAL\\ NOTE:\\ ...\\ -\\/-\\textgreater{}}",
        text,
        flags=re.I,
    )
    text = strip_process_paragraphs(text)
    return text


def strip_process_paragraphs(text: str) -> str:
    """Drop delivery/continuation bookkeeping paragraphs from public readers."""
    lines = text.splitlines()
    out: list[str] = []
    skipping = False
    for line in lines:
        stripped = line.strip()
        lower = stripped.lower()
        starts_process_paragraph = (
            "continuation anchor" in lower
            or "continuation point" in lower
            or "translator's status note" in lower
            or "translator’s status note" in lower
            or "fresh-only continuation" in lower
            or "source basis:" in lower
            or "this working draft section continues" in lower
            or "this working draft section begins" in lower
            or "corresponds to source lines" in lower
            or "the range corresponds to source lines" in lower
            or lower.startswith("this batch ")
            or " next batch " in f" {lower} "
            or "preceding delivery" in lower
            or "redelivered separately" in lower
            or "source line " in lower
            or "source lines " in lower and ("continue" in lower or "batch" in lower)
            or "new-only" in lower
        )
        if starts_process_paragraph:
            skipping = True
            continue
        if skipping:
            if stripped == r"\end{center}":
                skipping = False
                out.append(line)
                continue
            if not stripped:
                skipping = False
                out.append(line)
            continue
        out.append(line)
    suffix = "\n" if text.endswith("\n") else ""
    return "\n".join(out) + suffix


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_") or "item"


def main() -> int:
    src_zip = latest_sga_zip()
    fresh_specs = [
        {
            "fragment": "batch_014",
            "suffix": "02_new_translation_latex/batch_014/SGA4_Expose_IV_section_9_en.pdf",
            "dest": "08 SGA 4 - Expose IV English Draft section 9.pdf",
            "unit": "SGA 4 Expose IV",
            "status": "Fresh current English working draft: Expose IV section 9, subtopoi and gluing of topoi.",
            "artifact": "81 SGA - Expose IV Section 9 Sources and Render Checks.zip",
            "root": "sga_expose_iv_section_9_sources",
        },
        {
            "fragment": "batch_016",
            "suffix": "02_new_translation_latex/batch_016/SGA4_Expose_IV_sections_10_to_14_en.pdf",
            "dest": "09 SGA 4 - Expose IV English Draft sections 10 to 14.pdf",
            "unit": "SGA 4 Expose IV",
            "status": "Fresh current English working draft: Expose IV sections 10 through 14.",
            "artifact": "82 SGA - Expose IV Sections 10 to 14 Sources and Render Checks.zip",
            "root": "sga_expose_iv_sections_10_to_14_sources",
        },
        {
            "fragment": "batch_017",
            "suffix": "02_new_translation_latex/batch_017/SGA4_Expose_V_intro_and_section_0_en.pdf",
            "dest": "10 SGA 4 - Expose V Introduction and Section 0.pdf",
            "unit": "SGA 4 Expose V",
            "status": "Fresh current English working draft: Expose V introduction and section 0.",
            "artifact": "83 SGA - Expose V Introduction and Section 0 Sources and Render Checks.zip",
            "root": "sga_expose_v_introduction_and_section_0_sources",
        },
        {
            "fragment": "batch_018",
            "suffix": "02_new_translation_latex/batch_018/SGA4_Expose_V_sections_1_to_4_en.pdf",
            "dest": "11 SGA 4 - Expose V English Draft sections 1 to 4.pdf",
            "unit": "SGA 4 Expose V",
            "status": "Fresh current English working draft: Expose V sections 1 through 4.",
            "artifact": "84 SGA - Expose V Sections 1 to 4 Sources and Render Checks.zip",
            "root": "sga_expose_v_sections_1_to_4_sources",
        },
        {
            "fragment": "batch_019",
            "suffix": "02_new_translation_latex/batch_019/SGA4_Expose_V_sections_5_to_8_en.pdf",
            "dest": "12 SGA 4 - Expose V English Draft sections 5 to 8.pdf",
            "unit": "SGA 4 Expose V",
            "status": "Fresh current English working draft: Expose V sections 5 through 8. Together with the preceding fresh packets, this completes the current Expose V working draft.",
            "artifact": "85 SGA - Expose V Sections 5 to 8 Sources and Render Checks.zip",
            "root": "sga_expose_v_sections_5_to_8_sources",
        },
        {
            "fragment": "batch_020",
            "suffix": "02_new_translation_latex/batch_020/SGA4_Expose_VI_introduction_and_section_1_1_to_1_21_en.pdf",
            "dest": "13 SGA 4 - Expose VI Introduction and Section 1.1 to 1.21.pdf",
            "unit": "SGA 4 Expose VI",
            "status": "Fresh current English working draft: Expose VI introduction and section 1.1 through 1.21.",
            "artifact": "86 SGA - Expose VI Introduction and Section 1.1 to 1.21 Sources and Render Checks.zip",
            "root": "sga_expose_vi_introduction_and_section_1_1_to_1_21_sources",
        },
        {
            "fragment": "batch_021",
            "suffix": "02_new_translation_latex/batch_021/SGA4_Expose_VI_sections_1_22_to_2_18_en.pdf",
            "dest": "14 SGA 4 - Expose VI English Draft sections 1.22 to 2.18.pdf",
            "unit": "SGA 4 Expose VI",
            "status": "Fresh current English working draft: Expose VI sections 1.22 through 2.18.",
            "artifact": "87 SGA - Expose VI Sections 1.22 to 2.18 Sources and Render Checks.zip",
            "root": "sga_expose_vi_sections_1_22_to_2_18_sources",
        },
        {
            "fragment": "batch_022",
            "suffix": "02_new_translation_latex/batch_022/SGA4_Expose_VI_sections_3_to_9_complete_en.pdf",
            "dest": "15 SGA 4 - Expose VI English Draft sections 3 to 9.pdf",
            "unit": "SGA 4 Expose VI",
            "status": "Fresh current English working draft: Expose VI sections 3 through 9, completing the current Expose VI working draft.",
            "artifact": "88 SGA - Expose VI Sections 3 to 9 and Expose VII Sources and Render Checks.zip",
            "root": "sga_expose_vi_sections_3_to_9_and_expose_vii_sources",
        },
        {
            "fragment": "batch_022",
            "suffix": "02_new_translation_latex/batch_022/SGA4_Expose_VII_complete_en.pdf",
            "dest": "16 SGA 4 - Expose VII Complete English Draft.pdf",
            "unit": "SGA 4 Expose VII",
            "status": "Fresh current English working draft: complete Expose VII.",
            "artifact": "88 SGA - Expose VI Sections 3 to 9 and Expose VII Sources and Render Checks.zip",
            "root": "sga_expose_vi_sections_3_to_9_and_expose_vii_sources",
        },
        {
            "fragment": "batch_023",
            "suffix": "02_new_translation_latex/batch_023/SGA4_Exposes_VIII_to_XII_5_11_en.pdf",
            "dest": "17 SGA 4 - Exposes VIII to XII section 5.11 English Draft.pdf",
            "unit": "SGA 4 Exposes VIII-XII",
            "status": "Fresh current English working draft: Exposes VIII through XI complete, and Expose XII through section 5.11.",
            "artifact": "89 SGA - Exposes VIII to XII Section 5.11 Sources and Render Checks.zip",
            "root": "sga_exposes_viii_to_xii_section_5_11_sources",
        },
        {
            "fragment": "batch_024",
            "suffix": "02_new_translation_latex/batch_024/SGA4_Expose_XII_6_to_XVII_5_2_4_en.pdf",
            "dest": "18 SGA 4 - Exposes XII-XVII English Draft.pdf",
            "unit": "SGA 4 Exposes XII-XVII",
            "status": "Fresh current English working draft: Expose XII section 6 through Expose XVII section 5.2.4.",
            "artifact": "90 SGA - Exposes XII-XVII Sources and Render Checks.zip",
            "root": "sga_expose_xii_section_6_to_expose_xvii_section_5_2_4_sources",
        },
        {
            "fragment": "batch_025",
            "suffix": "02_new_translation_latex/batch_025/SGA4_Expose_XVII_5_2_4_to_XVIII_section_2_en.pdf",
            "dest": "19 SGA 4 - Exposes XVII-XVIII English Draft.pdf",
            "unit": "SGA 4 Exposes XVII-XVIII",
            "status": "Fresh current English working draft: Expose XVII section 5.2.4 through the end of Expose XVII, and Expose XVIII through section 2.",
            "artifact": "91 SGA - Exposes XVII-XVIII Sources and Render Checks.zip",
            "root": "sga_expose_xvii_completion_and_expose_xviii_section_2_sources",
        },
        {
            "fragment": "batch_026",
            "suffix": "02_new_translation_latex/batch_026/SGA4_Expose_XVIII_section_3_and_XIX_complete_en.pdf",
            "dest": "20 SGA 4 - Exposes XVIII-XIX Complete English Draft.pdf",
            "unit": "SGA 4 Exposes XVIII-XIX",
            "status": "Fresh current English working draft: Expose XVIII section 3 and complete Expose XIX, completing the current SGA 4 working draft.",
            "artifact": "92 SGA - SGA 4 Completion and SGA 5 Expose I Section 2 Sources and Render Checks.zip",
            "root": "sga4_completion_and_sga5_expose_i_section_2_sources",
        },
        {
            "fragment": "batch_026",
            "suffix": "02_new_translation_latex/batch_026/SGA5_Expose_I_introduction_sections_1_to_2_en.pdf",
            "dest": "30 SGA 5 - English through Expose I section 2.pdf",
            "unit": "SGA 5",
            "status": "Fresh current English working draft: SGA 5 Expose I opening through section 2.",
            "artifact": "92 SGA - SGA 4 Completion and SGA 5 Expose I Section 2 Sources and Render Checks.zip",
            "root": "sga4_completion_and_sga5_expose_i_section_2_sources",
            "superseded_by": "batch_028",
        },
        {
            "fragment": "batch_027",
            "suffix": "02_new_translation_latex/batch_027/SGA5_Expose_I_complete_and_Expose_III_to_III_B_5_10_en.pdf",
            "dest": "30 SGA 5 - English Expose I Complete and Expose III to III B 5.10.pdf",
            "unit": "SGA 5",
            "status": "Fresh current English working draft: SGA 5 Expose I section 3 through section 5, Expose I bibliography and appendix fragment, Expose III continuation through section 6.12, and Expose III B through section II.5.10.",
            "artifact": "93 SGA - SGA 5 Expose I Complete and Expose III to III B 5.10 Sources and Render Checks.zip",
            "root": "sga5_expose_i_complete_and_expose_iii_to_iii_b_5_10_sources",
            "superseded_by": "batch_028",
        },
        {
            "fragment": "batch_027",
            "artifact": "93 SGA - SGA 5 Expose I Complete and Expose III to III B 5.10 Sources and Render Checks.zip",
            "root": "sga5_expose_i_complete_and_expose_iii_to_iii_b_5_10_sources",
            "artifact_only": True,
        },
        {
            "fragment": "batch_028",
            "artifact": "94 SGA - SGA 5 Later Delivered Segments Sources and Render Checks.zip",
            "root": "sga5_later_delivered_segments_sources",
            "artifact_only": True,
        },
        {
            "fragment": "batch_029",
            "artifact": "95 SGA - SGA 6 Opening Through Expose I Section 1.5.1 Sources and Render Checks.zip",
            "root": "sga6_opening_through_expose_i_section_1_5_1_sources",
            "artifact_only": True,
        },
        {
            "fragment": "batch_030",
            "artifact": "96 SGA - SGA 6 Expose I Continuation Through Expose V Section 2.3 Sources and Render Checks.zip",
            "root": "sga6_expose_i_continuation_through_expose_v_section_2_3_sources",
            "artifact_only": True,
        },
        {
            "fragment": "batch_031",
            "artifact": "97 SGA - SGA 6 Expose V Tail Through Expose VIII Section 3.4 Sources and Render Checks.zip",
            "root": "sga6_expose_v_tail_through_expose_viii_section_3_4_sources",
            "artifact_only": True,
        },
        {
            "fragment": "batch_032",
            "artifact": "98 SGA - SGA 6 Expose VIII Section 3.5 Through Expose XIII Section 2.11 Sources and Render Checks.zip",
            "root": "sga6_expose_viii_section_3_5_through_expose_xiii_section_2_11_sources",
            "artifact_only": True,
        },
        {
            "fragment": "batch_033",
            "artifact": "99 SGA - SGA 6 Completion and SGA 7-I Expose I Sources and Render Checks.zip",
            "root": "sga6_completion_and_sga7_i_expose_i_sources",
            "artifact_only": True,
        },
    ]
    fresh_packets = [(spec, find_fresh_zip(str(spec["fragment"]))) for spec in fresh_specs]
    fresh_packets = [
        (spec, path)
        for spec, path in fresh_packets
        if not (spec.get("superseded_by") and find_fresh_zip(str(spec["superseded_by"])) is not None)
    ]
    reset_dir(OUT)
    upload = OUT / "upload"
    reports = OUT / "reports"
    upload.mkdir(parents=True, exist_ok=True)
    reports.mkdir(parents=True, exist_ok=True)

    # Front-facing translations: coherent whole/current readers only.
    expose_i_complete_tex_parts = [
        "02_new_translation_latex/SGA4_Expose_I_opening_sections_0_to_1_4_en.tex",
        "02_new_translation_latex/batch_002/SGA4_Expose_I_sections_2_to_5_en.tex",
        "02_new_translation_latex/batch_003/SGA4_Expose_I_sections_6_to_7_en.tex",
        "02_new_translation_latex/batch_004/SGA4_Expose_I_sections_8_1_to_8_6_en.tex",
        "02_new_translation_latex/batch_004/SGA4_Expose_I_sections_8_7_to_8_8_en.tex",
        "02_new_translation_latex/batch_005/SGA4_Expose_I_sections_8_9_to_8_13_en.tex",
        "02_new_translation_latex/batch_006/SGA4_Expose_I_section_9_0_to_9_13_1_en.tex",
        "02_new_translation_latex/batch_007/SGA4_Expose_I_sections_9_13_2_to_9_26_en.tex",
        "02_new_translation_latex/batch_008/SGA4_Expose_I_section_10_and_appendix_universes_en.tex",
    ]
    expose_ii_complete_tex_parts = [
        "02_new_translation_latex/batch_009/SGA4_Expose_II_opening_sections_1_to_2_7_en.tex",
        "02_new_translation_latex/batch_010/SGA4_Expose_II_sections_3_to_6_9_en.tex",
    ]
    selected_suffixes = [
        ("01_existing_translations_latex/fixed_math_render_tex/SGA1_existing_english_from_jcreinhold_mathfixed.tex", "00 SGA 1 - Existing English Translation Snapshot.pdf", "SGA 1", "Existing English translation snapshot, public reader rebuilt with reader-facing front matter"),
        ("01_existing_translations_latex/fixed_math_render_tex/SGA2_existing_english_from_jcreinhold_mathfixed.tex", "01 SGA 2 - Existing English Translation Snapshot.pdf", "SGA 2", "Existing English translation snapshot, public reader rebuilt with reader-facing front matter"),
        ("01_existing_translations_latex/fixed_math_render_tex/SGA3_existing_english_from_jcreinhold_mathfixed.tex", "02 SGA 3 - Existing English Translation Snapshot.pdf", "SGA 3", "Existing English translation snapshot, public reader rebuilt with reader-facing front matter"),
        ("02_new_translation_latex/cumulative/SGA4_Expose_I_complete_through_section_10_and_appendix_cumulative_en.pdf", "04 SGA 4 - Expose I Complete English Draft.pdf", "SGA 4 Expose I", "Complete current English working draft: Expose I through section 10 and appendix on universes"),
        ("02_new_translation_latex/cumulative/SGA4_Expose_II_complete_sections_1_to_6_9_cumulative_en.pdf", "05 SGA 4 - Expose II Complete English Draft.pdf", "SGA 4 Expose II", "Complete current English working draft: Expose II through section 6.9"),
        ("02_new_translation_latex/cumulative/SGA4_Expose_III_complete_cumulative_en.pdf", "06 SGA 4 - Expose III Complete English Draft.pdf", "SGA 4 Expose III", "Complete current English working draft: Expose III"),
        ("02_new_translation_latex/cumulative/SGA4_Expose_IV_sections_0_to_8_8_cumulative_en.tex", "07 SGA 4 - Expose IV English Draft through section 8.8.pdf", "SGA 4 Expose IV", "Current English working draft: Expose IV sections 0 through 8.8"),
    ]

    rows: list[dict[str, Any]] = []
    temp = OUT / "staging" / "tmp_pdf_parts"
    sga4_combined_parts: list[Path] = []
    with zipfile.ZipFile(src_zip, "r") as zf:
        for suffix, dest_name, unit, status in selected_suffixes:
            if dest_name.startswith("04 SGA 4 - Expose I"):
                dest = compile_clean_tex_parts(zf, expose_i_complete_tex_parts, upload / dest_name, "sga4_expose_i_complete")
            elif dest_name.startswith("05 SGA 4 - Expose II"):
                dest = compile_clean_tex_parts(zf, expose_ii_complete_tex_parts, upload / dest_name, "sga4_expose_ii_complete")
            elif dest_name.startswith("06 SGA 4 - Expose III"):
                dest = compile_clean_existing_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_011/SGA4_Expose_III_complete_en.tex",
                    upload / dest_name,
                )
            elif suffix.endswith(".tex"):
                dest = compile_clean_existing_sga_tex(zf, suffix, upload / dest_name)
            else:
                member = find_member(zf, suffix)
                dest = copy_member(zf, member, upload / dest_name)
            if unit.startswith("SGA 4"):
                sga4_combined_parts.append(dest)
            rows.append(
                {
                    "filename": dest.name,
                    "unit": unit,
                    "status": status,
                    "bytes": dest.stat().st_size,
                    "sha256": sha256(dest),
                }
            )
        if find_fresh_zip("batch_026") is None:
            sga5_intro = compile_clean_existing_sga_tex(
                zf,
                "02_new_translation_latex/SGA5_volume_introduction_opening_en.tex",
                temp / "sga5_intro.pdf",
            )
            sga5_section1 = compile_clean_existing_sga_tex(
                zf,
                "02_new_translation_latex/sga5_batch_002/SGA5_Expose_I_section_1_dualizing_complexes_en.tex",
                temp / "sga5_expose_i_section1.pdf",
            )
            sga5_current = upload / "30 SGA 5 - English intro and Expose I section 1.pdf"
            run_pdfunite([sga5_intro, sga5_section1], sga5_current)
            rows.append(
                {
                    "filename": sga5_current.name,
                    "unit": "SGA 5",
                    "status": "Combined current English reader: volume introduction opening and Expose I section 1",
                    "bytes": sga5_current.stat().st_size,
                    "sha256": sha256(sga5_current),
                }
            )

    for spec, fresh_zip in fresh_packets:
        if fresh_zip is None:
            continue
        if spec.get("artifact_only"):
            continue
        with zipfile.ZipFile(fresh_zip, "r") as zf:
            try:
                dest = compile_clean_fresh_sga_tex(zf, str(spec["suffix"]), upload / str(spec["dest"]))
            except Exception:
                member = find_member(zf, str(spec["suffix"]))
                dest = copy_member(zf, member, upload / str(spec["dest"]))
            if str(spec["unit"]).startswith("SGA 4"):
                sga4_combined_parts.append(dest)
            rows.append(
                {
                    "filename": dest.name,
                    "unit": spec["unit"],
                    "status": spec["status"],
                    "bytes": dest.stat().st_size,
                    "sha256": sha256(dest),
                }
            )

    batch026 = find_fresh_zip("batch_026")
    batch027 = find_fresh_zip("batch_027")
    batch028 = find_fresh_zip("batch_028")
    if batch026 is not None and batch027 is not None and batch028 is not None:
        sga5_parts: list[Path] = [
            build_cover_pdf(
                "SGA 5 -- Current English Working Draft from Delivered Segments",
                "Dualizing complexes, Lefschetz formulas, local terms, J-adic systems, and the beginning of l-adic cohomology",
                (
                    "This reader assembles the currently delivered SGA 5 English working translation segments into a single checking file. "
                    "It combines Expose I through section 2, the completion of Expose I together with Expose III and III B through II.5.10, "
                    "and the continuation from after III B II.5.10 through the end point described by the delivered source packet. "
                    "Coverage is being treated conservatively pending a line-by-line audit against the 496-page French reference scan. "
                    "The original French reference PDF and the source TeX/render-check packages are included separately in this record."
                ),
                OUT / "staging" / "sga5_complete" / "cover.pdf",
            )
        ]
        with zipfile.ZipFile(batch026, "r") as zf:
            sga5_parts.append(
                compile_clean_fresh_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_026/SGA5_Expose_I_introduction_sections_1_to_2_en.pdf",
                    OUT / "staging" / "sga5_complete" / "part_001_expose_i_sections_1_to_2.pdf",
                )
            )
        with zipfile.ZipFile(batch027, "r") as zf:
            sga5_parts.append(
                compile_clean_fresh_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_027/SGA5_Expose_I_complete_and_Expose_III_to_III_B_5_10_en.pdf",
                    OUT / "staging" / "sga5_complete" / "part_002_expose_i_complete_to_iii_b_5_10.pdf",
                )
            )
        with zipfile.ZipFile(batch028, "r") as zf:
            sga5_tail_bridge = compile_clean_fresh_sga_tex(
                zf,
                "02_new_translation_latex/batch_028/SGA5_Expose_III_B_after_5_10_to_Expose_VI_section_1_bridge_en.pdf",
                OUT / "staging" / "sga5_complete" / "part_003a_after_iii_b_5_10_to_expose_vi.pdf",
            )
            sga5_tail_continuation = compile_clean_fresh_sga_tex(
                zf,
                "02_new_translation_latex/batch_028/SGA5_Expose_VII_continuation_to_Expose_XV_end_en.pdf",
                OUT / "staging" / "sga5_complete" / "part_003b_expose_vii_to_end.pdf",
            )
            sga5_tail = OUT / "staging" / "sga5_complete" / "part_003_after_iii_b_5_10_to_end.pdf"
            run_pdfunite([sga5_tail_bridge, sga5_tail_continuation], sga5_tail)
            sga5_parts.append(
                sga5_tail
            )
        sga5_current = upload / "30 SGA 5 - Current English Working Draft from Delivered Segments.pdf"
        run_pdfunite(sga5_parts, sga5_current)
        rows.append(
            {
                "filename": sga5_current.name,
                "unit": "SGA 5",
                "status": "Combined current English reader: currently delivered SGA 5 working segments assembled into one checking PDF; coverage is under audit against the 496-page French reference.",
                "bytes": sga5_current.stat().st_size,
                "sha256": sha256(sga5_current),
            }
        )

    batch029 = find_fresh_zip("batch_029")
    batch030 = find_fresh_zip("batch_030")
    batch031 = find_fresh_zip("batch_031")
    batch032 = find_fresh_zip("batch_032")
    batch033 = find_fresh_zip("batch_033")
    if batch029 is not None and batch030 is not None:
        if batch033 is not None:
            sga6_current_endpoint = "Expose XIV end"
        elif batch032 is not None:
            sga6_current_endpoint = "Expose XIII section 2.11"
        elif batch031 is not None:
            sga6_current_endpoint = "Expose VIII section 3.4"
        else:
            sga6_current_endpoint = "Expose V section 2.3"
        sga6_parts: list[Path] = [
            build_cover_pdf(
                "SGA 6 -- English Working Draft",
                f"Intersection theory and the Riemann--Roch theorem, through {sga6_current_endpoint}",
                (
                    "This reader assembles the currently delivered SGA 6 English working translation into a single checking file. "
                    "It combines the volume front matter, Expose 0, the Riemann--Roch appendix, Expose I through section 8, "
                    f"and the continuation through {sga6_current_endpoint}. "
                    "The original French reference PDF and the source TeX/render-check packages are included separately in this record."
                ),
                OUT / "staging" / "sga6_current" / "cover.pdf",
            )
        ]
        with zipfile.ZipFile(batch029, "r") as zf:
            sga6_parts.append(
                compile_clean_fresh_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_029/SGA6_frontmatter_expose0_appendix_en.pdf",
                    OUT / "staging" / "sga6_current" / "part_001_opening_through_expose_i_1_5_1.pdf",
                )
            )
        with zipfile.ZipFile(batch030, "r") as zf:
            sga6_parts.append(
                compile_clean_fresh_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_030/SGA6_Expose_I_sections_2_to_8_complete_en.pdf",
                    OUT / "staging" / "sga6_current" / "part_002_expose_i_sections_2_to_8.pdf",
                )
            )
            sga6_parts.append(
                compile_clean_fresh_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_030/SGA6_Expose_II_and_following_sections_en.pdf",
                    OUT / "staging" / "sga6_current" / "part_003_expose_ii_through_expose_v_2_3.pdf",
                )
            )
        if batch031 is not None:
            with zipfile.ZipFile(batch031, "r") as zf:
                sga6_parts.append(
                    compile_clean_fresh_sga_tex(
                        zf,
                        "02_new_translation_latex/batch_031/SGA6_Expose_V_2_3_4_to_Expose_VI_complete_en.pdf",
                        OUT / "staging" / "sga6_current" / "part_004_expose_v_tail_to_expose_vi.pdf",
                    )
                )
                sga6_parts.append(
                    compile_clean_fresh_sga_tex(
                        zf,
                        "02_new_translation_latex/batch_031/SGA6_Expose_VII_complete_en.pdf",
                        OUT / "staging" / "sga6_current" / "part_005_expose_vii.pdf",
                    )
                )
                sga6_parts.append(
                    compile_clean_fresh_sga_tex(
                        zf,
                        "02_new_translation_latex/batch_031/SGA6_Expose_VIII_opening_to_3_4_en.pdf",
                        OUT / "staging" / "sga6_current" / "part_006_expose_viii_to_3_4.pdf",
                    )
                )
        if batch032 is not None:
            with zipfile.ZipFile(batch032, "r") as zf:
                sga6_parts.append(
                    compile_clean_fresh_sga_tex(
                        zf,
                        "02_new_translation_latex/batch_032/SGA6_Expose_VIII_3_5_to_Expose_XIII_2_11_en.pdf",
                        OUT / "staging" / "sga6_current" / "part_007_expose_viii_3_5_to_xiii_2_11.pdf",
                    )
                )
        if batch033 is not None:
            with zipfile.ZipFile(batch033, "r") as zf:
                sga6_parts.append(
                    compile_clean_fresh_sga_tex(
                        zf,
                        "02_new_translation_latex/batch_033/SGA6_Expose_XIII_3_to_XIV_end_en.pdf",
                        OUT / "staging" / "sga6_current" / "part_008_expose_xiii_3_to_xiv_end.pdf",
                    )
                )
                sga7_i_current = compile_clean_fresh_sga_tex(
                    zf,
                    "02_new_translation_latex/batch_033/SGA7_I_introduction_and_expose_I_en.pdf",
                    upload / "32 SGA 7-I - English Working Draft Introduction and Expose I.pdf",
                )
                rows.append(
                    {
                        "filename": sga7_i_current.name,
                        "unit": "SGA 7-I",
                        "status": "Combined current English reader: introduction and Expose I from the latest delivered SGA 7-I working translation packet.",
                        "bytes": sga7_i_current.stat().st_size,
                        "sha256": sha256(sga7_i_current),
                    }
                )
        sga6_current = upload / f"31 SGA 6 - English Working Draft through {sga6_current_endpoint}.pdf"
        run_pdfunite(sga6_parts, sga6_current)
        rows.append(
            {
                "filename": sga6_current.name,
                "unit": "SGA 6",
                "status": f"Combined current English reader: volume opening, Expose 0, Riemann--Roch appendix, Expose I through section 8, and continuation through {sga6_current_endpoint}.",
                "bytes": sga6_current.stat().st_size,
                "sha256": sha256(sga6_current),
            }
        )

    if sga4_combined_parts:
        sga4_current = upload / "03 SGA 4 - Complete English Working Draft.pdf"
        run_pdfunite(sga4_combined_parts, sga4_current)
        rows.append(
            {
                "filename": sga4_current.name,
                "unit": "SGA 4",
                "status": "Combined current English reader: complete current working draft of SGA 4, Exposes I through XIX.",
                "bytes": sga4_current.stat().st_size,
                "sha256": sha256(sga4_current),
            }
        )

    source_pdfs = [
        (TYPESSET_SGA / "sga1.pdf", "40 SGA 1 - French Reference PDF.pdf", "SGA 1 source/reference"),
        (TYPESSET_SGA / "sga2.pdf", "41 SGA 2 - French Reference PDF.pdf", "SGA 2 source/reference"),
        (TYPESSET_SGA / "sga3-1.pdf", "42 SGA 3 Part 1 - French Reference PDF.pdf", "SGA 3 part 1 source/reference"),
        (TYPESSET_SGA / "sga3-2.pdf", "43 SGA 3 Part 2 - French Reference PDF.pdf", "SGA 3 part 2 source/reference"),
        (TYPESSET_SGA / "sga3-3.pdf", "44 SGA 3 Part 3 - French Reference PDF.pdf", "SGA 3 part 3 source/reference"),
        (TYPESSET_SGA / "sga4-1.pdf", "45 SGA 4 Part 1 - French Reference PDF.pdf", "SGA 4 part 1 source/reference"),
        (TYPESSET_SGA / "sga4-2.pdf", "46 SGA 4 Part 2 - French Reference PDF.pdf", "SGA 4 part 2 source/reference"),
        (TYPESSET_SGA / "sga4-3.pdf", "47 SGA 4 Part 3 - French Reference PDF.pdf", "SGA 4 part 3 source/reference"),
        (TYPESSET_SGA / "sga4.5.pdf", "48 SGA 4.5 - French Reference PDF.pdf", "SGA 4.5 source/reference"),
        (SGA_HANDOFF / "03_SGA_5_7_REFERENCE_SCANS" / "SGA5.pdf", "49 SGA 5 - French Reference PDF.pdf", "SGA 5 source/reference"),
        (SGA_HANDOFF / "03_SGA_5_7_REFERENCE_SCANS" / "sga6.pdf", "50 SGA 6 - French Reference PDF.pdf", "SGA 6 source/reference"),
        (SGA_HANDOFF / "03_SGA_5_7_REFERENCE_SCANS" / "sga7-1.pdf", "51 SGA 7 Tome 1 - French Reference PDF.pdf", "SGA 7 tome 1 source/reference"),
        (SGA_HANDOFF / "03_SGA_5_7_REFERENCE_SCANS" / "sga7-2.pdf", "52 SGA 7 Tome 2 - French Reference PDF.pdf", "SGA 7 tome 2 source/reference"),
    ]
    for src, dest_name, status in source_pdfs:
        if src.exists():
            dest = copy_file(src, upload / dest_name)
            rows.append(
                {
                    "filename": dest.name,
                    "unit": status,
                    "status": "Original/reference PDF for checking translation and source alignment",
                    "bytes": dest.stat().st_size,
                    "sha256": sha256(dest),
                }
            )

    copy_public_zip(src_zip, upload / "80 SGA - Translation Sources, Render Checks, and Review Logs.zip", "sga_translation_sources_current")
    for spec, fresh_zip in fresh_packets:
        if fresh_zip is not None:
            copy_public_zip(fresh_zip, upload / str(spec["artifact"]), str(spec["root"]))

    for row in rows:
        filename = str(row.get("filename", ""))
        if filename.lower().endswith(".pdf"):
            pages = pdf_pages(upload / filename)
            if pages is not None:
                row["pages"] = pages

    page_counts = {str(row["filename"]): row.get("pages") for row in rows if str(row.get("filename", "")).lower().endswith(".pdf")}
    sga5_pages = page_counts.get("30 SGA 5 - Current English Working Draft from Delivered Segments.pdf")
    sga6_pages = page_counts.get("31 SGA 6 - English Working Draft through Expose XIV end.pdf")
    sga5_reference_pages = page_counts.get("49 SGA 5 - French Reference PDF.pdf")
    sga6_reference_pages = page_counts.get("50 SGA 6 - French Reference PDF.pdf")

    source_packets_used = list(dict.fromkeys([src_zip, *[fresh_zip for _, fresh_zip in fresh_packets if fresh_zip is not None]]))
    source_packet_names = [path.name for path in source_packets_used]
    highest_batch = max((batch for batch in (batch_number(path) for path in source_packets_used) if batch is not None), default=None)

    summary = {
        "generated_at": now_iso(),
        "public_title": "Seminaire de Geometrie Algebrique (SGA): English Translation Working Drafts",
        "source_packet_note": "Latest locally available cumulative SGA 4 packet plus later fresh SGA 4/5/6/7 packets staged as current source/artifact ZIPs.",
        "source_packets_used": source_packet_names,
        "highest_source_batch": highest_batch,
        "fresh_packet_note": "Fresh source packets for SGA 4 Expose IV section 9, Expose IV sections 10-14, Expose V sections 0-8, Expose VI, Expose VII, Exposes VIII-XII section 5.11, Expose XII section 6 through Expose XVII section 5.2.4, Expose XVII completion through Expose XVIII section 2, the SGA 4 completion/SGA 5 Expose I section 2 packet, the SGA 5 Expose I/III/III B packet, the later delivered SGA 5 segments packet, SGA 6 through Expose XIV end, and the opening SGA 7-I material are included as ZIP artifacts.",
        "top_level_reader_pdf_count": len(rows),
        "key_page_counts": {
            "sga5_current_english_reader_pages": sga5_pages,
            "sga5_french_reference_pages": sga5_reference_pages,
            "sga6_current_english_reader_pages": sga6_pages,
            "sga6_french_reference_pages": sga6_reference_pages,
        },
        "top_level_reader_pdfs": rows,
        "coverage": {
            "sga1": "Existing English translation snapshot present.",
            "sga2": "Existing English translation snapshot present.",
            "sga3": "Existing English translation snapshot present.",
            "sga4_expose_i": "Complete working English draft through section 10 and appendix on universes.",
            "sga4_expose_ii": "Complete working English draft through section 6.9.",
            "sga4_expose_iii": "Complete working English draft.",
            "sga4": "Combined current English reader: complete current working draft of SGA 4, Exposes I through XIX.",
            "sga4_expose_iv": "Working English draft through section 14, assembled from the cumulative Expose IV draft through 8.8 plus fresh section 9 and sections 10-14 packets.",
            "sga4_expose_v": "Fresh current working English draft for the introduction and sections 0-8; the latest source packet describes this as completing the current Expose V draft.",
            "sga4_expose_vi": "Fresh current working English draft through section 9; the latest source packet describes this as completing the current Expose VI draft.",
            "sga4_expose_vii": "Fresh complete current working English draft.",
            "sga4_exposes_viii_to_xii": "Fresh current working English draft: Exposes VIII-XI complete and Expose XII through section 8 when combined with the next packet.",
            "sga4_exposes_xiii_to_xvii": "Fresh current working English draft: Exposes XIII-XVII complete.",
            "sga4_expose_xviii": "Fresh current working English draft: Expose XVIII complete.",
            "sga4_expose_xix": "Fresh current working English draft: Expose XIX complete.",
            "sga5": f"Combined current English working reader present: {sga5_pages or 'unknown'} pages assembled from the currently delivered Expose I material, Expose III/III B through section II.5.10, and the later delivered continuation; coverage is under audit against the {sga5_reference_pages or 496}-page French reference scan and should not be called a complete proofread SGA 5 volume yet.",
            "sga6": f"Combined current English working reader present: {sga6_pages or 'unknown'} pages containing front matter, Expose 0, Riemann--Roch appendix, Expose I through section 8, and continuation through Expose XIV end; coverage is under audit against the {sga6_reference_pages or 702}-page French reference scan.",
            "sga7_i": "Opening current English working reader present: introduction and Expose I.",
            "reference_pdf_note": "SGA 5, SGA 6, SGA 7-I, and SGA 7-II French reference PDFs are image-based scans; they open and page-count correctly, but they are not expected to expose much embedded text.",
            "proofreading": "Working drafts for continuation; not certified final proofread editions.",
        },
    }
    write_json(upload / "99 SGA - Public Summary.json", summary)
    write_json(reports / "sga_current_summary.json", summary)

    manifest = []
    for path in sorted(upload.iterdir(), key=lambda p: p.name.lower()):
        if path.is_file():
            manifest.append({"filename": path.name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_json(reports / "upload_manifest.json", manifest)

    description = (
        "<p>Linked SGA record for the Modern LaTeX Editions of Public-Domain Mathematics Manuscripts project. "
        "This record collects current English translation working drafts, source/reference PDFs, and render checks for continuing SGA translation work. "
        "Top-level translation PDFs are coherent current readers rather than loose section fragments; the artifact ZIP preserves complete TeX/Markdown, render checks, review logs, validation notes, and reference material.</p>"
        "<p><strong>Human-readable contents.</strong> This release contains existing English translation snapshots for SGA 1, SGA 2, and SGA 3; "
        "a complete current English working translation reader for SGA 4, Exposes I through XIX, available both as a combined reader and as expose/section readers; "
        "the current delivered SGA 5 English working segments assembled into one checking reader, with coverage under audit against the French reference scan; "
        "the current SGA 6 English working reader through Expose XIV end; "
        "and the current opening SGA 7-I English working reader containing the introduction and Expose I. Source/reference French PDFs for SGA 1 through SGA 7 are included as top-level checking files where locally available.</p>"
        "<p><strong>Status at a glance.</strong></p>"
        "<ul>"
        "<li>SGA 1 existing English snapshot: <code>[##########] present</code>.</li>"
        "<li>SGA 2 existing English snapshot: <code>[##########] present</code>.</li>"
        "<li>SGA 3 existing English snapshot: <code>[##########] present</code>.</li>"
        "<li>SGA 4 Expose I English working draft: <code>[##########] complete current draft</code>, through section 10 and appendix on universes.</li>"
        "<li>SGA 4 Expose II English working draft: <code>[##########] complete current draft</code>, through section 6.9.</li>"
        "<li>SGA 4 Expose III English working draft: <code>[##########] complete current draft</code>.</li>"
        "<li>SGA 4 combined English working reader: <code>[##########] complete current working draft of Exposes I-XIX</code>.</li>"
        "<li>SGA 4 Expose IV English working draft: <code>[##########] current draft through section 14</code>.</li>"
        "<li>SGA 4 Expose V English working draft: <code>[##########] introduction and sections 0-8 are present as fresh working drafts</code>.</li>"
        "<li>SGA 4 Expose VI English working draft: <code>[##########] current draft through section 9</code>.</li>"
        "<li>SGA 4 Exposes VII-XI English working drafts: <code>[##########] complete current drafts</code>.</li>"
        "<li>SGA 4 Expose XII English working draft: <code>[##########] current draft through section 8</code>.</li>"
        "<li>SGA 4 Exposes XIII-XVII English working drafts: <code>[##########] complete current drafts</code>.</li>"
        "<li>SGA 4 Expose XVIII English working draft: <code>[##########] complete current draft</code>.</li>"
        "<li>SGA 4 Expose XIX English working draft: <code>[##########] complete current draft</code>.</li>"
        f"<li>SGA 5 English working material: <code>[###-------] delivered working segments assembled</code>; this is not described as a certified complete SGA 5 reader until the {sga5_pages or 'current'}-page assembled draft is audited against the {sga5_reference_pages or 496}-page French reference scan and the apparent gaps between delivered expose ranges are resolved.</li>"
        f"<li>SGA 6 English working material: <code>[#######---] current working reader through Expose XIV end</code>; the latest assembled reader is {sga6_pages or 'current'} pages, and the latest delivered packet describes this as completing the current SGA 6 pass, but this remains pending independent audit against the {sga6_reference_pages or 702}-page French reference scan.</li>"
        "<li>SGA 7-I English working material: <code>[#---------] opening reader present</code>; introduction and Expose I are present from the latest delivered translation packet.</li>"
        "<li>Original/reference PDFs for SGA 1-7: <code>[##########] present where locally available</code>, as direct top-level files for checking against the translations. The SGA 5, SGA 6, SGA 7-I, and SGA 7-II French reference files are image-based scan PDFs: they open and page-count correctly, but they are not expected to provide reliable embedded text extraction.</li>"
        "<li>Mathematical proofreading/final edition status: <code>[----------] working draft</code>; useful for continuation, not a certified critical edition.</li>"
        "</ul>"
        "<p><strong>Workflow.</strong> Source scans, existing translation snapshots, TeX drafts, render checks, and reference PDFs are organized here for inspection and continuation. "
        "Reader-facing files are organized by corpus, volume, and expose; source material and editorial work files are kept in artifact ZIPs rather than in public titles or reader PDFs.</p>"
    )

    metadata = {
        "title": "Seminaire de Geometrie Algebrique (SGA): English Translation Working Drafts",
        "upload_type": "dataset",
        "publication_date": date.today().isoformat(),
        "version": "2026-05-28 current SGA working translation release with SGA 4 complete, SGA 5 delivered segments under coverage audit, SGA 6 through Expose XIV end, and SGA 7-I opening material",
        "description": description,
        "creators": [{"name": "Manuscript Typesetting Project", "affiliation": "Independent"}],
        "access_right": "open",
        "license": "cc0-1.0",
        "keywords": ["SGA", "Grothendieck", "algebraic geometry", "translation", "LaTeX", "mathematics", "public domain", "CC0", "typesetting"],
        "related_identifiers": [
            {"identifier": MAIN_CONCEPT_DOI, "relation": "isPartOf", "scheme": "doi"},
            {"identifier": MAIN_RECORD_URL, "relation": "isReferencedBy", "scheme": "url"},
        ],
        "notes": "Current public-facing SGA record, organized by volume/expose and translation status.",
    }
    write_json(ZENODO / "metadata_satellite_sga_working_translation_public_current.json", metadata)

    print(
        json.dumps(
            {
                "cumulative_anchor_zip": str(src_zip),
                "source_packets_used": source_packet_names,
                "highest_source_batch": highest_batch,
                "upload": str(upload),
                "metadata": str(ZENODO / "metadata_satellite_sga_working_translation_public_current.json"),
                "files": len(manifest),
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


