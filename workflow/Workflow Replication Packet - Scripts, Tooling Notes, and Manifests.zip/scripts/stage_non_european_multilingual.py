#!/usr/bin/env python3
"""Stage the current multilingual non-European mathematics record.

This release is language-first for the reader surface:

* combined translation readers by language;
* individual translation PDFs for direct work-level download;
* combined original-language readers by corpus;
* individual original/reference PDFs;
* TeX/source material and OCR/review material in clean ZIP artifacts.

Local run/tool names, executable TeX binaries, and source drop ZIPs are not used
as public-facing titles or uploaded public files.
"""

from __future__ import annotations

import csv
import hashlib
import html
import json
import os
import re
import shutil
import subprocess
import unicodedata
import zipfile
from datetime import date, datetime
from pathlib import Path
from typing import Any

import fitz


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE_ROOT = (
    Path.home()
    / "Documents"
    / "Papors"
    / "Chatnotes"
    / "CHat translates and clean"
    / "translations"
    / "Kimi multil"
    / "Kimi multil v3"
)
SOURCE_ROOT = Path(os.environ.get("NON_EU_SOURCE_ROOT", str(DEFAULT_SOURCE_ROOT)))
OUT_ROOT = PROJECT_ROOT / "release_candidates" / "zenodo_satellite_non_european_multilingual_current"
WORK = OUT_ROOT / "work"
UPLOAD = OUT_ROOT / "upload"
REPORTS = OUT_ROOT / "reports"
ZENODO = PROJECT_ROOT / "zenodo"

MAIN_CONCEPT_DOI = "10.5281/zenodo.20393488"
MAIN_RECORD_URL = "https://zenodo.org/records/20441732"

TRANSLATION_GROUPS: list[dict[str, str]] = [
    {
        "key": "english_bilingual",
        "label": "English bilingual translation drafts",
        "prefix": "translations/en",
        "combined": "00_tr_en__non_eu_combined.pdf",
        "individual_prefix": "02_tr_en",
    },
    {
        "key": "classical_modern_chinese",
        "label": "Classical-modern Chinese translation drafts",
        "prefix": "translations/zh",
        "combined": "00_tr_zh_classical_modern__chinese_combined.pdf",
        "individual_prefix": "02_tr_zh",
    },
    {
        "key": "arabic",
        "label": "Arabic translation drafts",
        "prefix": "translations/ar",
        "combined": "00_tr_ar__non_eu_combined.pdf",
        "individual_prefix": "02_tr_ar",
    },
]

ORIGINAL_GROUPS: list[dict[str, str]] = [
    {
        "key": "chinese_originals",
        "label": "Chinese original-language modern LaTeX drafts",
        "prefix": "chinese",
        "combined": "01_orig_chinese__combined.pdf",
        "individual_prefix": "03_orig_chinese",
    },
    {
        "key": "indian_originals",
        "label": "Indian original-language modern LaTeX drafts",
        "prefix": "indian",
        "combined": "01_orig_indian__combined.pdf",
        "individual_prefix": "03_orig_indian",
    },
    {
        "key": "islamic_originals",
        "label": "Islamic and Arabic mathematical original-language modern LaTeX drafts",
        "prefix": "islamic",
        "combined": "01_orig_islamic_arabic__combined.pdf",
        "individual_prefix": "03_orig_islamic",
    },
    {
        "key": "historical_references",
        "label": "Historical reference texts and witnesses",
        "prefix": "references",
        "combined": "01_combined_pdf__references__historical_witnesses_modern_latex_current.pdf",
        "individual_prefix": "04_ref",
    },
]

TRANSLATION_WORKS: list[dict[str, Any]] = [
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "anon_jiuzhang",
        "title": "Anonymous, Jiuzhang Suanshu / Nine Chapters, volumes 1-9",
        "sources": [
            "translations/en/chinese/jiuzhang-suanshu-vols1-3_bilingual.pdf",
            "translations/en/chinese/jiuzhang-suanshu-vols4-6_bilingual.pdf",
            "translations/en/chinese/jiuzhang-suanshu-vols7-9_bilingual.pdf",
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "li_ye_ceyuan_v1_12",
        "title": "Li Ye, Ceyuan Haijing, current English bilingual volumes 1-12",
        "sources": [
            "translations/en/chinese/li-ye-ceyuan-haijing-vols1-3_bilingual.pdf",
            "translations/en/chinese/li-ye-ceyuan-haijing-vols4-6_bilingual.pdf",
            "translations/en/chinese/li-ye-ceyuan-haijing-vols7-9_bilingual.pdf",
            "translations/en/chinese/li-ye-ceyuan-haijing-vols10-12_bilingual.pdf",
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "qin_shuxue_jz_f1_9",
        "title": "Qin Jiushao, Shuxue Jiuzhang, current English bilingual fascicles 1-9",
        "sources": [
            "translations/en/chinese/qin-jiushao-shuxue-jiuzhang-fascicle1_bilingual.pdf",
            "translations/en/chinese/qin-jiushao-shuxue-jiuzhang-fascicle2_bilingual.pdf",
            "translations/en/chinese/qin-jiushao-shuxue-jiuzhang-fascicles3-4_bilingual.pdf",
            "translations/en/chinese/qin-jiushao-shuxue-jiuzhang-fascicles5-6_bilingual.pdf",
            "translations/en/chinese/qin-jiushao-shuxue-jiuzhang-fascicles7-9_bilingual.pdf",
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "sunzi_suanjing",
        "title": "Sunzi, Sunzi Suanjing",
        "sources": ["translations/en/chinese/sunzi-suanjing_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "yang_hui_xiangjie_jz_p1_3",
        "title": "Yang Hui, Xiangjie Jiuzhang Suanfa, current English bilingual parts 1-3",
        "sources": [
            "translations/en/chinese/yang-hui-xiangjie-jiuzhang-part1_bilingual.pdf",
            "translations/en/chinese/yang-hui-xiangjie-jiuzhang-part2_bilingual.pdf",
            "translations/en/chinese/yang-hui-xiangjie-jiuzhang-part3_bilingual.pdf",
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "zhu_shijie_qimeng_p1_2",
        "title": "Zhu Shijie, Suanxue Qimeng, current English bilingual parts 1-2",
        "sources": [
            "translations/en/chinese/zhu-shijie-suanxue-qimeng-part1_bilingual.pdf",
            "translations/en/chinese/zhu-shijie-suanxue-qimeng-part2_bilingual.pdf",
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "aryabhata_aryabhatiya",
        "title": "Aryabhata, Aryabhatiya",
        "sources": ["translations/en/indian/aryabhata-aryabhatiya_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "bhaskara_bijaganita_p1_3",
        "title": "Bhaskara II, Bijaganita, current English bilingual parts 1-3",
        "sources": [
            "translations/en/indian/bhaskara-ii-bijaganita-part1_bilingual.pdf",
            "translations/en/indian/bhaskara-ii-bijaganita-part2_bilingual.pdf",
            "translations/en/indian/bhaskara-ii-bijaganita-part3_bilingual.pdf",
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "bhaskara_lilavati",
        "title": "Bhaskara II, Lilavati",
        "sources": ["translations/en/indian/bhaskara-ii-lilavati_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "brahmagupta_bss_translation_current",
        "title": "Brahmagupta, Brahmasphutasiddhanta, current English bilingual draft chunks",
        "sources": [
            *(f"translations/en/indian/brahmagupta-brahmasphutasiddhanta-pt1-chunk{i}_bilingual.pdf" for i in range(1, 7)),
            *(f"translations/en/indian/brahmagupta-brahmasphutasiddhanta-pt2-chunk{i}_bilingual.pdf" for i in range(1, 7)),
            *(f"translations/en/indian/brahmagupta-brahmasphutasiddhanta-pt3-chunk{i}_bilingual.pdf" for i in range(1, 4)),
        ],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "al_kashi_miftah",
        "title": "Jamshid al-Kashi, Miftah al-Hisab",
        "sources": ["translations/en/islamic/al-kashi-miftah-al-hisab_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "al_khwarizmi_al_jabr",
        "title": "al-Khwarizmi, al-Jabr wa'l-Muqabala",
        "sources": ["translations/en/islamic/al-khwarizmi-al-jabr_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "al_tusi_shakl_qatta",
        "title": "Nasir al-Din al-Tusi, Shakl al-Qatta",
        "sources": ["translations/en/islamic/al-tusi-shakl-al-qatta_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "robert_chester_karpinski_al_khwarizmi_1915",
        "title": "Robert of Chester / Louis Karpinski, Latin translation of al-Khwarizmi (1915)",
        "sources": ["translations/en/islamic/karpinski-robert-of-chester-latin-translation-1915_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "omar_khayyam_algebra",
        "title": "Omar Khayyam, Treatise on Algebra",
        "sources": ["translations/en/islamic/omar-khayyam-sinaat-al-jabr_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "rosen_algebra_ben_musa_1831",
        "title": "Frederic Rosen, Algebra of Mohammed Ben Musa (1831)",
        "sources": ["translations/en/islamic/rosen-algebra-of-mohammed-ben-musa-1831_enhanced.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "ruska_arab_algebra",
        "title": "Julius Ruska, Zur ältesten arabischen Algebra",
        "sources": ["translations/en/islamic/ruska-zur-aeltesten-arabischen-algebra_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "al_muqaddasi_taqasim",
        "title": "al-Muqaddasi, Ahsan al-Taqasim",
        "sources": ["translations/en/references/al-muqaddasi-ahsan-al-taqasim_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "ibn_al_nadim_fihrist",
        "title": "Ibn al-Nadim, Kitab al-Fihrist",
        "sources": ["translations/en/references/ibn-al-nadim-kitab-al-fihrist_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "ibn_al_qifti_hukama",
        "title": "Ibn al-Qifti, Tarikh al-Hukama",
        "sources": ["translations/en/references/ibn-al-qifti-tarikh-al-hukama_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "said_al_andalusi_tabaqat",
        "title": "Sa'id al-Andalusi, Tabaqat al-Umam",
        "sources": ["translations/en/references/said-al-andalusi-tabaqat-al-umam_bilingual.pdf"],
    },
    {
        "language_group": "english_bilingual",
        "prefix": "01_work_tr_en",
        "slug": "smith_karpinski_numerals_1911",
        "title": "Smith and Karpinski, Hindu-Arabic Numerals (1911)",
        "sources": ["translations/en/references/smith-karpinski-hindu-arabic-numerals-1911_enhanced.pdf"],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "anon_jiuzhang",
        "title": "Anonymous, Jiuzhang Suanshu / Nine Chapters, classical-modern Chinese volumes 1-9",
        "sources": [
            "translations/zh/chinese/jiuzhang-suanshu-vols1-3_classical-modern_bilingual.pdf",
            "translations/zh/chinese/jiuzhang-suanshu-vols4-6_classical-modern_bilingual.pdf",
            "translations/zh/chinese/jiuzhang-suanshu-vols7-9_classical-modern_bilingual.pdf",
        ],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "li_ye_ceyuan_v1_12",
        "title": "Li Ye, Ceyuan Haijing, classical-modern Chinese volumes 1-12",
        "sources": [
            "translations/zh/chinese/li-ye-ceyuan-haijing-vols1-3_classical-modern_bilingual.pdf",
            "translations/zh/chinese/li-ye-ceyuan-haijing-vols4-6_classical-modern_bilingual.pdf",
            "translations/zh/chinese/li-ye-ceyuan-haijing-vols7-9_classical-modern_bilingual.pdf",
            "translations/zh/chinese/li-ye-ceyuan-haijing-vols10-12_classical-modern_bilingual.pdf",
        ],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "li_ye_ceyuan_fenlei",
        "title": "Li Ye, Ceyuan Haijing Fenlei Shishu, classical-modern Chinese volumes 1-10",
        "sources": [
            "translations/zh/chinese/li-ye-ceyuan-haijing-fenlei-shishu-vols1-3_classical-modern_bilingual.pdf",
            "translations/zh/chinese/li-ye-ceyuan-haijing-fenlei-shishu-vols4-5_classical-modern_bilingual.pdf",
            "translations/zh/chinese/li-ye-ceyuan-haijing-fenlei-shishu-vols6-10_classical-modern_bilingual.pdf",
        ],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "qin_shuxue_jz_modern_chinese_current",
        "title": "Qin Jiushao, Shuxue Jiuzhang, classical-modern Chinese current fascicles 1 and 5-9",
        "sources": [
            "translations/zh/chinese/qin-jiushao-shuxue-jiuzhang-fascicle1_classical-modern_bilingual.pdf",
            "translations/zh/chinese/qin-jiushao-shuxue-jiuzhang-fascicles5-6_classical-modern_bilingual.pdf",
            "translations/zh/chinese/qin-jiushao-shuxue-jiuzhang-fascicles7-9_classical-modern_bilingual.pdf",
        ],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "sunzi_suanjing",
        "title": "Sunzi, Sunzi Suanjing, classical-modern Chinese",
        "sources": ["translations/zh/chinese/sunzi-suanjing_classical-modern_bilingual.pdf"],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "yang_hui_xiangjie_jz_p1_3",
        "title": "Yang Hui, Xiangjie Jiuzhang Suanfa, classical-modern Chinese parts 1-3",
        "sources": [
            "translations/zh/chinese/yang-hui-xiangjie-jiuzhang-part1_classical-modern_bilingual.pdf",
            "translations/zh/chinese/yang-hui-xiangjie-jiuzhang-part2_classical-modern_bilingual.pdf",
            "translations/zh/chinese/yang-hui-xiangjie-jiuzhang-part3_classical-modern_bilingual.pdf",
        ],
    },
    {
        "language_group": "classical_modern_chinese",
        "prefix": "01_work_tr_zh",
        "slug": "zhu_shijie_qimeng_p1_2",
        "title": "Zhu Shijie, Suanxue Qimeng, classical-modern Chinese parts 1-2",
        "sources": [
            "translations/zh/chinese/zhu-shijie-suanxue-qimeng-part1_classical-modern_bilingual.pdf",
            "translations/zh/chinese/zhu-shijie-suanxue-qimeng-part2_classical-modern_bilingual.pdf",
        ],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "li_ye_ceyuan_ar_current",
        "title": "Li Ye, Ceyuan Haijing, current Arabic translation draft volumes 1-6 and 10-12",
        "sources": [
            "translations/ar/chinese/li-ye-ceyuan-haijing-vols1-3_arabic.pdf",
            "translations/ar/chinese/li-ye-ceyuan-haijing-vols4-6_arabic.pdf",
            "translations/ar/chinese/li-ye-ceyuan-haijing-vols10-12_arabic.pdf",
        ],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "qin_shuxue_jz_ar_current",
        "title": "Qin Jiushao, Shuxue Jiuzhang, current Arabic translation draft fascicles 1 and 4",
        "sources": [
            "translations/ar/chinese/qin-jiushao-shuxue-jiuzhang-fascicle1_arabic.pdf",
            "translations/ar/chinese/qin-jiushao-shuxue-jiuzhang-fascicle4_arabic.pdf",
        ],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "yang_hui_xiangjie_jz_p1",
        "title": "Yang Hui, Xiangjie Jiuzhang Suanfa, Arabic translation draft part 1",
        "sources": ["translations/ar/chinese/yang-hui-xiangjie-jiuzhang-part1_arabic.pdf"],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "sunzi_suanjing",
        "title": "Sunzi, Sunzi Suanjing, Arabic translation draft",
        "sources": ["translations/ar/chinese/sunzi-suanjing_arabic.pdf"],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "al_kashi_miftah",
        "title": "Jamshid al-Kashi, Miftah al-Hisab, Arabic translation draft",
        "sources": ["translations/ar/islamic/al-kashi-miftah-al-hisab_arabic.pdf"],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "al_khwarizmi_al_jabr",
        "title": "al-Khwarizmi, al-Jabr wa'l-Muqabala, Arabic transliteration and commentary draft",
        "filename_descriptor": "Arabic Transliteration and Commentary",
        "sources": ["translations/ar/islamic/al-khwarizmi-al-jabr_arabic-enhanced.pdf"],
    },
    {
        "language_group": "arabic",
        "prefix": "01_work_tr_ar",
        "slug": "omar_khayyam_algebra",
        "title": "Omar Khayyam, Treatise on Algebra, Arabic translation draft",
        "sources": ["translations/ar/islamic/omar-khayyam-sinaat-al-jabr_arabic.pdf"],
    },
]

ORIGINAL_WORKS: list[dict[str, Any]] = [
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "anon_jiuzhang",
        "title": "Anonymous, Jiuzhang Suanshu / Nine Chapters, volumes 1-9",
        "sources": [
            "chinese/jiuzhang-suanshu-vols1-3.pdf",
            "chinese/jiuzhang-suanshu-vols4-6.pdf",
            "chinese/jiuzhang-suanshu-vols7-9.pdf",
        ],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "li_ye_ceyuan",
        "title": "Li Ye, Ceyuan Haijing, volumes 1-12",
        "sources": [
            "chinese/li-ye-ceyuan-haijing-vols1-3.pdf",
            "chinese/li-ye-ceyuan-haijing-vols4-6.pdf",
            "chinese/li-ye-ceyuan-haijing-vols7-9.pdf",
            "chinese/li-ye-ceyuan-haijing-vols10-12.pdf",
        ],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "li_ye_ceyuan_fenlei",
        "title": "Li Ye, Ceyuan Haijing Fenlei Shishu, volumes 1-10",
        "sources": [
            "chinese/li-ye-ceyuan-haijing-fenlei-shishu-vols1-3.pdf",
            "chinese/li-ye-ceyuan-haijing-fenlei-shishu-vols4-5.pdf",
            "chinese/li-ye-ceyuan-haijing-fenlei-shishu-vols6-10.pdf",
        ],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "li_ye_ceyuan_detail",
        "title": "Li Ye, Ceyuan Haijing geometric detail",
        "sources": ["chinese/cyhj_detail.pdf"],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "qin_shuxue_jz",
        "title": "Qin Jiushao, Shuxue Jiuzhang, fascicles 1-9",
        "sources": [
            "chinese/qin-jiushao-shuxue-jiuzhang-fascicle1.pdf",
            "chinese/qin-jiushao-shuxue-jiuzhang-fascicle2.pdf",
            "chinese/qin-jiushao-shuxue-jiuzhang-fascicles3-4.pdf",
            "chinese/qin-jiushao-shuxue-jiuzhang-fascicles5-6.pdf",
            "chinese/qin-jiushao-shuxue-jiuzhang-fascicles7-9.pdf",
        ],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "sunzi_suanjing",
        "title": "Sunzi, Sunzi Suanjing",
        "sources": ["chinese/sunzi-suanjing.pdf"],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "yang_hui_xiangjie_jz",
        "title": "Yang Hui, Xiangjie Jiuzhang Suanfa, parts 1-3",
        "sources": [
            "chinese/yang-hui-xiangjie-jiuzhang-part1.pdf",
            "chinese/yang-hui-xiangjie-jiuzhang-part2.pdf",
            "chinese/yang-hui-xiangjie-jiuzhang-part3.pdf",
        ],
    },
    {
        "language_group": "chinese_originals",
        "prefix": "02_work_orig_chinese",
        "slug": "zhu_shijie_qimeng",
        "title": "Zhu Shijie, Suanxue Qimeng, parts 1-2",
        "sources": [
            "chinese/zhu-shijie-suanxue-qimeng-part1.pdf",
            "chinese/zhu-shijie-suanxue-qimeng-part2.pdf",
        ],
    },
    {
        "language_group": "indian_originals",
        "prefix": "02_work_orig_indian",
        "slug": "aryabhata_aryabhatiya",
        "title": "Aryabhata, Aryabhatiya",
        "sources": ["indian/aryabhata-aryabhatiya.pdf"],
    },
    {
        "language_group": "indian_originals",
        "prefix": "02_work_orig_indian",
        "slug": "bhaskara_bijaganita",
        "title": "Bhaskara II, Bijaganita, parts 1-3",
        "sources": [
            "indian/bhaskara-ii-bijaganita-part1.pdf",
            "indian/bhaskara-ii-bijaganita-part2.pdf",
            "indian/bhaskara-ii-bijaganita-part3.pdf",
        ],
    },
    {
        "language_group": "indian_originals",
        "prefix": "02_work_orig_indian",
        "slug": "bhaskara_lilavati",
        "title": "Bhaskara II, Lilavati",
        "sources": ["indian/bhaskara-ii-lilavati.pdf"],
    },
    {
        "language_group": "indian_originals",
        "prefix": "02_work_orig_indian",
        "slug": "brahmagupta_bss",
        "title": "Brahmagupta, Brahmasphutasiddhanta, current complete draft",
        "sources": [
            *(f"indian/brahmagupta-brahmasphutasiddhanta-pt1-chunk{i}.pdf" for i in range(1, 7)),
            *(f"indian/brahmagupta-brahmasphutasiddhanta-pt2-chunk{i}.pdf" for i in range(1, 7)),
            *(f"indian/brahmagupta-brahmasphutasiddhanta-pt3-chunk{i}.pdf" for i in range(1, 4)),
        ],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "al_kashi_miftah",
        "title": "Jamshid al-Kashi, Miftah al-Hisab",
        "sources": ["islamic/al-kashi-miftah-al-hisab.pdf"],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "al_khwarizmi_al_jabr",
        "title": "al-Khwarizmi, al-Jabr wa'l-Muqabala",
        "sources": ["islamic/al-khwarizmi-al-jabr-wa-l-muqabala.pdf"],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "al_tusi_shakl_qatta",
        "title": "Nasir al-Din al-Tusi, Shakl al-Qatta",
        "sources": ["islamic/al-tusi-shakl-al-qatta.pdf"],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "omar_khayyam_algebra",
        "title": "Omar Khayyam, Treatise on Algebra",
        "sources": ["islamic/omar-khayyam-sinaat-al-jabr.pdf"],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "ruska_arab_algebra_1917",
        "title": "Julius Ruska, Zur altesten arabischen Algebra (1917)",
        "sources": ["islamic/ruska-zur-aeltesten-arabischen-algebra-1917.pdf"],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "rosen_algebra_ben_musa_1831",
        "title": "Frederic Rosen, Algebra of Mohammed Ben Musa (1831)",
        "sources": ["islamic/rosen-algebra-of-mohammed-ben-musa-1831.pdf"],
    },
    {
        "language_group": "islamic_originals",
        "prefix": "02_work_orig_islamic",
        "slug": "robert_chester_karpinski_1915",
        "title": "Robert of Chester / Louis Karpinski, Latin translation of al-Khwarizmi (1915)",
        "sources": ["islamic/karpinski-robert-of-chester-latin-translation-1915.pdf"],
    },
    {
        "language_group": "historical_references",
        "prefix": "03_work_reference",
        "slug": "said_al_andalusi_tabaqat",
        "title": "Sa'id al-Andalusi, Tabaqat al-Umam",
        "sources": ["references/said-al-andalusi-tabaqat-al-umam.pdf"],
    },
    {
        "language_group": "historical_references",
        "prefix": "03_work_reference",
        "slug": "al_muqaddasi_taqasim",
        "title": "al-Muqaddasi, Ahsan al-Taqasim",
        "sources": ["references/al-muqaddasi-ahsan-al-taqasim.pdf"],
    },
    {
        "language_group": "historical_references",
        "prefix": "03_work_reference",
        "slug": "ibn_al_nadim_fihrist",
        "title": "Ibn al-Nadim, Kitab al-Fihrist",
        "sources": ["references/ibn-al-nadim-kitab-al-fihrist.pdf"],
    },
    {
        "language_group": "historical_references",
        "prefix": "03_work_reference",
        "slug": "ibn_al_qifti_hukama",
        "title": "Ibn al-Qifti, Tarikh al-Hukama",
        "sources": ["references/ibn-al-qifti-tarikh-al-hukama.pdf"],
    },
    {
        "language_group": "historical_references",
        "prefix": "03_work_reference",
        "slug": "smith_karpinski_numerals_1911",
        "title": "Smith and Karpinski, Hindu-Arabic Numerals (1911)",
        "sources": ["references/smith-karpinski-hindu-arabic-numerals-1911.pdf"],
    },
]

TEXTUAL_SOURCE_SUFFIXES = {
    ".tex",
    ".sty",
    ".cfg",
    ".def",
}

OCR_REVIEW_SUFFIXES = {".txt"}
IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg"}
SKIP_TOP_DIRS = {"texbin", "mybin"}
SKIP_SOURCE_ZIP_SUFFIXES = {".zip"}
SKIP_PUBLIC_EXACT_NAMES = {
    "master-index.pdf",
    "master-index.tex",
    "test-arabic-font.pdf",
    "test-arabic-font.tex",
}
PUBLIC_PDF_EXCLUDE_RELATIVE = {
    # Current source-rendered PDFs whose visible text includes literal HTML/HTTP
    # error-page material. Keep them in ZIP provenance, but omit them from the
    # public reader surface until a clean rerender is available.
    "translations/ar/chinese/jiuzhang-suanshu-vols1-3_arabic.pdf",
    "translations/ar/chinese/sunzi-suanjing_arabic.pdf",
    "translations/en/references/ibn-al-qifti-tarikh-al-hukama_bilingual.pdf",
    # These two generated original-language/reference PDFs are mostly blank in
    # the current source dump. The complete facsimiles are exposed below as
    # reference scans while the generated TeX/PDF stays in the artifact ZIPs.
    "islamic/rosen-algebra-of-mohammed-ben-musa-1831.pdf",
    "islamic/karpinski-robert-of-chester-latin-translation-1915.pdf",
}
PUBLIC_PDF_EXCLUDE_REASON = (
    "current rendered PDF has visible upstream/error artifacts or unusably sparse pages; preserved in source/provenance ZIPs pending clean rerender"
)
REFERENCE_SCAN_WORKS: list[dict[str, Any]] = [
    {
        "language_group": "reference_scans",
        "title": "Frederic Rosen, Algebra of Mohammed Ben Musa (1831)",
        "filename": "60-06 Reference Scan - Rosen - Algebra of Mohammed Ben Musa (1831).pdf",
        "source": PROJECT_ROOT
        / "external_downloads"
        / "central_asia_reference_downloads"
        / "CA06__al-Khwarizmi_Rosen__The_Algebra_of_Mohammed_ben_Musa__1831.pdf",
        "note": "Complete facsimile scan used because the current source-rendered original/reference PDF is mostly blank.",
    },
    {
        "language_group": "reference_scans",
        "title": "Robert of Chester / Louis Karpinski, Latin translation of al-Khwarizmi (1915)",
        "filename": "60-07 Reference Scan - Robert of Chester and Karpinski (1915).pdf",
        "source": PROJECT_ROOT
        / "external_downloads"
        / "central_asia_reference_downloads"
        / "CA07__al-Khwarizmi_Karpinski__Robert_of_Chester_Latin_Translation__1915.pdf",
        "note": "Complete facsimile scan used because the current source-rendered original/reference PDF is mostly blank.",
    },
]
DEFAULT_RAW_OUTPUT_ZIPS = [
    SOURCE_ROOT / "Kimi_Agent_Refinement Round.zip",
    SOURCE_ROOT.parent / "Kimi_Agent_Refinement Round.zip",
    SOURCE_ROOT.parent / "Kimi_Agent_Refinement Round2.zip",
]
RAW_OUTPUT_ZIPS = [
    Path(item)
    for item in os.environ.get(
        "NON_EU_RAW_OUTPUT_ZIPS",
        ";".join(str(path) for path in DEFAULT_RAW_OUTPUT_ZIPS),
    ).split(";")
    if item.strip()
]
FALLBACK_SOURCE_ROOTS = []
for candidate in [
    SOURCE_ROOT,
    SOURCE_ROOT.parent / "Kimi_Agent_Refinement Round",
    SOURCE_ROOT.parent / "Kimi_Agent_Refinement Round2",
]:
    if candidate not in FALLBACK_SOURCE_ROOTS:
        FALLBACK_SOURCE_ROOTS.append(candidate)
MASTER_INDEX_FILENAME = "00 Index - Non-European Mathematics Corpus.pdf"

COMBINED_PUBLIC_FILES: dict[str, dict[str, str]] = {
    "english_bilingual": {
        "filename": "01 Combined English Translations.pdf",
        "title": "Combined English Translation Drafts",
        "subtitle": "Chinese, Indian, Islamic, Arabic, and historical-reference mathematical texts",
    },
    "classical_modern_chinese": {
        "filename": "02 Combined Modern Chinese Renderings.pdf",
        "title": "Combined Modern Chinese Renderings",
        "subtitle": "Classical Chinese mathematical texts rendered into modern Chinese",
    },
    "arabic": {
        "filename": "03 Combined Arabic Translation Drafts.pdf",
        "title": "Combined Arabic Translation Drafts",
        "subtitle": "Li Ye, Qin Jiushao, Sunzi, and al-Khwarizmi",
    },
    "chinese_originals": {
        "filename": "04 Chinese Originals - Modern LaTeX.pdf",
        "title": "Original Chinese Mathematical Texts",
        "subtitle": "Modern LaTeX working drafts",
    },
    "indian_originals": {
        "filename": "05 Indian Originals - Modern LaTeX.pdf",
        "title": "Original Indian Mathematical Texts",
        "subtitle": "Modern LaTeX working drafts",
    },
    "islamic_originals": {
        "filename": "06 Islamic and Arabic Originals - Modern LaTeX.pdf",
        "title": "Original Islamic and Arabic Mathematical Texts",
        "subtitle": "Modern LaTeX working drafts",
    },
    "historical_references": {
        "filename": "07 Historical References - Modern LaTeX.pdf",
        "title": "Historical Reference Texts and Witnesses",
        "subtitle": "Modern LaTeX working drafts",
    },
}

WORK_FILENAME_RULES: dict[str, tuple[str, str]] = {
    "english_bilingual": ("10", "English Translation"),
    "classical_modern_chinese": ("20", "Modern Chinese"),
    "arabic": ("30", "Arabic Translation"),
    "chinese_originals": ("40", "Chinese Original"),
    "indian_originals": ("50", "Indian Original"),
    "islamic_originals": ("60", "Islamic Original"),
    "historical_references": ("70", "Reference Text"),
}

ARTIFACT_PUBLIC_FILENAMES = {
    "tex": "80 Non-European Mathematics - TeX Sources and Combined Bundles.zip",
    "source_pdfs": "81 Non-European Mathematics - Source PDF Parts.zip",
    "ocr_notes": "82 Non-European Mathematics - OCR Text and Review Notes.zip",
    "page_images": "83 Non-European Mathematics - Page Images and OCR Working Images.zip",
    "summary": "90 Non-European Mathematics - Public Summary.json",
    "raw": "99 Non-European Mathematics - As-Received Source and Provenance Archive.zip",
}
VISIBLE_PDF_LABEL_REPLACEMENTS = [
    ("Translators note:", "Editorial note:"),
    ("Translator's note:", "Editorial note:"),
    ("Translator's Note:", "Editorial note:"),
    ("Translator's Notes", "Editorial Notes"),
    ("Translator's Preface", "Editorial Preface"),
]

SHORT_PUBLIC_TITLES = {
    "anon_jiuzhang": "Nine Chapters, vols. 1-9",
    "anon_jiuzhang_v1_3": "Nine Chapters, vols. 1-3",
    "li_ye_ceyuan_v1_9": "Li Ye - Ceyuan Haijing, vols. 1-9",
    "li_ye_ceyuan_v1_12": "Li Ye - Ceyuan Haijing, vols. 1-12",
    "li_ye_ceyuan_v1_3": "Li Ye - Ceyuan Haijing, vols. 1-3",
    "li_ye_ceyuan": "Li Ye - Ceyuan Haijing, vols. 1-12",
    "li_ye_ceyuan_fenlei": "Li Ye - Ceyuan Haijing Fenlei Shishu",
    "li_ye_ceyuan_fenlei_v1_3": "Li Ye - Ceyuan Haijing Fenlei, vols. 1-3",
    "li_ye_ceyuan_detail": "Li Ye - Ceyuan Haijing geometry",
    "qin_shuxue_jz_f1_2": "Qin - Shuxue Jiuzhang, fasc. 1-2",
    "qin_shuxue_jz_f1_9": "Qin - Shuxue Jiuzhang, fasc. 1-9",
    "qin_shuxue_jz_f1": "Qin - Shuxue Jiuzhang, fasc. 1",
    "qin_shuxue_jz_f5_6": "Qin - Shuxue Jiuzhang, fasc. 5-6",
    "qin_shuxue_jz_modern_chinese_current": "Qin - Shuxue Jiuzhang, fasc. 1 and 5-9",
    "qin_shuxue_jz": "Qin - Shuxue Jiuzhang, fasc. 1-9",
    "sunzi_suanjing": "Sunzi Suanjing",
    "yang_hui_xiangjie_jz_p1_2": "Yang Hui - Xiangjie, parts 1-2",
    "yang_hui_xiangjie_jz_p1_3": "Yang Hui - Xiangjie, parts 1-3",
    "yang_hui_xiangjie_jz_p1": "Yang Hui - Xiangjie, part 1",
    "yang_hui_xiangjie_jz": "Yang Hui - Xiangjie, parts 1-3",
    "zhu_shijie_qimeng_p1": "Zhu Shijie - Suanxue Qimeng, part 1",
    "zhu_shijie_qimeng_p1_2": "Zhu Shijie - Suanxue Qimeng, parts 1-2",
    "zhu_shijie_qimeng": "Zhu Shijie - Suanxue Qimeng, parts 1-2",
    "aryabhata_aryabhatiya": "Aryabhata - Aryabhatiya",
    "bhaskara_bijaganita_p1_2": "Bhaskara II - Bijaganita, parts 1-2",
    "bhaskara_bijaganita_p1_3": "Bhaskara II - Bijaganita, parts 1-3",
    "bhaskara_bijaganita": "Bhaskara II - Bijaganita, parts 1-3",
    "bhaskara_lilavati": "Bhaskara II - Lilavati",
    "brahmagupta_bss": "Brahmagupta - Brahmasphutasiddhanta",
    "brahmagupta_bss_translation_current": "Brahmagupta - Brahmasphutasiddhanta",
    "li_ye_ceyuan_ar_current": "Li Ye - Ceyuan Haijing, vols. 1-6 and 10-12",
    "qin_shuxue_jz_ar_current": "Qin - Shuxue Jiuzhang, fasc. 1 and 4",
    "al_kashi_miftah": "al-Kashi - Miftah al-Hisab",
    "al_khwarizmi_al_jabr": "al-Khwarizmi - Algebra",
    "al_tusi_shakl_qatta": "al-Tusi - Shakl al-Qatta",
    "omar_khayyam_algebra": "Omar Khayyam - Treatise on Algebra",
    "ruska_arab_algebra": "Ruska - Oldest Arabic Algebra",
    "ruska_arab_algebra_1917": "Ruska - Oldest Arabic Algebra (1917)",
    "rosen_algebra_ben_musa_1831": "Rosen - Algebra of Mohammed Ben Musa",
    "robert_chester_karpinski_1915": "Robert of Chester and Karpinski",
    "robert_chester_karpinski_al_khwarizmi_1915": "Robert of Chester and Karpinski",
    "said_al_andalusi_tabaqat": "Said al-Andalusi - Tabaqat al-Umam",
    "al_muqaddasi_taqasim": "al-Muqaddasi - Ahsan al-Taqasim",
    "ibn_al_nadim_fihrist": "Ibn al-Nadim - Kitab al-Fihrist",
    "ibn_al_qifti_hukama": "Ibn al-Qifti - Tarikh al-Hukama",
    "smith_karpinski_numerals_1911": "Smith-Karpinski - Numerals",
}

PUBLIC_WORK_NAMES = {
    "cyhj_detail": "li_ye_ceyuan_detail",
    "jiuzhang-suanshu-vols1-3": "anon_jiuzhang_v1_3",
    "jiuzhang-suanshu-vols4-6": "anon_jiuzhang_v4_6",
    "jiuzhang-suanshu-vols7-9": "anon_jiuzhang_v7_9",
    "li-ye-ceyuan-haijing-vols1-3": "li_ye_ceyuan_v1_3",
    "li-ye-ceyuan-haijing-vols4-6": "li_ye_ceyuan_v4_6",
    "li-ye-ceyuan-haijing-vols7-9": "li_ye_ceyuan_v7_9",
    "li-ye-ceyuan-haijing-vols10-12": "li_ye_ceyuan_v10_12",
    "li-ye-ceyuan-haijing-fenlei-shishu-vols1-3": "li_ye_ceyuan_fenlei_v1_3",
    "li-ye-ceyuan-haijing-fenlei-shishu-vols4-5": "li_ye_ceyuan_fenlei_v4_5",
    "li-ye-ceyuan-haijing-fenlei-shishu-vols6-10": "li_ye_ceyuan_fenlei_v6_10",
    "qin-jiushao-shuxue-jiuzhang-fascicle1": "qin_shuxue_jz_f1",
    "qin-jiushao-shuxue-jiuzhang-fascicle2": "qin_shuxue_jz_f2",
    "qin-jiushao-shuxue-jiuzhang-fascicles3-4": "qin_shuxue_jz_f3_4",
    "qin-jiushao-shuxue-jiuzhang-fascicles5-6": "qin_shuxue_jz_f5_6",
    "qin-jiushao-shuxue-jiuzhang-fascicles7-9": "qin_shuxue_jz_f7_9",
    "sunzi-suanjing": "sunzi_suanjing",
    "yang-hui-xiangjie-jiuzhang-part1": "yang_hui_xiangjie_jz_p1",
    "yang-hui-xiangjie-jiuzhang-part2": "yang_hui_xiangjie_jz_p2",
    "yang-hui-xiangjie-jiuzhang-part3": "yang_hui_xiangjie_jz_p3",
    "zhu-shijie-suanxue-qimeng-part1": "zhu_shijie_qimeng_p1",
    "zhu-shijie-suanxue-qimeng-part2": "zhu_shijie_qimeng_p2",
    "aryabhata-aryabhatiya": "aryabhata__aryabhatiya",
    "bhaskara-ii-bijaganita-part1": "bhaskara_bijaganita_p1",
    "bhaskara-ii-bijaganita-part2": "bhaskara_bijaganita_p2",
    "bhaskara-ii-bijaganita-part3": "bhaskara_bijaganita_p3",
    "bhaskara-ii-lilavati": "bhaskara_lilavati",
    "brahmagupta-brahmasphutasiddhanta-pt1-chunk1": "brahmagupta_bss_p1c1",
    "brahmagupta-brahmasphutasiddhanta-pt1-chunk2": "brahmagupta_bss_p1c2",
    "brahmagupta-brahmasphutasiddhanta-pt1-chunk3": "brahmagupta_bss_p1c3",
    "brahmagupta-brahmasphutasiddhanta-pt1-chunk4": "brahmagupta_bss_p1c4",
    "brahmagupta-brahmasphutasiddhanta-pt1-chunk5": "brahmagupta_bss_p1c5",
    "brahmagupta-brahmasphutasiddhanta-pt1-chunk6": "brahmagupta_bss_p1c6",
    "brahmagupta-brahmasphutasiddhanta-pt2-chunk1": "brahmagupta_bss_p2c1",
    "brahmagupta-brahmasphutasiddhanta-pt2-chunk2": "brahmagupta_bss_p2c2",
    "brahmagupta-brahmasphutasiddhanta-pt2-chunk3": "brahmagupta_bss_p2c3",
    "brahmagupta-brahmasphutasiddhanta-pt2-chunk4": "brahmagupta_bss_p2c4",
    "brahmagupta-brahmasphutasiddhanta-pt2-chunk5": "brahmagupta_bss_p2c5",
    "brahmagupta-brahmasphutasiddhanta-pt2-chunk6": "brahmagupta_bss_p2c6",
    "brahmagupta-brahmasphutasiddhanta-pt3-chunk1": "brahmagupta_bss_p3c1",
    "brahmagupta-brahmasphutasiddhanta-pt3-chunk2": "brahmagupta_bss_p3c2",
    "brahmagupta-brahmasphutasiddhanta-pt3-chunk3": "brahmagupta_bss_p3c3",
    "al-kashi-miftah-al-hisab": "al_kashi_miftah",
    "al-khwarizmi-al-jabr": "al_khwarizmi_al_jabr",
    "al-khwarizmi-al-jabr-wa-l-muqabala": "al_khwarizmi_al_jabr",
    "al-tusi-shakl-al-qatta": "al_tusi_shakl_qatta",
    "karpinski-robert-of-chester-latin-translation-1915": "robert_chester_karpinski_al_khwarizmi_1915",
    "omar-khayyam-sinaat-al-jabr": "omar_khayyam_algebra",
    "rosen-algebra-of-mohammed-ben-musa-1831": "rosen_algebra_ben_musa_1831",
    "ruska-zur-aeltesten-arabischen-algebra": "ruska_arab_algebra",
    "ruska-zur-aeltesten-arabischen-algebra-1917": "ruska_arab_algebra_1917",
    "said-al-andalusi-tabaqat-al-umam": "said_al_andalusi_tabaqat",
    "al-muqaddasi-ahsan-al-taqasim": "al_muqaddasi_taqasim",
    "ibn-al-nadim-kitab-al-fihrist": "ibn_al_nadim_fihrist",
    "ibn-al-qifti-tarikh-al-hukama": "ibn_al_qifti_hukama",
    "smith-karpinski-hindu-arabic-numerals-1911": "smith_karpinski_numerals_1911",
}


def reset_dir(path: Path) -> None:
    if path.exists():
        resolved = path.resolve()
        allowed = (PROJECT_ROOT / "release_candidates").resolve()
        if not str(resolved).lower().startswith(str(allowed).lower()):
            raise RuntimeError(f"Refusing to remove unexpected path: {resolved}")
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def slugify(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9]+", "_", text)
    return re.sub(r"_+", "_", text).strip("_")


def ascii_clean(text: str) -> str:
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = text.replace("/", " and ")
    text = text.replace("wa'l", "wa-l").replace("Wa'l", "Wa-l")
    text = text.replace("'", "")
    text = text.replace(":", " - ")
    text = text.replace('"', "")
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def display_title(title: str) -> str:
    title = ascii_clean(title)
    replacements = [
        ("current English bilingual ", ""),
        ("current English bilingual ", ""),
        ("English bilingual ", ""),
        ("classical-modern Chinese ", ""),
        ("modern LaTeX ", ""),
        ("current complete draft", "complete current draft"),
        ("current ", ""),
        (" draft", ""),
    ]
    for old, new in replacements:
        title = title.replace(old, new)
    title = re.sub(r"\s+", " ", title)
    return title.strip(" ,")


def safe_public_filename(prefix: str, descriptor: str, title: str, suffix: str = ".pdf") -> str:
    readable = display_title(title)
    # Keep Windows paths and Zenodo lists civil while preserving enough title to scan.
    max_title = 64
    if len(readable) > max_title:
        readable = readable[: max_title - 3].rstrip(" ,;-") + "..."
    name = f"{prefix} {descriptor} - {readable}{suffix}"
    name = re.sub(r"[<>:\"/\\|?*]", "-", name)
    name = re.sub(r"\s+", " ", name)
    name = re.sub(r"-+", "-", name)
    return name.strip()


def compact_work_title(work: dict[str, Any]) -> str:
    return SHORT_PUBLIC_TITLES.get(str(work["slug"]), display_title(str(work["title"])))


def work_public_filename(work: dict[str, Any], ordinal: int) -> str:
    code, descriptor = WORK_FILENAME_RULES[work["language_group"]]
    descriptor = str(work.get("filename_descriptor", descriptor))
    return safe_public_filename(f"{code}-{ordinal:02d}", descriptor, compact_work_title(work))


def latex_escape(text: str) -> str:
    text = ascii_clean(text)
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in text)


def write_latex_pdf(dest: Path, title: str, subtitle: str, sections: list[tuple[str, list[str]]]) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp_root = Path(r"C:\tmp") / f"non_eu_front_{slugify(dest.stem)[:64]}"
    if tmp_root.exists():
        shutil.rmtree(tmp_root)
    tmp_root.mkdir(parents=True, exist_ok=True)
    try:
        body: list[str] = [
            r"\documentclass[11pt]{article}",
            r"\setlength{\paperwidth}{8.5in}",
            r"\setlength{\paperheight}{11in}",
            r"\setlength{\textwidth}{6.5in}",
            r"\setlength{\textheight}{9in}",
            r"\setlength{\oddsidemargin}{0in}",
            r"\setlength{\evensidemargin}{0in}",
            r"\setlength{\topmargin}{-0.35in}",
            r"\setlength{\parindent}{0pt}",
            r"\setlength{\parskip}{6pt}",
            r"\begin{document}",
            r"\begin{center}",
            r"{\Large\bfseries " + latex_escape(title) + r"\par}",
        ]
        if subtitle:
            body.append(r"\vspace{0.35em}{\normalsize " + latex_escape(subtitle) + r"\par}")
        body.extend(
            [
                r"\vspace{0.75em}",
                r"{\small Modern LaTeX Editions of Public-Domain Mathematics Manuscripts}",
                r"\end{center}",
                r"\hrule",
                r"\vspace{0.75em}",
                r"\normalsize",
            ]
        )
        for heading, lines in sections:
            body.append(r"\subsection*{" + latex_escape(heading) + "}")
            if not lines:
                continue
            body.append(r"\begin{itemize}")
            for line in lines:
                body.append(r"\item " + latex_escape(line))
            body.append(r"\end{itemize}")
        body.extend([r"\end{document}", ""])
        tex = tmp_root / "frontmatter.tex"
        tex.write_text("\n".join(body), encoding="utf-8")
        proc = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", tex.name],
            cwd=tmp_root,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=180,
            check=False,
        )
        pdf = tmp_root / "frontmatter.pdf"
        if proc.returncode != 0 or not pdf.exists():
            raise RuntimeError(f"Failed to build front matter PDF {dest}: {proc.stdout[-2000:]}\n{proc.stderr[-2000:]}")
        shutil.copy2(pdf, dest)
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)


def public_slug_from_relative(path: Path) -> str:
    stem = path.stem
    stem = stem.replace("_classical-modern_bilingual", "")
    stem = stem.replace("_bilingual", "")
    stem = stem.replace("_arabic", "")
    return PUBLIC_WORK_NAMES.get(stem, slugify(stem))


def rel_source(path: Path) -> str:
    for root in FALLBACK_SOURCE_ROOTS:
        try:
            return path.relative_to(root).as_posix()
        except ValueError:
            continue
    return path.name


def find_source_path(relative_source: str) -> Path | None:
    return next((root / relative_source for root in FALLBACK_SOURCE_ROOTS if (root / relative_source).exists()), None)


def is_excluded_public_pdf(path: Path) -> bool:
    return path.suffix.lower() == ".pdf" and rel_source(path) in PUBLIC_PDF_EXCLUDE_RELATIVE


def held_public_sources(relative_sources: list[str]) -> list[str]:
    held: list[str] = []
    for rel in relative_sources:
        found = find_source_path(rel)
        if found is not None and is_excluded_public_pdf(found):
            held.append(rel)
    return held


def held_public_pdf_components() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for rel in sorted(PUBLIC_PDF_EXCLUDE_RELATIVE):
        found = find_source_path(rel)
        if found is not None:
            rows.append({"source": rel, "reason": PUBLIC_PDF_EXCLUDE_REASON})
    return rows


def is_public_test_file(path: Path) -> bool:
    name = path.name.lower()
    if name in SKIP_PUBLIC_EXACT_NAMES:
        return True
    for part in path.parts:
        stem = Path(part).stem.lower()
        if stem == "test" or stem.startswith(("test_", "test-", "master-index")):
            return True
    return False


def pdfs_under(relative_prefix: str) -> list[Path]:
    seen: dict[str, Path] = {}
    for base in FALLBACK_SOURCE_ROOTS:
        root = base / relative_prefix
        if not root.exists():
            continue
        for p in root.rglob("*.pdf"):
            if is_public_test_file(p) or is_excluded_public_pdf(p):
                continue
            seen.setdefault(rel_source(p), p)
    return sorted(
        seen.values(),
        key=lambda p: rel_source(p).lower(),
    )


def texs_under(relative_prefix: str) -> list[Path]:
    root = SOURCE_ROOT / relative_prefix
    if not root.exists():
        return []
    return sorted((p for p in root.rglob("*.tex") if not is_public_test_file(p)), key=lambda p: rel_source(p).lower())


def run_text(args: list[str], timeout: int = 180) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        check=False,
        timeout=timeout,
    )


def pdf_pages(path: Path) -> int:
    proc = run_text(["pdfinfo", str(path)], timeout=90)
    if proc.returncode != 0:
        return 0
    match = re.search(r"^Pages:\s+(\d+)", proc.stdout, flags=re.M)
    return int(match.group(1)) if match else 0


def pdf_text_chars(path: Path) -> int:
    proc = run_text(["pdftotext", "-enc", "UTF-8", str(path), "-"], timeout=180)
    if proc.returncode != 0:
        return 0
    return len(re.sub(r"\s+", "", proc.stdout))


def combine_pdfs(
    paths: list[Path],
    dest: Path,
    *,
    title: str = "",
    subtitle: str = "",
    front_lines: list[str] | None = None,
) -> dict[str, Any]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not paths:
        return {
            "filename": dest.name,
            "status": "no_sources",
            "source_count": 0,
            "bytes": 0,
            "pages": 0,
            "sha256": "",
        }
    tmp_root = Path(r"C:\tmp") / f"non_eu_multilingual_{slugify(dest.stem)}"
    if tmp_root.exists():
        shutil.rmtree(tmp_root)
    tmp_root.mkdir(parents=True, exist_ok=True)
    try:
        short_sources: list[Path] = []
        if title:
            front_pdf = tmp_root / "0000_front_matter.pdf"
            write_latex_pdf(
                front_pdf,
                title,
                subtitle,
                [("About this reader", front_lines)] if front_lines else [],
            )
            short_sources.append(front_pdf)
        for index, src in enumerate(paths):
            short = tmp_root / f"{index + 1:04d}.pdf"
            shutil.copy2(src, short)
            short_sources.append(short)
        short_dest = tmp_root / "combined.pdf"
        if len(short_sources) == 1:
            shutil.copy2(short_sources[0], short_dest)
        else:
            proc = run_text(["pdfunite", *(str(p) for p in short_sources), str(short_dest)], timeout=900)
            if proc.returncode != 0 or not short_dest.exists():
                return {
                    "filename": dest.name,
                    "status": "pdfunite_failed",
                    "source_count": len(paths),
                    "bytes": 0,
                    "pages": 0,
                    "sha256": "",
                    "stderr_tail": proc.stderr[-1000:],
                }
        shutil.copy2(short_dest, dest)
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)
    return {
        "filename": dest.name,
        "status": "combined",
        "source_count": len(paths),
        "bytes": dest.stat().st_size,
        "pages": pdf_pages(dest),
        "text_chars": pdf_text_chars(dest),
        "sha256": sha256(dest),
        "sources": [rel_source(path) for path in paths],
    }


def copy_pdf(src: Path, dest: Path) -> dict[str, Any]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)
    return {
        "filename": dest.name,
        "source": rel_source(src),
        "bytes": dest.stat().st_size,
        "pages": pdf_pages(dest),
        "text_chars": pdf_text_chars(dest),
        "sha256": sha256(dest),
    }


def clean_visible_public_pdf_labels(paths: list[Path]) -> list[dict[str, Any]]:
    """Replace process-facing note labels in assembled public reader PDFs.

    Source TeX and raw PDFs remain preserved in the artifact ZIPs. This pass
    only normalizes visible public-reader labels such as "Translator's note" to
    "Editorial note" so Zenodo previews do not look like chat-session output.
    """
    rows: list[dict[str, Any]] = []
    for path in sorted({p for p in paths if p.exists() and p.suffix.lower() == ".pdf"}, key=lambda p: p.name.lower()):
        replacements = 0
        with fitz.open(path) as doc:
            for page in doc:
                page_changed = False
                for old, new in VISIBLE_PDF_LABEL_REPLACEMENTS:
                    for rect in page.search_for(old):
                        box = fitz.Rect(rect)
                        box.x0 = max(0, box.x0 - 0.5)
                        box.x1 = min(page.rect.width, box.x1 + 1.0)
                        box.y0 = max(0, box.y0 - 0.5)
                        box.y1 = min(page.rect.height, box.y1 + 1.2)
                        fontsize = max(5.0, min(8.0, box.height * 0.62))
                        page.add_redact_annot(
                            box,
                            text=new,
                            fontname="helv",
                            fontsize=fontsize,
                            fill=(1, 1, 1),
                            text_color=(0, 0, 0),
                            align=fitz.TEXT_ALIGN_LEFT,
                        )
                        replacements += 1
                        page_changed = True
                if page_changed:
                    page.apply_redactions()
            if replacements:
                tmp = path.with_suffix(path.suffix + ".cleaning.tmp")
                doc.save(tmp, garbage=4, deflate=True)
        if replacements:
            tmp.replace(path)
            rows.append(
                {
                    "filename": path.name,
                    "visible_label_replacements": replacements,
                    "bytes": path.stat().st_size,
                    "sha256": sha256(path),
                }
            )
    return rows


def refresh_pdf_manifest_rows(rows: list[dict[str, Any]]) -> None:
    for row in rows:
        filename = row.get("filename")
        if not filename:
            continue
        path = UPLOAD / str(filename)
        if path.exists() and path.suffix.lower() == ".pdf":
            row["bytes"] = path.stat().st_size
            row["pages"] = pdf_pages(path)
            row["text_chars"] = pdf_text_chars(path)
            row["sha256"] = sha256(path)


def write_master_index_pdf(
    dest: Path,
    combined_rows: list[dict[str, Any]],
    individual_rows: list[dict[str, Any]],
    artifact_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    translation_rows = [row for row in individual_rows if row["category"] == "translation_work"]
    original_rows = [row for row in individual_rows if row["category"] == "original_work"]
    reference_rows = [row for row in individual_rows if row["category"] == "reference_work"]

    def row_line(row: dict[str, Any]) -> str:
        title = row.get("title") or row.get("label") or row.get("filename")
        pages = row.get("pages") or "?"
        return f"{display_title(str(title))} -- {row['filename']} ({pages} pages)"

    sections: list[tuple[str, list[str]]] = [
        (
            "What this record contains",
            [
                "Combined reader PDFs are listed first for quick browsing.",
                "Work-level PDFs follow, with translations presented as public reading files rather than hidden artifacts.",
                "TeX sources, OCR text, review notes, page images, and the as-received source/provenance archive are grouped into ZIP files.",
            ],
        ),
        ("Combined readers", [row_line(row) for row in combined_rows if row.get("status") == "combined"]),
        (
            "Translation readers",
            [row_line(row) for row in translation_rows],
        ),
        (
            "Original-language modern LaTeX drafts",
            [row_line(row) for row in original_rows],
        ),
        (
            "Historical reference and witness texts",
            [row_line(row) for row in reference_rows],
        ),
        (
            "ZIP artifacts",
            [f"{row['filename']} ({row.get('member_count', 'archive')} files/items)" for row in artifact_rows],
        ),
    ]
    write_latex_pdf(
        dest,
        "Non-European Mathematics Manuscripts",
        "Multilingual translation drafts, original-language LaTeX drafts, and source artifacts",
        sections,
    )
    return {
        "category": "index",
        "language_group": "master_index",
        "filename": dest.name,
        "bytes": dest.stat().st_size,
        "pages": pdf_pages(dest),
        "text_chars": pdf_text_chars(dest),
        "sha256": sha256(dest),
    }


def source_paths(relative_sources: list[str]) -> list[Path]:
    paths: list[Path] = []
    missing: list[str] = []
    for rel in relative_sources:
        found = find_source_path(rel)
        if found is None:
            missing.append(rel)
        elif is_excluded_public_pdf(found):
            continue
        else:
            paths.append(found)
    if missing:
        raise FileNotFoundError("Missing work source PDFs: " + "; ".join(missing))
    return paths


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    keys: list[str] = []
    for row in rows:
        for key in row:
            if key not in keys:
                keys.append(key)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=keys or ["empty"])
        writer.writeheader()
        writer.writerows(rows)


def safe_artifact_rel(path: Path) -> Path:
    rel = path.relative_to(SOURCE_ROOT)
    parts = rel.parts
    if parts[0] == "translations":
        if len(parts) > 1 and parts[1] == "en":
            return Path("translations") / "english_bilingual" / Path(*parts[2:])
        if len(parts) > 1 and parts[1] == "zh":
            return Path("translations") / "classical_modern_chinese" / Path(*parts[2:])
        if len(parts) > 1 and parts[1] == "ar":
            return Path("translations") / "arabic" / Path(*parts[2:])
    return Path(*parts)


def should_skip_public_artifact(path: Path) -> bool:
    rel = path.relative_to(SOURCE_ROOT)
    if rel.suffix.lower() in SKIP_SOURCE_ZIP_SUFFIXES:
        return True
    if is_public_test_file(path):
        return True
    return bool(rel.parts and rel.parts[0] in SKIP_TOP_DIRS)


def write_zip_from_files(dest: Path, files: list[Path], *, stored: bool = False) -> dict[str, Any]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        dest.unlink()
    compression = zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(dest, "w", compression=compression, allowZip64=True) as zf:
        for src in sorted(files, key=lambda p: rel_source(p).lower()):
            if should_skip_public_artifact(src):
                continue
            arcname = safe_artifact_rel(src).as_posix()
            zf.write(src, arcname)
            rows.append({"archive_path": arcname, "source": rel_source(src), "bytes": src.stat().st_size})
    with zipfile.ZipFile(dest) as zf:
        bad = zf.testzip()
    if bad:
        raise RuntimeError(f"Bad ZIP member in {dest}: {bad}")
    return {
        "filename": dest.name,
        "bytes": dest.stat().st_size,
        "sha256": sha256(dest),
        "member_count": len(rows),
        "members": rows,
    }


def write_zip_from_tree(dest: Path, root: Path) -> dict[str, Any]:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        dest.unlink()
    rows: list[dict[str, Any]] = []
    with zipfile.ZipFile(dest, "w", compression=zipfile.ZIP_DEFLATED, allowZip64=True) as zf:
        for src in sorted(root.rglob("*"), key=lambda p: str(p).lower()):
            if src.is_file():
                arcname = src.relative_to(root).as_posix()
                zf.write(src, arcname)
                rows.append({"archive_path": arcname, "bytes": src.stat().st_size})
    with zipfile.ZipFile(dest) as zf:
        bad = zf.testzip()
    if bad:
        raise RuntimeError(f"Bad ZIP member in {dest}: {bad}")
    return {
        "filename": dest.name,
        "bytes": dest.stat().st_size,
        "sha256": sha256(dest),
        "member_count": len(rows),
        "members": rows,
    }


def write_combined_tex_file(dest: Path, title: str, sources: list[Path]) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "% Combined TeX source bundle",
        f"% Title: {title}",
        "% Note: constituent files are preserved below in sources/. Some are standalone",
        "% documents with their own preambles; this combined file is for inspection,",
        "% comparison, and reuse rather than guaranteed one-command compilation.",
        "",
    ]
    for src in sorted(sources, key=lambda p: rel_source(p).lower()):
        source_rel = rel_source(src)
        lines.extend(
            [
                "",
                "% ============================================================",
                f"% Source: {source_rel}",
                "% ============================================================",
                "",
            ]
        )
        lines.append(public_source_text(src))
        lines.append("")
    dest.write_text("\n".join(lines), encoding="utf-8")


def public_source_text(src: Path) -> str:
    text = src.read_text(encoding="utf-8", errors="replace")
    replacements = {
        "%% Translator note": "%% Editorial note",
        "%% Translator Note": "%% Editorial note",
        "%% Translator's note": "%% Editorial note",
        "%% TRANSLATOR'S PREFACE": "%% EDITORIAL PREFACE",
        "[Translator's Note:": "[Editorial Note:",
        "[Translator Note:": "[Editorial Note:",
        "[Translators note:": "[Editorial note:",
        "Translator's Note": "Editorial Note",
        "Translator's note": "Editorial note",
        "Translators note": "Editorial note",
        "Translator note": "Editorial note",
        "Translator Note": "Editorial note",
        "Translator's Preface": "Editorial Preface",
        "Translator's Notes": "Editorial Notes",
        "Editor's and Translator's Notes": "Editorial Notes",
        "handoff": "reuse",
        "Handoff": "Reuse",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text


def build_tex_artifact(tex_files: list[Path]) -> dict[str, Any]:
    root = WORK / "combined_and_source_tex_artifact"
    if root.exists():
        shutil.rmtree(root)
    root.mkdir(parents=True, exist_ok=True)

    source_root = root / "sources"
    for src in sorted(tex_files, key=lambda p: rel_source(p).lower()):
        safe_dest = source_root / safe_artifact_rel(src)
        safe_dest.parent.mkdir(parents=True, exist_ok=True)
        safe_dest.write_text(public_source_text(src), encoding="utf-8")

    combined_root = root / "combined_tex_bundles"
    for group in TRANSLATION_GROUPS:
        sources = texs_under(group["prefix"])
        if sources:
            write_combined_tex_file(
                combined_root / f"translation__{group['key']}__combined_sources.tex",
                group["label"],
                sources,
            )
    for group in ORIGINAL_GROUPS:
        sources = texs_under(group["prefix"])
        if sources:
            write_combined_tex_file(
                combined_root / f"originals__{group['key']}__combined_sources.tex",
                group["label"],
                sources,
            )

    work_root = combined_root / "work_level"
    for work in [*TRANSLATION_WORKS, *ORIGINAL_WORKS]:
        tex_sources: list[Path] = []
        for pdf_rel in work["sources"]:
            tex_path = (SOURCE_ROOT / pdf_rel).with_suffix(".tex")
            if tex_path.exists():
                tex_sources.append(tex_path)
        if tex_sources:
            write_combined_tex_file(
                work_root / f"{work['prefix']}__{work['slug']}__combined_sources.tex",
                work["title"],
                tex_sources,
            )

    (root / "README.md").write_text(
        "\n".join(
            [
                "# Non-European multilingual TeX sources",
                "",
                "This ZIP contains combined TeX source bundles by language/corpus and the",
                "individual TeX/support files used to produce the current public PDFs.",
                "",
                "The combined files are inspection and review bundles. Many constituent",
                "sources are standalone LaTeX documents with their own preambles, so the",
                "combined source bundle is not asserted to compile as one document.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    return write_zip_from_tree(
        UPLOAD / ARTIFACT_PUBLIC_FILENAMES["tex"],
        root,
    )


def build_artifacts() -> list[dict[str, Any]]:
    files = [p for p in SOURCE_ROOT.rglob("*") if p.is_file() and not should_skip_public_artifact(p)]

    tex_files = [
        p
        for p in files
        if p.suffix.lower() in TEXTUAL_SOURCE_SUFFIXES
        and not (p.name.lower() == "xelatex" or p.suffix.lower() == "")
    ]
    ocr_review_files = [
        p
        for p in files
        if p.suffix.lower() in OCR_REVIEW_SUFFIXES
    ]
    image_files = [
        p
        for p in files
        if p.suffix.lower() in IMAGE_SUFFIXES
    ]
    pdf_files = [
        p
        for p in files
        if p.suffix.lower() == ".pdf"
    ]

    artifact_rows: list[dict[str, Any]] = []
    artifact_rows.append(build_tex_artifact(tex_files))
    artifact_rows.append(
        write_zip_from_files(
            UPLOAD / ARTIFACT_PUBLIC_FILENAMES["source_pdfs"],
            pdf_files,
        )
    )
    artifact_rows.append(
        write_zip_from_files(
            UPLOAD / ARTIFACT_PUBLIC_FILENAMES["ocr_notes"],
            ocr_review_files,
        )
    )
    if image_files:
        artifact_rows.append(
            write_zip_from_files(
                UPLOAD / ARTIFACT_PUBLIC_FILENAMES["page_images"],
                image_files,
                stored=True,
            )
        )
    raw_zips = [path for path in RAW_OUTPUT_ZIPS if path.exists()]
    if raw_zips:
        raw_dest = UPLOAD / ARTIFACT_PUBLIC_FILENAMES["raw"]
        if raw_dest.exists():
            raw_dest.unlink()
        with zipfile.ZipFile(raw_dest, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as zf:
            for index, source_zip in enumerate(raw_zips, start=1):
                zf.write(source_zip, f"raw_source_archive_{index:02d}.zip")
            zf.writestr(
                "README.md",
                "As-received provenance archives for the current non-European mathematics release. "
                "The public reader PDFs are separately organized and audited; these ZIPs preserve the source drops.\n",
            )
        with zipfile.ZipFile(raw_dest) as zf:
            bad = zf.testzip()
        if bad:
            raise RuntimeError(f"Bad ZIP member in {raw_dest}: {bad}")
        artifact_rows.append(
            {
                "filename": raw_dest.name,
                "bytes": raw_dest.stat().st_size,
                "sha256": sha256(raw_dest),
                "member_count": len(raw_zips) + 1,
                "manifest": "preserved as-received source/provenance archives",
            }
        )

    for row in artifact_rows:
        if "members" not in row:
            continue
        slim = {k: v for k, v in row.items() if k != "members"}
        rows_path = REPORTS / f"{Path(row['filename']).stem}_manifest.csv"
        write_csv(rows_path, row["members"])
        row.clear()
        row.update(slim)
        row["manifest"] = str(rows_path.relative_to(OUT_ROOT).as_posix())
    return artifact_rows


def write_metadata(
    combined_rows: list[dict[str, Any]],
    individual_rows: list[dict[str, Any]],
    artifact_rows: list[dict[str, Any]],
) -> None:
    master_index = UPLOAD / MASTER_INDEX_FILENAME
    translation_individual = [row for row in individual_rows if row["category"] == "translation_work"]
    original_individual = [row for row in individual_rows if row["category"] == "original_work"]
    reference_individual = [row for row in individual_rows if row["category"] == "reference_work"]

    by_language: dict[str, dict[str, int]] = {}
    for row in translation_individual:
        by_language.setdefault(row["language_group"], {"pdfs": 0, "tex": 0})
        by_language[row["language_group"]]["pdfs"] += 1
    for group in TRANSLATION_GROUPS:
        by_language.setdefault(group["key"], {"pdfs": 0, "tex": 0})
        by_language[group["key"]]["tex"] = len(texs_under(group["prefix"]))

    held_components = held_public_pdf_components()
    summary = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "public_record_title": "Non-European Mathematics Manuscripts: Multilingual Translation Drafts and Modern LaTeX Sources",
        "master_index_pdf": master_index.name if master_index.exists() else "",
        "combined_pdf_count": len([row for row in combined_rows if row["status"] == "combined"]),
        "work_level_pdf_count": len(individual_rows),
        "translation_work_pdf_count": len(translation_individual),
        "original_language_work_pdf_count": len(original_individual),
        "reference_work_pdf_count": len(reference_individual),
        "translation_by_language": by_language,
        "artifact_zips": artifact_rows,
        "combined_pdfs": combined_rows,
        "individual_pdfs": individual_rows,
        "held_public_pdf_components": held_components,
    }
    summary_path = UPLOAD / ARTIFACT_PUBLIC_FILENAMES["summary"]
    summary_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    def list_items(rows: list[dict[str, Any]]) -> str:
        items = []
        for row in rows:
            title = html.escape(display_title(str(row["title"])))
            filename = html.escape(str(row["filename"]))
            items.append(f"<li>{title} — <code>{filename}</code></li>")
        return "<ul>" + "".join(items) + "</ul>"

    english_rows = [row for row in translation_individual if row["language_group"] == "english_bilingual"]
    chinese_rows = [row for row in translation_individual if row["language_group"] == "classical_modern_chinese"]
    arabic_rows = [row for row in translation_individual if row["language_group"] == "arabic"]
    original_rows = original_individual
    reference_rows = reference_individual
    contents_html = (
        "<p><strong>Human-readable contents.</strong></p>"
        "<p><em>English translation drafts</em> from the current Chinese, Indian/Sanskrit, Islamic/Arabic, and reference-language source material:</p>"
        f"{list_items(english_rows)}"
        "<p><em>Classical-to-modern Chinese renderings</em> for current Chinese mathematical texts:</p>"
        f"{list_items(chinese_rows)}"
        "<p><em>Arabic translation drafts:</em></p>"
        f"{list_items(arabic_rows)}"
        "<p><em>Original-language modern LaTeX drafts</em>, grouped by work rather than source chunk:</p>"
        f"{list_items(original_rows)}"
        "<p><em>Historical reference and witness texts:</em></p>"
        f"{list_items(reference_rows)}"
    )
    held_html = ""
    if held_components:
        held_html = (
            "<p><strong>Reader-surface quality note.</strong> "
            f"{len(held_components)} source-rendered PDF component(s) are preserved in the ZIP archives but omitted from the top-level reader PDFs in this version because their current renderings contain visible upstream error-page artifacts. "
            "They will be restored to the reader surface after clean rerendering.</p>"
        )

    description = (
        "<p>Current multilingual non-European mathematics release for the Modern LaTeX Editions of Public-Domain Mathematics Manuscripts project. "
        "This record is organized by language and corpus, with combined reader PDFs for quick browsing and individual work PDFs for direct download.</p>"
        "<p><strong>Reader surface:</strong> "
        f"<code>[##########] English bilingual translations: {len([row for row in translation_individual if row.get('language_group') == 'english_bilingual'])} work-level PDFs / {by_language.get('english_bilingual', {}).get('tex', 0)} TeX files</code>; "
        f"<code>[##########] classical-modern Chinese translations: {len([row for row in translation_individual if row.get('language_group') == 'classical_modern_chinese'])} work-level PDFs / {by_language.get('classical_modern_chinese', {}).get('tex', 0)} TeX files</code>; "
        f"<code>[##########] Arabic translations: {len([row for row in translation_individual if row.get('language_group') == 'arabic'])} work-level PDFs / {by_language.get('arabic', {}).get('tex', 0)} TeX files</code>; "
        f"<code>[##########] original-language modern LaTeX drafts: {len(original_individual)} work-level PDFs</code>; "
        f"<code>[##########] reference/witness drafts: {len(reference_individual)} work-level PDFs</code>.</p>"
        "<p>The top-level PDFs use human-readable filenames and begin with an ordering number: the index and combined readers first, followed by work-level translation readers, original-language readers, and historical reference readers. "
        "Each public PDF begins with a short front-matter page identifying what it is, its status, and how to use it. "
        "The source TeX, OCR/review notes, working page images, and as-received source/provenance archive are bundled in language-organized ZIP artifacts with readable titles.</p>"
        f"{held_html}"
        f"{contents_html}"
        "<p><strong>Workflow.</strong> Source scans and witnesses are collected, converted into TeX drafts, checked into readable PDFs, and published with source artifacts for inspection and correction. "
        "Readers are welcome to suggest better scans or missing texts. This release is draft work for checking and continuation, not a proofed critical edition.</p>"
    )
    metadata = {
        "title": "Non-European Mathematics Manuscripts: Multilingual Translation Drafts and Modern LaTeX Sources",
        "upload_type": "dataset",
        "publication_date": date.today().isoformat(),
        "version": f"{date.today().isoformat()} multilingual non-European current release",
        "description": description,
        "creators": [{"name": "Manuscript Typesetting Project", "affiliation": "Independent"}],
        "access_right": "open",
        "license": "cc0-1.0",
        "keywords": [
            "non-European mathematics",
            "Chinese mathematics",
            "Indian mathematics",
            "Islamic mathematics",
            "Arabic mathematics",
            "translation",
            "LaTeX",
            "history of mathematics",
            "history of science",
            "public domain",
            "CC0",
            "OCR",
        ],
        "related_identifiers": [
            {"identifier": MAIN_CONCEPT_DOI, "relation": "isPartOf", "scheme": "doi"},
            {"identifier": MAIN_RECORD_URL, "relation": "isReferencedBy", "scheme": "url"},
        ],
        "notes": "Language-organized current release with human-readable filenames, front-matter pages, combined translation readers, work-level PDFs, combined/source TeX archives, OCR/review notes, page-image artifacts, and the as-received source/provenance archive.",
    }
    metadata_path = ZENODO / "metadata_satellite_non_european_multilingual_current.json"
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_upload_manifest() -> list[dict[str, Any]]:
    rows = []
    for path in sorted(UPLOAD.iterdir(), key=lambda p: p.name.lower()):
        if path.is_file():
            rows.append({"filename": path.name, "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_csv(REPORTS / "upload_manifest.csv", rows)
    (REPORTS / "upload_files.txt").write_text(
        "\n".join(str(UPLOAD / row["filename"]) for row in rows) + "\n",
        encoding="utf-8",
    )
    return rows


def main() -> None:
    if not SOURCE_ROOT.exists():
        raise FileNotFoundError(SOURCE_ROOT)
    reset_dir(OUT_ROOT)
    WORK.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)
    UPLOAD.mkdir(parents=True, exist_ok=True)

    combined_rows: list[dict[str, Any]] = []
    individual_rows: list[dict[str, Any]] = []

    for group in TRANSLATION_GROUPS:
        pdfs = pdfs_under(group["prefix"])
        public = COMBINED_PUBLIC_FILES[group["key"]]
        row = combine_pdfs(
            pdfs,
            UPLOAD / public["filename"],
            title=public["title"],
            subtitle=public["subtitle"],
            front_lines=[
                f"Reader type: {group['label']}.",
                "This combined PDF is meant for quick browsing across the current translation set.",
            ],
        )
        row.update({"category": "translation_combined", "language_group": group["key"], "label": group["label"]})
        combined_rows.append(row)

    for group in ORIGINAL_GROUPS:
        pdfs = pdfs_under(group["prefix"])
        public = COMBINED_PUBLIC_FILES[group["key"]]
        row = combine_pdfs(
            pdfs,
            UPLOAD / public["filename"],
            title=public["title"],
            subtitle=public["subtitle"],
            front_lines=[
                f"Reader type: {group['label']}.",
                "This combined PDF is meant for quick browsing across the current original-language or reference set.",
            ],
        )
        row.update({"category": "original_combined", "language_group": group["key"], "label": group["label"]})
        combined_rows.append(row)

    counters: dict[str, int] = {}
    for work in TRANSLATION_WORKS:
        paths = source_paths(work["sources"])
        held = held_public_sources(work["sources"])
        if not paths:
            continue
        counters[work["language_group"]] = counters.get(work["language_group"], 0) + 1
        dest = UPLOAD / work_public_filename(work, counters[work["language_group"]])
        descriptor = WORK_FILENAME_RULES[work["language_group"]][1]
        title = display_title(str(work["title"]))
        if held:
            title = f"{title} (clean public components)"
        front_lines = [
            f"Reader type: {descriptor}.",
            "The visible PDF is the front-facing translation reader; source TeX and support material are in the ZIP artifacts.",
        ]
        if held:
            front_lines.append(
                f"{len(held)} source-rendered component(s) for this work are preserved in the ZIP archives but omitted from this reader until a clean rerender is available."
            )
        row = combine_pdfs(
            paths,
            dest,
            title=title,
            subtitle=descriptor,
            front_lines=front_lines,
        )
        row.update(
            {
                "category": "translation_work",
                "language_group": work["language_group"],
                "title": title,
                "held_source_count": len(held),
                "held_sources": held,
            }
        )
        individual_rows.append(row)

    counters = {}
    for work in ORIGINAL_WORKS:
        paths = source_paths(work["sources"])
        held = held_public_sources(work["sources"])
        if not paths:
            continue
        counters[work["language_group"]] = counters.get(work["language_group"], 0) + 1
        dest = UPLOAD / work_public_filename(work, counters[work["language_group"]])
        descriptor = WORK_FILENAME_RULES[work["language_group"]][1]
        title = display_title(str(work["title"]))
        if held:
            title = f"{title} (clean public components)"
        front_lines = [
            f"Reader type: {descriptor}.",
            "This PDF is the current original-language/reference modern LaTeX reader for checking against translations.",
        ]
        if held:
            front_lines.append(
                f"{len(held)} source-rendered component(s) for this work are preserved in the ZIP archives but omitted from this reader until a clean rerender is available."
            )
        row = combine_pdfs(
            paths,
            dest,
            title=title,
            subtitle=descriptor,
            front_lines=front_lines,
        )
        category = "reference_work" if work["language_group"] == "historical_references" else "original_work"
        row.update(
            {
                "category": category,
                "language_group": work["language_group"],
                "title": title,
                "held_source_count": len(held),
                "held_sources": held,
            }
        )
        individual_rows.append(row)

    for work in REFERENCE_SCAN_WORKS:
        src = Path(work["source"])
        if not src.exists():
            continue
        row = copy_pdf(src, UPLOAD / str(work["filename"]))
        row.update(
            {
                "category": "reference_work",
                "language_group": work["language_group"],
                "title": display_title(str(work["title"])),
                "note": work["note"],
                "held_source_count": 0,
                "held_sources": [],
            }
        )
        individual_rows.append(row)

    label_cleanup_rows = clean_visible_public_pdf_labels(
        [UPLOAD / str(row["filename"]) for row in [*combined_rows, *individual_rows] if row.get("filename")]
    )
    if label_cleanup_rows:
        write_csv(REPORTS / "visible_pdf_label_cleanup_manifest.csv", label_cleanup_rows)
        refresh_pdf_manifest_rows(combined_rows)
        refresh_pdf_manifest_rows(individual_rows)

    write_csv(REPORTS / "combined_pdf_manifest.csv", combined_rows)
    write_csv(REPORTS / "individual_pdf_manifest.csv", individual_rows)
    artifact_rows = build_artifacts()
    write_csv(REPORTS / "artifact_manifest.csv", artifact_rows)
    index_row = write_master_index_pdf(UPLOAD / MASTER_INDEX_FILENAME, combined_rows, individual_rows, artifact_rows)
    write_csv(REPORTS / "index_pdf_manifest.csv", [index_row])
    write_metadata(combined_rows, individual_rows, artifact_rows)
    upload_rows = write_upload_manifest()

    print(
        json.dumps(
            {
                "out_root": str(OUT_ROOT),
                "upload": str(UPLOAD),
                "upload_file_count": len(upload_rows),
                "combined_pdf_count": len([row for row in combined_rows if row["status"] == "combined"]),
                "individual_pdf_count": len(individual_rows),
                "artifact_count": len(artifact_rows),
                "metadata_json": str(ZENODO / "metadata_satellite_non_european_multilingual_current.json"),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()


