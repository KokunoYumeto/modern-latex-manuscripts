#!/usr/bin/env python3
"""Publish the public workflow note and replication packet to the main landing record."""

from __future__ import annotations

import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests


ROOT = Path(__file__).resolve().parents[1]
ZENODO = ROOT / "zenodo"
BASE_URL = os.environ.get("ZENODO_BASE_URL", "https://zenodo.org").rstrip("/")
TOKEN_LOCATION = Path(r"LOCAL_USER_HOME\.codex\.sandbox\sandbox.log")
TOKEN_LINE = 12459
MAIN_RECORD_ID = 20458953
WORKFLOW_RECORD_URL = "https://zenodo.org/records/20461174"
WORKFLOW_CONCEPT_DOI = "10.5281/zenodo.20461174"
SOURCE_METADATA = ZENODO / "metadata_main_landing_current_after_author_refresh.json"
PACKET_DIR = ROOT / "release_candidates" / "workflow_replication_packet_20260530"
UPLOAD_FILES = [
    PACKET_DIR / "Project Workflow and Replication Notes.pdf",
    PACKET_DIR / "Workflow Replication Packet - Scripts, Tooling Notes, and Manifests.zip",
]
REQUEST_TIMEOUT = (30, 300)
UPLOAD_TIMEOUT = (30, 900)
TRANSIENT_STATUSES = {429, 500, 502, 503, 504}


def timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def recover_token() -> str:
    token = os.environ.get("ZENODO_ACCESS_TOKEN")
    if token:
        return token
    line = ""
    with TOKEN_LOCATION.open("r", encoding="utf-8", errors="ignore") as handle:
        for i, candidate in enumerate(handle, start=1):
            if i == TOKEN_LINE:
                line = candidate
                break
    regexes = [
        re.compile(r"(?i)ZENODO_ACCESS_TOKEN\s*[:=]\s*['\"]?([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)\"?zenodo[_-]?access[_-]?token\"?\s*[:=]\s*['\"]?([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)https?://(?:sandbox\.)?zenodo\.org/api/[^\s'\"<>]*access_token=([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)zenodo[^\r\n]{0,180}access[_-]?token[^\r\n]{0,40}['\":=\s]+([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)zenodo[^\r\n]{0,180}bearer\s+([A-Za-z0-9._~\-]{20,})"),
    ]
    for regex in regexes:
        match = regex.search(line)
        if match:
            return match.group(1)
    raise RuntimeError("Could not recover Zenodo token from the validated local token location.")


class Client:
    def __init__(self, token: str):
        self.token = token

    def headers(self, content_type: str | None = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.token}"}
        if content_type:
            headers["Content-Type"] = content_type
        return headers

    def request(self, method: str, path_or_url: str, *, payload=None, expected=(200, 201, 202, 204)):
        url = path_or_url if path_or_url.startswith("http") else f"{BASE_URL}{path_or_url}"
        response = None
        last_error: Exception | None = None
        for attempt in range(1, 6):
            try:
                response = requests.request(
                    method,
                    url,
                    headers=self.headers("application/json") if payload is not None else self.headers(),
                    json=payload,
                    timeout=REQUEST_TIMEOUT,
                )
                if response.status_code not in TRANSIENT_STATUSES:
                    break
                last_error = RuntimeError(f"HTTP {response.status_code}: {response.text[:1000]}")
            except (requests.Timeout, requests.ConnectionError) as exc:
                response = None
                last_error = exc
            if attempt < 5:
                time.sleep(min(90, 8 * attempt))
        if response is None:
            raise RuntimeError(f"Request failed on {method} {url}: {last_error}")
        if response.status_code not in expected:
            raise RuntimeError(f"HTTP {response.status_code} on {method} {url}\n{response.text[:4000]}")
        if response.text:
            return response.json()
        return None

    def put_file(self, bucket: str, path: Path):
        url = f"{bucket.rstrip('/')}/{quote(path.name)}"
        response = None
        for attempt in range(1, 6):
            with path.open("rb") as handle:
                try:
                    response = requests.put(
                        url,
                        headers=self.headers("application/octet-stream"),
                        data=handle,
                        timeout=UPLOAD_TIMEOUT,
                    )
                except (requests.Timeout, requests.ConnectionError) as exc:
                    if attempt == 5:
                        raise RuntimeError(f"Network error while uploading {path.name}: {exc}") from exc
                    time.sleep(10 * attempt)
                    continue
            if response.status_code not in TRANSIENT_STATUSES or attempt == 5:
                break
            time.sleep(10 * attempt)
        if response.status_code >= 400:
            raise RuntimeError(f"HTTP {response.status_code} while uploading {path.name}\n{response.text[:4000]}")
        return response.json()


def write_log(name: str, data) -> Path:
    ZENODO.mkdir(parents=True, exist_ok=True)
    path = ZENODO / f"main_landing_workflow_packet_{name}_{timestamp()}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def replace_li(description: str, heading: str, replacement: str) -> str:
    pattern = re.compile(rf"<li><strong>{re.escape(heading)}</strong>.*?</li>", flags=re.DOTALL)
    updated, count = pattern.subn(replacement, description, count=1)
    if count != 1:
        raise RuntimeError(f"Could not replace landing item {heading!r}")
    return updated


def upsert_paragraph(description: str, marker: str, paragraph: str) -> str:
    pattern = re.compile(rf"<p><strong>{re.escape(marker)}</strong>.*?</p>", flags=re.DOTALL)
    updated, count = pattern.subn(paragraph, description, count=1)
    if count:
        return updated
    insertion = "<p><strong>Current project map.</strong></p>"
    if insertion in description:
        return description.replace(insertion, paragraph + "\n" + insertion, 1)
    return description + "\n" + paragraph


def build_metadata() -> dict:
    metadata = json.loads(SOURCE_METADATA.read_text(encoding="utf-8"))
    metadata.pop("doi", None)
    metadata.pop("prereserve_doi", None)
    metadata["publication_date"] = datetime.now(timezone.utc).date().isoformat()
    metadata["version"] = (
        "2026-05-31 workflow replication packet and current links: EGA 20454552, "
        "SGA 20475076, non-European 20473794, Weber 20476405, Noether 20476442, "
        "Deligne 20472720, Gauss 20454309, classical/Cayley 20459215, author cluster 20442003, "
        "and workflow concept 20461174 (latest workflow version 20476520)"
    )
    description = metadata["description"]
    workflow_paragraph = (
        "<p><strong>Workflow and replication packet.</strong> The direct file "
        "<em>Project Workflow and Replication Notes.pdf</em> summarizes the practical pipeline used here: "
        "ChatGPT web project sessions help identify and repair works; Codex handles local indexing, scripting, "
        "auditing, Zenodo publication, and GitHub mirroring; Kimi K2.6 agent swarms have supplied large first-pass "
        "TeX transcriptions; ChatGPT Pro sessions perform review, repair, and translation; and Claude Code has "
        "been used as a local LaTeX-repair and translation worker. The current standalone workflow record "
        f"(<a href=\"{WORKFLOW_RECORD_URL}\">{WORKFLOW_CONCEPT_DOI}</a>) and the accompanying "
        "<em>Workflow Replication Packet - Scripts, Tooling Notes, and Manifests.zip</em> contains sanitized "
        "example scripts, tool lists, metadata templates, OCR notes, and operational notes for people who want "
        "to reproduce or adapt the workflow.</p>"
    )
    description = upsert_paragraph(description, "Workflow and replication packet.", workflow_paragraph)
    description = replace_li(
        description,
        "SGA working English translation:",
        (
            "<li><strong>SGA working English translation:</strong> <code>[#####-----] corpus-wide working translation; "
            "SGA 4 is the largest current compiled reader; SGA 5-7 are active partial assemblies</code> "
            "Current SGA record with coherent cumulative readers and source artifacts. Top-level readers include "
            "SGA 1-2 English snapshots, a cleaned 1,389-page SGA 3 English rebuild, SGA 4 as a 484-page "
            "current working reader, SGA 5 working drafts, SGA 6 as a 231-page current working draft plus a strict "
            "source-checked edition through source page 46, and SGA 7-I current working drafts. A source-checkable SGA 5 high-fidelity edition is included as paired "
            "French-source and English readers complete through printed page 484, including Expose XV, the terminological index, and the notation index. French reference PDFs for SGA 1-7 "
            "remain included for checking. All-version record: "
            "<a href=\"https://zenodo.org/records/20410947\">10.5281/zenodo.20410947</a>.</li>"
        ),
    )
    description = replace_li(
        description,
        "Non-European and multilingual mathematical manuscripts:",
        (
            "<li><strong>Non-European and multilingual mathematical manuscripts:</strong> <code>[#########-] "
            "working multilingual release with targeted layout and reader-surface repairs; broader corpus expansion "
            "continues</code> Consolidated release for Chinese, Indian/Sanskrit, Islamic/Arabic, and historical-reference "
            "mathematical works, organized as direct work-level PDFs, source/provenance/audit ZIP artifacts, and a public "
            "guide/summary. The latest public surface includes targeted reader replacements for <em>Nine Chapters on the Mathematical Art</em>, "
            "Li Ye's <em>Ceyuan Haijing</em>, al-Kashi's <em>Miftah al-Hisab</em>, and a Li Ye classified-method Chinese reader, with weak drafts preserved in ZIP "
            "artifacts until rebuilt. All-version record: "
            "<a href=\"https://zenodo.org/records/20410957\">10.5281/zenodo.20410957</a>.</li>"
        ),
    )
    description = replace_li(
        description,
        "Heinrich Weber:",
        (
            "<li><strong>Heinrich Weber:</strong> <code>[######----] broad draft available; literal repair stream active</code> "
            "author page with original-language modern LaTeX readers for <em>Lehrbuch der Algebra</em> Volumes I and III, "
            "plus English translation drafts. The high-fidelity repair stream now supplies paired German/English readers "
            "for Volume I introduction through section 39, Volume II sections 176 through end matter, and Volume III sections 1-96. TeX sources, source pages, component PDFs, rendered "
            "translation pieces, and provenance are preserved in the artifact ZIP. All-version record: "
            "<a href=\"https://zenodo.org/records/20412153\">10.5281/zenodo.20412153</a>.</li>"
        ),
    )
    description = replace_li(
        description,
        "Emmy Noether:",
        (
            "<li><strong>Emmy Noether:</strong> <code>[#####-----] older cumulative draft retained; paper-level "
            "high-fidelity edition in progress</code> author page with a selected mathematical-papers modern LaTeX "
            "draft, an older English translation/summary working reader, and source-checkable paper-level German/English "
            "pairs. The current cumulative paper-level pair runs through Papers 1-29 complete plus Paper 30 sections 1-5. The next continuation point is Paper 30 section 6. TeX, source scans, and build reports "
            "are preserved in the artifact ZIP. All-version record: "
            "<a href=\"https://zenodo.org/records/20412587\">10.5281/zenodo.20412587</a>.</li>"
        ),
    )
    description = replace_li(
        description,
        "Cayley, Dedekind, and Dirichlet: classical algebra and arithmetic shelf:",
        (
            "<li><strong>Cayley, Dedekind, and Dirichlet: classical algebra and arithmetic shelf:</strong> "
            "<code>[###-------] Cayley front-facing source-checked slice readers; [#########-] broader source "
            "material preserved</code> focused shelf for modern LaTeX working drafts by Cayley, Dedekind, and "
            "Dirichlet. The current record promotes 13 Cayley volume-level source-checked slice readers assembled "
            "from the current source-checked pickup ranges. The artifact ZIP preserves the broader "
            "Cayley source inventory, including rendered slice PDFs, TeX chunks, source trees, and audit material. Dedekind Bands I-III and one Dirichlet selected-works "
            "grouping remain available as working drafts. All-version record: "
            "<a href=\"https://zenodo.org/records/20414787\">10.5281/zenodo.20414787</a>.</li>"
        ),
    )
    description = replace_li(
        description,
        "Deligne papers:",
        (
            "<li><strong>Deligne papers:</strong> <code>[##########] 90/90 original-language reference PDFs preserved; "
            "[######----] English and French working readers continue</code> dedicated Deligne record with cumulative "
            "English and French working readers for the touched paper set, a grouped ZIP of the 90 original-language reference PDFs, and separate "
            "paper-level English translation PDFs for Paper 32 <em>The Weil Conjecture II</em> "
            "and Papers 42, 45, 56, 57, 58, 69, 70, 71, 83, 84, 85, 87, and 88. Individual bilingual "
            "TeX/PDF sidecars, working source layers, render checks, and provenance material are preserved in thematic "
            "artifact ZIPs, including the current complete touched-paper redo package for faithful continuation. All-version record: "
            "<a href=\"https://zenodo.org/records/20410853\">10.5281/zenodo.20410853</a>.</li>"
        ),
    )
    metadata["description"] = description
    metadata["notes"] = (
        "Front page for the modern LaTeX manuscript project. Current highlighted records include EGA 20454552, "
        "SGA 20475076, non-European multilingual manuscripts 20473794, Weber 20476405, Noether 20476442, "
        "Deligne 20472720, Gauss 20454309, Riemann 20434317, Cayley-Dedekind-Dirichlet classical shelf "
        "20459215, additional author cluster 20442003, and the broad cumulative landing/preservation surface "
        "under concept DOI 10.5281/zenodo.20393488. The current workflow replication packet is maintained "
        f"under concept DOI {WORKFLOW_CONCEPT_DOI}."
    )
    text = json.dumps(metadata, ensure_ascii=False)
    if re.search(r"project maintainer|C:\\\\Users|/Users/project maintainer", text, flags=re.IGNORECASE):
        raise RuntimeError("Local personal identifier remains in main metadata.")
    return metadata


def delete_existing_named_files(client: Client, draft_id: int, names: set[str]) -> list[dict]:
    files = client.request("GET", f"/api/deposit/depositions/{draft_id}/files") or []
    deleted = []
    for item in files:
        if item.get("filename") not in names:
            continue
        client.request("DELETE", f"/api/deposit/depositions/{draft_id}/files/{item['id']}", expected=(200, 202, 204))
        deleted.append({"filename": item.get("filename"), "id": item.get("id"), "filesize": item.get("filesize")})
    return deleted


def publish_metadata_only_edit(client: Client, metadata: dict) -> dict:
    """Fallback for records whose legacy bucket cannot be file-replaced by API."""
    try:
        draft = client.request("POST", f"/api/deposit/depositions/{MAIN_RECORD_ID}/actions/edit")
    except RuntimeError as exc:
        if "HTTP 400" not in str(exc) or "edit" not in str(exc).lower():
            raise
        draft = client.request("GET", f"/api/deposit/depositions/{MAIN_RECORD_ID}")
    draft_id = int(draft.get("id", MAIN_RECORD_ID))
    updated = client.request("PUT", f"/api/deposit/depositions/{draft_id}", payload={"metadata": metadata})
    write_log("metadata_edit_fallback", updated)
    try:
        published = client.request("POST", f"/api/deposit/depositions/{draft_id}/actions/publish")
        write_log("publish_edit_fallback", published)
    except RuntimeError as exc:
        if "HTTP 404" not in str(exc):
            raise
        write_log(
            "publish_edit_fallback_404_verify",
            {
                "warning": "Zenodo returned 404 on publish after an edit; verifying the record state instead.",
                "error": str(exc),
            },
        )
    return client.request("GET", f"/api/deposit/depositions/{draft_id}")


def main() -> int:
    for path in UPLOAD_FILES:
        if not path.exists():
            raise FileNotFoundError(path)
    client = Client(recover_token())
    metadata = build_metadata()
    try:
        new_version = client.request("POST", f"/api/deposit/depositions/{MAIN_RECORD_ID}/actions/newversion")
    except RuntimeError as exc:
        if "files.enabled" not in str(exc):
            raise
        live = publish_metadata_only_edit(client, metadata)
        result = {
            "record_id": live.get("id", MAIN_RECORD_ID),
            "doi": live.get("doi"),
            "html": live.get("links", {}).get("record_html") or live.get("links", {}).get("html"),
            "files": len(live.get("files", [])),
            "uploaded": [],
            "warning": "Zenodo refused a new version with files.enabled; metadata-only edit/publish fallback used.",
        }
        result_path = write_log("result", result)
        print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
        print(f"RESULT_LOG {result_path}", flush=True)
        return 0
    write_log("newversion", new_version)
    draft_id = int(new_version["id"])
    print(f"[main-workflow] draft {draft_id} from {MAIN_RECORD_ID}", flush=True)
    updated = client.request("PUT", f"/api/deposit/depositions/{draft_id}", payload={"metadata": metadata})
    write_log("metadata", updated)
    names = {path.name for path in UPLOAD_FILES}
    deleted = delete_existing_named_files(client, draft_id, names)
    bucket = client.request("GET", f"/api/deposit/depositions/{draft_id}")["links"]["bucket"]
    uploaded = []
    for path in UPLOAD_FILES:
        print(f"[main-workflow] upload {path.name} ({path.stat().st_size:,} bytes)", flush=True)
        uploaded.append(client.put_file(bucket, path))
    write_log("upload", {"draft_id": draft_id, "deleted": deleted, "uploaded": uploaded})
    print(f"[main-workflow] publishing draft {draft_id}", flush=True)
    try:
        published = client.request("POST", f"/api/deposit/depositions/{draft_id}/actions/publish")
        write_log("publish", published)
    except RuntimeError as exc:
        if "HTTP 504" not in str(exc) and "HTTP 404" not in str(exc):
            raise
        write_log("publish_transient", {"warning": "Publish endpoint returned a transient-looking error; verifying state.", "error": str(exc)})
    live = client.request("GET", f"/api/deposit/depositions/{draft_id}")
    write_log("live_verify", live)
    result = {
        "record_id": live.get("id", draft_id),
        "doi": live.get("doi"),
        "html": live.get("links", {}).get("record_html") or live.get("links", {}).get("html"),
        "files": len(live.get("files", [])),
        "uploaded": [path.name for path in UPLOAD_FILES],
    }
    result_path = write_log("result", result)
    print(json.dumps(result, indent=2, ensure_ascii=False), flush=True)
    print(f"RESULT_LOG {result_path}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())


