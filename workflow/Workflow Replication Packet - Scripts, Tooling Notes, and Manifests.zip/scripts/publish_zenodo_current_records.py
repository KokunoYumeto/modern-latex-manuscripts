from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import requests


ROOT = Path(__file__).resolve().parents[1]
ZENODO = ROOT / "zenodo"
BASE_URL = os.environ.get("ZENODO_BASE_URL", "https://zenodo.org").rstrip("/")
TOKEN_LOCATION = Path(r"LOCAL_USER_HOME\.codex\.sandbox\sandbox.log")
TOKEN_LINE = 12459
REQUEST_TIMEOUT = (30, 300)
UPLOAD_TIMEOUT = (30, 1800)
TRANSIENT_STATUSES = {429, 500, 502, 503, 504}

TASKS = {
    "noether": {
        "record_id": 20459983,
        "metadata": ZENODO / "metadata_author_noether_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_author_noether_current" / "upload",
    },
    "weber": {
        "record_id": 20460049,
        "metadata": ZENODO / "metadata_author_weber_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_author_weber_current" / "upload",
    },
    "sga": {
        "record_id": 20460126,
        "metadata": ZENODO / "metadata_satellite_sga_working_translation_public_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_satellite_sga_working_translation_public_current" / "upload",
    },
    "non_eu": {
        "record_id": 20460444,
        "metadata": ZENODO / "metadata_satellite_non_european_multilingual_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_satellite_non_european_multilingual_current" / "upload",
    },
    "ega": {
        "record_id": 20454552,
        "metadata": ZENODO / "metadata_satellite_ega_working_translation_public_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_satellite_ega_working_translation_public_current" / "upload",
    },
    "classical": {
        "record_id": 20459215,
        "metadata": ZENODO / "metadata_satellite_classical_algebra_arithmetic_modern_latex_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_satellite_classical_algebra_arithmetic_modern_latex_current" / "upload",
    },
    "author_cluster": {
        "record_id": 20442003,
        "metadata": ZENODO / "metadata_satellite_author_cluster_public_current_clean_surface.json",
        "upload": ROOT / "release_candidates" / "zenodo_satellite_author_cluster_public_current_clean_surface" / "upload",
    },
    "gauss": {
        "record_id": 20454309,
        "metadata": ZENODO / "metadata_author_gauss_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_author_gauss_current" / "upload",
    },
    "deligne": {
        "record_id": 20458935,
        "metadata": ZENODO / "metadata_satellite_deligne_papers_translations.json",
        "upload": ROOT / "release_candidates" / "zenodo_satellite_deligne_papers_translations" / "upload",
    },
    "chinese": {
        "record_id": 20435670,
        "metadata": ZENODO / "metadata_non_european_corpus_chinese_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_non_european_corpus_pages_current" / "chinese" / "upload",
    },
    "indian": {
        "record_id": 20435677,
        "metadata": ZENODO / "metadata_non_european_corpus_indian_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_non_european_corpus_pages_current" / "indian" / "upload",
    },
    "islamic_arabic": {
        "record_id": 20435687,
        "metadata": ZENODO / "metadata_non_european_corpus_islamic_arabic_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_non_european_corpus_pages_current" / "islamic_arabic" / "upload",
    },
    "historical_references": {
        "record_id": 20435690,
        "metadata": ZENODO / "metadata_non_european_corpus_historical_references_current.json",
        "upload": ROOT / "release_candidates" / "zenodo_non_european_corpus_pages_current" / "historical_references" / "upload",
    },
}


def recover_token() -> str:
    token = os.environ.get("ZENODO_ACCESS_TOKEN")
    if token:
        return token
    line = ""
    with TOKEN_LOCATION.open("r", encoding="utf-8", errors="ignore") as handle:
        for i, candidate in enumerate(handle, start=1):
            if i == TOKEN_LINE:
                line = candidate
                break
    regexes = [
        re.compile(r"(?i)ZENODO_ACCESS_TOKEN\s*[:=]\s*['\"]?([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)\"?zenodo[_-]?access[_-]?token\"?\s*[:=]\s*['\"]?([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)https?://(?:sandbox\.)?zenodo\.org/api/[^\s'\"<>]*access_token=([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)zenodo[^\r\n]{0,180}access[_-]?token[^\r\n]{0,40}['\":=\s]+([A-Za-z0-9._~\-]{20,})"),
        re.compile(r"(?i)zenodo[^\r\n]{0,180}bearer\s+([A-Za-z0-9._~\-]{20,})"),
    ]
    for regex in regexes:
        match = regex.search(line)
        if match:
            return match.group(1)
    raise RuntimeError("Could not recover Zenodo token from the validated local token location.")


class ZenodoClient:
    def __init__(self, token: str):
        self.token = token

    def headers(self, content_type: str | None = None) -> dict[str, str]:
        headers = {"Authorization": f"Bearer {self.token}"}
        if content_type:
            headers["Content-Type"] = content_type
        return headers

    def request(self, method: str, path_or_url: str, *, payload=None, expected=(200, 201, 202, 204)):
        url = path_or_url if path_or_url.startswith("http") else f"{BASE_URL}{path_or_url}"
        response = None
        for attempt in range(1, 6):
            try:
                response = requests.request(
                    method,
                    url,
                    headers=self.headers("application/json") if payload is not None else self.headers(),
                    json=payload,
                    timeout=REQUEST_TIMEOUT,
                )
            except (requests.Timeout, requests.ConnectionError) as exc:
                if attempt == 5:
                    raise RuntimeError(f"Network error on {method} {url}: {exc}") from exc
                time.sleep(8 * attempt)
                continue
            if response.status_code not in TRANSIENT_STATUSES or attempt == 5:
                break
            time.sleep(8 * attempt)
        if response.status_code not in expected:
            raise RuntimeError(f"HTTP {response.status_code} on {method} {url}\n{response.text[:4000]}")
        if response.text:
            return response.json()
        return None

    def put_file(self, bucket: str, path: Path):
        url = f"{bucket.rstrip('/')}/{quote(path.name)}"
        response = None
        for attempt in range(1, 6):
            with path.open("rb") as handle:
                try:
                    response = requests.put(
                        url,
                        data=handle,
                        headers=self.headers("application/octet-stream"),
                        timeout=UPLOAD_TIMEOUT,
                    )
                except (requests.Timeout, requests.ConnectionError) as exc:
                    if attempt == 5:
                        raise RuntimeError(f"Network error while uploading {path.name}: {exc}") from exc
                    time.sleep(10 * attempt)
                    continue
            if response.status_code not in TRANSIENT_STATUSES or attempt == 5:
                break
            time.sleep(10 * attempt)
        if response.status_code >= 400:
            raise RuntimeError(f"HTTP {response.status_code} while uploading {path.name}\n{response.text[:4000]}")
        return response.json()


def timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")


def write_log(label: str, stage: str, data) -> Path:
    ZENODO.mkdir(parents=True, exist_ok=True)
    path = ZENODO / f"{label}_{stage}_{timestamp()}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def normalize_metadata(metadata: dict) -> dict:
    cleaned = dict(metadata)
    cleaned.setdefault("publication_date", datetime.now(timezone.utc).date().isoformat())
    cleaned.setdefault("access_right", "open")
    cleaned.pop("doi", None)
    cleaned.pop("prereserve_doi", None)
    return cleaned


def files_for_upload(upload_dir: Path, exclude: set[str] | None = None) -> list[Path]:
    excluded = exclude or set()
    files = sorted((p for p in upload_dir.iterdir() if p.is_file() and p.name not in excluded), key=lambda p: p.name.lower())
    if not files:
        raise RuntimeError(f"No files found in {upload_dir}")
    return files


def delete_all_files(client: ZenodoClient, draft_id: int) -> list[dict]:
    files = client.request("GET", f"/api/deposit/depositions/{draft_id}/files") or []
    deleted = []
    for item in files:
        client.request("DELETE", f"/api/deposit/depositions/{draft_id}/files/{item['id']}", expected=(200, 202, 204))
        deleted.append({"filename": item.get("filename"), "id": item.get("id")})
    return deleted


def publish_task(client: ZenodoClient, label: str, task: dict, *, publish: bool) -> dict:
    record_id = int(task["record_id"])
    metadata_path = Path(task["metadata"])
    upload_dir = Path(task["upload"])
    metadata = normalize_metadata(json.loads(metadata_path.read_text(encoding="utf-8")))
    files = files_for_upload(upload_dir, set(task.get("exclude", set())))
    total = sum(path.stat().st_size for path in files)
    print(f"[{label}] creating Zenodo new version from {record_id}; {len(files)} files, {total:,} bytes", flush=True)

    new_version = client.request("POST", f"/api/deposit/depositions/{record_id}/actions/newversion")
    write_log(label, "newversion", new_version)
    draft_id = int(new_version["id"])
    print(f"[{label}] draft {draft_id}", flush=True)

    updated = client.request("PUT", f"/api/deposit/depositions/{draft_id}", payload={"metadata": metadata})
    write_log(label, "metadata", updated)

    deleted = delete_all_files(client, draft_id)
    bucket = client.request("GET", f"/api/deposit/depositions/{draft_id}")["links"]["bucket"]
    uploaded = []
    for index, path in enumerate(files, start=1):
        print(f"[{label}] upload {index}/{len(files)} {path.name} ({path.stat().st_size:,} bytes)", flush=True)
        uploaded.append(client.put_file(bucket, path))
    upload_log = {"draft_id": draft_id, "deleted": deleted, "uploaded": uploaded, "local_total_bytes": total}
    write_log(label, "upload", upload_log)

    draft = client.request("GET", f"/api/deposit/depositions/{draft_id}")
    write_log(label, "draft_verify", draft)
    if not publish:
        return {"label": label, "draft_id": draft_id, "published": False, "html": draft.get("links", {}).get("html")}

    print(f"[{label}] publishing draft {draft_id}", flush=True)
    try:
        published = client.request("POST", f"/api/deposit/depositions/{draft_id}/actions/publish")
    except RuntimeError as exc:
        # Zenodo occasionally publishes the draft and then returns a stale 404
        # from the deposit publish endpoint. Verify the record state before
        # treating that as a failure.
        if "HTTP 404" not in str(exc):
            raise
        verified = client.request("GET", f"/api/deposit/depositions/{draft_id}")
        if not (verified.get("submitted") is True and verified.get("state") == "done"):
            raise
        published = {"publish_endpoint": "returned 404 after successful publish", "verified": verified}
    write_log(label, "publish", published)
    live = client.request("GET", f"/api/deposit/depositions/{draft_id}")
    write_log(label, "live_verify", live)
    return {
        "label": label,
        "draft_id": draft_id,
        "record_id": live.get("id", draft_id),
        "doi": live.get("doi"),
        "html": live.get("links", {}).get("record_html") or live.get("links", {}).get("html"),
        "files": len(live.get("files", [])),
        "published": True,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("labels", nargs="+", choices=sorted(TASKS))
    parser.add_argument("--no-publish", action="store_true")
    args = parser.parse_args()

    client = ZenodoClient(recover_token())
    results = []
    for label in args.labels:
        results.append(publish_task(client, label, TASKS[label], publish=not args.no_publish))
    result_path = ZENODO / f"publish_current_records_result_{timestamp()}.json"
    result_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(results, indent=2, ensure_ascii=False), flush=True)
    print(f"RESULT_LOG {result_path}", flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())



