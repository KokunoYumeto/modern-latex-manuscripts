[CmdletBinding()]
param(
    [string]$ProjectRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot '..')).Path,
    [int]$MaxArchiveDepth = 2,
    [switch]$SkipCopy,
    [switch]$SkipArchiveExtraction,
    [switch]$SkipHashes,
    [string]$SevenZipPath = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Sources = @(
    [pscustomobject]@{
        Label = 'chat_translates_and_clean'
        Path = 'LOCAL_USER_HOME\Documents\Papors\Chatnotes\CHat translates and clean'
        CopyName = 'chat_translates_and_clean'
    },
    [pscustomobject]@{
        Label = 'kimi_agent_swarm_del'
        Path = 'LOCAL_USER_HOME\Documents\Papors\Kimi\Agent swarm stoef\del'
        CopyName = 'kimi_agent_swarm_del'
    }
)

$ArchiveExtensions = @('.zip', '.rar', '.7z', '.tar', '.gz', '.tgz')
$ExtractableExtensions = @('.zip', '.rar', '.7z', '.tar', '.gz', '.tgz')

function New-Directory {
    param([Parameter(Mandatory)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) {
        New-Item -ItemType Directory -Force -Path $Path | Out-Null
    }
}

function Resolve-SevenZip {
    param([string]$PreferredPath)

    $candidates = @()
    if ($PreferredPath) { $candidates += $PreferredPath }

    $cmd = Get-Command 7z -ErrorAction SilentlyContinue
    if ($cmd) { $candidates += $cmd.Source }

    $candidates += @(
        'C:\Program Files\7-Zip\7z.exe',
        'C:\Program Files (x86)\7-Zip\7z.exe'
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate)) {
            return (Resolve-Path -LiteralPath $candidate).Path
        }
    }

    throw '7-Zip was not found. Install 7-Zip or pass -SevenZipPath.'
}

function Get-StringHash {
    param([Parameter(Mandatory)][string]$Text)

    $sha1 = [System.Security.Cryptography.SHA1]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        $hash = $sha1.ComputeHash($bytes)
        return (([System.BitConverter]::ToString($hash)) -replace '-', '').Substring(0, 12).ToLowerInvariant()
    }
    finally {
        $sha1.Dispose()
    }
}

function Get-RelativePath {
    param(
        [Parameter(Mandatory)][string]$Root,
        [Parameter(Mandatory)][string]$Path
    )

    $rootFull = [System.IO.Path]::GetFullPath($Root)
    $pathFull = [System.IO.Path]::GetFullPath($Path)
    return [System.IO.Path]::GetRelativePath($rootFull, $pathFull)
}

function Join-RelativePath {
    param(
        [Parameter(Mandatory)][string]$Root,
        [Parameter(Mandatory)][string]$RelativePath
    )

    return [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($Root, $RelativePath))
}

function New-SafeName {
    param(
        [Parameter(Mandatory)][string]$Text,
        [int]$MaxBaseLength = 120
    )

    $safe = $Text -replace '[\\/:*?"<>|]+', '__'
    $safe = $safe -replace '\s+', '_'
    $safe = $safe.Trim(' ', '.', '_')
    if ([string]::IsNullOrWhiteSpace($safe)) {
        $safe = 'archive'
    }
    if ($safe.Length -gt $MaxBaseLength) {
        $safe = $safe.Substring(0, $MaxBaseLength).Trim(' ', '.', '_')
    }
    return ('{0}--{1}' -f $safe, (Get-StringHash -Text $Text))
}

function Get-FileSha256 {
    param([Parameter(Mandatory)][string]$Path)

    try {
        return [pscustomobject]@{
            Hash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
            Status = 'hashed'
        }
    }
    catch {
        return [pscustomobject]@{
            Hash = ''
            Status = ('hash_failed: ' + $_.Exception.Message)
        }
    }
}

function Get-FileInventory {
    param(
        [Parameter(Mandatory)][string]$Root,
        [Parameter(Mandatory)][string]$Corpus,
        [Parameter(Mandatory)][string]$Scope,
        [string]$MappedRoot = '',
        [bool]$ComputeHashes = $true
    )

    $rows = [System.Collections.Generic.List[object]]::new()
    if (-not (Test-Path -LiteralPath $Root)) {
        return $rows
    }

    $resolvedRoot = (Resolve-Path -LiteralPath $Root).Path
    $files = Get-ChildItem -LiteralPath $resolvedRoot -Recurse -File -Force -ErrorAction SilentlyContinue
    foreach ($file in $files) {
        $relative = Get-RelativePath -Root $resolvedRoot -Path $file.FullName
        $mappedPath = ''
        if ($MappedRoot) {
            $mappedPath = Join-RelativePath -Root $MappedRoot -RelativePath $relative
        }

        $hash = ''
        $hashStatus = 'skipped'
        if ($ComputeHashes) {
            $hashResult = Get-FileSha256 -Path $file.FullName
            $hash = $hashResult.Hash
            $hashStatus = $hashResult.Status
        }

        $rows.Add([pscustomobject]@{
            scope = $Scope
            corpus = $Corpus
            root = $resolvedRoot
            relative_path = $relative
            full_path = $file.FullName
            mapped_path = $mappedPath
            file_name = $file.Name
            directory = $file.DirectoryName
            extension = $file.Extension.ToLowerInvariant()
            bytes = [int64]$file.Length
            created_utc = $file.CreationTimeUtc.ToString('o')
            modified_utc = $file.LastWriteTimeUtc.ToString('o')
            sha256 = $hash
            hash_status = $hashStatus
            attributes = $file.Attributes.ToString()
        })
    }

    return $rows
}

function Invoke-RobocopyTree {
    param(
        [Parameter(Mandatory)][string]$Source,
        [Parameter(Mandatory)][string]$Destination,
        [Parameter(Mandatory)][string]$LogPath
    )

    New-Directory -Path $Destination
    $arguments = @(
        $Source,
        $Destination,
        '/E',
        '/COPY:DAT',
        '/DCOPY:DAT',
        '/R:1',
        '/W:1',
        '/MT:16',
        '/XJ',
        '/FFT',
        '/NP',
        "/LOG:$LogPath"
    )

    & robocopy @arguments | Out-Null
    $code = $LASTEXITCODE
    if ($code -ge 8) {
        throw "Robocopy failed with exit code $code. See $LogPath"
    }

    return $code
}

function ConvertFrom-7ZipTechnicalList {
    param([string[]]$Lines = @())

    $rows = [System.Collections.Generic.List[object]]::new()
    $entry = [ordered]@{}
    $inEntries = $false

    foreach ($rawLine in $Lines) {
        $line = [string]$rawLine
        if ($line -match '^-{5,}\s*$') {
            $inEntries = $true
            continue
        }
        if (-not $inEntries) {
            continue
        }
        if ([string]::IsNullOrWhiteSpace($line)) {
            if ($entry.Count -gt 0) {
                $rows.Add([pscustomobject]$entry)
                $entry = [ordered]@{}
            }
            continue
        }
        if ($line -match '^([^=]+?) = (.*)$') {
            $entry[$Matches[1].Trim()] = $Matches[2]
        }
    }

    if ($entry.Count -gt 0) {
        $rows.Add([pscustomobject]$entry)
    }

    return $rows
}

function Get-ObjectPropertyText {
    param(
        [Parameter(Mandatory)]$Object,
        [Parameter(Mandatory)][string]$Name
    )

    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        return ''
    }
    return [string]$property.Value
}

function Get-ExtensionCounts {
    param([Parameter(Mandatory)]$Rows)

    $Rows |
        Group-Object extension |
        Sort-Object -Property @{ Expression = 'Count'; Descending = $true }, @{ Expression = 'Name'; Ascending = $true } |
        ForEach-Object {
            $sum = ($_.Group | Measure-Object -Property bytes -Sum).Sum
            if ($null -eq $sum) { $sum = 0 }
            [pscustomobject]@{
                extension = if ($_.Name) { $_.Name } else { '[none]' }
                count = $_.Count
                bytes = [int64]$sum
            }
        }
}

function Measure-InventoryBytes {
    param($Rows)

    $sum = ($Rows | Measure-Object -Property bytes -Sum).Sum
    if ($null -eq $sum) { return [int64]0 }
    return [int64]$sum
}

function New-ArchiveQueueItem {
    param(
        [Parameter(Mandatory)][int]$Number,
        [Parameter(Mandatory)][int]$Depth,
        [Parameter(Mandatory)][string]$Corpus,
        [Parameter(Mandatory)][string]$Origin,
        [string]$ParentArchiveId = '',
        [Parameter(Mandatory)][string]$ArchivePath,
        [Parameter(Mandatory)][string]$RelativePath
    )

    $file = Get-Item -LiteralPath $ArchivePath -Force
    return [pscustomobject]@{
        archive_id = ('A{0:d5}' -f $Number)
        depth = $Depth
        corpus = $Corpus
        origin = $Origin
        parent_archive_id = $ParentArchiveId
        archive_path = $file.FullName
        archive_relative_path = $RelativePath
        archive_name = $file.Name
        extension = $file.Extension.ToLowerInvariant()
        bytes = [int64]$file.Length
    }
}

function Read-ArchiveContents {
    param(
        [Parameter(Mandatory)]$Archive,
        [Parameter(Mandatory)][string]$SevenZip,
        [Parameter(Mandatory)][string]$LogDirectory
    )

    $logPath = Join-Path $LogDirectory ('list_{0}_{1}.log' -f $Archive.archive_id, (New-SafeName -Text $Archive.archive_name -MaxBaseLength 60))
    $output = & $SevenZip 'l' '-slt' '-bsp0' $Archive.archive_path 2>&1
    $exitCode = $LASTEXITCODE
    $lines = @($output | ForEach-Object { [string]$_ })
    $lines | Set-Content -LiteralPath $logPath -Encoding UTF8

    $entryObjects = ConvertFrom-7ZipTechnicalList -Lines $lines
    $status = if ($exitCode -eq 0) {
        'listed'
    }
    elseif ($entryObjects.Count -gt 0) {
        'listed_with_warnings'
    }
    else {
        'list_failed'
    }

    $rows = [System.Collections.Generic.List[object]]::new()
    if ($entryObjects.Count -eq 0) {
        $rows.Add([pscustomobject]@{
            archive_id = $Archive.archive_id
            depth = $Archive.depth
            corpus = $Archive.corpus
            origin = $Archive.origin
            parent_archive_id = $Archive.parent_archive_id
            archive_path = $Archive.archive_path
            archive_relative_path = $Archive.archive_relative_path
            archive_name = $Archive.archive_name
            archive_extension = $Archive.extension
            archive_bytes = $Archive.bytes
            entry_path = ''
            entry_is_folder = ''
            entry_bytes = ''
            entry_packed_bytes = ''
            entry_modified = ''
            entry_crc = ''
            entry_encrypted = ''
            list_status = $status
            list_exit_code = $exitCode
            log_path = $logPath
        })
        return $rows
    }

    foreach ($entry in $entryObjects) {
        $rows.Add([pscustomobject]@{
            archive_id = $Archive.archive_id
            depth = $Archive.depth
            corpus = $Archive.corpus
            origin = $Archive.origin
            parent_archive_id = $Archive.parent_archive_id
            archive_path = $Archive.archive_path
            archive_relative_path = $Archive.archive_relative_path
            archive_name = $Archive.archive_name
            archive_extension = $Archive.extension
            archive_bytes = $Archive.bytes
            entry_path = Get-ObjectPropertyText -Object $entry -Name 'Path'
            entry_is_folder = Get-ObjectPropertyText -Object $entry -Name 'Folder'
            entry_bytes = Get-ObjectPropertyText -Object $entry -Name 'Size'
            entry_packed_bytes = Get-ObjectPropertyText -Object $entry -Name 'Packed Size'
            entry_modified = Get-ObjectPropertyText -Object $entry -Name 'Modified'
            entry_crc = Get-ObjectPropertyText -Object $entry -Name 'CRC'
            entry_encrypted = Get-ObjectPropertyText -Object $entry -Name 'Encrypted'
            list_status = $status
            list_exit_code = $exitCode
            log_path = $logPath
        })
    }

    return $rows
}

function Expand-With7Zip {
    param(
        [Parameter(Mandatory)]$Archive,
        [Parameter(Mandatory)][string]$SevenZip,
        [Parameter(Mandatory)][string]$ExtractRoot,
        [Parameter(Mandatory)][string]$LogDirectory,
        [Parameter(Mandatory)][bool]$SkipExtraction
    )

    if ($SkipExtraction) {
        return [pscustomobject]@{
            archive_id = $Archive.archive_id
            depth = $Archive.depth
            corpus = $Archive.corpus
            archive_path = $Archive.archive_path
            archive_relative_path = $Archive.archive_relative_path
            archive_extension = $Archive.extension
            extract_dir = ''
            status = 'skipped'
            exit_code = ''
            log_path = ''
            nested_archive_count = 0
        }
    }

    if ($ExtractableExtensions -notcontains $Archive.extension) {
        return [pscustomobject]@{
            archive_id = $Archive.archive_id
            depth = $Archive.depth
            corpus = $Archive.corpus
            archive_path = $Archive.archive_path
            archive_relative_path = $Archive.archive_relative_path
            archive_extension = $Archive.extension
            extract_dir = ''
            status = 'unsupported_extension'
            exit_code = ''
            log_path = ''
            nested_archive_count = 0
        }
    }

    $safeName = New-SafeName -Text ('{0}_{1}_{2}' -f $Archive.archive_id, $Archive.corpus, $Archive.archive_relative_path)
    $extractDir = Join-Path $ExtractRoot ('depth_{0}\{1}' -f $Archive.depth, $safeName)
    New-Directory -Path $extractDir

    $logPath = Join-Path $LogDirectory ('extract_{0}_{1}.log' -f $Archive.archive_id, (New-SafeName -Text $Archive.archive_name -MaxBaseLength 60))
    $output = & $SevenZip 'x' '-y' '-bsp0' '-bb0' "-o$extractDir" $Archive.archive_path 2>&1
    $exitCode = $LASTEXITCODE
    @($output | ForEach-Object { [string]$_ }) | Set-Content -LiteralPath $logPath -Encoding UTF8

    $status = if ($exitCode -eq 0) {
        'extracted'
    }
    elseif ($exitCode -eq 1) {
        'extracted_with_warnings'
    }
    else {
        'extract_failed'
    }

    if (($status -eq 'extracted' -or $status -eq 'extracted_with_warnings') -and $Archive.archive_path.ToLowerInvariant().EndsWith('.tar.gz')) {
        $tarFiles = Get-ChildItem -LiteralPath $extractDir -Recurse -File -Force -Filter '*.tar' -ErrorAction SilentlyContinue
        foreach ($tarFile in $tarFiles) {
            $tarOut = Join-Path $tarFile.DirectoryName ($tarFile.BaseName + '_tar_contents')
            New-Directory -Path $tarOut
            $tarOutput = & $SevenZip 'x' '-y' '-bsp0' '-bb0' "-o$tarOut" $tarFile.FullName 2>&1
            $tarExit = $LASTEXITCODE
            Add-Content -LiteralPath $logPath -Encoding UTF8 -Value ''
            Add-Content -LiteralPath $logPath -Encoding UTF8 -Value ('Nested tar extraction: {0}' -f $tarFile.FullName)
            @($tarOutput | ForEach-Object { [string]$_ }) | Add-Content -LiteralPath $logPath -Encoding UTF8
            if ($tarExit -gt 1 -and $status -eq 'extracted') {
                $status = 'extracted_tar_failed'
            }
            elseif ($tarExit -eq 1 -and $status -eq 'extracted') {
                $status = 'extracted_tar_with_warnings'
            }
        }
    }

    $nestedCount = 0
    if (Test-Path -LiteralPath $extractDir) {
        $nestedCount = @(
            Get-ChildItem -LiteralPath $extractDir -Recurse -File -Force -ErrorAction SilentlyContinue |
                Where-Object { $ArchiveExtensions -contains $_.Extension.ToLowerInvariant() }
        ).Count
    }

    return [pscustomobject]@{
        archive_id = $Archive.archive_id
        depth = $Archive.depth
        corpus = $Archive.corpus
        archive_path = $Archive.archive_path
        archive_relative_path = $Archive.archive_relative_path
        archive_extension = $Archive.extension
        extract_dir = $extractDir
        status = $status
        exit_code = $exitCode
        log_path = $logPath
        nested_archive_count = $nestedCount
    }
}

New-Directory -Path $ProjectRoot
$InventoryRoot = Join-Path $ProjectRoot 'inventory'
$LogRoot = Join-Path $ProjectRoot 'logs'
$CopyRoot = Join-Path $ProjectRoot 'source_copy'
$ExtractRoot = Join-Path $ProjectRoot 'archives_extracted'
New-Directory -Path $InventoryRoot
New-Directory -Path $LogRoot
New-Directory -Path $CopyRoot
New-Directory -Path $ExtractRoot

$sevenZip = Resolve-SevenZip -PreferredPath $SevenZipPath
$computeHashes = -not $SkipHashes.IsPresent

Write-Host "Project root: $ProjectRoot"
Write-Host "7-Zip: $sevenZip"
Write-Host "Hashing enabled: $computeHashes"
Write-Host "Max archive depth: $MaxArchiveDepth"

$copyResults = [System.Collections.Generic.List[object]]::new()
foreach ($source in $Sources) {
    if (-not (Test-Path -LiteralPath $source.Path)) {
        throw "Source does not exist: $($source.Path)"
    }

    $destination = Join-Path $CopyRoot $source.CopyName
    $copyLog = Join-Path $LogRoot ('robocopy_{0}.log' -f $source.CopyName)
    if ($SkipCopy) {
        Write-Host "Skipping copy for $($source.Label)"
        $copyCode = ''
    }
    else {
        Write-Host "Copying $($source.Path) -> $destination"
        $copyCode = Invoke-RobocopyTree -Source $source.Path -Destination $destination -LogPath $copyLog
    }

    $copyResults.Add([pscustomobject]@{
        corpus = $source.Label
        source_path = $source.Path
        copy_path = $destination
        robocopy_exit_code = $copyCode
        log_path = $copyLog
    })
}
$copyResults | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'copy_results.csv') -NoTypeInformation

Write-Host 'Indexing original source files...'
$sourceRows = [System.Collections.Generic.List[object]]::new()
foreach ($source in $Sources) {
    $copyPath = Join-Path $CopyRoot $source.CopyName
    $items = Get-FileInventory -Root $source.Path -Corpus $source.Label -Scope 'source_original' -MappedRoot $copyPath -ComputeHashes:$computeHashes
    foreach ($item in $items) { $sourceRows.Add($item) }
}
$sourceRows | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'source_files.csv') -NoTypeInformation

Write-Host 'Indexing copied source files...'
$copiedRows = [System.Collections.Generic.List[object]]::new()
foreach ($source in $Sources) {
    $copyPath = Join-Path $CopyRoot $source.CopyName
    $items = Get-FileInventory -Root $copyPath -Corpus $source.Label -Scope 'source_copy' -MappedRoot $source.Path -ComputeHashes:$computeHashes
    foreach ($item in $items) { $copiedRows.Add($item) }
}
$copiedRows | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'copied_files.csv') -NoTypeInformation

Write-Host 'Preparing archive queue...'
$archiveQueue = [System.Collections.Generic.List[object]]::new()
$archiveNumber = 0
foreach ($row in ($copiedRows | Where-Object { $ArchiveExtensions -contains $_.extension })) {
    $archiveNumber += 1
    $archiveQueue.Add((New-ArchiveQueueItem -Number $archiveNumber -Depth 0 -Corpus $row.corpus -Origin 'source_copy' -ArchivePath $row.full_path -RelativePath $row.relative_path))
}

$archiveContentRows = [System.Collections.Generic.List[object]]::new()
$archiveExtractRows = [System.Collections.Generic.List[object]]::new()
$processedArchivePaths = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
$queueIndex = 0

while ($queueIndex -lt $archiveQueue.Count) {
    $archive = $archiveQueue[$queueIndex]
    $queueIndex += 1

    if (-not $processedArchivePaths.Add($archive.archive_path)) {
        continue
    }

    Write-Host ("Archive {0}: depth {1} {2}" -f $archive.archive_id, $archive.depth, $archive.archive_relative_path)

    $listed = Read-ArchiveContents -Archive $archive -SevenZip $sevenZip -LogDirectory $LogRoot
    foreach ($row in $listed) { $archiveContentRows.Add($row) }

    $extractResult = Expand-With7Zip -Archive $archive -SevenZip $sevenZip -ExtractRoot $ExtractRoot -LogDirectory $LogRoot -SkipExtraction:$SkipArchiveExtraction.IsPresent
    $archiveExtractRows.Add($extractResult)

    if (($extractResult.status -like 'extracted*') -and $archive.depth -lt $MaxArchiveDepth -and (Test-Path -LiteralPath $extractResult.extract_dir)) {
        $nestedArchives = Get-ChildItem -LiteralPath $extractResult.extract_dir -Recurse -File -Force -ErrorAction SilentlyContinue |
            Where-Object { $ArchiveExtensions -contains $_.Extension.ToLowerInvariant() }

        foreach ($nested in $nestedArchives) {
            $archiveNumber += 1
            $nestedRelative = Get-RelativePath -Root $ExtractRoot -Path $nested.FullName
            $archiveQueue.Add((New-ArchiveQueueItem -Number $archiveNumber -Depth ($archive.depth + 1) -Corpus $archive.corpus -Origin 'archives_extracted' -ParentArchiveId $archive.archive_id -ArchivePath $nested.FullName -RelativePath $nestedRelative))
        }
    }
}

$archiveQueue | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'archive_queue.csv') -NoTypeInformation
$archiveContentRows | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'archive_contents.csv') -NoTypeInformation
$archiveExtractRows | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'archive_extracts.csv') -NoTypeInformation

Write-Host 'Indexing extracted archive files...'
$extractedRows = Get-FileInventory -Root $ExtractRoot -Corpus 'archive_extracts' -Scope 'archives_extracted' -ComputeHashes:$computeHashes
$extractedRows | Export-Csv -LiteralPath (Join-Path $InventoryRoot 'extracted_files.csv') -NoTypeInformation

$sourceBytes = Measure-InventoryBytes -Rows $sourceRows
$copiedBytes = Measure-InventoryBytes -Rows $copiedRows
$extractedBytes = Measure-InventoryBytes -Rows $extractedRows

$summary = [ordered]@{
    generated_at = (Get-Date).ToString('o')
    project_root = $ProjectRoot
    copy_root = $CopyRoot
    archive_extract_root = $ExtractRoot
    inventory_root = $InventoryRoot
    log_root = $LogRoot
    seven_zip = $sevenZip
    compute_hashes = $computeHashes
    max_archive_depth = $MaxArchiveDepth
    sources = $Sources
    counts = [ordered]@{
        source_files = $sourceRows.Count
        copied_files = $copiedRows.Count
        source_bytes = $sourceBytes
        copied_bytes = $copiedBytes
        archive_queue_items = $archiveQueue.Count
        archive_content_rows = $archiveContentRows.Count
        archive_extract_rows = $archiveExtractRows.Count
        extracted_files = $extractedRows.Count
        extracted_bytes = $extractedBytes
    }
    extension_counts = [ordered]@{
        source_original = @(Get-ExtensionCounts -Rows $sourceRows)
        source_copy = @(Get-ExtensionCounts -Rows $copiedRows)
        archives_extracted = @(Get-ExtensionCounts -Rows $extractedRows)
    }
}

$summaryPath = Join-Path $InventoryRoot 'summary.json'
$summary | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $summaryPath -Encoding UTF8

$readme = @"
# Inventory Output

Generated: $($summary.generated_at)

This folder is the machine-readable index for the manuscript translation/typesetting consolidation project.

- source_files.csv: original files in the two source folders, with SHA-256 hashes unless hashing was skipped.
- copied_files.csv: files copied into the project workspace under source_copy.
- archive_queue.csv: every archive discovered and processed, including nested archives up to depth $MaxArchiveDepth.
- archive_contents.csv: 7-Zip technical listings for ZIP, RAR, and related archive files.
- archive_extracts.csv: extraction status and extraction folder for each processed archive.
- extracted_files.csv: files unpacked from archives, with SHA-256 hashes unless hashing was skipped.
- copy_results.csv: robocopy result codes and log paths.
- summary.json: aggregate counts, byte totals, roots, and extension summaries.

Logs are stored in:

$LogRoot
"@
$readme | Set-Content -LiteralPath (Join-Path $InventoryRoot 'README.md') -Encoding UTF8

Write-Host "Done. Summary: $summaryPath"
exit 0
