from __future__ import annotations

import json
import re
import shutil
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MIRROR = ROOT / "github_mirror" / "modern-latex-manuscripts"
RELEASES = ROOT / "release_candidates"
ZENODO = ROOT / "zenodo"


CURRENT = {
    "main": "https://zenodo.org/records/20393488",
    "workflow": "https://zenodo.org/records/20461174",
    "ega": "https://zenodo.org/records/20414353",
    "sga": "https://zenodo.org/records/20410947",
    "non_european": "https://zenodo.org/records/20410957",
    "weber": "https://zenodo.org/records/20412153",
    "noether": "https://zenodo.org/records/20412587",
    "deligne": "https://zenodo.org/records/20410853",
    "classical": "https://zenodo.org/records/20414787",
    "author_cluster": "https://zenodo.org/records/20411006",
    "gauss": "https://zenodo.org/records/20410934",
    "riemann": "https://zenodo.org/records/20429778",
}


RECORDS = {
    "ega": {
        "upload": RELEASES / "zenodo_satellite_ega_working_translation_public_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "ega",
        "source": MIRROR / "sources" / "ega",
        "summary": "91 EGA - Public Summary.json",
        "metadata": ZENODO / "metadata_satellite_ega_working_translation_public_current.json",
        "source_zips": [
            ("80 EGA - EGA 0 IV Translation TeX Supplement.zip", None),
            ("82 EGA - EGA IV Main Text Translation TeX Supplement.zip", None),
        ],
        "replace_source": False,
    },
    "sga": {
        "upload": RELEASES / "zenodo_satellite_sga_working_translation_public_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "sga",
        "source": MIRROR / "sources" / "sga",
        "summary": "99 SGA - Public Summary.json",
        "metadata": ZENODO / "metadata_satellite_sga_working_translation_public_current.json",
        "source_zips": [
            ("80 SGA - Current Cumulative TeX Sources and Render Checks.zip", "00 SGA - Current Sources and SGA 5 High-Fidelity Edition"),
        ],
        "replace_source": True,
    },
    "non-european": {
        "upload": RELEASES / "zenodo_satellite_non_european_multilingual_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "non-european",
        "source": MIRROR / "sources" / "non-european",
        "summary": "90 Non-European Mathematics - Public Summary.json",
        "metadata": ZENODO / "metadata_satellite_non_european_multilingual_current.json",
        "source_zips": [
            ("80 Non-European Mathematics - TeX Sources and Combined Bundles.zip", None),
            ("84 Non-European Mathematics - Audit and Repair Notes.zip", "audit_and_repair_notes"),
        ],
        "replace_source": True,
    },
    "weber": {
        "upload": RELEASES / "zenodo_author_weber_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "weber",
        "source": MIRROR / "sources" / "weber",
        "summary": "90 Weber - Public Summary.json",
        "metadata": ZENODO / "metadata_author_weber_current.json",
        "source_zips": [
            ("80 Weber - TeX Sources, Component PDFs, and Provenance.zip", None),
        ],
        "replace_source": True,
    },
    "noether": {
        "upload": RELEASES / "zenodo_author_noether_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "noether",
        "source": MIRROR / "sources" / "noether",
        "summary": "90 Noether - Public Summary.json",
        "metadata": ZENODO / "metadata_author_noether_current.json",
        "source_zips": [
            ("80 Noether - TeX Sources, Component PDFs, and Provenance.zip", None),
        ],
        "replace_source": True,
    },
    "classical": {
        "upload": RELEASES / "zenodo_satellite_classical_algebra_arithmetic_modern_latex_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "classical",
        "source": MIRROR / "sources" / "classical",
        "summary": "Record Summary - Classical Algebra and Arithmetic.json",
        "metadata": ZENODO / "metadata_satellite_classical_algebra_arithmetic_modern_latex_current.json",
        "source_zips": [
            ("Supplementary Sources - Classical Algebra and Arithmetic.zip", None),
        ],
        "replace_source": True,
    },
    "author-cluster": {
        "upload": RELEASES / "zenodo_satellite_author_cluster_public_current_clean_surface" / "upload",
        "reader": MIRROR / "reader-pdfs" / "author-cluster",
        "source": MIRROR / "sources" / "author-cluster",
        "summary": "90 Additional Author Cluster - Public Summary.json",
        "metadata": ZENODO / "metadata_satellite_author_cluster_public_current_clean_surface.json",
        "source_zips": [
            ("80 Additional Author Cluster - Sources, TeX, and Provenance.zip", None),
        ],
        "replace_source": True,
    },
    "gauss": {
        "upload": RELEASES / "zenodo_author_gauss_current" / "upload",
        "reader": MIRROR / "reader-pdfs" / "gauss",
        "source": MIRROR / "sources" / "gauss",
        "summary": "90 Carl Friedrich Gauss - Public Summary.json",
        "metadata": ZENODO / "metadata_author_gauss_current.json",
        "source_zips": [
            ("80 Carl Friedrich Gauss - TeX Sources, Component PDFs, and Audits.zip", None),
        ],
        "replace_source": True,
    },
    "deligne": {
        "upload": RELEASES / "zenodo_satellite_deligne_papers_translations" / "upload",
        "reader": MIRROR / "reader-pdfs" / "deligne",
        "source": MIRROR / "sources" / "deligne",
        "summary": "99 Deligne - Public Summary.json",
        "metadata": ZENODO / "metadata_satellite_deligne_papers_translations.json",
        "source_zips": [
            ("10 Deligne - Original-Language Reference PDFs.zip", "original-language-reference-pdfs"),
            ("90 Deligne - Paper-Level Translation TeX and PDFs.zip", "paper-level-translations"),
            ("91 Deligne - Prior Translation Packages and Provenance A.zip", "prior-translation-packages-a"),
            ("92 Deligne - Prior Translation Packages and Provenance B.zip", "prior-translation-packages-b"),
            ("93 Deligne - Additional Sources, Reports, and Render Checks.zip", "additional-sources-reports-render-checks"),
        ],
        "replace_source": True,
    },
}


WORKFLOW_PACKET = RELEASES / "workflow_replication_packet_20260530"


def ensure_inside(path: Path, parent: Path) -> None:
    resolved = path.resolve()
    base = parent.resolve()
    if resolved != base and base not in resolved.parents:
        raise RuntimeError(f"Refusing path outside {base}: {resolved}")


def reset_dir(path: Path) -> None:
    ensure_inside(path, MIRROR)
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def pdf_page_count(path: Path) -> int | None:
    try:
        result = subprocess.run(
            ["pdfinfo", str(path)],
            check=True,
            capture_output=True,
            text=True,
        )
    except (FileNotFoundError, subprocess.CalledProcessError):
        return None
    for line in result.stdout.splitlines():
        if line.startswith("Pages:"):
            try:
                return int(line.split(":", 1)[1].strip())
            except ValueError:
                return None
    return None


def split_large_pdf_for_github(src: Path, dest: Path) -> list[dict[str, object]]:
    pages = pdf_page_count(src)
    if not pages:
        return []

    limit = 95 * 1024 * 1024
    target = 90 * 1024 * 1024
    chunks = max(2, (src.stat().st_size + target - 1) // target)
    produced: list[dict[str, object]] = []

    for attempt in range(8):
        produced.clear()
        pages_per_chunk = max(1, (pages + chunks - 1) // chunks)
        outputs: list[Path] = []
        failed = False
        for index, first_page in enumerate(range(1, pages + 1, pages_per_chunk), start=1):
            last_page = min(pages, first_page + pages_per_chunk - 1)
            out = dest / f"{src.stem}, part {index:02d} of {chunks:02d}{src.suffix}"
            try:
                subprocess.run(
                    [
                        "mutool",
                        "clean",
                        "-gggg",
                        "-z",
                        "-f",
                        "-i",
                        "-c",
                        str(src),
                        str(out),
                        f"{first_page}-{last_page}",
                    ],
                    check=True,
                    capture_output=True,
                    text=True,
                )
            except (FileNotFoundError, subprocess.CalledProcessError):
                failed = True
                break
            outputs.append(out)

        if failed or any(out.stat().st_size > limit for out in outputs):
            for out in outputs:
                out.unlink(missing_ok=True)
            chunks += 1
            continue

        for out in outputs:
            produced.append(
                {
                    "path": str(out.relative_to(MIRROR)).replace("\\", "/"),
                    "bytes": out.stat().st_size,
                    "split_from": src.name,
                }
            )
        return produced

    for out in dest.glob(f"{src.stem}, part *{src.suffix}"):
        out.unlink(missing_ok=True)
    return []


def copy_public_pdfs(upload: Path, dest: Path) -> list[dict[str, object]]:
    reset_dir(dest)
    copied = []
    for src in sorted(upload.glob("*.pdf")):
        if src.stat().st_size > 95 * 1024 * 1024:
            split = split_large_pdf_for_github(src, dest)
            if split:
                copied.extend(split)
                continue
        dst = dest / src.name
        shutil.copy2(src, dst)
        copied.append({"path": str(dst.relative_to(MIRROR)).replace("\\", "/"), "bytes": dst.stat().st_size})
    return copied


def should_skip_zip_member(name: str, size: int) -> bool:
    lower = name.lower()
    if name.endswith("/"):
        return False
    if lower.endswith((".bak", ".bak2", ".tmp", ".orig", ".rej")):
        return True
    if size > 95 * 1024 * 1024:
        return True
    if lower.endswith((".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp")):
        return True
    if lower.endswith((".zip", ".7z", ".rar")):
        return True
    parts = [part for part in lower.split("/") if part]
    if any(part.startswith(("work_", "_work_", "ocr_", "scan_png")) for part in parts):
        return True
    if any(part in {"working", "pngs", "rendered_pages", "page_images"} for part in parts):
        return True
    if (
        any(part in {"scans", "source_scans", "source-scans"} for part in parts)
        and lower.endswith((".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"))
    ):
        return True
    if "as_received/" in lower:
        return True
    if "as-received/" in lower:
        return True
    if lower.startswith("input_artifacts_and_audits/"):
        return True
    if "superseded-top-level-sga5-strict-supplements/" in lower:
        return True
    if "sga5-high-fidelity-through-expose-xv-page-450/" in lower:
        return True
    if "superseded-top-level-noether-paper-level-readers/" in lower:
        return True
    if "superseded-top-level-weber-literal-readers/" in lower:
        return True
    if "kimi" in lower:
        return True
    if any(token in lower for token in ["chatgpt", "claude", "handoff", "cleanup"]):
        return True
    if lower.startswith("cayley_clean_per_volume_2026-05-29/"):
        return True
    if lower.startswith("cayley_clean_per_volume_2026-05-29/pdf/"):
        return True
    if lower.startswith("cayley-current-slice-and-source-rebuild-2026-05-29/broad-working-volume-pdfs/"):
        return True
    cayley_public_prefix = (
        "cayley-current-slice-and-source-rebuild-2026-05-29/"
        "cayley_clean_per_volume_public/cayley_collected_mathematical_papers_"
    )
    if lower.startswith(cayley_public_prefix):
        return True
    cayley_current_prefix = (
        "cayley-current-slice-and-source-rebuild-2026-05-29/"
        "cayley_clean_per_volume_public/"
    )
    if lower.startswith(cayley_current_prefix):
        rest = lower[len(cayley_current_prefix):]
        if not (rest.startswith("sources_tex_") or rest.startswith("scan_gap_pages/")):
            return True
        if rest in {"sources_tex_vol_viii/status.md", "sources_tex_vol_viii/_build_master.py"}:
            return True
    if lower == "cayley-current-slice-and-source-rebuild-2026-05-29/cayley_public_rebuild_manifest.json":
        return True
    if "__macosx" in lower:
        return True
    return False


def public_skipped_summary(skipped: list[str]) -> dict[str, int]:
    summary = {
        "oversized_or_binary_archive": 0,
        "raw_delivery_or_internal_artifact": 0,
        "other": 0,
    }
    for name in skipped:
        lower = name.lower()
        if lower.endswith((".zip", ".7z", ".rar")):
            summary["oversized_or_binary_archive"] += 1
        elif "as_received/" in lower or lower.startswith("input_artifacts_and_audits/"):
            summary["raw_delivery_or_internal_artifact"] += 1
        else:
            summary["other"] += 1
    return summary


def safe_extract(zip_path: Path, dest: Path) -> dict[str, object]:
    dest.mkdir(parents=True, exist_ok=True)
    extracted = 0
    skipped = []
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            name = info.filename
            if should_skip_zip_member(name, info.file_size):
                skipped.append(name)
                continue
            target = dest / name
            ensure_inside(target, MIRROR)
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as source, target.open("wb") as handle:
                shutil.copyfileobj(source, handle)
            extracted += 1
    return {
        "zip": str(zip_path.relative_to(ROOT)).replace("\\", "/"),
        "dest": str(dest.relative_to(MIRROR)).replace("\\", "/"),
        "extracted": extracted,
        "skipped_summary": public_skipped_summary(skipped),
        "skipped_count": len(skipped),
    }


def copy_if_exists(src: Path, dst: Path) -> dict[str, object] | None:
    if not src.exists():
        return None
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return {"path": str(dst.relative_to(MIRROR)).replace("\\", "/"), "bytes": dst.stat().st_size}


def update_text_file(path: Path, replacements: dict[str, str]) -> None:
    text = path.read_text(encoding="utf-8")
    for old, new in replacements.items():
        text = text.replace(old, new)
    path.write_text(text, encoding="utf-8")


def update_public_text_files(replacements: dict[str, str]) -> None:
    text_suffixes = {".md", ".json", ".csv", ".cff", ".txt"}
    for path in MIRROR.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        try:
            relative = path.relative_to(MIRROR)
        except ValueError:
            relative = path
        if relative.parts and relative.parts[0] == "sources":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        new = text
        for old, replacement in replacements.items():
            new = new.replace(old, replacement)
        if new != text:
            path.write_text(new, encoding="utf-8")


def write_status_files(manifest: dict[str, object]) -> None:
    (MIRROR / "manifests").mkdir(parents=True, exist_ok=True)
    (MIRROR / "manifests" / "current_public_records.json").write_text(
        json.dumps(CURRENT, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    (MIRROR / "manifests" / "github_mirror_sync_manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    status = f"""# Current Archive Status

Generated from the local public release folders.

- Main landing and preservation backstop: {CURRENT["main"]}
- Workflow and replication packet: {CURRENT["workflow"]}
- EGA: {CURRENT["ega"]}
- SGA: {CURRENT["sga"]}
- Non-European and multilingual mathematics: {CURRENT["non_european"]}
- Heinrich Weber: {CURRENT["weber"]}
- Emmy Noether: {CURRENT["noether"]}
- Deligne papers: {CURRENT["deligne"]}
- Classical Cayley/Dedekind/Dirichlet shelf: {CURRENT["classical"]}
- Additional author cluster, including Landau and Sylvester source scans: {CURRENT["author_cluster"]}
- Gauss: {CURRENT["gauss"]}
- Riemann: {CURRENT["riemann"]}

GitHub contains forkable reader PDFs and reasonably sized source material. Very large raw preservation ZIPs, page-image bundles, and complete provenance dumps remain on Zenodo.
"""
    (MIRROR / "manifests" / "current_archive_status.md").write_text(status, encoding="utf-8")


def cleanup_public_surface() -> None:
    for path in (MIRROR / "zenodo-metadata").glob("metadata_main_landing_current_*.json"):
        if path.name != "metadata_main_landing_current_after_author_refresh.json":
            ensure_inside(path, MIRROR)
            path.unlink()
    for name in [
        "non_eu_final_release_vs_current_promotion_audit_20260529.json",
        "non_eu_current_output_quality_audit_20260529.json",
        "non_european_current_quality_audit.csv",
        "non_european_current_repair_queue_20260528.csv",
        "non_european_current_repair_queue_20260528.md",
        "github_reader_pdf_health_audit_20260529.json",
    ]:
        path = MIRROR / "manifests" / name
        if path.exists():
            ensure_inside(path, MIRROR)
            path.unlink()


def replace_current_links_everywhere() -> None:
    replacements = {
        "https://zenodo.org/records/20441063": CURRENT["main"],
        "https://zenodo.org/records/20441732": CURRENT["main"],
        "https://zenodo.org/records/20443233": CURRENT["main"],
        "https://zenodo.org/records/20443965": CURRENT["main"],
        "https://zenodo.org/records/20446135": CURRENT["main"],
        "https://zenodo.org/records/20449972": CURRENT["main"],
        "https://zenodo.org/records/20450957": CURRENT["main"],
        "https://zenodo.org/records/20451281": CURRENT["main"],
        "https://zenodo.org/records/20440845": CURRENT["ega"],
        "https://zenodo.org/records/20443395": CURRENT["sga"],
        "https://zenodo.org/records/20436860": CURRENT["sga"],
        "https://zenodo.org/records/20446071": CURRENT["sga"],
        "https://zenodo.org/records/20443748": CURRENT["non_european"],
        "https://zenodo.org/records/20439960": CURRENT["non_european"],
        "https://zenodo.org/records/20441309": CURRENT["non_european"],
        "https://zenodo.org/records/20442084": CURRENT["non_european"],
        "https://zenodo.org/records/20445876": CURRENT["non_european"],
        "https://zenodo.org/records/20449340": CURRENT["non_european"],
        "https://zenodo.org/records/20443602": CURRENT["weber"],
        "https://zenodo.org/records/20440806": CURRENT["weber"],
        "https://zenodo.org/records/20441673": CURRENT["weber"],
        "https://zenodo.org/records/20445798": CURRENT["weber"],
        "https://zenodo.org/records/20443958": CURRENT["noether"],
        "https://zenodo.org/records/20440811": CURRENT["noether"],
        "https://zenodo.org/records/20441857": CURRENT["noether"],
        "https://zenodo.org/records/20444588": CURRENT["noether"],
        "https://zenodo.org/records/20443168": CURRENT["deligne"],
        "https://zenodo.org/records/20445997": CURRENT["deligne"],
        "https://zenodo.org/records/20441980": CURRENT["classical"],
        "https://zenodo.org/records/20441015": CURRENT["classical"],
        "https://zenodo.org/records/20441561": CURRENT["classical"],
        "https://zenodo.org/records/20444896": CURRENT["classical"],
        "https://zenodo.org/records/20451184": CURRENT["classical"],
        "https://zenodo.org/records/20480192": CURRENT["classical"],
        "https://zenodo.org/records/20416839": CURRENT["author_cluster"],
        "https://zenodo.org/records/20414959": CURRENT["deligne"],
        "20446135": "20450957",
        "20449972": "20450957",
        "20450957": "20451500",
        "20451281": "20451500",
        "20446071": "20450840",
        "20449849": "20450840",
        "20450413": "20450840",
        "20445876": "20450502",
        "20449340": "20450502",
        "20450052": "20450502",
        "20445798": "20450915",
        "20449951": "20450915",
        "20450465": "20450915",
        "20444588": "20450906",
        "20449931": "20450906",
        "20450451": "20450906",
        "20445997": "20450386",
        "20449788": "20450386",
        "20444896": "20451184",
        "20451184": "20451242",
        "10.5281/zenodo.20441063": "10.5281/zenodo.20450957",
        "10.5281/zenodo.20441732": "10.5281/zenodo.20450957",
        "10.5281/zenodo.20443233": "10.5281/zenodo.20450957",
        "10.5281/zenodo.20443965": "10.5281/zenodo.20450957",
        "10.5281/zenodo.20446135": "10.5281/zenodo.20450957",
        "10.5281/zenodo.20449972": "10.5281/zenodo.20450957",
        "10.5281/zenodo.20450957": "10.5281/zenodo.20451500",
        "10.5281/zenodo.20451281": "10.5281/zenodo.20451500",
        "10.5281/zenodo.20440845": "10.5281/zenodo.20444982",
        "10.5281/zenodo.20443395": "10.5281/zenodo.20450840",
        "10.5281/zenodo.20436860": "10.5281/zenodo.20450840",
        "10.5281/zenodo.20446071": "10.5281/zenodo.20450840",
        "10.5281/zenodo.20449849": "10.5281/zenodo.20450840",
        "10.5281/zenodo.20450413": "10.5281/zenodo.20450840",
        "10.5281/zenodo.20443748": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20439960": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20441309": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20442084": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20445876": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20449340": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20450052": "10.5281/zenodo.20450502",
        "10.5281/zenodo.20443602": "10.5281/zenodo.20450915",
        "10.5281/zenodo.20440806": "10.5281/zenodo.20450915",
        "10.5281/zenodo.20441673": "10.5281/zenodo.20450915",
        "10.5281/zenodo.20445798": "10.5281/zenodo.20450915",
        "10.5281/zenodo.20449951": "10.5281/zenodo.20450915",
        "10.5281/zenodo.20450465": "10.5281/zenodo.20450915",
        "10.5281/zenodo.20443958": "10.5281/zenodo.20450906",
        "10.5281/zenodo.20440811": "10.5281/zenodo.20450906",
        "10.5281/zenodo.20441857": "10.5281/zenodo.20450906",
        "10.5281/zenodo.20444588": "10.5281/zenodo.20450906",
        "10.5281/zenodo.20449931": "10.5281/zenodo.20450906",
        "10.5281/zenodo.20450451": "10.5281/zenodo.20450906",
        "10.5281/zenodo.20443168": "10.5281/zenodo.20450386",
        "10.5281/zenodo.20445997": "10.5281/zenodo.20450386",
        "10.5281/zenodo.20449788": "10.5281/zenodo.20450386",
        "10.5281/zenodo.20441015": "10.5281/zenodo.20451184",
        "10.5281/zenodo.20441561": "10.5281/zenodo.20451184",
        "10.5281/zenodo.20441980": "10.5281/zenodo.20451184",
        "10.5281/zenodo.20444896": "10.5281/zenodo.20451184",
        "10.5281/zenodo.20451184": "10.5281/zenodo.20451242",
        "10.5281/zenodo.20416839": "10.5281/zenodo.20442003",
        "10.5281/zenodo.20414959": "10.5281/zenodo.20445997",
    }
    version_to_concept = {
        # Main landing / combined preservation record.
        "20441063": "20393488",
        "20441732": "20393488",
        "20443233": "20393488",
        "20443965": "20393488",
        "20446135": "20393488",
        "20449972": "20393488",
        "20450957": "20393488",
        "20451281": "20393488",
        "20451500": "20393488",
        "20453131": "20393488",
        "20454357": "20393488",
        "20454593": "20393488",
        "20454827": "20393488",
        "20456732": "20393488",
        # EGA.
        "20440845": "20414353",
        "20444982": "20414353",
        "20453302": "20414353",
        "20454552": "20414353",
        # SGA.
        "20436860": "20410947",
        "20443395": "20410947",
        "20446071": "20410947",
        "20449849": "20410947",
        "20450413": "20410947",
        "20450840": "20410947",
        "20451805": "20410947",
        "20452103": "20410947",
        "20452911": "20410947",
        "20452958": "20410947",
        "20455791": "20410947",
        "20460126": "20410947",
        "20464007": "20410947",
        "20470330": "20410947",
        "20470664": "20410947",
        "20470972": "20410947",
        "20471111": "20410947",
        "20472389": "20410947",
        "20474076": "20410947",
        "20475076": "20410947",
        "20477337": "20410947",
        "20478073": "20410947",
        "20479892": "20410947",
        # Non-European / multilingual.
        "20435670": "20410957",
        "20435677": "20410957",
        "20435687": "20410957",
        "20435690": "20410957",
        "20439960": "20410957",
        "20441309": "20410957",
        "20442084": "20410957",
        "20443748": "20410957",
        "20445876": "20410957",
        "20449340": "20410957",
        "20450052": "20410957",
        "20450502": "20410957",
        "20451902": "20410957",
        "20452140": "20410957",
        "20452637": "20410957",
        "20453575": "20410957",
        "20455873": "20410957",
        "20460444": "20410957",
        "20463460": "20410957",
        "20470301": "20410957",
        "20470476": "20410957",
        "20472672": "20410957",
        "20473794": "20410957",
        "20476722": "20410957",
        "20477396": "20410957",
        "20478602": "20410957",
        # Weber.
        "20440806": "20412153",
        "20441673": "20412153",
        "20443602": "20412153",
        "20445798": "20412153",
        "20449951": "20412153",
        "20450465": "20412153",
        "20450915": "20412153",
        "20451876": "20412153",
        "20452099": "20412153",
        "20452496": "20412153",
        "20452986": "20412153",
        "20453523": "20412153",
        "20455748": "20412153",
        "20470313": "20412153",
        "20470638": "20412153",
        "20472571": "20412153",
        "20472661": "20412153",
        "20473075": "20412153",
        "20474126": "20412153",
        "20474643": "20412153",
        "20474973": "20412153",
        "20476405": "20412153",
        "20476902": "20412153",
        "20477287": "20412153",
        "20478037": "20412153",
        "20479833": "20412153",
        # Noether.
        "20440811": "20412587",
        "20441857": "20412587",
        "20443958": "20412587",
        "20444588": "20412587",
        "20449931": "20412587",
        "20450451": "20412587",
        "20450906": "20412587",
        "20451859": "20412587",
        "20452095": "20412587",
        "20452437": "20412587",
        "20452979": "20412587",
        "20453511": "20412587",
        "20455701": "20412587",
        "20459983": "20412587",
        "20463939": "20412587",
        "20470300": "20412587",
        "20470623": "20412587",
        "20470931": "20412587",
        "20472554": "20412587",
        "20472651": "20412587",
        "20474233": "20412587",
        "20474614": "20412587",
        "20475009": "20412587",
        "20476442": "20412587",
        "20477217": "20412587",
        "20477990": "20412587",
        "20479732": "20412587",
        # Deligne.
        "20414959": "20410853",
        "20443168": "20410853",
        "20445997": "20410853",
        "20449788": "20410853",
        "20450386": "20410853",
        "20453026": "20410853",
        "20453551": "20410853",
        "20458935": "20410853",
        "20464181": "20410853",
        "20470354": "20410853",
        "20472591": "20410853",
        "20472720": "20410853",
        "20479243": "20410853",
        "20480092": "20410853",
        # Classical / Cayley-Dedekind-Dirichlet shelf.
        "20441015": "20414787",
        "20441561": "20414787",
        "20441980": "20414787",
        "20444896": "20414787",
        "20451184": "20414787",
        "20451242": "20414787",
        "20451700": "20414787",
        "20454226": "20414787",
        "20476969": "20414787",
        "20477601": "20414787",
        "20480192": "20414787",
        # Additional author cluster, Gauss, Riemann.
        "20416839": "20411006",
        "20442003": "20411006",
        "20444827": "20410934",
        "20453354": "20410934",
        "20454309": "20410934",
        "20434317": "20429778",
    }
    for version, concept in version_to_concept.items():
        replacements[f"https://zenodo.org/records/{version}"] = f"https://zenodo.org/records/{concept}"
        replacements[f"10.5281/zenodo.{version}"] = f"10.5281/zenodo.{concept}"
        replacements[version] = concept
    for folder in [MIRROR, MIRROR / "manifests", MIRROR / "zenodo-metadata"]:
        for path in folder.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".md", ".json", ".csv", ".cff", ".txt", ".tex"}:
                try:
                    text = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    continue
                new = text
                for old, replacement in replacements.items():
                    new = new.replace(old, replacement)
                if new != text:
                    path.write_text(new, encoding="utf-8")


def sanitize_public_text_surface() -> None:
    replacements = {
        "Pass-2 compatibility shim inserted by ChatGPT, 2026-05-25": "Pass-2 compatibility shim inserted during review, 2026-05-25",
        "ChatGPT": "review system",
        "Claude (Opus 4.7)": "independent review pass",
        "Claude": "review system",
        "Kimi": "transcription system",
        "handoff packet": "source packet",
        "handoff": "source packet",
        "cleanup pass": "editorial pass",
        "cleanup": "repair",
        "Cleanup": "Repair",
        "project maintainer": "project maintainer",
        "C:\\Users\\project maintainer": "local workspace",
        "batch/package commentary": "package commentary",
    }
    for path in MIRROR.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".md", ".json", ".csv", ".cff", ".txt", ".tex"}:
            continue
        try:
            relative = path.relative_to(MIRROR)
        except ValueError:
            relative = path
        if relative.parts and relative.parts[0] == "workflow":
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        new = text
        for old, replacement in replacements.items():
            new = new.replace(old, replacement)
        if new != text:
            path.write_text(new, encoding="utf-8")


def scrub_public_local_paths_and_private_planning() -> None:
    text_suffixes = {".md", ".json", ".csv", ".cff", ".txt", ".tex"}
    phrase_replacements = {
        "Pandoc for Markdown-to-DOCX/PDF conversion of proposal, workflow, and prompt-provenance packets.": (
            "Pandoc for Markdown-to-DOCX/PDF conversion of workflow and provenance packets."
        ),
        "Grant-planning conservative multiplier:": "Conservative production multiplier:",
    }
    path_patterns = [
        re.compile(r"C:\\Users\\(?:project maintainer|project maintainer)\\[^\"'\r\n,]*"),
        re.compile(r"C:/Users/(?:project maintainer|project maintainer)/[^\"'<>\s\r\n,)]*"),
        re.compile(r"C:\\\\Users\\\\(?:project maintainer|project maintainer)\\\\[^\"'\r\n,]*"),
        re.compile(r"C:/Users/(?:project maintainer|project maintainer)/[^\"'<>\s\r\n,)]*"),
    ]

    def scrub_json_value(value):
        if isinstance(value, dict):
            scrubbed = {}
            for key, child in value.items():
                if key in {"stdout_tail", "stderr_tail"}:
                    scrubbed[key] = "[build log omitted from public mirror]"
                elif key in {"source_upload", "local_source", "source_dir"}:
                    scrubbed[key] = "local workspace path"
                else:
                    scrubbed[key] = scrub_json_value(child)
            return scrubbed
        if isinstance(value, list):
            return [scrub_json_value(child) for child in value]
        if isinstance(value, str):
            new_value = value
            for pattern in path_patterns:
                new_value = pattern.sub("local workspace path", new_value)
            return new_value
        return value

    for path in MIRROR.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        if path.suffix.lower() == ".json":
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                pass
            else:
                scrubbed = scrub_json_value(data)
                if scrubbed != data:
                    path.write_text(json.dumps(scrubbed, indent=2, ensure_ascii=False), encoding="utf-8")
                continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        new = text
        for old, replacement in phrase_replacements.items():
            new = new.replace(old, replacement)
        for pattern in path_patterns:
            new = pattern.sub("local workspace path", new)
        if new != text:
            path.write_text(new, encoding="utf-8")


def main() -> None:
    if not (MIRROR / ".git").exists():
        raise RuntimeError(f"Mirror repo not found: {MIRROR}")

    manifest: dict[str, object] = {
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "current_records": CURRENT,
        "records": {},
    }

    for key, config in RECORDS.items():
        upload = config["upload"]
        if not upload.exists():
            raise RuntimeError(f"Missing upload dir for {key}: {upload}")
        record: dict[str, object] = {}
        record["reader_pdfs"] = copy_public_pdfs(upload, config["reader"])

        source_dir: Path = config["source"]
        if config["replace_source"]:
            reset_dir(source_dir)
        else:
            source_dir.mkdir(parents=True, exist_ok=True)

        extracted = []
        for zip_name, subdir in config["source_zips"]:
            zip_path = upload / zip_name
            if not zip_path.exists():
                raise RuntimeError(f"Missing source ZIP for {key}: {zip_path}")
            dest = source_dir / subdir if subdir else source_dir
            if subdir:
                reset_dir(dest)
            extracted.append(safe_extract(zip_path, dest))
        record["source_extracts"] = extracted

        summary = copy_if_exists(upload / config["summary"], MIRROR / "manifests" / config["summary"])
        if summary:
            record["summary"] = summary
        metadata = copy_if_exists(config["metadata"], MIRROR / "zenodo-metadata" / config["metadata"].name)
        if metadata:
            record["metadata"] = metadata
        manifest["records"][key] = record

    copy_if_exists(
        ZENODO / "metadata_main_landing_current_after_author_refresh.json",
        MIRROR / "zenodo-metadata" / "metadata_main_landing_current_after_author_refresh.json",
    )

    workflow_dir = MIRROR / "workflow"
    reset_dir(workflow_dir)
    workflow_files = []
    for name in [
        "Project Workflow and Replication Notes.md",
        "Project Workflow and Replication Notes.pdf",
        "Workflow Replication Packet - Scripts, Tooling Notes, and Manifests.zip",
    ]:
        copied = copy_if_exists(WORKFLOW_PACKET / name, workflow_dir / name)
        if copied:
            workflow_files.append(copied)
    auxiliary_workflow_sources = [
        (
            RELEASES
            / "additional_assistance_packets_current"
            / "non_eu_web_fix_todo_packet_20260531_230639",
            workflow_dir / "audits" / "non-european-public-surface-current",
        ),
        (
            RELEASES
            / "additional_assistance_packets_current"
            / "cayley_current_source_checked_slice_coverage_20260531",
            workflow_dir / "audits" / "cayley-current-coverage-20260531",
        ),
        (
            RELEASES
            / "additional_assistance_packets_current"
            / "persian_iranian_mathematics_source_intake_20260531",
            workflow_dir / "source-intake" / "persian-iranian-mathematics",
        ),
    ]
    for source_dir, target_dir in auxiliary_workflow_sources:
        if not source_dir.exists():
            continue
        reset_dir(target_dir)
        for source in sorted(source_dir.rglob("*")):
            if not source.is_file():
                continue
            if source.name == "SHA256SUMS.txt" or "downloaded_sources" in source.parts or "qa_pages" in source.parts:
                continue
            target = target_dir / source.relative_to(source_dir)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            workflow_files.append(
                {
                    "path": str(target.relative_to(MIRROR)).replace("\\", "/"),
                    "bytes": target.stat().st_size,
                }
            )
    manifest["workflow"] = {
        "zenodo": CURRENT["workflow"],
        "files": workflow_files,
    }

    replacements = {
        "https://zenodo.org/records/20441063": CURRENT["main"],
        "https://zenodo.org/records/20441732": CURRENT["main"],
        "https://zenodo.org/records/20443233": CURRENT["main"],
        "https://zenodo.org/records/20443965": CURRENT["main"],
        "https://zenodo.org/records/20446135": CURRENT["main"],
        "https://zenodo.org/records/20449972": CURRENT["main"],
        "https://zenodo.org/records/20450957": CURRENT["main"],
        "https://zenodo.org/records/20451281": CURRENT["main"],
        "https://zenodo.org/records/20436860": CURRENT["sga"],
        "https://zenodo.org/records/20446071": CURRENT["sga"],
        "https://zenodo.org/records/20439960": CURRENT["non_european"],
        "https://zenodo.org/records/20441309": CURRENT["non_european"],
        "https://zenodo.org/records/20442084": CURRENT["non_european"],
        "https://zenodo.org/records/20445876": CURRENT["non_european"],
        "https://zenodo.org/records/20449340": CURRENT["non_european"],
        "https://zenodo.org/records/20440806": CURRENT["weber"],
        "https://zenodo.org/records/20441673": CURRENT["weber"],
        "https://zenodo.org/records/20445798": CURRENT["weber"],
        "https://zenodo.org/records/20440811": CURRENT["noether"],
        "https://zenodo.org/records/20441857": CURRENT["noether"],
        "https://zenodo.org/records/20444588": CURRENT["noether"],
        "https://zenodo.org/records/20441015": CURRENT["classical"],
        "https://zenodo.org/records/20441561": CURRENT["classical"],
        "https://zenodo.org/records/20444896": CURRENT["classical"],
        "https://zenodo.org/records/20451184": CURRENT["classical"],
        "https://zenodo.org/records/20480192": CURRENT["classical"],
        "https://zenodo.org/records/20416839": CURRENT["author_cluster"],
        "https://zenodo.org/records/20445997": CURRENT["deligne"],
        "https://zenodo.org/records/20414959": CURRENT["deligne"],
        "20446135": "20450957",
        "20449972": "20450957",
        "20450957": "20451500",
        "20451281": "20451500",
        "20446071": "20450840",
        "20449849": "20450840",
        "20450413": "20450840",
        "20445876": "20450502",
        "20449340": "20450502",
        "20450052": "20450502",
        "20445798": "20450915",
        "20449951": "20450915",
        "20450465": "20450915",
        "20444588": "20450906",
        "20449931": "20450906",
        "20450451": "20450906",
        "20445997": "20450386",
        "20449788": "20450386",
        "20444896": "20451184",
        "20451184": "20451242",
        "through section 175": "through supplementary matter",
        "through section 194": "through supplementary matter",
        "clean English translation batches 01-10": "current unchecked English translation/summary drafts plus paper-level restart material",
        "Volume II through section 175": "Volume II through supplementary matter",
        "Volume II through section 194": "Volume II through supplementary matter",
        "complete SGA 5 Expose I supplement": "SGA 5 source-checked edition through the opening of Expose VII",
        "SGA 5 Expose I source/translation supplement": "SGA 5 source-checked edition through the opening of Expose VII",
        "SGA 5 strict restart source/translation supplement through Expose III bibliography": "SGA 5 source-checked edition through the opening of Expose VII",
        "source-checkable SGA 5 strict restart through Expose III bibliography": "source-checkable SGA 5 edition through the opening of Expose VII",
        "a strict SGA 5 restart source/translation supplement through Expose III bibliography": "a source-checkable SGA 5 edition through the opening of Expose VII",
        "SGA 1-3 snapshots": "SGA 1-2 snapshots, a cleaned SGA 3 rebuild",
        "strict SGA 5 strict restart": "source-checkable SGA 5 edition",
        "strict SGA 5 restart": "source-checkable SGA 5 edition",
        "Strict Restart": "Source-Checked Edition",
        "literal repair supplements for sections 176-194": "paired literal repair readers through supplementary matter",
        "Weber includes Volume II English translation through supplementary matter plus paired literal repair readers through supplementary matter": "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I through section 46, Volume II sections 176-end matter, and Volume III sections 1-100",
        "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for the Volume II tail and Volume III sections 1-37": "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I through section 46, Volume II sections 176-end matter, and Volume III sections 1-100",
        "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for the Volume II tail and Volume III sections 1-45": "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I through section 46, Volume II sections 176-end matter, and Volume III sections 1-100",
        "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for the Volume II tail and Volume III sections 1-65": "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I through section 46, Volume II sections 176-end matter, and Volume III sections 1-100",
        "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for the Volume II tail and Volume III sections 1-69": "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I through section 46, Volume II sections 176-end matter, and Volume III sections 1-100",
        "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I introduction through section 8, Volume II sections 176-202, and Volume III sections 1-78": "Weber includes broad older English translation drafts plus current paired high-fidelity German/English readers for Volume I through section 46, Volume II sections 176-end matter, and Volume III sections 1-100",
        "Volume III sections 1-65": "Volume III sections 1-100",
        "Noether includes the older cumulative translation/summary draft plus newer paper-level high-fidelity restart files": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Paper 09 section 4": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "stricter work-level public surface of 35 reader PDFs": "stricter work-level public surface of 30 reader PDFs plus guide",
        "stricter work-level public surface of 30 reader PDFs plus guide": "stricter work-level public surface of 40 reader PDFs plus guide",
        "through Expose X page 382": "complete through printed page 484",
        "through complete Expose X page 406": "complete through printed page 484",
        "through Expose XV page 450": "complete through printed page 484",
        "through Expose XV page 461": "complete through printed page 484",
        "Current source-checkable SGA 5 material is through Expose X page 382": "Current source-checkable SGA 5 material is complete through printed page 484",
        "Current source-checkable SGA 5 material is through complete Expose X page 406": "Current source-checkable SGA 5 material is complete through printed page 484",
        "Current source-checkable SGA 5 material is through Expose XII page 438": "Current source-checkable SGA 5 material is complete through printed page 484",
        "Current source-checkable SGA 5 material is through Expose XV page 450": "Current source-checkable SGA 5 material is complete through printed page 484",
        "Current source-checkable SGA 5 material is through Expose XV page 461": "Current source-checkable SGA 5 material is complete through printed page 484",
        "through Expose XII completion plus Expose XV opening, printed page 450": "complete through printed page 484",
        "through Expose XII completion and Expose XV opening, printed page 450": "complete through printed page 484",
        "through Expose XV, printed page 461": "complete through printed page 484",
        "paired German/English paper-level cumulative readers through Paper 15": "paired German/English paper-level cumulative readers through Papers 1-31 and Paper 31 section 2",
        "through paper 15": "through Papers 1-31 and Paper 31 section 2",
        "through Paper 15": "through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Paper 15": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Paper 16": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Paper 16 and Paper 17 through section 4": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Paper 16 and Paper 17 through section 9": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Papers 1-18 complete": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Papers 1-19 complete": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Papers 1-21 complete": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "The current cumulative paper-level pair runs through Papers 1-22 complete": "The current cumulative paper-level pair runs through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Paper 15": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Paper 16": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Paper 16 and Paper 17 through section 4": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Paper 16 and Paper 17 through section 9": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Papers 1-18 complete": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Papers 1-19 complete": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Papers 1-21 complete": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "Noether includes the older cumulative translation/summary draft plus paper-level high-fidelity German/English readers through Papers 1-22 complete": "Noether includes paper-level high-fidelity German/English readers through Papers 1-31 and Paper 31 section 2",
        "through Paper 16 and Paper 17 through section 4 and Paper 17 through section 4": "through Papers 1-31 and Paper 31 section 2",
        "through Paper 16 and Paper 17 through section 9": "through Papers 1-31 and Paper 31 section 2",
        "through Paper 16 and Paper 17 through Section 9": "through Papers 1-31 and Paper 31 section 2",
        "through Paper 16 plus Paper 17 through Section 9": "through Papers 1-31 and Paper 31 section 2",
        "through Papers 1-18 complete and Paper 17 through section 9": "through Papers 1-31 and Paper 31 section 2",
        "through Papers 1-18 complete and Paper 17 through Section 9": "through Papers 1-31 and Paper 31 section 2",
        "through Papers 1-19 complete": "through Papers 1-31 and Paper 31 section 2",
        "through Papers 1-22 complete": "through Papers 1-31 and Paper 31 section 2",
        "Volume III sections 1-69": "Volume III sections 1-100",
        "Volume III sections 1-72": "Volume III sections 1-100",
        "Volume III sections 1-76": "Volume III sections 1-100",
        "Volume III sections 1-78": "Volume III sections 1-100",
        "Volume III section 69": "Volume III section 100",
        "Volume III section 70": "Volume III section 100",
        "Volume III section 76": "Volume III section 100",
        "Volume III section 78": "Volume III section 100",
        "Deligne includes a complete bilingual working package for Paper 32 and source-grounded rebuild material for the active paper-level repair set": "Deligne includes cumulative English/French working readers for the touched paper set, individual English paper PDFs, a separate Deligne-to-Illusie III letter item, and source artifacts",
        "including a complete bilingual working package for Paper 32, *The Weil Conjecture II*, and source-grounded rebuild material for papers 32, 42, 45, 56, 57, 58, 69, 70, 71, 83, 84, 85, 87, and 88": "including cumulative English/French working readers for touched papers, individual English paper PDFs, a separate Deligne-to-Illusie III letter item, and TeX/source artifacts for papers 32, 42, 45, 56, 57, 58, 69, 70, 71, 83, 84, 85, 87, and 88",
    }
    version_to_concept = {
        "20451500": "20393488",
        "20453131": "20393488",
        "20454357": "20393488",
        "20454593": "20393488",
        "20454827": "20393488",
        "20456732": "20393488",
        "20444982": "20414353",
        "20453302": "20414353",
        "20454552": "20414353",
        "20452103": "20410947",
        "20452958": "20410947",
        "20455791": "20410947",
        "20460126": "20410947",
        "20464007": "20410947",
        "20470330": "20410947",
        "20470664": "20410947",
        "20470972": "20410947",
        "20471111": "20410947",
        "20472389": "20410947",
        "20474076": "20410947",
        "20475076": "20410947",
        "20477337": "20410947",
        "20478073": "20410947",
        "20479892": "20410947",
        "20452140": "20410957",
        "20452637": "20410957",
        "20453575": "20410957",
        "20455873": "20410957",
        "20460444": "20410957",
        "20463460": "20410957",
        "20470301": "20410957",
        "20470476": "20410957",
        "20472672": "20410957",
        "20473794": "20410957",
        "20476722": "20410957",
        "20477396": "20410957",
        "20478602": "20410957",
        "20452099": "20412153",
        "20452986": "20412153",
        "20453523": "20412153",
        "20455748": "20412153",
        "20470313": "20412153",
        "20470638": "20412153",
        "20472571": "20412153",
        "20472661": "20412153",
        "20473075": "20412153",
        "20474126": "20412153",
        "20474643": "20412153",
        "20474973": "20412153",
        "20476405": "20412153",
        "20476902": "20412153",
        "20477287": "20412153",
        "20478037": "20412153",
        "20479833": "20412153",
        "20452095": "20412587",
        "20452979": "20412587",
        "20453511": "20412587",
        "20455701": "20412587",
        "20459983": "20412587",
        "20463939": "20412587",
        "20470300": "20412587",
        "20470623": "20412587",
        "20470931": "20412587",
        "20472554": "20412587",
        "20472651": "20412587",
        "20474233": "20412587",
        "20474614": "20412587",
        "20475009": "20412587",
        "20476442": "20412587",
        "20477217": "20412587",
        "20477990": "20412587",
        "20479732": "20412587",
        "20450386": "20410853",
        "20453026": "20410853",
        "20453551": "20410853",
        "20458935": "20410853",
        "20464181": "20410853",
        "20470354": "20410853",
        "20472591": "20410853",
        "20472720": "20410853",
        "20479243": "20410853",
        "20480092": "20410853",
        "20451700": "20414787",
        "20454226": "20414787",
        "20476969": "20414787",
        "20477601": "20414787",
        "20480192": "20414787",
        "20442003": "20411006",
        "20444827": "20410934",
        "20453354": "20410934",
        "20454309": "20410934",
        "20434317": "20429778",
    }
    for version, concept in version_to_concept.items():
        replacements[f"https://zenodo.org/records/{version}"] = f"https://zenodo.org/records/{concept}"
        replacements[f"10.5281/zenodo.{version}"] = f"10.5281/zenodo.{concept}"
        replacements[version] = concept
    update_public_text_files(replacements)

    write_status_files(manifest)
    cleanup_public_surface()
    replace_current_links_everywhere()
    sanitize_public_text_surface()
    scrub_public_local_paths_and_private_planning()

    print(json.dumps({
        "mirror": str(MIRROR),
        "records_synced": sorted(RECORDS),
        "main_record": CURRENT["main"],
    }, indent=2))


if __name__ == "__main__":
    main()



