# Math OCR Tooling Status for Repair Agents

Generated: 2026-05-30

This note records the current local state of OCR/math-OCR tooling for the manuscript modernization workflow. It is meant for future local agents and contributors, not as a claim that any OCR output is authoritative.

## Bottom Line

The useful current workflow is still:

`scan or rendered page -> OCR/formula witness -> TeX candidate -> compiled PDF -> visual/text audit -> source check`

No local open-source OCR tool tested here is reliable enough to replace source checking for historical mathematical text. The tools are useful for witnesses, triage, and line/block extraction.

## Local Tools Found

System-level tools:

- Python 3.13 via Miniconda and Python.org installs.
- MiKTeX `pdftotext.exe`.
- ImageMagick `magick.exe`.
- MuPDF `mutool.exe`.
- Tesseract was not found on PATH.
- Ghostscript executable was not found on PATH.
- Docker was not found on PATH.

Python environments:

- `.venv_ocr`: Docling, RapidOCR, PyTorch, Transformers.
- `.venv_formula_ocr`: PyTorch, Transformers, Surya OCR, pix2tex / LaTeX-OCR.
- `LOCAL_USER_HOME\Documents\CLAUDE PLEASE DONT DELETE WINDOWS 32\ocr_env`: Claude-side OCR environment with Marker, Surya, pix2tex, Transformers, and related models.

## Smoke-Test Results

### Docling + RapidOCR

Prior local benchmark output:

- `manuscript_translation_project/ocr_bench/outputs/docling_rapidocr_standard/rapidocr_standard_results.json`

Observed:

- EGA dense page: completed in about 70 seconds, 4,494 markdown characters. Text was useful as a witness but had spacing and symbol errors.
- SGA 5 scan page: completed in about 12 seconds, 965 markdown characters. Useful rough French OCR witness.
- Sanskrit math page: completed in about 10 seconds, only 13 markdown characters. Not useful for that non-Latin sample.

Use: page-level witness text for Latin-script mathematical prose. Do not trust formulas or non-Latin scripts without source/visual checking.

### pix2tex / LaTeX-OCR

Local command tested:

```powershell
.\.venv_formula_ocr\Scripts\pix2tex.exe --no-cuda manuscript_translation_project\ocr_bench\samples\sanskrit_math_page.png
```

Also tested against a cropped EGA formula/text region.

Observed:

- Runs on CPU.
- Model checkpoints were already available or auto-loaded successfully.
- Full-page and mixed text/math crops produced unusable LaTeX-like garbage.
- This is expected: pix2tex is designed for isolated formula images, not full pages.

Use: only as an optional witness for tightly cropped, isolated formulas. Do not feed it full manuscript pages or mixed theorem paragraphs.

### Surya OCR

Local command tested:

```powershell
.\.venv_formula_ocr\Scripts\surya_ocr.exe manuscript_translation_project\ocr_bench\samples\sga5_scan_page.png --output_dir manuscript_translation_project\ocr_bench\outputs\surya_ocr_smoke_20260530 --page_range 0
```

Observed:

- The installed Surya CLI is the newer VLM/server-backed path.
- It failed locally because Docker is not installed and no `llama-server` backend was configured.
- Error summary: Surya attempted to spawn the vLLM backend and could not find Docker.

Use: promising candidate for future layout/OCR/table work, but this machine needs Docker plus NVIDIA container support, or a configured `llama.cpp` `llama-server`, before Surya v2 can run locally.

### Claude OCR Test Output

Claude-side OCR outputs exist under:

- `LOCAL_USER_HOME\Documents\CLAUDE PLEASE DONT DELETE WINDOWS 32\CLAUDE_OUTPUTS\ocr_tests`

Notable file:

- `ega4_math_output/ega4-2_pages5-7/ega4-2_pages5-7.md`

Observed:

- The sample is a plausible OCR/linearization witness for EGA-style French mathematical prose with formulas.
- It is useful as source material for an LLM repair pass, but must still be checked against scans.

## Open-Source Candidates to Track

- pix2tex / LaTeX-OCR: formula-image to LaTeX, best suited to cropped equations.
- Surya: OCR, layout, reading order, and table recognition; current v2 needs an inference backend such as vLLM/Docker or llama.cpp.
- Docling: document conversion / parsing pipeline; already useful locally with RapidOCR for rough witnesses.
- Pix2Text: combined layout, table, text, and math-formula OCR to Markdown; not yet installed here, worth testing next.
- olmOCR: PDF linearization toolkit for LLM dataset/training style extraction; not installed here, worth testing on EGA/SGA-style PDFs.

## Recommended Next Experiments

1. Install or configure one Surya backend:
   - Docker Desktop + NVIDIA Container Toolkit if GPU is available; or
   - `llama.cpp` `llama-server` for CPU/local backend.
2. Install Pix2Text in a separate environment and test:
   - one EGA/SGA scanned page;
   - one table-heavy al-Battani page;
   - one Sanskrit/Arabic/Chinese mathematical page.
3. Install/test olmOCR on PDF slices and compare its markdown against Docling/RapidOCR.
4. Build a small OCR benchmark harness that stores:
   - source image/PDF path;
   - command used;
   - runtime;
   - output markdown/text;
   - screenshots/contact sheets;
   - verdict: useful witness, unusable, or needs backend.
5. For formula OCR, first crop formulas using source-page coordinates or layout detection; then pass only the formula crop to pix2tex/Pix2Text.

## Publication/Provenance Note

When OCR-derived text is used in public artifacts, record the tool/environment in source ZIP manifests. Do not put tool names in reader-facing public titles unless the tool itself is the subject of the record.
