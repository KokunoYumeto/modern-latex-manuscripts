# Tooling Notes

Minimum useful stack:

- PowerShell
- Python 3.11+
- PyMuPDF
- a TeX distribution such as MiKTeX or TeX Live
- Git
- Zenodo API token

Useful optional OCR stack:

- Docling + RapidOCR: useful rough witnesses for Latin-script/French mathematical prose; not reliable for formulas or non-Latin pages without checking.
- pix2tex / LaTeX-OCR: installed and CPU-runnable, but only useful for isolated formula crops; full pages and mixed text/math regions produced garbage in smoke tests.
- Surya OCR: installed, but current local Surya v2 use is backend-blocked until Docker/vLLM or llama.cpp server support is configured.
- Pix2Text and olmOCR: worth testing next for mixed layout/text/math/table extraction.
- Marker: present in one local OCR environment and worth keeping in the tool inventory.
- PyTorch with CUDA if available.

Current workstation snapshot: MiKTeX `pdftotext`, ImageMagick `magick`, and MuPDF `mutool` are available. Tesseract, Ghostscript, and Docker were not found on PATH during the latest audit.

The OCR stack should be treated as a witness generator. Mathematical correctness still comes from comparison with scans, successful TeX compilation, and human or model-assisted audit. Record OCR tools in source ZIP manifests when their output materially influences a public TeX file.
