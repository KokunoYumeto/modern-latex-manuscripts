# Publication and Curation Policy

- Publish logical records by author, corpus, or coherent project cluster.
- Use new Zenodo versions for updates instead of spawning many duplicate records.
- Put stable all-version DOI links in GitHub documentation.
- Keep direct top-level PDFs reader-facing.
- Keep TeX, scans, logs, provenance, superseded drafts, and raw model outputs inside ZIP artifacts.
- Do not name public records after internal batches or model sessions.
- Keep a complete source trail so future contributors can verify the modern TeX against original scans.
- When a cleaner replacement appears, promote it, but keep older drafts in artifacts until the replacement has clearly superseded them.
