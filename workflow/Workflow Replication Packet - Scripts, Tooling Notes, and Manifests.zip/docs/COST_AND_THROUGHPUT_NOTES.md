# Informal Cost and Throughput Notes

These notes are project observations, not formal benchmarks.

- Large language model transcription is now useful enough to attack thousand-page corpora, but verification remains the limiting discipline.
- Parallel web sessions are effective for steady translation and repair.
- Local coding agents are especially useful for packaging, compiling, indexing, and repetitive audit loops.
- The expensive part is not only transcription: high-quality cleanup, page completeness checks, and public-facing organization consume substantial compute.
- A practical workflow should preserve rough outputs while clearly marking what is reader-facing.
