# Workflow Replication Packet

This ZIP contains a sanitized, portable snapshot of scripts, templates, and notes used in the manuscript modernization workflow.

The scripts are examples, not a turnkey installer. They preserve the important structure: inventory, chunk, compile, audit, stage, publish, and mirror. Replace `LOCAL_USER_HOME`, local source paths, Zenodo record IDs, and GitHub repository URLs with your own values before use.

Recommended first read order:

1. `docs/WORKFLOW_STEPS.md`
2. `docs/TOOLING.md`
3. `docs/PUBLICATION_POLICY.md`
4. `docs/COST_AND_THROUGHPUT_NOTES.md`
5. `scripts/`

The public archive should always prefer clean reader PDFs as direct files and preserve rough or raw material in ZIP artifacts.
