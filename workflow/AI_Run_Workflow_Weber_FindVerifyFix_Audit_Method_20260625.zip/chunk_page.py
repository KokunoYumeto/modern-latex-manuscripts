"""Render a PRINTED Weber Lehrbuch page as overlapping high-dpi chunks for the audit.

Modeled on the SGA5 chunk_page.py. Weber has THREE volumes with different source PDFs
and different printed->PDF offsets, so you must say which volume.
Offsets (pdf_page_1based = printed + offset): vol1=26, vol2=22, vol3=22.
These plus the source PDFs are read straight from audit_manifest.json so this script and
the manifest can never disagree.

Usage:
  python chunk_page.py VOL PRINTED [PRINTED ...]        # 3 chunks each (top/mid/bot)
  python chunk_page.py VOL PRINTED --chunks N           # N chunks
  python chunk_page.py VOL PRINTED --full               # whole page, one image
    VOL is one of: vol1 vol2 vol3   (or 1 / 2 / 3)

Renders at 600 dpi then downsamples each chunk to <=2400px wide (legible, native scan
detail kept; native IA scan is ~2500px so this is near-native enlargement -- the "zoom"
with no real detail lost). Does NOT mass-render: only the pages you name.
"""
import sys, os, json
import fitz
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
MANIFEST = os.path.join(HERE, "audit_manifest.json")
OUT = os.path.join(HERE, "src")
os.makedirs(OUT, exist_ok=True)

_m = json.load(open(MANIFEST, encoding="utf-8"))
# per-volume source pdf + offset, taken from the manifest
VOL = {}
for u in _m["units"]:
    VOL.setdefault(u["volume"], {"pdf": u["source_pdf"],
                                 "offset": u["pdf_page"] - u["printed_page"]})


def norm_vol(s):
    s = s.lower()
    if s in VOL:
        return s
    if s in ("1", "2", "3"):
        return "vol" + s
    raise SystemExit(f"unknown volume {s!r}; choose from {sorted(VOL)}")


args = sys.argv[1:]
if not args:
    raise SystemExit(__doc__)
vol = norm_vol(args[0])
args = args[1:]
pages, nchunks, full = [], 3, False
i = 0
while i < len(args):
    a = args[i]
    if a == "--chunks":
        nchunks = int(args[i + 1]); i += 2
    elif a == "--full":
        full = True; i += 1
    else:
        pages.append(int(a)); i += 1

pdf_path = VOL[vol]["pdf"]
offset = VOL[vol]["offset"]
d = fitz.open(pdf_path)
print(f"# {vol}  pdf={os.path.basename(pdf_path)}  offset={offset}  (pdf_page = printed + {offset})")

for printed in pages:
    pidx = printed + offset - 1   # 0-based PDF index
    if pidx < 0 or pidx >= d.page_count:
        print(f"printed {printed}: out of range (pdf has {d.page_count} pages)"); continue
    pg = d[pidx]
    pm = pg.get_pixmap(dpi=600, colorspace=fitz.csGRAY)
    full_im = Image.frombytes("L", (pm.width, pm.height), pm.samples)
    W, H = full_im.size
    if full:
        im = full_im
        if im.width > 2400:
            im = im.resize((2400, int(im.height * 2400 / im.width)), Image.LANCZOS)
        fp = os.path.join(OUT, f"{vol}_p{printed:03d}_full.png")
        im.save(fp, optimize=True)
        print(fp, im.size); continue
    ov = int(H * 0.04)  # overlap so nothing falls on a seam
    band = H // nchunks
    names = ["top", "mid", "bot"] if nchunks == 3 else [f"c{k+1}" for k in range(nchunks)]
    for k in range(nchunks):
        y0 = max(0, k * band - ov)
        y1 = min(H, (k + 1) * band + ov)
        ch = full_im.crop((0, y0, W, y1))
        if ch.width > 2400:
            ch = ch.resize((2400, int(ch.height * 2400 / ch.width)), Image.LANCZOS)
        nm = names[k] if k < len(names) else "c" + str(k + 1)
        fp = os.path.join(OUT, f"{vol}_p{printed:03d}_{nm}.png")
        ch.save(fp, optimize=True)
        print(fp, ch.size)
