"""Build the Weber Lehrbuch der Algebra audit manifest.

One unit per printed page that is covered by BOTH a transcribed cumulative German
.tex AND a verified high-DPI source scan. Output: audit_manifest.json next to this file.

Design notes (see HARNESS_README.md for full rationale):
- Canonical German source .tex = the latest B139 cumulative set (Jun 13-14 2026):
    v1/ge/weber_v1_ge.tex, v2/ge/weber_v2_ge.tex, v3/ge/weber_v3_ge.tex
  These are CONTINUOUS PROSE with no per-page or per-section line markers, so
  tex_line_hint is a LINEAR INTERPOLATION across the volume body (begin..end of the
  document body mapped onto printed_start..printed_end). It locates the right screen,
  not the exact line -- treat it as a starting cursor, then search nearby for the
  page's opening words from the scan.
- Source scans = the Internet-Archive *weberich / *webe_0 PDFs (~500 dpi, uniform
  across all three volumes; highest consistent resolution on disk).
- printed -> pdf offsets were verified by reading running-head folios at many depths.
Re-run any time the cumulative tex changes; it reflects the current files.
"""
import json, os

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "audit_manifest.json")

CUM = (r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean"
       r"\Weber restart\Weber_B139_heuristic_fix\Weber_B139_heuristic_fix\02_cumulative")
SCAN = r"C:\Users\Floris\Documents\Papors\OS\Lehrbuch der Algebra"

# Per volume:
#  tex            : canonical German cumulative source
#  tex_body_start : first line of document body  (begin{document}+ a few)
#  tex_body_end   : last body line
#  source_pdf     : verified scan
#  offset         : pdf_page_1based = printed_page + offset
#  printed_start  : first printed page of the audit-ready body span
#  printed_end    : last printed page of the audit-ready body span (offset stays clean)
VOLUMES = {
    "vol1": {
        "tex": os.path.join(CUM, "v1", "ge", "weber_v1_ge.tex"),
        "tex_body_start": 157,
        "tex_body_end": 20728,
        "source_pdf": os.path.join(SCAN, "lehrbuchderalgeb01weberich.pdf"),
        "offset": 26,
        "printed_start": 1,
        "printed_end": 648,
    },
    "vol2": {
        "tex": os.path.join(CUM, "v2", "ge", "weber_v2_ge.tex"),
        "tex_body_start": 171,
        "tex_body_end": 19335,
        "source_pdf": os.path.join(SCAN, "lehrbuchderalgeb02weberich.pdf"),
        "offset": 22,
        "printed_start": 1,
        "printed_end": 680,
    },
    "vol3": {
        "tex": os.path.join(CUM, "v3", "ge", "weber_v3_ge.tex"),
        "tex_body_start": 59,
        "tex_body_end": 16485,
        "source_pdf": os.path.join(SCAN, "lehrbuchderalgeb03webe_0.pdf"),
        "offset": 22,
        "printed_start": 1,
        "printed_end": 392,   # scan has a duplicated signature after ~p392; offset drifts there
    },
}


def interp_line(printed, v):
    ps, pe = v["printed_start"], v["printed_end"]
    ls, le = v["tex_body_start"], v["tex_body_end"]
    if pe == ps:
        return ls
    frac = (printed - ps) / (pe - ps)
    return int(round(ls + frac * (le - ls)))


def main():
    units = []
    for vol, v in VOLUMES.items():
        assert os.path.exists(v["tex"]), v["tex"]
        assert os.path.exists(v["source_pdf"]), v["source_pdf"]
        for printed in range(v["printed_start"], v["printed_end"] + 1):
            pdf_page = printed + v["offset"]          # 1-based PDF page
            units.append({
                "volume": vol,
                "source_pdf": v["source_pdf"],
                "pdf_page": pdf_page,
                "printed_page": printed,
                "tex_file": v["tex"],
                "tex_line_hint": interp_line(printed, v),
            })
    manifest = {
        "schema": "weber_lehrbuch_audit_manifest_v1",
        "generated_by": "build_manifest.py",
        "unit": "one printed page covered by both cumulative German .tex and a verified scan",
        "canonical_tex_set": "Weber_B139_heuristic_fix/02_cumulative/{v1,v2,v3}/ge",
        "offset_rule": "pdf_page (1-based) = printed_page + offset",
        "offsets": {k: v["offset"] for k, v in VOLUMES.items()},
        "tex_line_hint_method": "linear interpolation over document body; locates screen not exact line",
        "n_units": len(units),
        "n_units_per_volume": {
            k: (v["printed_end"] - v["printed_start"] + 1) for k, v in VOLUMES.items()
        },
        "units": units,
    }
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    print("WROTE", OUT)
    print("total units:", len(units), manifest["n_units_per_volume"])


if __name__ == "__main__":
    main()
