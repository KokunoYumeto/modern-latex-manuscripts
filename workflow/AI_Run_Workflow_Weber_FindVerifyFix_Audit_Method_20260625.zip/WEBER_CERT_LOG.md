# Weber audit — certification log

Tracks every change applied to the canonical B139 `.tex` (under `…/02_cumulative/vN/ge/`),
with provenance. Method: agent finder (weber_audit_workflow.js) → I verify each fix by eye against
the 500-dpi scan → apply → pdflatex gate (0 errors AND page count not dropped).

## v1 (Band I) — weber_v1_ge.tex
Backup before first edit: `weber_v1_ge.tex.bak_pre_agentfix_20260625` (same dir).
State: **compiles 357 pp / 0 errors** (was 356; +1 page from the restored p100 block).

### 2026-06-25 — p100 + p102 (agent run wzmu04tqc; each fix hand-verified vs scan)
APPLIED (4):
- **p100 eq (9) determinant** — restored the dropped `φ(α₂)` row (scan shows φ(x), φ(α₁), φ(α₂), …, φ(αₙ); .tex had only φ(α₁) then dots).
- **p100 derivation block** — restored the dropped *"wofür wir auch setzen können"* + three displays `[x,…]=f(x)/(x−αᵢ)·[…]` + *"und ebenso"* (the bridge from (10) to formula (11)).
- **p102** — `f₁(x)=a₀xⁿ⁻¹+a′₁xⁿ⁻²+⋯` (restored the dropped `a′₁xⁿ⁻²` term).
- **p102** — restored the dropped second equation `f(x)=(x−α)(x−β)f₂(x)` on the `f₁=(x−β)f₂` display line.

DEFERRED (not applied — need tight-crop zoom to settle):
- p100 "Nenner" — `x−α₁, x−α₂ … x−αₙ` vs .tex ellipsis `x−α₁,…,x−αₙ` (agent conf 0.8; minor).
- p102 — source "Coëfficient" diaeresis vs .tex "Coefficient": my hand-read flagged it, the agent read it as faithful. Sub-symbol mark; settle with a crop before any change.

p101: clean (verified).

### 2026-06-25 — p103–107 (agent run wdraz676o; each candidate verified by eye)
APPLIED (1):
- **p106** — restored the dropped theorem numeral **VII.** before "Sind die Coefficienten $a_0,\ldots,a_n$ und die Variable $x$ reell…" (set off like VI/VIII; .tex had it as a bare paragraph). Compiles **357 pp / 0 err** (unchanged).

NO FIX NEEDED: p103, p104, p107 clean. **p105 — agent proposed 4 fixes, verifier rejected ALL 4** as phantom (old_string 0 matches); I hand-confirmed eq (5) is already the correct two-line `split` form (the audit agent hallucinated a one-line collapse). p104 `a_2/x` is a source-print typo the .tex correctly carries as `a_2/x^2` (type-B, untouched).

SYSTEMATIC (deferred — global policy, decide once for the whole work, do NOT patch per page): source prints "Coëfficient" (diaeresis); the .tex has "Coefficient" throughout.

### 2026-06-25 — p108–113 (run wahdj8vfy; each candidate verified by eye)
APPLIED (5):
- **p108 sign-schema** — restored the printed single shared header `ξ−ε<ξ<ξ+ε` (was two x-headers) and the `f(x)` row labels (were bare `1. 2. 3. 4.`).
- **p109** — restored a DROPPED displayed equation `\sqrt[2n]{a}=\sqrt[2]{\sqrt[n]{a}},\ \sqrt[4n]{a}=\sqrt[2]{\sqrt[2n]{a}}\ldots` and fixed garbled radical indices (`√a,√[n]a,√[n]α / "für jedes α"` → `√[n]a,√[2]a,√a / "für jedes a"`).
- **p112** — restored dropped equation number **(2)** on the `a=r(cosφ+i sinφ), a'=…` display (was untagged; (1),(3) present).
- **p113** — prose `nicht mehr als n` → source `n und nicht mehr` (exactly n; more precise).
- **p113** — prose `Die beistehende Figur` → `Die beistehende Fig. 1` (explicit reference; the Fig. 1 tikz exists in the .tex).
Compiles **357 pp / 0 err** (unchanged).

SKIPPED as cosmetic (commutative reorder, no math change): p111 ×2 `(b-ci)`→`(b-ic)` in eq (9) and the fraction. `ci=ic`; print and .tex are both internally inconsistent on the order anyway. p110 clean.

### 2026-06-25 — p114–119 (run w4kwfrqpa; verified by eye)
APPLIED (5):
- **p114** roots of unity — `\xi_k`→`\varepsilon_k` (×3: eq (11), "Werth von ε_k", Moivre `ε_k=ε^k`); the print uses ε throughout, the .tex misread it as ξ.
- **p114** — removed a spurious tagged eq (12) `\xi_k^n=1` and restored the real eq (12) `x^n=1` (the .tex had demoted it to inline); dropped the spurious word "ihrer".
- **p118** — xref `cubischen Gleichung (1)`→`(6)` (print shows (6)).
Compiles **357 pp / 0 err**.

REJECTED by me (kept the .tex): p119 footnote `Collected`→`Collectet`. Weber misprinted "Collectet"; the .tex correctly has "Collected" (Cayley's real title) — a defensible editor correction of an obvious typo, so KEPT and flagged type-B (the agent self-contradictorily emitted it as both a fix and a type-B). p115, p116, p117 clean.

### 2026-06-25 — p120–125 (run wnbmmoci2; verified by eye)
APPLIED (4) — all single-symbol/variable misreads:
- **p121** `d`→`\delta` (×2) — the lower-bound proof's small quantity is δ in print; the .tex had Latin d.
- **p123** — removed `=y+iz` that was wrongly added to the FIRST "Variable $x$" (print has bare x there; `=y+iz` belongs only to the second occurrence "der Variablen x=y+iz").
- **p124** `(P,\gamma)/\gamma<\eta/\gamma>\eta` → `(P,y)/y<\eta/y>\eta` — the cut variable is y (print); γ is correctly used later for the minimum value, so this was a localized misread.
Compiles **357 pp / 0 err**. p120, p122, p125 clean; 0 rejected.
Source typos correctly KEPT (not reverted): p125 Weber "kan"→.tex correct "kann" (type-B); `≦` double-bar glyph → `\le` (cosmetic).

NOTE: these 4 were found by the agent workflow and independently matched my by-hand audit. The same
run also produced HALLUCINATED fixes on phantom no-scan pages (args bug, now fixed) — proof the agent
output must never be applied unverified. Every line above was confirmed by eye before applying.
