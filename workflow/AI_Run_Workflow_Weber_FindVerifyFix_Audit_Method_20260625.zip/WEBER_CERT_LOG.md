# Weber audit — certification log

Tracks every change applied to the canonical B139 `.tex` (under `…/02_cumulative/vN/ge/`),
with provenance. Method: agent finder (weber_audit_workflow.js) → I verify each fix by eye against
the 500-dpi scan → apply → pdflatex gate (0 errors AND page count not dropped).

## v1 (Band I) — weber_v1_ge.tex
Backup before first edit: `weber_v1_ge.tex.bak_pre_agentfix_20260625` (same dir).
State: **compiles 360 pp / 0 errors** (grew from 356 as dropped blocks/footnotes were restored).

### 2026-06-25 — p100 + p102 (agent run wzmu04tqc; each fix hand-verified vs scan)
APPLIED (4):
- **p100 eq (9) determinant** — restored the dropped `φ(α₂)` row (scan shows φ(x), φ(α₁), φ(α₂), …, φ(αₙ); .tex had only φ(α₁) then dots).
- **p100 derivation block** — restored the dropped *"wofür wir auch setzen können"* + three displays `[x,…]=f(x)/(x−αᵢ)·[…]` + *"und ebenso"* (the bridge from (10) to formula (11)).
- **p102** — `f₁(x)=a₀xⁿ⁻¹+a′₁xⁿ⁻²+⋯` (restored the dropped `a′₁xⁿ⁻²` term).
- **p102** — restored the dropped second equation `f(x)=(x−α)(x−β)f₂(x)` on the `f₁=(x−β)f₂` display line.

DEFERRED (not applied — need tight-crop zoom to settle):
- p100 "Nenner" — `x−α₁, x−α₂ … x−αₙ` vs .tex ellipsis `x−α₁,…,x−αₙ` (agent conf 0.8; minor).
- p102 — source "Coëfficient" diaeresis vs .tex "Coefficient": my hand-read flagged it, the agent read it as faithful. Sub-symbol mark; settle with a crop before any change.

p101: clean (verified).

### 2026-06-25 — p103–107 (agent run wdraz676o; each candidate verified by eye)
APPLIED (1):
- **p106** — restored the dropped theorem numeral **VII.** before "Sind die Coefficienten $a_0,\ldots,a_n$ und die Variable $x$ reell…" (set off like VI/VIII; .tex had it as a bare paragraph). Compiles **357 pp / 0 err** (unchanged).

NO FIX NEEDED: p103, p104, p107 clean. **p105 — agent proposed 4 fixes, verifier rejected ALL 4** as phantom (old_string 0 matches); I hand-confirmed eq (5) is already the correct two-line `split` form (the audit agent hallucinated a one-line collapse). p104 `a_2/x` is a source-print typo the .tex correctly carries as `a_2/x^2` (type-B, untouched).

SYSTEMATIC (deferred — global policy, decide once for the whole work, do NOT patch per page): source prints "Coëfficient" (diaeresis); the .tex has "Coefficient" throughout.

### 2026-06-25 — p108–113 (run wahdj8vfy; each candidate verified by eye)
APPLIED (5):
- **p108 sign-schema** — restored the printed single shared header `ξ−ε<ξ<ξ+ε` (was two x-headers) and the `f(x)` row labels (were bare `1. 2. 3. 4.`).
- **p109** — restored a DROPPED displayed equation `\sqrt[2n]{a}=\sqrt[2]{\sqrt[n]{a}},\ \sqrt[4n]{a}=\sqrt[2]{\sqrt[2n]{a}}\ldots` and fixed garbled radical indices (`√a,√[n]a,√[n]α / "für jedes α"` → `√[n]a,√[2]a,√a / "für jedes a"`).
- **p112** — restored dropped equation number **(2)** on the `a=r(cosφ+i sinφ), a'=…` display (was untagged; (1),(3) present).
- **p113** — prose `nicht mehr als n` → source `n und nicht mehr` (exactly n; more precise).
- **p113** — prose `Die beistehende Figur` → `Die beistehende Fig. 1` (explicit reference; the Fig. 1 tikz exists in the .tex).
Compiles **357 pp / 0 err** (unchanged).

SKIPPED as cosmetic (commutative reorder, no math change): p111 ×2 `(b-ci)`→`(b-ic)` in eq (9) and the fraction. `ci=ic`; print and .tex are both internally inconsistent on the order anyway. p110 clean.

### 2026-06-25 — p114–119 (run w4kwfrqpa; verified by eye)
APPLIED (5):
- **p114** roots of unity — `\xi_k`→`\varepsilon_k` (×3: eq (11), "Werth von ε_k", Moivre `ε_k=ε^k`); the print uses ε throughout, the .tex misread it as ξ.
- **p114** — removed a spurious tagged eq (12) `\xi_k^n=1` and restored the real eq (12) `x^n=1` (the .tex had demoted it to inline); dropped the spurious word "ihrer".
- **p118** — xref `cubischen Gleichung (1)`→`(6)` (print shows (6)).
Compiles **357 pp / 0 err**.

REJECTED by me (kept the .tex): p119 footnote `Collected`→`Collectet`. Weber misprinted "Collectet"; the .tex correctly has "Collected" (Cayley's real title) — a defensible editor correction of an obvious typo, so KEPT and flagged type-B (the agent self-contradictorily emitted it as both a fix and a type-B). p115, p116, p117 clean.

### 2026-06-25 — p120–125 (run wnbmmoci2; verified by eye)
APPLIED (4) — all single-symbol/variable misreads:
- **p121** `d`→`\delta` (×2) — the lower-bound proof's small quantity is δ in print; the .tex had Latin d.
- **p123** — removed `=y+iz` that was wrongly added to the FIRST "Variable $x$" (print has bare x there; `=y+iz` belongs only to the second occurrence "der Variablen x=y+iz").
- **p124** `(P,\gamma)/\gamma<\eta/\gamma>\eta` → `(P,y)/y<\eta/y>\eta` — the cut variable is y (print); γ is correctly used later for the minimum value, so this was a localized misread.
Compiles **357 pp / 0 err**. p120, p122, p125 clean; 0 rejected.
Source typos correctly KEPT (not reverted): p125 Weber "kan"→.tex correct "kann" (type-B); `≦` double-bar glyph → `\le` (cosmetic).

### 2026-06-25 — p126–131 (run wtfu7alt6; dense §38–39 proof; each verified by eye)
APPLIED (10):
- **p126** — restored dropped QED marker "w. z. b. w." after eq (18).
- **p128** eq (5) — restored dropped explicit term: `a<b_1\le b_2\le b_3\le\cdots\le b_{n-1}`.
- **p129** — `\beta_i`/`\rho_i` → `\beta_1`/`\rho_1` (print uses subscript 1).
- **p130** — SYSTEMATIC `\theta`→`\Theta` (capital, ×4: the `a'<a\Theta` chain, eq (14) `a\Theta^\nu`, "da Θ^ν", and the `\Theta=1-\omega/4Q` definition); the print uses capital Θ throughout this proof.
- **p130 "Differenzen"** — fixed a `kleiner`↔`grösser` DIRECTION INVERSION and restored two dropped displays (the differences `(1-a/4Q),(1-a'/4Q),…` and `\Theta=1-\omega/4Q`); the .tex had paraphrased to inline `a^(ν)/4Q … grösser … ω/4Q`.
- **p130 eq (11)** — restored the dropped equation `α'=α-af(α)/(2Qf'(α))` and moved the (11) tag onto it; the δ/h display it had wrongly tagged is now untagged `\[…\]` (NOT `\begin{equation}`, which would auto-number spuriously). Added the dropped general term to the `a'<a\Theta` chain.
- **p131** — `|f'(α^(r))|≥k`→`|f'(α)|>k` (print: plain α, strict >; matches the p129 bound); restored the dropped general term `a^(ν−1)−a^(ν)>(a^(ν−1))²/4Q` in the eq (13) chain (stacked).
Compiles **357 pp / 0 err**. p127 clean; 0 rejected. Type-B kept: p130 eq (12) print "u" typo → .tex correctly "a".

### 2026-06-25 — p132–137 (run w0za37gy4; verified by eye)
APPLIED (0). p132, p133, p136, p137 clean. No .tex change → gate stays **357 pp / 0 err**.
**ALL 3 agent candidates REJECTED on review** (the verifier had passed all 3 — hand-check was the only gate):
- **p134 eq (10) & eq (14)** — agent escalated Weber's double-bar `≦` to `\gtreqless` (⋛). REJECTED: the .tex `\le` is correct — the prose says "im Inneren oder an der Peripherie/Grenze von (ϱ)" (= ≤) and the math (bound holds inside the disk) confirms ≤. The agent's own description ("two bars over a < wedge") is ≦=≤, mislabeled. Cosmetic glyph; kept `\le`.
- **p135 xref `(19),(20)`→`(20),(21)`** — REJECTED: the .tex correctly points to the inequalities (which ARE (19),(20)); the print's "(20),(21)" is an off-by-one SOURCE typo the editor fixed. Kept the correction; flagged type-B.

### 2026-06-25 — p138–143 (run wo4jo4wfi; §41–43 symmetric functions; verified by eye)
APPLIED (9):
- **p139** `n!`→`\Pi(n)` (Weber's factorial notation, book-wide; the .tex had modernized it).
- **p140** `sämtlich`→`sämmtlich` (lone slip vs the .tex's own 34× "sämmtlich" + the print).
- **p141** eq (2) — restored printed form `f(x)/(x−α)=…+f(α)/(x−α)` (the .tex had folded f(α) into the LHS numerator).
- **p141** eq (3) — restored dropped line `f_3(α)=α³+a₁α²+a₂α+a₃`.
- **p141** eq (4) — restored dropped first line `S(f(x)/(x−α))=f'(x)`.
- **p141** `worin nach §4,(8):`→`worin [§4,(8)]:` (brackets, dropped "nach").
- **p142** — restored dropped Newton footnote ("Arithmetica universalis, edit. 's Gravesande, p. 592").
- **p143** eq (11) — restored the dropped LONG form + connecting prose "die sich nach (7) auch so darstellen lassen:" (the .tex had only the short unnumbered form, mislabeled (11)).
- **p143** eq (3) — restored dropped term `+A_{m-1}α`.
Compiles **358 pp / 0 err** (was 357; +1 from restored content; no page swallowed). p138 clean.
REJECTED (verifier got this right): p140 `x`→`n` — print "x" is a source typo (sign of a_n is (−1)^n, depends on n); .tex correctly "n". Type-B.

### 2026-06-25 — p144–149 (run wmbmrvo7l; verified by eye)
APPLIED (2): **p144** restored dropped word "etwa" ("in S etwa noch vorkommenden"); **p148** restored dropped explicit 0 in the order tuple `(1,0,0,\ldots,0)` (matches siblings (1,1,0…0)/(2,0,0…0)). Compiles **358 pp / 0 err**. p145, p146, p149 clean.
REJECTED (verifier got this right): p147 — agent wanted to delete the .tex's "etc.", but the verifier's zoom confirmed the .tex matches the page; kept.

### 2026-06-25 — p150–155 (run wxyrbtpam; verified by eye)
APPLIED (1): **p154** eq (10) `β−γ`: `-u+v`→`u−v` — a genuine SIGN error (print shows u−v; the (X+Y, X−Y) difference-pattern and the cubic case at .tex 5529 both confirm). Compiles **358 pp / 0 err**. p150–153 clean.
REJECTED by me (revert-the-editor): **p155** `a_0,a_1,a_2,a_3,a_4`→`a_0,a_1,a_2,a_3` — the general quartic eq (14) is `a_0x⁴+…+a_4` (5 coeffs); the print's list OMITS a_4 (source oversight), the .tex's complete `a_0…a_4` is correct. Kept; type-B.

### 2026-06-25 — p156–161 (run wokiihclr; verified by eye)
APPLIED (2): **p160** prose `unendlich vieler`→`unendlicher` Wurzeln; **p161** prose `gewisse Werthepaare`→`gewisse dieser Werthpaare` (dropped "dieser"). Compiles **358 pp / 0 err**. p156, p157, p159 clean.
REJECTED by me (would inject a Weber error into the correct .tex): **p158 eq (14)** `Σν=m,Σμ=n`→`Σν=n,Σμ=m`. MATH truth is `Σν=m, Σμ=n` (verified by concrete example: f deg n=2, φ deg m=1 → Res=a_0b_1²−a_1b_0b_1+a_2b_0², degree 1=m in the a's, 2=n in the b's). The .tex already has the correct form; the PRINT's eq (14) is a Weber error.
  **Paired Weber erratum (type-B, left faithful):** §49 eq (5) prints `nν+mμ` for the resultant's y-degree, but the math-correct form is `mν+nμ` (same m↔n swap as the print's eq (14)). The .tex reproduces the print's `nν+mμ` there — faithful to the source error; note this leaves the (corrected) eq (14) and §49 (5) mutually inconsistent in the .tex. Flagged, not silently changed.

### 2026-06-25 — p162–167 (run wbi1e27lk; verified by eye)
APPLIED (0). p163–167 clean; p162 effectively clean. No .tex change → gate stays **358 pp / 0 err**.
REJECTED by me: **p162** `Endgleichung für z`→`für x`. Eliminating x and y cannot yield an equation "für x" (an eliminated variable); the §50 elimination chain is x→y→z, so the end-equation is in **z** — the .tex is correct. The print's "x" (if that is the glyph; the agent's own reasoning was self-contradictory) is a Weber typo. Kept .tex "z"; type-B.

### 2026-06-25 — p168–173 (run w0h0vvsc5; verified by eye)
APPLIED (1): **p172** restored a dropped displayed equation `ν_0+ν_1+ν_2+⋯+ν_{n-1}=m` + the "und" connector (between the "…vorkommt," prose and the μ-equation; it restates eq (13)). Compiles **358 pp / 0 err**. p168–171, p173 clean.
REJECTED by me (revert-the-editor; 4th such): **p172** s-subscript `(n-1)`→`(n+1)` — eq (12)'s x-exponent uses (n-1), so eq (14)'s s-subscript must too; the print's "(n+1)" is an internal-inconsistency typo, the .tex's "(n-1)" is correct. Kept; type-B.

### 2026-06-25 — p174–179 (run wh4r37hzt; verified by eye)
APPLIED (4):
- **p175** restored dropped `α_0` in the ratio chain `α_0:α_1:α_2:α_3:α_4` (the .tex said "vier Verhältnisse" but listed only 4 quantities = 3 ratios; eq (2) has 5 params α_0..α_4).
- **p178** restored the dropped section divider `Fünfter Abschnitt. / Lineare Transformation.` (the .tex flowed straight into §55; the parallel "Sechster Abschnitt" was present in-file).
- **p179** ×2 transformation-coeff index order `a_{ν,i}`→`a_{i,ν}` (and primed): print shows i first, consistent with the single-function `a_i`; coeffs not symmetric.
Compiles **358 pp / 0 err**. p174, p176, p177 clean; 0 rejected.

### 2026-06-25 — p180–185 (run wkgrk0q50; verified by eye)
APPLIED (0). p183, p184 clean; p180/181/185 had only cosmetic/revert candidates. No .tex change → gate stays **358 pp / 0 err**.
- **p185 eq (2)** `Φ'(x'_i)`→`Φ(x'_i)`: REJECTED (revert-the-editor) — eq (2) is the coeff of t in `Φ(x'_i+tξ'_i)=Σξ'_iΦ'(x'_i)`, so Φ' (partial derivative) is REQUIRED, parallel to eq (1)'s F'. The .tex's Φ' is correct; the print's unprimed Φ is a dropped-prime typo. Type-B.
- **p180 eq (3)** `ξ_i u_i`→`ξ_ν u_ν` and **p181 eq (11)** over-Σ index: SKIPPED as cosmetic — dummy summation-index name/placement, no meaning change; the .tex's consistent `i`/`\sum_i` is a defensible standardization (cf. the agent's own "Σ-index placement is cosmetic" note on p185).
- **p182** `x_m`→`x_n`: rejected by verifier; keep-the-editor anyway (print's x_n is a typo, ψ is of m variables).

### 2026-06-25 — p186–191 (run wsm4x3nui; verified by eye)
APPLIED (1): **p188** restored dropped word "den" ("Wenn wir nach den §. 16, (4) die Function"). Compiles **358 pp / 0 err**. p186, p187, p189, p190, p191 clean; 0 rejected. (Agent correctly auto-classified a commutative reorder `a_0 r^n`/`r^n a_0` as cosmetic — the rule is firing in-agent now.)

### 2026-06-25 — p192–197 (run w6wwajy55; §62–63 cubic-form invariant theory; verified by eye + math)
Densest batch yet — 13 candidates, **10 APPLIED, 2 rejected, p193 clean**:
- **p194** fixed .tex corruption `\\eta`→`\eta` (doubled backslash rendered a line break + literal "eta").
- **p195** identische Relationen: garbled chained-primed `3a'_1A'_0+a'_0A'_1=…` → two clean unprimed identities `3a_3A_0+a_1A_2=a_2A_1, a_2A_0+3a_0A_2=a_1A_1`.
- **p196** `C`→`C'` ×3 (covariant in the normal-form variables); exponents `α,3β`→`h,3k`; restored dropped parenthetical "(da wir die numerischen Coefficienten … vorausgesetzt haben)".
- **p197** restored dropped clause "(weil eine symmetrische Function von zwei Grössen…)"; `λ−2α` fabricated 2-step chain → `\frac32(μ−ν+2β+2τ)`; `r durch D`→`D^{-1/6}`.
Compiles **358 pp / 0 err**.
REJECTED: **p197** `γ`→`σ` (6th revert-the-editor — the paragraph proves γ integral; the print's "σ" is a Weber typo, the .tex's γ correct; type-B). SKIPPED: **p192** remove "ist" (low value, removing a grammatical word).

### 2026-06-25 — p198–203 (run w97rvytee; verified by eye + math)
APPLIED (3): **p198** restored dropped leading `Q^τ` on the first "Summe der Form" (eq (8) correctly keeps it dropped since Q is primitive); **p198** restored dropped display `(-1)^α M x^{2(α+β)} y^β` (+ "dieses"→"dies"); **p203** eq (11) `D=…−4a'_1a'_3³`→`−4a'_1³a'_3³` (D is a degree-6 invariant; the .tex term was inhomogeneous degree 4). Compiles **358 pp / 0 err**. p199–202 clean; 0 rejected.

### 2026-06-25 — p204–209 (run w1agyukjg; §65–67 invariant theory; verified by eye + math)
Dense — 11 candidates, **11 APPLIED, 0 rejected, p204 clean**:
- **p205** restored dropped derivation block (`ψ_1=a'_1ξ²−a'_3η²=a_0[…]/(α−β)` + "Darin aber … cyklisch zu vertauschen. Man findet so").
- **p206** `I'=r^λ I`→`r^{2μ}` (weight; I is degree μ); `Function I`→`I'`; `I(a)=I(0,…).`→`I'(0,…),`; "Diese Function I … a'_1a'_3 und a'_2"→"und diese Function I … a'_2 und dem Product a'_1a'_3".
- **p207** inverted substitution `ξ'=λξ`→`ξ=λξ'` (+ matching coeff exponents `λ^{-2}a'_1,λ²a'_3`→`λ²a'_1,λ^{-2}a'_3`); `χ`→`ψ` in eq (5) + its prose (Weber distinguishes ψ(5) from χ(6)).
- **p208** generator list `A,D,B`→`A,B,D` (matches print + eq (3)).
- **p209** restored dropped bibliography footnote (Clebsch 1872 / Faà di Bruno 1881 / Gordan–Kerschensteiner 1885 / F. Meyer 1890–91) — verified against a full-page re-render (the chunk scans were too faint).
Compiles **358 pp / 0 err**.

### 2026-06-25 — p210–215 (run wgfxgnw5z; §68–69 Tschirnhausen/Hermite; SPLIT — §68 fixed, §69 HELD)
Worst-transcribed region so far (27 agents, 894k tok). **§68 (p210–211): 5 APPLIED. §69 (p213–215): 10 HELD (see flag). p212 cosmetic only.**
§68 applied (genuine same-edition garbling):
- **p210** restored dropped footnote (Hermite, *Sur quelques théorèmes d'algèbre…*, Comptes rendus, Paris 1859).
- **p211 eq (3)** wrong LHS `x^ν`→`f(t)/(t−x)`, ν→n indices, restored dropped `+t f_{n-2}(x)` term.
- **p211 eq (4)** f_ν array shifted by one: restored `f_0=a_0` row, corrected last row to degree n−1.
- **p211 eq (6)** S[f_ν] shifted: restored `S[f_0]=na_0`, added `S[f_2]` row.
- **p211 eq (9)** wrong general formula → explicit `F_0,…,F_{n-2}` array (the .tex formula gives wrong F_0 even after eq (4) is corrected).
Compiles **359 pp / 0 err** (footnote + restored rows = +1 page; no swallow).

⚠️ **§69 HELD — p212–216 (.tex 7748–7876) needs a DEDICATED COHERENT REWORK, not piecemeal:**
The .tex §69 systematically writes `H(τ,ξ)` for Weber's eq-(3) analytic function `Φ(τ,ξ)`, which COLLIDES with the print's *separate* `H(τ,ξ)` (eq (10), the τ_k-substituted symbolic form `=Στ_kΦ_k`). It also drops the `Φ_ν(ξ)` expansion lines and a derivation block (the `dt/dτ=r/(γτ+δ)²` formula + the subtraction step). The verify stage correctly REJECTED the single eq-(8) Φ-graft (would reference an undefined symbol / break consistency) and flagged a possible "edition difference"; my read is it's a confused transcription, not a different edition. Either way the 10 agent candidates are scoped Φ/H grafts that together make a broken hybrid. **FIX PLAN:** read all print §69 (p212–216) in one pass, then rework .tex 7748–7876 coherently — restore `Φ` for the eq-(3) function, keep `H` only for the eq-(10) symbolic form, restore the `Φ_ν` expansions + the dropped blocks. Do NOT apply the agent's 10 §69 candidates individually. (Edition cross-check available: BSB first-edition Band I scan on disk.)

### 2026-06-25 — p216–221 (run w1buniwck; §70 Hermite-satz + §71 cubic transformation; verified by eye + math)
Another worst-region (30 agents, 915k tok), 0 clean pages. **20 APPLIED, 1 Weber erratum flagged.**
§70 (p216–218):
- **p216** restored dropped `a_0^\lambda` (`a_0^λ P(y_1…y_n)=K(t,a)`); `Coefficienten von f'(t)`→`-\frac1n f'(t)`; coefficient list →`0, -\frac{n-1}{n}a_1…, -\frac1n a_{n-1}` (added 0, minus signs, removed spurious `(n-2)/n a_2`); `p_2…p_n`/`p_ν`→capital `P` (eq (3) + prose).
- **p217** display `\frac{f(t)}{t-x}`→`-\frac1n f'(t)` added (it's F(t,x)); eq (5) restored print's specific indices + plain fraction `y_1-y_2=(x_1-x_2)\frac{f(t)}{(t-x_1)(t-x_2)}` (.tex had general i,k + a `(…)_t` wrapper not in print) + matching prose; **systematic Greek→Latin** `θ_{ik}`→`t_{i,k}` (×3: prose, eq (6), eq (7)) — print uses Latin t for building blocks, capital Θ for their product; eq (7) also restored `a_0^{n-1}` on LHS.
- **p218** `C_ν=Q_ν/Θ`→`ΘC_ν=Q_ν` (print's form).
§71 cubic (p220–221):
- **p220** eq (5) 2nd group `\tfrac23a_1x²+\tfrac13a_2x+\tfrac13a_3`→`a_0x²+a_1x+\tfrac23a_2` (= F_1 from §68); Δ `-4(\tfrac13H)³-27(\tfrac1{27}Q)²`→`-\tfrac1{27}(4H³+Q²)` (print's compact form, connects to eq (7)).
- **p221** restored dropped `3Q_0=\tfrac23H(t_1,t_0)Q_2-a_1f(t_1,t_0)` (.tex had `Q_0=0`); `y_2-y_3` factor `(x_2+x_3+t)`→`(t_1-t_0x_1)`; `y_2²-y_3²` restored dropped `y_1` factor; sum formulas `Σx_1(x_2-x_3)`→`Σx_1²(x_2-x_3)` & `a_0²x_1²`→`a_0³x_1³` (.tex's first was identically 0); restored dropped `Q_0` line + fixed `Q_1`,`Q_2` (`-t`→`-t_0`); eq (10) `-tH(t)`→`-\tfrac23H(t)`.
Compiles **359 pp / 0 err** (no swallow).

⚠️ **WEBER ERRATUM (type-B, transcribed faithfully as printed):** p221 final `Q_0` line prints `-\tfrac23 t_0 H`, but the H-coefficient must be **2/9** — proven twice: (a) Weber's own `3Q_0=\tfrac23H·Q_2-a_1f` (same page) with `Q_2=-t_0` ⇒ `-\tfrac29 t_0H`; (b) matching eq (10) `(3a_0x+a_1)f=-\tfrac23H+yf'-3y²` against `3·`eq (9) ⇒ `3Q_0=-a_1f-\tfrac23H` ⇒ `2/9`. Weber's page is internally inconsistent; the printed `Q_0` (2/3) is the typo. Zoom-verified via new `crop_src.py` (glyph is unambiguously `3`). RESTORED AS PRINTED (2/3) + flagged; candidate for an editorial `[sic; 2/9]` footnote — user's call.

DEFERRED (equal-value, not yet scan-confirmed): p218 `\sqrt{\Delta}`→`\Theta\sqrt{D}` (=√Δ since Δ=DΘ²). REJECTED (w/ agent): p217 eq (6) i,k authentic; p219 ×3 (.tex already correct).

### 2026-06-25 — p222–227 (run wxv40r1h5; §71 Cardano tail + §72 general transformation; verified by eye + math)
**10 APPLIED, 0 rejected, p225–227 clean** (16 agents, 523k tok).
§71 Cardano (p222):
- eq (12)/(13) `\Omega`→`\varrho` (varrho misread as Omega) + eq (13) `Q(t)`→`Q`; eq (14) `\sqrt[3]{Q(t)}`→`\sqrt[3]{3\varrho f(t)}`; prose `Der`→`und der Ausdruck (10)`.
- **Restored a badly-garbled Cardano-derivation block** (§62 link): `.tex` had `ξ=-h^{-1}Q`, `f(t)=r³f(t)=η³+ξ³`, `(16) 3a_0x+a_1=A-(ξ+η)`, `A=q_0/2A_0³` → print's `ξ=-hϱ; f(t)=ξ³, f'=3ξ²ξ'; f(t)=-h³ϱ³, f'=3h³A_0ϱ²; y=hϱ∛(3ϱ)/3; 3a_0x+a_1=-hA_0∛(3ϱ)-1/(h∛(3ϱ)); (16)=A_0(k-h)∛(3ϱ); hA_0∛(3ϱ)=∛((-q_0+3ϱa_0)/2), kA_0∛(3ϱ)=∛((+q_0+3ϱa_0)/2)`. Internally math-consistent (`ξ=-hϱ⇒f=ξ³=-h³ϱ³`, `f'=3ξ²ξ'=3h³A_0ϱ²`, eq (14)⇒`y=hϱ∛(3ϱ)/3`).
- eq (17) Cardano formula `q,p`→Weber's `a_3,a_2` (depressed cubic `p=a_2,q=a_3`); added `(§35)` xref.
§72 (p223–224):
- **p223** eq (5) restored dropped `a_0` factor (`E_{r,0}=a_0t_{n-1-r}`, consistent w/ eq (9) at s=0); prose `E_{r,s}; diese sind…t.`→ relative clause `E_{r,s}, die…t sind.`
- **p224** prose `Wenn wir`→`und wenn wir` (dropped connective + de-capitalized).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p228–233 (run wv6xbxijm; §73 Bezoutiante + §74/75; verified by eye + math)
**12 APPLIED, 0 rejected, p230–232 clean** (20 agents, 611k tok).
- **§73 E-table (p228–229)** systematic `t`→`τ` in the entire RIGHT factor column (the bilinear φ(t)φ(τ) construction; left columns stay in t). Rewrote all 12 cells at once: row coeff = f'(t) coeff (4a_0,3a_1,2a_2,a_3) × τ_{3-s}. Agent caught 10; verifier wrongly rejected 2 (E_{3,2} uniqueness-fail on its scoped old_string; E_{1,3} misread as `3a_0` — zoom-confirmed `3a_1`, consistent with the row). Whole-column rewrite covers all.
- **§75 (p233)** restored two dropped footnotes: Cayley (on Tschirnhausen's Transformation, Phil. Trans. 1861, Math. Papers IV, Nr. 275) + Gordan (Math. Annalen Bd. 28, 1886).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p234–239 (run wszgm639n; §75/76 → 'Zweites Buch. Die Wurzeln'; verified by eye + math)
**1 APPLIED, 0 rejected, p234/236/237/238/239 clean** (7 agents, 265k tok). Mostly clean (end of Erstes Buch).
- **p235** `ξ=-\frac1{y+\sqrt c}`→`ξ=\frac1{y+\sqrt c}` (spurious minus; the next line `y=(1-ξ√c)/ξ` only follows from `+`; scan shows no minus, equals sign directly on the fraction bar).
Compiles **359 pp / 0 err**. (p239 = the 'Zweites Buch / Die Wurzeln' divider — new major part begins.)

### 2026-06-25 — p240–245 (run w7dhyhsih; §76–78 root reality/Sturm; verified by eye + math)
**2 APPLIED, 0 rejected, p240/241/243/245 clean** (8 agents, 272k tok).
- **p242** discriminant display: `.tex` OVER-EXPANDED Weber's prototype `(x_1-x_2)^2,` into the full product `(x_1-x_2)^2(x_1-x_3)^2⋯(x_{n-1}-x_n)^2,` — print shows only the single representative factor (full product described in prose 'Quadrate der sämmtlichen Wurzeldifferenzen'). Reverted to print. **(rare direction: .tex ADDED content, not dropped.)**
- **p244** prose `also sind alle drei Wurzeln reell`→`also alle drei Wurzeln reell` (dropped inserted `sind`; elliptical, parallel to 'also nur eine Wurzel … reell' above).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p246–251 (run wpkamn8yq; §78 biquadratic discussion; verified by eye + math)
**3 APPLIED, 0 rejected, p246–249 clean** (9 agents, 326k tok).
- **p250** restored two dropped footnotes: Kronecker (Monatsbericht Berliner Akad. 14 Feb 1878 + Dyck Katalog math. Modelle, München 1892, source of Fig. 5); Clebsch (Theorie der binären Formen §47) + Faà di Bruno (Walter, Leipzig 1881, §20, w/ Nöther's Zusatz).
- **p251** `-I^2`→`-T^2` in the covariant series `1, H, H²-16Af², -T²` (capital T misread as I; .tex's own §66 (7) at line 7534 uses -T²; scan p251_bot unambiguous T).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p252–257 (run wj6z5uigg; §79 Bezoutiante/Realität + §80 Trägheit; verified by eye + math)
**3 APPLIED, 0 rejected, p252/256/257 clean** (9 agents, 331k tok).
- **p253** restored dropped leading `\pm` on the Vandermonde determinant (`\pm|det|=∏(x_r-x_s)`; Vandermonde = product only up to sign).
- **p254** `π+ν+1=n`→`π+ν=n-1` (transposed +1; print's literal form).
- **p255** eq (2) `\sum_{1}^{m}`→`\sum_{1,m}^{i,k}` (Weber's double-index Σ: indices i,k on top, range 1..m below; .tex dropped the i,k labels).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p258–263 (run w3kk5thy0; §81–83 quadratic forms / vanishing determinants; verified by eye + math)
**13 APPLIED, 0 rejected, p261–263 clean** (19 agents, 592k tok).
- **§81 systematic `ξ`→`z`** (p258–259): the .tex rendered Weber's Latin linear forms `z_1,…,z_k`/`z_s` as `\xi` throughout — 10 instances (eq (2), the matrix prose, h-equation, y-system RHS ×3, the eq-(4)/(5) lead-in, eq-(6) lead-in). Converted the whole passage (incl. the cell the verifier rejected for wanting exactly this uniform conversion).
- **p259** eq (7) `\sum_{1}^{k}`→`\sum_{1,k}^{r,s}` (double-index Σ again); eq (6) `\varphi(…)',`→`\varphi(…);` (spurious prime + comma→semicolon).
- **p260** second-underdeterminant `A_{i,k}^{h,l}`→`A_{i,i'}^{k,k'}` (print's index convention).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p264–269 (run wtx630oo8; §83–84; verified by eye)
**1 APPLIED, 0 rejected, p265–269 clean** (7 agents, 244k tok). Very clean.
- **p264** .tex escape-corruption: `$\pi,\nu$` was split at a line-wrap into `$\pi,`⏎`u$` (the `\n` of `\nu` eaten as a newline → rendered 'π, u'). Restored `\nu`. **(2nd escape-corruption after p194's `\\eta`.)**
Compiles **359 pp / 0 err**. Sweep `\$\\(greek),?$` (unclosed macro at line-end) found 1 more candidate ~line 19660 (~p500) — flagged for when the audit reaches it.

### 2026-06-25 — p276–281 (run wf8ghhsen; §88 Säculargleichung; verified by eye)
**0 APPLIED — ALL SIX PAGES CLEAN** (6 agents, 211k tok). §88 (secular equation / Sturm) faithfully transcribed; only cosmetic diffs (Coëfficient diaeresis, ss/ß, spaced ellipses, footnote accent style acute-vs-grave, and a conventional `\sum_{i=1}^n` vs Weber's `\sum_{1,n}^{i}` layout — LEFT as complete-notation re-expression, NOT an info-loss like p255/p259's bare `\sum_1^m`). Gate unchanged **359 pp / 0 err** (no .tex change). Sturm footnotes on p279/p280 PRESENT in .tex (not dropped).

### 2026-06-25 — p270–275 (run wns0kdpad; §85–87 Sturm chains; verified by eye + zoom)
**6 APPLIED, 0 rejected, p270/271/275 clean** (12 agents, 413k tok).
- **Sturm-chain label**: the .tex rendered Weber's Fraktur chain name `(ℜ)` as the digit `(1)` throughout §86. Zoom-confirmed Fraktur **ℜ** (R for Reihe; agent was split K/R, verifier said R, my zoom + context = R). Fixed all 5 instances → `(\mathfrak R)`: eq (1) right-margin label (added, kept \tag{1}) + 4 in-text refs.
- **p274** prose `So ist P_n(x) … Grades, und`→`so dass P_n(x) … Grades ist, und` (restored subordinate clause + clause-final `ist`).
Compiles **359 pp / 0 err**.

### 2026-06-25 — p282–287 (run wqtorxz0i; §89–93 Hermite form / discriminant determinant / characteristic theory; verified by eye + math)
**16 APPLIED, p282/287 clean** (23 agents, 734k tok). Dense again.
- **p283** eq (6): all three sums `\sum_{s=0}^{·}`→`\sum_{s=0}^{n-1}` (2nd was n-2, 3rd was 0; print uniform 0..n-1) + eq-end period→comma; `z=y`→`τ=t`; `Dies`→`und dies`; `so ergeben sich`→`so ergiebt sich`.
- **p284** systematic `h_{i,k}`→`H_{i,k}` (×3: H=ΣΣ def, prose, S-def) + prose `t_it_k`→`t_iτ_k` (bilinear §91(6)); **restored dropped determinant-decomposition block** (`(-1)^nf(α)/a_0·|f_k(x_i)|²` + `|a_0-triangular|×|Vandermonde|` + `a_0^{2n-2}D`→`a_0²D`; math: product²=a_0^{2n}Π²=a_0²D); `so wird Δ`→`Δ also`; `Δ_n(α)`→`Δ_n(α)=Δ`.
- **p285** cubic Kette `-H_{2,2},-(…)/a_0,-Δ`→`(1/a_0)H_{2,2},(1/a_0)(…),(1/a_0)Δ` (signs+factor); 'vier Functionen' 3rd/4th terms badly garbled → restored (incl. `-f(α)D`).
- **p286** systematic `θ`→`Φ` (×3: prose, dΦ, eq (2) `[φ,Φ]`) — Weber's arbitrary function is Φ (θ would clash with the angle ϑ).
Compiles **360 pp / 0 err** (was 359; +1 from restored p284 block).

### 2026-06-25 — p288–293 (run w2jxi5lw0; §93–94 Charakteristikentheorie; verified by eye + zoom)
**8 APPLIED, 0 rejected, p290/291/293 clean** (13 agents, 427k tok).
- **p289 systematic `a`→`α`** (×4: 'der Punkt α', 'ψ in α positiv/negativ', Fig 9 node) — the intersection-point label is Greek α (zoom-confirmed; matches φ/ψ style + Fig 9). NB the doc DOES use Latin a elsewhere (counts: 'Ist a die Anzahl', p288), so a/α is a real distinction — zoomed to be sure.
- **p292** eq (3) restored dropped third member `=ψ'(x)²+ψ'(y)²` (= φ'(x)²+φ'(y)² via eq (2)).
- **p288** parenthesized '(Im Falle der Fig. 8 ist sie gleich −1)'; **p289** prose `Es gilt`→`und es gilt`.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p294–299 (run w3c0efzrk; §94–98 fundamental theorem of algebra; verified by eye)
**2 APPLIED, 0 rejected, p295–299 clean** (8 agents, 314k tok). Mostly clean.
- **p294** eq (4) `k=A_ε.`→`k=A_ε,` + `D. h.`→`d. h.` (the equation flows into the 'd.h.' sentence; period+capital → comma+lowercase).
- Footnotes p296 (Gauss 1799 'Demonstratio nova'), p299 (Sturm) PRESENT in .tex (only accent/punct cosmetic diffs).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p300–305 (run wa273i4qi; §99–100 Budan-Fourier / Newton's rule; verified by eye + zoom)
**~12 APPLIED + restored 2 dropped sign tables, p305 clean** (15 agents, 519k tok). Dense (computation §§).
- **p303 systematic `λ`→`𝔷`** (×3: prose + 2 eqs) — the root-count is Fraktur 𝔷 (z for Zahl; zoom-confirmed; .tex had Greek λ). μ (multiplicity) correctly kept.
- **p301–302 RESTORED 2 dropped sign tables** (Budan-Fourier case analysis: '1. μ gerade' + '2. μ ungerade', each with a)/b) sub-cases and δ_1/δ_2 sign-rows) — the .tex had collapsed both into a prose paraphrase. Reconstructed from both scan pages (all +/− entries legible) + restored the 'Es geht also' conclusion.
- **p304** eq (4) `F_0=F_n=1`→`F_0=F=1` (the .tex's F_n=1 contradicted F_n=f_n² on the same line); eq (6) badly garbled → `f_ν F_ν'(x)=(n-ν-1)(F_ν f_{ν+1}+F_{ν+1}f_{ν-1})`; removed over-expansion clause 'bis auf positive Zahlenfactoren…Form.'.
- **p300** `unverändert`→`ungeändert` (Weber's word); **p301** `f^{(ν+μ)}(ξ)`→`(x)`; **p302** `Reihe`→`Reihen`.
Compiles **360 pp / 0 err**.

### 2026-06-25 — p306–311 (run w1x9p9vuc; §101–102 Newton/Descartes/Jacobi criteria; verified by eye + zoom)
**9 APPLIED, 0 rejected, p307/308 clean** (15 agents, 513k tok).
- **p309** eq (4) restored dropped top row of the Doppelreihe (`a_0,…,a_n` over `A_0,…,A_n`; wrapped in gathered).
- **p311** sign sequence `+,-,+`→`-,+,-` (inverted); `D=A_1A_2-B²`→`3D=…` (dropped 3); eq (2) restored dropped 1st formula `y=(x-α)/(β-x)`; footnote removed over-inserted `Jacobi,`; connective `In der Reihe`→`und in der Reihe`.
- **p306** restored dropped 'lassen aber…nur zwei Fälle' enumeration-caveat clause + `Functionen f_ν`→`Functionen, etwa f_ν,`.
- **p310** `aller reellen Wurzeln`→`aller reeller Wurzeln` (don't-modernize: print's strong genitive `-er`).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p312–317 (run wwhxovth2; §103 Klein / §104 Laguerre; verified by eye + zoom)
**4 APPLIED, 0 rejected, p314/315 clean** (10 agents, 346k tok).
- **p312** §103 heading restored dropped author 'Klein's' (→ 'Klein's geometrische Vergleichung der verschiedenen Kriterien').
- **p313** restored dropped xref note 'Fig. 16 (a. f. S.)' (auf folgender Seite).
- **p316** Laguerre function list `f_0…f_n(x)`→`f_0…f_{n-1}(x)` (the §4 associated functions are f_0..f_{n-1}; f(x)=f_n(x) separate; confirmed by the p317 definition block).
- **p317** `in \S\,4`→`im \S\,4` (Weber's 'im §', dropped m).
Compiles **360 pp / 0 err**.

### 2026-06-25 — p318–323 (run w5die8q32; §106–107 Rolle/Laguerre; verified by eye + math)
**~10 APPLIED, p318/319/321/322 clean** (15 agents, 479k tok).
- **§107 (p323) systematic `\sum`→`S`** (Weber's sum-over-roots operator; print + prose 'das Summenzeichen S' confirm; eqs 1–4,7 all S) — agent had only converted some.
- **p323 eq (3)** removed spurious `n` (numerator `f'(x)²-H(x)`, consistent w/ eq (2)); **eq (4)** fixed + removed a PHANTOM 'in der sinngemässen…' block; **eq (5/6)** numbered the `rx'=dx-by` system as (6); **restored dropped display `r²H(x,y)=H'(x',y')` + 'Hiernach'**; **eq (7)** S form + restored dropped factor `(cx'+dy')²` + retag (6→7).
- **p320** `Ausdrucks`→`Ausdruckes` (dropped genitive -e; Weber uses -es 4×); `c-fache Wurzel u.s.f.`→`c-fache etc.\ Wurzel`; Theorem XIV `f(x)=0`→`f(x)` (XIII has =0, XIV doesn't).
Compiles **360 pp / 0 err**.

NOTE: these 4 were found by the agent workflow and independently matched my by-hand audit. The same
run also produced HALLUCINATED fixes on phantom no-scan pages (args bug, now fixed) — proof the agent
output must never be applied unverified. Every line above was confirmed by eye before applying.
