# Weber audit — certification log

Tracks every change applied to the canonical B139 `.tex` (under `…/02_cumulative/vN/ge/`),
with provenance. Method: agent finder (weber_audit_workflow.js) → I verify each fix by eye against
the 500-dpi scan → apply → pdflatex gate (0 errors AND page count not dropped).

## v1 (Band I) — weber_v1_ge.tex
Backup before first edit: `weber_v1_ge.tex.bak_pre_agentfix_20260625` (same dir).
State: **compiles 357 pp / 0 errors** (was 356; +1 page from the restored p100 block).

### 2026-06-25 — p100 + p102 (agent run wzmu04tqc; each fix hand-verified vs scan)
APPLIED (4):
- **p100 eq (9) determinant** — restored the dropped `φ(α₂)` row (scan shows φ(x), φ(α₁), φ(α₂), …, φ(αₙ); .tex had only φ(α₁) then dots).
- **p100 derivation block** — restored the dropped *"wofür wir auch setzen können"* + three displays `[x,…]=f(x)/(x−αᵢ)·[…]` + *"und ebenso"* (the bridge from (10) to formula (11)).
- **p102** — `f₁(x)=a₀xⁿ⁻¹+a′₁xⁿ⁻²+⋯` (restored the dropped `a′₁xⁿ⁻²` term).
- **p102** — restored the dropped second equation `f(x)=(x−α)(x−β)f₂(x)` on the `f₁=(x−β)f₂` display line.

DEFERRED (not applied — need tight-crop zoom to settle):
- p100 "Nenner" — `x−α₁, x−α₂ … x−αₙ` vs .tex ellipsis `x−α₁,…,x−αₙ` (agent conf 0.8; minor).
- p102 — source "Coëfficient" diaeresis vs .tex "Coefficient": my hand-read flagged it, the agent read it as faithful. Sub-symbol mark; settle with a crop before any change.

p101: clean (verified).

### 2026-06-25 — p103–107 (agent run wdraz676o; each candidate verified by eye)
APPLIED (1):
- **p106** — restored the dropped theorem numeral **VII.** before "Sind die Coefficienten $a_0,\ldots,a_n$ und die Variable $x$ reell…" (set off like VI/VIII; .tex had it as a bare paragraph). Compiles **357 pp / 0 err** (unchanged).

NO FIX NEEDED: p103, p104, p107 clean. **p105 — agent proposed 4 fixes, verifier rejected ALL 4** as phantom (old_string 0 matches); I hand-confirmed eq (5) is already the correct two-line `split` form (the audit agent hallucinated a one-line collapse). p104 `a_2/x` is a source-print typo the .tex correctly carries as `a_2/x^2` (type-B, untouched).

SYSTEMATIC (deferred — global policy, decide once for the whole work, do NOT patch per page): source prints "Coëfficient" (diaeresis); the .tex has "Coefficient" throughout.

### 2026-06-25 — p108–113 (run wahdj8vfy; each candidate verified by eye)
APPLIED (5):
- **p108 sign-schema** — restored the printed single shared header `ξ−ε<ξ<ξ+ε` (was two x-headers) and the `f(x)` row labels (were bare `1. 2. 3. 4.`).
- **p109** — restored a DROPPED displayed equation `\sqrt[2n]{a}=\sqrt[2]{\sqrt[n]{a}},\ \sqrt[4n]{a}=\sqrt[2]{\sqrt[2n]{a}}\ldots` and fixed garbled radical indices (`√a,√[n]a,√[n]α / "für jedes α"` → `√[n]a,√[2]a,√a / "für jedes a"`).
- **p112** — restored dropped equation number **(2)** on the `a=r(cosφ+i sinφ), a'=…` display (was untagged; (1),(3) present).
- **p113** — prose `nicht mehr als n` → source `n und nicht mehr` (exactly n; more precise).
- **p113** — prose `Die beistehende Figur` → `Die beistehende Fig. 1` (explicit reference; the Fig. 1 tikz exists in the .tex).
Compiles **357 pp / 0 err** (unchanged).

SKIPPED as cosmetic (commutative reorder, no math change): p111 ×2 `(b-ci)`→`(b-ic)` in eq (9) and the fraction. `ci=ic`; print and .tex are both internally inconsistent on the order anyway. p110 clean.

### 2026-06-25 — p114–119 (run w4kwfrqpa; verified by eye)
APPLIED (5):
- **p114** roots of unity — `\xi_k`→`\varepsilon_k` (×3: eq (11), "Werth von ε_k", Moivre `ε_k=ε^k`); the print uses ε throughout, the .tex misread it as ξ.
- **p114** — removed a spurious tagged eq (12) `\xi_k^n=1` and restored the real eq (12) `x^n=1` (the .tex had demoted it to inline); dropped the spurious word "ihrer".
- **p118** — xref `cubischen Gleichung (1)`→`(6)` (print shows (6)).
Compiles **357 pp / 0 err**.

REJECTED by me (kept the .tex): p119 footnote `Collected`→`Collectet`. Weber misprinted "Collectet"; the .tex correctly has "Collected" (Cayley's real title) — a defensible editor correction of an obvious typo, so KEPT and flagged type-B (the agent self-contradictorily emitted it as both a fix and a type-B). p115, p116, p117 clean.

### 2026-06-25 — p120–125 (run wnbmmoci2; verified by eye)
APPLIED (4) — all single-symbol/variable misreads:
- **p121** `d`→`\delta` (×2) — the lower-bound proof's small quantity is δ in print; the .tex had Latin d.
- **p123** — removed `=y+iz` that was wrongly added to the FIRST "Variable $x$" (print has bare x there; `=y+iz` belongs only to the second occurrence "der Variablen x=y+iz").
- **p124** `(P,\gamma)/\gamma<\eta/\gamma>\eta` → `(P,y)/y<\eta/y>\eta` — the cut variable is y (print); γ is correctly used later for the minimum value, so this was a localized misread.
Compiles **357 pp / 0 err**. p120, p122, p125 clean; 0 rejected.
Source typos correctly KEPT (not reverted): p125 Weber "kan"→.tex correct "kann" (type-B); `≦` double-bar glyph → `\le` (cosmetic).

### 2026-06-25 — p126–131 (run wtfu7alt6; dense §38–39 proof; each verified by eye)
APPLIED (10):
- **p126** — restored dropped QED marker "w. z. b. w." after eq (18).
- **p128** eq (5) — restored dropped explicit term: `a<b_1\le b_2\le b_3\le\cdots\le b_{n-1}`.
- **p129** — `\beta_i`/`\rho_i` → `\beta_1`/`\rho_1` (print uses subscript 1).
- **p130** — SYSTEMATIC `\theta`→`\Theta` (capital, ×4: the `a'<a\Theta` chain, eq (14) `a\Theta^\nu`, "da Θ^ν", and the `\Theta=1-\omega/4Q` definition); the print uses capital Θ throughout this proof.
- **p130 "Differenzen"** — fixed a `kleiner`↔`grösser` DIRECTION INVERSION and restored two dropped displays (the differences `(1-a/4Q),(1-a'/4Q),…` and `\Theta=1-\omega/4Q`); the .tex had paraphrased to inline `a^(ν)/4Q … grösser … ω/4Q`.
- **p130 eq (11)** — restored the dropped equation `α'=α-af(α)/(2Qf'(α))` and moved the (11) tag onto it; the δ/h display it had wrongly tagged is now untagged `\[…\]` (NOT `\begin{equation}`, which would auto-number spuriously). Added the dropped general term to the `a'<a\Theta` chain.
- **p131** — `|f'(α^(r))|≥k`→`|f'(α)|>k` (print: plain α, strict >; matches the p129 bound); restored the dropped general term `a^(ν−1)−a^(ν)>(a^(ν−1))²/4Q` in the eq (13) chain (stacked).
Compiles **357 pp / 0 err**. p127 clean; 0 rejected. Type-B kept: p130 eq (12) print "u" typo → .tex correctly "a".

### 2026-06-25 — p132–137 (run w0za37gy4; verified by eye)
APPLIED (0). p132, p133, p136, p137 clean. No .tex change → gate stays **357 pp / 0 err**.
**ALL 3 agent candidates REJECTED on review** (the verifier had passed all 3 — hand-check was the only gate):
- **p134 eq (10) & eq (14)** — agent escalated Weber's double-bar `≦` to `\gtreqless` (⋛). REJECTED: the .tex `\le` is correct — the prose says "im Inneren oder an der Peripherie/Grenze von (ϱ)" (= ≤) and the math (bound holds inside the disk) confirms ≤. The agent's own description ("two bars over a < wedge") is ≦=≤, mislabeled. Cosmetic glyph; kept `\le`.
- **p135 xref `(19),(20)`→`(20),(21)`** — REJECTED: the .tex correctly points to the inequalities (which ARE (19),(20)); the print's "(20),(21)" is an off-by-one SOURCE typo the editor fixed. Kept the correction; flagged type-B.

### 2026-06-25 — p138–143 (run wo4jo4wfi; §41–43 symmetric functions; verified by eye)
APPLIED (9):
- **p139** `n!`→`\Pi(n)` (Weber's factorial notation, book-wide; the .tex had modernized it).
- **p140** `sämtlich`→`sämmtlich` (lone slip vs the .tex's own 34× "sämmtlich" + the print).
- **p141** eq (2) — restored printed form `f(x)/(x−α)=…+f(α)/(x−α)` (the .tex had folded f(α) into the LHS numerator).
- **p141** eq (3) — restored dropped line `f_3(α)=α³+a₁α²+a₂α+a₃`.
- **p141** eq (4) — restored dropped first line `S(f(x)/(x−α))=f'(x)`.
- **p141** `worin nach §4,(8):`→`worin [§4,(8)]:` (brackets, dropped "nach").
- **p142** — restored dropped Newton footnote ("Arithmetica universalis, edit. 's Gravesande, p. 592").
- **p143** eq (11) — restored the dropped LONG form + connecting prose "die sich nach (7) auch so darstellen lassen:" (the .tex had only the short unnumbered form, mislabeled (11)).
- **p143** eq (3) — restored dropped term `+A_{m-1}α`.
Compiles **358 pp / 0 err** (was 357; +1 from restored content; no page swallowed). p138 clean.
REJECTED (verifier got this right): p140 `x`→`n` — print "x" is a source typo (sign of a_n is (−1)^n, depends on n); .tex correctly "n". Type-B.

### 2026-06-25 — p144–149 (run wmbmrvo7l; verified by eye)
APPLIED (2): **p144** restored dropped word "etwa" ("in S etwa noch vorkommenden"); **p148** restored dropped explicit 0 in the order tuple `(1,0,0,\ldots,0)` (matches siblings (1,1,0…0)/(2,0,0…0)). Compiles **358 pp / 0 err**. p145, p146, p149 clean.
REJECTED (verifier got this right): p147 — agent wanted to delete the .tex's "etc.", but the verifier's zoom confirmed the .tex matches the page; kept.

### 2026-06-25 — p150–155 (run wxyrbtpam; verified by eye)
APPLIED (1): **p154** eq (10) `β−γ`: `-u+v`→`u−v` — a genuine SIGN error (print shows u−v; the (X+Y, X−Y) difference-pattern and the cubic case at .tex 5529 both confirm). Compiles **358 pp / 0 err**. p150–153 clean.
REJECTED by me (revert-the-editor): **p155** `a_0,a_1,a_2,a_3,a_4`→`a_0,a_1,a_2,a_3` — the general quartic eq (14) is `a_0x⁴+…+a_4` (5 coeffs); the print's list OMITS a_4 (source oversight), the .tex's complete `a_0…a_4` is correct. Kept; type-B.

### 2026-06-25 — p156–161 (run wokiihclr; verified by eye)
APPLIED (2): **p160** prose `unendlich vieler`→`unendlicher` Wurzeln; **p161** prose `gewisse Werthepaare`→`gewisse dieser Werthpaare` (dropped "dieser"). Compiles **358 pp / 0 err**. p156, p157, p159 clean.
REJECTED by me (would inject a Weber error into the correct .tex): **p158 eq (14)** `Σν=m,Σμ=n`→`Σν=n,Σμ=m`. MATH truth is `Σν=m, Σμ=n` (verified by concrete example: f deg n=2, φ deg m=1 → Res=a_0b_1²−a_1b_0b_1+a_2b_0², degree 1=m in the a's, 2=n in the b's). The .tex already has the correct form; the PRINT's eq (14) is a Weber error.
  **Paired Weber erratum (type-B, left faithful):** §49 eq (5) prints `nν+mμ` for the resultant's y-degree, but the math-correct form is `mν+nμ` (same m↔n swap as the print's eq (14)). The .tex reproduces the print's `nν+mμ` there — faithful to the source error; note this leaves the (corrected) eq (14) and §49 (5) mutually inconsistent in the .tex. Flagged, not silently changed.

### 2026-06-25 — p162–167 (run wbi1e27lk; verified by eye)
APPLIED (0). p163–167 clean; p162 effectively clean. No .tex change → gate stays **358 pp / 0 err**.
REJECTED by me: **p162** `Endgleichung für z`→`für x`. Eliminating x and y cannot yield an equation "für x" (an eliminated variable); the §50 elimination chain is x→y→z, so the end-equation is in **z** — the .tex is correct. The print's "x" (if that is the glyph; the agent's own reasoning was self-contradictory) is a Weber typo. Kept .tex "z"; type-B.

### 2026-06-25 — p168–173 (run w0h0vvsc5; verified by eye)
APPLIED (1): **p172** restored a dropped displayed equation `ν_0+ν_1+ν_2+⋯+ν_{n-1}=m` + the "und" connector (between the "…vorkommt," prose and the μ-equation; it restates eq (13)). Compiles **358 pp / 0 err**. p168–171, p173 clean.
REJECTED by me (revert-the-editor; 4th such): **p172** s-subscript `(n-1)`→`(n+1)` — eq (12)'s x-exponent uses (n-1), so eq (14)'s s-subscript must too; the print's "(n+1)" is an internal-inconsistency typo, the .tex's "(n-1)" is correct. Kept; type-B.

### 2026-06-25 — p174–179 (run wh4r37hzt; verified by eye)
APPLIED (4):
- **p175** restored dropped `α_0` in the ratio chain `α_0:α_1:α_2:α_3:α_4` (the .tex said "vier Verhältnisse" but listed only 4 quantities = 3 ratios; eq (2) has 5 params α_0..α_4).
- **p178** restored the dropped section divider `Fünfter Abschnitt. / Lineare Transformation.` (the .tex flowed straight into §55; the parallel "Sechster Abschnitt" was present in-file).
- **p179** ×2 transformation-coeff index order `a_{ν,i}`→`a_{i,ν}` (and primed): print shows i first, consistent with the single-function `a_i`; coeffs not symmetric.
Compiles **358 pp / 0 err**. p174, p176, p177 clean; 0 rejected.

### 2026-06-25 — p180–185 (run wkgrk0q50; verified by eye)
APPLIED (0). p183, p184 clean; p180/181/185 had only cosmetic/revert candidates. No .tex change → gate stays **358 pp / 0 err**.
- **p185 eq (2)** `Φ'(x'_i)`→`Φ(x'_i)`: REJECTED (revert-the-editor) — eq (2) is the coeff of t in `Φ(x'_i+tξ'_i)=Σξ'_iΦ'(x'_i)`, so Φ' (partial derivative) is REQUIRED, parallel to eq (1)'s F'. The .tex's Φ' is correct; the print's unprimed Φ is a dropped-prime typo. Type-B.
- **p180 eq (3)** `ξ_i u_i`→`ξ_ν u_ν` and **p181 eq (11)** over-Σ index: SKIPPED as cosmetic — dummy summation-index name/placement, no meaning change; the .tex's consistent `i`/`\sum_i` is a defensible standardization (cf. the agent's own "Σ-index placement is cosmetic" note on p185).
- **p182** `x_m`→`x_n`: rejected by verifier; keep-the-editor anyway (print's x_n is a typo, ψ is of m variables).

NOTE: these 4 were found by the agent workflow and independently matched my by-hand audit. The same
run also produced HALLUCINATED fixes on phantom no-scan pages (args bug, now fixed) — proof the agent
output must never be applied unverified. Every line above was confirmed by eye before applying.
