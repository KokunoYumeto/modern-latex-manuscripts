# Weber audit — method log (what works, what fails, adjustments)

Running record for the vol1 (Band I) grind. Companion to `WEBER_CERT_LOG.md` (per-fix provenance).
Loop started 2026-06-25 via `/loop "do vol 1 - keep meticulous logs of what works and adjust"`.

## The loop (validated on p100–107)
Per batch: render pages (`chunk_page.py`, 500-dpi native, 2400px chunks) → `weber_audit_workflow.js`
(audit agent/page → adversarial verify/fix, default REJECT) → **I hand-verify every surviving fix
against the scan** → apply verified ones to B139 `weber_v1_ge.tex` → `pdflatex` gate (0 errors AND
page count not dropped) → log to `WEBER_CERT_LOG.md`. One workflow at a time (rate-limit rule).

## What WORKS
- **Agent recall is high** — on p100–107 the agents found every real drop I'd found by hand.
- **Verify stage filters most false positives** (uniqueness + source-support, default reject).
- **Compile gate + page-count check** catches silent breakage (the SGA5 swallowed-page lesson).
- **Discipline holds** — agents preserve 1890s orthography, route source-typos to type-B (don't
  revert the editor's corrections), call parens/punctuation cosmetic.

## What FAILS (why the hand-check is mandatory)
- **Audit agents hallucinate drops/collapses that aren't in the `.tex`** (p105 eq5: claimed a
  one-line collapse; the `.tex` already had the correct two-line form). The verifier caught all 4
  on p105 — but in batch 1 one phantom slipped through *accepted* (p1 determinant, a page with no
  scan). **Verifier reliability varies.**
- **Phantom pages** when args are mangled or scans missing → agents invent content. (Fixed.)

## Adjustments
- 2026-06-25 — fixed `parseArgs` (handle stringified `{volume,axis,pages}`), `pad(3)` chunk names,
  `texOf` v1/v2/v3 path (was `vol1`).
- 2026-06-25 — added **no-scan guard** to `chunks()` (agent must bail, not hallucinate, if PNGs unreadable).
- 2026-06-25 — added **"CONFIRM ABSENCE BEFORE CLAIMING A DROP"** rule to the audit prompt (grep the
  `.tex` to confirm content is truly absent before emitting a drop-fix). Targets the eq5-type
  hallucination; effect measured from p108 onward.
- Batch size: 3 → 5 → trying 6. Tune by review load (every accepted fix = an eye-read of the scan).

## Metrics
| batch | pages | agents | tokens | clean pages | real fixes applied | false-pos rejected | phantom slipped | compile |
|-------|-------|--------|--------|-------------|--------------------|--------------------|-----------------|---------|
| 1 | p100–102 | 13 | 456k | p101 | 4 (p100 det row + deriv block; p102 a′₁ + dropped eq) | 1 (caught by me) | 1 (p1 dup, harmless) | 357pp/0err |
| 2 | p103–107 | 10 | 336k | p103,104,107 | 1 (p106 "VII." label) | 4 (all p105, by verifier) | 0 | 357pp/0err |

## Open / global decisions
- **"Coëfficient" diaeresis** — source has it, `.tex` drops it throughout. Systematic → decide once
  for the whole work, do NOT patch per page.
- Volume identity: vol1 = Band I confirmed (running heads "Zweiter/Dritter Abschnitt" + content match).
- Cursor: vol1 audited through **p125**; next batch **p126–131** (rendered).

## Batch 5 (p120–125, run wnbmmoci2) — 10 agents, 348k tok
- 4 real fixes, all single-symbol/variable misreads (p121 d→δ ×2; p123 spurious "=y+iz" removed; p124 γ→y localized); p120/122/125 clean, 0 rejected.
- **Pattern emerging:** this region's errors are Greek/Latin glyph confusions (d/δ, γ/y, and ε/ξ in batch 4)
  — the dominant vol1 failure mode is **single-glyph misreads, not big drops**. Cheap for agents to find,
  easy to eye-verify, but they MATTER (wrong variable). Verifier passed all 4 (correct this time).
- Cosmetic discipline held: kept "kann" (Weber typo "kan"→type-B), `≦`→`\le`.

## Batch 4 (p114–119, run w4kwfrqpa) — 12 agents, 386k tok
- 5 real fixes applied (p114 roots-of-unity ξ→ε ×3 + bogus-eq removal/restore; p118 xref (1)→(6)); p115/116/117 clean.
- **I rejected 1 the verifier passed:** p119 `Collected`→`Collectet` — agent tried to revert the editor's
  correction of Weber's misprint (and self-contradictorily flagged it type-B too). The "don't revert
  obvious-typo corrections" rule is already in the prompt; the agent still violated it → hand-check is the gate.
- p114 was the fix-dense page: one symbol misread (ε→ξ) propagated to 4 spots plus a fabricated equation —
  exactly the kind of cascading transcription error worth catching.

## Batch 3 (p108–113, run wahdj8vfy) — 13 agents, 440k tok
- Verifier accepted **ALL 8** candidates (0 rejected) → the **hand-check did all the filtering**: I
  applied 5 real, SKIPPED 2 as cosmetic (p111 `ci`↔`ic` commutative reorder), p110 clean.
- The **confirm-absence rule worked**: the p109 agent grepped for the dropped `√[2n]` equation,
  found none, and correctly flagged the drop (no false "it's there").
- **Adjustment applied (active from p114):** "commutative reordering is cosmetic, never type-A" rule
  added to the audit prompt — directly targets the p111 over-flags.
- **Observation:** verifier reliability is inconsistent (filtered 4/4 in batch 2, 0/8 here) — my eye
  is the real gate, not the verify stage. Dense pages (8 candidates/6 pp) → keep batches ≤6 in this region.
