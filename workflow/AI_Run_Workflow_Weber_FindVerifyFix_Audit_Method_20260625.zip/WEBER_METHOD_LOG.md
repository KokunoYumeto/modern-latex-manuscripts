# Weber audit — method log (what works, what fails, adjustments)

Running record for the vol1 (Band I) grind. Companion to `WEBER_CERT_LOG.md` (per-fix provenance).
Loop started 2026-06-25 via `/loop "do vol 1 - keep meticulous logs of what works and adjust"`.

## The loop (validated on p100–107)
Per batch: render pages (`chunk_page.py`, 500-dpi native, 2400px chunks) → `weber_audit_workflow.js`
(audit agent/page → adversarial verify/fix, default REJECT) → **I hand-verify every surviving fix
against the scan** → apply verified ones to B139 `weber_v1_ge.tex` → `pdflatex` gate (0 errors AND
page count not dropped) → log to `WEBER_CERT_LOG.md`. One workflow at a time (rate-limit rule).

## What WORKS
- **Agent recall is high** — on p100–107 the agents found every real drop I'd found by hand.
- **Verify stage filters most false positives** (uniqueness + source-support, default reject).
- **Compile gate + page-count check** catches silent breakage (the SGA5 swallowed-page lesson).
- **Discipline holds** — agents preserve 1890s orthography, route source-typos to type-B (don't
  revert the editor's corrections), call parens/punctuation cosmetic.

## What FAILS (why the hand-check is mandatory)
- **Audit agents hallucinate drops/collapses that aren't in the `.tex`** (p105 eq5: claimed a
  one-line collapse; the `.tex` already had the correct two-line form). The verifier caught all 4
  on p105 — but in batch 1 one phantom slipped through *accepted* (p1 determinant, a page with no
  scan). **Verifier reliability varies.**
- **Phantom pages** when args are mangled or scans missing → agents invent content. (Fixed.)

## Adjustments
- 2026-06-25 — fixed `parseArgs` (handle stringified `{volume,axis,pages}`), `pad(3)` chunk names,
  `texOf` v1/v2/v3 path (was `vol1`).
- 2026-06-25 — added **no-scan guard** to `chunks()` (agent must bail, not hallucinate, if PNGs unreadable).
- 2026-06-25 — added **"CONFIRM ABSENCE BEFORE CLAIMING A DROP"** rule to the audit prompt (grep the
  `.tex` to confirm content is truly absent before emitting a drop-fix). Targets the eq5-type
  hallucination; effect measured from p108 onward.
- Batch size: 3 → 5 → trying 6. Tune by review load (every accepted fix = an eye-read of the scan).

## Metrics
| batch | pages | agents | tokens | clean pages | real fixes applied | false-pos rejected | phantom slipped | compile |
|-------|-------|--------|--------|-------------|--------------------|--------------------|-----------------|---------|
| 1 | p100–102 | 13 | 456k | p101 | 4 (p100 det row + deriv block; p102 a′₁ + dropped eq) | 1 (caught by me) | 1 (p1 dup, harmless) | 357pp/0err |
| 2 | p103–107 | 10 | 336k | p103,104,107 | 1 (p106 "VII." label) | 4 (all p105, by verifier) | 0 | 357pp/0err |

## Open / global decisions
- **"Coëfficient" diaeresis** — source has it, `.tex` drops it throughout. Systematic → decide once
  for the whole work, do NOT patch per page.
- Volume identity: vol1 = Band I confirmed (running heads "Zweiter/Dritter Abschnitt" + content match).
- Cursor: vol1 audited through **p323** (Buch II, §106–107; **§69 p212–216 still HELD for coherent rework**); next batch **p324–329** (rendered). Page count **360**. **~50% of vol1 done (HALFWAY).**

## Batch 38 (p318–323, run w5die8q32) — 15 agents, 479k tok
- §106–107 Rolle/Laguerre. **~10 applied, 4 clean.**
- **§107 \sum→S systematic:** Weber's sum-over-roots is the OPERATOR S (his §42 notation), not Σ. The .tex used \sum
  throughout §107; print + prose 'das Summenzeichen S' confirm S. Agent converted only eqs 4,7 → I did all (1–4,7).
  **New watch-class: \sum vs Weber's S operator — in root-sum contexts (Laguerre/§42-style) Weber writes S.**
- p323 also: phantom-block removal (eq 4), a dropped r²H covariant display (agent's rejected-on-uniqueness — I located
  + restored), a dropped (cx'+dy')² factor, eq renumbering (5/6/7). Rebuilt with \begin{equation}\tag (safe form),
  not the stray `\[ \tag \]` the .tex had.

## Batch 37 (p312–317, run wwhxovth2) — 10 agents, 346k tok
- §103 Klein's geometric comparison / §104 Laguerre upper bound. **4 applied, 0 rejected, 2 clean.**
- Small: dropped heading-author 'Klein's', dropped xref '(a. f. S.)', subscript f_n→f_{n-1}, 'in'→'im §4'.
- Descriptive/geometric §§ low density again; the f_{n-1} confirmed via the §4 definition block on the next page.

## Batch 36 (p306–311, run w1x9p9vuc) — 15 agents, 513k tok
- §101–102 Newton/Descartes/Jacobi criteria. **9 applied, 0 rejected, 2 clean.**
- Dropped content: Doppelreihe top row (p309), eq (2) 1st formula (p311), enumeration-caveat clause (p306). Sign
  inversion +,-,+→-,+,- and dropped coeff 3D (p311) — math-relevant, scan-confirmed.
- **OVER-INSERTION (rare):** .tex added 'Jacobi,' to a footnote starting 'Observatiunculae' (body already says 'hat
  Jacobi'). Same class as p242/p304 over-expansions — GPT draft occasionally ADDS plausible text.
- **don't-modernize:** 'aller reellen'→'aller reeller' (print's older strong genitive -er) — same class as Theil/giebt.

## Batch 35 (p300–305, run wa273i4qi) — 15 agents, 519k tok
- §99–100 Budan-Fourier theorem / Newton's rule. **~12 applied + 2 sign tables restored, 1 clean (p305).**
- **Restored 2 DROPPED SIGN TABLES** (p301-302, Budan-Fourier μ-gerade/μ-ungerade case analysis) the .tex collapsed
  into prose. Agent flagged them <0.6 ('can't reconstruct, spans page break') — but with BOTH scan pages I had every
  +/− entry and rebuilt confidently. **Lesson: an agent 'spans page break / can't reconstruct' flag is MINE to resolve —
  pull both pages and rebuild; don't accept the collapse as final.** Rendered as clean arrays.
- λ→𝔷 (Fraktur z=Zahl/count) systematic ×3; zoom-confirmed. p304 eq (6) garble + eq (4) self-contradiction (F_n=1 vs
  F_n=f_n²) + an over-expansion — computation §§ keep garbling.

## Batch 34 (p294–299, run w3c0efzrk) — 8 agents, 314k tok
- §94–98 fundamental theorem of algebra. **2 applied, 0 rejected, 5 clean.**
- Both small (eq-into-sentence period→comma + d.h. lowercase). §95–98 (the geometric FTA proof) transcribed well.
- Footnotes on p296 (Gauss 1799), p299 (Sturm) PRESENT in .tex — footnote-drop pattern NOT recurring in these §§.

## Batch 33 (p288–293, run w2jxi5lw0) — 13 agents, 427k tok
- §93–94 Charakteristikentheorie. **8 applied, 0 rejected, 3 clean.**
- **a→α systematic (×4):** intersection-point label is Greek α; .tex had Latin a. Zoom-confirmed (crop_src.py) —
  important because the doc legitimately uses Latin a for COUNTS ('Ist a die Anzahl der Punkte A') on the SAME spread.
  So a/α is a real two-alphabet distinction; ALWAYS zoom a-vs-α, never assume from context.
- p292 dropped eq member (= via eq (2)), p288 parens, p289 connective — small.

## Batch 32 (p282–287, run wqtorxz0i) — 23 agents, 734k tok
- §89–93 Hermite-form discriminant determinant + characteristic theory. **16 applied, 2 clean.** Dense — Buch II isn't
  uniformly clean; computation-heavy §§ still garble.
- **TWO systematic notation conversions:** h_{i,k}→H_{i,k} (p284 bilinear-form coeffs) and θ→Φ (p286 arbitrary function;
  θ would clash with the angle ϑ=\vartheta). Both whole-passage. Verifier rejected 1 cell of EACH on bad-grep
  uniqueness — my own grep confirmed they exist, applied. **Verifier grep escaping is unreliable; trust my Grep over the verifier's uniqueness-fail.**
- **Restored a dropped determinant-decomposition block** (p284): |f_k(x_i)|=|a_0-triangular|×|Vandermonde| + a_0^{2n-2}→a_0²
  coefficient fix. Math-verified (product²=a_0^{2n}Π²=a_0²D). +1 page (359→360).
- **eq (6) uniform-range check:** the 3 sums must share range 0..n-1 (the .tex had n-2, 0 on lines 2-3). Use the uniform
  structure of a multiline sum to catch per-line limit errors.

## Batch 31 (p276–281, run wf8ghhsen) — 6 agents, 211k tok
- §88 Säculargleichung. **0 applied — ALL 6 pages CLEAN.** First fully-clean batch.
- **Σ-notation boundary clarified:** p277 .tex `\sum_{i=1}^n` vs print `\sum_{1,n}^{i}` = LEFT (cosmetic). Distinct from
  p255/p259 where the .tex had bare `\sum_1^m` (index variable DROPPED → fixed). **Rule: fix when the index variable is
  LOST; leave when complete but in conventional layout** (accept minor doc-internal Σ-style variation as the result).
- Confirms Buch II has genuinely clean whole sections (GPT draft transcribed §88 well). Agent auto-scaled to 6.

## Batch 30 (p270–275, run wns0kdpad) — 12 agents, 413k tok
- §85–87 Sturm chains. **6 applied, 0 rejected, 3 clean.**
- **Fraktur label (1)→(ℜ):** the .tex digitized Weber's Fraktur chain name `ℜ` (Reihe) as `(1)`. The AGENT was internally
  inconsistent (read K on p272, R on p273) and the VERIFIER disagreed (R) → classic zoom-it situation. crop_src.py
  confirmed Fraktur ℜ. **Lesson: when agent vs verifier disagree on a glyph (esp. Fraktur K/R), ZOOM — don't average.**
- Did it as a systematic 5-instance label fix (eq tag + all in-text refs), one consistent letter.
- **New Fraktur watch-class:** Fraktur letters in parens used as labels get digitized to numbers (𝔯→'1'). Watch for stray
  '(1)/(2)' in-text refs that should be Fraktur names, esp. in the Galois chapters (Gruppe 𝔊, etc.).

## Batch 29 (p264–269, run wtx630oo8) — 7 agents, 244k tok
- §83–84. **1 applied, 0 rejected, 5 clean.**
- p264 = 2nd `\`-macro escape-corruption (`\nu`→newline+`u`; cf. p194 `\\eta`). These compile fine but render WRONG
  (silent). Ran sweep `\$\\(pi|mu|nu|rho|tau|chi|phi|psi),?\s*$` → 1 candidate ~line 19660 CHECKED = FALSE POSITIVE
  (legit line-wrapped list `$\psi,`⏎`\psi_1,`⏎`\ldots`). **Discriminator: a REAL corruption's next line starts with a
  non-macro fragment (p264 next line was `u$`); a legit wrap continues with `\macro`.** So the sweep is a triage, not
  a verdict — eyeball the next line.
- **New standing check: escape-corruptions are SILENT (0 compile errors, wrong glyph). The line-end-macro grep is a
  cheap periodic sweep — re-run each major section.**

## Batch 28 (p258–263, run w3kk5thy0) — 19 agents, 592k tok
- §81–83 quadratic forms / vanishing determinants. **13 applied, 0 rejected, 3 clean.**
- **Systematic `ξ`→`z` across §81** (10 instances): the .tex consistently mistranscribed Weber's Latin linear-form
  variable z as Greek ξ. Did the whole passage as ONE conversion.
- **Verifier signal worth noting:** it REJECTED a single ξ→z cell with reason 'needs uniform conversion, not a single
  line'. Treat that kind of rejection as 'DO the whole passage', not 'skip' — the verifier is flagging systematicity.
- Σ double-index (Σ_{1,k}^{r,s}) collapsed to Σ_1^k AGAIN (now p255, p259×2) — Weber's range-on-bottom/indices-on-top
  Σ is a recurring transcription loss; watch it in every quadratic-form sum.

## Batch 27 (p252–257, run wj6z5uigg) — 9 agents, 331k tok
- §79 Bezoutiante/Realität + §80 Trägheit (inertia of quadratic forms). **3 applied, 0 rejected, 3 clean.**
- All 3 small symbol/form fidelity fixes: dropped `±`, transposed eq (π+ν=n-1), Weber's double-index Σ_{1,m}^{i,k}.
  Buch II error profile = small single-symbol/form deviations (vs Buch I's dropped derivation blocks).
- Consistent rule on transposed equations (π+ν+1=n vs π+ν=n-1): MATCH the print = type-A faithfulness, NOT cosmetic
  (a transposition across '=' changes the literal form, unlike a commutative reorder which stays cosmetic).

## Batch 26 (p246–251, run wpkamn8yq) — 9 agents, 326k tok
- §78 biquadratic discussion. **3 applied, 0 rejected, 4 clean.**
- 2 more dropped §-end footnotes (Kronecker/Dyck, Clebsch/Faà di Bruno) — drop pattern continues (now
  p209, p210, p233×2, p250×2). The footnote-presence sweep is increasingly worth doing.
- `-I^2`→`-T^2`: caught by .tex-internal consistency (§66 (7) uses -T²) + zoom-clear scan. T/I confusion = another
  single-glyph misread class to watch in Buch II.

## Batch 25 (p240–245, run w7dhyhsih) — 8 agents, 272k tok
- §76–78 root reality / Sturm. **2 applied, 0 rejected, 4 clean.**
- **First clear OVER-EXPANSION:** p242 the .tex ADDED the full discriminant product where Weber printed only a
  representative factor `(x_1-x_2)²` (prose covers 'sämmtliche Wurzeldifferenzen'). So the GPT draft doesn't only
  drop — it occasionally 'helpfully' expands shorthand. Confirms the audit must (and does) flag .tex-content-not-
  on-page, both directions.
- Buch II staying low-density (4/6 clean), as expected for root/Galois theory vs the garbled invariant-theory Buch I.

## Batch 24 (p234–239, run wszgm639n) — 7 agents, 265k tok
- §75/76 end of Erstes Buch → 'Zweites Buch. Die Wurzeln' divider (p239). **1 applied, 0 rejected, 5 clean.**
- Density dropped sharply (5/6 clean) now that the invariant-theory/transformation chapters are done — expect
  lower fix-rates in Buch II (root/Galois theory). Agent auto-scaled DOWN to 7 (vs 30 in §71); the scaling
  tracks candidate density well, so token cost will fall through the cleaner chapters.
- p235 sign fix confirmed by math (next eq) + scan.

## Batch 23 (p228–233, run wv6xbxijm) — 20 agents, 611k tok
- §73 Bezoutiante + §74/75. **12 applied, 0 rejected, 3 clean (p230–232).**
- **Systematic `t`→`τ` across a whole table column** (E-table right factor column). Handled as ONE whole-column
  rewrite (12 cells) not 12 patches — the systematic-notation rule again. This auto-fixed the 2 cells the verifier
  rejected (one uniqueness-fail on its scoped old_string, one a_0/a_1 misread).
- **Verifier a_0/a_1 misread caught by row-pattern + zoom:** verifier claimed E_{1,3}=3a_0τ_0; the row pattern
  (3a_1 in E_{1,1},E_{1,2}) said 3a_1; crop_src.py zoom confirmed 3a_1. The f'(t)-coefficient structure of the
  column is a strong internal check — use structural patterns to overrule single-cell agent/verifier reads.
- 2 dropped §-end bibliographic footnotes restored (Cayley, Gordan). **Recurring pattern: §-end citation footnotes
  keep getting dropped (p209, p210, p233×2).** Candidate for a targeted footnote-presence sweep across vol1.

## Batch 22 (p222–227, run wxv40r1h5) — 16 agents, 523k tok
- §71 Cardano tail + §72 general transformation. **10 applied, 0 rejected, 3 clean (p225–227).**
- §72 is back to normal density (3 clean pages) after the §68–71 garbled stretch. §71's Cardano tail (p222)
  was still heavy — a big multi-equation derivation block badly garbled, restored from the scan + verified
  internally consistent.
- `\varrho` misread as `\Omega` (curly-rho → capital-omega): single systematic symbol, fixed at both occurrences.
- **agent restructure block (#5) matched the scan exactly AND was internally math-consistent — when BOTH hold,
  a big block restore is safe.** (Contrast §69, where the agent grafts were mutually inconsistent → held.) This
  is the discriminator for "restore vs hold" on big garbled blocks.

## Batch 21 (p216–221, run w1buniwck) — 30 agents, 915k tok (worst region, §70–71)
- §70 Hermite-satz + §71 cubic transformation. **20 applied, 1 Weber erratum flagged, 0 clean pages.**
- §71 (cubic) is computation-dense → many dropped/garbled coefficients (dropped `a_0^λ`, `a_0^{n-1}`,
  the whole `Q_0=…` RHS, the `Q_0` line; wrong exponents `x_1→x_1²`; `-tH`→`-2/3 H`).
- **Built `crop_src.py`** (the long-pending tight-zoom tool): renders a fractional page box at high dpi +
  upscales, for glyphs the width-capped chunks can't resolve. Used it to settle a 2/3-vs-2/9 denominator →
  confirmed Weber printed 2/3 (a genuine erratum; math demands 2/9, proven two ways).
- **Math cross-checks caught a real fork the agents missed:** agent #14 (`3Q_0=⅔H·Q_2-a_1f`) and #18
  (`Q_0=-⅔t_0H`) are mutually inconsistent ×3. Re-deriving independently (sum of eq (9); and matching eq (10)
  to 3·eq (9)) proved #14 right and Weber's printed `Q_0` wrong. **LESSON: on computation-dense pages, derive
  the relations yourself — agent fixes can each be plausible but mutually inconsistent.**
- **Half-made agent fix completed by me:** eq (5) — the agent fixed only the prose (`y_1-y_2`) and left the
  equation in general `i,k` form; I restored the print's specific `1,2` + plain fraction. Always cross-check the
  WHOLE display when the agent flags only its prose.
- θ→t was a systematic Greek→Latin (3 spots) — fixed together (whole-section consistency), per the batch-20 rule.

## Batch 20 (p210–215, run wgfxgnw5z) — 27 agents, 894k tok (worst region yet)
- §68–69 Tschirnhausen/Hermite transformation. **§68: 5 applied. §69: 10 HELD.**
- §68 (p210–211) was genuine same-edition garbling (dropped Hermite footnote; eqs (3),(4),(6),(9) all
  index-shifted or wrong-LHS) — verified + applied like any batch.
- **§69 (p213–215) is the first STRUCTURAL hold.** The .tex confused Weber's `Φ(τ,ξ)` with `H` (symbol
  collision) and dropped the `Φ_ν` expansions + a derivation block. The verify stage flagged it as a
  possible 'edition difference' and rejected the piecemeal Φ-graft. My read: confused transcription, not
  a different edition — but it needs a COHERENT whole-section rework, not loop patches. Flagged in cert log.
- **New rule: when a section shows a SYSTEMATIC notation collision (one symbol consistently standing in
  for another, with internal self-consistency), HOLD the whole section for a dedicated coherent pass — do
  NOT apply the agent's per-line grafts (they make a broken hybrid).** Same lesson as the SGA5 global-notation
  decisions: systematic = decide once, section-wide; never piecemeal.
- 27-agent auto-scale: the workflow scaled up because §68–69 had ~20+ candidates. High recall, but the §69
  structural issue is exactly what per-page agents can't resolve (no whole-section context). Reconfirms that
  whole-section human judgment is the gate, not the swarm.

## Batch 19 (p204–209, run w1agyukjg) — 17 agents, 549k tok (dense)
- §65–67 invariant theory: **11 applied, 0 rejected, p204 clean.** Dropped derivation block, weight
  exponent r^{2μ}, I→I' ×3, an inverted substitution (ξ'=λξ→ξ=λξ' + matching coeff exponents — both are
  consistent conventions, so I matched the print and moved both together), χ→ψ ×2, generator-list order,
  a dropped bibliography footnote.
- **Faint-scan lesson:** the p209 chunk renders were washed-out → I deferred the footnote, re-rendered the
  FULL page (clear), verified the 4 citations exactly, then applied. **New step: when a chunk is too faint
  to read, re-render `--full` before deciding — don't guess, don't silently drop.**

## Batch 18 (p198–203, run w97rvytee) — 9 agents, 325k tok
- **3 applied (p198 dropped Q^τ + dropped display; p203 discriminant exponent via homogeneity), 0 rejected,
  4 clean.** The p203 fix is a clean math-verified catch: D's two terms must share degree 6, so the .tex's
  −4a'_1a'_3³ (deg 4) → −4a'_1³a'_3³ (deg 6).

## Batch 17 (p192–197, run w6wwajy55) — 18 agents, 574k tok (densest yet)
- §62–63 cubic-form invariant theory: **10 applied, 2 rejected, p193 clean.** Heavy garbling — a `\\eta`
  LaTeX corruption, a garbled identische-Relationen equation (wrong primes+subscripts+structure), 2 dropped
  clauses, wrong exponents (α,β vs h,k), a fabricated 2-step λ−2α chain, a dropped D^{-1/6} exponent.
- Rejects: γ→σ (6th revert-the-editor; print's σ is a typo, the proof is about γ) + a "remove ist" skip.
- **Note:** dense invariant-theory pages need full math reasoning (verified the λ−2α equivalence via eq (3);
  confirmed D^{-1/6} via r⁶=−27/D) AND reading multiple chunks — the disputed equations straddled chunk
  boundaries, so I fetched p195_top / p197_bot in a 2nd pass before deciding.

## Batch 16 (p186–191, run wsm4x3nui) — 7 agents, 246k tok
- **1 applied (p188 dropped word "den"), 0 rejected, 5 clean.** §60 (covariants / Hessian) well-transcribed.
  The commutative-cosmetic rule is now firing in-agent (a_0 r^n vs r^n a_0 auto-classified cosmetic).

## Batch 15 (p180–185, run wkgrk0q50) — 10 agents, 354k tok
- **0 applied; p183/184 clean; all candidates cosmetic or revert-the-editor.** §57–59 (quadratic forms /
  functional determinant) is well-transcribed.
- Key reject: p185 `Φ'`→`Φ` — the .tex's Φ' (partial derivative = coeff of t in the Taylor expansion,
  parallel to F') is math-correct; the print dropped the prime. 5th revert-the-editor catch.
- Skipped as cosmetic: dummy summation-index name (i vs ν) and Σ-index placement (\sum_i vs \sum^i) —
  no math meaning; the .tex's consistent choices are defensible standardizations.

## Batch 14 (p174–179, run wh4r37hzt) — 10 agents, 343k tok
- **4 applied, 0 rejected, 3 clean.** Notable: a dropped section-divider heading (Fünfter Abschnitt /
  Lineare Transformation) — first dropped-heading catch in vol1; plus a dropped α_0 (caught via the
  .tex's own "vier Verhältnisse" internal inconsistency) and reversed transformation-coeff indices
  a_{ν,i}→a_{i,ν}.
- **New watch category:** Abschnitt section-divider headings sit between sections and are easy for the
  transcription to skip — check page tops at section boundaries.

## Batch 13 (p168–173, run w0h0vvsc5) — 8 agents, 281k tok
- **1 applied (p172 dropped ν-equation + "und"), 1 rejected (p172 s-subscript (n-1)→(n+1), 4th
  revert-the-editor catch), 5 clean.** §52 mixed a genuine drop and a source-typo-revert temptation on
  the SAME page — verify each candidate independently, even within one page.

## Batch 12 (p162–167, run wbi1e27lk) — 7 agents, 246k tok
- **0 applied, 1 rejected by me, 5 clean.** The reject (p162 "Endgleichung für z"→"x") is the 3rd
  revert-the-editor/inject-error catch (cf. batches 7, 11): eliminating x,y can't give an equation "für x";
  the §50 chain is x→y→z so the end-equation is in z (.tex correct). Agent's reasoning self-contradictory again.
- **Standing pattern:** in well-transcribed regions a large share of agent "accepted" candidates are
  attempts to revert correct .tex readings to source typos — caught by math/context, not by the verifier.

## Batch 11 (p156–161, run wokiihclr) — 9 agents, 318k tok
- **2 prose fixes applied (p160, p161), 1 rejected by me, 3 clean.** The reject (p158 eq (14), resultant
  degrees) was the hardest call so far: the agent's fix would have INJECTED a Weber error into the
  math-correct .tex. Settled by a concrete n=2/m=1 example (Σν=m, Σμ=n is the truth). The agent's own
  type-B note had the right reasoning while its fix contradicted it — classic "verify the MATH, not the agent."
- Found a paired Weber erratum: §49 (5) `nν+mμ` should be `mν+nμ` (same swap); the .tex reproduces it
  faithfully — left type-B (notes the .tex's eq14-corrected vs §49(5)-faithful internal inconsistency).

## Batch 10 (p150–155, run wxyrbtpam) — 8 agents, 270k tok
- **1 applied (p154 β−γ sign error −u+v→u−v), 1 rejected by me (revert-the-editor: p155 dropped a_4 — the
  quartic needs all 5 coeffs), 4 clean.** The sign error is a good catch (a real math error in the .tex);
  the a_4 reject is the familiar "keep the editor's completion of a source oversight" pattern (cf. Collectet, (19)/(20)).

## Batch 9 (p144–149, run wmbmrvo7l) — 9 agents, 305k tok
- Low-density: **2 small fixes (p144 dropped word "etwa", p148 dropped 0 in a tuple), 3 clean, 1 correctly
  rejected** (verifier kept the authentic ".tex etc."). §44–45 symmetric-functions text is well-transcribed.

## Batch 8 (p138–143, run wo4jo4wfi) — 16 agents, 519k tok
- §41–43 symmetric functions: **9 real fixes applied, 1 correctly rejected by the verifier, p138 clean.**
  Many dropped equation lines/terms (f_3 line, eq (4) first line, eq (11) long form, +A_{m-1}α) + a dropped
  Newton footnote + a `\Pi(n)`→`n!` notation modernization.
- **Verifier got one right** (rejected p140 x→n, keeping the .tex's correct "n") — inconsistent but not useless.
- Weber's factorial is `\Pi(n)`, not `n!`; the .tex sometimes modernizes it — watch for more. Orthography
  policy holding: fix lone spelling slips (sämtlich→sämmtlich), defer systematic modernizations (Theil/teil).

## Batch 7 (p132–137, run w0za37gy4) — 9 agents, 323k tok
- **0 fixes applied. 4 clean (p132/133/136/137). All 3 agent candidates REJECTED on review** — the
  strongest "hand-check is the gate" data point yet (the verifier passed all 3):
  - p134 ×2: agent escalated Weber's double-bar `≦` (= ≤) to `\gtreqless` (⋛); the .tex `\le` is correct
    (prose "innerhalb oder an der Grenze" + the math both say ≤). The agent even described it as ≦ but mislabeled it.
  - p135: revert-the-editor xref (print "(20),(21)" is an off-by-one source typo; .tex correct "(19),(20)" kept).
- **Adjustment applied:** rule added — Weber's `≦/≧` are leqq/geqq (cosmetic `\le/\ge`), never escalate to `\gtreqless`/3-way.
- **Verifier scorecard:** it has now passed false candidates I rejected in batches 1, 4, and 7; reliable
  filtering only in batch 2. The verify stage is a WEAK filter; my eye is the gate.

## Batch 6 (p126–131, run wtfu7alt6) — 16 agents, 561k tok (densest yet)
- §38–39 Fundamental-Theorem convergence proof: **10 real fixes, 0 rejected, p127 clean.** Highest-value
  batch — the math was garbled in consequential ways: systematic θ→Θ (×4), a `kleiner`↔`grösser`
  inequality-direction inversion, several dropped general terms, a mis-tagged eq (11) with a dropped
  equation, a dropped QED.
- **New adjustment/check:** an agent "restructure" patch un-tagged a display using `\begin{equation}`
  (which auto-numbers) where the doc convention is `\[…\]`. I corrected it on apply. RULE: inspect any
  agent restructure that adds/converts an equation environment for spurious auto-numbering.
- Dense proof pages → many interrelated fixes; 16 agents auto-spun (561k tok). Consider 4-page batches
  in proof-dense regions to cap review load.

## Batch 5 (p120–125, run wnbmmoci2) — 10 agents, 348k tok
- 4 real fixes, all single-symbol/variable misreads (p121 d→δ ×2; p123 spurious "=y+iz" removed; p124 γ→y localized); p120/122/125 clean, 0 rejected.
- **Pattern emerging:** this region's errors are Greek/Latin glyph confusions (d/δ, γ/y, and ε/ξ in batch 4)
  — the dominant vol1 failure mode is **single-glyph misreads, not big drops**. Cheap for agents to find,
  easy to eye-verify, but they MATTER (wrong variable). Verifier passed all 4 (correct this time).
- Cosmetic discipline held: kept "kann" (Weber typo "kan"→type-B), `≦`→`\le`.

## Batch 4 (p114–119, run w4kwfrqpa) — 12 agents, 386k tok
- 5 real fixes applied (p114 roots-of-unity ξ→ε ×3 + bogus-eq removal/restore; p118 xref (1)→(6)); p115/116/117 clean.
- **I rejected 1 the verifier passed:** p119 `Collected`→`Collectet` — agent tried to revert the editor's
  correction of Weber's misprint (and self-contradictorily flagged it type-B too). The "don't revert
  obvious-typo corrections" rule is already in the prompt; the agent still violated it → hand-check is the gate.
- p114 was the fix-dense page: one symbol misread (ε→ξ) propagated to 4 spots plus a fabricated equation —
  exactly the kind of cascading transcription error worth catching.

## Batch 3 (p108–113, run wahdj8vfy) — 13 agents, 440k tok
- Verifier accepted **ALL 8** candidates (0 rejected) → the **hand-check did all the filtering**: I
  applied 5 real, SKIPPED 2 as cosmetic (p111 `ci`↔`ic` commutative reorder), p110 clean.
- The **confirm-absence rule worked**: the p109 agent grepped for the dropped `√[2n]` equation,
  found none, and correctly flagged the drop (no false "it's there").
- **Adjustment applied (active from p114):** "commutative reordering is cosmetic, never type-A" rule
  added to the audit prompt — directly targets the p111 over-flags.
- **Observation:** verifier reliability is inconsistent (filtered 4/4 in batch 2, 0/8 here) — my eye
  is the real gate, not the verify stage. Dense pages (8 candidates/6 pp) → keep batches ≤6 in this region.
