# Weber audit — method log (what works, what fails, adjustments)

Running record for the vol1 (Band I) grind. Companion to `WEBER_CERT_LOG.md` (per-fix provenance).
Loop started 2026-06-25 via `/loop "do vol 1 - keep meticulous logs of what works and adjust"`.

## The loop (validated on p100–107)
Per batch: render pages (`chunk_page.py`, 500-dpi native, 2400px chunks) → `weber_audit_workflow.js`
(audit agent/page → adversarial verify/fix, default REJECT) → **I hand-verify every surviving fix
against the scan** → apply verified ones to B139 `weber_v1_ge.tex` → `pdflatex` gate (0 errors AND
page count not dropped) → log to `WEBER_CERT_LOG.md`. One workflow at a time (rate-limit rule).

## What WORKS
- **Agent recall is high** — on p100–107 the agents found every real drop I'd found by hand.
- **Verify stage filters most false positives** (uniqueness + source-support, default reject).
- **Compile gate + page-count check** catches silent breakage (the SGA5 swallowed-page lesson).
- **Discipline holds** — agents preserve 1890s orthography, route source-typos to type-B (don't
  revert the editor's corrections), call parens/punctuation cosmetic.

## What FAILS (why the hand-check is mandatory)
- **Audit agents hallucinate drops/collapses that aren't in the `.tex`** (p105 eq5: claimed a
  one-line collapse; the `.tex` already had the correct two-line form). The verifier caught all 4
  on p105 — but in batch 1 one phantom slipped through *accepted* (p1 determinant, a page with no
  scan). **Verifier reliability varies.**
- **Phantom pages** when args are mangled or scans missing → agents invent content. (Fixed.)

## Adjustments
- 2026-06-25 — fixed `parseArgs` (handle stringified `{volume,axis,pages}`), `pad(3)` chunk names,
  `texOf` v1/v2/v3 path (was `vol1`).
- 2026-06-25 — added **no-scan guard** to `chunks()` (agent must bail, not hallucinate, if PNGs unreadable).
- 2026-06-25 — added **"CONFIRM ABSENCE BEFORE CLAIMING A DROP"** rule to the audit prompt (grep the
  `.tex` to confirm content is truly absent before emitting a drop-fix). Targets the eq5-type
  hallucination; effect measured from p108 onward.
- Batch size: 3 → 5 → trying 6. Tune by review load (every accepted fix = an eye-read of the scan).

## Metrics
| batch | pages | agents | tokens | clean pages | real fixes applied | false-pos rejected | phantom slipped | compile |
|-------|-------|--------|--------|-------------|--------------------|--------------------|-----------------|---------|
| 1 | p100–102 | 13 | 456k | p101 | 4 (p100 det row + deriv block; p102 a′₁ + dropped eq) | 1 (caught by me) | 1 (p1 dup, harmless) | 357pp/0err |
| 2 | p103–107 | 10 | 336k | p103,104,107 | 1 (p106 "VII." label) | 4 (all p105, by verifier) | 0 | 357pp/0err |

## Open / global decisions
- **"Coëfficient" diaeresis** — source has it, `.tex` drops it throughout. Systematic → decide once
  for the whole work, do NOT patch per page.
- Volume identity: vol1 = Band I confirmed (running heads "Zweiter/Dritter Abschnitt" + content match).
- Cursor: vol1 audited through **p185**; next batch **p186–191** (rendered). Page count 358.

## Batch 15 (p180–185, run wkgrk0q50) — 10 agents, 354k tok
- **0 applied; p183/184 clean; all candidates cosmetic or revert-the-editor.** §57–59 (quadratic forms /
  functional determinant) is well-transcribed.
- Key reject: p185 `Φ'`→`Φ` — the .tex's Φ' (partial derivative = coeff of t in the Taylor expansion,
  parallel to F') is math-correct; the print dropped the prime. 5th revert-the-editor catch.
- Skipped as cosmetic: dummy summation-index name (i vs ν) and Σ-index placement (\sum_i vs \sum^i) —
  no math meaning; the .tex's consistent choices are defensible standardizations.

## Batch 14 (p174–179, run wh4r37hzt) — 10 agents, 343k tok
- **4 applied, 0 rejected, 3 clean.** Notable: a dropped section-divider heading (Fünfter Abschnitt /
  Lineare Transformation) — first dropped-heading catch in vol1; plus a dropped α_0 (caught via the
  .tex's own "vier Verhältnisse" internal inconsistency) and reversed transformation-coeff indices
  a_{ν,i}→a_{i,ν}.
- **New watch category:** Abschnitt section-divider headings sit between sections and are easy for the
  transcription to skip — check page tops at section boundaries.

## Batch 13 (p168–173, run w0h0vvsc5) — 8 agents, 281k tok
- **1 applied (p172 dropped ν-equation + "und"), 1 rejected (p172 s-subscript (n-1)→(n+1), 4th
  revert-the-editor catch), 5 clean.** §52 mixed a genuine drop and a source-typo-revert temptation on
  the SAME page — verify each candidate independently, even within one page.

## Batch 12 (p162–167, run wbi1e27lk) — 7 agents, 246k tok
- **0 applied, 1 rejected by me, 5 clean.** The reject (p162 "Endgleichung für z"→"x") is the 3rd
  revert-the-editor/inject-error catch (cf. batches 7, 11): eliminating x,y can't give an equation "für x";
  the §50 chain is x→y→z so the end-equation is in z (.tex correct). Agent's reasoning self-contradictory again.
- **Standing pattern:** in well-transcribed regions a large share of agent "accepted" candidates are
  attempts to revert correct .tex readings to source typos — caught by math/context, not by the verifier.

## Batch 11 (p156–161, run wokiihclr) — 9 agents, 318k tok
- **2 prose fixes applied (p160, p161), 1 rejected by me, 3 clean.** The reject (p158 eq (14), resultant
  degrees) was the hardest call so far: the agent's fix would have INJECTED a Weber error into the
  math-correct .tex. Settled by a concrete n=2/m=1 example (Σν=m, Σμ=n is the truth). The agent's own
  type-B note had the right reasoning while its fix contradicted it — classic "verify the MATH, not the agent."
- Found a paired Weber erratum: §49 (5) `nν+mμ` should be `mν+nμ` (same swap); the .tex reproduces it
  faithfully — left type-B (notes the .tex's eq14-corrected vs §49(5)-faithful internal inconsistency).

## Batch 10 (p150–155, run wxyrbtpam) — 8 agents, 270k tok
- **1 applied (p154 β−γ sign error −u+v→u−v), 1 rejected by me (revert-the-editor: p155 dropped a_4 — the
  quartic needs all 5 coeffs), 4 clean.** The sign error is a good catch (a real math error in the .tex);
  the a_4 reject is the familiar "keep the editor's completion of a source oversight" pattern (cf. Collectet, (19)/(20)).

## Batch 9 (p144–149, run wmbmrvo7l) — 9 agents, 305k tok
- Low-density: **2 small fixes (p144 dropped word "etwa", p148 dropped 0 in a tuple), 3 clean, 1 correctly
  rejected** (verifier kept the authentic ".tex etc."). §44–45 symmetric-functions text is well-transcribed.

## Batch 8 (p138–143, run wo4jo4wfi) — 16 agents, 519k tok
- §41–43 symmetric functions: **9 real fixes applied, 1 correctly rejected by the verifier, p138 clean.**
  Many dropped equation lines/terms (f_3 line, eq (4) first line, eq (11) long form, +A_{m-1}α) + a dropped
  Newton footnote + a `\Pi(n)`→`n!` notation modernization.
- **Verifier got one right** (rejected p140 x→n, keeping the .tex's correct "n") — inconsistent but not useless.
- Weber's factorial is `\Pi(n)`, not `n!`; the .tex sometimes modernizes it — watch for more. Orthography
  policy holding: fix lone spelling slips (sämtlich→sämmtlich), defer systematic modernizations (Theil/teil).

## Batch 7 (p132–137, run w0za37gy4) — 9 agents, 323k tok
- **0 fixes applied. 4 clean (p132/133/136/137). All 3 agent candidates REJECTED on review** — the
  strongest "hand-check is the gate" data point yet (the verifier passed all 3):
  - p134 ×2: agent escalated Weber's double-bar `≦` (= ≤) to `\gtreqless` (⋛); the .tex `\le` is correct
    (prose "innerhalb oder an der Grenze" + the math both say ≤). The agent even described it as ≦ but mislabeled it.
  - p135: revert-the-editor xref (print "(20),(21)" is an off-by-one source typo; .tex correct "(19),(20)" kept).
- **Adjustment applied:** rule added — Weber's `≦/≧` are leqq/geqq (cosmetic `\le/\ge`), never escalate to `\gtreqless`/3-way.
- **Verifier scorecard:** it has now passed false candidates I rejected in batches 1, 4, and 7; reliable
  filtering only in batch 2. The verify stage is a WEAK filter; my eye is the gate.

## Batch 6 (p126–131, run wtfu7alt6) — 16 agents, 561k tok (densest yet)
- §38–39 Fundamental-Theorem convergence proof: **10 real fixes, 0 rejected, p127 clean.** Highest-value
  batch — the math was garbled in consequential ways: systematic θ→Θ (×4), a `kleiner`↔`grösser`
  inequality-direction inversion, several dropped general terms, a mis-tagged eq (11) with a dropped
  equation, a dropped QED.
- **New adjustment/check:** an agent "restructure" patch un-tagged a display using `\begin{equation}`
  (which auto-numbers) where the doc convention is `\[…\]`. I corrected it on apply. RULE: inspect any
  agent restructure that adds/converts an equation environment for spurious auto-numbering.
- Dense proof pages → many interrelated fixes; 16 agents auto-spun (561k tok). Consider 4-page batches
  in proof-dense regions to cap review load.

## Batch 5 (p120–125, run wnbmmoci2) — 10 agents, 348k tok
- 4 real fixes, all single-symbol/variable misreads (p121 d→δ ×2; p123 spurious "=y+iz" removed; p124 γ→y localized); p120/122/125 clean, 0 rejected.
- **Pattern emerging:** this region's errors are Greek/Latin glyph confusions (d/δ, γ/y, and ε/ξ in batch 4)
  — the dominant vol1 failure mode is **single-glyph misreads, not big drops**. Cheap for agents to find,
  easy to eye-verify, but they MATTER (wrong variable). Verifier passed all 4 (correct this time).
- Cosmetic discipline held: kept "kann" (Weber typo "kan"→type-B), `≦`→`\le`.

## Batch 4 (p114–119, run w4kwfrqpa) — 12 agents, 386k tok
- 5 real fixes applied (p114 roots-of-unity ξ→ε ×3 + bogus-eq removal/restore; p118 xref (1)→(6)); p115/116/117 clean.
- **I rejected 1 the verifier passed:** p119 `Collected`→`Collectet` — agent tried to revert the editor's
  correction of Weber's misprint (and self-contradictorily flagged it type-B too). The "don't revert
  obvious-typo corrections" rule is already in the prompt; the agent still violated it → hand-check is the gate.
- p114 was the fix-dense page: one symbol misread (ε→ξ) propagated to 4 spots plus a fabricated equation —
  exactly the kind of cascading transcription error worth catching.

## Batch 3 (p108–113, run wahdj8vfy) — 13 agents, 440k tok
- Verifier accepted **ALL 8** candidates (0 rejected) → the **hand-check did all the filtering**: I
  applied 5 real, SKIPPED 2 as cosmetic (p111 `ci`↔`ic` commutative reorder), p110 clean.
- The **confirm-absence rule worked**: the p109 agent grepped for the dropped `√[2n]` equation,
  found none, and correctly flagged the drop (no false "it's there").
- **Adjustment applied (active from p114):** "commutative reordering is cosmetic, never type-A" rule
  added to the audit prompt — directly targets the p111 over-flags.
- **Observation:** verifier reliability is inconsistent (filtered 4/4 in batch 2, 0/8 here) — my eye
  is the real gate, not the verify stage. Dense pages (8 candidates/6 pp) → keep batches ≤6 in this region.
