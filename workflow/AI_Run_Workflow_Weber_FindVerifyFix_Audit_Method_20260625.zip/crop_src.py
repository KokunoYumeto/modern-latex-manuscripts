"""Tight high-dpi crop of a printed Weber page region — for settling ambiguous glyphs
(e.g. a denominator that could be 3 or 9) that the width-capped chunk renders can't resolve.

Usage:
  python crop_src.py VOL PRINTED X0 Y0 X1 Y1 [DPI] [SCALE]
    X0 Y0 X1 Y1 : crop box as fractions of the page (0..1), top-left origin.
    DPI         : render dpi before crop (default 600; source detail ceiling ~500).
    SCALE       : upscale the crop for display legibility (default 3).
Reads source pdf + printed->pdf offset from audit_manifest.json (same as chunk_page.py),
so it can never disagree with the manifest. Writes to src/<vol>_p<NNN>_crop_<x0>_<y0>.png
"""
import sys, os, json
import fitz
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
m = json.load(open(os.path.join(HERE, "audit_manifest.json"), encoding="utf-8"))
VOL = {}
for u in m["units"]:
    VOL.setdefault(u["volume"], {"pdf": u["source_pdf"],
                                 "offset": u["pdf_page"] - u["printed_page"]})

a = sys.argv[1:]
if len(a) < 6:
    raise SystemExit(__doc__)
vol = a[0] if a[0] in VOL else "vol" + a[0]
printed = int(a[1])
x0, y0, x1, y1 = map(float, a[2:6])
dpi = int(a[6]) if len(a) > 6 else 600
scale = float(a[7]) if len(a) > 7 else 3.0

off = VOL[vol]["offset"]
d = fitz.open(VOL[vol]["pdf"])
pg = d[printed + off - 1]
pm = pg.get_pixmap(dpi=dpi, colorspace=fitz.csGRAY)
im = Image.frombytes("L", (pm.width, pm.height), pm.samples)
W, H = im.size
box = (int(x0 * W), int(y0 * H), int(x1 * W), int(y1 * H))
c = im.crop(box)
c = c.resize((int(c.width * scale), int(c.height * scale)), Image.LANCZOS)
out = os.path.join(HERE, "src", f"{vol}_p{printed:03d}_crop_{int(x0*100)}_{int(y0*100)}.png")
c.save(out, optimize=True)
print(out, c.size)
