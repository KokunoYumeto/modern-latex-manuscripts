# Weber *Lehrbuch der Algebra* — audit method (lifted from SGA5) + adaptation plan

Written 2026-06-25. Companion to `HARNESS_README.md` (which covers the file inventory) and
`weber_audit_workflow.js` (the runnable workflow with the exact prompts).

This document does two things the user asked for:
1. Writes down, precisely, what the SGA5 audit session actually does, and the pitfalls it hit.
2. Maps that method onto Weber's three German volumes, where it has to change and where it doesn't.

---

## ⚠️ PRIORITY CORRECTION — 2026-06-25 (Floris steer; supersedes the two-axis framing below)

The English-translation axis (axis X) is **dropped from priority.** Translation is trivial and comes
later. **The only job is the German transcription, and inside it, that every mathematical symbol is
exactly what Weber printed.** Read §§3, 5.4, 6, 7 below as German-axis-only.

Two facts that change the method versus SGA5:

1. **The B139 German `.tex` is a half-baked GPT draft, not a faithful copy.** It was produced
   (~2000 pp) by GPT before we knew it confidently summarizes, skips lines, and smooths over
   formulae — partly on under-resolution scans. So unlike SGA5 (complete `.tex`, rare slips), expect
   dropped lines, summarized paragraphs, missing formulae. **Audit for OMISSION / summarization
   FIRST, wrong symbols second.** Fixes are often whole-span **re-transcriptions** from the scan, not
   few-character patches. A page where three sentences became one is a FAIL even if every word in
   that one is right.

2. **650+ dpi or don't trust a symbol.** The on-disk scans (the IA `…weberich` set) are only
   ~430–500 dpi — *below the trust line.* Either source higher-res masters (GDZ Göttingen / e-rara
   have clean Weber) or zoom to a tight crop per formula and **flag anything not cleanly legible —
   never guess.** Re-rendering a ~430 dpi PDF at 600 dpi does not add real resolution.

Difficulty profile flips: SGA5 = hard notation / complete text; Weber = easy notation / holey text.
The work here is **completeness**, not symbol forensics.

---

## Source resolution — MEASURED 2026-06-25 (definitive; ends the conflicting DPI claims)

Whole machine swept (one drive, C:). Native pixels ÷ physical page size, measured with fitz
(`measure_sources.py` in this folder):

| Volume | Best file on disk | True native | Note |
|--------|-------------------|-------------|------|
| Band I (vol1) | `lehrbuchderalgeb01weberich.pdf` | **~500 dpi** (2502×4082) | the "166 dpi Band I" note is STALE — this copy is 500; manifest already uses it |
| Band II (vol2) | `Weber_Algebra_Bd1_Google.pdf` *(mislabeled — IS Band II)* | **~560 dpi** (2940×4928) | highest-res full volume on disk; `…02weberich.pdf` is ~500 |
| Band III (vol3) | `lehrbuchderalgeb03webe_0.pdf` | **~500 dpi** (2618×4139) | manifest uses it |

Worse → ignore: UofT jp2 ~345 dpi; BSB ~265 dpi **and first edition** (different text).

**No ≥650 dpi native Weber scan exists anywhere on the machine.** The "650dpi"-named files are
those ~500 dpi natives **upscaled** to a 650 render target — that is the origin of the "we have 650"
impression. True ceiling: ~500 (vol1/3), ~560 (vol2).

**Consequence (Floris's rule):** ~500–560 is below the 650 trust line, so every page is worked
zoomed — tight crops of the native, tricky equations split 5 ways, anything not cleanly legible
FLAGGED not guessed. No resolution shortcut. (Same as how SGA5 certifies at ~500 dpi.) TODO before
first page: add a `crop_src.py` tight-zoom tool (mirror SGA5's), and confirm each volume's identity
by eye (one running-head per volume — one file on disk was already mislabeled).

---

## 0. The one-paragraph version

SGA5 is being checked with a **find → verify → fix** loop. One agent reads the scan of one
printed page and compares it to the LaTeX, element by element. A second agent re-checks each
proposed change and is told to reject by default. I (foreground) review every surviving change by
eye, apply it, and recompile as a gate. It is page-keyed, runs one workflow at a time, and a
*clean page is the normal result*. Weber can reuse this almost verbatim for its **German
transcription** — but Weber also has an **English translation track**, so it needs a *second* axis
the SGA5 method never had, and a *German-orthography rule* that is the mirror image of SGA5's
"don't undo the editor's corrections" rule. The Weber harness for all this is already staged.

---

## 1. What the SGA5 method does, precisely

Source of truth: `…\sga5_full_audit_20260623\_work\sga5_audit_workflow.js` and the lessons in
`SWARM_SESSION_STATUS_20260624.md`.

**Unit of work = one printed page.** Page numbers are not in the `.tex`. Each page was
pre-rendered to three overlapping high-DPI PNG chunks (top / mid / bottom) so the fine print and
formulae are legible.

**The pipeline (per page, no barrier between stages — each page flows independently):**

1. **Audit agent (1 per page).** Reads the three scan chunks. Picks a distinctive phrase from the
   top chunk, greps it in the `.tex`, reads ~50 lines around the hit to get the whole page region.
   Compares scan vs `.tex` element by element in reading order: prose (every word), formulae
   (every symbol — subscripts, superscripts, bars, primes, lower-shriek `f_!` vs star `f^*` vs
   upper-shriek `f^!`, `⊗` vs derived `⊗^L`, `Hom` vs `RHom`), diagrams (every node, arrow
   direction, arrow label), and all numbering / cross-references. It returns a structured object,
   not prose.

2. **Three-way classification** — this is the heart of it:
   - **type A (emit as a fix):** the `.tex` deviates from the source in a way that changes meaning.
     The `.tex` is *worse* than the page. → propose an exact `old_string → new_string` patch.
   - **type B (flag, do not fix):** the *source itself* has a typo/error that the `.tex` faithfully
     reproduces. Report it, change nothing.
   - **cosmetic (note, do not fix):** difference that does not change meaning — punctuation,
     arrow glyph style, citation format, an added/dropped article, a defensible normalization.

3. **Verify agent (1 per candidate fix), default = REJECT.** Re-checks the patch against the scan.
   Runs five gates and accepts only if *all* pass: (1) `old_string` occurs exactly once in the
   file; (2) the source actually shows the new reading and not the old; (3) it is not cosmetic and
   not undoing a standardization; (4) it fixes a real mathematical/textual error; (5) **direction**
   — the fix must make the `.tex` match a reading it got *wrong*, never make it match a source typo
   and never revert the editor's correction.

4. **Human review (me, foreground) — mandatory, not optional.** I read every *accepted* fix
   against the scan myself before it lands. The agents systematically over-trust literal source
   fidelity (see pitfall 3), so this step is load-bearing.

5. **Apply + compile gate.** Patches go in via a unique-match-gated applier (or Edit), then
   `pdflatex` runs as a gate. The invariant for SGA5 was **307 pages / 0 errors** — it must hold
   after every batch, or the change is backed out.

**Exact prompts:** embedded verbatim in the SGA5 script (`auditPrompt`, `verifyPrompt`). The Weber
versions are in `weber_audit_workflow.js` in this folder.

**Measured economics (SGA5):** ~**65k tokens per page**. Roughly **1 genuine fix per ~6 pages**,
and *fix density tracks math density* — prose-heavy stretches came back ~28/30 clean and cheaper
(~44k/page); dense diagram/intersection-theory stretches yielded 10–18 fixes per 30 and cost more
(~2M/batch). A 30-page batch ran ~3–10 minutes wall-clock. Over ~270 workflow-audited pages it
landed ~65 verified fixes with the compile gate never broken.

---

## 2. Pitfalls (the hard-won lessons)

These are the things that actually went wrong, with the fix that stuck. Each is tagged for whether
it carries to Weber.

1. **Rate limit, not token budget, is the binding constraint.** Running 3+ big workflows at once
   trips *server-side* throttling and wastes agents. → **Run ONE workflow at a time.** *(Carries to
   Weber — same API.)*

2. **Args arrive in inconsistent shapes.** The first run returned `pagesAudited: 0` because the
   page list reached the script as a JSON string, not an array. → the script coerces array / object
   / number / JSON-string / comma-string. *(Carried — same coercion in the Weber script.)*

3. **★ Agents over-revert the editor's good corrections.** The single most important quality
   lesson. Audit agents weight literal source-fidelity too highly and propose "fixing" the `.tex`
   back to a *source* typo (e.g. reverting a corrected `Rf_{2*}A` to the source's wrong `Rf_*A`, or
   undoing a uniform `⊗_X` standardization). → the prompts were hardened with an explicit
   "do NOT revert improvements" rule **and** every accepted fix gets human review. *(Carries to
   Weber — but the rule **inverts**: see §5.1.)*

4. **A diagram/float insert can silently swallow a page.** A reconstructed `tikzcd` compiled with
   0 errors but the page count dropped 307→306 — an unbraced comma in an arrow label
   (`"t\mapsto(t,0)"`) was eaten as a tikz option separator, consuming content to the next
   sub-section. → brace special label content (`"{t\mapsto(t,0)}"`), and **a 0-error compile is not
   sufficient: also confirm the page count is unchanged and render the page.** *(Carries — applies
   to any float/figure edit in Weber too.)*

5. **Reconstructing dropped diagrams/proofs is high-risk.** Where a whole diagram or proof step was
   dropped, the workflow's auto-reconstruction was often partial or malformed. → those were
   deferred to a focused hand pass, not trusted from the agent. *(Carries — Weber has dropped
   sentences/pages too; one *entire printed page* of proof was found missing in SGA5 Exposé XII.)*

6. **Clean is the expected result; do not invent fixes.** The prompt says so explicitly. Agents
   that "look productive" by emitting marginal fixes create review load and false-accept risk.
   *(Carries.)*

7. **Decide systematic notation choices once, globally — never piecemeal.** When a symbol convention
   differs between source and edition across many pages (the `Λ` vs `A` group-ring case, the `K^•`
   standardization), patching page-by-page creates *inconsistency*. → confirm the source's usage
   across the whole section first, then make one global decision. *(Carries — Weber has its own
   global conventions: Fraktur letters, old orthography, proper-name spellings.)*

8. **The no-GPU / no-background rule still holds, and this respects it.** Agents only *read*
   pre-rendered PNGs + grep/read `.tex`. Zero GPU, zero model-load. Rendering chunks and running
   `pdflatex` is CPU, done in my foreground, one shell call at a time. *(Carries.)*

---

## 3. Why Weber is not just "SGA5 in German": two fidelity axes

SGA5 is French → French. There is one artifact (the `.tex`) and one ground truth (the scan). One
axis.

Weber is German → German **and** German → English. There are two artifacts per volume —
`weber_vN_ge.tex` (transcription) and `weber_vN_en.tex` (translation) — and therefore **two things
that can be wrong**:

- **Axis T — transcription fidelity.** `weber_vN_ge.tex` vs the scanned printed page. *"Does the
  German `.tex` faithfully reproduce Weber's printed German and mathematics?"* This is the direct
  analog of SGA5 and reuses the method almost unchanged.

- **Axis X — translation fidelity.** `weber_vN_en.tex` vs `weber_vN_ge.tex` (with the scan as a
  tie-breaker for mathematics). *"Is the English a complete, faithful, mathematically-correct
  rendering of the German — nothing dropped, no contresens, every formula identical?"* This axis
  **does not exist in SGA5** and needs its own prompt.

Order matters: **axis T is prerequisite to axis X.** A faithful German source is the thing the
translation is judged against. Audit transcription first, translation second.

---

## 4. What is already staged for Weber (so we are not starting cold)

The prior session already built the harness that this plan needs. From `HARNESS_README.md` and
`audit_manifest.json`:

- **Canonical `.tex` (the B139 cumulative, one file per volume per track):**
  `…\Weber restart\Weber_B139_heuristic_fix\Weber_B139_heuristic_fix\02_cumulative\v{1,2,3}\{ge,en}\weber_v{1,2,3}_{ge,en}.tex`.
  German line counts: v1 ≈ 20.7k, v2 ≈ 19.3k, v3 ≈ 16.5k. v1 ≈ §§1–183 (foundations); v2 = groups /
  cyclotomy / number fields (this is where the §203 transcendental-numbers material lives); v3 =
  elliptic functions. **Everything older than this — every `weber_literal_repair_batchNN`, every
  `cumulative_repaired*`, the section fragments with `\srcpage` markers — is superseded.** Audit
  B139, nothing else.
- **Scans:** the Internet-Archive `…weberich.pdf` set in `…\Papors\OS\Lehrbuch der Algebra\`,
  ~500 dpi and uniform across all three volumes. Printed→PDF offsets verified: **vol1 +26, vol2
  +22, vol3 +22**.
- **Manifest:** `audit_manifest.json`, **1720 page-units** (vol1 = 648, vol2 = 680, vol3 = 392),
  each unit = printed page → pdf page + tex file + an approximate `tex_line_hint`.
- **Renderer:** `chunk_page.py vol2 745` → `_audit\src\vol2_p745_{top,mid,bot}.png`. Renders only
  the pages you name (no mass render).
- **Caveats baked into the manifest:** vol3 is reliable only to printed **p392** (the IA scan
  re-shoots a signature after that and the offset shifts +22→+32); vol2 to **p680**.

So the missing piece is exactly the part the user asked for: the *workflow and prompts*. That is
`weber_audit_workflow.js` in this folder.

---

## 5. The adaptation — what changes in the prompts and the loop

Same skeleton as SGA5 (render → audit → default-reject verify → human review → apply → compile
gate, one workflow at a time). Four things change.

### 5.1 The German-orthography rule — SGA5's rule, inverted

SGA5's rule was *"don't undo the editor's improvements."* Weber's rule is the mirror:
**"don't modernize Weber's German."** The transcription must keep the 1890s/1900s printing exactly.
The audit prompt must classify all of the following as **cosmetic / do-not-fix**, never type A:

- Old spellings: `Theil / Theile / Theiler`, `giebt`, verbs in `-iren` (`definirt`, `operirt`,
  `construirt`), `Coefficient / Coordinaten / Function / Product` (C-, not K-), `Gesammtheit`,
  `transcendent`, `Ueber-` / `Aehnlich-` at word start.
- **`ß` written as `ss`** (`dass`, `heisst`, `grösser`, `Ausser`). This is a settled edition
  normalization throughout the transcription. Never flag it.
- Accents/diacritic style, em-dash style, footnote-marker style.

A type-A transcription fix is a genuine *misread*, exactly as in SGA5: a dropped word / sentence /
footnote, a wrong digit or formula, a wrong subscript/exponent, a **wrong Fraktur letter** (Weber
uses German/Fraktur letters for groups, ideals, and forms — a misread there is real and matters),
a wrong cross-reference, a wrong theorem/section number, dropped or mis-ordered math.

Proper names follow the SGA5 pattern: if Weber prints `Silow`/`Chafarevitch` and the edition
standardizes to `Sylow`/`Shafarevich`, that is a *defensible standardization* (type B / cosmetic),
not a fix — decide it once, globally (pitfall 7).

### 5.2 New pitfall: the canonical `.tex` has no page or section anchors

The B139 cumulative is continuous prose. The cumulative merge **stripped the `\srcpage{}` and
`§N` / `\textbf{N.}` anchors** that the old section fragments had. Consequences for the audit:

- "Locate the page region" is weaker than in SGA5. There is no in-file marker that says "page 745
  starts here." → the agent must use the manifest's `tex_line_hint` (a linear interpolation, good to
  ~±75 lines) **and** search for the page's opening German words read off the top chunk. The prompt
  must say the page boundary is *approximate* and that the agent should compare *the content visible
  in the three chunks*, not assume a tex line range.
- This makes "is a whole sentence missing at the page break?" harder to see. That is precisely where
  real transcription drops hide, so it deserves extra care.
- *Optional future improvement (separate task):* re-inject `\srcpage{}` anchors into B139 from the
  manifest. Not required to start; would make every later pass easier.

### 5.3 New step: render the batch before firing the workflow

SGA5 had all 484 pages pre-rendered. Weber renders on demand. So each batch gets a foreground
step first:

```
python _audit\chunk_page.py vol2 745 746 747 748 749 750
```

then fire the workflow for those pages. Rendering is CPU (pdf → png), not GPU — inside the rules.
Agents only read the produced PNGs.

### 5.4 Two prompts instead of one

- **Axis T (transcription)** = the SGA5 audit prompt with the German-orthography rule of §5.1
  swapped in for the "don't-undo-the-editor" rule, and the "boundary is approximate" note of §5.2.
  Reads three scan chunks + the `ge.tex` region.
- **Axis X (translation)** = a new prompt. Reads the `en.tex` region and the `ge.tex` region in
  parallel, paragraph by paragraph. type A = the English **drops** content the German has, **adds**
  content the German lacks, **mistranslates** (contresens / wrong term of art), or **alters a
  formula** (math must be identical between tracks). It pulls a scan chunk only to adjudicate a math
  discrepancy. Cosmetic = defensible stylistic translation choices (word order, synonym, article).
  The verify agent still defaults to reject. Note: axis X compares text-to-text, so it needs PNGs
  only occasionally — it should run **cheaper per page** than axis T.

Both prompts are written out verbatim in `weber_audit_workflow.js`.

### 5.5 Apply target and gate

Edits land in the **B139 cumulative** files under `…\02_cumulative\v{N}\{ge,en}\`, not in `_audit\`
(this folder is read/verify only). Back up the volume file first, apply, then `pdflatex` that
volume as the gate. The volume `.tex` files are standalone `article`-class documents, so each
compiles on its own. Stay within the volume caps (vol3 ≤ p392, vol2 ≤ p680).

---

## 6. Cost and scale — the real number, and why this needs a steer

At the SGA5 rate (~65k tok/page), the arithmetic is large:

| Pass | Pages | Rough cost |
|------|-------|-----------|
| Axis T (transcription), all 3 volumes | 1720 | **~110M tokens** |
| Axis X (translation), all 3 volumes | 1720 | ~60–110M tokens (cheaper, text-vs-text) |
| Both axes, everything | — | **~170–220M tokens** |

That is far past "a batch." It is a multi-week, deliberate spend, and after the recent recalibration
(*efficiency, don't nuke the cap*) it is explicitly your call, not something I should launch on my
own — exactly as the SGA5 scale decision was. The method itself is efficient *per page*; the size
comes from there being 1720 pages × 2 axes.

**My recommendation — staged, cheapest-information-first:**

1. **Validation batch (cheap, ~0.5–0.8M tok):** run **both axes** on a 6-page slice I can
   cross-check — `vol2 pp.745–750` (the §203 "Transcendente Zahlen" pages; I already have the old
   fragment text to sanity-check against). Measure real cost/yield, eyeball quality, confirm the
   no-anchor region-location actually works. Same as how SGA5's workflow was validated before
   scaling.
2. **Pick the order** (your steer): which volume first, and one axis or both. My default would be
   **transcription first on vol1** (foundations, most-read, and axis T must precede axis X), in
   ~30-page batches, one workflow at a time, every accepted fix reviewed by eye, compile-gated.
3. **Report cost + yield after each batch**, so you can stop or redirect at any point — the SGA5
   cadence that worked.

---

## 7. What I need from you to start

Three decisions, then I can run autonomously to whatever scale you set:

- **Scope:** transcription only (axis T), or transcription + translation (both axes)?
- **Volume priority:** vol1 / vol2 / vol3 first? (I'd start vol1.)
- **Green-light the validation batch** (vol2 pp.745–750, both axes, ~0.5–0.8M tok) so we have real
  Weber numbers before committing to a volume.

Everything else — orthography calls, Fraktur, proper-name standardization, batch size, the prompts —
I'll decide and run by the rules above.
