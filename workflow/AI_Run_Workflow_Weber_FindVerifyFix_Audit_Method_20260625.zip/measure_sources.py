"""Measure the TRUE native resolution of every candidate Weber source on disk.
Native dpi = embedded raster pixels / physical page size (from the PDF mediabox).
Re-rendering a low-native PDF at 600dpi does NOT add detail, so native is what matters.
CPU only (fitz + PIL), no GPU."""
import os, json, glob
import fitz
from PIL import Image

HERE = r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Weber semi-restard and fidelity pass\_audit"

def pdf_native(path, frac=0.5):
    try:
        d = fitz.open(path)
        pg = d[int(d.page_count * frac)]
        best = None
        for im in pg.get_images(full=True):
            info = d.extract_image(im[0]); w, h = info["width"], info["height"]
            if best is None or w * h > best[0] * best[1]:
                best = (w, h)
        pw, ph = pg.rect.width / 72.0, pg.rect.height / 72.0   # inches
        if best and ph:
            return f"{d.page_count}pp | page {pw:.1f}x{ph:.1f}in | raster {best[0]}x{best[1]}px | NATIVE ~{best[0]/pw:.0f}x{best[1]/ph:.0f} dpi"
        return f"{d.page_count}pp | no embedded raster (vector/text)"
    except Exception as e:
        return f"ERR {e}"

def img_native(path, assume_in=9.3):
    try:
        try:
            w, h = Image.open(path).size
        except Exception:
            px = fitz.Pixmap(path); w, h = px.width, px.height
        return f"{w}x{h}px | ~{h/assume_in:.0f} dpi @ {assume_in}in tall"
    except Exception as e:
        return f"ERR {e}"

print("=== MANIFEST source PDFs (what chunk_page.py actually renders) ===")
m = json.load(open(os.path.join(HERE, "audit_manifest.json"), encoding="utf-8"))
vol = {}
for u in m["units"]:
    vol.setdefault(u["volume"], u["source_pdf"])
for v in sorted(vol):
    print(f"{v}: {os.path.basename(vol[v])}\n     {pdf_native(vol[v])}")

print("\n=== candidate full-volume PDFs ===")
cands = [
 r"C:\Users\Floris\Documents\Papors\OS\Lehrbuch der Algebra\lehrbuchderalgeb01weberich.pdf",
 r"C:\Users\Floris\Documents\Papors\OS\Lehrbuch der Algebra\lehrbuchderalgeb02weberich.pdf",
 r"C:\Users\Floris\Documents\Papors\OS\Lehrbuch der Algebra\lehrbuchderalgeb03webe_0.pdf",
 r"C:\Users\Floris\Documents\Papors\OS\Lehrbuch der Algebra\Bd1_Google_chapters\Weber_Algebra_Bd1_Google.pdf",
]
for c in cands:
    print(f"{os.path.basename(c)}\n     {pdf_native(c) if os.path.exists(c) else 'NOT FOUND'}")

print("\n=== Band I higher-res crop packets (pp1-152 only) ===")
for pat in ["**/*uoft330_AUDIT_PACKET.pdf", "**/*bsb275_AUDIT_PACKET.pdf"]:
    for f in glob.glob(os.path.join(r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Weber restart", pat), recursive=True)[:1]:
        print(f"{os.path.basename(f)}\n     {pdf_native(f)}")

print("\n=== UofT jp2 masters (sample mid page) ===")
for pat in [
 r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Weber restart\_claude_aid\bd1_uoft_jp2_workspace\lehrbuchderalgeb01webeuoft_jp2\lehrbuchderalgeb01webeuoft_jp2\*0300.jp2",
 r"C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Weber restart\_claude_aid\masters\lehrbuchderalgeb03webeuoft_jp2\lehrbuchderalgeb03webeuoft_jp2\*0300.jp2",
]:
    fs = glob.glob(pat)
    print((os.path.basename(fs[0]) if fs else pat.split("*")[0][-40:]) + f"\n     {img_native(fs[0]) if fs else 'no match'}")
