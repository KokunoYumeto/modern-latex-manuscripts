# Weber *Lehrbuch der Algebra* — find -> verify -> fix audit harness

Launch-ready harness for a page-by-page, source-faithful audit of the German
transcription of Heinrich Weber, *Lehrbuch der Algebra* (3 volumes). Built 2026-06-24.
Models the SGA5 full-audit harness (`SGA continuation 2/_claude_aid/sga5_full_audit_20260623/_work/`).

Everything in this `_audit/` folder is self-contained. Do **not** edit the manuscript
`.tex` from here — this is the read/verify side only.

---

## 1. Canonical German source `.tex` (the transcription being audited)

The latest, complete, three-volume **B139** cumulative set (Jun 13–14 2026). One file per
volume, German source track:

```
…\Weber restart\Weber_B139_heuristic_fix\Weber_B139_heuristic_fix\02_cumulative\v1\ge\weber_v1_ge.tex   (20728 lines)
…\Weber restart\Weber_B139_heuristic_fix\Weber_B139_heuristic_fix\02_cumulative\v2\ge\weber_v2_ge.tex   (19335 lines)
…\Weber restart\Weber_B139_heuristic_fix\Weber_B139_heuristic_fix\02_cumulative\v3\ge\weber_v3_ge.tex   (16485 lines)
```

(English translation tracks sit beside them under `…\v{1,2,3}\en\`.)

These are **complete cumulative editions** of each volume's body, not section fragments.
v1 ≈ §§1–183 (printed pp.1–648), v2 = the group-theory / cyclotomy / number-field volume,
v3 = the elliptic-functions volume.

### SUPERSEDED / do NOT use (flagged trash)
- `Weber semi-restard and fidelity pass\cumulative_repaired\*german_source.tex` — May 29–30
  partial merges (e.g. `…vol2_tail_plus_vol3_sections1_69…`, ≤17.5k lines). Older + incomplete.
- `…\cumulative_current\`, `…\cumulative_repaired_through_207*\`, every `weber_literal_repair_batchNN*`
  zip/folder, and all dated `Weber_Cumulative_…Batch42…Batch60…` packages in the fidelity-pass
  folder — early Kimi/"semi-restard"/per-batch lineage, all rolled into B139.
- Any `*english_translation*` / `*source*` PDF slices at the fidelity-pass root — render checks, not edition text.

Rule of thumb: if it predates Jun 8 2026 or is not under `Weber restart\Weber_B139_heuristic_fix`,
it is superseded.

---

## 2. Source scans + printed→PDF offset

Best uniform-resolution scans on disk: the Internet-Archive set in
`C:\Users\Floris\Documents\Papors\OS\Lehrbuch der Algebra\` (~500 dpi, ~2500×4100 px,
consistent across all three volumes — higher and more uniform than the UofT jp2 masters
(~1945×3209) or the BSB-1895 PDF (72 dpi embedded)).

| Volume | Source PDF | PDF pages | embedded img | ~DPI | Offset (pdf_page = printed + offset) |
|--------|------------|-----------|--------------|------|--------------------------------------|
| vol1 | `lehrbuchderalgeb01weberich.pdf` | 686 | 2502×4082 | ~500 | **+26** |
| vol2 | `lehrbuchderalgeb02weberich.pdf` | 828 | 2462×4172 | ~501 | **+22** |
| vol3 | `lehrbuchderalgeb03webe_0.pdf`   | 772 | 2618×4139 | ~500 | **+22** |

Offsets were verified by reading running-head folios at many depths (vol1: printed 50/100/200/
300/400/500/600/648 all exact; vol2: 50…680 exact; vol3: 50…392 exact).

`lehrbuchderalge01webegoog.pdf` (Google Bd1, 826 pp, nominal ~550 dpi) is a backup only — Google
scans are uneven; prefer the `weberich` set.

---

## 3. Manifest structure — `audit_manifest.json`

One **unit per printed page** covered by both a canonical `.tex` and a verified scan.

```json
{
  "schema": "weber_lehrbuch_audit_manifest_v1",
  "offsets": {"vol1": 26, "vol2": 22, "vol3": 22},
  "n_units": 1720,
  "n_units_per_volume": {"vol1": 648, "vol2": 680, "vol3": 392},
  "units": [
    {
      "volume": "vol1",
      "source_pdf": "…\\lehrbuchderalgeb01weberich.pdf",
      "pdf_page": 126,            // 1-based page in source_pdf
      "printed_page": 100,        // folio printed on the page
      "tex_file": "…\\weber_v1_ge.tex",
      "tex_line_hint": 3305       // approximate line in tex_file (see caveat)
    }
  ]
}
```

Regenerate with `python build_manifest.py` (rerun whenever the cumulative tex changes).

---

## 4. Chunk renderer — `chunk_page.py`

Renders one printed page as overlapping high-dpi chunks (top/mid/bot by default) so the
fine print and formulae are legible. Reads source PDF + offset straight from the manifest,
so the two can never disagree. **Does not mass-render** — only the pages you name.

```
python chunk_page.py vol1 100              # 3 chunks of vol1 printed p100 -> src\vol1_p100_{top,mid,bot}.png
python chunk_page.py 2 400 401 --chunks 4  # vol2 pp.400-401, 4 chunks each
python chunk_page.py vol3 50 --full        # whole page, single image
```

Output: `_audit\src\`. 600-dpi render, each chunk downsampled to ≤2400 px wide.

---

## 5. Suggested audit loop (find -> verify -> fix)

For a unit: `chunk_page.py VOL PRINTED` → read the chunks → jump to `tex_line_hint` in
`tex_file`, search nearby for the page's opening German words → compare prose/formulae line
by line → record drops/garbles/formula errors. The tex is the only thing edited, and that
happens in the manuscript files under `Weber restart\…\02_cumulative\`, never here.

---

## Ready units & caveats

- **Audit-ready page-units: 1720** — vol1 = 648 (pp.1–648), vol2 = 680 (pp.1–680), vol3 = 392 (pp.1–392).
- **Biggest caveat — the canonical tex carries NO per-page or per-section line markers.** It is
  continuous prose (cumulative integration stripped the `\textbf{N.}` / `§N` anchors). So
  `tex_line_hint` is a **linear interpolation** over the document body, not an exact line — it
  lands you on the right screen (validated: p100 hint 3305 vs actual §29 content at 3371–3380,
  within ~75 lines). Always confirm by searching for the page's opening words.
- **vol3 is capped at printed p392.** The IA vol3 scan has a duplicated signature after ~p392
  (pages ~385–394 reshot), and the offset shifts from +22 to +32 past that point. pp.1–392 are
  clean at +22; auditing beyond p392 needs the two-regime offset handled first (or a cleaner vol3 scan).
- **vol2 is capped at printed p680.** Offset +22 is exact to ~p680; the index/Nachträge tail
  beyond drifts slightly and is not core transcription.
- vol1 printed p1 (and other chapter-opening pages) print no folio — normal; the offset is still exact.
- Richer source assets exist if needed: 650-dpi labelled section cutouts and UofT jp2 / BSB-1895
  masters under `Weber restart\_claude_aid\weber_source_cutout_packets_20260610\` and `…\_claude_aid\masters\`.
```
