# Weber Find-Verify-Fix Audit Method Snapshot

This is a compact workflow/methodology packet, not a Weber edition and not a certification claim.

It records the live Weber Band I source-audit method adapted from the SGA5 page-local find -> verify -> fix pattern. The Weber-specific priority is German transcription/source completeness first: omissions, compressed prose, missing formulae, wrong symbols, dropped tables, and over-added editorial completions are checked before treating English translation as the main production axis.

Current scope in this snapshot: Band I audit/certification logs through source p347, with the method log cursor pointing to p348-p353 next. Newer logged ranges beyond the previous p323 snapshot include p324-p329 (Laguerre continuation; S-vs-sum and Phi-vs-Omega repairs), p330-p335 (numerical/Newton approximation; p334 printed erratum retained and flagged), p336-p341 (approximation/Bernoulli), and p342-p347 (Bernoulli/Graeffe with Berichtigungen handling). Earlier logs cover p100-p323.

Important guardrail: the same workflow also produced hallucinated fixes on phantom/no-scan pages when an argument bug targeted unavailable pages. The logged applied fixes were hand/source verified before application. The method lesson is that agent/OCR output is finder evidence only; source images and mathematical context remain the gate.

Bulky source scans and page renders are intentionally not included here. They should be regenerated from the manifest and local source PDFs when needed.
