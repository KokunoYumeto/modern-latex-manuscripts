# Weber Find-Verify-Fix Audit Method Snapshot

This is a compact workflow/methodology packet, not a Weber edition and not a certification claim.

It records the live Weber Band I source-audit method adapted from the SGA5 page-local find -> verify -> fix pattern. The Weber-specific priority is German transcription/source completeness first: omissions, compressed prose, missing formulae, wrong symbols, dropped tables, and over-added editorial completions are checked before treating English translation as the main production axis.

Current scope in this snapshot: Band I audit/method logs through source p311. The newest logged ranges include p300-p305 (Budan-Fourier/Newton, including two restored sign tables and Fraktur-z/root-count repairs) and p306-p311 (Newton/Descartes/Jacobi criteria, including a restored double-row table, sign-sequence repairs, and dropped formula material). Earlier logs cover p100-p299.

Important guardrail: the same workflow also produced hallucinated fixes on phantom/no-scan pages when an argument bug targeted unavailable pages. The logged applied fixes were hand/source verified before application. The method lesson is that agent/OCR output is finder evidence only; source images and mathematical context remain the gate.

Bulky source scans and page renders are intentionally not included here. They should be regenerated from the manifest and local source PDFs when needed.

