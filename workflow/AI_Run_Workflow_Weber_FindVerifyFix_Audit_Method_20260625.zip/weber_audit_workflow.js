// Weber "Lehrbuch der Algebra" source-fidelity audit — verify-gated workflow.
// Adapted from sga5_audit_workflow.js. Two axes (SGA5 had one):
//   axis 'T' (transcription): weber_vN_ge.tex  vs  the scanned printed page.
//   axis 'X' (translation):   weber_vN_en.tex  vs  weber_vN_ge.tex (+ scan for math tie-break).
//
// Usage:
//   Workflow({ scriptPath: "...\\_audit\\weber_audit_workflow.js",
//              args: { volume: "vol2", axis: "T", pages: [745,746,747,748,749,750] } })
//   args.pages = PRINTED page numbers. Chunks must already exist in _audit\src\ for axis T —
//     render them first (foreground, CPU, no GPU):  python _audit\chunk_page.py vol2 745 746 ...
//   args.axis: "T" (default) or "X".  args.volume: "vol1"|"vol2"|"vol3".
// Returns { volume, axis, pagesAudited, cleanPages, accepted[], rejected[], typeB[], cosmetic[] }.
//   accepted[] = fixes that PASSED adversarial verification. I review each by eye, then apply to the
//   B139 cumulative tex under ...\02_cumulative\vN\{ge,en}\  + back up + pdflatex that volume (gate).
//
// Why this respects the rules: agents only READ pre-rendered PNGs + Grep/Read .tex → zero GPU,
// zero model-load. Run ONE workflow at a time (rate-limit lesson). ~30 pages/run is a safe batch.
// Volume caps: vol3 <= printed p392, vol2 <= p680 (scan-offset drift past those).

export const meta = {
  name: 'weber-audit-batch',
  description: 'Audit a batch of Weber Lehrbuch der Algebra printed pages (transcription vs scan, or translation vs German), adversarially verify each candidate fix, return applied-ready patches',
  phases: [
    { title: 'Audit',  detail: 'one agent/page: compare scan↔ge.tex (T) or en.tex↔ge.tex (X), emit fixes + typeB + cosmetic' },
    { title: 'Verify', detail: 'one agent/fix: adversarial re-check, default REJECT' },
  ],
}

const WEBER = String.raw`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Weber restart\Weber_B139_heuristic_fix\Weber_B139_heuristic_fix\02_cumulative`
const AUDIT = String.raw`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\Weber semi-restard and fidelity pass\_audit`
const SRC   = AUDIT + String.raw`\src`
const texOf = (vol, track) => { const v = vol.replace('vol', 'v'); return `${WEBER}\\${v}\\${track}\\weber_${v}_${track}.tex` } // B139 dirs/files use v1/v2/v3

// args may be {volume,axis,pages}, or a bare array/number/string of pages (defaults vol1/T) — coerce all.
function parseArgs(a) {
  let volume = 'vol1', axis = 'T', pages = []
  let obj = a
  if (typeof a === 'string') { try { obj = JSON.parse(a) } catch (e) { obj = a } } // stringified {volume,axis,pages} -> object (harness may stringify)
  const numsFrom = (p) => Array.isArray(p) ? p.map(Number).filter(Number.isFinite)
    : typeof p === 'number' ? [p]
    : typeof p === 'string' ? p.split(/[^0-9]+/).map(Number).filter(Number.isFinite) : []
  if (obj && typeof obj === 'object' && !Array.isArray(obj)) {
    if (obj.volume) volume = String(obj.volume)
    if (obj.axis) axis = String(obj.axis).toUpperCase()
    pages = numsFrom(obj.pages)            // read pages ONLY from .pages — never scrape digits out of "vol1"
  } else {
    pages = numsFrom(obj)                  // bare array / number / "100,101,102" string; volume/axis stay default
  }
  if (!/^vol[123]$/.test(volume)) volume = 'vol1'
  if (axis !== 'T' && axis !== 'X') axis = 'T'
  return { volume, axis, pages }
}
const { volume, axis, pages } = parseArgs(args)
const GE = texOf(volume, 'ge')
const EN = texOf(volume, 'en')

const FIX_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: {
    page: { type: 'integer' },
    clean: { type: 'boolean' },
    region_note: { type: 'string', description: 'what content / approximate .tex lines this page maps to' },
    fixes: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      properties: {
        kind: { type: 'string' },
        target: { type: 'string', description: 'which file the patch edits: "ge" or "en"' },
        old_string: { type: 'string' },
        new_string: { type: 'string' },
        evidence: { type: 'string' },
        confidence: { type: 'number' },
      },
      required: ['kind','target','old_string','new_string','evidence','confidence'],
    } },
    typeB: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      properties: { kind: { type: 'string' }, evidence: { type: 'string' } },
      required: ['evidence'],
    } },
    cosmetic: { type: 'array', items: {
      type: 'object', additionalProperties: false,
      properties: { evidence: { type: 'string' } },
      required: ['evidence'],
    } },
  },
  required: ['page','clean','fixes','typeB','cosmetic'],
}
const VERDICT_SCHEMA = {
  type: 'object', additionalProperties: false,
  properties: { accept: { type: 'boolean' }, reason: { type: 'string' } },
  required: ['accept','reason'],
}

const pad = (n) => String(n).padStart(3, '0') // chunk_page.py pads printed page to 3 digits
const chunks = (n) => `  ${SRC}\\${volume}_p${pad(n)}_top.png
  ${SRC}\\${volume}_p${pad(n)}_mid.png
  ${SRC}\\${volume}_p${pad(n)}_bot.png
  *** If you CANNOT open/read these three image files, the page was not rendered. Do NOT analyze it and do NOT infer the page from the .tex or from memory. An audit agent must then return {clean:true, region_note:"scan chunks missing"}; a verify agent must return {accept:false, reason:"scan chunks missing"}. ***`

// ---------- AXIS T: transcription (German .tex vs scanned page) ----------
const auditPromptT = (n) => `You are a meticulous proof-checker auditing ONE printed page of Heinrich Weber, *Lehrbuch der Algebra* (${volume}), against its German LaTeX transcription, for SOURCE FIDELITY. A reader must be able to TRUST that the .tex reproduces Weber's printed page exactly.

=== SOURCE (authoritative ground truth) ===
Three high-resolution scan chunks (top/middle/bottom of printed page ${n}):
${chunks(n)}

=== TRANSCRIPTION ===
File: ${GE}
This .tex has NO page or section markers — it is continuous prose. So the page boundary is APPROXIMATE. Locate the region like this: read a distinctive German phrase or formula from the TOP chunk, Grep it in the .tex, then Read ~60 lines around the match. Use what is VISIBLE in the three chunks as the page's extent; do not assume a fixed line range.

=== TASK: compare scan vs .tex ELEMENT BY ELEMENT, in reading order ===
- prose: every word (dropped / added / wrong words, dropped clauses or whole sentences — these hide at page breaks)
- footnotes: present? complete? correct text and reference?
- equations & formulae: every symbol, digit, subscript, superscript, sign, index
- letters with special meaning: Fraktur / German letters for groups, ideals, forms (a misread Fraktur letter is a REAL error)
- numbering & cross-references: §-numbers, theorem/definition numbers, equation tags, citations

Classify each difference:
  • type A (EMIT AS FIX): the .tex DEVIATES from the printed page in a way that changes mathematical or textual meaning — wrong/dropped/added symbol, digit, word, clause, sentence, or footnote; wrong subscript/exponent; wrong Fraktur letter; wrong number or cross-reference.
  • type B (FLAG, DO NOT FIX): the PRINTED PAGE itself has a typo/error that the .tex faithfully reproduces. Report; change nothing.
  • cosmetic (NOTE, DO NOT FIX): difference that does NOT change meaning.

*** CRITICAL — do NOT "modernize" Weber's German. *** This is an 1890s–1900s text. The following are the AUTHENTIC printing and are COSMETIC / never type-A:
  - old spellings: "Theil/Theile/Theiler", "giebt", verbs in -iren ("definirt","operirt","construirt"), C- forms ("Coefficient","Coordinaten","Function","Product"), "Gesammtheit", "transcendent", word-initial "Ueber-"/"Aehnlich-".
  - "ß" written as "ss" ("dass","heisst","grösser","Ausser") — a settled edition normalization; NEVER flag it.
  - accent/diacritic style, em-dash style, footnote-marker style.
Proper-name spelling that the edition standardized (e.g. printed "Silow"/"Chafarevitch" → "Sylow"/"Shafarevich") is a DEFENSIBLE standardization → type B / cosmetic, NOT a fix.
LITMUS: type-A is ONLY for the .tex MIS-reading the printed page (a real drop / wrong symbol / wrong number). If your "fix" would modernize the German, undo a normalization, or make the .tex match a source typo → it is NOT type-A.

For each type-A fix: kind ("prose","equation","symbol","fraktur","footnote","number","xref"); target="ge"; old_string = an EXACT, VERBATIM, UNIQUE substring copied from ${GE} (long enough to occur exactly once in the whole file); new_string = corrected to match the page; evidence "page shows X; .tex has Y"; confidence 0.0–1.0 (emit only ≥0.6).

*** CONFIRM ABSENCE BEFORE CLAIMING A DROP. *** Before emitting any fix that claims the .tex dropped/collapsed/summarized content (a missing equation, matrix row, term, sentence, or label), FIRST Grep the .tex for a distinctive fragment of that content. If grep finds it anywhere (or in a form you misread), it is NOT dropped — do not emit the fix. Only assert a drop you have confirmed is truly absent from the file.

*** COMMUTATIVE REORDERING IS COSMETIC, NEVER type-A. *** $ic$ vs $ci$, $ab$ vs $ba$, $a+b$ vs $b+a$, the order of factors in a product or terms in a sum — these have the same value; classify cosmetic, do NOT emit them as fixes.

*** WEBER'S DOUBLE-BAR RELATION GLYPHS ≦ / ≧ ARE JUST leqq/geqq (= ≤/≥). *** The .tex's \le / \ge renders them correctly — COSMETIC, never a type-A symbol fix. Do NOT read a double-bar ≦/≧ as \gtreqless / \lesseqgtr or any 3-way relation.

BE CONSERVATIVE. When unsure, classify cosmetic/typeB, NOT a fix. A CLEAN page is the expected, common result — do NOT invent fixes to look productive.

Return the structured object only: {page:${n}, clean (true iff zero type-A fixes), region_note, fixes:[...], typeB:[...], cosmetic:[...]}.`

const verifyPromptT = (n, fix) => `Adversarially verify ONE proposed correction to the Weber GERMAN TRANSCRIPTION (${volume}). Your DEFAULT is to REJECT; accept only if clearly warranted.

Printed page ${n}. Source scan chunks (ground truth):
${chunks(n)}
Transcription file: ${GE}

Proposed type-A fix:
  old_string (current .tex): ${JSON.stringify(fix.old_string)}
  new_string (proposed):     ${JSON.stringify(fix.new_string)}
  claimed reason:            ${fix.evidence}

Run ALL of these checks:
  1. UNIQUENESS: Grep old_string in ${GE}. Must occur EXACTLY ONCE. If 0 or >1 → REJECT.
  2. SOURCE SUPPORT: read the scan chunk(s). The printed page must actually show new_string and NOT old_string. If it matches the current old_string, or is illegible/ambiguous → REJECT.
  3. NOT COSMETIC / NOT MODERNIZATION: if the change only modernizes Weber's German (old spelling, ss↔ß, accent style), is otherwise cosmetic, or undoes a defensible standardization (e.g. a standardized proper name) → REJECT.
  4. MEANING: it must correct a genuine textual or mathematical error (a real drop, wrong symbol/digit, wrong Fraktur letter, wrong number).
  5. DIRECTION (most common false-accept): the fix must make the .tex MATCH the printed page where the .tex got it WRONG. REJECT if it would instead make the .tex match a source TYPO, or modernize/standardize away the authentic printing.

Accept ONLY if 1–5 ALL pass. Return {accept: bool, reason: "<one sentence: which check decided it>"}.`

// ---------- AXIS X: translation (English .tex vs German .tex) ----------
const auditPromptX = (n) => `You are a bilingual (German→English) mathematics proof-checker auditing ONE printed page of Heinrich Weber, *Lehrbuch der Algebra* (${volume}). You check the ENGLISH TRANSLATION against the GERMAN SOURCE for TRANSLATION FIDELITY: the English must be a complete, faithful, mathematically-correct rendering of the German — nothing dropped, nothing invented, no mistranslation, and every formula identical.

=== GERMAN SOURCE (the thing being translated) ===
File: ${GE}
=== ENGLISH TRANSLATION (the thing being checked) ===
File: ${EN}
Both files are continuous prose with NO page markers, but they run PARALLEL paragraph-by-paragraph. Locate page ${n} in BOTH: read a distinctive phrase from the German top chunk below, Grep it in ${GE}, read ~60 lines; then find the corresponding English passage in ${EN} (same paragraph order).
For adjudicating any MATH discrepancy you may also read the scan chunks:
${chunks(n)}

=== TASK: compare English vs German paragraph by paragraph ===
Classify each difference:
  • type A (EMIT AS FIX): the English DROPS content the German has (a clause, sentence, footnote, condition), ADDS content the German lacks, MISTRANSLATES (contresens, or a wrong mathematical term of art — e.g. "Menge" must be "set" not "quantity", "Körper"→"field", "Ring"→"ring", "abzählbar"→"countable"), or ALTERS A FORMULA (mathematics must be byte-for-byte identical between the two tracks).
  • type B (FLAG, DO NOT FIX): the German source itself is wrong/odd and the English faithfully follows it. Report; change nothing.
  • cosmetic (NOTE, DO NOT FIX): a defensible stylistic translation choice — word order, a synonym, an article, light rephrasing that preserves meaning. Translation is not word-for-word; do NOT flag legitimate English phrasing.

LITMUS: type-A is for MEANING lost, added, or corrupted, or MATH that differs. If the English says the same thing in different words, it is cosmetic.

For each type-A fix: kind ("dropped","added","mistranslation","math","term"); target="en"; old_string = an EXACT, VERBATIM, UNIQUE substring copied from ${EN} (or "" if the fix is a pure insertion — then describe the insertion point in evidence); new_string = the corrected English; evidence "German says X; English has Y"; confidence 0.0–1.0 (emit only ≥0.6).

BE CONSERVATIVE. A CLEAN page is the expected result. Do NOT rewrite good translation to your taste.

Return the structured object only: {page:${n}, clean (true iff zero type-A fixes), region_note, fixes:[...], typeB:[...], cosmetic:[...]}.`

const verifyPromptX = (n, fix) => `Adversarially verify ONE proposed correction to the Weber ENGLISH TRANSLATION (${volume}). Your DEFAULT is to REJECT; accept only if clearly warranted.

Printed page ${n}. German source: ${GE}. English translation: ${EN}. (Scan for math tie-break:)
${chunks(n)}

Proposed type-A fix:
  old_string (current English): ${JSON.stringify(fix.old_string)}
  new_string (proposed):        ${JSON.stringify(fix.new_string)}
  claimed reason:               ${fix.evidence}

Run ALL of these checks:
  1. UNIQUENESS: if old_string is non-empty, Grep it in ${EN}; must occur EXACTLY ONCE (0/>1 → REJECT). If it is an insertion (empty old_string), confirm the German genuinely has content with NO English counterpart.
  2. GERMAN SUPPORT: read the German region. It must actually carry the meaning the new_string adds/corrects, and the current English must actually be missing/wrong.
  3. NOT COSMETIC: a synonym, reordering, or rephrasing that preserves meaning → REJECT. Translation need not be literal.
  4. MEANING or MATH: it must restore dropped meaning, remove invented content, fix a real mistranslation/term-of-art error, or make a formula match the German.
  5. DIRECTION: the fix must make the English match the GERMAN. REJECT if it would instead introduce a meaning the German does not have, or "correct" the German itself (that is type B, not an English fix).

Accept ONLY if 1–5 ALL pass. Return {accept: bool, reason: "<one sentence: which check decided it>"}.`

const auditPrompt  = axis === 'X' ? auditPromptX  : auditPromptT
const verifyPrompt = axis === 'X' ? verifyPromptX : verifyPromptT

log(`Weber audit — ${volume} axis ${axis} — ${pages.length} pages: ${pages.join(',')}`)

// ---- run: audit each page, then verify each candidate fix from that page (pipeline, no barrier) ----
const results = await pipeline(
  pages,
  (n) => agent(auditPrompt(n), { label: `audit:${volume}.${axis}.p${n}`, phase: 'Audit', schema: FIX_SCHEMA }),
  (audit, n) => {
    if (!audit) return { page: n, audit: null, verified: [] }
    const fixes = audit.fixes || []
    if (!fixes.length) return { page: n, audit, verified: [] }
    return parallel(fixes.map(fx => () =>
      agent(verifyPrompt(n, fx), { label: `verify:${volume}.${axis}.p${n}`, phase: 'Verify', schema: VERDICT_SCHEMA })
        .then(v => ({ ...fx, page: n, accept: !!(v && v.accept), verifyReason: v ? v.reason : 'verifier died' }))
    )).then(vs => ({ page: n, audit, verified: vs.filter(Boolean) }))
  }
)

const flat = results.filter(Boolean)
const accepted = [], rejected = [], typeB = [], cosmetic = []
for (const r of flat) {
  const a = r.audit || {}
  for (const t of (a.typeB || []))    typeB.push({ page: r.page, ...t })
  for (const c of (a.cosmetic || [])) cosmetic.push({ page: r.page, ...c })
  for (const f of (r.verified || [])) {
    if (f.accept) accepted.push({ page: f.page, kind: f.kind, target: f.target, old_string: f.old_string, new_string: f.new_string, evidence: f.evidence, confidence: f.confidence })
    else rejected.push({ page: f.page, kind: f.kind, reason: f.verifyReason, evidence: f.evidence })
  }
}
log(`Weber ${volume}/${axis}: ${flat.length} pages | ${accepted.length} fixes ACCEPTED, ${rejected.length} rejected | ${typeB.length} typeB | ${cosmetic.length} cosmetic`)

return {
  volume, axis,
  pagesAudited: flat.length,
  cleanPages: flat.filter(r => r.audit && r.audit.clean).map(r => r.page).sort((a,b)=>a-b),
  accepted, rejected, typeB, cosmetic,
}
