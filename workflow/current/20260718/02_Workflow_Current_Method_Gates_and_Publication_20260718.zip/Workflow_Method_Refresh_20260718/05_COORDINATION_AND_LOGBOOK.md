# Coordination and Logbook

## Private continuity log

Each substantive action records:

- timestamp and model/session identity;
- paths and records inspected;
- current and predecessor hashes;
- exact source/translation cursor;
- validation and visual-inspection scope;
- publication record and readback result;
- Git commit and verified branches;
- remaining weaknesses and next gate.

## Public fleet map

The fleet map reports evidence-backed output, not task titles. It distinguishes:

- public frozen endpoint;
- newer live but unsealed cursor;
- excluded moving work;
- next release gate.

## Cross-session rule

Another session's package is untrusted until unpacked and read. A manager note, branch subject, or `COMPLETE` filename cannot promote the payload. Inspect TeX/PDF bodies, status files, build closure, source coordinates, and hashes.

## Failure recovery

- Keep predecessor records immutable.
- Keep source scans and release hashes outside ephemeral session state.
- Store public receipts in GitHub.
- Preserve an exact package root that another machine can rebuild.
- Treat a machine restart or context compaction as a reason to consult the logbook, not to infer state from memory.

