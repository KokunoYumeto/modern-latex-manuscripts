# Translation and Language-Manager Gate

## Required source control

- frozen source TeX checksum;
- stable source unit IDs;
- source coordinates and parity inventory;
- explicit formula, table, footnote, and apparatus handling;
- known source-control weaknesses.

## Target-language state

- target BCP-47 tag and script policy;
- unit-level target TeX;
- cumulative reader;
- terminology and names ledger;
- build and render evidence;
- independent source/target decisions;
- native or community review state;
- exact continuation unit.

## Language-manager responsibilities

1. Maintain canonical source anchors and target terminology.
2. Keep generated proposals separate from native evidence.
3. Prevent related-language output from becoming authority by convenience.
4. Define bounded worker tranches and return contracts.
5. Freeze and hash a candidate before claiming a gate pass.
6. Report technical reproducibility separately from linguistic approval.

## Interlanguage-specific rule

Weighted automata, correspondence ledgers, and marginal-intelligibility heuristics are research instruments. They can rank or document choices. They do not establish actual reader comprehension without observations. Keep proxy evidence and empirical evidence in separate fields.

