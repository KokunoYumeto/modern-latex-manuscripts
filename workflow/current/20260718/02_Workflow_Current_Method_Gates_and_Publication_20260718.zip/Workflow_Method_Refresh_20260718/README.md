# Workflow Method Refresh 2026-07-18

This is the compact reproducibility package accompanying the reader-first workflow PDF and Markdown file.

## Contents

- `00_AI_Run_Modern_LaTeX_Manuscript_Workflow_Current_20260718.md`: current human-readable method.
- `01_AUTHORITY_AND_STATUS_MODEL.md`: authority layers and public status vocabulary.
- `02_SOURCE_RESCRIBE_PAGE_GATE.md`: pagewise scan-to-TeX procedure.
- `03_TRANSLATION_LANGUAGE_MANAGER_GATE.md`: source-frozen multilingual production procedure.
- `04_PUBLICATION_AND_READBACK_GATE.md`: Zenodo/GitHub publication and verification procedure.
- `05_COORDINATION_AND_LOGBOOK.md`: cross-session continuity requirements.
- `templates/`: small machine-readable ledger and receipt templates.
- `scripts/validate_release_package.py`: portable release-package checks.
- `scripts/build_public_catalog.py` and `scripts/build_record_pages.py`: current public catalog generators.
- `examples/live-fleet-map.md`: evidence-backed public state map at release time.

The older addenda/scripts ZIP remains a separate top-level Zenodo file. This package adds the current gate structure without duplicating the large interlanguage or author evidence packages already preserved under their own concept DOIs.

## Status

This package documents and checks a workflow. It does not certify any manuscript, translation, or mathematical claim.

