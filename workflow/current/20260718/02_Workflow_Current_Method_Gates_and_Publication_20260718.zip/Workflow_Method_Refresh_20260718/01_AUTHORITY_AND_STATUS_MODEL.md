# Authority and Status Model

## Authority layers

| Layer | Typical files | What it can establish | What it cannot establish |
|---|---|---|---|
| Source | verified scan, JP2/TIFF, bibliography, checksum | what the selected edition visibly contains | correctness of the historical edition itself |
| Witness | OCR, VLM, formula candidates, crops | likely presence, location, and comparison candidates | authoritative text or mathematics |
| Scaffold | inherited TeX, old reader, translation memory | navigation and reusable structure | source fidelity |
| Source-reconciled work | TeX plus page/unit ledger and witnesses | checked scope at declared coordinates | unchecked remainder or native-language approval |
| Translation | target TeX tied to frozen source units | target coverage and technical parity | source certification or independent linguistic review |
| Release | frozen bytes, build, render, manifest, readback | artifact identity and declared gate results | peer review, semantic perfection, or critical-edition status |

## Public states

- `PUBLIC`: released on the cited Zenodo version.
- `SEALED_LOCAL`: immutable candidate closure exists, publication pending.
- `IN_REVIEW`: work exists but bytes, endpoint, or evidence are moving.
- `WITNESS_SUPPORT`: useful evidence not promoted as a reader.
- `SUPERSEDED`: retained as immutable history beneath a newer version.
- `HELD`: candidate failed readability, fidelity, completeness, provenance, or packaging checks.

## Prohibited inferences

- Compiles cleanly -> source-faithful.
- Has every page number -> complete transcription.
- Validator passes -> mathematically or linguistically correct.
- OCR and TeX agree -> source confirms them.
- Related language agrees -> target language is reviewed.
- Filename says complete -> project is complete.

