# Source-Rescribe Page Gate

## Before page work

1. Verify edition, scan hash, native resolution, and page map.
2. Declare whether current TeX is authority, reconciled work, or scaffold.
3. Set one cursor in scan and printed-page coordinates.
4. Preserve the inherited bytes before editing.

## For each page

1. Render full-page context.
2. Make overlapping bands: roughly three for ordinary prose, five or more for dense mathematics.
3. Add object crops for formulas, diagrams, tables, notes, and ambiguous glyphs.
4. Compare headings, prose, citations, mathematical objects, punctuation with mathematical meaning, and page-spanning syntax.
5. Apply source-backed TeX changes.
6. Record accepted, rejected, and deferred decisions.
7. Compile and render the affected output.
8. Update the page ledger and next cursor.

## Stop conditions

- wrong or incomplete scan;
- uncertain edition identity;
- page offset not established;
- moving TeX target during a freeze gate;
- unresolved page-spanning syntax that makes later pages unsafe;
- evidence package does not identify its source coordinates.

## Release boundary

A public checkpoint may stop before the end of a volume. Its status must state:

- last directly processed page;
- next cursor;
- whether later TeX is inherited scaffold;
- deferred systematic or page-spanning issues;
- exact source delta included in the package.

