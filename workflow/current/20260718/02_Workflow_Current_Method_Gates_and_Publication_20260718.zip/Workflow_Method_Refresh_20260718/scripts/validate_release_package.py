#!/usr/bin/env python3
"""Validate safe paths, duplicate names, manifest rows, hashes, and byte counts."""

from __future__ import annotations

import argparse
import csv
import hashlib
import sys
from pathlib import Path, PurePosixPath


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def safe_relative(value: str) -> bool:
    posix = PurePosixPath(value.replace("\\", "/"))
    return not posix.is_absolute() and ".." not in posix.parts and bool(posix.parts)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    parser.add_argument("manifest", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    failures: list[str] = []
    seen: set[str] = set()

    with args.manifest.open(newline="", encoding="utf-8-sig") as handle:
        rows = list(csv.DictReader(handle))

    required = {"relative_path", "sha256", "bytes"}
    if not rows or not required.issubset(rows[0]):
        failures.append("manifest must contain relative_path, sha256, bytes")
    else:
        for row in rows:
            rel = row["relative_path"]
            key = rel.casefold()
            if not safe_relative(rel):
                failures.append(f"unsafe path: {rel}")
                continue
            if key in seen:
                failures.append(f"duplicate path: {rel}")
                continue
            seen.add(key)
            path = (root / Path(*PurePosixPath(rel.replace("\\", "/")).parts)).resolve()
            if root not in path.parents and path != root:
                failures.append(f"path escapes root: {rel}")
            elif not path.is_file():
                failures.append(f"missing file: {rel}")
            else:
                if path.stat().st_size != int(row["bytes"]):
                    failures.append(f"byte mismatch: {rel}")
                if sha256(path) != row["sha256"].upper():
                    failures.append(f"hash mismatch: {rel}")

    if failures:
        print("FAIL")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print(f"PASS: {len(rows)} manifest rows")
    return 0


if __name__ == "__main__":
    sys.exit(main())
