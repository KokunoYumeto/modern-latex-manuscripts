# Publication and Readback Gate

## Candidate freeze

1. Copy the exact reader and evidence tree into a release root.
2. Record every dependency, byte count, and SHA-256.
3. Build from the frozen tree.
4. Render from the newly built PDF.
5. Validate manifests and safe paths.
6. Reject secrets, private machine paths, process chatter, and visible internal notes.

## Zenodo

1. Create a new version under the existing concept DOI.
2. Keep the top-level surface small and reader-first.
3. Upload the likely first-read PDF first or explicitly select it as default preview.
4. Group TeX, scans, ledgers, scripts, and QA into coherent ZIPs.
5. Publish only after metadata and file order are correct.

## Public readback

1. Read the published API record.
2. Download every changed file from the public endpoint.
3. Compare byte count and checksum.
4. Inspect rendered HTML and confirm the preview filename.
5. Store an exact publication receipt.

## GitHub

1. Mirror reader and editable evidence at practical granularity.
2. Preserve release bytes when Git text filters would alter package checksums.
3. Regenerate catalogs and reader-facing status pages.
4. Commit and push.
5. Verify remote branch refs at the exact commit.

Publication is not complete while the only evidence is a local staging directory.

