# RTL/Persianate/Arabic Gap Source-Canon Cycle 2

Created UTC: 2026-07-05T21:42:16Z

This package continues the Noether Session 06 / R3 Arabic-Persianate-RTL source-canon lane. It captures candidate source bodies or provenance leads for Arabic, Persian/Farsi, Urdu/Hindustani, and Ottoman/Turkic-adjacent gaps, extracts text where practical, and records exact term evidence with page/line/UTF-16 offset fields.

Core outputs:

- SEARCHED_URLS_AND_QUERIES.csv
- CANDIDATE_SOURCE_WITNESSES.csv
- SOURCE_TEXT_EXTRACTION_LEDGER.csv
- EXACT_TERM_CONTEXT_EVIDENCE.csv
- SOURCE_USE_LABELS_UPDATE.csv
- SOURCE_GATED_DRAFT_UNLOCK_CANDIDATES.csv
- GAP_STATUS_UPDATE.csv
- NEXT_RECOVERY_ACTIONS.csv

Boundaries:

- Arabic evidence does not cover Persian/Farsi, Urdu, Dari, Tajik, or Ottoman.
- Persian/Farsi evidence does not cover Arabic, Dari, Tajik, Urdu, or Ottoman.
- Urdu and Ottoman rows remain separate gates.
- This is source-canon/provenance/generated-draft support only, not native review, canonical approval, accepted terminology, license clearance, source certification, gate promotion, final status, translation completion, or lane completion.
