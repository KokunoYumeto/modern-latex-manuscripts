# RTL / Formula-Neighboring Usage Notes

Created UTC: 2026-07-05T18:05:01Z

This file is generated-draft and non-canonical. It records where the Session 06 source-body and Fable-ledger evidence can support pretranslation attention, not accepted wording.

Rules applied:

- Keep Arabic, Persian/Farsi, Dari, Tajik, Urdu/Hindustani, Ottoman, Uyghur, and Turkish evidence gates separate.
- Preserve RTL formula directionality around Latin symbols, variables, matrices, and equations.
- Treat OCR witnesses as locator evidence only until source-image verification.
- Do not turn Persian/Farsi support into Arabic support, or Arabic support into Persian/Farsi support.
- Leave Urdu/Hindustani and Ottoman rows in acquisition status in this package.

High-risk rows:

- L005 ideal: register and false-friend risk across Arabic, Persian, and Uyghur.
- L006 Noetherian ring: spelling/register variation and OCR-source distinction.
- L009 invariant theory: Arabic exact source context deferred.
- L010 polynomial ring: Uyghur-only support in this pass.
