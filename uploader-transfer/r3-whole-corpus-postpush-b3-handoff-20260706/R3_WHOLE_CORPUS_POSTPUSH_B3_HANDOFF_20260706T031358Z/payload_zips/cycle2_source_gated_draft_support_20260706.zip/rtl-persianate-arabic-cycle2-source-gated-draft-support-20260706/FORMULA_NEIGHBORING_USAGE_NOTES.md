# Formula-Neighboring Usage Notes

Created UTC: 2026-07-05T22:07:18Z

Arabic and Persian/Farsi rows in this package are generated-draft / non-canonical support only. Each row is tied to an exact source_evidence_id from cycle2 source-canon recovery.

Use constraints:

- Keep Arabic evidence in the Arabic RTL draft lane only.
- Keep Persian/Farsi evidence in the fa_IR draft lane only.
- Do not use fa_IR evidence to authorize Dari, Tajik, Urdu, Hindustani, or Pan-Turkic rows.
- Keep Urdu rows in source-acquisition status until stronger Urdu mathematical source bodies are captured.
- Keep Ottoman rows in provenance/source-acquisition status until literal Ottoman Arabic-script mathematical prose is captured.
- Preserve formula order from the cited source context; only the surrounding script direction is RTL-sensitive.
