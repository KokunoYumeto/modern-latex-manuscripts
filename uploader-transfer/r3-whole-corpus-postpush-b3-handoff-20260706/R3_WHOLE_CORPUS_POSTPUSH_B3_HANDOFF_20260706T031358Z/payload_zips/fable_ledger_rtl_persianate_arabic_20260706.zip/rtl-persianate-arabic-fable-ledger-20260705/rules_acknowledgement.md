# Rules Acknowledgement

Created UTC: 2026-07-05T18:01:01Z

This artifact implements the Fable object as data for the Session 06 RTL/Persianate/Arabic lane.

Checklist:

- Weighted rooted-tree witness measure / branch-weight witness ledger: done in branch_weight_ledger.csv.
- Language family/branch map: done in languages.csv.
- Per-language source index: done in source_documents.csv.
- Per-word/per-concept index: done in lexemes.jsonl.
- Forms table: done in forms.csv.
- Word/candidate weights: done in word_weights.csv.
- Marginal intelligibility ledger: done in marginal_intelligibility.csv.
- Do-not-use/adverse evidence ledger: done in do_not_use.csv.
- Source-use categories: inherited from language-source-bodies/rtl-persianate-arabic/SOURCE_USE_LABELS.csv and copied into source_documents.csv.
- Full independent interlanguage and complete translations: not done; this package is a lane-local data step.
- Native review / canonical approval / accepted terminology / license clearance / gate promotion / source certification / final status / translation completion: not claimed.

Operational rules applied:

- Linkage is not witness, and witness is not review.
- Generated-draft rows cannot become native-source evidence.
- OCR witnesses are not canonical transcription.
- Arabic, Persian/Farsi, Dari, Tajik, Urdu, Ottoman, Uyghur, and Turkish gates remain separate.
