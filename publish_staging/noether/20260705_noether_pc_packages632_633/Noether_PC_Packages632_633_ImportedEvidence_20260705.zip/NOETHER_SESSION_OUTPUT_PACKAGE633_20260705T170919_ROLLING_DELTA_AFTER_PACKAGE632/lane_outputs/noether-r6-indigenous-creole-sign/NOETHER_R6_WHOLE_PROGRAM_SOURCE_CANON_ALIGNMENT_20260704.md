# Noether R6 Whole-Program Source-Canon Alignment

Generated: 2026-07-04

Lane: Session I / R6 Indigenous, Creole, and Sign Access

Status: source-canon/provenance alignment with scoped draft-support transition metadata. This is not accepted translation, term/sign approval, native-review claim, canonical-approval claim, license-clearance claim, gate promotion, reader claim, lane-completion claim, or Git action.

## Repo-Visible Instructions Read

| Source | Local reading route | R6 implication |
|---|---|---|
| `AGENTS.md` on branch `codex/noether-pc-20260629` | Read from the safe checkout root on branch `codex/noether-pc-20260629` | Source canon comes before translation. R6 must maintain witness/gap rows and only move to scoped draft support when source-canon sufficiency is recorded. |
| `.github/copilot-instructions.md` on branch `codex/noether-pc-20260629` | Read from `.github/copilot-instructions.md` in the same safe checkout | GitHub-visible instructions are the coordination bus. Language lanes do not push. |
| Open-machine GitHub coordination rule | `noether-slavic-handoff\20260629\cross-session-coordination\20260704\NOETHER_OPEN_MACHINE_GITHUB_COORDINATION_RULE_20260704.md` and `.json` in the same safe checkout | GitHub-tracked artifacts and PR-visible records are authoritative; local-only thread chatter and heartbeat wording are not authoritative unless made GitHub-visible. |
| Source-canon sufficiency transition rule | `noether-slavic-handoff\20260629\cross-session-coordination\20260704\NOETHER_SOURCE_CANON_SUFFICIENCY_TRANSLATION_TRANSITION_20260705.md` in the same safe checkout | Source-canon-first is not an endless source-only loop. Covered rows may receive draft, non-canonical review support; uncovered rows remain in source acquisition or gap status. |
| Parent ledger | `C:\Users\memo_\Documents\Codex\2026-07-04\noether-non-slavic-core-lane\outputs\NOETHER_INTERLANGUAGE_TRANSLATION_CONSOLIDATION_LEDGER_20260704.md` | Current live work supersedes older translation-first/checkpoint notes: source-canon witness tables and gaps first. |
| Source-canon steering record | `C:\Users\memo_\Documents\Codex\2026-07-04\noether-non-slavic-core-lane\outputs\NOETHER_SOURCE_CANON_FIRST_STEERING_RECORD_20260704.md` | The required witness-table field shape is now mirrored for R6. |
| B3 steward log | `C:\Users\memo_\Documents\Codex\2026-07-04\noether-github-pr-branch-steward\outputs\NOETHER_SESSION_B_COORDINATOR_RUN_LOG_20260704.md` | B3 source-canon packaging boundaries reviewed; B3 owns staging, commits, pushes, and package checks. |

Safe checkout observed read-only on branch `codex/noether-pc-20260629` at `c8fd72191abb3e3841b571f2497ce719839c9deb`. Earlier B3-owned package-steward drift remains outside R6 control. R6 did not stage, clean, modify, commit, or push the safe checkout.

## Other Lane Outputs Rechecked

| Lane or shelf | Artifact checked | Relevance to R6 |
|---|---|---|
| B3 Slavic source shelves | `noether-slavic-source-canon/20260704/` in the safe checkout | Confirms shared source-canon publication style: TeX/source packages when available, web/PDF provenance and blocked rows otherwise. |
| Slavic canonical baseline | `NOETHER_SLAVIC_TARGET_LANGUAGE_SOURCE_CANON_WITNESS_TABLE_20260704.md` | Confirms local cache, URL reachability, access-boundary, non-contamination, and open-blocker pattern. R6 should not borrow Slavic authority. |
| R2 Pan-Turkic | `NOETHER_R2_PAN_TURKIC_SOURCE_CANON_WITNESS_TABLE_20260704.md` | Closest non-Slavic analogue for explicit zero TeX/source-package result with PDF/HTML witnesses and hard blockers. |
| R7 Malay/SEA/Pacific | `NOETHER_R7_SOURCE_CANON_MATH_CORPUS_WITNESSES_20260704.md` | Shows mixed source-package context rows and PDF/HTML fallback rows. R6 currently has no equivalent source-package row. |
| R9 Africa/Horn/West Africa | `R9_SOURCE_CANON_MATH_CORPUS_WITNESS_TABLE_20260704.md` | Shows how source-level packages can exist for adjacent language-resource topics while algebra/proof-register gaps remain explicit. R6 keeps the same distinction. |
| CJK native/source evidence | `NOETHER_CJK_NATIVE_SOURCE_EVIDENCE_*` outputs | Confirms source evidence and fallback-format provenance can be packageable without native-review or edition claims. |
| R3 Arabic/Persianate LA | `R3_SOURCE_CANON_WITNESS_LAYER_*` outputs | Confirms source-canon witness layers should remain reviewable sidecars, not zip-only hidden evidence. |

No other lane evidence is imported as R6 authority. Cross-lane recheck only supplies formatting, packaging, and blocker-pattern guidance.

## R6 Alignment Outputs

| Artifact | Rows | Purpose |
|---|---:|---|
| `NOETHER_R6_SOURCE_CANON_STRICT_PROVENANCE_WITNESS_TABLE_20260704.csv` | 82 | Strict R6 source witness rows with exact source URLs, local paths, hashes, license/access signals, topic/access tags, and authority notes. |
| `NOETHER_R6_SOURCE_CANON_REQUIRED_FIELD_MIRROR_20260704.csv` | 82 | Normalized mirror matching the current source-canon steering record fields, with no missing URL/path/hash/license/tag fields. |
| `NOETHER_R6_NON_SOURCE_GUARDRAIL_ROWS_20260704.csv` | 10 | International Sign comparator policy/question rows split out as non-source guardrails. |
| `NOETHER_R6_NON_STRICT_ROUTE_METADATA_ROWS_20260704.csv` | 1 | DGS route metadata row with local hash but placeholder URL, split out until exact URL is resolved. |
| `NOETHER_R6_SOURCE_CANON_EXPLICIT_GAP_LEDGER_20260704.csv` | 78 | Explicit exact-source, GitHub/source-repository, URL/access, source-archive, reviewer/source-owner, media/reuse, and authority gaps. |
| `NOETHER_R6_SOURCE_CANON_FIELD_COMPLETENESS_AUDIT_20260704.md` | 1 | Audit explaining the strict witness split, non-source guardrail split, and added GitHub/source-repository gaps. |
| `NOETHER_R6_STRICT_PROVENANCE_PATH_HASH_AUDIT_20260704.md` | 1 | Path/hash replay audit for strict source-canon provenance rows. |
| `NOETHER_R6_STRICT_PROVENANCE_PATH_HASH_AUDIT_20260704.csv` | 82 | Per-row local path existence and SHA-256 verification for strict provenance rows. |
| `NOETHER_R6_STRICT_PROVENANCE_URL_REACHABILITY_AUDIT_20260704.md` | 1 | Headers-only live URL reachability audit for strict exact-URL rows. |
| `NOETHER_R6_STRICT_PROVENANCE_URL_REACHABILITY_AUDIT_20260704.csv` | 82 | Per-row live URL status; no source bodies saved. |
| `NOETHER_R6_STRICT_PROVENANCE_LICENSE_ACCESS_AUDIT_20260704.md` | 1 | License/access and package-use boundary audit summary for strict provenance rows. |
| `NOETHER_R6_STRICT_PROVENANCE_LICENSE_ACCESS_AUDIT_20260704.csv` | 82 | Per-row metadata-only package boundary, payload policy, source-body policy, reviewer/source-owner gate, ethics note, and non-claim boundary. |
| `NOETHER_R6_PUBLIC_SOURCE_ARCHIVE_DISCOVERY_AUDIT_20260704.md` | 1 | Public GitHub/arXiv/CTAN source-archive discovery summary; metadata only. |
| `NOETHER_R6_PUBLIC_SOURCE_ARCHIVE_DISCOVERY_AUDIT_20260704.csv` | 17 | Per-query public source-archive discovery probes and candidate/blocker classifications. |
| `NOETHER_R6_SOURCE_ARCHIVE_CANDIDATE_ROUTE_LEDGER_20260704.csv` | 1 | Candidate GitHub repository route for future manual review; not a strict witness. |
| `NOETHER_R6_SOURCE_ARCHIVE_CANDIDATE_METADATA_HASH_AUDIT_20260704.md` | 1 | Metadata hash audit summary for the GitHub candidate route; no source body captured. |
| `NOETHER_R6_SOURCE_ARCHIVE_CANDIDATE_METADATA_HASH_AUDIT_20260704.csv` | 1 | Candidate route metadata capture path, bytes, SHA-256, URLs, commit, license signal, policy, status, and blockers. |
| `NOETHER_R6_SOURCE_ARCHIVE_CANDIDATE_GITHUB_METADATA_CAPTURE_20260704.json` | 1 | Hashed GitHub API metadata capture for repository, branch, commit, and root listing metadata only. |
| `NOETHER_R6_B3_PACKAGE_BOUNDARY_AUDIT_20260704.md` | 1 | B3 package-boundary audit summary for R6 outputs; metadata-only and no payload/promotion claim. |
| `NOETHER_R6_B3_PACKAGE_BOUNDARY_AUDIT_20260704.csv` | 77 | Per-file package classification for stable non-checksum R6 metadata outputs, excluding audit self-files and checksum manifests. |
| `NOETHER_R6_TARGET_COVERAGE_CROSSWALK_20260704.md` | 1 | Source-canon target coverage crosswalk summary; no source-authority or completion claim. |
| `NOETHER_R6_TARGET_COVERAGE_CROSSWALK_20260704.csv` | 57 | Per-target coverage state across strict witnesses, gaps, candidates, guardrails, and non-strict route rows. |
| `NOETHER_R6_GAP_TRANSITION_REQUIREMENTS_AUDIT_20260704.md` | 1 | Gap transition requirements audit summary; records evidence required before blocker movement. |
| `NOETHER_R6_GAP_TRANSITION_REQUIREMENTS_AUDIT_20260704.csv` | 78 | Per-gap transition class and required source/license/authority evidence; no movement or promotion. |
| `NOETHER_R6_BISLAMA_OFFICIAL_SOURCE_RETRY_ADDENDUM_20260705.md` | 1 | Bislama official-source retry summary; exact Matematiks/Saens PDF captures now exist but authority/reuse gates remain open. |
| `NOETHER_R6_BISLAMA_OFFICIAL_SOURCE_RETRY_ADDENDUM_20260705.csv` | 8 | Per-source Bislama retry rows with URLs, local capture paths, hashes, mirror relationships, language/topic tags, and no-claim boundaries. |
| `NOETHER_R6_ARUBA_PAPIAMENTO_SOURCE_ROUTE_RETRY_ADDENDUM_20260705.md` | 1 | Aruba Papiamento route retry summary; official EA.AW routes remain source-access blockers, not captured witnesses. |
| `NOETHER_R6_ARUBA_PAPIAMENTO_SOURCE_ROUTE_RETRY_ADDENDUM_20260705.csv` | 7 | Per-route Aruba retry rows with official URLs, probe-metadata hash, direct 404/verification outcomes, tags, and no-claim boundaries. |
| `NOETHER_R6_GUATEMALA_USPANTEKO_DIGEBI_SOURCE_CAPTURE_ADDENDUM_20260705.md` | 1 | Guatemala Uspanteko source capture summary; exact PDF fallback captured from official DIGEBI product-page download route with authority/reuse gates open. |
| `NOETHER_R6_GUATEMALA_USPANTEKO_DIGEBI_SOURCE_CAPTURE_ADDENDUM_20260705.csv` | 2 | Per-route Uspanteko rows with official URLs, local PDF path, bytes, SHA-256, tags, and no-claim boundaries. |
| `NOETHER_R6_PARAGUAY_GUARANI_MEC_ROUTE_RETRY_ADDENDUM_20260705.md` | 1 | Paraguay Guarani MEC route retry summary; official page and named files are search-visible, but source-body access timed out. |
| `NOETHER_R6_PARAGUAY_GUARANI_MEC_ROUTE_RETRY_ADDENDUM_20260705.csv` | 3 | Per-route Paraguay MEC rows with official URLs, named-file evidence, probe metadata hash, and no-claim boundaries. |
| `NOETHER_R6_BOLIVIA_QUECHUA_RED_MINEDU_SOURCE_CAPTURE_ADDENDUM_20260705.md` | 1 | Bolivia Quechua Red Minedu source capture summary; exact `19985.pdf` captures from HTTPS and HTTP routes share a matching hash. |
| `NOETHER_R6_BOLIVIA_QUECHUA_RED_MINEDU_SOURCE_CAPTURE_ADDENDUM_20260705.csv` | 2 | Per-route Bolivia Quechua rows with Red Minedu URLs, local PDF paths, bytes, SHA-256 values, tags, and no-claim boundaries. |
| `NOETHER_R6_ECUADOR_EIB_KICHWA_CNIB_ROUTE_RETRY_ADDENDUM_20260705.md` | 1 | Ecuador EIB/Kichwa CNIB route retry summary; official CNIB page and exact Kichwa PDF route are recorded, but source-body access timed out. |
| `NOETHER_R6_ECUADOR_EIB_KICHWA_CNIB_ROUTE_RETRY_ADDENDUM_20260705.csv` | 2 | Per-route Ecuador EIB/Kichwa CNIB rows with official URLs, probe metadata hash, failed local access status, tags, and no-claim boundaries. |
| `NOETHER_R6_MEXICO_CONALITEG_INDIGENOUS_ROUTE_RETRY_ADDENDUM_20260705.md` | 1 | Mexico CONALITEG Indigenous route retry summary; official catalogue HTML is captured, but linked book/viewer/PDF bodies remain blocked. |
| `NOETHER_R6_MEXICO_CONALITEG_INDIGENOUS_ROUTE_RETRY_ADDENDUM_20260705.csv` | 7 | Per-route Mexico CONALITEG rows with catalogue URLs, local catalogue hashes, blocked linked-route status, tags, and no-claim boundaries. |
| `NOETHER_R6_SIGN_ACCESS_DGS_ASL_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Sign access source-route summary; existing ASL/DGS route captures are consolidated with a headers-only route probe. |
| `NOETHER_R6_SIGN_ACCESS_DGS_ASL_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 11 | Per-route ASL/DGS rows with local capture hashes, probe metadata hash, source/reviewer/media blockers, and no-claim boundaries. |
| `NOETHER_R6_KREYOL_MIT_AYITI_MENFP_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Kreyol source-route summary; MIT-Ayiti route captures, MENFP/context captures, and GitHub candidate blockers are kept separate. |
| `NOETHER_R6_KREYOL_MIT_AYITI_MENFP_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 12 | Per-route Kreyol/MENFP/GitHub rows with local capture hashes where available, probe metadata hash, source-owner/reviewer blockers, and no-claim boundaries. |
| `NOETHER_R6_MAURITIUS_KREOL_MIE_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Mauritius Kreol/MIE source-route summary; MIE curriculum/context, Kreol Morisien/Kreol Rodrige bookcase, and practice-paper routes are kept as route/blocker metadata. |
| `NOETHER_R6_MAURITIUS_KREOL_MIE_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 8 | Per-route MIE/Kreol rows with local capture hashes and probe metadata hash; exact math body, source-owner/reviewer, and reuse gates remain open. |
| `NOETHER_R6_KRIO_SIERRA_LEONE_MBSSE_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Krio/Sierra Leone source-route summary; official Krio syllabus and Sierra Leone mathematics/context comparator routes are kept as route/blocker metadata. |
| `NOETHER_R6_KRIO_SIERRA_LEONE_MBSSE_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 5 | Per-route Krio/MBSSE/TSC rows with local capture hashes and probe metadata hash; exact Krio math body, source-owner/reviewer, and reuse gates remain open. |
| `NOETHER_R6_TOK_PISIN_PNG_FODE_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Tok Pisin/PNG source-route summary; official FODE Tok Pisin language-context and English mathematics comparator routes are kept as route/blocker metadata. |
| `NOETHER_R6_TOK_PISIN_PNG_FODE_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 5 | Per-route Tok Pisin/PNG FODE rows with local capture hashes and probe metadata hash; exact Tok Pisin math body, source-owner/reviewer, and reuse gates remain open. |
| `NOETHER_R6_NIGERIAN_PIDGIN_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Nigerian Pidgin source-route summary; NERDC/FME policy and English mathematics comparator routes plus public GitHub `pcm` source-file candidates are kept as route/blocker metadata. |
| `NOETHER_R6_NIGERIAN_PIDGIN_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 7 | Per-route Nigerian Pidgin/Nigeria rows with local capture hashes and probe metadata hash; exact Nigerian Pidgin math body, source-owner/reviewer, source-archive, and reuse gates remain open. |
| `NOETHER_R6_CAPE_VERDEAN_KRIOLU_SOURCE_ROUTE_ADDENDUM_20260705.md` | 1 | Cape Verdean Kriolu source-route summary; Cabo Verde Portuguese mathematics comparators and Kriolu/bilingual-education context routes are kept as route/blocker metadata. |
| `NOETHER_R6_CAPE_VERDEAN_KRIOLU_SOURCE_ROUTE_ADDENDUM_20260705.csv` | 5 | Per-route Cape Verdean Kriolu/Cabo Verde rows with local capture hashes and probe metadata hash; exact Kriolu math body, source-owner/reviewer, source-archive, and reuse gates remain open. |
| `NOETHER_R6_SOURCE_STATE_INVARIANT_AUDIT_20260704.md` | 1 | Source-state invariant audit summary; 14 pass, 0 fail, no promotion. |
| `NOETHER_R6_SOURCE_STATE_INVARIANT_AUDIT_20260704.csv` | 14 | Per-invariant status across strict/gap/candidate/guardrail/crosswalk/B3/gate/manifest artifacts. |
| `NOETHER_R6_SOURCE_CANON_SUFFICIENCY_TRANSITION_AUDIT_20260705.md` | 1 | Source-canon sufficiency transition summary; Kreyol and Bislama only are scoped for draft review support. |
| `NOETHER_R6_SOURCE_CANON_SUFFICIENCY_TRANSITION_AUDIT_20260705.csv` | 6 | Per-target sufficiency/gap decision rows for covered Kreyol/Bislama, blocked Tok Pisin, Nigerian Pidgin, Cape Verdean Kriolu, and sign-access rows. |
| `NOETHER_R6_SCOPED_DRAFT_TRANSLATION_SUPPORT_CREOLE_COVERED_ROWS_20260705.md` | 1 | Draft, non-canonical review-support summary for covered creole rows only; not native reviewed, accepted, complete, or package-promoted. |
| `NOETHER_R6_SCOPED_DRAFT_TRANSLATION_SUPPORT_CREOLE_COVERED_ROWS_20260705.csv` | 6 | Per-row Kreyol/Bislama draft support with source witness IDs, source-context notes, alternatives, formula-neighboring notes, and reviewer questions. |
| `NOETHER_R6_GITHUB_GOVERNANCE_SYNC_20260705.md` | 1 | GitHub-visible governance sync summary with instruction-bus hashes, local ledger hashes, R6 compliance state, and B3-facing blockers/tasks. |
| `NOETHER_R6_GITHUB_GOVERNANCE_SYNC_20260705.csv` | 14 | Structured governance sync rows covering GitHub bus files, local ledgers, R6 current state, covered-row tasks, blockers, and package boundary. |

Normalized mirror facts:

| Field check | Count |
|---|---:|
| Source-level TeX/LaTeX/arXiv/e-print/GitHub/source archive rows | 0 |
| PDF/HTML/text-style fallback or source-route rows | 50 |
| Video/dynamic signed-language route rows | 32 |
| Target/source access route rows that still lack authority | 68 |
| Candidate or context rows that still lack exact math authority | 11 |
| Comparator-only strict source rows | 4 |
| Non-source comparator guardrail rows | 10 |
| Non-strict placeholder-URL route metadata rows | 1 |
| Strict provenance rows with local path found | 82 |
| Strict provenance rows with recorded SHA-256 matching disk | 82 |
| Missing local paths or hash mismatches | 0 |
| Strict URLs reachable by headers/range audit | 77 |
| Strict URLs access-restricted endpoint-present | 5 |
| Strict provenance rows with license/access class and payload policy | 82 |
| Missing license/access classes or payload policies | 0 |
| Rows still metadata-only for package/source-body use from this lane | 82 |
| Public source-archive discovery probes added | 17 |
| Public GitHub repository candidate routes split out | 1 |
| Candidate routes with hashed local metadata capture | 1 |
| New strict source-archive witnesses from discovery slice | 0 |
| B3 package-boundary stable non-checksum files classified | 77 |
| B3 raw source-body, zip, temp/cache/runtime, over-5-MiB, or payload flags | 0 |
| Source-canon sufficiency transition audit rows | 6 |
| Scoped draft-support review rows | 6 |
| R6 targets currently allowed draft support under sufficiency rule | 2 |
| R6 sufficiency rows still blocked from draft support | 4 |
| GitHub governance sync rows | 14 |
| Target coverage crosswalk rows | 57 |
| Crosswalk rows with source-authority or completion claims | 0 |
| Explicit gap rows with transition requirements | 78 |
| Gap rows allowed to move or promote now | 0 |
| Bislama official-source retry rows | 8 |
| Bislama retry rows with source-authority/reuse gates still open | 8 |
| Aruba Papiamento route retry rows | 7 |
| Aruba route retry rows with source-body capture still blocked | 7 |
| Guatemala Uspanteko source capture rows | 2 |
| Guatemala Uspanteko capture rows with source-authority/reuse gates still open | 2 |
| Paraguay Guarani MEC route retry rows | 3 |
| Paraguay route retry rows with source-body access still blocked | 3 |
| Bolivia Quechua Red Minedu source capture rows | 2 |
| Bolivia capture rows with source-authority/reuse gates still open | 2 |
| Ecuador EIB/Kichwa CNIB route retry rows | 2 |
| Ecuador route retry rows with source-body access still blocked | 2 |
| Mexico CONALITEG Indigenous route retry rows | 7 |
| Mexico route retry rows with linked book bodies still blocked | 7 |
| Mauritius Kreol/MIE route addendum rows | 8 |
| Mauritius route rows with exact math/STEM body still blocked | 8 |
| Krio Sierra Leone route addendum rows | 5 |
| Krio route rows with exact Krio math/STEM body still blocked | 5 |
| Tok Pisin PNG FODE route addendum rows | 5 |
| Tok Pisin route rows with exact Tok Pisin math/STEM body still blocked | 5 |
| Nigerian Pidgin route addendum rows | 7 |
| Nigerian Pidgin route rows with exact Nigerian Pidgin math/STEM body still blocked | 7 |
| Cape Verdean Kriolu route addendum rows | 5 |
| Cape Verdean Kriolu route rows with exact Kriolu math/STEM body still blocked | 5 |
| Source-state invariant audit rows | 14 |
| Source-state invariant failures | 0 |

## R6 Source-Archive Boundary

Recovered R6 evidence still contains no validated native mathematical TeX, LaTeX, arXiv, e-print, GitHub source repository, CTAN-style package, or source archive for the Indigenous, creole/contact, or signed-language access targets. That absence is represented as explicit gap/blocker evidence, including `R6-GITHUB-GAP-001` through `R6-GITHUB-GAP-003`. The public discovery slice adds one candidate GitHub repository metadata route, `mexicanisimo/Tutoaula`, and the metadata hash audit records a local metadata-only capture hash for that route. The candidate remains outside strict witness status until source-body review, file hashes for actual source files, target-language mathematics evidence, source-owner/reviewer route, and package boundary are recorded. Blocked gap state must not be used to infer a technical register, start draft support, promote terms/signs, or collapse named languages/access communities into a generalized interlanguage route. The only current draft-support exception is the recorded sufficiency transition for scoped Kreyol and Bislama classroom mathematics/STEM rows.

## Live Non-Claim Boundary

Allowed current use:

- source-location and provenance maintenance;
- URL/local-path/hash/license-signal checking;
- target-language/access tags;
- reviewer/source-owner question preparation;
- explicit gap rows and blocker ledgers;
- scoped draft, non-canonical review scaffolds for covered Kreyol and Bislama rows only;
- B3 package metadata consumption if B3 gates it.

Blocked current use:

- accepted/canonical translation, translation completion, or draft support for uncovered rows;
- pilot creation;
- term spine;
- sign or visual inventory;
- source-authority promotion;
- native-review, community-consent, canonical-approval, license-clearance, gate-promotion, or lane-completion claims;
- Git push from R6.

## Next Maintenance Gates

Future R6 work should only alter source-canon state when one of these lands:

1. A new exact target-language mathematical source witness with URL, local path, hash, license/access signal, and language/topic tags.
2. A source-level TeX/LaTeX/arXiv/e-print/GitHub/source archive witness that is genuinely for an R6 target and passes access/license checks.
3. A dated reviewer/source-owner return, recorded separately from reuse/media clearance.
4. A media/reuse decision for signed-language routes, recorded separately from sign authority.
5. A correction to existing witness metadata, hashes, URLs, local paths, or gap status.
6. A recorded sufficiency transition from exact target-language source witnesses to draft, non-canonical review support, with uncovered rows left in source acquisition or gap status.
