# SGA6 Claude/Codex source-rescribe workpass evidence

This folder mirrors the current local Claude/Codex SGA6 source-rescribe workpass from:

`C:\Users\Floris\Documents\Papors\Chatnotes\CHat translates and clean\SGA continuation 2\_claude_aid\sga6_full_audit_20260703`

Status as of 2026-07-05 local sweep:

- Current CERT_LOG frontier: entry #195, idx198 / volume p185 / Expose II p26.
- Next cursor: idx199 / volume p186 / Expose II p27.
- Current workpass build: `sga6_fr_workpass.pdf`, 390 pages, 0 LaTeX errors per `sga6_fr_workpass.log`.
- The latest logged source fix restores a major proof-condensation in Preuve 2.4.8.1, including a full-page normalization argument, display/inline corrections, Oka/normalization citations, `resp.` reversions, and book-quirk reproductions.
- This is source-rescribe/workpass provenance only. It is not completed SGA6 reader output, not English synchronization, not whole-volume source-faithfulness certification, not index audit, not publication readiness, and not a critical edition.

Use `SHA256SUMS.txt` for local file-integrity checks.
