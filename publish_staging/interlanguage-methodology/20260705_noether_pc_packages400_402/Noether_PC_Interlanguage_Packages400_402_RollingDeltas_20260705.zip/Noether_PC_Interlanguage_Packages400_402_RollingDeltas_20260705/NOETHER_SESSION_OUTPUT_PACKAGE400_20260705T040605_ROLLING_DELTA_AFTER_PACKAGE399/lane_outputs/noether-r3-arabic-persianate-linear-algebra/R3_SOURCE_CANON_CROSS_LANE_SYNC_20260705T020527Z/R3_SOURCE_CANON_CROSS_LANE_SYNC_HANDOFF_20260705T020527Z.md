# R3 Source-Canon Cross-Lane Sync

Created: 20260705T020527Z

Status: source-canon/provenance sync only. This is not translation, glossary expansion, bridge promotion, native review, canonical approval, license clearance, gate promotion, completion, packaging, or Git push.

## Current R3 Spine

- Master source-canon index: 70 rows.
- Policy-sync table: 70 rows with normalized access/upload/license classes.
- Arabic external-pointer probe: 13 targets, 9 hash matches, 4 live-drift/hash mismatch rows, 0 fetch failures.
- Source-body omit manifest: 114 raw/source-body omit rows, 73 under current pointers/cache, 28 duplicate hash groups.
- Target-language source witness probe: 9 rows, including fallback witnesses and explicit TeX/source-package gaps.
- Source-archive frontier probe: 11 rows, including GitHub/API zero-hit gaps, access blockers, and false-positive rejections.
- ArXiv/e-print frontier probe: 11 rows, including query-metadata hashes, zero-hit gaps, screening blockers, and one existing non-authorizing e-print pointer where present.
- Zenodo source frontier probe: 12 rows, including repository metadata hashes, source/archive hints, fallback hints, and screening blockers.
- Internet Archive text/PDF frontier probe: 10 rows, including Archive query/item metadata hashes, file-hash signals, and route-specific gap rows.

## Cross-Lane State

- Arabic lane has an R3 intake, but the owner-lane markdown still cites older R3 policy/probe timestamps. Current R3 pointers are policy 20260704T210315Z and Arabic probe 20260704T210216Z; refresh is recorded as an action row.
- Persianate/Tajik owner witness table has 15 rows, all 15 without explicit upload/payload policy fields. R3 provides route-compatible policy hints only; it does not edit owner-lane files.
- GitHub-visible source-canon shelves are present under C:\Users\memo_\Documents\Codex\2026-06-29\updatede-goal-text-maintain-the-noether-2\work\github-checkouts\modern-latex-manuscripts-noether-pc-nocone-20260702\noether-slavic-source-canon\20260704 with 8 directories. They are comparison/provenance-shape shelves, not Arabic or Persianate authority.

## Open Actions

- Gap/action sidecar rows: 35.
- Durable R3 row log append: 123 rows, each with route, source pointer, support choice, blocker, and sidecar decision.
- B3 package boundary: use unpacked sidecars/checksums; omit raw source bodies and probe caches unless B3 creates a gated source-canon payload artifact.

## Files

- Cross-lane rows: C:\Users\memo_\Documents\Codex\2026-07-04\noether-r3-arabic-persianate-linear-algebra\outputs\R3_SOURCE_CANON_CROSS_LANE_SYNC_20260705T020527Z\R3_SOURCE_CANON_CROSS_LANE_SYNC_ROWS_20260705T020527Z.csv
- Open gaps/actions: C:\Users\memo_\Documents\Codex\2026-07-04\noether-r3-arabic-persianate-linear-algebra\outputs\R3_SOURCE_CANON_CROSS_LANE_SYNC_20260705T020527Z\R3_SOURCE_CANON_OPEN_GAPS_AND_REFRESH_ACTIONS_20260705T020527Z.csv
- Durable log append rows: C:\Users\memo_\Documents\Codex\2026-07-04\noether-r3-arabic-persianate-linear-algebra\outputs\R3_SOURCE_CANON_CROSS_LANE_SYNC_20260705T020527Z\R3_SOURCE_CANON_DURABLE_RUN_LOG_APPEND_ROWS_20260705T020527Z.csv
- Validation: C:\Users\memo_\Documents\Codex\2026-07-04\noether-r3-arabic-persianate-linear-algebra\outputs\R3_SOURCE_CANON_CROSS_LANE_SYNC_20260705T020527Z\R3_SOURCE_CANON_CROSS_LANE_SYNC_VALIDATION_20260705T020527Z.json
- Checksums: C:\Users\memo_\Documents\Codex\2026-07-04\noether-r3-arabic-persianate-linear-algebra\outputs\R3_SOURCE_CANON_CROSS_LANE_SYNC_20260705T020527Z\R3_SOURCE_CANON_CROSS_LANE_SYNC_CHECKSUMS_20260705T020527Z.sha256
