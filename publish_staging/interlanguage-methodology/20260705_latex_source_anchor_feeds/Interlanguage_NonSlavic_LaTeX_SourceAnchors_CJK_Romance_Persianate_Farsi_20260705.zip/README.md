# Interlanguage LaTeX Source Anchors - 2026-07-05

Purpose: feed web/pro review sessions actual LaTeX/source-anchor material, not generated translations, screenshots, logs, or source-route promises.

Contents are source-anchor files already present in the public repo plus two downloaded Farsi/Persian GitHub math-source repositories referenced by the latest source ledgers.

Status boundaries:
- These are native/source-anchor or source-corpus candidate files for terminology/framework anchoring.
- They are not Noether translations, not term approvals, not native-review certification, and not critical editions.
- Some Slavic folders are broad GitHub TeX captures and include mixed quality/relevance. Use MANIFEST.csv and source paths for triage.
- Downloaded Farsi source repos included here: ArsalanDalvand/atomathix-latex and SireJeff/linear-algebra-3blue1brown-notes.

Use:
1. Start with MANIFEST.csv and COUNTS_BY_LANE_EXTENSION.csv.
2. Use TeX-family files as language/register anchors.
3. Do not treat generated project translations as native witness material unless separately marked.
