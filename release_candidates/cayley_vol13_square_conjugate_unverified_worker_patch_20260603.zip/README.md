# Cayley Vol. XIII Square / Table-of-Conjugates Worker Patch - Unverified

This packet preserves a worker-generated native-LaTeX replacement attempt for three prose witnesses in `cayley_vol13_pages_301_325.tex`:

- square diagrams for weights 2-10;
- continuation square diagrams for weights 8-10;
- the printed p. 303 Table of Conjugates.

Do **not** promote this patch directly. It was saved because it may be useful as a scaffold, but local review found that the p. 303 table is a readable rotated stepped table in the scan and must be checked cell-by-cell before public release. The worker output is clean-looking, but not yet proven scan-faithful.

Included witnesses:

- `scan_pdf_page_316_printed_294_squares_w8_w10.png`
- `scan_pdf_page_317_printed_295_w7_filled_square_text.png`
- `scan_pdf_page_325_printed_303_table_of_conjugates.png`
- `UNVERIFIED_vol13_square_conjugate_worker.diff`

Current policy: keep the committed source's honest prose witness until the table is exactly transcribed or reconstructed with a documented cell audit.
