# Grupe, simetrije i tenzori u fizici

Ovo je "otvoreni" udžbenik fizike, napisan u LaTeX-u.
Diseminacija elektroničkim putem, te printanje dijelova ili cijele knjige je dozvoljeno
u okviru licence  [Creative Commons Attribution-ShareAlike 4.0 International License](http://creativecommons.org/licenses/by-sa/4.0/), vidi i datoteku LICENSE.txt za detalje.

## Pristup elektroničkoj verziji knjige

- **Najnovija verzija u PDF formatu**: [Najnoviji PDF](https://github.com/kkumer/simetrije/releases/latest/download/simetrije.pdf)
- **Sve verzije**: [Sve verzije](https://github.com/kkumer/simetrije/releases) 


## Pristup tiskanoj verziji knjige

- **Print-on-demand**: Najnoviju verziju (ver-0.9.10) je moguće naručiti putem
[print-on-demand servisa lulu.com](https://www.lulu.com/shop/kre%C5%A1imir-kumeri%C4%8Dki/grupe-simetrije-i-tenzori-u-fizici/paperback/product-m2yr2pw.html) 
(tvrdi uvez, 16 EUR + poštarina 8 EUR, cijena taman pokriva troškove tiska).

- **Knjižnica PMF, Fizički odsjek**: Nakon završenog recenzentskog postupka i tiska,
knjiga će se moći posuditi ili kupiti
u knjižnici FO, PMF (po cijeni vjerojatno nižoj od ove gore). Najvjerojatnije ne prije ljeta 2026.

## Korekcije i modifikacije

Izvedenice ove knjige (npr. izolirani dijelovi ili modificirane verzije knjige) moraju
minimalno navesti 1. izvornog autora, 2. izvorni naziv knjige, 3. modifikacije, ako
ih ima i 4. poveznicu na ovaj GitHub repozitorij.

Korekcije ovoj verziji knjige možete poslati putem "Pull request" procedure
ili putem "Issues."


**Copyright © 2025 Krešimir Kumerički. Sva prava pridržana.**


