# Non-Russian / Non-Ukrainian Slavic baseline source bundle

Built: 20260704

Purpose: source/reference feed for Slavic mathematical terminology work excluding Russian and Ukrainian. This is a source/control baseline bundle, not a translation output and not a certification layer.

Included primary languages from the broad Slavic register: Czech, Polish, Slovak, Slovenian, Serbian, Croatian, Bulgarian. Belarusian/Macedonian/Sorbian/Interslavic rows are only included if actual source files were present or registered; this build found the broad PDF reference shelf mostly in the seven languages above.

The package contains:
- one folder per language with downloaded registered PDF source/reference witnesses where the source URL resolved;
- MANIFEST_non_ru_uk_slavic_sources.csv with id, language, role, URL, byte count, SHA256, and download status;
- the upstream broad reference register from the Noether PC branch;
- xtra_local_latex_or_pdf_found/ for any local non-RU/non-UK Slavic TeX/PDF files found by filename/path scan.

Boundary: Russian and Ukrainian are deliberately excluded from this ZIP. Generated Interslavic/Russian/Ukrainian Noether translations are not used as source witnesses here.
